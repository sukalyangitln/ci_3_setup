<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-19 00:02:22 --> Total execution time: 0.0636
DEBUG - 2022-05-19 00:02:28 --> Total execution time: 0.0144
DEBUG - 2022-05-19 00:03:20 --> Total execution time: 0.0136
DEBUG - 2022-05-19 00:03:28 --> Total execution time: 0.0195
DEBUG - 2022-05-19 00:03:54 --> Total execution time: 0.0240
DEBUG - 2022-05-19 00:03:55 --> Total execution time: 0.0157
DEBUG - 2022-05-19 01:04:54 --> Total execution time: 0.1389
DEBUG - 2022-05-19 01:04:58 --> Total execution time: 0.0222
DEBUG - 2022-05-19 01:33:55 --> Total execution time: 0.1086
DEBUG - 2022-05-19 01:34:25 --> Total execution time: 0.0171
DEBUG - 2022-05-19 01:34:38 --> Total execution time: 0.0202
DEBUG - 2022-05-19 01:34:57 --> Total execution time: 0.0151
DEBUG - 2022-05-19 01:35:01 --> Total execution time: 0.0283
DEBUG - 2022-05-19 01:35:12 --> Total execution time: 0.0210
DEBUG - 2022-05-19 01:35:21 --> Total execution time: 0.0240
DEBUG - 2022-05-19 01:35:46 --> Total execution time: 0.0224
DEBUG - 2022-05-19 01:36:04 --> Total execution time: 0.0234
DEBUG - 2022-05-19 01:36:07 --> Total execution time: 0.0101
DEBUG - 2022-05-19 01:36:17 --> Total execution time: 0.0121
DEBUG - 2022-05-19 01:36:33 --> Total execution time: 0.1725
DEBUG - 2022-05-19 01:37:24 --> Total execution time: 0.0237
DEBUG - 2022-05-19 01:37:30 --> Total execution time: 0.1118
DEBUG - 2022-05-19 01:37:47 --> Total execution time: 0.0158
DEBUG - 2022-05-19 01:37:49 --> Total execution time: 0.0141
DEBUG - 2022-05-19 01:37:51 --> Total execution time: 0.0231
DEBUG - 2022-05-19 01:37:53 --> Total execution time: 0.0186
DEBUG - 2022-05-19 01:37:55 --> Total execution time: 0.0162
DEBUG - 2022-05-19 01:37:56 --> Total execution time: 0.0137
DEBUG - 2022-05-19 01:37:59 --> Total execution time: 0.0132
DEBUG - 2022-05-19 01:38:19 --> Total execution time: 0.0151
DEBUG - 2022-05-19 01:38:23 --> Total execution time: 0.0122
DEBUG - 2022-05-19 01:38:36 --> Total execution time: 0.0139
DEBUG - 2022-05-19 01:38:47 --> Total execution time: 0.0143
DEBUG - 2022-05-19 01:38:49 --> Total execution time: 0.0152
DEBUG - 2022-05-19 01:39:28 --> Total execution time: 0.0184
DEBUG - 2022-05-19 01:39:31 --> Total execution time: 0.0135
DEBUG - 2022-05-19 01:39:36 --> Total execution time: 0.0173
DEBUG - 2022-05-19 01:39:38 --> Total execution time: 0.0178
DEBUG - 2022-05-19 01:39:55 --> Total execution time: 0.0146
DEBUG - 2022-05-19 01:40:02 --> Total execution time: 0.0140
DEBUG - 2022-05-19 01:40:05 --> Total execution time: 0.0192
DEBUG - 2022-05-19 01:40:15 --> Total execution time: 0.0278
DEBUG - 2022-05-19 01:40:38 --> Total execution time: 0.0160
DEBUG - 2022-05-19 01:40:47 --> Total execution time: 0.0161
DEBUG - 2022-05-19 01:40:49 --> Total execution time: 0.0151
DEBUG - 2022-05-19 01:43:00 --> Total execution time: 0.0617
DEBUG - 2022-05-19 01:43:03 --> Total execution time: 0.0171
DEBUG - 2022-05-19 01:43:07 --> Total execution time: 0.0401
DEBUG - 2022-05-19 01:43:09 --> Total execution time: 0.0126
DEBUG - 2022-05-19 01:43:23 --> Total execution time: 0.0162
DEBUG - 2022-05-19 02:14:02 --> Total execution time: 0.1828
DEBUG - 2022-05-19 06:50:58 --> Total execution time: 0.1192
DEBUG - 2022-05-19 06:53:09 --> Total execution time: 0.0648
DEBUG - 2022-05-19 06:53:13 --> Total execution time: 0.0163
DEBUG - 2022-05-19 06:53:54 --> Total execution time: 0.0240
DEBUG - 2022-05-19 06:54:31 --> Total execution time: 0.0275
DEBUG - 2022-05-19 06:55:06 --> Total execution time: 0.0587
DEBUG - 2022-05-19 06:56:06 --> Total execution time: 0.0173
DEBUG - 2022-05-19 06:56:07 --> Total execution time: 0.0139
DEBUG - 2022-05-19 06:56:17 --> Total execution time: 0.0188
DEBUG - 2022-05-19 06:56:17 --> Total execution time: 0.0192
DEBUG - 2022-05-19 07:42:06 --> Total execution time: 0.0226
DEBUG - 2022-05-19 07:44:29 --> Total execution time: 0.0167
DEBUG - 2022-05-19 07:44:51 --> Total execution time: 0.0229
DEBUG - 2022-05-19 07:45:03 --> Total execution time: 0.0604
DEBUG - 2022-05-19 07:45:40 --> Total execution time: 0.0211
DEBUG - 2022-05-19 07:45:48 --> Total execution time: 0.0142
DEBUG - 2022-05-19 07:45:55 --> Total execution time: 0.0220
DEBUG - 2022-05-19 07:46:09 --> Total execution time: 0.0133
DEBUG - 2022-05-19 07:50:37 --> Total execution time: 0.0987
DEBUG - 2022-05-19 07:51:21 --> Total execution time: 0.0169
DEBUG - 2022-05-19 07:51:41 --> Total execution time: 0.0221
DEBUG - 2022-05-19 07:51:54 --> Total execution time: 0.0348
DEBUG - 2022-05-19 07:52:26 --> Total execution time: 0.0239
DEBUG - 2022-05-19 07:52:44 --> Total execution time: 0.0151
DEBUG - 2022-05-19 07:53:00 --> Total execution time: 0.0180
DEBUG - 2022-05-19 07:53:05 --> Total execution time: 0.0163
DEBUG - 2022-05-19 07:53:07 --> Total execution time: 0.0302
DEBUG - 2022-05-19 07:53:09 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:53:12 --> Total execution time: 0.0245
DEBUG - 2022-05-19 07:53:14 --> Total execution time: 0.0235
DEBUG - 2022-05-19 07:53:18 --> Total execution time: 0.0154
DEBUG - 2022-05-19 07:53:23 --> Total execution time: 0.0168
DEBUG - 2022-05-19 07:53:33 --> Total execution time: 0.0145
DEBUG - 2022-05-19 07:53:37 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:53:40 --> Total execution time: 0.0178
DEBUG - 2022-05-19 07:53:42 --> Total execution time: 0.0254
DEBUG - 2022-05-19 07:57:18 --> Total execution time: 0.0349
DEBUG - 2022-05-19 07:58:11 --> Total execution time: 0.0134
DEBUG - 2022-05-19 08:00:52 --> Total execution time: 0.0147
DEBUG - 2022-05-19 08:06:04 --> Total execution time: 0.0197
DEBUG - 2022-05-19 08:06:22 --> Total execution time: 0.0233
DEBUG - 2022-05-19 08:06:37 --> Total execution time: 0.0386
DEBUG - 2022-05-19 08:09:16 --> Total execution time: 0.0178
DEBUG - 2022-05-19 08:11:40 --> Total execution time: 0.0198
DEBUG - 2022-05-19 08:12:10 --> Total execution time: 0.0175
DEBUG - 2022-05-19 08:12:42 --> Total execution time: 0.0174
DEBUG - 2022-05-19 08:13:00 --> Total execution time: 0.0250
DEBUG - 2022-05-19 08:13:09 --> Total execution time: 0.0139
DEBUG - 2022-05-19 08:14:41 --> Total execution time: 0.0181
DEBUG - 2022-05-19 08:14:46 --> Total execution time: 0.0141
DEBUG - 2022-05-19 08:14:56 --> Total execution time: 0.0157
DEBUG - 2022-05-19 08:15:05 --> Total execution time: 0.0352
DEBUG - 2022-05-19 08:15:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 08:15:27 --> Total execution time: 0.0234
DEBUG - 2022-05-19 08:15:51 --> Total execution time: 0.0226
DEBUG - 2022-05-19 08:16:08 --> Total execution time: 0.0198
DEBUG - 2022-05-19 08:16:14 --> Total execution time: 0.0181
DEBUG - 2022-05-19 08:16:18 --> Total execution time: 0.0212
DEBUG - 2022-05-19 08:16:29 --> Total execution time: 0.0222
DEBUG - 2022-05-19 08:16:41 --> Total execution time: 0.0149
DEBUG - 2022-05-19 08:16:43 --> Total execution time: 0.0179
DEBUG - 2022-05-19 08:16:45 --> Total execution time: 0.0226
DEBUG - 2022-05-19 08:16:49 --> Total execution time: 0.0226
DEBUG - 2022-05-19 08:16:52 --> Total execution time: 0.0212
DEBUG - 2022-05-19 08:16:54 --> Total execution time: 0.0155
DEBUG - 2022-05-19 08:17:03 --> Total execution time: 0.0198
DEBUG - 2022-05-19 08:17:07 --> Total execution time: 0.0148
DEBUG - 2022-05-19 08:17:09 --> Total execution time: 0.0213
DEBUG - 2022-05-19 08:17:26 --> Total execution time: 0.0227
DEBUG - 2022-05-19 08:26:32 --> Total execution time: 0.0160
DEBUG - 2022-05-19 08:29:34 --> Total execution time: 0.0197
DEBUG - 2022-05-19 08:29:47 --> Total execution time: 0.0278
DEBUG - 2022-05-19 08:29:51 --> Total execution time: 0.0269
DEBUG - 2022-05-19 08:30:09 --> Total execution time: 0.0355
DEBUG - 2022-05-19 09:19:15 --> Total execution time: 0.0901
DEBUG - 2022-05-19 09:19:20 --> Total execution time: 0.0345
DEBUG - 2022-05-19 09:19:26 --> Total execution time: 0.0328
DEBUG - 2022-05-19 09:19:31 --> Total execution time: 0.0318
DEBUG - 2022-05-19 09:19:34 --> Total execution time: 0.0330
DEBUG - 2022-05-19 09:19:34 --> Total execution time: 0.0340
DEBUG - 2022-05-19 09:19:34 --> Total execution time: 0.0359
DEBUG - 2022-05-19 09:19:34 --> Total execution time: 0.0308
DEBUG - 2022-05-19 09:19:44 --> Total execution time: 0.0345
DEBUG - 2022-05-19 09:20:31 --> Total execution time: 0.0384
DEBUG - 2022-05-19 09:35:20 --> Total execution time: 0.0171
DEBUG - 2022-05-19 09:44:15 --> Total execution time: 0.0433
DEBUG - 2022-05-19 09:45:32 --> Total execution time: 0.0218
DEBUG - 2022-05-19 09:45:52 --> Total execution time: 0.0130
DEBUG - 2022-05-19 09:47:38 --> Total execution time: 0.0299
DEBUG - 2022-05-19 09:47:44 --> Total execution time: 0.0253
DEBUG - 2022-05-19 09:47:58 --> Total execution time: 0.0172
DEBUG - 2022-05-19 09:48:21 --> Total execution time: 0.0192
DEBUG - 2022-05-19 09:48:39 --> Total execution time: 0.0170
DEBUG - 2022-05-19 09:48:47 --> Total execution time: 0.0205
DEBUG - 2022-05-19 09:48:58 --> Total execution time: 0.0398
DEBUG - 2022-05-19 10:00:23 --> Total execution time: 0.1236
DEBUG - 2022-05-19 10:01:18 --> Total execution time: 0.0370
DEBUG - 2022-05-19 10:01:21 --> Total execution time: 0.0361
DEBUG - 2022-05-19 10:01:24 --> Total execution time: 0.0174
DEBUG - 2022-05-19 10:01:54 --> Total execution time: 0.0495
DEBUG - 2022-05-19 10:04:45 --> Total execution time: 0.0959
DEBUG - 2022-05-19 10:05:07 --> Total execution time: 0.0180
DEBUG - 2022-05-19 10:05:28 --> Total execution time: 0.0141
DEBUG - 2022-05-19 10:09:09 --> Total execution time: 0.0208
DEBUG - 2022-05-19 10:09:27 --> Total execution time: 0.0270
DEBUG - 2022-05-19 10:09:41 --> Total execution time: 0.0171
DEBUG - 2022-05-19 10:09:44 --> Total execution time: 0.0181
DEBUG - 2022-05-19 10:09:53 --> Total execution time: 0.0270
DEBUG - 2022-05-19 10:14:39 --> Total execution time: 0.0604
DEBUG - 2022-05-19 10:14:39 --> Total execution time: 0.0431
DEBUG - 2022-05-19 10:14:45 --> Total execution time: 0.0346
DEBUG - 2022-05-19 10:15:11 --> Total execution time: 0.0403
DEBUG - 2022-05-19 10:15:14 --> Total execution time: 0.0519
DEBUG - 2022-05-19 10:15:24 --> Total execution time: 0.1354
DEBUG - 2022-05-19 10:16:21 --> Total execution time: 0.0332
DEBUG - 2022-05-19 10:16:29 --> Total execution time: 0.3311
DEBUG - 2022-05-19 10:16:42 --> Total execution time: 0.2279
DEBUG - 2022-05-19 10:16:45 --> Total execution time: 0.0377
DEBUG - 2022-05-19 10:16:52 --> Total execution time: 0.0572
DEBUG - 2022-05-19 10:17:11 --> Total execution time: 0.0385
DEBUG - 2022-05-19 10:17:20 --> Total execution time: 0.0336
DEBUG - 2022-05-19 10:22:58 --> Total execution time: 0.0156
DEBUG - 2022-05-19 00:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:41 --> Total execution time: 0.0705
DEBUG - 2022-05-19 00:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:45 --> Total execution time: 0.0507
DEBUG - 2022-05-19 00:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:54 --> Total execution time: 0.0341
DEBUG - 2022-05-19 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:15:53 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:45:53 --> Total execution time: 0.0690
DEBUG - 2022-05-19 00:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:17:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:47:05 --> Total execution time: 0.0532
DEBUG - 2022-05-19 00:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:48:51 --> Total execution time: 0.0331
DEBUG - 2022-05-19 00:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 00:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:49:11 --> Total execution time: 0.0454
DEBUG - 2022-05-19 00:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:49:30 --> Total execution time: 0.0556
DEBUG - 2022-05-19 00:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:49:33 --> Total execution time: 0.0481
DEBUG - 2022-05-19 00:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:49:44 --> Total execution time: 0.0320
DEBUG - 2022-05-19 00:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:04 --> Total execution time: 0.0592
DEBUG - 2022-05-19 00:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:08 --> Total execution time: 0.0424
DEBUG - 2022-05-19 00:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:36 --> Total execution time: 0.0513
DEBUG - 2022-05-19 00:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:43 --> Total execution time: 0.0876
DEBUG - 2022-05-19 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:52:32 --> Total execution time: 0.0698
DEBUG - 2022-05-19 00:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:52:40 --> Total execution time: 0.0517
DEBUG - 2022-05-19 00:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:52:57 --> Total execution time: 0.0432
DEBUG - 2022-05-19 00:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:53:07 --> Total execution time: 0.0374
DEBUG - 2022-05-19 00:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:53:12 --> Total execution time: 0.0374
DEBUG - 2022-05-19 00:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:53:17 --> Total execution time: 0.1204
DEBUG - 2022-05-19 00:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:54:07 --> Total execution time: 0.1025
DEBUG - 2022-05-19 00:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:55:24 --> Total execution time: 0.0582
DEBUG - 2022-05-19 00:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:55:31 --> Total execution time: 0.0428
DEBUG - 2022-05-19 00:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:55:37 --> Total execution time: 0.0425
DEBUG - 2022-05-19 00:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:56:35 --> Total execution time: 0.1118
DEBUG - 2022-05-19 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:57:53 --> Total execution time: 0.0696
DEBUG - 2022-05-19 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:58:14 --> Total execution time: 0.1060
DEBUG - 2022-05-19 00:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:58:38 --> Total execution time: 0.1024
DEBUG - 2022-05-19 00:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:58:49 --> Total execution time: 0.0466
DEBUG - 2022-05-19 00:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:58:53 --> Total execution time: 0.0617
DEBUG - 2022-05-19 00:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:59:20 --> Total execution time: 0.0332
DEBUG - 2022-05-19 00:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:59:50 --> Total execution time: 0.0352
DEBUG - 2022-05-19 00:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:01:27 --> Total execution time: 0.0543
DEBUG - 2022-05-19 00:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 00:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:17:00 --> Total execution time: 0.0399
DEBUG - 2022-05-19 00:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:17:00 --> Total execution time: 0.0328
DEBUG - 2022-05-19 00:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 00:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:17:02 --> Total execution time: 0.0298
DEBUG - 2022-05-19 00:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:02 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:17:02 --> Total execution time: 0.0391
DEBUG - 2022-05-19 00:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:10 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:17:11 --> Total execution time: 0.0491
DEBUG - 2022-05-19 00:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:47:12 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:17:12 --> Total execution time: 0.0354
DEBUG - 2022-05-19 00:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 00:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:18:48 --> Total execution time: 0.0372
DEBUG - 2022-05-19 00:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:48:55 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:18:55 --> Total execution time: 0.0369
DEBUG - 2022-05-19 00:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:49:51 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:19:51 --> Total execution time: 0.0340
DEBUG - 2022-05-19 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:50:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 00:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:20:29 --> Total execution time: 0.0369
DEBUG - 2022-05-19 00:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:20:39 --> Total execution time: 0.0321
DEBUG - 2022-05-19 00:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 00:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:20:56 --> Total execution time: 0.0366
DEBUG - 2022-05-19 00:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:21:06 --> Total execution time: 0.0560
DEBUG - 2022-05-19 00:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:21:08 --> Total execution time: 0.0293
DEBUG - 2022-05-19 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:21:17 --> Total execution time: 0.0762
DEBUG - 2022-05-19 00:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:25:20 --> Total execution time: 0.0569
DEBUG - 2022-05-19 00:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:25:51 --> Total execution time: 0.0397
DEBUG - 2022-05-19 00:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:25:53 --> Total execution time: 0.0409
DEBUG - 2022-05-19 00:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:26:04 --> Total execution time: 0.0348
DEBUG - 2022-05-19 00:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 00:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 00:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:26:33 --> Total execution time: 0.0313
DEBUG - 2022-05-19 01:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:06:32 --> No URI present. Default controller set.
DEBUG - 2022-05-19 01:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:36:32 --> Total execution time: 0.1047
DEBUG - 2022-05-19 01:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:36:58 --> Total execution time: 0.0165
DEBUG - 2022-05-19 01:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:11 --> Total execution time: 0.0185
DEBUG - 2022-05-19 01:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:28 --> Total execution time: 0.0256
DEBUG - 2022-05-19 01:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:32 --> Total execution time: 0.0280
DEBUG - 2022-05-19 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:35 --> Total execution time: 0.0178
DEBUG - 2022-05-19 01:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:46 --> Total execution time: 0.0212
DEBUG - 2022-05-19 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:53 --> Total execution time: 0.0266
DEBUG - 2022-05-19 01:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:38:52 --> Total execution time: 0.0193
DEBUG - 2022-05-19 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:38:56 --> Total execution time: 0.0190
DEBUG - 2022-05-19 01:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:38:58 --> Total execution time: 0.0196
DEBUG - 2022-05-19 01:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:39:09 --> Total execution time: 0.0080
DEBUG - 2022-05-19 01:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:43:25 --> Total execution time: 0.0426
DEBUG - 2022-05-19 01:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:44:26 --> Total execution time: 0.0159
DEBUG - 2022-05-19 01:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:45:31 --> Total execution time: 0.0269
DEBUG - 2022-05-19 01:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:45:36 --> Total execution time: 0.0155
DEBUG - 2022-05-19 01:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:26:08 --> No URI present. Default controller set.
DEBUG - 2022-05-19 01:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:56:09 --> Total execution time: 0.1117
DEBUG - 2022-05-19 01:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:56:11 --> Total execution time: 0.0214
DEBUG - 2022-05-19 01:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:56:14 --> Total execution time: 0.0175
DEBUG - 2022-05-19 01:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:05:08 --> Total execution time: 0.1180
DEBUG - 2022-05-19 01:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:05:12 --> Total execution time: 0.0276
DEBUG - 2022-05-19 01:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:05:16 --> Total execution time: 0.0255
DEBUG - 2022-05-19 01:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:36:28 --> No URI present. Default controller set.
DEBUG - 2022-05-19 01:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:06:28 --> Total execution time: 0.0262
DEBUG - 2022-05-19 01:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:06:31 --> Total execution time: 0.0165
DEBUG - 2022-05-19 01:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:06:40 --> Total execution time: 0.0160
DEBUG - 2022-05-19 01:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:06:49 --> Total execution time: 0.1803
DEBUG - 2022-05-19 01:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:08:22 --> Total execution time: 0.0263
DEBUG - 2022-05-19 01:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:08:24 --> Total execution time: 0.0277
DEBUG - 2022-05-19 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:38:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:08:26 --> Total execution time: 0.0191
DEBUG - 2022-05-19 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:07 --> Total execution time: 0.0188
DEBUG - 2022-05-19 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:15 --> Total execution time: 0.1401
DEBUG - 2022-05-19 01:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:39:39 --> No URI present. Default controller set.
DEBUG - 2022-05-19 01:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:39 --> Total execution time: 0.0258
DEBUG - 2022-05-19 01:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:58 --> Total execution time: 0.0156
DEBUG - 2022-05-19 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:10:15 --> Total execution time: 0.0337
DEBUG - 2022-05-19 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:10:27 --> Total execution time: 0.0372
DEBUG - 2022-05-19 01:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:10:42 --> Total execution time: 0.0182
DEBUG - 2022-05-19 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:11:05 --> Total execution time: 0.0216
DEBUG - 2022-05-19 01:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:11:07 --> Total execution time: 0.0189
DEBUG - 2022-05-19 01:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:43:47 --> No URI present. Default controller set.
DEBUG - 2022-05-19 01:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:13:47 --> Total execution time: 0.0504
DEBUG - 2022-05-19 01:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:13:50 --> Total execution time: 0.0329
DEBUG - 2022-05-19 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:13:53 --> Total execution time: 0.0128
DEBUG - 2022-05-19 01:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:13:56 --> Total execution time: 0.0150
DEBUG - 2022-05-19 01:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:14:09 --> Total execution time: 0.0169
DEBUG - 2022-05-19 01:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:14:17 --> Total execution time: 0.0376
DEBUG - 2022-05-19 01:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:14:40 --> Total execution time: 0.0482
DEBUG - 2022-05-19 01:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:14:43 --> Total execution time: 0.0243
DEBUG - 2022-05-19 01:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:54:02 --> Total execution time: 0.0183
DEBUG - 2022-05-19 01:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:54:19 --> Total execution time: 0.0167
DEBUG - 2022-05-19 01:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:54:22 --> Total execution time: 0.0195
DEBUG - 2022-05-19 01:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:54:22 --> Total execution time: 0.0318
DEBUG - 2022-05-19 01:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:00 --> Total execution time: 0.0240
DEBUG - 2022-05-19 01:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:03 --> Total execution time: 0.0129
DEBUG - 2022-05-19 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:17 --> Total execution time: 0.0178
DEBUG - 2022-05-19 01:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:21 --> Total execution time: 0.0187
DEBUG - 2022-05-19 01:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:25 --> Total execution time: 0.0204
DEBUG - 2022-05-19 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:35 --> Total execution time: 0.0132
DEBUG - 2022-05-19 01:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:00 --> Total execution time: 0.0142
DEBUG - 2022-05-19 01:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 01:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:07 --> Total execution time: 0.0156
DEBUG - 2022-05-19 01:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:10 --> Total execution time: 0.0232
DEBUG - 2022-05-19 01:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:16 --> Total execution time: 0.0216
DEBUG - 2022-05-19 01:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:21 --> Total execution time: 0.1955
DEBUG - 2022-05-19 01:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:31 --> Total execution time: 0.1855
DEBUG - 2022-05-19 01:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 01:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 01:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:34 --> Total execution time: 0.1972
DEBUG - 2022-05-19 02:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:30:24 --> Total execution time: 0.0457
DEBUG - 2022-05-19 02:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:18:51 --> No URI present. Default controller set.
DEBUG - 2022-05-19 02:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:48:51 --> Total execution time: 0.0432
DEBUG - 2022-05-19 02:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:49:05 --> Total execution time: 0.0320
DEBUG - 2022-05-19 02:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:49:10 --> Total execution time: 0.0318
DEBUG - 2022-05-19 02:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:58:39 --> Total execution time: 0.0669
DEBUG - 2022-05-19 02:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:58:46 --> Total execution time: 0.0316
DEBUG - 2022-05-19 02:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:21 --> Total execution time: 0.0721
DEBUG - 2022-05-19 02:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:24 --> Total execution time: 0.0380
DEBUG - 2022-05-19 02:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:31 --> Total execution time: 0.0370
DEBUG - 2022-05-19 02:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:38 --> Total execution time: 0.0407
DEBUG - 2022-05-19 02:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:40 --> Total execution time: 0.0341
DEBUG - 2022-05-19 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:09:54 --> Total execution time: 0.0748
DEBUG - 2022-05-19 02:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:47:36 --> Total execution time: 0.0221
DEBUG - 2022-05-19 02:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:47:37 --> Total execution time: 0.0165
DEBUG - 2022-05-19 02:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:47:37 --> Total execution time: 0.0183
DEBUG - 2022-05-19 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:48:50 --> Total execution time: 0.0444
DEBUG - 2022-05-19 02:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:48:51 --> Total execution time: 0.0186
DEBUG - 2022-05-19 02:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:48:51 --> Total execution time: 0.0171
DEBUG - 2022-05-19 02:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:48:54 --> Total execution time: 0.0130
DEBUG - 2022-05-19 02:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:19:30 --> Total execution time: 1.4562
DEBUG - 2022-05-19 02:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:49:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:14 --> Total execution time: 0.0210
DEBUG - 2022-05-19 02:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:16 --> Total execution time: 0.0399
DEBUG - 2022-05-19 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:25 --> Total execution time: 0.0336
DEBUG - 2022-05-19 02:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:33 --> Total execution time: 0.0144
DEBUG - 2022-05-19 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:35 --> Total execution time: 0.0140
DEBUG - 2022-05-19 02:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:44 --> Total execution time: 0.0123
DEBUG - 2022-05-19 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:48 --> Total execution time: 0.0155
DEBUG - 2022-05-19 02:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:50 --> Total execution time: 0.0248
DEBUG - 2022-05-19 02:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:25:04 --> Total execution time: 0.0926
DEBUG - 2022-05-19 02:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:58:50 --> No URI present. Default controller set.
DEBUG - 2022-05-19 02:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:28:50 --> Total execution time: 0.0996
DEBUG - 2022-05-19 03:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:01:12 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:31:12 --> Total execution time: 0.0611
DEBUG - 2022-05-19 03:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:31:17 --> Total execution time: 0.0205
DEBUG - 2022-05-19 03:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:31:55 --> Total execution time: 0.0252
DEBUG - 2022-05-19 03:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:32:20 --> Total execution time: 0.1761
DEBUG - 2022-05-19 03:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:01 --> Total execution time: 0.3333
DEBUG - 2022-05-19 03:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:09 --> Total execution time: 0.4785
DEBUG - 2022-05-19 03:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:21 --> Total execution time: 0.3536
DEBUG - 2022-05-19 03:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:29 --> Total execution time: 0.0125
DEBUG - 2022-05-19 03:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:37 --> Total execution time: 0.0152
DEBUG - 2022-05-19 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:49 --> Total execution time: 0.0186
DEBUG - 2022-05-19 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:34:00 --> Total execution time: 0.0260
DEBUG - 2022-05-19 03:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:34:46 --> Total execution time: 0.0132
DEBUG - 2022-05-19 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:34:52 --> Total execution time: 0.0151
DEBUG - 2022-05-19 03:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:35:05 --> Total execution time: 0.0174
DEBUG - 2022-05-19 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:10 --> Total execution time: 0.1020
DEBUG - 2022-05-19 03:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:13 --> Total execution time: 0.0212
DEBUG - 2022-05-19 03:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:15 --> Total execution time: 0.0179
DEBUG - 2022-05-19 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:29 --> Total execution time: 0.0254
DEBUG - 2022-05-19 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:29 --> Total execution time: 0.0085
DEBUG - 2022-05-19 03:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:36 --> Total execution time: 0.0095
DEBUG - 2022-05-19 03:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:41:43 --> Total execution time: 0.0302
DEBUG - 2022-05-19 03:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:17:44 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:47:44 --> Total execution time: 0.1402
DEBUG - 2022-05-19 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:47:49 --> Total execution time: 0.0174
DEBUG - 2022-05-19 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:48:12 --> Total execution time: 0.0177
DEBUG - 2022-05-19 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:48:44 --> Total execution time: 0.0192
DEBUG - 2022-05-19 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:27:42 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:57:42 --> Total execution time: 0.0939
DEBUG - 2022-05-19 03:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:30:34 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:00:34 --> Total execution time: 0.0709
DEBUG - 2022-05-19 03:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:30:39 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:00:39 --> Total execution time: 0.0155
DEBUG - 2022-05-19 03:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:10:48 --> Total execution time: 0.1044
DEBUG - 2022-05-19 03:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:42:52 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:12:52 --> Total execution time: 0.0733
DEBUG - 2022-05-19 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:43:30 --> Total execution time: 0.0167
DEBUG - 2022-05-19 03:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:43:32 --> Total execution time: 0.0296
DEBUG - 2022-05-19 03:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:43:33 --> Total execution time: 0.0190
DEBUG - 2022-05-19 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:44:45 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:14:45 --> Total execution time: 0.0169
DEBUG - 2022-05-19 03:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:46:01 --> Total execution time: 0.0184
DEBUG - 2022-05-19 03:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:46:03 --> Total execution time: 0.0155
DEBUG - 2022-05-19 03:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 03:46:03 --> Total execution time: 0.0303
DEBUG - 2022-05-19 03:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:47:25 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:17:25 --> Total execution time: 0.0377
DEBUG - 2022-05-19 03:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:47:25 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:17:25 --> Total execution time: 0.0257
DEBUG - 2022-05-19 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:24:56 --> Total execution time: 0.0429
DEBUG - 2022-05-19 04:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:03:10 --> No URI present. Default controller set.
DEBUG - 2022-05-19 04:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:33:10 --> Total execution time: 0.1138
DEBUG - 2022-05-19 04:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:33:18 --> Total execution time: 0.0124
DEBUG - 2022-05-19 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:33:30 --> Total execution time: 0.0126
DEBUG - 2022-05-19 04:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:33:47 --> Total execution time: 0.0162
DEBUG - 2022-05-19 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:34:13 --> Total execution time: 0.0131
DEBUG - 2022-05-19 04:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 04:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:01:52 --> Total execution time: 0.0197
DEBUG - 2022-05-19 04:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:08:32 --> Total execution time: 0.0787
DEBUG - 2022-05-19 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:08:36 --> Total execution time: 0.0798
DEBUG - 2022-05-19 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 04:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:08:51 --> Total execution time: 0.0300
DEBUG - 2022-05-19 04:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:09:12 --> Total execution time: 0.0305
DEBUG - 2022-05-19 04:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:09:20 --> Total execution time: 0.0755
DEBUG - 2022-05-19 04:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:10:22 --> Total execution time: 0.0660
DEBUG - 2022-05-19 04:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:11:41 --> Total execution time: 0.0382
DEBUG - 2022-05-19 04:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:58:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 04:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:28:05 --> Total execution time: 0.0931
DEBUG - 2022-05-19 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:56:18 --> Total execution time: 38.7338
DEBUG - 2022-05-19 05:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 05:26:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:27:25 --> Total execution time: 0.0314
DEBUG - 2022-05-19 05:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:57:45 --> Total execution time: 0.0332
DEBUG - 2022-05-19 05:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:27:49 --> No URI present. Default controller set.
DEBUG - 2022-05-19 05:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:57:49 --> Total execution time: 0.0525
DEBUG - 2022-05-19 05:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:57:59 --> Total execution time: 3.3909
DEBUG - 2022-05-19 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:58:12 --> Total execution time: 0.0327
DEBUG - 2022-05-19 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:58:30 --> Total execution time: 0.0338
DEBUG - 2022-05-19 05:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:58:36 --> Total execution time: 0.0503
DEBUG - 2022-05-19 05:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:58:49 --> Total execution time: 0.1955
DEBUG - 2022-05-19 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:08 --> Total execution time: 0.0400
DEBUG - 2022-05-19 05:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:12 --> Total execution time: 0.0327
DEBUG - 2022-05-19 05:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:14 --> Total execution time: 0.0462
DEBUG - 2022-05-19 05:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:17 --> Total execution time: 0.0358
DEBUG - 2022-05-19 05:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:20 --> Total execution time: 0.0406
DEBUG - 2022-05-19 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:02:28 --> Total execution time: 41.9300
DEBUG - 2022-05-19 05:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:03:18 --> Total execution time: 0.0442
DEBUG - 2022-05-19 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:03:21 --> Total execution time: 0.0395
DEBUG - 2022-05-19 05:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:03:40 --> Total execution time: 0.0426
DEBUG - 2022-05-19 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:34:17 --> Total execution time: 0.1165
DEBUG - 2022-05-19 05:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:34:20 --> Total execution time: 0.0347
DEBUG - 2022-05-19 05:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:34:20 --> Total execution time: 0.0355
DEBUG - 2022-05-19 05:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:04:43 --> Total execution time: 0.0410
DEBUG - 2022-05-19 05:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:10:16 --> Total execution time: 0.0820
DEBUG - 2022-05-19 05:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:10:26 --> Total execution time: 0.1940
DEBUG - 2022-05-19 05:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:26:08 --> Total execution time: 0.0171
DEBUG - 2022-05-19 05:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:57:35 --> No URI present. Default controller set.
DEBUG - 2022-05-19 05:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:35 --> Total execution time: 0.0215
DEBUG - 2022-05-19 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:38 --> Total execution time: 0.0134
DEBUG - 2022-05-19 05:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:50 --> Total execution time: 0.0182
DEBUG - 2022-05-19 05:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:55 --> Total execution time: 0.0182
DEBUG - 2022-05-19 05:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:59 --> Total execution time: 0.0240
DEBUG - 2022-05-19 05:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:04 --> Total execution time: 0.0167
DEBUG - 2022-05-19 05:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:06 --> Total execution time: 0.0270
DEBUG - 2022-05-19 05:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:11 --> Total execution time: 0.0146
DEBUG - 2022-05-19 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:13 --> Total execution time: 0.0217
DEBUG - 2022-05-19 05:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:17 --> Total execution time: 0.0205
DEBUG - 2022-05-19 05:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:20 --> Total execution time: 0.0167
DEBUG - 2022-05-19 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:23 --> Total execution time: 0.0143
DEBUG - 2022-05-19 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:27 --> Total execution time: 0.0395
DEBUG - 2022-05-19 05:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:37 --> Total execution time: 0.0237
DEBUG - 2022-05-19 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:39 --> Total execution time: 0.0255
DEBUG - 2022-05-19 05:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:42 --> Total execution time: 0.0161
DEBUG - 2022-05-19 05:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:46 --> Total execution time: 0.0150
DEBUG - 2022-05-19 05:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:28:49 --> Total execution time: 0.0079
DEBUG - 2022-05-19 05:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 05:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:29:02 --> Total execution time: 0.0182
DEBUG - 2022-05-19 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:29:10 --> Total execution time: 0.0147
DEBUG - 2022-05-19 05:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:29:15 --> Total execution time: 0.0238
DEBUG - 2022-05-19 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:29:24 --> Total execution time: 0.0246
DEBUG - 2022-05-19 05:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:29:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 05:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 05:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 05:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:29:43 --> Total execution time: 0.0246
DEBUG - 2022-05-19 06:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:30:04 --> Total execution time: 0.0818
DEBUG - 2022-05-19 06:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:30:06 --> Total execution time: 0.0941
DEBUG - 2022-05-19 06:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:30:16 --> Total execution time: 0.1449
DEBUG - 2022-05-19 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:30:30 --> Total execution time: 0.0403
DEBUG - 2022-05-19 06:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:30:32 --> Total execution time: 0.0233
DEBUG - 2022-05-19 06:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:30:35 --> Total execution time: 0.0208
DEBUG - 2022-05-19 06:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:00:50 --> Total execution time: 0.0316
DEBUG - 2022-05-19 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:00:53 --> Total execution time: 0.0080
DEBUG - 2022-05-19 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:00:53 --> Total execution time: 0.0154
DEBUG - 2022-05-19 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:04:53 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:34:53 --> Total execution time: 0.0935
DEBUG - 2022-05-19 06:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:34:56 --> Total execution time: 0.0187
DEBUG - 2022-05-19 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:35:01 --> Total execution time: 0.0291
DEBUG - 2022-05-19 06:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:35:03 --> Total execution time: 0.0136
DEBUG - 2022-05-19 06:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:35:16 --> Total execution time: 0.0283
DEBUG - 2022-05-19 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:35:25 --> Total execution time: 0.0367
DEBUG - 2022-05-19 06:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:13:50 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:43:50 --> Total execution time: 0.0918
DEBUG - 2022-05-19 06:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:45:09 --> Total execution time: 0.0449
DEBUG - 2022-05-19 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:45:40 --> Total execution time: 0.0129
DEBUG - 2022-05-19 06:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:45:55 --> Total execution time: 0.0136
DEBUG - 2022-05-19 06:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:46:15 --> Total execution time: 0.0134
DEBUG - 2022-05-19 06:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:46:31 --> Total execution time: 0.0146
DEBUG - 2022-05-19 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:46:44 --> Total execution time: 0.0124
DEBUG - 2022-05-19 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:47:06 --> Total execution time: 0.0129
DEBUG - 2022-05-19 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:17:18 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:47:18 --> Total execution time: 0.0221
DEBUG - 2022-05-19 06:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:47:27 --> Total execution time: 0.0129
DEBUG - 2022-05-19 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:17:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:47:40 --> Total execution time: 0.0152
DEBUG - 2022-05-19 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:47:45 --> Total execution time: 0.0161
DEBUG - 2022-05-19 06:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:48:08 --> Total execution time: 0.0134
DEBUG - 2022-05-19 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:20:04 --> Total execution time: 0.0165
DEBUG - 2022-05-19 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:20:06 --> Total execution time: 0.0184
DEBUG - 2022-05-19 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:20:06 --> Total execution time: 0.0131
DEBUG - 2022-05-19 06:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:50:14 --> Total execution time: 0.0136
DEBUG - 2022-05-19 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:50:40 --> Total execution time: 0.0141
DEBUG - 2022-05-19 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:51:26 --> Total execution time: 0.0614
DEBUG - 2022-05-19 06:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:21:46 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:51:46 --> Total execution time: 0.0168
DEBUG - 2022-05-19 06:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:51:51 --> Total execution time: 0.0175
DEBUG - 2022-05-19 06:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:03 --> Total execution time: 0.0200
DEBUG - 2022-05-19 06:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:24 --> Total execution time: 0.0209
DEBUG - 2022-05-19 06:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:31 --> Total execution time: 0.0282
DEBUG - 2022-05-19 06:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:33 --> Total execution time: 0.0150
DEBUG - 2022-05-19 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:48 --> Total execution time: 0.0149
DEBUG - 2022-05-19 06:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:52 --> Total execution time: 0.0152
DEBUG - 2022-05-19 06:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:55 --> Total execution time: 0.0159
DEBUG - 2022-05-19 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:22:57 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:52:57 --> Total execution time: 0.0249
DEBUG - 2022-05-19 06:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:53:24 --> Total execution time: 0.0154
DEBUG - 2022-05-19 06:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:23:54 --> Total execution time: 0.0105
DEBUG - 2022-05-19 06:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:23:55 --> Total execution time: 0.0103
DEBUG - 2022-05-19 06:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:23:55 --> Total execution time: 0.0139
DEBUG - 2022-05-19 06:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:53:59 --> Total execution time: 0.0074
DEBUG - 2022-05-19 06:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:56:28 --> Total execution time: 0.0523
DEBUG - 2022-05-19 06:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:27:15 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:57:15 --> Total execution time: 0.0378
DEBUG - 2022-05-19 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:57:56 --> Total execution time: 0.0138
DEBUG - 2022-05-19 06:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:58:20 --> Total execution time: 0.0137
DEBUG - 2022-05-19 06:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:58:47 --> Total execution time: 0.0073
DEBUG - 2022-05-19 06:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:59:04 --> Total execution time: 0.0171
DEBUG - 2022-05-19 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:03:16 --> Total execution time: 0.0181
DEBUG - 2022-05-19 06:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:03:28 --> Total execution time: 0.0222
DEBUG - 2022-05-19 06:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:05:17 --> Total execution time: 0.0253
DEBUG - 2022-05-19 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:05:30 --> Total execution time: 0.0154
DEBUG - 2022-05-19 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:05:33 --> Total execution time: 0.0293
DEBUG - 2022-05-19 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:05:53 --> Total execution time: 0.0264
DEBUG - 2022-05-19 06:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:06:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 06:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:06:21 --> Total execution time: 0.0166
DEBUG - 2022-05-19 06:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 06:36:22 --> 404 Page Not Found: User/update-thumbnail
DEBUG - 2022-05-19 06:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:07:09 --> Total execution time: 0.0399
DEBUG - 2022-05-19 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:07:18 --> Total execution time: 0.0801
DEBUG - 2022-05-19 06:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:37:58 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:07:58 --> Total execution time: 0.0452
DEBUG - 2022-05-19 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:08:08 --> Total execution time: 0.0151
DEBUG - 2022-05-19 06:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:08:33 --> Total execution time: 0.0310
DEBUG - 2022-05-19 06:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:08:54 --> Total execution time: 0.0161
DEBUG - 2022-05-19 06:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:08:59 --> Total execution time: 0.0154
DEBUG - 2022-05-19 06:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:39:01 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:09:01 --> Total execution time: 0.0244
DEBUG - 2022-05-19 06:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:20 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:10:20 --> Total execution time: 0.0499
DEBUG - 2022-05-19 06:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:10:26 --> Total execution time: 0.0147
DEBUG - 2022-05-19 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:10:41 --> Total execution time: 0.0315
DEBUG - 2022-05-19 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:10:42 --> Total execution time: 0.0474
DEBUG - 2022-05-19 06:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:10:48 --> Total execution time: 0.0416
DEBUG - 2022-05-19 06:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:10:50 --> Total execution time: 0.0132
DEBUG - 2022-05-19 06:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 06:40:51 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-05-19 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:11:41 --> Total execution time: 0.0199
DEBUG - 2022-05-19 06:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:11:48 --> Total execution time: 0.0187
DEBUG - 2022-05-19 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:11:52 --> Total execution time: 0.0162
DEBUG - 2022-05-19 06:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:12:15 --> Total execution time: 0.0263
DEBUG - 2022-05-19 06:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:12:31 --> Total execution time: 0.0228
DEBUG - 2022-05-19 06:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:12:31 --> Total execution time: 0.0220
DEBUG - 2022-05-19 06:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:12:36 --> Total execution time: 0.0225
DEBUG - 2022-05-19 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:12:42 --> Total execution time: 0.0721
DEBUG - 2022-05-19 06:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:12:49 --> Total execution time: 0.0476
DEBUG - 2022-05-19 06:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:02 --> Total execution time: 0.0551
DEBUG - 2022-05-19 06:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:43:12 --> Total execution time: 0.0151
DEBUG - 2022-05-19 06:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:18 --> Total execution time: 0.0240
DEBUG - 2022-05-19 06:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:18 --> Total execution time: 0.0428
DEBUG - 2022-05-19 06:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:22 --> Total execution time: 0.0225
DEBUG - 2022-05-19 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:40 --> Total execution time: 0.0188
DEBUG - 2022-05-19 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:45 --> Total execution time: 0.0155
DEBUG - 2022-05-19 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:13:55 --> Total execution time: 0.0334
DEBUG - 2022-05-19 06:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:06 --> Total execution time: 0.0205
DEBUG - 2022-05-19 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:11 --> Total execution time: 0.0224
DEBUG - 2022-05-19 06:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:28 --> Total execution time: 0.0286
DEBUG - 2022-05-19 06:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:46 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:46 --> Total execution time: 0.0815
DEBUG - 2022-05-19 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:50 --> Total execution time: 0.0242
DEBUG - 2022-05-19 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:44:55 --> Total execution time: 0.0163
DEBUG - 2022-05-19 06:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:58 --> Total execution time: 0.0349
DEBUG - 2022-05-19 06:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:14:59 --> Total execution time: 0.0411
DEBUG - 2022-05-19 06:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:11 --> Total execution time: 0.0251
DEBUG - 2022-05-19 06:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:12 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:12 --> Total execution time: 0.0390
DEBUG - 2022-05-19 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:19 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:19 --> Total execution time: 0.0310
DEBUG - 2022-05-19 06:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:22 --> Total execution time: 0.0271
DEBUG - 2022-05-19 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:29 --> Total execution time: 0.0248
DEBUG - 2022-05-19 06:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:38 --> Total execution time: 0.0522
DEBUG - 2022-05-19 06:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:45:48 --> Total execution time: 0.0338
DEBUG - 2022-05-19 06:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:50 --> Total execution time: 0.0934
DEBUG - 2022-05-19 06:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:15:57 --> Total execution time: 0.0601
DEBUG - 2022-05-19 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:02 --> Total execution time: 0.0601
DEBUG - 2022-05-19 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:06 --> Total execution time: 0.0403
DEBUG - 2022-05-19 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:16 --> Total execution time: 0.0339
DEBUG - 2022-05-19 06:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:35 --> Total execution time: 0.0380
DEBUG - 2022-05-19 06:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:38 --> Total execution time: 0.0212
DEBUG - 2022-05-19 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:40 --> Total execution time: 0.0196
DEBUG - 2022-05-19 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:56 --> Total execution time: 0.0556
DEBUG - 2022-05-19 06:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:16:58 --> Total execution time: 0.0292
DEBUG - 2022-05-19 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:03 --> Total execution time: 0.0202
DEBUG - 2022-05-19 06:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:05 --> Total execution time: 0.0596
DEBUG - 2022-05-19 06:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:09 --> Total execution time: 0.0385
DEBUG - 2022-05-19 06:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:33 --> Total execution time: 0.0270
DEBUG - 2022-05-19 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:47 --> Total execution time: 0.0382
DEBUG - 2022-05-19 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:48 --> Total execution time: 0.0195
DEBUG - 2022-05-19 06:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:17:53 --> Total execution time: 0.0259
DEBUG - 2022-05-19 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:18:04 --> Total execution time: 0.0380
DEBUG - 2022-05-19 06:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:18:11 --> Total execution time: 0.1007
DEBUG - 2022-05-19 06:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:18:27 --> Total execution time: 0.0443
DEBUG - 2022-05-19 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:18:36 --> Total execution time: 0.0532
DEBUG - 2022-05-19 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:03 --> Total execution time: 0.1412
DEBUG - 2022-05-19 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:10 --> Total execution time: 0.0526
DEBUG - 2022-05-19 06:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:23 --> Total execution time: 0.0413
DEBUG - 2022-05-19 06:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:24 --> Total execution time: 0.0217
DEBUG - 2022-05-19 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:40 --> Total execution time: 0.0559
DEBUG - 2022-05-19 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:44 --> Total execution time: 0.0439
DEBUG - 2022-05-19 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:19:44 --> Total execution time: 0.0551
DEBUG - 2022-05-19 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:20:16 --> Total execution time: 0.0420
DEBUG - 2022-05-19 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:20:38 --> Total execution time: 0.0211
DEBUG - 2022-05-19 06:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:20:44 --> Total execution time: 0.0396
DEBUG - 2022-05-19 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:03 --> Total execution time: 0.0430
DEBUG - 2022-05-19 06:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:36 --> Total execution time: 0.0863
DEBUG - 2022-05-19 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:45 --> Total execution time: 0.2739
DEBUG - 2022-05-19 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:45 --> Total execution time: 0.0725
DEBUG - 2022-05-19 06:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:47 --> Total execution time: 0.2288
DEBUG - 2022-05-19 06:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:48 --> Total execution time: 0.0651
DEBUG - 2022-05-19 06:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:51 --> Total execution time: 0.0426
DEBUG - 2022-05-19 06:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:53 --> Total execution time: 0.0415
DEBUG - 2022-05-19 06:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:55 --> Total execution time: 0.1314
DEBUG - 2022-05-19 06:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:56 --> Total execution time: 0.1245
DEBUG - 2022-05-19 06:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:21:58 --> Total execution time: 0.0159
DEBUG - 2022-05-19 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:22:01 --> Total execution time: 0.1001
DEBUG - 2022-05-19 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:22:09 --> Total execution time: 0.0420
DEBUG - 2022-05-19 06:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:52:18 --> Total execution time: 0.0197
DEBUG - 2022-05-19 06:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:52:20 --> Total execution time: 0.0182
DEBUG - 2022-05-19 06:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 06:52:20 --> Total execution time: 0.0204
DEBUG - 2022-05-19 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:23:20 --> Total execution time: 0.0301
DEBUG - 2022-05-19 07:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:40:09 --> Total execution time: 0.0914
DEBUG - 2022-05-19 07:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:40:28 --> Total execution time: 0.0360
DEBUG - 2022-05-19 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:40:54 --> Total execution time: 0.0287
DEBUG - 2022-05-19 07:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:40:58 --> Total execution time: 0.0891
DEBUG - 2022-05-19 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:41:46 --> Total execution time: 0.0524
DEBUG - 2022-05-19 07:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:41:54 --> Total execution time: 0.0167
DEBUG - 2022-05-19 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:42:02 --> Total execution time: 0.0243
DEBUG - 2022-05-19 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:42:02 --> Total execution time: 0.0210
DEBUG - 2022-05-19 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:42:02 --> Total execution time: 0.0196
DEBUG - 2022-05-19 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:42:02 --> Total execution time: 0.0227
DEBUG - 2022-05-19 07:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:42:34 --> Total execution time: 0.0255
DEBUG - 2022-05-19 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:48 --> Total execution time: 0.0098
DEBUG - 2022-05-19 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:12:53 --> Total execution time: 0.0135
DEBUG - 2022-05-19 07:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:42:59 --> Total execution time: 0.0175
DEBUG - 2022-05-19 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:43:06 --> Total execution time: 0.0290
DEBUG - 2022-05-19 07:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:43:37 --> Total execution time: 0.0157
DEBUG - 2022-05-19 07:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:43:45 --> Total execution time: 0.0153
DEBUG - 2022-05-19 07:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:43:48 --> Total execution time: 0.0140
DEBUG - 2022-05-19 07:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:43:54 --> Total execution time: 0.0127
DEBUG - 2022-05-19 07:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:14:15 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:44:15 --> Total execution time: 0.0243
DEBUG - 2022-05-19 07:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:14:17 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:44:17 --> Total execution time: 0.0197
DEBUG - 2022-05-19 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:44:52 --> Total execution time: 0.0137
DEBUG - 2022-05-19 07:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:45:03 --> Total execution time: 0.0143
DEBUG - 2022-05-19 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:48:11 --> Total execution time: 0.0938
DEBUG - 2022-05-19 07:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:18:52 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:48:52 --> Total execution time: 0.0176
DEBUG - 2022-05-19 07:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:48:57 --> Total execution time: 0.0138
DEBUG - 2022-05-19 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:49:12 --> Total execution time: 0.0197
DEBUG - 2022-05-19 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:49:27 --> Total execution time: 0.0348
DEBUG - 2022-05-19 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:30 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:49:30 --> Total execution time: 0.0207
DEBUG - 2022-05-19 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:49:33 --> Total execution time: 0.0227
DEBUG - 2022-05-19 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:49:37 --> Total execution time: 0.0584
DEBUG - 2022-05-19 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:49:57 --> Total execution time: 0.0164
DEBUG - 2022-05-19 07:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:50:15 --> Total execution time: 0.0256
DEBUG - 2022-05-19 07:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:50:15 --> Total execution time: 0.0278
DEBUG - 2022-05-19 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:20:56 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:50:56 --> Total execution time: 0.0191
DEBUG - 2022-05-19 07:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:00 --> Total execution time: 0.0155
DEBUG - 2022-05-19 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:12 --> Total execution time: 0.0375
DEBUG - 2022-05-19 07:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:14 --> Total execution time: 0.0191
DEBUG - 2022-05-19 07:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:17 --> Total execution time: 0.0185
DEBUG - 2022-05-19 07:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:25 --> Total execution time: 0.0327
DEBUG - 2022-05-19 07:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:27 --> Total execution time: 0.0229
DEBUG - 2022-05-19 07:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:30 --> Total execution time: 0.0183
DEBUG - 2022-05-19 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:33 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:33 --> Total execution time: 0.0177
DEBUG - 2022-05-19 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:45 --> Total execution time: 0.0252
DEBUG - 2022-05-19 07:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:47 --> Total execution time: 0.0181
DEBUG - 2022-05-19 07:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:49 --> Total execution time: 0.0147
DEBUG - 2022-05-19 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:21:51 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:51:51 --> Total execution time: 0.0172
DEBUG - 2022-05-19 07:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:23:09 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:53:09 --> Total execution time: 0.0248
DEBUG - 2022-05-19 07:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:53:24 --> Total execution time: 0.0741
DEBUG - 2022-05-19 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:53:32 --> Total execution time: 0.0190
DEBUG - 2022-05-19 07:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:53:37 --> Total execution time: 0.0251
DEBUG - 2022-05-19 07:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:53:38 --> Total execution time: 0.0147
DEBUG - 2022-05-19 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:53:50 --> Total execution time: 0.0138
DEBUG - 2022-05-19 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:00 --> Total execution time: 0.0198
DEBUG - 2022-05-19 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:07 --> Total execution time: 0.0195
DEBUG - 2022-05-19 07:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:10 --> Total execution time: 0.0170
DEBUG - 2022-05-19 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:12 --> Total execution time: 0.0145
DEBUG - 2022-05-19 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:18 --> Total execution time: 0.0204
DEBUG - 2022-05-19 07:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:27 --> Total execution time: 0.0153
DEBUG - 2022-05-19 07:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:29 --> Total execution time: 0.0151
DEBUG - 2022-05-19 07:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:36 --> Total execution time: 0.0164
DEBUG - 2022-05-19 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:37 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:37 --> Total execution time: 0.0213
DEBUG - 2022-05-19 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:38 --> Total execution time: 0.0153
DEBUG - 2022-05-19 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:40 --> Total execution time: 0.0132
DEBUG - 2022-05-19 07:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:43 --> Total execution time: 0.0176
DEBUG - 2022-05-19 07:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:47 --> Total execution time: 0.0197
DEBUG - 2022-05-19 07:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:50 --> Total execution time: 0.0151
DEBUG - 2022-05-19 07:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:50 --> Total execution time: 0.0158
DEBUG - 2022-05-19 07:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:53 --> Total execution time: 0.0131
DEBUG - 2022-05-19 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:54:59 --> Total execution time: 0.0182
DEBUG - 2022-05-19 07:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:00 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:07 --> Total execution time: 0.0172
DEBUG - 2022-05-19 07:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:13 --> Total execution time: 0.0174
DEBUG - 2022-05-19 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:13 --> Total execution time: 0.0159
DEBUG - 2022-05-19 07:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:15 --> Total execution time: 0.0169
DEBUG - 2022-05-19 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:16 --> Total execution time: 0.0164
DEBUG - 2022-05-19 07:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:17 --> Total execution time: 0.0165
DEBUG - 2022-05-19 07:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:18 --> Total execution time: 0.0207
DEBUG - 2022-05-19 07:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:20 --> Total execution time: 0.0248
DEBUG - 2022-05-19 07:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:27 --> Total execution time: 0.0313
DEBUG - 2022-05-19 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:28 --> Total execution time: 0.0204
DEBUG - 2022-05-19 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:29 --> Total execution time: 0.0273
DEBUG - 2022-05-19 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:31 --> Total execution time: 0.0208
DEBUG - 2022-05-19 07:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:33 --> Total execution time: 0.0242
DEBUG - 2022-05-19 07:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:33 --> Total execution time: 0.0218
DEBUG - 2022-05-19 07:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:36 --> Total execution time: 0.0138
DEBUG - 2022-05-19 07:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:38 --> Total execution time: 0.0143
DEBUG - 2022-05-19 07:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:46 --> Total execution time: 0.0190
DEBUG - 2022-05-19 07:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:49 --> Total execution time: 0.0150
DEBUG - 2022-05-19 07:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:52 --> Total execution time: 0.0145
DEBUG - 2022-05-19 07:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:56 --> Total execution time: 0.0147
DEBUG - 2022-05-19 07:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:55:57 --> Total execution time: 0.0173
DEBUG - 2022-05-19 07:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:01 --> Total execution time: 0.0166
DEBUG - 2022-05-19 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:02 --> Total execution time: 0.0188
DEBUG - 2022-05-19 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:02 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:04 --> Total execution time: 0.0141
DEBUG - 2022-05-19 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:05 --> Total execution time: 0.0160
DEBUG - 2022-05-19 07:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:08 --> Total execution time: 0.0153
DEBUG - 2022-05-19 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:13 --> Total execution time: 0.0355
DEBUG - 2022-05-19 07:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:14 --> Total execution time: 0.0168
DEBUG - 2022-05-19 07:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:15 --> Total execution time: 0.0254
DEBUG - 2022-05-19 07:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:19 --> Total execution time: 0.0192
DEBUG - 2022-05-19 07:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:23 --> Total execution time: 0.0166
DEBUG - 2022-05-19 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:28 --> Total execution time: 0.1765
DEBUG - 2022-05-19 07:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:43 --> Total execution time: 0.0465
DEBUG - 2022-05-19 07:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:46 --> Total execution time: 0.0165
DEBUG - 2022-05-19 07:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:48 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:56:49 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:05 --> Total execution time: 0.0153
DEBUG - 2022-05-19 07:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:11 --> Total execution time: 0.0161
DEBUG - 2022-05-19 07:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:14 --> Total execution time: 0.0196
DEBUG - 2022-05-19 07:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:15 --> Total execution time: 0.0170
DEBUG - 2022-05-19 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:19 --> Total execution time: 0.0197
DEBUG - 2022-05-19 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:25 --> Total execution time: 0.0204
DEBUG - 2022-05-19 07:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:29 --> Total execution time: 0.0163
DEBUG - 2022-05-19 07:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:33 --> Total execution time: 0.0440
DEBUG - 2022-05-19 07:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:38 --> Total execution time: 0.0105
DEBUG - 2022-05-19 07:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:42 --> Total execution time: 0.0163
DEBUG - 2022-05-19 07:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:57:49 --> Total execution time: 0.0168
DEBUG - 2022-05-19 07:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:58:23 --> Total execution time: 0.0211
DEBUG - 2022-05-19 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:28:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:58:26 --> Total execution time: 0.0265
DEBUG - 2022-05-19 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:59:54 --> Total execution time: 0.0458
DEBUG - 2022-05-19 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:00:42 --> Total execution time: 0.0370
DEBUG - 2022-05-19 07:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:00:56 --> Total execution time: 0.0138
DEBUG - 2022-05-19 07:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:30:56 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:00:56 --> Total execution time: 0.0218
DEBUG - 2022-05-19 07:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:01:06 --> Total execution time: 0.0152
DEBUG - 2022-05-19 07:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:01:31 --> Total execution time: 0.0267
DEBUG - 2022-05-19 07:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:01:51 --> Total execution time: 0.0252
DEBUG - 2022-05-19 07:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:32:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:02:29 --> Total execution time: 0.0303
DEBUG - 2022-05-19 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:02:38 --> Total execution time: 0.0333
DEBUG - 2022-05-19 07:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:02:46 --> Total execution time: 0.0325
DEBUG - 2022-05-19 07:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:32:49 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:02:49 --> Total execution time: 0.0188
DEBUG - 2022-05-19 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:02:59 --> Total execution time: 0.0154
DEBUG - 2022-05-19 07:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:03:35 --> Total execution time: 0.0139
DEBUG - 2022-05-19 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:04:02 --> Total execution time: 0.0149
DEBUG - 2022-05-19 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:04:17 --> Total execution time: 0.0279
DEBUG - 2022-05-19 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:34:56 --> Total execution time: 0.0206
DEBUG - 2022-05-19 07:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:05:03 --> Total execution time: 0.0356
DEBUG - 2022-05-19 07:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:05:03 --> Total execution time: 0.0143
DEBUG - 2022-05-19 07:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:05:38 --> Total execution time: 0.0127
DEBUG - 2022-05-19 07:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:05:56 --> Total execution time: 0.0213
DEBUG - 2022-05-19 07:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:06:20 --> Total execution time: 0.0214
DEBUG - 2022-05-19 07:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:06:32 --> Total execution time: 0.0139
DEBUG - 2022-05-19 07:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:06:40 --> Total execution time: 0.0187
DEBUG - 2022-05-19 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:06:58 --> Total execution time: 0.0183
DEBUG - 2022-05-19 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:01 --> Total execution time: 0.0275
DEBUG - 2022-05-19 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:09 --> Total execution time: 0.0284
DEBUG - 2022-05-19 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:37:11 --> Total execution time: 0.0185
DEBUG - 2022-05-19 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:37:17 --> Total execution time: 0.0174
DEBUG - 2022-05-19 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:37:17 --> Total execution time: 0.0216
DEBUG - 2022-05-19 07:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:30 --> Total execution time: 0.0183
DEBUG - 2022-05-19 07:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:31 --> Total execution time: 0.0191
DEBUG - 2022-05-19 07:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:34 --> Total execution time: 0.0176
DEBUG - 2022-05-19 07:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:34 --> Total execution time: 0.0341
DEBUG - 2022-05-19 07:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:46 --> Total execution time: 0.0149
DEBUG - 2022-05-19 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:48 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:48 --> Total execution time: 0.0258
DEBUG - 2022-05-19 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:07:50 --> Total execution time: 0.0164
DEBUG - 2022-05-19 07:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:08:03 --> Total execution time: 0.0163
DEBUG - 2022-05-19 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:08:03 --> Total execution time: 0.0154
DEBUG - 2022-05-19 07:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:08:06 --> Total execution time: 0.0383
DEBUG - 2022-05-19 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:08:20 --> Total execution time: 0.0178
DEBUG - 2022-05-19 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:08:50 --> Total execution time: 0.0146
DEBUG - 2022-05-19 07:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:09:00 --> Total execution time: 0.0169
DEBUG - 2022-05-19 07:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:09:10 --> Total execution time: 0.0327
DEBUG - 2022-05-19 07:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:09:22 --> Total execution time: 0.0212
DEBUG - 2022-05-19 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:09:41 --> Total execution time: 0.0146
DEBUG - 2022-05-19 07:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:09:49 --> Total execution time: 0.0303
DEBUG - 2022-05-19 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:05 --> Total execution time: 0.0151
DEBUG - 2022-05-19 07:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:15 --> Total execution time: 0.0175
DEBUG - 2022-05-19 07:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:19 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:19 --> Total execution time: 0.0187
DEBUG - 2022-05-19 07:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:20 --> Total execution time: 0.0181
DEBUG - 2022-05-19 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:22 --> Total execution time: 0.0137
DEBUG - 2022-05-19 07:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:34 --> Total execution time: 0.0172
DEBUG - 2022-05-19 07:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:35 --> Total execution time: 0.0145
DEBUG - 2022-05-19 07:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:36 --> Total execution time: 0.0364
DEBUG - 2022-05-19 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:38 --> Total execution time: 0.0163
DEBUG - 2022-05-19 07:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:10:43 --> Total execution time: 0.0273
DEBUG - 2022-05-19 07:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:47:53 --> No URI present. Default controller set.
DEBUG - 2022-05-19 07:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:17:53 --> Total execution time: 0.0491
DEBUG - 2022-05-19 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:20:44 --> Total execution time: 0.0150
DEBUG - 2022-05-19 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:21:03 --> Total execution time: 0.0188
DEBUG - 2022-05-19 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:21:06 --> Total execution time: 0.0225
DEBUG - 2022-05-19 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:21:18 --> Total execution time: 0.0208
DEBUG - 2022-05-19 07:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:21:38 --> Total execution time: 0.0149
DEBUG - 2022-05-19 08:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:02:59 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:32:59 --> Total execution time: 0.0615
DEBUG - 2022-05-19 08:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:33:09 --> Total execution time: 0.0374
DEBUG - 2022-05-19 08:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:34:30 --> Total execution time: 0.0358
DEBUG - 2022-05-19 08:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:34:59 --> Total execution time: 0.0383
DEBUG - 2022-05-19 08:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:35:19 --> Total execution time: 0.0469
DEBUG - 2022-05-19 08:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:35:34 --> Total execution time: 0.0331
DEBUG - 2022-05-19 08:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:36:00 --> Total execution time: 0.0450
DEBUG - 2022-05-19 08:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:36:14 --> Total execution time: 0.0440
DEBUG - 2022-05-19 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:36:23 --> Total execution time: 0.0354
DEBUG - 2022-05-19 08:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:38:27 --> Total execution time: 0.0612
DEBUG - 2022-05-19 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:02 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:02 --> Total execution time: 0.0513
DEBUG - 2022-05-19 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:07 --> Total execution time: 0.0332
DEBUG - 2022-05-19 08:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:15 --> Total execution time: 0.0396
DEBUG - 2022-05-19 08:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:18 --> Total execution time: 0.0469
DEBUG - 2022-05-19 08:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:22 --> Total execution time: 0.0362
DEBUG - 2022-05-19 08:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:25 --> Total execution time: 0.0327
DEBUG - 2022-05-19 08:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:37 --> Total execution time: 0.0886
DEBUG - 2022-05-19 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:09:55 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:39:55 --> Total execution time: 0.0403
DEBUG - 2022-05-19 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:40:00 --> Total execution time: 0.0325
DEBUG - 2022-05-19 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:40:17 --> Total execution time: 0.0334
DEBUG - 2022-05-19 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:40:35 --> Total execution time: 0.0431
DEBUG - 2022-05-19 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:11:23 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:41:23 --> Total execution time: 0.0537
DEBUG - 2022-05-19 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:12:04 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:42:04 --> Total execution time: 0.0348
DEBUG - 2022-05-19 08:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:42:12 --> Total execution time: 0.0346
DEBUG - 2022-05-19 08:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:42:16 --> Total execution time: 0.0496
DEBUG - 2022-05-19 08:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:42:37 --> Total execution time: 0.0496
DEBUG - 2022-05-19 08:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:42:52 --> Total execution time: 0.1117
DEBUG - 2022-05-19 08:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:13:22 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:43:22 --> Total execution time: 0.0551
DEBUG - 2022-05-19 08:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:44:28 --> Total execution time: 0.0640
DEBUG - 2022-05-19 08:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:45:00 --> Total execution time: 0.0427
DEBUG - 2022-05-19 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:45:22 --> Total execution time: 0.2558
DEBUG - 2022-05-19 08:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:45:39 --> Total execution time: 0.0421
DEBUG - 2022-05-19 08:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:45:53 --> Total execution time: 0.0490
DEBUG - 2022-05-19 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:46:41 --> Total execution time: 0.0583
DEBUG - 2022-05-19 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:46:54 --> Total execution time: 0.0449
DEBUG - 2022-05-19 08:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:47:09 --> Total execution time: 0.0430
DEBUG - 2022-05-19 08:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:47:20 --> Total execution time: 0.0463
DEBUG - 2022-05-19 08:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:47:39 --> Total execution time: 0.0516
DEBUG - 2022-05-19 08:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:47:48 --> Total execution time: 0.0410
DEBUG - 2022-05-19 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:48:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 08:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:48:30 --> Total execution time: 0.0566
DEBUG - 2022-05-19 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:48:56 --> Total execution time: 0.0463
DEBUG - 2022-05-19 08:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:21:59 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:51:59 --> Total execution time: 0.1379
DEBUG - 2022-05-19 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:52:15 --> Total execution time: 0.0194
DEBUG - 2022-05-19 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:52:26 --> Total execution time: 0.0161
DEBUG - 2022-05-19 08:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:52:29 --> Total execution time: 0.0144
DEBUG - 2022-05-19 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:52:33 --> Total execution time: 0.0149
DEBUG - 2022-05-19 08:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:52:48 --> Total execution time: 0.0268
DEBUG - 2022-05-19 08:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:53:02 --> Total execution time: 0.2011
DEBUG - 2022-05-19 08:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:24:14 --> Total execution time: 0.0154
DEBUG - 2022-05-19 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:54:18 --> Total execution time: 0.0152
DEBUG - 2022-05-19 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:54:41 --> Total execution time: 0.0266
DEBUG - 2022-05-19 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:54:45 --> Total execution time: 0.0150
DEBUG - 2022-05-19 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:54:52 --> Total execution time: 0.0196
DEBUG - 2022-05-19 08:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:55:00 --> Total execution time: 0.0185
DEBUG - 2022-05-19 08:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:55:12 --> Total execution time: 0.0215
DEBUG - 2022-05-19 08:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:55:15 --> Total execution time: 0.0168
DEBUG - 2022-05-19 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:55:21 --> Total execution time: 0.0167
DEBUG - 2022-05-19 08:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:55:28 --> Total execution time: 0.0164
DEBUG - 2022-05-19 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:55:55 --> Total execution time: 0.0229
DEBUG - 2022-05-19 08:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:56:00 --> Total execution time: 0.0197
DEBUG - 2022-05-19 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:56:05 --> Total execution time: 0.0168
DEBUG - 2022-05-19 08:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:17:56 --> Total execution time: 0.0140
DEBUG - 2022-05-19 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:48:23 --> No URI present. Default controller set.
DEBUG - 2022-05-19 08:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:18:23 --> Total execution time: 0.0209
DEBUG - 2022-05-19 08:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:18:30 --> Total execution time: 0.0257
DEBUG - 2022-05-19 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:19:03 --> Total execution time: 0.0193
DEBUG - 2022-05-19 08:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:19:16 --> Total execution time: 0.0318
DEBUG - 2022-05-19 08:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 08:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:19:23 --> Total execution time: 0.0246
DEBUG - 2022-05-19 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:19:43 --> Total execution time: 0.0465
DEBUG - 2022-05-19 08:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:19:51 --> Total execution time: 0.0180
DEBUG - 2022-05-19 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:19:57 --> Total execution time: 0.0248
DEBUG - 2022-05-19 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 08:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 08:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:20:05 --> Total execution time: 0.0161
DEBUG - 2022-05-19 09:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:06:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 09:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:36:29 --> Total execution time: 0.1144
DEBUG - 2022-05-19 09:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:36:34 --> Total execution time: 0.0192
DEBUG - 2022-05-19 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:36:36 --> Total execution time: 0.0330
DEBUG - 2022-05-19 09:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:18:47 --> No URI present. Default controller set.
DEBUG - 2022-05-19 09:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:48:47 --> Total execution time: 0.0925
DEBUG - 2022-05-19 09:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:49:07 --> Total execution time: 0.0522
DEBUG - 2022-05-19 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:50:35 --> Total execution time: 0.0169
DEBUG - 2022-05-19 09:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:22:14 --> No URI present. Default controller set.
DEBUG - 2022-05-19 09:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:52:14 --> Total execution time: 0.0396
DEBUG - 2022-05-19 09:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:52:14 --> Total execution time: 0.0367
DEBUG - 2022-05-19 09:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:53:14 --> Total execution time: 0.0536
DEBUG - 2022-05-19 09:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:23:45 --> No URI present. Default controller set.
DEBUG - 2022-05-19 09:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:53:45 --> Total execution time: 0.0218
DEBUG - 2022-05-19 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:53:48 --> Total execution time: 0.0130
DEBUG - 2022-05-19 09:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:53:54 --> Total execution time: 0.0308
DEBUG - 2022-05-19 09:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:54:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 09:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:54:46 --> Total execution time: 0.0255
DEBUG - 2022-05-19 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:57:48 --> Total execution time: 0.0412
DEBUG - 2022-05-19 09:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:58:27 --> Total execution time: 0.0684
DEBUG - 2022-05-19 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:58:44 --> Total execution time: 0.0427
DEBUG - 2022-05-19 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 09:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:58:45 --> Total execution time: 0.0376
DEBUG - 2022-05-19 09:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:58:58 --> Total execution time: 0.0527
DEBUG - 2022-05-19 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:59:02 --> Total execution time: 0.0692
DEBUG - 2022-05-19 09:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:59:05 --> Total execution time: 0.0169
DEBUG - 2022-05-19 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:59:12 --> Total execution time: 0.0268
DEBUG - 2022-05-19 09:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:59:33 --> Total execution time: 0.0157
DEBUG - 2022-05-19 09:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:29:33 --> No URI present. Default controller set.
DEBUG - 2022-05-19 09:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:59:33 --> Total execution time: 0.0151
DEBUG - 2022-05-19 09:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:27:33 --> Total execution time: 0.0533
DEBUG - 2022-05-19 09:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:28:47 --> Total execution time: 0.0292
DEBUG - 2022-05-19 09:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:28:50 --> Total execution time: 0.0432
DEBUG - 2022-05-19 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:28:52 --> Total execution time: 0.0155
DEBUG - 2022-05-19 09:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:28:54 --> Total execution time: 0.0198
DEBUG - 2022-05-19 09:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:28:56 --> Total execution time: 0.0225
DEBUG - 2022-05-19 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 09:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:29:21 --> Total execution time: 0.0260
DEBUG - 2022-05-19 10:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:31:07 --> Total execution time: 0.0530
DEBUG - 2022-05-19 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:31:14 --> Total execution time: 0.0169
DEBUG - 2022-05-19 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:35:31 --> Total execution time: 0.0522
DEBUG - 2022-05-19 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:35:56 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:06:12 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:36:12 --> Total execution time: 0.0202
DEBUG - 2022-05-19 10:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:07:04 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:37:04 --> Total execution time: 0.1371
DEBUG - 2022-05-19 10:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:09:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:39:36 --> Total execution time: 0.0508
DEBUG - 2022-05-19 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:11:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:41:40 --> Total execution time: 0.0376
DEBUG - 2022-05-19 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:11:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:41:40 --> Total execution time: 0.0143
DEBUG - 2022-05-19 10:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:11:50 --> Total execution time: 0.0216
DEBUG - 2022-05-19 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:11:52 --> Total execution time: 0.0446
DEBUG - 2022-05-19 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:11:52 --> Total execution time: 0.0385
DEBUG - 2022-05-19 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:12:33 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:42:33 --> Total execution time: 0.0158
DEBUG - 2022-05-19 10:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:08 --> Total execution time: 0.0169
DEBUG - 2022-05-19 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:09 --> Total execution time: 0.0216
DEBUG - 2022-05-19 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:09 --> Total execution time: 0.0227
DEBUG - 2022-05-19 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:09 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:10 --> Total execution time: 0.0278
DEBUG - 2022-05-19 10:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:10 --> Total execution time: 0.0316
DEBUG - 2022-05-19 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:19 --> Total execution time: 0.0150
DEBUG - 2022-05-19 10:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:20 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:43:20 --> Total execution time: 0.0212
DEBUG - 2022-05-19 10:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:43:49 --> Total execution time: 0.0155
DEBUG - 2022-05-19 10:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:15:40 --> Total execution time: 0.0144
DEBUG - 2022-05-19 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:15:41 --> Total execution time: 0.0218
DEBUG - 2022-05-19 10:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:15:41 --> Total execution time: 0.0179
DEBUG - 2022-05-19 10:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:01 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:46:01 --> Total execution time: 0.0206
DEBUG - 2022-05-19 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:17 --> Total execution time: 0.0176
DEBUG - 2022-05-19 10:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:23 --> Total execution time: 0.0173
DEBUG - 2022-05-19 10:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:23 --> Total execution time: 0.0229
DEBUG - 2022-05-19 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:51 --> Total execution time: 0.0150
DEBUG - 2022-05-19 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:53 --> Total execution time: 0.0178
DEBUG - 2022-05-19 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:16:53 --> Total execution time: 0.0157
DEBUG - 2022-05-19 10:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:17:14 --> Total execution time: 0.0150
DEBUG - 2022-05-19 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:17:15 --> Total execution time: 0.0181
DEBUG - 2022-05-19 10:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:17:15 --> Total execution time: 0.0242
DEBUG - 2022-05-19 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:47:24 --> Total execution time: 1.5041
DEBUG - 2022-05-19 10:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:17:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:48:35 --> Total execution time: 1.5021
DEBUG - 2022-05-19 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:18:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:49:43 --> Total execution time: 0.0186
DEBUG - 2022-05-19 10:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:44 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:49:44 --> Total execution time: 0.0221
DEBUG - 2022-05-19 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:49:45 --> Total execution time: 0.0393
DEBUG - 2022-05-19 10:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:19:50 --> Total execution time: 0.0250
DEBUG - 2022-05-19 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:51 --> Total execution time: 0.0185
DEBUG - 2022-05-19 10:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:19:51 --> Total execution time: 0.0165
DEBUG - 2022-05-19 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:49:53 --> Total execution time: 0.0183
DEBUG - 2022-05-19 10:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:00 --> Total execution time: 0.0313
DEBUG - 2022-05-19 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:21 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:21 --> Total execution time: 0.0443
DEBUG - 2022-05-19 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:28 --> Total execution time: 0.0200
DEBUG - 2022-05-19 10:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:29 --> Total execution time: 0.0447
DEBUG - 2022-05-19 10:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:30 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:30 --> Total execution time: 0.0172
DEBUG - 2022-05-19 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:33 --> Total execution time: 0.0162
DEBUG - 2022-05-19 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:38 --> Total execution time: 0.0140
DEBUG - 2022-05-19 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:41 --> Total execution time: 0.0149
DEBUG - 2022-05-19 10:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:48 --> Total execution time: 0.0155
DEBUG - 2022-05-19 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:50:59 --> Total execution time: 0.0079
DEBUG - 2022-05-19 10:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:08 --> Total execution time: 0.0292
DEBUG - 2022-05-19 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:09 --> Total execution time: 0.0151
DEBUG - 2022-05-19 10:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:17 --> Total execution time: 0.0159
DEBUG - 2022-05-19 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:23 --> Total execution time: 0.0186
DEBUG - 2022-05-19 10:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:27 --> Total execution time: 0.0182
DEBUG - 2022-05-19 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:32 --> Total execution time: 0.0170
DEBUG - 2022-05-19 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:34 --> Total execution time: 1.4869
DEBUG - 2022-05-19 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:35 --> Total execution time: 0.0158
DEBUG - 2022-05-19 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:37 --> Total execution time: 0.0180
DEBUG - 2022-05-19 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:21:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:39 --> Total execution time: 0.0259
DEBUG - 2022-05-19 10:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:51 --> Total execution time: 0.0140
DEBUG - 2022-05-19 10:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:52:02 --> Total execution time: 0.0186
DEBUG - 2022-05-19 10:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:52:05 --> Total execution time: 0.0184
DEBUG - 2022-05-19 10:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:52:08 --> Total execution time: 0.0179
DEBUG - 2022-05-19 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:52:09 --> Total execution time: 0.0155
DEBUG - 2022-05-19 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:52:30 --> Total execution time: 0.0578
DEBUG - 2022-05-19 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:04 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:04 --> Total execution time: 0.0156
DEBUG - 2022-05-19 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:23:19 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:23:21 --> Total execution time: 0.0081
DEBUG - 2022-05-19 10:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:23:21 --> Total execution time: 0.0166
DEBUG - 2022-05-19 10:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:30 --> Total execution time: 0.0153
DEBUG - 2022-05-19 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:42 --> Total execution time: 0.0168
DEBUG - 2022-05-19 10:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:46 --> Total execution time: 0.0230
DEBUG - 2022-05-19 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:49 --> Total execution time: 0.0131
DEBUG - 2022-05-19 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:52 --> Total execution time: 0.0312
DEBUG - 2022-05-19 10:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:53:58 --> Total execution time: 0.0184
DEBUG - 2022-05-19 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:24:10 --> Total execution time: 0.0112
DEBUG - 2022-05-19 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:24:12 --> Total execution time: 0.0179
DEBUG - 2022-05-19 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:24:12 --> Total execution time: 0.0139
DEBUG - 2022-05-19 10:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:22 --> Total execution time: 0.0216
DEBUG - 2022-05-19 10:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:29 --> Total execution time: 0.0153
DEBUG - 2022-05-19 10:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:32 --> Total execution time: 0.0101
DEBUG - 2022-05-19 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:37 --> Total execution time: 0.0134
DEBUG - 2022-05-19 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:44 --> Total execution time: 0.0070
DEBUG - 2022-05-19 10:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:52 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:54 --> Total execution time: 0.0106
DEBUG - 2022-05-19 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:56 --> Total execution time: 0.0084
DEBUG - 2022-05-19 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:54:59 --> Total execution time: 0.0145
DEBUG - 2022-05-19 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:05 --> Total execution time: 0.0129
DEBUG - 2022-05-19 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:05 --> Total execution time: 0.0136
DEBUG - 2022-05-19 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:15 --> Total execution time: 0.0172
DEBUG - 2022-05-19 10:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:36 --> Total execution time: 0.0138
DEBUG - 2022-05-19 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:40 --> Total execution time: 0.0136
DEBUG - 2022-05-19 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:41 --> Total execution time: 0.0242
DEBUG - 2022-05-19 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:42 --> Total execution time: 0.0475
DEBUG - 2022-05-19 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:42 --> Total execution time: 0.0143
DEBUG - 2022-05-19 10:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:56 --> Total execution time: 0.0255
DEBUG - 2022-05-19 10:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:55:58 --> Total execution time: 1.4305
DEBUG - 2022-05-19 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:56:06 --> Total execution time: 0.0232
DEBUG - 2022-05-19 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:56:09 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:56:14 --> Total execution time: 0.0133
DEBUG - 2022-05-19 10:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:26:47 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:56:47 --> Total execution time: 0.0198
DEBUG - 2022-05-19 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:56:51 --> Total execution time: 0.0157
DEBUG - 2022-05-19 10:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:27:04 --> Total execution time: 0.0172
DEBUG - 2022-05-19 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:27:06 --> Total execution time: 0.0153
DEBUG - 2022-05-19 10:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:27:06 --> Total execution time: 0.0347
DEBUG - 2022-05-19 10:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:12 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:58:12 --> Total execution time: 0.0202
DEBUG - 2022-05-19 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:15 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:17 --> Total execution time: 0.0159
DEBUG - 2022-05-19 10:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:17 --> Total execution time: 0.0254
DEBUG - 2022-05-19 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:39 --> Total execution time: 0.0172
DEBUG - 2022-05-19 10:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:58:44 --> Total execution time: 0.0291
DEBUG - 2022-05-19 10:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0240
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0209
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0304
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0227
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0359
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0324
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0195
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0296
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0362
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0381
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0463
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0698
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0610
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0679
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0729
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0570
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0459
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0170
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0174
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0183
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0168
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0171
DEBUG - 2022-05-19 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:47 --> Total execution time: 0.0190
DEBUG - 2022-05-19 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:48 --> Total execution time: 0.0167
DEBUG - 2022-05-19 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:48 --> Total execution time: 0.0217
DEBUG - 2022-05-19 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:48 --> Total execution time: 0.0227
DEBUG - 2022-05-19 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:49 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:49 --> Total execution time: 0.0164
DEBUG - 2022-05-19 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:49 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:58:52 --> Total execution time: 0.0261
DEBUG - 2022-05-19 10:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:58:53 --> Total execution time: 0.0351
DEBUG - 2022-05-19 10:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:28:59 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:58:59 --> Total execution time: 0.0148
DEBUG - 2022-05-19 10:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:01 --> Total execution time: 0.0167
DEBUG - 2022-05-19 10:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:02 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:02 --> Total execution time: 0.0186
DEBUG - 2022-05-19 10:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:04 --> Total execution time: 0.0247
DEBUG - 2022-05-19 20:59:05 --> Total execution time: 1.4717
DEBUG - 2022-05-19 10:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:05 --> Total execution time: 1.3921
DEBUG - 2022-05-19 10:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:06 --> Total execution time: 0.0146
DEBUG - 2022-05-19 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:08 --> Total execution time: 0.0165
DEBUG - 2022-05-19 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:08 --> Total execution time: 0.0192
DEBUG - 2022-05-19 10:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:09 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:09 --> Total execution time: 0.0187
DEBUG - 2022-05-19 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:10 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:10 --> Total execution time: 0.0154
DEBUG - 2022-05-19 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:10 --> Total execution time: 0.0162
DEBUG - 2022-05-19 10:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:13 --> Total execution time: 0.0144
DEBUG - 2022-05-19 10:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:14 --> Total execution time: 0.0166
DEBUG - 2022-05-19 10:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:14 --> Total execution time: 0.0167
DEBUG - 2022-05-19 10:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:21 --> Total execution time: 0.0178
DEBUG - 2022-05-19 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:23 --> Total execution time: 0.0268
DEBUG - 2022-05-19 10:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:23 --> Total execution time: 0.0266
DEBUG - 2022-05-19 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:24 --> Total execution time: 0.0138
DEBUG - 2022-05-19 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:29 --> Total execution time: 0.0215
DEBUG - 2022-05-19 10:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:34 --> Total execution time: 0.0300
DEBUG - 2022-05-19 10:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:35 --> Total execution time: 0.0219
DEBUG - 2022-05-19 10:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:37 --> Total execution time: 0.0174
DEBUG - 2022-05-19 10:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:29:41 --> Total execution time: 0.0180
DEBUG - 2022-05-19 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:46 --> Total execution time: 0.0249
DEBUG - 2022-05-19 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:50 --> Total execution time: 0.0223
DEBUG - 2022-05-19 10:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:52 --> Total execution time: 0.0169
DEBUG - 2022-05-19 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:54 --> Total execution time: 0.0243
DEBUG - 2022-05-19 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:59:56 --> Total execution time: 0.0256
DEBUG - 2022-05-19 10:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:01 --> Total execution time: 0.0543
DEBUG - 2022-05-19 10:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:03 --> Total execution time: 0.0466
DEBUG - 2022-05-19 10:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:04 --> Total execution time: 0.0265
DEBUG - 2022-05-19 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:08 --> Total execution time: 0.0141
DEBUG - 2022-05-19 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:09 --> Total execution time: 0.0503
DEBUG - 2022-05-19 10:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:09 --> Total execution time: 0.0216
DEBUG - 2022-05-19 10:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:10 --> Total execution time: 0.0182
DEBUG - 2022-05-19 10:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:15 --> Total execution time: 0.0178
DEBUG - 2022-05-19 10:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:18 --> Total execution time: 0.0180
DEBUG - 2022-05-19 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:27 --> Total execution time: 0.0141
DEBUG - 2022-05-19 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:32 --> Total execution time: 0.0235
DEBUG - 2022-05-19 10:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:43 --> Total execution time: 0.0212
DEBUG - 2022-05-19 10:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:52 --> Total execution time: 0.0194
DEBUG - 2022-05-19 10:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:53 --> Total execution time: 0.0131
DEBUG - 2022-05-19 10:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:54 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:00:54 --> Total execution time: 0.0159
DEBUG - 2022-05-19 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:30:55 --> Total execution time: 0.0141
DEBUG - 2022-05-19 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:05 --> Total execution time: 0.0160
DEBUG - 2022-05-19 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:09 --> Total execution time: 0.0155
DEBUG - 2022-05-19 10:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:11 --> Total execution time: 0.0209
DEBUG - 2022-05-19 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:11 --> Total execution time: 0.0184
DEBUG - 2022-05-19 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:13 --> Total execution time: 0.0164
DEBUG - 2022-05-19 10:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:14 --> Total execution time: 0.0191
DEBUG - 2022-05-19 10:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:14 --> Total execution time: 0.0245
DEBUG - 2022-05-19 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:01:15 --> Total execution time: 0.0205
DEBUG - 2022-05-19 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:15 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:16 --> Total execution time: 0.0172
DEBUG - 2022-05-19 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:16 --> Total execution time: 0.0194
DEBUG - 2022-05-19 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:01:20 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:21 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:01:21 --> Total execution time: 0.0157
DEBUG - 2022-05-19 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:01:22 --> Total execution time: 0.0318
DEBUG - 2022-05-19 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:01:31 --> Total execution time: 0.1960
DEBUG - 2022-05-19 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:01:34 --> Total execution time: 1.4314
DEBUG - 2022-05-19 10:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:31:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:31:51 --> Total execution time: 0.0189
DEBUG - 2022-05-19 21:01:52 --> Total execution time: 1.4561
DEBUG - 2022-05-19 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:31:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:01 --> Total execution time: 0.0131
DEBUG - 2022-05-19 10:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:25 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:25 --> Total execution time: 0.0263
DEBUG - 2022-05-19 10:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:36 --> Total execution time: 0.2121
DEBUG - 2022-05-19 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:45 --> Total execution time: 0.0166
DEBUG - 2022-05-19 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:46 --> Total execution time: 0.0297
DEBUG - 2022-05-19 10:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:49 --> Total execution time: 0.0159
DEBUG - 2022-05-19 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:32:57 --> Total execution time: 0.0146
DEBUG - 2022-05-19 10:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:02:59 --> Total execution time: 0.0290
DEBUG - 2022-05-19 10:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:33:00 --> Total execution time: 0.0139
DEBUG - 2022-05-19 10:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:33:00 --> Total execution time: 0.0203
DEBUG - 2022-05-19 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:03:11 --> Total execution time: 0.0270
DEBUG - 2022-05-19 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:33:23 --> Total execution time: 0.0142
DEBUG - 2022-05-19 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:03:30 --> Total execution time: 1.4602
DEBUG - 2022-05-19 10:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:33:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:09 --> Total execution time: 0.0146
DEBUG - 2022-05-19 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:04:10 --> Total execution time: 0.0261
DEBUG - 2022-05-19 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:10 --> Total execution time: 0.0137
DEBUG - 2022-05-19 10:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:10 --> Total execution time: 0.0168
DEBUG - 2022-05-19 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:04:18 --> Total execution time: 0.0262
DEBUG - 2022-05-19 10:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:04:40 --> Total execution time: 0.0169
DEBUG - 2022-05-19 10:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:34:50 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:04:50 --> Total execution time: 0.0330
DEBUG - 2022-05-19 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:03 --> Total execution time: 0.0216
DEBUG - 2022-05-19 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:04 --> Total execution time: 0.0665
DEBUG - 2022-05-19 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:09 --> Total execution time: 0.0095
DEBUG - 2022-05-19 10:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:12 --> Total execution time: 0.0149
DEBUG - 2022-05-19 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:35:14 --> Total execution time: 0.0098
DEBUG - 2022-05-19 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:18 --> Total execution time: 0.0221
DEBUG - 2022-05-19 10:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:20 --> Total execution time: 0.0332
DEBUG - 2022-05-19 10:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:22 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:22 --> Total execution time: 0.0153
DEBUG - 2022-05-19 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:28 --> Total execution time: 0.0424
DEBUG - 2022-05-19 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:32 --> Total execution time: 1.4130
DEBUG - 2022-05-19 10:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:44 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:44 --> Total execution time: 0.0156
DEBUG - 2022-05-19 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:35:46 --> Total execution time: 0.0147
DEBUG - 2022-05-19 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:49 --> Total execution time: 1.4631
DEBUG - 2022-05-19 10:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:05:59 --> Total execution time: 0.0363
DEBUG - 2022-05-19 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:03 --> Total execution time: 0.0148
DEBUG - 2022-05-19 10:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:04 --> Total execution time: 0.0224
DEBUG - 2022-05-19 10:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:04 --> Total execution time: 0.0142
DEBUG - 2022-05-19 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:05 --> Total execution time: 0.0246
DEBUG - 2022-05-19 10:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:06 --> Total execution time: 0.0148
DEBUG - 2022-05-19 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:10 --> Total execution time: 0.0092
DEBUG - 2022-05-19 10:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:14 --> Total execution time: 0.0178
DEBUG - 2022-05-19 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:17 --> Total execution time: 1.4478
DEBUG - 2022-05-19 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:18 --> Total execution time: 0.0165
DEBUG - 2022-05-19 10:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:20 --> Total execution time: 0.0256
DEBUG - 2022-05-19 10:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:24 --> Total execution time: 0.0264
DEBUG - 2022-05-19 10:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:32 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:32 --> Total execution time: 0.0281
DEBUG - 2022-05-19 10:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:35 --> Total execution time: 0.0257
DEBUG - 2022-05-19 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:36 --> Total execution time: 0.0209
DEBUG - 2022-05-19 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:37 --> Total execution time: 0.0153
DEBUG - 2022-05-19 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:38 --> Total execution time: 0.0148
DEBUG - 2022-05-19 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:38 --> Total execution time: 0.0173
DEBUG - 2022-05-19 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:39 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:39 --> Total execution time: 0.0192
DEBUG - 2022-05-19 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:39 --> Total execution time: 0.0154
DEBUG - 2022-05-19 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:42 --> Total execution time: 0.0158
DEBUG - 2022-05-19 10:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:47 --> Total execution time: 0.0152
DEBUG - 2022-05-19 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:48 --> Total execution time: 0.0175
DEBUG - 2022-05-19 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:51 --> Total execution time: 0.0282
DEBUG - 2022-05-19 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:52 --> Total execution time: 0.0159
DEBUG - 2022-05-19 10:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:54 --> Total execution time: 0.0149
DEBUG - 2022-05-19 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:55 --> Total execution time: 0.0148
DEBUG - 2022-05-19 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:56 --> Total execution time: 0.0186
DEBUG - 2022-05-19 10:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:36:56 --> Total execution time: 0.0241
DEBUG - 2022-05-19 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:06:59 --> Total execution time: 0.0150
DEBUG - 2022-05-19 10:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:00 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:07:00 --> Total execution time: 0.0149
DEBUG - 2022-05-19 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:07:10 --> Total execution time: 0.0141
DEBUG - 2022-05-19 10:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:07:26 --> Total execution time: 0.0165
DEBUG - 2022-05-19 10:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:37:34 --> Total execution time: 0.0151
DEBUG - 2022-05-19 10:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:07:43 --> Total execution time: 0.0178
DEBUG - 2022-05-19 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:37:59 --> Total execution time: 0.0174
DEBUG - 2022-05-19 10:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:02 --> Total execution time: 0.0188
DEBUG - 2022-05-19 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:03 --> Total execution time: 0.0162
DEBUG - 2022-05-19 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:03 --> Total execution time: 0.0158
DEBUG - 2022-05-19 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:03 --> Total execution time: 0.0216
DEBUG - 2022-05-19 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:04 --> Total execution time: 0.0153
DEBUG - 2022-05-19 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:30 --> Total execution time: 0.0184
DEBUG - 2022-05-19 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:08:33 --> Total execution time: 0.0181
DEBUG - 2022-05-19 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:35 --> Total execution time: 0.0156
DEBUG - 2022-05-19 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:38:35 --> Total execution time: 0.0235
DEBUG - 2022-05-19 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:08:35 --> Total execution time: 0.0345
DEBUG - 2022-05-19 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:08:44 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:09:02 --> Total execution time: 0.0284
DEBUG - 2022-05-19 10:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:39:10 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:09:10 --> Total execution time: 0.0188
DEBUG - 2022-05-19 10:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:39:17 --> Total execution time: 0.0117
DEBUG - 2022-05-19 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:39:18 --> Total execution time: 0.0230
DEBUG - 2022-05-19 10:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:39:18 --> Total execution time: 0.0186
DEBUG - 2022-05-19 10:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:39:38 --> Total execution time: 0.0171
DEBUG - 2022-05-19 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:40:28 --> Total execution time: 0.0149
DEBUG - 2022-05-19 10:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:40:29 --> Total execution time: 0.0140
DEBUG - 2022-05-19 10:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:40:29 --> Total execution time: 0.0171
DEBUG - 2022-05-19 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:11:18 --> Total execution time: 0.0142
DEBUG - 2022-05-19 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:11:52 --> Total execution time: 0.0185
DEBUG - 2022-05-19 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:41:58 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:11:58 --> Total execution time: 0.0221
DEBUG - 2022-05-19 10:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:12:02 --> Total execution time: 0.0864
DEBUG - 2022-05-19 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:12:11 --> Total execution time: 0.0402
DEBUG - 2022-05-19 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:12:12 --> Total execution time: 0.0193
DEBUG - 2022-05-19 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:12:28 --> Total execution time: 0.0310
DEBUG - 2022-05-19 10:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:12:48 --> Total execution time: 0.0205
DEBUG - 2022-05-19 10:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:42:56 --> Total execution time: 0.0151
DEBUG - 2022-05-19 10:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:42:57 --> Total execution time: 0.0233
DEBUG - 2022-05-19 10:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:42:57 --> Total execution time: 0.0263
DEBUG - 2022-05-19 10:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:13:14 --> Total execution time: 0.0177
DEBUG - 2022-05-19 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:13:18 --> Total execution time: 0.0176
DEBUG - 2022-05-19 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:13:29 --> Total execution time: 0.0171
DEBUG - 2022-05-19 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:13:46 --> Total execution time: 0.0189
DEBUG - 2022-05-19 10:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:13:51 --> Total execution time: 0.0177
DEBUG - 2022-05-19 10:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:14:36 --> Total execution time: 0.0159
DEBUG - 2022-05-19 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:15:41 --> Total execution time: 0.0199
DEBUG - 2022-05-19 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:15:51 --> Total execution time: 0.0184
DEBUG - 2022-05-19 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:15:56 --> Total execution time: 0.0175
DEBUG - 2022-05-19 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:16:06 --> Total execution time: 0.0169
DEBUG - 2022-05-19 10:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:47:39 --> Total execution time: 0.0435
DEBUG - 2022-05-19 10:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:17:45 --> Total execution time: 0.0146
DEBUG - 2022-05-19 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:48:00 --> Total execution time: 0.0160
DEBUG - 2022-05-19 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:48:02 --> Total execution time: 0.0208
DEBUG - 2022-05-19 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:48:02 --> Total execution time: 0.0158
DEBUG - 2022-05-19 10:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:49:07 --> Total execution time: 0.0145
DEBUG - 2022-05-19 10:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:19:25 --> Total execution time: 0.0157
DEBUG - 2022-05-19 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:50:10 --> Total execution time: 0.0166
DEBUG - 2022-05-19 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:50:10 --> Total execution time: 0.0239
DEBUG - 2022-05-19 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:50:16 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:20:16 --> Total execution time: 0.0299
DEBUG - 2022-05-19 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:50:24 --> Total execution time: 0.0162
DEBUG - 2022-05-19 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:50:35 --> Total execution time: 0.0142
DEBUG - 2022-05-19 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:50:35 --> Total execution time: 0.0163
DEBUG - 2022-05-19 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:21:15 --> Total execution time: 1.5697
DEBUG - 2022-05-19 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:16 --> Total execution time: 0.0182
DEBUG - 2022-05-19 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 10:51:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:18 --> Total execution time: 0.0277
DEBUG - 2022-05-19 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:18 --> Total execution time: 0.0235
DEBUG - 2022-05-19 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:21:37 --> Total execution time: 0.0184
DEBUG - 2022-05-19 10:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:21:38 --> Total execution time: 0.0311
DEBUG - 2022-05-19 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:44 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:21:44 --> Total execution time: 0.0165
DEBUG - 2022-05-19 10:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:21:55 --> Total execution time: 0.0199
DEBUG - 2022-05-19 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 10:54:09 --> No URI present. Default controller set.
DEBUG - 2022-05-19 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 10:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:24:09 --> Total execution time: 0.0450
DEBUG - 2022-05-19 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:04:18 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:34:18 --> Total execution time: 0.0405
DEBUG - 2022-05-19 11:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:34:28 --> Total execution time: 0.0153
DEBUG - 2022-05-19 11:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:06 --> Total execution time: 0.0200
DEBUG - 2022-05-19 11:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:12 --> Total execution time: 0.0151
DEBUG - 2022-05-19 11:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:12 --> Total execution time: 0.0190
DEBUG - 2022-05-19 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:35:29 --> Total execution time: 0.0277
DEBUG - 2022-05-19 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:51 --> Total execution time: 0.0159
DEBUG - 2022-05-19 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:52 --> Total execution time: 0.0145
DEBUG - 2022-05-19 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:52 --> Total execution time: 0.0182
DEBUG - 2022-05-19 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:05:59 --> Total execution time: 0.0148
DEBUG - 2022-05-19 11:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:35:59 --> Total execution time: 0.0322
DEBUG - 2022-05-19 11:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:06:00 --> Total execution time: 0.0177
DEBUG - 2022-05-19 11:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:06:00 --> Total execution time: 0.0146
DEBUG - 2022-05-19 11:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:38:21 --> Total execution time: 0.0173
DEBUG - 2022-05-19 11:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:38:46 --> Total execution time: 0.0163
DEBUG - 2022-05-19 11:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:39:42 --> Total execution time: 0.0187
DEBUG - 2022-05-19 11:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:47:47 --> Total execution time: 0.0966
DEBUG - 2022-05-19 11:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:05 --> Total execution time: 0.1034
DEBUG - 2022-05-19 11:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:12 --> Total execution time: 0.0262
DEBUG - 2022-05-19 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:24 --> Total execution time: 0.0151
DEBUG - 2022-05-19 11:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:29 --> Total execution time: 0.0152
DEBUG - 2022-05-19 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:57:54 --> Total execution time: 0.1326
DEBUG - 2022-05-19 11:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:58:31 --> Total execution time: 0.0251
DEBUG - 2022-05-19 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:28:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:58:36 --> Total execution time: 0.0173
DEBUG - 2022-05-19 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:58:39 --> Total execution time: 0.0109
DEBUG - 2022-05-19 11:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:58:44 --> Total execution time: 0.0159
DEBUG - 2022-05-19 11:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:58:50 --> Total execution time: 0.0336
DEBUG - 2022-05-19 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:58:53 --> Total execution time: 0.0265
DEBUG - 2022-05-19 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:06 --> Total execution time: 0.0160
DEBUG - 2022-05-19 11:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:12 --> Total execution time: 0.0149
DEBUG - 2022-05-19 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:26 --> Total execution time: 0.0311
DEBUG - 2022-05-19 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:30:32 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:00:32 --> Total execution time: 0.0196
DEBUG - 2022-05-19 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:30:54 --> Total execution time: 0.0147
DEBUG - 2022-05-19 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:01:34 --> Total execution time: 0.0203
DEBUG - 2022-05-19 11:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:31:48 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:01:48 --> Total execution time: 0.0157
DEBUG - 2022-05-19 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:33:22 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:03:22 --> Total execution time: 0.0266
DEBUG - 2022-05-19 11:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:03:39 --> Total execution time: 0.0516
DEBUG - 2022-05-19 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:04:33 --> Total execution time: 0.0139
DEBUG - 2022-05-19 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:04:33 --> Total execution time: 0.0801
DEBUG - 2022-05-19 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:04:58 --> Total execution time: 0.0099
DEBUG - 2022-05-19 11:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:05:02 --> Total execution time: 0.0276
DEBUG - 2022-05-19 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:05:13 --> Total execution time: 0.0203
DEBUG - 2022-05-19 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:05:17 --> Total execution time: 0.0258
DEBUG - 2022-05-19 11:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:36:11 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:06:11 --> Total execution time: 0.0188
DEBUG - 2022-05-19 11:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:06:25 --> Total execution time: 0.0327
DEBUG - 2022-05-19 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:06:26 --> Total execution time: 0.0184
DEBUG - 2022-05-19 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:06:28 --> Total execution time: 0.0243
DEBUG - 2022-05-19 11:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:07 --> Total execution time: 0.0161
DEBUG - 2022-05-19 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:14 --> Total execution time: 0.0135
DEBUG - 2022-05-19 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:14 --> Total execution time: 0.0172
DEBUG - 2022-05-19 11:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:39 --> Total execution time: 1.4324
DEBUG - 2022-05-19 11:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:37:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 11:37:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 11:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:08:06 --> Total execution time: 0.0168
DEBUG - 2022-05-19 11:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:08:14 --> Total execution time: 0.0304
DEBUG - 2022-05-19 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:09:08 --> Total execution time: 0.0296
DEBUG - 2022-05-19 11:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:09:37 --> Total execution time: 0.0216
DEBUG - 2022-05-19 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:09:44 --> Total execution time: 0.0199
DEBUG - 2022-05-19 11:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:09:55 --> Total execution time: 0.0208
DEBUG - 2022-05-19 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:10:05 --> Total execution time: 0.0485
DEBUG - 2022-05-19 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 11:40:06 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-05-19 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:10:31 --> Total execution time: 0.0424
DEBUG - 2022-05-19 11:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:16 --> Total execution time: 0.0565
DEBUG - 2022-05-19 11:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:22 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:22 --> Total execution time: 0.0278
DEBUG - 2022-05-19 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:43 --> Total execution time: 0.0217
DEBUG - 2022-05-19 11:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:47 --> Total execution time: 0.0181
DEBUG - 2022-05-19 11:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:48 --> Total execution time: 0.0187
DEBUG - 2022-05-19 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:57 --> Total execution time: 0.0389
DEBUG - 2022-05-19 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:11:57 --> Total execution time: 0.0449
DEBUG - 2022-05-19 11:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:00 --> Total execution time: 0.0156
DEBUG - 2022-05-19 11:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:06 --> Total execution time: 0.0216
DEBUG - 2022-05-19 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:10 --> Total execution time: 0.0172
DEBUG - 2022-05-19 11:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:18 --> Total execution time: 0.0410
DEBUG - 2022-05-19 11:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:24 --> Total execution time: 0.0388
DEBUG - 2022-05-19 11:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:26 --> Total execution time: 0.0233
DEBUG - 2022-05-19 11:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:31 --> Total execution time: 0.0187
DEBUG - 2022-05-19 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:34 --> Total execution time: 0.0443
DEBUG - 2022-05-19 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:47 --> Total execution time: 0.0518
DEBUG - 2022-05-19 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:13:43 --> Total execution time: 0.0165
DEBUG - 2022-05-19 11:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:13:51 --> Total execution time: 0.0432
DEBUG - 2022-05-19 11:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:13:57 --> Total execution time: 0.0185
DEBUG - 2022-05-19 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:13:59 --> Total execution time: 0.0196
DEBUG - 2022-05-19 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:00 --> Total execution time: 0.0657
DEBUG - 2022-05-19 11:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:02 --> Total execution time: 0.0946
DEBUG - 2022-05-19 11:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:02 --> Total execution time: 0.0431
DEBUG - 2022-05-19 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:04 --> Total execution time: 0.0327
DEBUG - 2022-05-19 11:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:09 --> Total execution time: 0.0391
DEBUG - 2022-05-19 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:13 --> Total execution time: 0.0880
DEBUG - 2022-05-19 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:22 --> Total execution time: 0.0763
DEBUG - 2022-05-19 11:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:40 --> Total execution time: 0.0172
DEBUG - 2022-05-19 11:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:44:47 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:14:47 --> Total execution time: 0.0270
DEBUG - 2022-05-19 11:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:46:10 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:16:10 --> Total execution time: 0.0222
DEBUG - 2022-05-19 11:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:16:47 --> Total execution time: 0.0190
DEBUG - 2022-05-19 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:16:48 --> Total execution time: 0.0449
DEBUG - 2022-05-19 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:16:58 --> Total execution time: 0.0183
DEBUG - 2022-05-19 11:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:17:09 --> Total execution time: 0.0288
DEBUG - 2022-05-19 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:17:12 --> Total execution time: 0.0213
DEBUG - 2022-05-19 11:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:17:27 --> Total execution time: 0.0279
DEBUG - 2022-05-19 11:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:18:13 --> Total execution time: 0.1528
DEBUG - 2022-05-19 11:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:18:13 --> Total execution time: 0.0754
DEBUG - 2022-05-19 11:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:18:38 --> Total execution time: 0.0578
DEBUG - 2022-05-19 11:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:18:51 --> Total execution time: 0.0425
DEBUG - 2022-05-19 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:21 --> Total execution time: 0.0394
DEBUG - 2022-05-19 11:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:33 --> No URI present. Default controller set.
DEBUG - 2022-05-19 11:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:33 --> Total execution time: 0.0213
DEBUG - 2022-05-19 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:36 --> Total execution time: 0.0138
DEBUG - 2022-05-19 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:44 --> Total execution time: 0.0393
DEBUG - 2022-05-19 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:57 --> Total execution time: 0.0155
DEBUG - 2022-05-19 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:01 --> Total execution time: 0.0512
DEBUG - 2022-05-19 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:01 --> Total execution time: 0.0133
DEBUG - 2022-05-19 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:04 --> Total execution time: 0.0211
DEBUG - 2022-05-19 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:04 --> Total execution time: 0.0180
DEBUG - 2022-05-19 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:04 --> Total execution time: 0.0166
DEBUG - 2022-05-19 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:04 --> Total execution time: 0.0202
DEBUG - 2022-05-19 11:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:05 --> Total execution time: 0.0168
DEBUG - 2022-05-19 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:08 --> Total execution time: 0.0165
DEBUG - 2022-05-19 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:13 --> Total execution time: 0.0174
DEBUG - 2022-05-19 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:13 --> Total execution time: 0.0139
DEBUG - 2022-05-19 11:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:15 --> Total execution time: 0.0168
DEBUG - 2022-05-19 11:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:15 --> Total execution time: 0.0173
DEBUG - 2022-05-19 11:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:15 --> Total execution time: 0.0151
DEBUG - 2022-05-19 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:17 --> Total execution time: 0.0152
DEBUG - 2022-05-19 11:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:25 --> Total execution time: 0.0299
DEBUG - 2022-05-19 11:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:29 --> Total execution time: 0.0168
DEBUG - 2022-05-19 11:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:33 --> Total execution time: 0.0316
DEBUG - 2022-05-19 11:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:34 --> Total execution time: 0.0163
DEBUG - 2022-05-19 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:55 --> Total execution time: 0.0170
DEBUG - 2022-05-19 11:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:59 --> Total execution time: 1.4069
DEBUG - 2022-05-19 11:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:08 --> Total execution time: 0.0232
DEBUG - 2022-05-19 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:48 --> Total execution time: 0.0139
DEBUG - 2022-05-19 11:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:56 --> Total execution time: 0.0108
DEBUG - 2022-05-19 11:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:01 --> Total execution time: 0.0132
DEBUG - 2022-05-19 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:11 --> Total execution time: 0.0150
DEBUG - 2022-05-19 11:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:19 --> Total execution time: 0.0134
DEBUG - 2022-05-19 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:22 --> Total execution time: 0.0125
DEBUG - 2022-05-19 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:23 --> Total execution time: 0.0114
DEBUG - 2022-05-19 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:23 --> Total execution time: 0.0318
DEBUG - 2022-05-19 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:26 --> Total execution time: 0.0104
DEBUG - 2022-05-19 11:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:35 --> Total execution time: 0.0088
DEBUG - 2022-05-19 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:40 --> Total execution time: 0.0256
DEBUG - 2022-05-19 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:29 --> Total execution time: 0.0170
DEBUG - 2022-05-19 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:38 --> Total execution time: 0.0105
DEBUG - 2022-05-19 11:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:42 --> Total execution time: 0.0148
DEBUG - 2022-05-19 11:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:47 --> Total execution time: 0.0092
DEBUG - 2022-05-19 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:24:07 --> Total execution time: 0.0066
DEBUG - 2022-05-19 11:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 11:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:24:14 --> Total execution time: 0.0161
DEBUG - 2022-05-19 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:24:20 --> Total execution time: 0.0142
DEBUG - 2022-05-19 11:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:24:25 --> Total execution time: 0.0311
DEBUG - 2022-05-19 11:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:03 --> Total execution time: 0.0596
DEBUG - 2022-05-19 11:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:14 --> Total execution time: 0.0222
DEBUG - 2022-05-19 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:16 --> Total execution time: 0.0171
DEBUG - 2022-05-19 11:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:21 --> Total execution time: 0.0247
DEBUG - 2022-05-19 11:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:28 --> Total execution time: 0.0140
DEBUG - 2022-05-19 11:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:34 --> Total execution time: 0.0164
DEBUG - 2022-05-19 11:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:39 --> Total execution time: 0.0188
DEBUG - 2022-05-19 11:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:43 --> Total execution time: 0.0259
DEBUG - 2022-05-19 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:12 --> Total execution time: 0.0154
DEBUG - 2022-05-19 11:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:20 --> Total execution time: 0.0239
DEBUG - 2022-05-19 11:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:31 --> Total execution time: 0.0164
DEBUG - 2022-05-19 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:36 --> Total execution time: 0.0170
DEBUG - 2022-05-19 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:36 --> Total execution time: 0.0318
DEBUG - 2022-05-19 11:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:39 --> Total execution time: 0.0231
DEBUG - 2022-05-19 11:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:42 --> Total execution time: 0.0156
DEBUG - 2022-05-19 11:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:42 --> Total execution time: 0.0150
DEBUG - 2022-05-19 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:43 --> Total execution time: 0.0798
DEBUG - 2022-05-19 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:44 --> Total execution time: 0.0146
DEBUG - 2022-05-19 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:44 --> Total execution time: 0.0160
DEBUG - 2022-05-19 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:50 --> Total execution time: 0.0391
DEBUG - 2022-05-19 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:50 --> Total execution time: 0.0173
DEBUG - 2022-05-19 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:28:54 --> Total execution time: 0.5016
DEBUG - 2022-05-19 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:03 --> Total execution time: 0.0147
DEBUG - 2022-05-19 11:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:12 --> Total execution time: 0.0224
DEBUG - 2022-05-19 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:20 --> Total execution time: 0.0168
DEBUG - 2022-05-19 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:21 --> Total execution time: 0.0182
DEBUG - 2022-05-19 11:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:27 --> Total execution time: 0.8871
DEBUG - 2022-05-19 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:35 --> Total execution time: 0.0150
DEBUG - 2022-05-19 11:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:36 --> Total execution time: 0.0226
DEBUG - 2022-05-19 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:39 --> Total execution time: 0.0323
DEBUG - 2022-05-19 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 11:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:29:44 --> Total execution time: 0.1709
DEBUG - 2022-05-19 12:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:00:58 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:30:58 --> Total execution time: 0.0335
DEBUG - 2022-05-19 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:31:20 --> Total execution time: 0.0141
DEBUG - 2022-05-19 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:31:54 --> Total execution time: 0.0148
DEBUG - 2022-05-19 12:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:32:39 --> Total execution time: 0.0178
DEBUG - 2022-05-19 12:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:02:57 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:32:57 --> Total execution time: 0.0186
DEBUG - 2022-05-19 12:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:32:59 --> Total execution time: 0.0134
DEBUG - 2022-05-19 12:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:10 --> Total execution time: 0.0109
DEBUG - 2022-05-19 12:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:17 --> Total execution time: 0.0249
DEBUG - 2022-05-19 12:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:21 --> Total execution time: 0.0212
DEBUG - 2022-05-19 12:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:26 --> Total execution time: 0.0220
DEBUG - 2022-05-19 12:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:41 --> Total execution time: 0.0214
DEBUG - 2022-05-19 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:45 --> Total execution time: 0.0199
DEBUG - 2022-05-19 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:33:49 --> Total execution time: 0.0244
DEBUG - 2022-05-19 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:34:01 --> Total execution time: 0.1590
DEBUG - 2022-05-19 12:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:34:33 --> Total execution time: 0.0218
DEBUG - 2022-05-19 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:34:43 --> Total execution time: 0.0245
DEBUG - 2022-05-19 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:34:43 --> Total execution time: 0.0181
DEBUG - 2022-05-19 12:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:34:45 --> Total execution time: 0.0187
DEBUG - 2022-05-19 12:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:34:52 --> Total execution time: 0.0176
DEBUG - 2022-05-19 12:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:35:16 --> Total execution time: 0.0169
DEBUG - 2022-05-19 12:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:35:16 --> Total execution time: 0.0149
DEBUG - 2022-05-19 12:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:35:20 --> Total execution time: 0.0103
DEBUG - 2022-05-19 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:35:27 --> Total execution time: 0.0174
DEBUG - 2022-05-19 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:35:40 --> Total execution time: 0.0215
DEBUG - 2022-05-19 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:35:48 --> Total execution time: 0.0131
DEBUG - 2022-05-19 12:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:36:02 --> Total execution time: 0.0212
DEBUG - 2022-05-19 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:36:15 --> Total execution time: 0.0264
DEBUG - 2022-05-19 12:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:36:19 --> Total execution time: 0.0162
DEBUG - 2022-05-19 12:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:36:27 --> Total execution time: 0.0167
DEBUG - 2022-05-19 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:36:30 --> Total execution time: 0.0228
DEBUG - 2022-05-19 12:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:07:35 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:37:35 --> Total execution time: 0.0187
DEBUG - 2022-05-19 12:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:37:44 --> Total execution time: 0.0139
DEBUG - 2022-05-19 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:33 --> Total execution time: 0.0092
DEBUG - 2022-05-19 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:40 --> Total execution time: 0.0187
DEBUG - 2022-05-19 12:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:45 --> Total execution time: 0.0169
DEBUG - 2022-05-19 12:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:49 --> Total execution time: 0.0265
DEBUG - 2022-05-19 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:53 --> Total execution time: 0.0278
DEBUG - 2022-05-19 12:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:58 --> Total execution time: 0.0138
DEBUG - 2022-05-19 12:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:01 --> Total execution time: 0.0173
DEBUG - 2022-05-19 12:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:11 --> Total execution time: 0.0152
DEBUG - 2022-05-19 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:20 --> Total execution time: 0.0285
DEBUG - 2022-05-19 12:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:26 --> Total execution time: 0.0249
DEBUG - 2022-05-19 12:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:29 --> Total execution time: 0.0153
DEBUG - 2022-05-19 12:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:31 --> Total execution time: 0.0147
DEBUG - 2022-05-19 12:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:31 --> Total execution time: 0.0392
DEBUG - 2022-05-19 12:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:32 --> Total execution time: 0.0146
DEBUG - 2022-05-19 12:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:33 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:33 --> Total execution time: 0.0145
DEBUG - 2022-05-19 12:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:40 --> Total execution time: 0.0130
DEBUG - 2022-05-19 12:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:56 --> Total execution time: 0.0204
DEBUG - 2022-05-19 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:10:43 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:43 --> Total execution time: 0.0212
DEBUG - 2022-05-19 12:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:50 --> Total execution time: 0.0161
DEBUG - 2022-05-19 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:55 --> Total execution time: 0.0142
DEBUG - 2022-05-19 12:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:57 --> Total execution time: 0.0129
DEBUG - 2022-05-19 12:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:11 --> Total execution time: 0.0176
DEBUG - 2022-05-19 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:49 --> Total execution time: 0.0130
DEBUG - 2022-05-19 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:41 --> Total execution time: 0.0211
DEBUG - 2022-05-19 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:41 --> Total execution time: 0.0149
DEBUG - 2022-05-19 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:42 --> Total execution time: 0.0148
DEBUG - 2022-05-19 12:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:46 --> Total execution time: 0.0181
DEBUG - 2022-05-19 12:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:50 --> Total execution time: 0.0184
DEBUG - 2022-05-19 12:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:03 --> Total execution time: 0.0151
DEBUG - 2022-05-19 12:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:12 --> Total execution time: 0.0142
DEBUG - 2022-05-19 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:43 --> Total execution time: 0.0147
DEBUG - 2022-05-19 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:00 --> Total execution time: 0.0174
DEBUG - 2022-05-19 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:03 --> Total execution time: 0.0227
DEBUG - 2022-05-19 12:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:47:07 --> Total execution time: 0.0892
DEBUG - 2022-05-19 12:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:47:11 --> Total execution time: 0.1133
DEBUG - 2022-05-19 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:47:18 --> Total execution time: 0.0190
DEBUG - 2022-05-19 12:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:47:47 --> Total execution time: 0.1199
DEBUG - 2022-05-19 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:06 --> Total execution time: 0.0179
DEBUG - 2022-05-19 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:13 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:48:13 --> Total execution time: 0.0214
DEBUG - 2022-05-19 12:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:48:15 --> Total execution time: 0.0152
DEBUG - 2022-05-19 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:20 --> Total execution time: 0.0170
DEBUG - 2022-05-19 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:20 --> Total execution time: 0.0175
DEBUG - 2022-05-19 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:48:23 --> Total execution time: 0.0212
DEBUG - 2022-05-19 12:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:49 --> Total execution time: 0.0203
DEBUG - 2022-05-19 12:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:48:52 --> Total execution time: 0.0135
DEBUG - 2022-05-19 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:49:50 --> Total execution time: 0.0132
DEBUG - 2022-05-19 12:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:50:12 --> Total execution time: 1.5565
DEBUG - 2022-05-19 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 12:20:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:51:44 --> Total execution time: 0.0159
DEBUG - 2022-05-19 12:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:51:45 --> Total execution time: 0.0311
DEBUG - 2022-05-19 12:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:51:51 --> Total execution time: 0.0151
DEBUG - 2022-05-19 12:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:51:56 --> Total execution time: 0.0245
DEBUG - 2022-05-19 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:24 --> Total execution time: 0.0274
DEBUG - 2022-05-19 12:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:53:02 --> Total execution time: 0.0210
DEBUG - 2022-05-19 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:53:05 --> Total execution time: 0.0190
DEBUG - 2022-05-19 12:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:26 --> Total execution time: 0.1667
DEBUG - 2022-05-19 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:26:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:26 --> Total execution time: 0.0241
DEBUG - 2022-05-19 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:29 --> Total execution time: 0.0144
DEBUG - 2022-05-19 12:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:39 --> Total execution time: 0.0224
DEBUG - 2022-05-19 12:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:53 --> Total execution time: 0.0353
DEBUG - 2022-05-19 12:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:57:04 --> Total execution time: 0.0147
DEBUG - 2022-05-19 12:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:57:07 --> Total execution time: 0.0117
DEBUG - 2022-05-19 12:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:09 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:57:09 --> Total execution time: 0.0098
DEBUG - 2022-05-19 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:57:12 --> Total execution time: 0.0122
DEBUG - 2022-05-19 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:57:14 --> Total execution time: 0.0250
DEBUG - 2022-05-19 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:58:42 --> Total execution time: 0.0216
DEBUG - 2022-05-19 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:00:43 --> Total execution time: 0.0079
DEBUG - 2022-05-19 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:30:54 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:00:54 --> Total execution time: 0.0124
DEBUG - 2022-05-19 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:32:41 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:02:41 --> Total execution time: 0.0199
DEBUG - 2022-05-19 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:02:56 --> Total execution time: 0.0133
DEBUG - 2022-05-19 12:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:03:11 --> Total execution time: 0.0152
DEBUG - 2022-05-19 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:03:24 --> Total execution time: 0.0130
DEBUG - 2022-05-19 12:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:18 --> Total execution time: 0.0148
DEBUG - 2022-05-19 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:23 --> Total execution time: 0.0272
DEBUG - 2022-05-19 12:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:30 --> Total execution time: 0.0423
DEBUG - 2022-05-19 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:34:47 --> Total execution time: 0.0137
DEBUG - 2022-05-19 12:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:05:06 --> Total execution time: 0.0148
DEBUG - 2022-05-19 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:19 --> No URI present. Default controller set.
DEBUG - 2022-05-19 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:05:19 --> Total execution time: 0.0207
DEBUG - 2022-05-19 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:05:27 --> Total execution time: 0.0284
DEBUG - 2022-05-19 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:05:48 --> Total execution time: 0.0361
DEBUG - 2022-05-19 12:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:05:56 --> Total execution time: 0.0203
DEBUG - 2022-05-19 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:05:59 --> Total execution time: 0.0268
DEBUG - 2022-05-19 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:06:15 --> Total execution time: 0.0203
DEBUG - 2022-05-19 12:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:06:19 --> Total execution time: 0.0441
DEBUG - 2022-05-19 12:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:09:33 --> Total execution time: 0.0289
DEBUG - 2022-05-19 12:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:15:39 --> Total execution time: 0.0166
DEBUG - 2022-05-19 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:11 --> Total execution time: 0.1059
DEBUG - 2022-05-19 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:18 --> Total execution time: 0.0114
DEBUG - 2022-05-19 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 12:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:32 --> Total execution time: 0.0155
DEBUG - 2022-05-19 12:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:36 --> Total execution time: 0.0287
DEBUG - 2022-05-19 12:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:51 --> Total execution time: 0.0255
DEBUG - 2022-05-19 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:29:05 --> Total execution time: 0.0235
DEBUG - 2022-05-19 12:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 12:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 12:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:29:12 --> Total execution time: 0.1349
DEBUG - 2022-05-19 13:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:03:55 --> Total execution time: 0.0144
DEBUG - 2022-05-19 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:04:00 --> Total execution time: 0.0153
DEBUG - 2022-05-19 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:04:00 --> Total execution time: 0.0224
DEBUG - 2022-05-19 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:04:10 --> Total execution time: 0.0150
DEBUG - 2022-05-19 13:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:35:45 --> Total execution time: 1.4432
DEBUG - 2022-05-19 13:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 13:05:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 13:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:37:32 --> Total execution time: 0.0167
DEBUG - 2022-05-19 13:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:37:33 --> Total execution time: 0.0311
DEBUG - 2022-05-19 13:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:37:37 --> Total execution time: 0.0165
DEBUG - 2022-05-19 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:39:21 --> Total execution time: 0.0259
DEBUG - 2022-05-19 13:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:39:26 --> Total execution time: 0.0254
DEBUG - 2022-05-19 13:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:39:36 --> Total execution time: 0.0248
DEBUG - 2022-05-19 13:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:39:51 --> Total execution time: 0.0268
DEBUG - 2022-05-19 13:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:40:20 --> Total execution time: 0.1191
DEBUG - 2022-05-19 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:11:39 --> No URI present. Default controller set.
DEBUG - 2022-05-19 13:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:41:39 --> Total execution time: 0.0143
DEBUG - 2022-05-19 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:42:01 --> Total execution time: 0.1189
DEBUG - 2022-05-19 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:16 --> No URI present. Default controller set.
DEBUG - 2022-05-19 13:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:16 --> Total execution time: 0.0425
DEBUG - 2022-05-19 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:19 --> Total execution time: 0.0347
DEBUG - 2022-05-19 13:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:24 --> Total execution time: 0.0426
DEBUG - 2022-05-19 13:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:26 --> Total execution time: 0.0346
DEBUG - 2022-05-19 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:29 --> Total execution time: 0.0332
DEBUG - 2022-05-19 13:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:30 --> Total execution time: 0.0599
DEBUG - 2022-05-19 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:42 --> Total execution time: 0.0463
DEBUG - 2022-05-19 13:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:50:44 --> Total execution time: 0.0512
DEBUG - 2022-05-19 13:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:39:58 --> No URI present. Default controller set.
DEBUG - 2022-05-19 13:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:39:59 --> No URI present. Default controller set.
DEBUG - 2022-05-19 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:45:04 --> No URI present. Default controller set.
DEBUG - 2022-05-19 13:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:45:11 --> No URI present. Default controller set.
DEBUG - 2022-05-19 13:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 13:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 13:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 13:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:03:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 14:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:00 --> No URI present. Default controller set.
DEBUG - 2022-05-19 14:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 14:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 14:52:15 --> No URI present. Default controller set.
DEBUG - 2022-05-19 14:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 14:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 15:38:13 --> No URI present. Default controller set.
DEBUG - 2022-05-19 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 15:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 15:38:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 15:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 15:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 15:44:56 --> No URI present. Default controller set.
DEBUG - 2022-05-19 15:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 15:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 15:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 15:56:37 --> No URI present. Default controller set.
DEBUG - 2022-05-19 15:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 15:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:00:23 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:19:45 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:22:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:22:08 --> Total execution time: 0.0150
DEBUG - 2022-05-19 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:22:54 --> Total execution time: 0.0137
DEBUG - 2022-05-19 16:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:02 --> Total execution time: 0.0152
DEBUG - 2022-05-19 16:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:53 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:58 --> Total execution time: 0.0224
DEBUG - 2022-05-19 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:59 --> Total execution time: 0.0152
DEBUG - 2022-05-19 16:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:32:59 --> Total execution time: 0.0326
DEBUG - 2022-05-19 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:16 --> Total execution time: 0.0190
DEBUG - 2022-05-19 16:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:16 --> Total execution time: 0.0189
DEBUG - 2022-05-19 16:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:16 --> Total execution time: 0.0186
DEBUG - 2022-05-19 16:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:16 --> Total execution time: 0.0298
DEBUG - 2022-05-19 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:16 --> Total execution time: 0.0248
DEBUG - 2022-05-19 16:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:17 --> Total execution time: 0.0162
DEBUG - 2022-05-19 16:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:17 --> Total execution time: 0.0239
DEBUG - 2022-05-19 16:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:17 --> Total execution time: 0.0199
DEBUG - 2022-05-19 16:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:17 --> Total execution time: 0.0192
DEBUG - 2022-05-19 16:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:17 --> Total execution time: 0.0163
DEBUG - 2022-05-19 16:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:20 --> Total execution time: 0.0182
DEBUG - 2022-05-19 16:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:20 --> Total execution time: 0.0157
DEBUG - 2022-05-19 16:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:22 --> Total execution time: 0.0173
DEBUG - 2022-05-19 16:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:22 --> Total execution time: 0.0162
DEBUG - 2022-05-19 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:25 --> Total execution time: 0.0159
DEBUG - 2022-05-19 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:26 --> Total execution time: 0.0156
DEBUG - 2022-05-19 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:26 --> Total execution time: 0.0161
DEBUG - 2022-05-19 16:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:28 --> Total execution time: 0.0159
DEBUG - 2022-05-19 16:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:28 --> Total execution time: 0.0160
DEBUG - 2022-05-19 16:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:28 --> Total execution time: 0.0161
DEBUG - 2022-05-19 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:29 --> Total execution time: 0.0161
DEBUG - 2022-05-19 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:30 --> Total execution time: 0.0252
DEBUG - 2022-05-19 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:31 --> Total execution time: 0.0175
DEBUG - 2022-05-19 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:31 --> Total execution time: 0.0202
DEBUG - 2022-05-19 16:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:32 --> Total execution time: 0.0157
DEBUG - 2022-05-19 16:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:32 --> Total execution time: 0.0180
DEBUG - 2022-05-19 16:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:34 --> Total execution time: 0.0158
DEBUG - 2022-05-19 16:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:35 --> Total execution time: 0.0240
DEBUG - 2022-05-19 16:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:36 --> Total execution time: 0.0157
DEBUG - 2022-05-19 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:37 --> Total execution time: 0.0159
DEBUG - 2022-05-19 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:38 --> Total execution time: 0.0163
DEBUG - 2022-05-19 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:38 --> Total execution time: 0.0182
DEBUG - 2022-05-19 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:40 --> Total execution time: 0.0161
DEBUG - 2022-05-19 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:40 --> Total execution time: 0.0220
DEBUG - 2022-05-19 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:44 --> Total execution time: 0.0172
DEBUG - 2022-05-19 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:45 --> Total execution time: 0.0234
DEBUG - 2022-05-19 16:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:46 --> Total execution time: 0.0159
DEBUG - 2022-05-19 16:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:46 --> Total execution time: 0.0160
DEBUG - 2022-05-19 16:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:47 --> Total execution time: 0.0192
DEBUG - 2022-05-19 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:48 --> Total execution time: 0.0165
DEBUG - 2022-05-19 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:49 --> Total execution time: 0.0162
DEBUG - 2022-05-19 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:49 --> Total execution time: 0.0170
DEBUG - 2022-05-19 16:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:36:01 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:36:06 --> Total execution time: 0.0134
DEBUG - 2022-05-19 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:36:07 --> Total execution time: 0.0163
DEBUG - 2022-05-19 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:36:07 --> Total execution time: 0.0211
DEBUG - 2022-05-19 16:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:39:20 --> Total execution time: 0.0721
DEBUG - 2022-05-19 16:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:39:21 --> Total execution time: 0.0161
DEBUG - 2022-05-19 16:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:39:21 --> Total execution time: 0.0133
DEBUG - 2022-05-19 16:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:39:23 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:39:59 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:40:01 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 16:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 16:40:21 --> No URI present. Default controller set.
DEBUG - 2022-05-19 16:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 16:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 17:31:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 17:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 17:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 17:31:06 --> No URI present. Default controller set.
DEBUG - 2022-05-19 17:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 17:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 17:34:03 --> No URI present. Default controller set.
DEBUG - 2022-05-19 17:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 17:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 17:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 17:34:04 --> No URI present. Default controller set.
DEBUG - 2022-05-19 17:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 17:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 18:23:07 --> No URI present. Default controller set.
DEBUG - 2022-05-19 18:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 18:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 18:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 18:24:20 --> No URI present. Default controller set.
DEBUG - 2022-05-19 18:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 18:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 19:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 19:50:12 --> No URI present. Default controller set.
DEBUG - 2022-05-19 19:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 19:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 20:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 20:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 20:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:43:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 21:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:43:26 --> No URI present. Default controller set.
DEBUG - 2022-05-19 21:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 21:48:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 21:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:58 --> Total execution time: 0.0169
DEBUG - 2022-05-19 21:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:59 --> Total execution time: 0.0168
DEBUG - 2022-05-19 21:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:49:59 --> Total execution time: 0.0134
DEBUG - 2022-05-19 21:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:06 --> Total execution time: 0.0204
DEBUG - 2022-05-19 21:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:32 --> Total execution time: 0.0134
DEBUG - 2022-05-19 21:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:35 --> Total execution time: 0.0174
DEBUG - 2022-05-19 21:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:51:35 --> Total execution time: 0.0219
DEBUG - 2022-05-19 21:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:46 --> No URI present. Default controller set.
DEBUG - 2022-05-19 21:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 21:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 21:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 21:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:02:57 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:17:52 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:01 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:46 --> Total execution time: 0.0191
DEBUG - 2022-05-19 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:47 --> Total execution time: 0.0161
DEBUG - 2022-05-19 22:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:20:47 --> Total execution time: 0.0220
DEBUG - 2022-05-19 22:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:20:54 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:21:23 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:22:40 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:24:49 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:01 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:43 --> Total execution time: 0.0171
DEBUG - 2022-05-19 22:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:44 --> Total execution time: 0.0166
DEBUG - 2022-05-19 22:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:44 --> Total execution time: 0.0132
DEBUG - 2022-05-19 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:57 --> Total execution time: 0.0218
DEBUG - 2022-05-19 22:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:57 --> Total execution time: 0.0402
DEBUG - 2022-05-19 22:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:57 --> Total execution time: 0.0451
DEBUG - 2022-05-19 22:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:57 --> Total execution time: 0.0576
DEBUG - 2022-05-19 22:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:58 --> Total execution time: 0.0287
DEBUG - 2022-05-19 22:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:58 --> Total execution time: 0.0199
DEBUG - 2022-05-19 22:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:39:59 --> Total execution time: 0.0163
DEBUG - 2022-05-19 22:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:00 --> Total execution time: 0.0173
DEBUG - 2022-05-19 22:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:00 --> Total execution time: 0.0174
DEBUG - 2022-05-19 22:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:00 --> Total execution time: 0.0169
DEBUG - 2022-05-19 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:01 --> Total execution time: 0.0166
DEBUG - 2022-05-19 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:01 --> Total execution time: 0.0175
DEBUG - 2022-05-19 22:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:02 --> Total execution time: 0.0934
DEBUG - 2022-05-19 22:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:02 --> Total execution time: 0.0204
DEBUG - 2022-05-19 22:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:02 --> Total execution time: 0.0178
DEBUG - 2022-05-19 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:03 --> Total execution time: 0.0195
DEBUG - 2022-05-19 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:03 --> Total execution time: 0.0241
DEBUG - 2022-05-19 22:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:04 --> Total execution time: 0.0227
DEBUG - 2022-05-19 22:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:04 --> Total execution time: 0.0159
DEBUG - 2022-05-19 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:05 --> Total execution time: 0.0169
DEBUG - 2022-05-19 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:05 --> Total execution time: 0.0195
DEBUG - 2022-05-19 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:05 --> Total execution time: 0.0179
DEBUG - 2022-05-19 22:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:06 --> Total execution time: 0.0165
DEBUG - 2022-05-19 22:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:40:06 --> Total execution time: 0.0183
DEBUG - 2022-05-19 22:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:04 --> Total execution time: 0.0145
DEBUG - 2022-05-19 22:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:35 --> Total execution time: 0.0122
DEBUG - 2022-05-19 22:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:44 --> Total execution time: 0.0127
DEBUG - 2022-05-19 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:42:56 --> Total execution time: 0.0122
DEBUG - 2022-05-19 22:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:01 --> Total execution time: 0.0132
DEBUG - 2022-05-19 22:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:12 --> Total execution time: 0.0123
DEBUG - 2022-05-19 22:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:14 --> Total execution time: 0.0124
DEBUG - 2022-05-19 22:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:15 --> Total execution time: 0.0124
DEBUG - 2022-05-19 22:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:21 --> Total execution time: 0.0138
DEBUG - 2022-05-19 22:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:28 --> Total execution time: 0.0141
DEBUG - 2022-05-19 22:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:32 --> Total execution time: 0.0171
DEBUG - 2022-05-19 22:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:32 --> Total execution time: 0.0225
DEBUG - 2022-05-19 22:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:33 --> Total execution time: 0.0124
DEBUG - 2022-05-19 22:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:35 --> Total execution time: 0.0217
DEBUG - 2022-05-19 22:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:36 --> Total execution time: 0.0123
DEBUG - 2022-05-19 22:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:43 --> Total execution time: 0.0174
DEBUG - 2022-05-19 22:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:45 --> Total execution time: 0.0172
DEBUG - 2022-05-19 22:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:03 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 22:44:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 22:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:32 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:34 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:42 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:54:25 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:00 --> No URI present. Default controller set.
DEBUG - 2022-05-19 22:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:11 --> Total execution time: 0.0151
DEBUG - 2022-05-19 22:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:12 --> Total execution time: 0.0134
DEBUG - 2022-05-19 22:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:22 --> Total execution time: 0.0185
DEBUG - 2022-05-19 22:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 22:56:32 --> Total execution time: 0.0130
DEBUG - 2022-05-19 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 22:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 22:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:04:06 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:04:36 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:09:45 --> Total execution time: 0.0143
DEBUG - 2022-05-19 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:19 --> Total execution time: 0.0122
DEBUG - 2022-05-19 23:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:28 --> Total execution time: 0.0162
DEBUG - 2022-05-19 23:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:30 --> Total execution time: 0.0121
DEBUG - 2022-05-19 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:10:35 --> Total execution time: 0.0124
DEBUG - 2022-05-19 23:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:04 --> Total execution time: 0.0121
DEBUG - 2022-05-19 23:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:05 --> Total execution time: 0.0137
DEBUG - 2022-05-19 23:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:06 --> Total execution time: 0.0163
DEBUG - 2022-05-19 23:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:07 --> Total execution time: 0.0139
DEBUG - 2022-05-19 23:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:16 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:11:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 23:11:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:12:00 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:12:45 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:15:19 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:23:35 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:16 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:49 --> Total execution time: 0.0136
DEBUG - 2022-05-19 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:50 --> Total execution time: 0.0174
DEBUG - 2022-05-19 23:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:25:05 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:29 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:29:09 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:33:06 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:35:09 --> No URI present. Default controller set.
DEBUG - 2022-05-19 23:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-19 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 23:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 23:48:45 --> Encryption: Auto-configured driver 'openssl'.
