<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-30 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:07:17 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 15:37:17 --> Total execution time: 0.1249
DEBUG - 2021-12-30 11:15:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:15:23 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 15:45:23 --> Total execution time: 0.0695
DEBUG - 2021-12-30 11:16:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:16:26 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 15:46:26 --> Total execution time: 0.0612
DEBUG - 2021-12-30 11:16:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:16:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:16:32 --> 404 Page Not Found: Admin/Rozor/index
DEBUG - 2021-12-30 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:16:56 --> 404 Page Not Found: Front/Rozor
DEBUG - 2021-12-30 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:16:58 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 15:46:58 --> Total execution time: 0.0489
DEBUG - 2021-12-30 11:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:17:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 15:47:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Orders C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Loader.php 348
DEBUG - 2021-12-30 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 15:51:27 --> Severity: error --> Exception: Call to undefined function random_strimg() C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 192
DEBUG - 2021-12-30 11:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:23:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:24:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:27:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:27:45 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 15:57:45 --> Total execution time: 0.0554
DEBUG - 2021-12-30 11:35:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:35:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:05:04 --> Severity: Notice --> Undefined variable: ORDER C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 216
ERROR - 2021-12-30 16:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 31
ERROR - 2021-12-30 16:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 32
ERROR - 2021-12-30 16:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 36
ERROR - 2021-12-30 16:05:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 37
ERROR - 2021-12-30 16:05:05 --> Severity: error --> Exception: The amount must be atleast INR 1.00 C:\xampp\htdocs\gopal\dishapradaanfoundation\application\libraries\razorpay\razorpay-php\src\Request.php 120
ERROR - 2021-12-30 16:05:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Exceptions.php:271) C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Common.php 570
DEBUG - 2021-12-30 11:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:35:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:05:18 --> Severity: Notice --> Undefined variable: ORDER C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 216
ERROR - 2021-12-30 16:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 31
ERROR - 2021-12-30 16:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 32
ERROR - 2021-12-30 16:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 36
ERROR - 2021-12-30 16:05:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 37
ERROR - 2021-12-30 16:05:19 --> Severity: error --> Exception: The amount must be atleast INR 1.00 C:\xampp\htdocs\gopal\dishapradaanfoundation\application\libraries\razorpay\razorpay-php\src\Request.php 120
ERROR - 2021-12-30 16:05:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Exceptions.php:271) C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Common.php 570
DEBUG - 2021-12-30 11:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:35:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:05:48 --> Severity: Warning --> Use of undefined constant LOGO - assumed 'LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 94
ERROR - 2021-12-30 16:05:48 --> Severity: Notice --> Undefined index: ord_order_id C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 102
DEBUG - 2021-12-30 16:05:48 --> Total execution time: 1.1652
DEBUG - 2021-12-30 11:35:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:35:51 --> 404 Page Not Found: LOGO/index
DEBUG - 2021-12-30 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:38:57 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:08:57 --> Total execution time: 0.0638
DEBUG - 2021-12-30 11:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:09:00 --> Total execution time: 1.0385
DEBUG - 2021-12-30 11:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:47:13 --> 404 Page Not Found: Payment-status/index
DEBUG - 2021-12-30 11:47:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:47:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:47:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:47:44 --> 404 Page Not Found: Transaction-status/index
DEBUG - 2021-12-30 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:47:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:47:48 --> 404 Page Not Found: Transaction-status/index
DEBUG - 2021-12-30 11:47:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:47:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:47:50 --> 404 Page Not Found: Transaction-status/index
DEBUG - 2021-12-30 11:47:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:47:54 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:17:54 --> Total execution time: 0.0487
DEBUG - 2021-12-30 11:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:18:12 --> Total execution time: 1.0730
DEBUG - 2021-12-30 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:48:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:48:37 --> 404 Page Not Found: Transaction-status/index
DEBUG - 2021-12-30 11:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:49:11 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:19:11 --> Total execution time: 0.0492
DEBUG - 2021-12-30 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:19:13 --> Total execution time: 1.0095
DEBUG - 2021-12-30 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:51:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:21:10 --> Severity: Notice --> Undefined index: ord_order_id C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 117
DEBUG - 2021-12-30 11:51:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:52:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:52:05 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:22:05 --> Total execution time: 0.0538
DEBUG - 2021-12-30 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:22:15 --> Total execution time: 1.1537
DEBUG - 2021-12-30 11:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:56:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:26:29 --> Severity: Notice --> Undefined variable: ORDER C:\xampp\htdocs\gopal\dishapradaanfoundation\application\controllers\Rozor.php 119
DEBUG - 2021-12-30 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:56:29 --> 404 Page Not Found: Register-now/index
DEBUG - 2021-12-30 11:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:56:54 --> 404 Page Not Found: Register-now/index
DEBUG - 2021-12-30 11:56:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:56:56 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:26:56 --> Total execution time: 0.0495
DEBUG - 2021-12-30 11:56:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:56:58 --> No URI present. Default controller set.
DEBUG - 2021-12-30 11:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:26:58 --> Total execution time: 0.0504
DEBUG - 2021-12-30 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:27:00 --> Total execution time: 1.0259
DEBUG - 2021-12-30 11:57:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:57:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 11:57:23 --> 404 Page Not Found: Transaction-status/index
DEBUG - 2021-12-30 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 11:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:28:28 --> Total execution time: 0.0534
DEBUG - 2021-12-30 11:58:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:28:49 --> Total execution time: 0.0515
DEBUG - 2021-12-30 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:59:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:29:19 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Front\transaction-status.php 4
ERROR - 2021-12-30 16:29:19 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Front\transaction-status.php 40
DEBUG - 2021-12-30 16:29:19 --> Total execution time: 0.0582
DEBUG - 2021-12-30 12:00:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:30:40 --> Total execution time: 0.0673
DEBUG - 2021-12-30 12:01:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:31:12 --> Total execution time: 0.0605
DEBUG - 2021-12-30 12:01:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:31:26 --> Total execution time: 0.0586
DEBUG - 2021-12-30 12:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:31:46 --> Total execution time: 0.0852
DEBUG - 2021-12-30 12:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:33:18 --> Total execution time: 0.0513
DEBUG - 2021-12-30 12:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 12:03:18 --> 404 Page Not Found: Assets/frontend2
DEBUG - 2021-12-30 12:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:33:35 --> Total execution time: 0.0731
DEBUG - 2021-12-30 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:34:00 --> Total execution time: 0.0759
DEBUG - 2021-12-30 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:34:15 --> Total execution time: 0.1038
DEBUG - 2021-12-30 12:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:34:25 --> Total execution time: 0.0678
DEBUG - 2021-12-30 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:35:10 --> Total execution time: 0.0744
DEBUG - 2021-12-30 12:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:35:23 --> Total execution time: 0.0486
DEBUG - 2021-12-30 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:50:22 --> Total execution time: 0.0544
DEBUG - 2021-12-30 12:20:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:50:37 --> Total execution time: 0.0686
DEBUG - 2021-12-30 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:51:02 --> Total execution time: 0.0525
DEBUG - 2021-12-30 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:51:34 --> Total execution time: 0.0529
DEBUG - 2021-12-30 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:52:19 --> Total execution time: 0.0489
DEBUG - 2021-12-30 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:24 --> No URI present. Default controller set.
DEBUG - 2021-12-30 12:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:52:24 --> Total execution time: 0.0503
DEBUG - 2021-12-30 12:22:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:43 --> No URI present. Default controller set.
DEBUG - 2021-12-30 12:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:52:43 --> Total execution time: 0.0506
DEBUG - 2021-12-30 12:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 12:22:56 --> Total execution time: 0.0712
DEBUG - 2021-12-30 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:52:57 --> Total execution time: 0.0509
DEBUG - 2021-12-30 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:23:40 --> No URI present. Default controller set.
DEBUG - 2021-12-30 12:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:53:40 --> Total execution time: 0.0646
DEBUG - 2021-12-30 12:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:26:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-30 16:56:44 --> Severity: Notice --> Undefined variable: lists C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Admin\admin-payment-list.php 29
DEBUG - 2021-12-30 16:56:44 --> Total execution time: 0.0608
DEBUG - 2021-12-30 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 16:56:57 --> Total execution time: 0.1299
DEBUG - 2021-12-30 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 17:02:14 --> Total execution time: 0.0569
DEBUG - 2021-12-30 12:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 17:02:34 --> Total execution time: 0.0727
DEBUG - 2021-12-30 12:33:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-30 17:03:38 --> Total execution time: 0.0719
