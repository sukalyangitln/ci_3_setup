<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-10-05 00:03:31 --> Total execution time: 0.1324
DEBUG - 2022-10-05 00:06:52 --> Total execution time: 0.1284
DEBUG - 2022-10-05 00:16:41 --> Total execution time: 0.1408
DEBUG - 2022-10-05 00:17:20 --> Total execution time: 0.4621
DEBUG - 2022-10-05 00:19:37 --> Total execution time: 0.1394
DEBUG - 2022-10-05 00:19:38 --> Total execution time: 0.0813
DEBUG - 2022-10-05 00:19:44 --> Total execution time: 0.1422
DEBUG - 2022-10-05 00:20:05 --> Total execution time: 0.1402
DEBUG - 2022-10-05 00:20:20 --> Total execution time: 0.1795
DEBUG - 2022-10-05 00:21:35 --> Total execution time: 0.0999
DEBUG - 2022-10-05 00:21:51 --> Total execution time: 0.2174
DEBUG - 2022-10-05 00:22:03 --> Total execution time: 0.1515
DEBUG - 2022-10-05 00:24:07 --> Total execution time: 0.1392
DEBUG - 2022-10-05 00:24:28 --> Total execution time: 0.1308
DEBUG - 2022-10-05 00:24:52 --> Total execution time: 0.1253
DEBUG - 2022-10-05 00:24:58 --> Total execution time: 0.1343
DEBUG - 2022-10-05 00:29:07 --> Total execution time: 0.1390
DEBUG - 2022-10-05 00:30:02 --> Total execution time: 0.2485
DEBUG - 2022-10-05 00:35:19 --> Total execution time: 0.1452
DEBUG - 2022-10-05 00:37:10 --> Total execution time: 0.1379
DEBUG - 2022-10-05 00:37:18 --> Total execution time: 0.1306
DEBUG - 2022-10-05 00:37:50 --> Total execution time: 0.1295
DEBUG - 2022-10-05 00:37:56 --> Total execution time: 0.1055
DEBUG - 2022-10-05 00:38:00 --> Total execution time: 0.1123
DEBUG - 2022-10-05 00:38:07 --> Total execution time: 0.1559
DEBUG - 2022-10-05 00:38:12 --> Total execution time: 0.1444
DEBUG - 2022-10-05 00:38:14 --> Total execution time: 0.1351
DEBUG - 2022-10-05 00:39:05 --> Total execution time: 0.1333
DEBUG - 2022-10-05 00:40:31 --> Total execution time: 0.1365
DEBUG - 2022-10-05 00:40:45 --> Total execution time: 0.1595
DEBUG - 2022-10-05 00:40:54 --> Total execution time: 0.1989
DEBUG - 2022-10-05 00:42:05 --> Total execution time: 0.0961
DEBUG - 2022-10-05 00:42:12 --> Total execution time: 0.1328
DEBUG - 2022-10-05 00:42:23 --> Total execution time: 0.1286
DEBUG - 2022-10-05 00:42:45 --> Total execution time: 0.0787
DEBUG - 2022-10-05 00:43:35 --> Total execution time: 0.4231
DEBUG - 2022-10-05 00:43:41 --> Total execution time: 0.1636
DEBUG - 2022-10-05 00:44:38 --> Total execution time: 0.3512
DEBUG - 2022-10-05 00:46:18 --> Total execution time: 0.3682
DEBUG - 2022-10-05 00:47:51 --> Total execution time: 0.0823
DEBUG - 2022-10-05 00:52:40 --> Total execution time: 0.1534
DEBUG - 2022-10-05 00:58:46 --> Total execution time: 0.4085
DEBUG - 2022-10-05 01:11:32 --> Total execution time: 0.1757
DEBUG - 2022-10-05 01:11:36 --> Total execution time: 0.0880
DEBUG - 2022-10-05 01:24:48 --> Total execution time: 0.1569
DEBUG - 2022-10-05 01:25:00 --> Total execution time: 0.1292
DEBUG - 2022-10-05 01:25:03 --> Total execution time: 0.1253
DEBUG - 2022-10-05 01:25:47 --> Total execution time: 0.1692
DEBUG - 2022-10-05 01:26:14 --> Total execution time: 0.1508
DEBUG - 2022-10-05 01:26:28 --> Total execution time: 0.1583
DEBUG - 2022-10-05 01:27:18 --> Total execution time: 0.1668
DEBUG - 2022-10-05 01:30:03 --> Total execution time: 0.2259
DEBUG - 2022-10-05 01:36:21 --> Total execution time: 0.3355
DEBUG - 2022-10-05 01:40:24 --> Total execution time: 0.1545
DEBUG - 2022-10-05 01:40:28 --> Total execution time: 0.0828
DEBUG - 2022-10-05 01:41:38 --> Total execution time: 0.3479
DEBUG - 2022-10-05 01:41:51 --> Total execution time: 0.0787
DEBUG - 2022-10-05 01:42:13 --> Total execution time: 0.0843
DEBUG - 2022-10-05 01:42:15 --> Total execution time: 0.1359
DEBUG - 2022-10-05 01:42:21 --> Total execution time: 0.3402
DEBUG - 2022-10-05 01:42:25 --> Total execution time: 0.1410
DEBUG - 2022-10-05 01:42:34 --> Total execution time: 0.2359
DEBUG - 2022-10-05 01:42:36 --> Total execution time: 0.0769
DEBUG - 2022-10-05 01:42:49 --> Total execution time: 0.1883
DEBUG - 2022-10-05 01:42:54 --> Total execution time: 0.1390
DEBUG - 2022-10-05 01:43:09 --> Total execution time: 0.1800
DEBUG - 2022-10-05 01:43:12 --> Total execution time: 0.1837
DEBUG - 2022-10-05 01:44:16 --> Total execution time: 0.1416
DEBUG - 2022-10-05 01:44:26 --> Total execution time: 0.1331
DEBUG - 2022-10-05 01:45:00 --> Total execution time: 0.1288
DEBUG - 2022-10-05 01:47:52 --> Total execution time: 0.1172
DEBUG - 2022-10-05 01:53:23 --> Total execution time: 0.1341
DEBUG - 2022-10-05 01:53:24 --> Total execution time: 0.0801
DEBUG - 2022-10-05 01:59:07 --> Total execution time: 0.1652
DEBUG - 2022-10-05 02:01:39 --> Total execution time: 0.0770
DEBUG - 2022-10-05 02:30:02 --> Total execution time: 0.6851
DEBUG - 2022-10-05 02:47:52 --> Total execution time: 0.4907
DEBUG - 2022-10-05 03:07:44 --> Total execution time: 0.4829
DEBUG - 2022-10-05 03:07:46 --> Total execution time: 0.0871
DEBUG - 2022-10-05 03:07:54 --> Total execution time: 0.0912
DEBUG - 2022-10-05 03:08:04 --> Total execution time: 0.1956
DEBUG - 2022-10-05 03:08:11 --> Total execution time: 0.1926
DEBUG - 2022-10-05 03:08:27 --> Total execution time: 0.1625
DEBUG - 2022-10-05 03:08:27 --> Total execution time: 0.1021
DEBUG - 2022-10-05 03:08:47 --> Total execution time: 0.1471
DEBUG - 2022-10-05 03:09:05 --> Total execution time: 0.1608
DEBUG - 2022-10-05 03:09:17 --> Total execution time: 0.1455
DEBUG - 2022-10-05 03:09:28 --> Total execution time: 0.1432
DEBUG - 2022-10-05 03:09:33 --> Total execution time: 0.1813
DEBUG - 2022-10-05 03:10:00 --> Total execution time: 0.1287
DEBUG - 2022-10-05 03:10:11 --> Total execution time: 0.1362
DEBUG - 2022-10-05 03:15:17 --> Total execution time: 0.4316
DEBUG - 2022-10-05 03:15:18 --> Total execution time: 0.1372
DEBUG - 2022-10-05 03:15:26 --> Total execution time: 0.1268
DEBUG - 2022-10-05 03:15:36 --> Total execution time: 0.1311
DEBUG - 2022-10-05 03:16:04 --> Total execution time: 0.3382
DEBUG - 2022-10-05 03:16:12 --> Total execution time: 2.4968
DEBUG - 2022-10-05 03:16:59 --> Total execution time: 0.1422
DEBUG - 2022-10-05 03:17:07 --> Total execution time: 0.1373
DEBUG - 2022-10-05 03:20:16 --> Total execution time: 0.1659
DEBUG - 2022-10-05 03:20:24 --> Total execution time: 0.1348
DEBUG - 2022-10-05 03:20:45 --> Total execution time: 0.1301
DEBUG - 2022-10-05 03:20:56 --> Total execution time: 0.1375
DEBUG - 2022-10-05 03:21:04 --> Total execution time: 0.1544
DEBUG - 2022-10-05 03:21:10 --> Total execution time: 0.3383
DEBUG - 2022-10-05 03:21:19 --> Total execution time: 0.1565
DEBUG - 2022-10-05 03:21:25 --> Total execution time: 0.1793
DEBUG - 2022-10-05 03:21:38 --> Total execution time: 0.1238
DEBUG - 2022-10-05 03:21:44 --> Total execution time: 0.1286
DEBUG - 2022-10-05 03:21:55 --> Total execution time: 0.1259
DEBUG - 2022-10-05 03:22:04 --> Total execution time: 0.3832
DEBUG - 2022-10-05 03:22:05 --> Total execution time: 0.1228
DEBUG - 2022-10-05 03:30:02 --> Total execution time: 0.3066
DEBUG - 2022-10-05 04:10:01 --> Total execution time: 0.5399
DEBUG - 2022-10-05 04:30:03 --> Total execution time: 0.5843
DEBUG - 2022-10-05 04:52:49 --> Total execution time: 0.1312
DEBUG - 2022-10-05 04:52:59 --> Total execution time: 0.1786
DEBUG - 2022-10-05 05:03:34 --> Total execution time: 0.1429
DEBUG - 2022-10-05 05:07:43 --> Total execution time: 0.1292
DEBUG - 2022-10-05 05:10:01 --> Total execution time: 0.1405
DEBUG - 2022-10-05 05:13:35 --> Total execution time: 0.1399
DEBUG - 2022-10-05 05:23:05 --> Total execution time: 0.1500
DEBUG - 2022-10-05 05:30:02 --> Total execution time: 0.2049
DEBUG - 2022-10-05 05:32:16 --> Total execution time: 0.1343
DEBUG - 2022-10-05 05:32:48 --> Total execution time: 0.1552
DEBUG - 2022-10-05 05:33:02 --> Total execution time: 0.1438
DEBUG - 2022-10-05 05:33:02 --> Total execution time: 0.1547
DEBUG - 2022-10-05 05:41:35 --> Total execution time: 0.1290
DEBUG - 2022-10-05 05:41:44 --> Total execution time: 0.1330
DEBUG - 2022-10-05 05:41:50 --> Total execution time: 0.1828
DEBUG - 2022-10-05 05:52:51 --> Total execution time: 0.1738
DEBUG - 2022-10-05 05:52:52 --> Total execution time: 0.0859
DEBUG - 2022-10-05 05:53:26 --> Total execution time: 0.0887
DEBUG - 2022-10-05 05:53:34 --> Total execution time: 0.0849
DEBUG - 2022-10-05 05:56:31 --> Total execution time: 0.1455
DEBUG - 2022-10-05 06:02:41 --> Total execution time: 0.1304
DEBUG - 2022-10-05 06:10:00 --> Total execution time: 0.1589
DEBUG - 2022-10-05 06:18:35 --> Total execution time: 0.4459
DEBUG - 2022-10-05 06:18:41 --> Total execution time: 0.1519
DEBUG - 2022-10-05 06:18:46 --> Total execution time: 0.1394
DEBUG - 2022-10-05 06:23:02 --> Total execution time: 0.1702
DEBUG - 2022-10-05 06:23:09 --> Total execution time: 0.1459
DEBUG - 2022-10-05 06:24:32 --> Total execution time: 0.1152
DEBUG - 2022-10-05 06:24:40 --> Total execution time: 0.1192
DEBUG - 2022-10-05 06:24:46 --> Total execution time: 0.1336
DEBUG - 2022-10-05 06:24:54 --> Total execution time: 0.1753
DEBUG - 2022-10-05 06:25:31 --> Total execution time: 0.1461
DEBUG - 2022-10-05 06:25:46 --> Total execution time: 0.1839
DEBUG - 2022-10-05 06:25:56 --> Total execution time: 0.1312
DEBUG - 2022-10-05 06:26:03 --> Total execution time: 0.1315
DEBUG - 2022-10-05 06:30:02 --> Total execution time: 0.1806
DEBUG - 2022-10-05 06:52:51 --> Total execution time: 0.1340
DEBUG - 2022-10-05 06:53:08 --> Total execution time: 0.1540
DEBUG - 2022-10-05 06:53:13 --> Total execution time: 0.1950
DEBUG - 2022-10-05 06:53:43 --> Total execution time: 0.1391
DEBUG - 2022-10-05 06:53:53 --> Total execution time: 0.1328
DEBUG - 2022-10-05 06:54:01 --> Total execution time: 0.1745
DEBUG - 2022-10-05 06:54:21 --> Total execution time: 0.1428
DEBUG - 2022-10-05 06:54:50 --> Total execution time: 0.2074
DEBUG - 2022-10-05 06:54:57 --> Total execution time: 0.1396
DEBUG - 2022-10-05 06:54:58 --> Total execution time: 0.1308
DEBUG - 2022-10-05 06:55:00 --> Total execution time: 0.1309
DEBUG - 2022-10-05 07:10:24 --> Total execution time: 0.0942
DEBUG - 2022-10-05 07:10:55 --> Total execution time: 0.0872
DEBUG - 2022-10-05 07:11:30 --> Total execution time: 0.1015
DEBUG - 2022-10-05 07:17:12 --> Total execution time: 0.1479
DEBUG - 2022-10-05 07:17:13 --> Total execution time: 0.3390
DEBUG - 2022-10-05 07:17:40 --> Total execution time: 0.1329
DEBUG - 2022-10-05 07:17:55 --> Total execution time: 0.2940
DEBUG - 2022-10-05 07:17:55 --> Total execution time: 0.1311
DEBUG - 2022-10-05 07:18:02 --> Total execution time: 0.1796
DEBUG - 2022-10-05 07:18:09 --> Total execution time: 0.1578
DEBUG - 2022-10-05 07:18:19 --> Total execution time: 0.1723
DEBUG - 2022-10-05 07:26:04 --> Total execution time: 0.1431
DEBUG - 2022-10-05 07:26:45 --> Total execution time: 0.1310
DEBUG - 2022-10-05 07:29:56 --> Total execution time: 0.1417
DEBUG - 2022-10-05 07:30:02 --> Total execution time: 0.2195
DEBUG - 2022-10-05 07:32:08 --> Total execution time: 0.1392
DEBUG - 2022-10-05 07:34:18 --> Total execution time: 0.1269
DEBUG - 2022-10-05 07:35:06 --> Total execution time: 0.0824
DEBUG - 2022-10-05 07:39:12 --> Total execution time: 0.1362
DEBUG - 2022-10-05 07:39:12 --> Total execution time: 0.1363
DEBUG - 2022-10-05 07:41:15 --> Total execution time: 0.1384
DEBUG - 2022-10-05 07:41:18 --> Total execution time: 0.1223
DEBUG - 2022-10-05 07:41:48 --> Total execution time: 0.1533
DEBUG - 2022-10-05 07:50:08 --> Total execution time: 0.1425
DEBUG - 2022-10-05 07:50:18 --> Total execution time: 0.1686
DEBUG - 2022-10-05 07:50:24 --> Total execution time: 0.1808
DEBUG - 2022-10-05 07:50:35 --> Total execution time: 0.1332
DEBUG - 2022-10-05 07:50:39 --> Total execution time: 0.1301
DEBUG - 2022-10-05 07:50:45 --> Total execution time: 0.1528
DEBUG - 2022-10-05 07:50:50 --> Total execution time: 0.1349
DEBUG - 2022-10-05 07:50:58 --> Total execution time: 0.1321
DEBUG - 2022-10-05 07:51:00 --> Total execution time: 0.1293
DEBUG - 2022-10-05 07:52:56 --> Total execution time: 0.0901
DEBUG - 2022-10-05 07:52:59 --> Total execution time: 0.1320
DEBUG - 2022-10-05 07:54:57 --> Total execution time: 0.1248
DEBUG - 2022-10-05 07:55:11 --> Total execution time: 0.1214
DEBUG - 2022-10-05 07:55:38 --> Total execution time: 0.1177
DEBUG - 2022-10-05 07:56:32 --> Total execution time: 0.1499
DEBUG - 2022-10-05 07:56:39 --> Total execution time: 0.1253
DEBUG - 2022-10-05 07:56:47 --> Total execution time: 0.1496
DEBUG - 2022-10-05 07:57:42 --> Total execution time: 0.1249
DEBUG - 2022-10-05 07:58:55 --> Total execution time: 0.1375
DEBUG - 2022-10-05 07:59:06 --> Total execution time: 0.1284
DEBUG - 2022-10-05 07:59:19 --> Total execution time: 0.1368
DEBUG - 2022-10-05 07:59:25 --> Total execution time: 0.1436
DEBUG - 2022-10-05 07:59:32 --> Total execution time: 0.1410
DEBUG - 2022-10-05 07:59:34 --> Total execution time: 0.1447
DEBUG - 2022-10-05 08:00:14 --> Total execution time: 0.0871
DEBUG - 2022-10-05 08:00:32 --> Total execution time: 0.1336
DEBUG - 2022-10-05 08:00:38 --> Total execution time: 0.1368
DEBUG - 2022-10-05 08:00:45 --> Total execution time: 0.1815
DEBUG - 2022-10-05 08:01:09 --> Total execution time: 0.1724
DEBUG - 2022-10-05 08:01:13 --> Total execution time: 0.1275
DEBUG - 2022-10-05 08:01:16 --> Total execution time: 0.1313
DEBUG - 2022-10-05 08:01:24 --> Total execution time: 0.1738
DEBUG - 2022-10-05 08:01:34 --> Total execution time: 0.1313
DEBUG - 2022-10-05 08:01:40 --> Total execution time: 0.1391
DEBUG - 2022-10-05 08:01:59 --> Total execution time: 3.2708
DEBUG - 2022-10-05 08:02:08 --> Total execution time: 0.1452
DEBUG - 2022-10-05 08:02:09 --> Total execution time: 0.1326
DEBUG - 2022-10-05 08:02:10 --> Total execution time: 0.1654
DEBUG - 2022-10-05 08:03:48 --> Total execution time: 0.1495
DEBUG - 2022-10-05 08:03:50 --> Total execution time: 0.1239
DEBUG - 2022-10-05 08:04:03 --> Total execution time: 0.1651
DEBUG - 2022-10-05 08:04:09 --> Total execution time: 0.1319
DEBUG - 2022-10-05 08:04:18 --> Total execution time: 0.1437
DEBUG - 2022-10-05 08:04:26 --> Total execution time: 0.1434
DEBUG - 2022-10-05 08:04:30 --> Total execution time: 0.1546
DEBUG - 2022-10-05 08:04:35 --> Total execution time: 0.1635
DEBUG - 2022-10-05 08:04:38 --> Total execution time: 0.1567
DEBUG - 2022-10-05 08:04:41 --> Total execution time: 0.1293
DEBUG - 2022-10-05 08:04:43 --> Total execution time: 0.1825
DEBUG - 2022-10-05 08:07:26 --> Total execution time: 0.4183
DEBUG - 2022-10-05 08:07:33 --> Total execution time: 0.1624
DEBUG - 2022-10-05 08:07:41 --> Total execution time: 0.1402
DEBUG - 2022-10-05 08:07:44 --> Total execution time: 0.3377
DEBUG - 2022-10-05 08:07:52 --> Total execution time: 0.0848
DEBUG - 2022-10-05 08:08:02 --> Total execution time: 0.1422
DEBUG - 2022-10-05 08:08:29 --> Total execution time: 0.1367
DEBUG - 2022-10-05 08:09:20 --> Total execution time: 0.1911
DEBUG - 2022-10-05 08:09:43 --> Total execution time: 2.0800
DEBUG - 2022-10-05 08:09:56 --> Total execution time: 0.0855
DEBUG - 2022-10-05 08:10:00 --> Total execution time: 0.0874
DEBUG - 2022-10-05 08:10:05 --> Total execution time: 0.1361
DEBUG - 2022-10-05 08:10:21 --> Total execution time: 0.0834
DEBUG - 2022-10-05 08:11:22 --> Total execution time: 0.4043
DEBUG - 2022-10-05 08:11:24 --> Total execution time: 0.0999
DEBUG - 2022-10-05 08:11:27 --> Total execution time: 0.1379
DEBUG - 2022-10-05 08:11:27 --> Total execution time: 0.1300
DEBUG - 2022-10-05 08:11:35 --> Total execution time: 0.1415
DEBUG - 2022-10-05 08:11:47 --> Total execution time: 0.1780
DEBUG - 2022-10-05 08:11:57 --> Total execution time: 1.9029
DEBUG - 2022-10-05 08:12:12 --> Total execution time: 0.1781
DEBUG - 2022-10-05 08:12:12 --> Total execution time: 0.1969
DEBUG - 2022-10-05 08:12:26 --> Total execution time: 0.1298
DEBUG - 2022-10-05 08:12:44 --> Total execution time: 0.1266
DEBUG - 2022-10-05 08:12:53 --> Total execution time: 0.3828
DEBUG - 2022-10-05 08:12:57 --> Total execution time: 0.0811
DEBUG - 2022-10-05 08:13:04 --> Total execution time: 0.1312
DEBUG - 2022-10-05 08:13:19 --> Total execution time: 0.1695
DEBUG - 2022-10-05 08:13:47 --> Total execution time: 0.1425
DEBUG - 2022-10-05 08:13:54 --> Total execution time: 0.1580
DEBUG - 2022-10-05 08:14:05 --> Total execution time: 0.1346
DEBUG - 2022-10-05 08:14:06 --> Total execution time: 0.1430
DEBUG - 2022-10-05 08:14:06 --> Total execution time: 0.1432
DEBUG - 2022-10-05 08:14:13 --> Total execution time: 0.0758
DEBUG - 2022-10-05 08:14:25 --> Total execution time: 0.1364
DEBUG - 2022-10-05 08:14:31 --> Total execution time: 1.9181
DEBUG - 2022-10-05 08:14:40 --> Total execution time: 0.0793
DEBUG - 2022-10-05 08:14:53 --> Total execution time: 0.1281
DEBUG - 2022-10-05 08:15:04 --> Total execution time: 0.1390
DEBUG - 2022-10-05 08:15:18 --> Total execution time: 0.1713
DEBUG - 2022-10-05 08:15:49 --> Total execution time: 0.3507
DEBUG - 2022-10-05 08:16:01 --> Total execution time: 0.1269
DEBUG - 2022-10-05 08:16:02 --> Total execution time: 0.1396
DEBUG - 2022-10-05 08:16:15 --> Total execution time: 0.1273
DEBUG - 2022-10-05 08:16:51 --> Total execution time: 1.8037
DEBUG - 2022-10-05 08:16:54 --> Total execution time: 0.1211
DEBUG - 2022-10-05 08:17:32 --> Total execution time: 0.1187
DEBUG - 2022-10-05 08:17:34 --> Total execution time: 0.1308
DEBUG - 2022-10-05 08:17:47 --> Total execution time: 0.1306
DEBUG - 2022-10-05 08:17:52 --> Total execution time: 0.1315
DEBUG - 2022-10-05 08:17:58 --> Total execution time: 0.1593
DEBUG - 2022-10-05 08:18:09 --> Total execution time: 0.1251
DEBUG - 2022-10-05 08:18:14 --> Total execution time: 0.1582
DEBUG - 2022-10-05 08:18:27 --> Total execution time: 0.1406
DEBUG - 2022-10-05 08:18:33 --> Total execution time: 0.1460
DEBUG - 2022-10-05 08:18:51 --> Total execution time: 0.1676
DEBUG - 2022-10-05 08:18:52 --> Total execution time: 0.1291
DEBUG - 2022-10-05 08:19:49 --> Total execution time: 0.1434
DEBUG - 2022-10-05 08:20:05 --> Total execution time: 2.4112
DEBUG - 2022-10-05 08:20:50 --> Total execution time: 0.3480
DEBUG - 2022-10-05 08:22:42 --> Total execution time: 0.1277
DEBUG - 2022-10-05 08:25:25 --> Total execution time: 2.1695
DEBUG - 2022-10-05 08:25:30 --> Total execution time: 0.1286
DEBUG - 2022-10-05 08:27:04 --> Total execution time: 0.0929
DEBUG - 2022-10-05 08:27:11 --> Total execution time: 0.1261
DEBUG - 2022-10-05 08:27:16 --> Total execution time: 0.0836
DEBUG - 2022-10-05 08:27:21 --> Total execution time: 0.1424
DEBUG - 2022-10-05 08:27:30 --> Total execution time: 0.1681
DEBUG - 2022-10-05 08:27:38 --> Total execution time: 0.1315
DEBUG - 2022-10-05 08:27:45 --> Total execution time: 0.1420
DEBUG - 2022-10-05 08:27:58 --> Total execution time: 0.1290
DEBUG - 2022-10-05 08:28:12 --> Total execution time: 0.1367
DEBUG - 2022-10-05 08:28:19 --> Total execution time: 0.1247
DEBUG - 2022-10-05 08:28:22 --> Total execution time: 0.1291
DEBUG - 2022-10-05 08:28:23 --> Total execution time: 0.1351
DEBUG - 2022-10-05 08:28:42 --> Total execution time: 0.1350
DEBUG - 2022-10-05 08:28:48 --> Total execution time: 0.3460
DEBUG - 2022-10-05 08:29:03 --> Total execution time: 0.1292
DEBUG - 2022-10-05 08:29:05 --> Total execution time: 0.1266
DEBUG - 2022-10-05 08:30:02 --> Total execution time: 0.1111
DEBUG - 2022-10-05 08:31:21 --> Total execution time: 0.0893
DEBUG - 2022-10-05 08:31:37 --> Total execution time: 0.1446
DEBUG - 2022-10-05 08:31:46 --> Total execution time: 0.1410
DEBUG - 2022-10-05 08:32:03 --> Total execution time: 0.1397
DEBUG - 2022-10-05 08:32:14 --> Total execution time: 0.1320
DEBUG - 2022-10-05 08:36:23 --> Total execution time: 0.0867
DEBUG - 2022-10-05 08:37:41 --> Total execution time: 0.1526
DEBUG - 2022-10-05 08:37:44 --> Total execution time: 0.0811
DEBUG - 2022-10-05 08:38:09 --> Total execution time: 0.1202
DEBUG - 2022-10-05 08:38:20 --> Total execution time: 0.1303
DEBUG - 2022-10-05 08:38:43 --> Total execution time: 0.1395
DEBUG - 2022-10-05 08:38:46 --> Total execution time: 0.1435
DEBUG - 2022-10-05 08:38:53 --> Total execution time: 0.1737
DEBUG - 2022-10-05 08:38:57 --> Total execution time: 0.1248
DEBUG - 2022-10-05 08:39:06 --> Total execution time: 0.1329
DEBUG - 2022-10-05 08:39:10 --> Total execution time: 0.1326
DEBUG - 2022-10-05 08:39:11 --> Total execution time: 0.1856
DEBUG - 2022-10-05 08:39:19 --> Total execution time: 0.1352
DEBUG - 2022-10-05 08:39:20 --> Total execution time: 0.1321
DEBUG - 2022-10-05 08:39:20 --> Total execution time: 0.1546
DEBUG - 2022-10-05 08:39:25 --> Total execution time: 0.1336
DEBUG - 2022-10-05 08:40:51 --> Total execution time: 0.1011
DEBUG - 2022-10-05 08:41:04 --> Total execution time: 0.0872
DEBUG - 2022-10-05 08:41:06 --> Total execution time: 0.1487
DEBUG - 2022-10-05 08:41:44 --> Total execution time: 0.1286
DEBUG - 2022-10-05 08:45:29 --> Total execution time: 0.1643
DEBUG - 2022-10-05 08:46:00 --> Total execution time: 0.1279
DEBUG - 2022-10-05 08:46:02 --> Total execution time: 0.4018
DEBUG - 2022-10-05 08:48:06 --> Total execution time: 0.1502
DEBUG - 2022-10-05 08:49:51 --> Total execution time: 0.1551
DEBUG - 2022-10-05 08:49:55 --> Total execution time: 0.1354
DEBUG - 2022-10-05 08:49:56 --> Total execution time: 0.1257
DEBUG - 2022-10-05 08:49:56 --> Total execution time: 0.1207
DEBUG - 2022-10-05 08:50:09 --> Total execution time: 0.1401
DEBUG - 2022-10-05 08:50:16 --> Total execution time: 0.1537
DEBUG - 2022-10-05 08:50:26 --> Total execution time: 0.1548
DEBUG - 2022-10-05 08:50:35 --> Total execution time: 0.1354
DEBUG - 2022-10-05 08:50:43 --> Total execution time: 0.1247
DEBUG - 2022-10-05 08:51:15 --> Total execution time: 0.1345
DEBUG - 2022-10-05 08:51:18 --> Total execution time: 0.1372
DEBUG - 2022-10-05 08:51:32 --> Total execution time: 0.1485
DEBUG - 2022-10-05 08:51:40 --> Total execution time: 0.1362
DEBUG - 2022-10-05 08:51:50 --> Total execution time: 0.1301
DEBUG - 2022-10-05 08:51:54 --> Total execution time: 0.1384
DEBUG - 2022-10-05 08:52:07 --> Total execution time: 0.1407
DEBUG - 2022-10-05 08:52:31 --> Total execution time: 0.1360
DEBUG - 2022-10-05 08:53:06 --> Total execution time: 0.1282
DEBUG - 2022-10-05 08:53:27 --> Total execution time: 0.1246
DEBUG - 2022-10-05 08:54:13 --> Total execution time: 0.1298
DEBUG - 2022-10-05 08:54:36 --> Total execution time: 0.1268
DEBUG - 2022-10-05 08:54:43 --> Total execution time: 0.1282
DEBUG - 2022-10-05 08:54:47 --> Total execution time: 0.1510
DEBUG - 2022-10-05 08:55:47 --> Total execution time: 0.1259
DEBUG - 2022-10-05 08:56:38 --> Total execution time: 0.0810
DEBUG - 2022-10-05 08:56:46 --> Total execution time: 0.0883
DEBUG - 2022-10-05 08:57:15 --> Total execution time: 0.1484
DEBUG - 2022-10-05 08:57:34 --> Total execution time: 0.1360
DEBUG - 2022-10-05 08:57:35 --> Total execution time: 0.0846
DEBUG - 2022-10-05 08:57:53 --> Total execution time: 0.1490
DEBUG - 2022-10-05 08:57:55 --> Total execution time: 0.3499
DEBUG - 2022-10-05 08:58:17 --> Total execution time: 0.1291
DEBUG - 2022-10-05 08:58:25 --> Total execution time: 0.1323
DEBUG - 2022-10-05 08:58:59 --> Total execution time: 0.1396
DEBUG - 2022-10-05 08:59:01 --> Total execution time: 0.1389
DEBUG - 2022-10-05 08:59:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 08:59:22 --> Total execution time: 0.1375
DEBUG - 2022-10-05 09:00:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 09:00:12 --> Total execution time: 0.1537
DEBUG - 2022-10-05 09:00:56 --> Total execution time: 0.1401
DEBUG - 2022-10-05 09:01:10 --> Total execution time: 0.1436
DEBUG - 2022-10-05 09:01:12 --> Total execution time: 0.1416
DEBUG - 2022-10-05 09:01:15 --> Total execution time: 0.1518
DEBUG - 2022-10-05 09:01:32 --> Total execution time: 0.1716
DEBUG - 2022-10-05 09:01:33 --> Total execution time: 0.1313
DEBUG - 2022-10-05 09:01:48 --> Total execution time: 0.1682
DEBUG - 2022-10-05 09:02:39 --> Total execution time: 0.0882
DEBUG - 2022-10-05 09:05:47 --> Total execution time: 0.1601
DEBUG - 2022-10-05 09:07:14 --> Total execution time: 0.0841
DEBUG - 2022-10-05 09:07:15 --> Total execution time: 0.0828
DEBUG - 2022-10-05 09:07:22 --> Total execution time: 0.1602
DEBUG - 2022-10-05 09:07:26 --> Total execution time: 0.1071
DEBUG - 2022-10-05 09:07:32 --> Total execution time: 0.1442
DEBUG - 2022-10-05 09:07:43 --> Total execution time: 0.1835
DEBUG - 2022-10-05 09:07:51 --> Total execution time: 0.1965
DEBUG - 2022-10-05 09:08:32 --> Total execution time: 0.0826
DEBUG - 2022-10-05 09:15:25 --> Total execution time: 0.4192
DEBUG - 2022-10-05 09:15:32 --> Total execution time: 0.1751
DEBUG - 2022-10-05 09:16:16 --> Total execution time: 0.3483
DEBUG - 2022-10-05 09:16:24 --> Total execution time: 0.1403
DEBUG - 2022-10-05 09:16:41 --> Total execution time: 0.1819
DEBUG - 2022-10-05 09:16:59 --> Total execution time: 0.1347
DEBUG - 2022-10-05 09:17:18 --> Total execution time: 0.2001
DEBUG - 2022-10-05 09:17:19 --> Total execution time: 0.4387
DEBUG - 2022-10-05 09:17:24 --> Total execution time: 0.1460
DEBUG - 2022-10-05 09:17:30 --> Total execution time: 0.1360
DEBUG - 2022-10-05 09:17:42 --> Total execution time: 0.1250
DEBUG - 2022-10-05 09:18:15 --> Total execution time: 0.1387
DEBUG - 2022-10-05 09:21:45 --> Total execution time: 0.1723
DEBUG - 2022-10-05 09:22:04 --> Total execution time: 0.3691
DEBUG - 2022-10-05 09:22:04 --> Total execution time: 0.1362
DEBUG - 2022-10-05 09:25:22 --> Total execution time: 0.1699
DEBUG - 2022-10-05 09:25:46 --> Total execution time: 0.3713
DEBUG - 2022-10-05 09:27:08 --> Total execution time: 0.1292
DEBUG - 2022-10-05 09:27:23 --> Total execution time: 0.1641
DEBUG - 2022-10-05 09:27:31 --> Total execution time: 0.1663
DEBUG - 2022-10-05 09:27:51 --> Total execution time: 0.4827
DEBUG - 2022-10-05 09:28:22 --> Total execution time: 0.1952
DEBUG - 2022-10-05 09:28:52 --> Total execution time: 0.1240
DEBUG - 2022-10-05 09:30:02 --> Total execution time: 0.1495
DEBUG - 2022-10-05 09:30:27 --> Total execution time: 0.1371
DEBUG - 2022-10-05 09:30:30 --> Total execution time: 0.0983
DEBUG - 2022-10-05 09:30:39 --> Total execution time: 0.1349
DEBUG - 2022-10-05 09:32:14 --> Total execution time: 0.1410
DEBUG - 2022-10-05 09:33:09 --> Total execution time: 0.0815
DEBUG - 2022-10-05 09:33:29 --> Total execution time: 0.1351
DEBUG - 2022-10-05 09:33:56 --> Total execution time: 0.1260
DEBUG - 2022-10-05 09:34:12 --> Total execution time: 0.1401
DEBUG - 2022-10-05 09:34:34 --> Total execution time: 0.1255
DEBUG - 2022-10-05 09:34:42 --> Total execution time: 0.1346
DEBUG - 2022-10-05 09:34:47 --> Total execution time: 0.0847
DEBUG - 2022-10-05 09:34:53 --> Total execution time: 0.1427
DEBUG - 2022-10-05 09:35:05 --> Total execution time: 0.1374
DEBUG - 2022-10-05 09:35:48 --> Total execution time: 0.1325
DEBUG - 2022-10-05 09:35:50 --> Total execution time: 0.1387
DEBUG - 2022-10-05 09:36:25 --> Total execution time: 0.1503
DEBUG - 2022-10-05 09:36:46 --> Total execution time: 0.1428
DEBUG - 2022-10-05 09:36:58 --> Total execution time: 0.1450
DEBUG - 2022-10-05 09:37:03 --> Total execution time: 0.1485
DEBUG - 2022-10-05 09:37:21 --> Total execution time: 0.1306
DEBUG - 2022-10-05 09:37:43 --> Total execution time: 0.1302
DEBUG - 2022-10-05 09:37:55 --> Total execution time: 0.0780
DEBUG - 2022-10-05 09:38:03 --> Total execution time: 2.5220
DEBUG - 2022-10-05 09:38:24 --> Total execution time: 0.1175
DEBUG - 2022-10-05 09:38:26 --> Total execution time: 0.1336
DEBUG - 2022-10-05 09:38:37 --> Total execution time: 0.1355
DEBUG - 2022-10-05 09:38:47 --> Total execution time: 0.1247
DEBUG - 2022-10-05 09:38:52 --> Total execution time: 0.1317
DEBUG - 2022-10-05 09:38:54 --> Total execution time: 0.1287
DEBUG - 2022-10-05 09:38:55 --> Total execution time: 0.1474
DEBUG - 2022-10-05 09:39:02 --> Total execution time: 0.3606
DEBUG - 2022-10-05 09:39:05 --> Total execution time: 0.1299
DEBUG - 2022-10-05 09:39:09 --> Total execution time: 0.1478
DEBUG - 2022-10-05 09:39:25 --> Total execution time: 0.1367
DEBUG - 2022-10-05 09:39:27 --> Total execution time: 0.1239
DEBUG - 2022-10-05 09:39:30 --> Total execution time: 0.1813
DEBUG - 2022-10-05 09:39:53 --> Total execution time: 0.1816
DEBUG - 2022-10-05 09:39:55 --> Total execution time: 0.1349
DEBUG - 2022-10-05 09:39:55 --> Total execution time: 0.0871
DEBUG - 2022-10-05 09:39:56 --> Total execution time: 0.1552
DEBUG - 2022-10-05 09:39:56 --> Total execution time: 0.1558
DEBUG - 2022-10-05 09:39:59 --> Total execution time: 0.1273
DEBUG - 2022-10-05 09:40:07 --> Total execution time: 0.0754
DEBUG - 2022-10-05 09:40:08 --> Total execution time: 0.1225
DEBUG - 2022-10-05 09:40:15 --> Total execution time: 0.1576
DEBUG - 2022-10-05 09:40:16 --> Total execution time: 0.1280
DEBUG - 2022-10-05 09:40:16 --> Total execution time: 0.1249
DEBUG - 2022-10-05 09:40:18 --> Total execution time: 0.3335
DEBUG - 2022-10-05 09:40:24 --> Total execution time: 0.1268
DEBUG - 2022-10-05 09:40:29 --> Total execution time: 0.1629
DEBUG - 2022-10-05 09:40:35 --> Total execution time: 0.3595
DEBUG - 2022-10-05 09:40:56 --> Total execution time: 0.1407
DEBUG - 2022-10-05 09:40:57 --> Total execution time: 0.1601
DEBUG - 2022-10-05 09:41:01 --> Total execution time: 0.1309
DEBUG - 2022-10-05 09:41:06 --> Total execution time: 0.1643
DEBUG - 2022-10-05 09:41:23 --> Total execution time: 0.1359
DEBUG - 2022-10-05 09:41:26 --> Total execution time: 0.1353
DEBUG - 2022-10-05 09:41:27 --> Total execution time: 0.1290
DEBUG - 2022-10-05 09:41:39 --> Total execution time: 0.1278
DEBUG - 2022-10-05 09:42:03 --> Total execution time: 0.1304
DEBUG - 2022-10-05 09:42:07 --> Total execution time: 0.1401
DEBUG - 2022-10-05 09:42:09 --> Total execution time: 0.2227
DEBUG - 2022-10-05 09:42:18 --> Total execution time: 0.1339
DEBUG - 2022-10-05 09:42:28 --> Total execution time: 0.1517
DEBUG - 2022-10-05 09:42:29 --> Total execution time: 0.0922
DEBUG - 2022-10-05 09:42:29 --> Total execution time: 0.1619
DEBUG - 2022-10-05 09:42:32 --> Total execution time: 0.1288
DEBUG - 2022-10-05 09:42:38 --> Total execution time: 0.2112
DEBUG - 2022-10-05 09:42:50 --> Total execution time: 0.1281
DEBUG - 2022-10-05 09:43:04 --> Total execution time: 0.0881
DEBUG - 2022-10-05 09:43:10 --> Total execution time: 0.3546
DEBUG - 2022-10-05 09:43:11 --> Total execution time: 0.1381
DEBUG - 2022-10-05 09:43:34 --> Total execution time: 0.1864
DEBUG - 2022-10-05 09:43:38 --> Total execution time: 0.1426
DEBUG - 2022-10-05 09:43:41 --> Total execution time: 0.1569
DEBUG - 2022-10-05 09:43:45 --> Total execution time: 0.1714
DEBUG - 2022-10-05 09:44:12 --> Total execution time: 0.1346
DEBUG - 2022-10-05 09:44:19 --> Total execution time: 0.1360
DEBUG - 2022-10-05 09:44:31 --> Total execution time: 0.1547
DEBUG - 2022-10-05 09:44:42 --> Total execution time: 0.1631
DEBUG - 2022-10-05 09:44:47 --> Total execution time: 0.1292
DEBUG - 2022-10-05 09:45:05 --> Total execution time: 0.1728
DEBUG - 2022-10-05 09:45:07 --> Total execution time: 0.1511
DEBUG - 2022-10-05 09:45:08 --> Total execution time: 0.1356
DEBUG - 2022-10-05 09:45:13 --> Total execution time: 0.2184
DEBUG - 2022-10-05 09:45:17 --> Total execution time: 0.1596
DEBUG - 2022-10-05 09:45:38 --> Total execution time: 0.1477
DEBUG - 2022-10-05 09:46:18 --> Total execution time: 0.1357
DEBUG - 2022-10-05 09:46:22 --> Total execution time: 0.1787
DEBUG - 2022-10-05 09:47:09 --> Total execution time: 0.3409
DEBUG - 2022-10-05 09:47:20 --> Total execution time: 0.1313
DEBUG - 2022-10-05 09:47:36 --> Total execution time: 0.1404
DEBUG - 2022-10-05 09:47:45 --> Total execution time: 0.1418
DEBUG - 2022-10-05 09:47:50 --> Total execution time: 0.1351
DEBUG - 2022-10-05 09:47:53 --> Total execution time: 0.1293
DEBUG - 2022-10-05 09:47:59 --> Total execution time: 0.1259
DEBUG - 2022-10-05 09:48:03 --> Total execution time: 0.1525
DEBUG - 2022-10-05 09:48:06 --> Total execution time: 0.1566
DEBUG - 2022-10-05 09:48:21 --> Total execution time: 0.0791
DEBUG - 2022-10-05 09:48:27 --> Total execution time: 0.1468
DEBUG - 2022-10-05 09:48:54 --> Total execution time: 0.1418
DEBUG - 2022-10-05 09:49:00 --> Total execution time: 0.1327
DEBUG - 2022-10-05 09:49:14 --> Total execution time: 0.1324
DEBUG - 2022-10-05 09:49:51 --> Total execution time: 0.1303
DEBUG - 2022-10-05 09:49:53 --> Total execution time: 0.1338
DEBUG - 2022-10-05 09:50:43 --> Total execution time: 0.1269
DEBUG - 2022-10-05 09:50:47 --> Total execution time: 0.1636
DEBUG - 2022-10-05 09:50:54 --> Total execution time: 0.1630
DEBUG - 2022-10-05 09:51:04 --> Total execution time: 0.1389
DEBUG - 2022-10-05 09:51:53 --> Total execution time: 0.2188
DEBUG - 2022-10-05 09:52:06 --> Total execution time: 0.1502
DEBUG - 2022-10-05 09:52:15 --> Total execution time: 0.1684
DEBUG - 2022-10-05 09:52:23 --> Total execution time: 0.2305
DEBUG - 2022-10-05 09:52:25 --> Total execution time: 0.3821
DEBUG - 2022-10-05 09:53:36 --> Total execution time: 0.1340
DEBUG - 2022-10-05 09:53:49 --> Total execution time: 0.1330
DEBUG - 2022-10-05 09:54:02 --> Total execution time: 0.1645
DEBUG - 2022-10-05 09:54:18 --> Total execution time: 0.1448
DEBUG - 2022-10-05 09:54:25 --> Total execution time: 0.1419
DEBUG - 2022-10-05 09:54:28 --> Total execution time: 0.0854
DEBUG - 2022-10-05 09:54:30 --> Total execution time: 0.1046
DEBUG - 2022-10-05 09:54:42 --> Total execution time: 0.1262
DEBUG - 2022-10-05 10:01:45 --> Total execution time: 0.4836
DEBUG - 2022-10-05 10:02:34 --> Total execution time: 0.0857
DEBUG - 2022-10-05 10:03:51 --> Total execution time: 0.0828
DEBUG - 2022-10-05 10:05:55 --> Total execution time: 0.1564
DEBUG - 2022-10-05 10:05:56 --> Total execution time: 0.1280
DEBUG - 2022-10-05 10:06:39 --> Total execution time: 0.1207
DEBUG - 2022-10-05 10:06:44 --> Total execution time: 0.1267
DEBUG - 2022-10-05 10:06:51 --> Total execution time: 0.0966
DEBUG - 2022-10-05 10:06:56 --> Total execution time: 0.1363
DEBUG - 2022-10-05 10:07:00 --> Total execution time: 0.1695
DEBUG - 2022-10-05 10:07:03 --> Total execution time: 0.1383
DEBUG - 2022-10-05 10:07:07 --> Total execution time: 0.2075
DEBUG - 2022-10-05 10:09:17 --> Total execution time: 0.1892
DEBUG - 2022-10-05 10:10:25 --> Total execution time: 0.4149
DEBUG - 2022-10-05 10:11:58 --> Total execution time: 0.0876
DEBUG - 2022-10-05 10:13:02 --> Total execution time: 0.1275
DEBUG - 2022-10-05 10:16:09 --> Total execution time: 0.3882
DEBUG - 2022-10-05 10:17:47 --> Total execution time: 0.1595
DEBUG - 2022-10-05 10:19:35 --> Total execution time: 0.1285
DEBUG - 2022-10-05 10:23:50 --> Total execution time: 0.4079
DEBUG - 2022-10-05 10:27:08 --> Total execution time: 0.1324
DEBUG - 2022-10-05 10:28:35 --> Total execution time: 0.0842
DEBUG - 2022-10-05 10:29:19 --> Total execution time: 0.1416
DEBUG - 2022-10-05 10:29:31 --> Total execution time: 0.1488
DEBUG - 2022-10-05 10:29:55 --> Total execution time: 0.1550
DEBUG - 2022-10-05 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:30:02 --> Total execution time: 0.1337
DEBUG - 2022-10-05 00:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:00:42 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:30:42 --> Total execution time: 0.1048
DEBUG - 2022-10-05 00:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:30:47 --> Total execution time: 0.0910
DEBUG - 2022-10-05 00:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:00:57 --> Total execution time: 0.1286
DEBUG - 2022-10-05 00:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:00:59 --> Total execution time: 0.1330
DEBUG - 2022-10-05 00:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:00 --> Total execution time: 0.1444
DEBUG - 2022-10-05 00:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:02 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:02 --> Total execution time: 0.0899
DEBUG - 2022-10-05 00:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:03 --> Total execution time: 0.0958
DEBUG - 2022-10-05 00:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:08 --> Total execution time: 0.1649
DEBUG - 2022-10-05 00:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:09 --> Total execution time: 0.1545
DEBUG - 2022-10-05 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:11 --> Total execution time: 0.1335
DEBUG - 2022-10-05 00:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:11 --> Total execution time: 0.3198
DEBUG - 2022-10-05 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:13 --> Total execution time: 0.1380
DEBUG - 2022-10-05 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:18 --> Total execution time: 0.0840
DEBUG - 2022-10-05 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:19 --> Total execution time: 0.1657
DEBUG - 2022-10-05 00:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:20 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:20 --> Total execution time: 0.1270
DEBUG - 2022-10-05 00:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:24 --> Total execution time: 0.1430
DEBUG - 2022-10-05 00:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:26 --> Total execution time: 0.1253
DEBUG - 2022-10-05 00:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:27 --> Total execution time: 0.1254
DEBUG - 2022-10-05 00:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:29 --> Total execution time: 0.1408
DEBUG - 2022-10-05 00:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:34 --> Total execution time: 0.1249
DEBUG - 2022-10-05 00:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:38 --> Total execution time: 0.1583
DEBUG - 2022-10-05 00:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:43 --> Total execution time: 0.1216
DEBUG - 2022-10-05 00:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:50 --> Total execution time: 0.1596
DEBUG - 2022-10-05 00:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:52 --> Total execution time: 0.1212
DEBUG - 2022-10-05 00:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:54 --> Total execution time: 0.1480
DEBUG - 2022-10-05 00:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:55 --> Total execution time: 0.1360
DEBUG - 2022-10-05 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:56 --> Total execution time: 0.1319
DEBUG - 2022-10-05 00:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:59 --> Total execution time: 0.1532
DEBUG - 2022-10-05 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:01:59 --> Total execution time: 0.3145
DEBUG - 2022-10-05 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:01:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:59 --> Total execution time: 0.1544
DEBUG - 2022-10-05 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:32:05 --> Total execution time: 0.1375
DEBUG - 2022-10-05 00:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:32:31 --> Total execution time: 0.1376
DEBUG - 2022-10-05 00:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:17 --> Total execution time: 0.1236
DEBUG - 2022-10-05 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:19 --> Total execution time: 0.2096
DEBUG - 2022-10-05 00:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:25 --> Total execution time: 0.1356
DEBUG - 2022-10-05 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:28 --> Total execution time: 0.1244
DEBUG - 2022-10-05 00:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:28 --> Total execution time: 0.1596
DEBUG - 2022-10-05 00:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:37 --> Total execution time: 0.1615
DEBUG - 2022-10-05 00:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:44 --> Total execution time: 0.2223
DEBUG - 2022-10-05 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:02 --> Total execution time: 0.1283
DEBUG - 2022-10-05 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:09 --> Total execution time: 0.1586
DEBUG - 2022-10-05 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:14 --> Total execution time: 0.1355
DEBUG - 2022-10-05 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:20 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:20 --> Total execution time: 0.1450
DEBUG - 2022-10-05 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:22 --> Total execution time: 0.1196
DEBUG - 2022-10-05 00:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:26 --> Total execution time: 0.1368
DEBUG - 2022-10-05 00:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:30 --> Total execution time: 0.1344
DEBUG - 2022-10-05 00:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:43 --> Total execution time: 0.1310
DEBUG - 2022-10-05 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:48 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:48 --> Total execution time: 0.1308
DEBUG - 2022-10-05 00:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 00:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:51 --> Total execution time: 0.1611
DEBUG - 2022-10-05 00:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:35:57 --> Total execution time: 0.1403
DEBUG - 2022-10-05 00:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:05 --> Total execution time: 0.1599
DEBUG - 2022-10-05 00:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:21 --> Total execution time: 0.3755
DEBUG - 2022-10-05 00:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:22 --> Total execution time: 0.1276
DEBUG - 2022-10-05 00:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:28 --> Total execution time: 0.1672
DEBUG - 2022-10-05 00:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:30 --> Total execution time: 0.1526
DEBUG - 2022-10-05 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:43 --> Total execution time: 0.1472
DEBUG - 2022-10-05 00:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:52 --> Total execution time: 0.1740
DEBUG - 2022-10-05 00:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:36:54 --> Total execution time: 0.1647
DEBUG - 2022-10-05 00:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:37:04 --> Total execution time: 0.1520
DEBUG - 2022-10-05 00:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:37:08 --> Total execution time: 0.1424
DEBUG - 2022-10-05 00:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:37:20 --> Total execution time: 0.1581
DEBUG - 2022-10-05 00:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:33 --> Total execution time: 0.4280
DEBUG - 2022-10-05 00:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:41 --> Total execution time: 0.1409
DEBUG - 2022-10-05 00:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:44 --> Total execution time: 0.3698
DEBUG - 2022-10-05 00:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:47 --> Total execution time: 0.1415
DEBUG - 2022-10-05 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:50 --> Total execution time: 0.1350
DEBUG - 2022-10-05 00:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:57 --> Total execution time: 0.1568
DEBUG - 2022-10-05 00:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:10:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:40:31 --> Total execution time: 0.3524
DEBUG - 2022-10-05 00:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:10:37 --> Total execution time: 0.1350
DEBUG - 2022-10-05 00:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:10:39 --> Total execution time: 0.1342
DEBUG - 2022-10-05 00:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:10:40 --> Total execution time: 0.1622
DEBUG - 2022-10-05 00:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:41:12 --> Total execution time: 0.0933
DEBUG - 2022-10-05 00:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:12:07 --> Total execution time: 0.1684
DEBUG - 2022-10-05 00:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:12:10 --> Total execution time: 0.1269
DEBUG - 2022-10-05 00:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:12:11 --> Total execution time: 0.1321
DEBUG - 2022-10-05 00:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:42:29 --> Total execution time: 0.0820
DEBUG - 2022-10-05 00:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:12:40 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:42:40 --> Total execution time: 0.0852
DEBUG - 2022-10-05 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:14:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:44:45 --> Total execution time: 0.1408
DEBUG - 2022-10-05 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:48:18 --> Total execution time: 0.1291
DEBUG - 2022-10-05 00:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:49:57 --> Total execution time: 0.3594
DEBUG - 2022-10-05 00:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:50:13 --> Total execution time: 0.1292
DEBUG - 2022-10-05 00:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:53:23 --> Total execution time: 0.1839
DEBUG - 2022-10-05 00:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:53:36 --> Total execution time: 0.0993
DEBUG - 2022-10-05 00:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:53:41 --> Total execution time: 0.0823
DEBUG - 2022-10-05 00:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:54:18 --> Total execution time: 0.1385
DEBUG - 2022-10-05 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:54:26 --> Total execution time: 0.1514
DEBUG - 2022-10-05 00:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:54:34 --> Total execution time: 0.1798
DEBUG - 2022-10-05 00:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:55:00 --> Total execution time: 0.1575
DEBUG - 2022-10-05 00:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:55:09 --> Total execution time: 0.1361
DEBUG - 2022-10-05 00:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:56:12 --> Total execution time: 0.0804
DEBUG - 2022-10-05 00:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:56:49 --> Total execution time: 0.1342
DEBUG - 2022-10-05 00:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:27:19 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:57:20 --> Total execution time: 0.4193
DEBUG - 2022-10-05 00:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:57:30 --> Total execution time: 0.1261
DEBUG - 2022-10-05 00:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:57:42 --> Total execution time: 0.1309
DEBUG - 2022-10-05 00:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:58:02 --> Total execution time: 0.1431
DEBUG - 2022-10-05 00:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:58:27 --> Total execution time: 0.0781
DEBUG - 2022-10-05 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:58:30 --> Total execution time: 0.1669
DEBUG - 2022-10-05 00:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:59:29 --> Total execution time: 0.1288
DEBUG - 2022-10-05 00:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:59:43 --> Total execution time: 0.1291
DEBUG - 2022-10-05 00:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:59:43 --> Total execution time: 0.1644
DEBUG - 2022-10-05 00:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:59:47 --> Total execution time: 0.1271
DEBUG - 2022-10-05 00:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:59:56 --> Total execution time: 0.1376
DEBUG - 2022-10-05 00:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:59:59 --> Total execution time: 0.1353
DEBUG - 2022-10-05 00:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:00:17 --> Total execution time: 0.0783
DEBUG - 2022-10-05 00:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:00:18 --> Total execution time: 0.1240
DEBUG - 2022-10-05 00:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:00:31 --> Total execution time: 0.1355
DEBUG - 2022-10-05 00:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:00:38 --> Total execution time: 0.1426
DEBUG - 2022-10-05 00:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:01:25 --> Total execution time: 0.1245
DEBUG - 2022-10-05 00:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:01:35 --> Total execution time: 0.1309
DEBUG - 2022-10-05 00:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:01:42 --> Total execution time: 0.1632
DEBUG - 2022-10-05 00:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:01:54 --> Total execution time: 0.2136
DEBUG - 2022-10-05 00:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:03:15 --> Total execution time: 0.3530
DEBUG - 2022-10-05 00:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:03:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 00:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:03:22 --> Total execution time: 0.1763
DEBUG - 2022-10-05 00:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:03:37 --> Total execution time: 0.2117
DEBUG - 2022-10-05 00:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:03:49 --> Total execution time: 0.1664
DEBUG - 2022-10-05 00:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:04:00 --> Total execution time: 0.1807
DEBUG - 2022-10-05 00:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:17 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:17 --> Total execution time: 0.1843
DEBUG - 2022-10-05 00:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:18 --> Total execution time: 0.4928
DEBUG - 2022-10-05 00:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:21 --> Total execution time: 0.1071
DEBUG - 2022-10-05 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:30 --> Total execution time: 0.1397
DEBUG - 2022-10-05 00:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:36 --> Total execution time: 0.1053
DEBUG - 2022-10-05 00:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:37 --> Total execution time: 0.3458
DEBUG - 2022-10-05 00:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:47 --> Total execution time: 0.1628
DEBUG - 2022-10-05 00:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:08:02 --> Total execution time: 0.1535
DEBUG - 2022-10-05 00:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:08:09 --> Total execution time: 0.1479
DEBUG - 2022-10-05 00:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:38:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:08:21 --> Total execution time: 0.0870
DEBUG - 2022-10-05 00:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:09:41 --> Total execution time: 0.1289
DEBUG - 2022-10-05 00:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:40:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:10:43 --> Total execution time: 0.0976
DEBUG - 2022-10-05 00:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:40:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:10:45 --> Total execution time: 0.1297
DEBUG - 2022-10-05 00:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:41:27 --> Total execution time: 0.1354
DEBUG - 2022-10-05 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:41:34 --> Total execution time: 0.1532
DEBUG - 2022-10-05 00:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:41:34 --> Total execution time: 0.3387
DEBUG - 2022-10-05 00:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:13:44 --> Total execution time: 0.1876
DEBUG - 2022-10-05 00:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:13:45 --> Total execution time: 0.1409
DEBUG - 2022-10-05 00:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:44:04 --> Total execution time: 0.1383
DEBUG - 2022-10-05 00:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:44:07 --> Total execution time: 0.1445
DEBUG - 2022-10-05 00:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:44:08 --> Total execution time: 0.1540
DEBUG - 2022-10-05 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:44:56 --> Total execution time: 0.1638
DEBUG - 2022-10-05 00:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:15:01 --> Total execution time: 2.4947
DEBUG - 2022-10-05 00:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:45:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 00:45:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 00:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:17:02 --> Total execution time: 0.3460
DEBUG - 2022-10-05 00:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:17:51 --> Total execution time: 0.3851
DEBUG - 2022-10-05 00:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:02 --> Total execution time: 0.2035
DEBUG - 2022-10-05 00:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:12 --> Total execution time: 0.1659
DEBUG - 2022-10-05 00:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:16 --> Total execution time: 0.1482
DEBUG - 2022-10-05 00:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:23 --> Total execution time: 0.3725
DEBUG - 2022-10-05 00:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:24 --> Total execution time: 0.1253
DEBUG - 2022-10-05 00:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:49 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:49 --> Total execution time: 0.0875
DEBUG - 2022-10-05 00:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:48:56 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:18:56 --> Total execution time: 0.1299
DEBUG - 2022-10-05 00:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:51:20 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:20 --> Total execution time: 0.0821
DEBUG - 2022-10-05 00:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:24 --> Total execution time: 0.0932
DEBUG - 2022-10-05 00:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:40 --> Total execution time: 0.1346
DEBUG - 2022-10-05 00:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:53 --> Total execution time: 0.1317
DEBUG - 2022-10-05 00:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:22:35 --> Total execution time: 0.1327
DEBUG - 2022-10-05 00:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:22:56 --> Total execution time: 0.1402
DEBUG - 2022-10-05 00:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:23:07 --> Total execution time: 0.1653
DEBUG - 2022-10-05 00:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:53:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:23:28 --> Total execution time: 0.0940
DEBUG - 2022-10-05 00:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:53:50 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:23:51 --> Total execution time: 0.0808
DEBUG - 2022-10-05 00:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:12 --> Total execution time: 0.0825
DEBUG - 2022-10-05 00:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:24 --> Total execution time: 0.1643
DEBUG - 2022-10-05 00:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:29 --> Total execution time: 0.1459
DEBUG - 2022-10-05 00:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:40 --> Total execution time: 0.1349
DEBUG - 2022-10-05 00:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:44 --> Total execution time: 0.1422
DEBUG - 2022-10-05 00:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:45 --> Total execution time: 0.3431
DEBUG - 2022-10-05 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:46 --> Total execution time: 0.1350
DEBUG - 2022-10-05 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:47 --> Total execution time: 0.1318
DEBUG - 2022-10-05 00:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:50 --> Total execution time: 0.1532
DEBUG - 2022-10-05 00:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:54 --> Total execution time: 0.0805
DEBUG - 2022-10-05 00:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:57 --> Total execution time: 0.1355
DEBUG - 2022-10-05 00:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:54:57 --> Total execution time: 0.1366
DEBUG - 2022-10-05 00:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:12 --> Total execution time: 0.1346
DEBUG - 2022-10-05 00:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:12 --> Total execution time: 0.1286
DEBUG - 2022-10-05 00:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:13 --> Total execution time: 0.1430
DEBUG - 2022-10-05 00:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:17 --> Total execution time: 0.1485
DEBUG - 2022-10-05 00:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:20 --> Total execution time: 0.2882
DEBUG - 2022-10-05 00:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:21 --> Total execution time: 0.1360
DEBUG - 2022-10-05 00:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:22 --> Total execution time: 0.1254
DEBUG - 2022-10-05 00:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:55:31 --> Total execution time: 0.1223
DEBUG - 2022-10-05 00:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:55:33 --> Total execution time: 0.1614
DEBUG - 2022-10-05 00:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 00:55:33 --> Total execution time: 0.1289
DEBUG - 2022-10-05 00:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:55:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 00:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:25:36 --> Total execution time: 0.1463
DEBUG - 2022-10-05 00:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:27:30 --> Total execution time: 0.1384
DEBUG - 2022-10-05 00:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:27:33 --> Total execution time: 0.1417
DEBUG - 2022-10-05 00:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 00:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 00:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:27:40 --> Total execution time: 0.1300
DEBUG - 2022-10-05 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:30:02 --> Total execution time: 0.1790
DEBUG - 2022-10-05 01:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:32:44 --> Total execution time: 0.0956
DEBUG - 2022-10-05 01:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:32:55 --> Total execution time: 0.1417
DEBUG - 2022-10-05 01:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:33:28 --> Total execution time: 0.1493
DEBUG - 2022-10-05 01:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:33:50 --> Total execution time: 0.1500
DEBUG - 2022-10-05 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:34:00 --> Total execution time: 0.1383
DEBUG - 2022-10-05 01:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:36:20 --> Total execution time: 0.1350
DEBUG - 2022-10-05 01:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:36:34 --> Total execution time: 0.1558
DEBUG - 2022-10-05 01:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:36:42 --> Total execution time: 0.1326
DEBUG - 2022-10-05 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:36:57 --> Total execution time: 0.1424
DEBUG - 2022-10-05 01:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:37:13 --> Total execution time: 0.2060
DEBUG - 2022-10-05 01:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:07:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:37:28 --> Total execution time: 0.0946
DEBUG - 2022-10-05 01:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:37:45 --> Total execution time: 0.1365
DEBUG - 2022-10-05 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:37:53 --> Total execution time: 0.1325
DEBUG - 2022-10-05 01:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:38:10 --> Total execution time: 0.1254
DEBUG - 2022-10-05 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:38:15 --> Total execution time: 0.1252
DEBUG - 2022-10-05 01:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:38:23 --> Total execution time: 0.1263
DEBUG - 2022-10-05 01:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:38:26 --> Total execution time: 0.1239
DEBUG - 2022-10-05 01:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:39:51 --> Total execution time: 0.0786
DEBUG - 2022-10-05 01:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:39:57 --> Total execution time: 0.1380
DEBUG - 2022-10-05 01:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:40:01 --> Total execution time: 0.2323
DEBUG - 2022-10-05 01:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:40:06 --> Total execution time: 0.1487
DEBUG - 2022-10-05 01:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:40:08 --> Total execution time: 0.1248
DEBUG - 2022-10-05 01:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:40:13 --> Total execution time: 0.1434
DEBUG - 2022-10-05 01:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:41:30 --> Total execution time: 0.1303
DEBUG - 2022-10-05 01:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:41:52 --> Total execution time: 0.1282
DEBUG - 2022-10-05 01:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:11:53 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:41:53 --> Total execution time: 0.1330
DEBUG - 2022-10-05 01:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:02 --> Total execution time: 0.1320
DEBUG - 2022-10-05 01:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:03 --> Total execution time: 0.1427
DEBUG - 2022-10-05 01:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:06 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:06 --> Total execution time: 0.3679
DEBUG - 2022-10-05 01:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:07 --> Total execution time: 0.1266
DEBUG - 2022-10-05 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:09 --> Total execution time: 0.1301
DEBUG - 2022-10-05 01:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:14 --> Total execution time: 0.1748
DEBUG - 2022-10-05 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:53 --> Total execution time: 0.1281
DEBUG - 2022-10-05 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:42:56 --> Total execution time: 0.1378
DEBUG - 2022-10-05 01:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:43:39 --> Total execution time: 0.1663
DEBUG - 2022-10-05 01:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:43:45 --> Total execution time: 0.3024
DEBUG - 2022-10-05 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:44:47 --> Total execution time: 0.1299
DEBUG - 2022-10-05 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:44:56 --> Total execution time: 0.1347
DEBUG - 2022-10-05 01:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:10 --> Total execution time: 0.1500
DEBUG - 2022-10-05 01:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:22 --> Total execution time: 0.1306
DEBUG - 2022-10-05 01:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:30 --> Total execution time: 0.1323
DEBUG - 2022-10-05 01:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:31 --> Total execution time: 0.1376
DEBUG - 2022-10-05 01:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:37 --> Total execution time: 0.1432
DEBUG - 2022-10-05 01:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:44 --> Total execution time: 0.0937
DEBUG - 2022-10-05 01:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:46 --> Total execution time: 0.3624
DEBUG - 2022-10-05 01:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:47 --> Total execution time: 0.1323
DEBUG - 2022-10-05 01:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:50 --> Total execution time: 0.1280
DEBUG - 2022-10-05 01:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:54 --> Total execution time: 0.1349
DEBUG - 2022-10-05 01:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:45:55 --> Total execution time: 0.1334
DEBUG - 2022-10-05 01:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:01 --> Total execution time: 0.1300
DEBUG - 2022-10-05 01:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:03 --> Total execution time: 0.1509
DEBUG - 2022-10-05 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:09 --> Total execution time: 0.1392
DEBUG - 2022-10-05 01:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:13 --> Total execution time: 0.1389
DEBUG - 2022-10-05 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:16:29 --> Total execution time: 0.1281
DEBUG - 2022-10-05 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:16:32 --> Total execution time: 0.1298
DEBUG - 2022-10-05 01:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:16:33 --> Total execution time: 0.1313
DEBUG - 2022-10-05 01:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:43 --> Total execution time: 0.1334
DEBUG - 2022-10-05 01:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:59 --> Total execution time: 0.1689
DEBUG - 2022-10-05 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:47:39 --> Total execution time: 0.9644
DEBUG - 2022-10-05 01:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:47:41 --> Total execution time: 0.8985
DEBUG - 2022-10-05 01:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:47:49 --> Total execution time: 0.1418
DEBUG - 2022-10-05 01:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:48:03 --> Total execution time: 2.5995
DEBUG - 2022-10-05 01:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 01:18:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 01:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:48:41 --> Total execution time: 1.1896
DEBUG - 2022-10-05 11:48:41 --> Total execution time: 1.1979
DEBUG - 2022-10-05 01:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:48:42 --> Total execution time: 1.8930
DEBUG - 2022-10-05 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:48:44 --> Total execution time: 1.1406
DEBUG - 2022-10-05 01:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:48:50 --> Total execution time: 0.1388
DEBUG - 2022-10-05 01:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:49:05 --> Total execution time: 0.4532
DEBUG - 2022-10-05 01:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:49:47 --> Total execution time: 0.2279
DEBUG - 2022-10-05 01:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:49:55 --> Total execution time: 0.1695
DEBUG - 2022-10-05 01:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:17 --> Total execution time: 0.1389
DEBUG - 2022-10-05 01:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:34 --> Total execution time: 0.1426
DEBUG - 2022-10-05 01:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:48 --> Total execution time: 0.3605
DEBUG - 2022-10-05 01:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:49 --> Total execution time: 0.1277
DEBUG - 2022-10-05 01:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:53 --> Total execution time: 0.1740
DEBUG - 2022-10-05 01:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:54 --> Total execution time: 0.1328
DEBUG - 2022-10-05 01:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:55 --> Total execution time: 0.1286
DEBUG - 2022-10-05 01:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:51:08 --> Total execution time: 0.1790
DEBUG - 2022-10-05 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:51:10 --> Total execution time: 0.1279
DEBUG - 2022-10-05 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:51:13 --> Total execution time: 0.1427
DEBUG - 2022-10-05 01:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:51:17 --> Total execution time: 0.1624
DEBUG - 2022-10-05 01:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:21:50 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:51:50 --> Total execution time: 0.0909
DEBUG - 2022-10-05 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:52:16 --> Total execution time: 0.1813
DEBUG - 2022-10-05 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:25:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:55:28 --> Total execution time: 0.1804
DEBUG - 2022-10-05 01:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:55:43 --> Total execution time: 0.1035
DEBUG - 2022-10-05 01:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:55:54 --> Total execution time: 0.1359
DEBUG - 2022-10-05 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:56:00 --> Total execution time: 0.1580
DEBUG - 2022-10-05 01:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:56:04 --> Total execution time: 0.1572
DEBUG - 2022-10-05 01:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:56:15 --> Total execution time: 0.1482
DEBUG - 2022-10-05 01:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:56:18 --> Total execution time: 0.1344
DEBUG - 2022-10-05 01:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:57:09 --> Total execution time: 0.1419
DEBUG - 2022-10-05 01:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:57:37 --> Total execution time: 0.1449
DEBUG - 2022-10-05 01:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:57:43 --> Total execution time: 0.1591
DEBUG - 2022-10-05 01:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:57:52 --> Total execution time: 0.1543
DEBUG - 2022-10-05 01:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:58:01 --> Total execution time: 0.1718
DEBUG - 2022-10-05 01:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:58:15 --> Total execution time: 0.1368
DEBUG - 2022-10-05 01:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:58:19 --> Total execution time: 0.1465
DEBUG - 2022-10-05 01:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:58:23 --> Total execution time: 0.1634
DEBUG - 2022-10-05 01:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:58:35 --> Total execution time: 0.1527
DEBUG - 2022-10-05 01:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:01:38 --> Total execution time: 0.3554
DEBUG - 2022-10-05 01:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:01:51 --> Total execution time: 0.1637
DEBUG - 2022-10-05 01:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:02:37 --> Total execution time: 0.1593
DEBUG - 2022-10-05 01:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:02:43 --> Total execution time: 0.1696
DEBUG - 2022-10-05 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:02:52 --> Total execution time: 0.1774
DEBUG - 2022-10-05 01:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:03:19 --> Total execution time: 0.1447
DEBUG - 2022-10-05 01:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:03:20 --> Total execution time: 0.1797
DEBUG - 2022-10-05 01:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:03 --> Total execution time: 0.1629
DEBUG - 2022-10-05 01:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:17 --> Total execution time: 0.1674
DEBUG - 2022-10-05 01:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:20 --> Total execution time: 0.1908
DEBUG - 2022-10-05 01:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:27 --> Total execution time: 0.1649
DEBUG - 2022-10-05 01:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:31 --> Total execution time: 0.1397
DEBUG - 2022-10-05 01:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:37 --> Total execution time: 0.1335
DEBUG - 2022-10-05 01:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:44 --> Total execution time: 0.1560
DEBUG - 2022-10-05 01:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:52 --> Total execution time: 0.1394
DEBUG - 2022-10-05 01:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:55 --> Total execution time: 0.1490
DEBUG - 2022-10-05 01:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:02 --> Total execution time: 0.1951
DEBUG - 2022-10-05 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:38 --> Total execution time: 0.1354
DEBUG - 2022-10-05 01:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:43 --> Total execution time: 0.1687
DEBUG - 2022-10-05 01:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:53 --> Total execution time: 0.1361
DEBUG - 2022-10-05 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:57 --> Total execution time: 0.1344
DEBUG - 2022-10-05 01:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:05 --> Total execution time: 0.1389
DEBUG - 2022-10-05 01:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:08 --> Total execution time: 0.1461
DEBUG - 2022-10-05 01:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:08 --> Total execution time: 0.0819
DEBUG - 2022-10-05 01:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:19 --> Total execution time: 0.1307
DEBUG - 2022-10-05 01:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:25 --> Total execution time: 0.0822
DEBUG - 2022-10-05 01:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:31 --> Total execution time: 0.1279
DEBUG - 2022-10-05 01:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:33 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:33 --> Total execution time: 0.0806
DEBUG - 2022-10-05 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:41 --> Total execution time: 0.1375
DEBUG - 2022-10-05 01:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:07:21 --> Total execution time: 0.4088
DEBUG - 2022-10-05 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:07:46 --> Total execution time: 0.1975
DEBUG - 2022-10-05 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:08:27 --> Total execution time: 0.1707
DEBUG - 2022-10-05 01:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:01 --> Total execution time: 0.5003
DEBUG - 2022-10-05 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:07 --> Total execution time: 0.1549
DEBUG - 2022-10-05 01:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:08 --> Total execution time: 0.1324
DEBUG - 2022-10-05 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:13 --> Total execution time: 0.1637
DEBUG - 2022-10-05 01:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:14 --> Total execution time: 0.1380
DEBUG - 2022-10-05 01:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:24 --> Total execution time: 0.1362
DEBUG - 2022-10-05 01:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:29 --> Total execution time: 0.1575
DEBUG - 2022-10-05 01:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:36 --> Total execution time: 0.1336
DEBUG - 2022-10-05 01:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:43 --> Total execution time: 0.1434
DEBUG - 2022-10-05 01:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:49 --> Total execution time: 0.1638
DEBUG - 2022-10-05 01:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:09:55 --> Total execution time: 0.1683
DEBUG - 2022-10-05 01:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:10:00 --> Total execution time: 0.1974
DEBUG - 2022-10-05 01:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:40:20 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:10:20 --> Total execution time: 0.1566
DEBUG - 2022-10-05 01:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:40:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:10:22 --> Total execution time: 0.1631
DEBUG - 2022-10-05 01:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:10:24 --> Total execution time: 0.3592
DEBUG - 2022-10-05 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:10:52 --> Total execution time: 0.0941
DEBUG - 2022-10-05 01:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:44:41 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:14:42 --> Total execution time: 0.1625
DEBUG - 2022-10-05 01:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:15:47 --> Total execution time: 0.3946
DEBUG - 2022-10-05 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:15:48 --> Total execution time: 0.1455
DEBUG - 2022-10-05 01:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:45:51 --> Total execution time: 0.1385
DEBUG - 2022-10-05 01:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:15:53 --> Total execution time: 0.1573
DEBUG - 2022-10-05 01:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:15:53 --> Total execution time: 0.1272
DEBUG - 2022-10-05 01:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:02 --> Total execution time: 0.1315
DEBUG - 2022-10-05 01:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:17 --> Total execution time: 0.1673
DEBUG - 2022-10-05 01:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:16:18 --> Total execution time: 0.1439
DEBUG - 2022-10-05 01:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:18 --> Total execution time: 0.2349
DEBUG - 2022-10-05 01:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:19 --> Total execution time: 0.1354
DEBUG - 2022-10-05 01:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:19 --> Total execution time: 0.1570
DEBUG - 2022-10-05 01:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:20 --> Total execution time: 0.1309
DEBUG - 2022-10-05 01:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:20 --> Total execution time: 0.1645
DEBUG - 2022-10-05 01:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:47 --> Total execution time: 0.1329
DEBUG - 2022-10-05 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:16:57 --> Total execution time: 0.1639
DEBUG - 2022-10-05 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:47:53 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:17:53 --> Total execution time: 0.1098
DEBUG - 2022-10-05 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:11 --> Total execution time: 0.1695
DEBUG - 2022-10-05 01:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:18 --> Total execution time: 0.1297
DEBUG - 2022-10-05 01:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:20 --> Total execution time: 0.1272
DEBUG - 2022-10-05 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:53 --> Total execution time: 0.3486
DEBUG - 2022-10-05 01:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:19:01 --> Total execution time: 0.1426
DEBUG - 2022-10-05 01:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:19:19 --> Total execution time: 0.1672
DEBUG - 2022-10-05 01:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:19:19 --> Total execution time: 0.1337
DEBUG - 2022-10-05 01:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:19:31 --> Total execution time: 0.1291
DEBUG - 2022-10-05 01:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:50:00 --> Total execution time: 0.1000
DEBUG - 2022-10-05 01:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:03 --> Total execution time: 0.1453
DEBUG - 2022-10-05 01:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:06 --> Total execution time: 0.1750
DEBUG - 2022-10-05 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:08 --> Total execution time: 0.1635
DEBUG - 2022-10-05 01:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:10 --> Total execution time: 0.1687
DEBUG - 2022-10-05 01:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:14 --> Total execution time: 0.1694
DEBUG - 2022-10-05 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:22 --> Total execution time: 0.1272
DEBUG - 2022-10-05 01:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:23 --> Total execution time: 0.1211
DEBUG - 2022-10-05 01:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:26 --> Total execution time: 0.1652
DEBUG - 2022-10-05 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:28 --> Total execution time: 0.2243
DEBUG - 2022-10-05 01:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:18 --> Total execution time: 0.1611
DEBUG - 2022-10-05 01:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:21 --> Total execution time: 0.1461
DEBUG - 2022-10-05 01:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:22 --> Total execution time: 0.1630
DEBUG - 2022-10-05 01:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:22 --> Total execution time: 0.3235
DEBUG - 2022-10-05 01:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:23 --> Total execution time: 0.1537
DEBUG - 2022-10-05 01:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:23 --> Total execution time: 0.3915
DEBUG - 2022-10-05 01:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:24 --> Total execution time: 0.1730
DEBUG - 2022-10-05 01:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:24 --> Total execution time: 0.1606
DEBUG - 2022-10-05 01:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:21:30 --> Total execution time: 0.1946
DEBUG - 2022-10-05 01:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:22:04 --> Total execution time: 0.2027
DEBUG - 2022-10-05 01:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:22:18 --> Total execution time: 0.1325
DEBUG - 2022-10-05 01:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:52:55 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:22:55 --> Total execution time: 0.0897
DEBUG - 2022-10-05 01:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:23:22 --> Total execution time: 0.1420
DEBUG - 2022-10-05 01:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:54:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:24:27 --> Total execution time: 0.0828
DEBUG - 2022-10-05 01:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:54:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 01:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:24:27 --> Total execution time: 0.1176
DEBUG - 2022-10-05 01:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:55:30 --> Total execution time: 0.1390
DEBUG - 2022-10-05 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:25:40 --> Total execution time: 0.3420
DEBUG - 2022-10-05 01:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:25:52 --> Total execution time: 0.1936
DEBUG - 2022-10-05 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:25:58 --> Total execution time: 0.1516
DEBUG - 2022-10-05 01:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:26 --> Total execution time: 0.1354
DEBUG - 2022-10-05 01:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:28 --> Total execution time: 0.3978
DEBUG - 2022-10-05 01:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:30 --> Total execution time: 0.1671
DEBUG - 2022-10-05 01:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:32 --> Total execution time: 0.1705
DEBUG - 2022-10-05 01:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:33 --> Total execution time: 0.1738
DEBUG - 2022-10-05 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:34 --> Total execution time: 0.1705
DEBUG - 2022-10-05 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:39 --> Total execution time: 0.1565
DEBUG - 2022-10-05 01:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:40 --> Total execution time: 0.1682
DEBUG - 2022-10-05 01:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:26:49 --> Total execution time: 0.2061
DEBUG - 2022-10-05 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:18 --> Total execution time: 0.1555
DEBUG - 2022-10-05 01:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:20 --> Total execution time: 0.4185
DEBUG - 2022-10-05 01:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:20 --> Total execution time: 0.1489
DEBUG - 2022-10-05 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:26 --> Total execution time: 0.1272
DEBUG - 2022-10-05 01:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:43 --> Total execution time: 0.1263
DEBUG - 2022-10-05 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:47 --> Total execution time: 0.1664
DEBUG - 2022-10-05 01:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:49 --> Total execution time: 0.1709
DEBUG - 2022-10-05 01:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:53 --> Total execution time: 0.1985
DEBUG - 2022-10-05 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:54 --> Total execution time: 0.1900
DEBUG - 2022-10-05 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:54 --> Total execution time: 0.3565
DEBUG - 2022-10-05 01:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:27:55 --> Total execution time: 0.1948
DEBUG - 2022-10-05 01:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:02 --> Total execution time: 0.2188
DEBUG - 2022-10-05 01:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:02 --> Total execution time: 0.1618
DEBUG - 2022-10-05 01:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:11 --> Total execution time: 0.1660
DEBUG - 2022-10-05 01:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:16 --> Total execution time: 0.1344
DEBUG - 2022-10-05 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:18 --> Total execution time: 0.1304
DEBUG - 2022-10-05 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:19 --> Total execution time: 0.1250
DEBUG - 2022-10-05 01:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:20 --> Total execution time: 0.1478
DEBUG - 2022-10-05 01:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:21 --> Total execution time: 0.1447
DEBUG - 2022-10-05 01:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:23 --> Total execution time: 0.2870
DEBUG - 2022-10-05 01:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:25 --> Total execution time: 0.1542
DEBUG - 2022-10-05 01:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:27 --> Total execution time: 0.1631
DEBUG - 2022-10-05 01:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:30 --> Total execution time: 0.1624
DEBUG - 2022-10-05 01:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:30 --> Total execution time: 0.1268
DEBUG - 2022-10-05 01:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:58:34 --> Total execution time: 0.1206
DEBUG - 2022-10-05 01:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:35 --> Total execution time: 0.1902
DEBUG - 2022-10-05 01:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:28:36 --> Total execution time: 0.1710
DEBUG - 2022-10-05 01:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:29:26 --> Total execution time: 0.0879
DEBUG - 2022-10-05 01:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:29:31 --> Total execution time: 0.1303
DEBUG - 2022-10-05 01:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:29:33 --> Total execution time: 0.1209
DEBUG - 2022-10-05 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:29:37 --> Total execution time: 0.1193
DEBUG - 2022-10-05 01:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:29:41 --> Total execution time: 0.1408
DEBUG - 2022-10-05 01:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 01:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 01:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 01:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:29:56 --> Total execution time: 0.1237
DEBUG - 2022-10-05 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:02 --> Total execution time: 0.2866
DEBUG - 2022-10-05 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:03 --> Total execution time: 0.1762
DEBUG - 2022-10-05 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:05 --> Total execution time: 0.1749
DEBUG - 2022-10-05 02:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:19 --> Total execution time: 0.1625
DEBUG - 2022-10-05 02:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:27 --> Total execution time: 0.1405
DEBUG - 2022-10-05 02:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:40 --> Total execution time: 0.1364
DEBUG - 2022-10-05 02:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:41 --> Total execution time: 0.1681
DEBUG - 2022-10-05 02:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:43 --> Total execution time: 0.3624
DEBUG - 2022-10-05 02:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:46 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:46 --> Total execution time: 0.0803
DEBUG - 2022-10-05 02:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:52 --> Total execution time: 0.1347
DEBUG - 2022-10-05 02:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:08 --> Total execution time: 0.1638
DEBUG - 2022-10-05 02:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:23 --> Total execution time: 0.1544
DEBUG - 2022-10-05 02:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:27 --> Total execution time: 0.1449
DEBUG - 2022-10-05 02:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:39 --> Total execution time: 0.2176
DEBUG - 2022-10-05 02:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:40 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:40 --> Total execution time: 0.0777
DEBUG - 2022-10-05 02:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:51 --> Total execution time: 0.0771
DEBUG - 2022-10-05 02:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:31:52 --> Total execution time: 0.1283
DEBUG - 2022-10-05 02:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:32:05 --> Total execution time: 0.1406
DEBUG - 2022-10-05 02:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:32:17 --> Total execution time: 0.1383
DEBUG - 2022-10-05 02:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:32:53 --> Total execution time: 0.1587
DEBUG - 2022-10-05 02:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:33:06 --> Total execution time: 0.1427
DEBUG - 2022-10-05 02:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:33:16 --> Total execution time: 0.4125
DEBUG - 2022-10-05 02:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:33:17 --> Total execution time: 0.1460
DEBUG - 2022-10-05 02:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:26 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:33:27 --> Total execution time: 0.0858
DEBUG - 2022-10-05 02:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:03:42 --> Total execution time: 0.1397
DEBUG - 2022-10-05 02:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:03:44 --> Total execution time: 0.1637
DEBUG - 2022-10-05 02:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:03:45 --> Total execution time: 0.1305
DEBUG - 2022-10-05 02:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:33:48 --> Total execution time: 0.1327
DEBUG - 2022-10-05 02:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:42 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:34:42 --> Total execution time: 0.0806
DEBUG - 2022-10-05 02:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:42 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:34:43 --> Total execution time: 0.0823
DEBUG - 2022-10-05 02:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:34:48 --> Total execution time: 0.1077
DEBUG - 2022-10-05 12:34:50 --> Total execution time: 2.2615
DEBUG - 2022-10-05 02:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 02:04:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 02:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:34:57 --> Total execution time: 0.1405
DEBUG - 2022-10-05 02:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:35:06 --> Total execution time: 0.1710
DEBUG - 2022-10-05 02:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:35:13 --> Total execution time: 0.1285
DEBUG - 2022-10-05 02:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:35:18 --> Total execution time: 0.1482
DEBUG - 2022-10-05 02:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:47 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:35:48 --> Total execution time: 0.1353
DEBUG - 2022-10-05 02:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:35:54 --> Total execution time: 0.1394
DEBUG - 2022-10-05 02:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:36:04 --> Total execution time: 0.1979
DEBUG - 2022-10-05 02:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:36:11 --> Total execution time: 0.1345
DEBUG - 2022-10-05 02:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:06:19 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:36:19 --> Total execution time: 0.1004
DEBUG - 2022-10-05 02:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:37:29 --> Total execution time: 0.0934
DEBUG - 2022-10-05 02:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:09:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:39:30 --> Total execution time: 0.1115
DEBUG - 2022-10-05 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:39:40 --> Total execution time: 0.0813
DEBUG - 2022-10-05 02:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:39:59 --> Total execution time: 0.1359
DEBUG - 2022-10-05 02:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:40:10 --> Total execution time: 0.4654
DEBUG - 2022-10-05 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:40:23 --> Total execution time: 0.0804
DEBUG - 2022-10-05 02:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:40:56 --> Total execution time: 0.3449
DEBUG - 2022-10-05 02:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:06 --> Total execution time: 0.1360
DEBUG - 2022-10-05 02:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:32 --> Total execution time: 0.1378
DEBUG - 2022-10-05 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:36 --> Total execution time: 0.1364
DEBUG - 2022-10-05 02:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:42 --> Total execution time: 0.1723
DEBUG - 2022-10-05 02:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:42 --> Total execution time: 0.1791
DEBUG - 2022-10-05 02:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:43 --> Total execution time: 0.1827
DEBUG - 2022-10-05 02:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:43 --> Total execution time: 0.2886
DEBUG - 2022-10-05 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:42:50 --> Total execution time: 0.1831
DEBUG - 2022-10-05 02:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:15:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:45:11 --> Total execution time: 0.1809
DEBUG - 2022-10-05 02:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:15:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:45:13 --> Total execution time: 0.0901
DEBUG - 2022-10-05 02:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:45:52 --> Total execution time: 0.1019
DEBUG - 2022-10-05 02:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:46:01 --> Total execution time: 0.1712
DEBUG - 2022-10-05 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:46:13 --> Total execution time: 0.1739
DEBUG - 2022-10-05 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:16:20 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:46:20 --> Total execution time: 0.1003
DEBUG - 2022-10-05 02:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:46:39 --> Total execution time: 0.1361
DEBUG - 2022-10-05 02:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:46:45 --> Total execution time: 0.1428
DEBUG - 2022-10-05 02:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:47:09 --> Total execution time: 0.1686
DEBUG - 2022-10-05 02:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:47:26 --> Total execution time: 0.0983
DEBUG - 2022-10-05 02:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:48:33 --> Total execution time: 0.3628
DEBUG - 2022-10-05 02:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:50:43 --> Total execution time: 0.1390
DEBUG - 2022-10-05 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:20:44 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:50:44 --> Total execution time: 0.0911
DEBUG - 2022-10-05 02:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:50:51 --> Total execution time: 0.1566
DEBUG - 2022-10-05 02:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:04 --> Total execution time: 0.1800
DEBUG - 2022-10-05 02:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:22 --> Total execution time: 0.0809
DEBUG - 2022-10-05 02:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:24 --> Total execution time: 0.1260
DEBUG - 2022-10-05 02:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:33 --> Total execution time: 0.0824
DEBUG - 2022-10-05 02:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:21:37 --> Total execution time: 0.1279
DEBUG - 2022-10-05 02:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:38 --> Total execution time: 0.1292
DEBUG - 2022-10-05 02:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:21:39 --> Total execution time: 0.1307
DEBUG - 2022-10-05 02:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:21:40 --> Total execution time: 0.1362
DEBUG - 2022-10-05 02:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:51 --> Total execution time: 0.1362
DEBUG - 2022-10-05 02:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:52:30 --> Total execution time: 0.3408
DEBUG - 2022-10-05 02:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:52:38 --> Total execution time: 0.1604
DEBUG - 2022-10-05 02:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:22:49 --> Total execution time: 0.1378
DEBUG - 2022-10-05 02:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:22:52 --> Total execution time: 0.1736
DEBUG - 2022-10-05 02:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:22:52 --> Total execution time: 0.1526
DEBUG - 2022-10-05 02:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:02 --> Total execution time: 0.1392
DEBUG - 2022-10-05 02:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:23:04 --> Total execution time: 0.0815
DEBUG - 2022-10-05 02:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:05 --> Total execution time: 0.0752
DEBUG - 2022-10-05 02:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:09 --> Total execution time: 0.1422
DEBUG - 2022-10-05 02:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:15 --> Total execution time: 0.1411
DEBUG - 2022-10-05 02:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:19 --> Total execution time: 0.1471
DEBUG - 2022-10-05 02:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:24 --> Total execution time: 0.1588
DEBUG - 2022-10-05 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:34 --> Total execution time: 0.1359
DEBUG - 2022-10-05 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:53:48 --> Total execution time: 0.1299
DEBUG - 2022-10-05 02:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:10 --> Total execution time: 0.1354
DEBUG - 2022-10-05 02:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:12 --> Total execution time: 0.1663
DEBUG - 2022-10-05 02:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:13 --> Total execution time: 0.1368
DEBUG - 2022-10-05 02:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:55:16 --> Total execution time: 0.1268
DEBUG - 2022-10-05 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:17 --> Total execution time: 0.1216
DEBUG - 2022-10-05 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:18 --> Total execution time: 0.1365
DEBUG - 2022-10-05 02:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:55:29 --> Total execution time: 0.1436
DEBUG - 2022-10-05 02:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:55:36 --> Total execution time: 0.1523
DEBUG - 2022-10-05 02:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:55:51 --> Total execution time: 0.1337
DEBUG - 2022-10-05 02:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:55:52 --> Total execution time: 0.1304
DEBUG - 2022-10-05 02:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:56:11 --> Total execution time: 0.1685
DEBUG - 2022-10-05 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:56:18 --> Total execution time: 0.1302
DEBUG - 2022-10-05 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:56:38 --> Total execution time: 0.1329
DEBUG - 2022-10-05 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:56:43 --> Total execution time: 0.1271
DEBUG - 2022-10-05 02:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:56:51 --> Total execution time: 0.1346
DEBUG - 2022-10-05 02:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:56:58 --> Total execution time: 0.3341
DEBUG - 2022-10-05 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:27:18 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:57:18 --> Total execution time: 0.1156
DEBUG - 2022-10-05 02:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:58:05 --> Total execution time: 0.3482
DEBUG - 2022-10-05 02:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:02:30 --> Total execution time: 0.6025
DEBUG - 2022-10-05 02:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:02:42 --> Total execution time: 0.1406
DEBUG - 2022-10-05 02:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:02:50 --> Total execution time: 0.1691
DEBUG - 2022-10-05 02:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:02:59 --> Total execution time: 0.1491
DEBUG - 2022-10-05 02:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:03:08 --> Total execution time: 0.1257
DEBUG - 2022-10-05 02:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:34:52 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:04:52 --> Total execution time: 0.1083
DEBUG - 2022-10-05 02:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:06:37 --> Total execution time: 0.1378
DEBUG - 2022-10-05 02:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:37:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:07:59 --> Total execution time: 0.1060
DEBUG - 2022-10-05 02:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:11 --> Total execution time: 0.0893
DEBUG - 2022-10-05 02:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:23 --> Total execution time: 0.1471
DEBUG - 2022-10-05 02:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:26 --> Total execution time: 0.3956
DEBUG - 2022-10-05 02:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:33 --> Total execution time: 0.1644
DEBUG - 2022-10-05 02:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:33 --> Total execution time: 0.1767
DEBUG - 2022-10-05 02:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:38 --> Total execution time: 0.1731
DEBUG - 2022-10-05 02:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:08:52 --> Total execution time: 0.1381
DEBUG - 2022-10-05 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:39:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:09:21 --> Total execution time: 0.0902
DEBUG - 2022-10-05 02:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:09:29 --> Total execution time: 0.1250
DEBUG - 2022-10-05 02:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:09:38 --> Total execution time: 0.1323
DEBUG - 2022-10-05 02:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:09:48 --> Total execution time: 0.1595
DEBUG - 2022-10-05 02:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:12:01 --> Total execution time: 0.2605
DEBUG - 2022-10-05 02:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:13:40 --> Total execution time: 0.0812
DEBUG - 2022-10-05 02:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:14:27 --> Total execution time: 0.1329
DEBUG - 2022-10-05 02:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:14:47 --> Total execution time: 0.1370
DEBUG - 2022-10-05 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:14:50 --> Total execution time: 0.1335
DEBUG - 2022-10-05 02:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:15:56 --> Total execution time: 0.1389
DEBUG - 2022-10-05 02:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:16:00 --> Total execution time: 0.1329
DEBUG - 2022-10-05 02:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:16:01 --> Total execution time: 0.1551
DEBUG - 2022-10-05 02:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:47:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:17:03 --> Total execution time: 0.0853
DEBUG - 2022-10-05 02:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:17:04 --> Total execution time: 0.1409
DEBUG - 2022-10-05 02:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:49:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:19:04 --> Total execution time: 0.1125
DEBUG - 2022-10-05 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:19:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 02:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:19:10 --> Total execution time: 0.1469
DEBUG - 2022-10-05 02:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:19:43 --> Total execution time: 0.1517
DEBUG - 2022-10-05 02:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:20:21 --> Total execution time: 0.1294
DEBUG - 2022-10-05 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:20:25 --> Total execution time: 0.0937
DEBUG - 2022-10-05 02:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:20:44 --> Total execution time: 0.1473
DEBUG - 2022-10-05 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:20:49 --> Total execution time: 0.1525
DEBUG - 2022-10-05 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:50:49 --> Total execution time: 0.1415
DEBUG - 2022-10-05 02:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:20:55 --> Total execution time: 0.1932
DEBUG - 2022-10-05 02:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:04 --> Total execution time: 0.1348
DEBUG - 2022-10-05 02:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:09 --> Total execution time: 0.3470
DEBUG - 2022-10-05 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:33 --> Total execution time: 0.1363
DEBUG - 2022-10-05 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:36 --> Total execution time: 0.1558
DEBUG - 2022-10-05 02:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:38 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:38 --> Total execution time: 0.3431
DEBUG - 2022-10-05 02:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:43 --> Total execution time: 0.1457
DEBUG - 2022-10-05 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:51:56 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:21:56 --> Total execution time: 0.2091
DEBUG - 2022-10-05 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:22:11 --> Total execution time: 0.2482
DEBUG - 2022-10-05 02:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:52:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:22:11 --> Total execution time: 0.1473
DEBUG - 2022-10-05 02:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:22:47 --> Total execution time: 0.3431
DEBUG - 2022-10-05 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:09 --> Total execution time: 0.2491
DEBUG - 2022-10-05 02:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:16 --> Total execution time: 0.0969
DEBUG - 2022-10-05 02:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:18 --> Total execution time: 0.1431
DEBUG - 2022-10-05 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:21 --> Total execution time: 0.1001
DEBUG - 2022-10-05 02:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:28 --> Total execution time: 0.1837
DEBUG - 2022-10-05 02:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:37 --> Total execution time: 0.1354
DEBUG - 2022-10-05 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:42 --> Total execution time: 0.1357
DEBUG - 2022-10-05 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:42 --> Total execution time: 0.1359
DEBUG - 2022-10-05 02:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:46 --> Total execution time: 0.1498
DEBUG - 2022-10-05 02:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:25:56 --> Total execution time: 0.1539
DEBUG - 2022-10-05 02:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:02 --> Total execution time: 0.1398
DEBUG - 2022-10-05 02:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:03 --> Total execution time: 0.1365
DEBUG - 2022-10-05 02:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:08 --> Total execution time: 0.0860
DEBUG - 2022-10-05 02:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:10 --> Total execution time: 0.1341
DEBUG - 2022-10-05 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:20 --> Total execution time: 0.1792
DEBUG - 2022-10-05 02:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:56:27 --> Total execution time: 0.1373
DEBUG - 2022-10-05 02:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:56:34 --> Total execution time: 0.1893
DEBUG - 2022-10-05 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:50 --> Total execution time: 0.1617
DEBUG - 2022-10-05 02:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:27:00 --> Total execution time: 0.1397
DEBUG - 2022-10-05 02:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:27:22 --> Total execution time: 0.2239
DEBUG - 2022-10-05 02:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:06 --> Total execution time: 0.1882
DEBUG - 2022-10-05 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:14 --> Total execution time: 0.1371
DEBUG - 2022-10-05 02:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:29 --> Total execution time: 0.1426
DEBUG - 2022-10-05 02:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:36 --> Total execution time: 0.1206
DEBUG - 2022-10-05 02:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:43 --> Total execution time: 0.1241
DEBUG - 2022-10-05 02:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:45 --> Total execution time: 0.1620
DEBUG - 2022-10-05 02:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:28:56 --> Total execution time: 0.1355
DEBUG - 2022-10-05 02:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:25 --> Total execution time: 0.3920
DEBUG - 2022-10-05 02:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 02:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:33 --> Total execution time: 0.3656
DEBUG - 2022-10-05 02:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:45 --> Total execution time: 0.2056
DEBUG - 2022-10-05 02:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 02:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:57 --> Total execution time: 0.1574
DEBUG - 2022-10-05 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 02:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 02:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:58 --> Total execution time: 0.0798
DEBUG - 2022-10-05 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:30:02 --> Total execution time: 0.1538
DEBUG - 2022-10-05 03:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:30:09 --> Total execution time: 0.2652
DEBUG - 2022-10-05 03:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:30:17 --> Total execution time: 0.1863
DEBUG - 2022-10-05 03:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:30:22 --> Total execution time: 0.1440
DEBUG - 2022-10-05 03:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:01:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:31:22 --> Total execution time: 0.0919
DEBUG - 2022-10-05 03:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:01:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:01:33 --> 404 Page Not Found: Contact/index
DEBUG - 2022-10-05 03:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:32:15 --> Total execution time: 0.3566
DEBUG - 2022-10-05 03:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:32:19 --> Total execution time: 0.1503
DEBUG - 2022-10-05 03:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:02:20 --> Total execution time: 0.1576
DEBUG - 2022-10-05 03:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:32:20 --> Total execution time: 0.1445
DEBUG - 2022-10-05 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:32:22 --> Total execution time: 0.3538
DEBUG - 2022-10-05 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:02:22 --> Total execution time: 0.1481
DEBUG - 2022-10-05 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:02:23 --> Total execution time: 0.1382
DEBUG - 2022-10-05 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:01 --> Total execution time: 0.1775
DEBUG - 2022-10-05 03:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:10 --> Total execution time: 0.1378
DEBUG - 2022-10-05 03:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:21 --> Total execution time: 0.1415
DEBUG - 2022-10-05 03:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:25 --> Total execution time: 0.1358
DEBUG - 2022-10-05 03:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:27 --> Total execution time: 0.1631
DEBUG - 2022-10-05 03:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:28 --> Total execution time: 0.0807
DEBUG - 2022-10-05 03:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:31 --> Total execution time: 0.0836
DEBUG - 2022-10-05 03:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:34:47 --> Total execution time: 0.1602
DEBUG - 2022-10-05 03:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:12 --> Total execution time: 0.1457
DEBUG - 2022-10-05 03:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:23 --> Total execution time: 0.1578
DEBUG - 2022-10-05 03:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:26 --> Total execution time: 0.1516
DEBUG - 2022-10-05 03:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:27 --> Total execution time: 0.1407
DEBUG - 2022-10-05 03:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:33 --> Total execution time: 0.1494
DEBUG - 2022-10-05 03:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:34 --> Total execution time: 0.1449
DEBUG - 2022-10-05 03:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:41 --> Total execution time: 0.1553
DEBUG - 2022-10-05 03:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:35:56 --> Total execution time: 0.1578
DEBUG - 2022-10-05 03:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:36:04 --> Total execution time: 0.1893
DEBUG - 2022-10-05 03:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:36:04 --> Total execution time: 0.1578
DEBUG - 2022-10-05 03:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:36:07 --> Total execution time: 0.1598
DEBUG - 2022-10-05 03:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:36:14 --> Total execution time: 0.1489
DEBUG - 2022-10-05 03:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:36:28 --> Total execution time: 0.1439
DEBUG - 2022-10-05 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:34 --> Total execution time: 0.1405
DEBUG - 2022-10-05 03:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:36 --> Total execution time: 0.1403
DEBUG - 2022-10-05 03:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:47 --> Total execution time: 0.1471
DEBUG - 2022-10-05 03:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:50 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:36:50 --> Total execution time: 0.1222
DEBUG - 2022-10-05 03:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:06:55 --> Total execution time: 0.1317
DEBUG - 2022-10-05 03:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:01 --> Total execution time: 0.1827
DEBUG - 2022-10-05 03:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:18 --> Total execution time: 0.1424
DEBUG - 2022-10-05 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:37:29 --> Total execution time: 0.1310
DEBUG - 2022-10-05 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:43 --> Total execution time: 0.1242
DEBUG - 2022-10-05 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:07:57 --> Total execution time: 0.1274
DEBUG - 2022-10-05 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:38:04 --> Total execution time: 0.0931
DEBUG - 2022-10-05 03:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:08:06 --> Total execution time: 0.1294
DEBUG - 2022-10-05 03:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:39:26 --> Total execution time: 0.4088
DEBUG - 2022-10-05 03:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:39:32 --> Total execution time: 0.1406
DEBUG - 2022-10-05 03:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:39:54 --> Total execution time: 0.1318
DEBUG - 2022-10-05 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:39:56 --> Total execution time: 0.1485
DEBUG - 2022-10-05 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:40:00 --> Total execution time: 0.1326
DEBUG - 2022-10-05 03:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:40:06 --> Total execution time: 0.1550
DEBUG - 2022-10-05 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:41:22 --> Total execution time: 0.0879
DEBUG - 2022-10-05 03:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:42:44 --> Total execution time: 0.0808
DEBUG - 2022-10-05 03:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:42:44 --> Total execution time: 0.0856
DEBUG - 2022-10-05 03:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:42:46 --> Total execution time: 0.1280
DEBUG - 2022-10-05 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:42:53 --> Total execution time: 0.1268
DEBUG - 2022-10-05 03:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:42:55 --> Total execution time: 0.1300
DEBUG - 2022-10-05 03:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:42:57 --> Total execution time: 0.1336
DEBUG - 2022-10-05 03:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:03 --> Total execution time: 0.1254
DEBUG - 2022-10-05 03:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:06 --> Total execution time: 0.1434
DEBUG - 2022-10-05 03:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:11 --> Total execution time: 0.1442
DEBUG - 2022-10-05 03:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:29 --> Total execution time: 0.1265
DEBUG - 2022-10-05 03:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:30 --> Total execution time: 0.0791
DEBUG - 2022-10-05 03:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:43 --> Total execution time: 0.1539
DEBUG - 2022-10-05 03:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:43:54 --> Total execution time: 0.1912
DEBUG - 2022-10-05 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:02 --> Total execution time: 0.0956
DEBUG - 2022-10-05 03:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:09 --> Total execution time: 0.1286
DEBUG - 2022-10-05 03:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:13 --> Total execution time: 0.0957
DEBUG - 2022-10-05 03:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:26 --> Total execution time: 0.1328
DEBUG - 2022-10-05 03:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:32 --> Total execution time: 0.1268
DEBUG - 2022-10-05 03:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:37 --> Total execution time: 0.1417
DEBUG - 2022-10-05 03:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:46 --> Total execution time: 0.1267
DEBUG - 2022-10-05 03:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:51 --> Total execution time: 0.1433
DEBUG - 2022-10-05 03:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:56 --> Total execution time: 0.1268
DEBUG - 2022-10-05 03:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:00 --> Total execution time: 0.2049
DEBUG - 2022-10-05 03:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:05 --> Total execution time: 0.1212
DEBUG - 2022-10-05 03:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:07 --> Total execution time: 0.1387
DEBUG - 2022-10-05 03:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:13 --> Total execution time: 0.1310
DEBUG - 2022-10-05 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:18 --> Total execution time: 0.1420
DEBUG - 2022-10-05 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:19 --> Total execution time: 0.1326
DEBUG - 2022-10-05 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:37 --> Total execution time: 0.1317
DEBUG - 2022-10-05 03:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:37 --> Total execution time: 0.3535
DEBUG - 2022-10-05 03:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:54 --> Total execution time: 0.1367
DEBUG - 2022-10-05 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:55 --> Total execution time: 0.1562
DEBUG - 2022-10-05 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:16:12 --> Total execution time: 0.1725
DEBUG - 2022-10-05 03:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:46:17 --> Total execution time: 0.1255
DEBUG - 2022-10-05 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:46:18 --> Total execution time: 0.1361
DEBUG - 2022-10-05 03:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:16:22 --> Total execution time: 0.1357
DEBUG - 2022-10-05 03:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:16:51 --> Total execution time: 0.1975
DEBUG - 2022-10-05 03:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:47:05 --> Total execution time: 0.0797
DEBUG - 2022-10-05 03:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:47:07 --> Total execution time: 0.1288
DEBUG - 2022-10-05 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:16 --> Total execution time: 0.1561
DEBUG - 2022-10-05 03:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:47:20 --> Total execution time: 0.1357
DEBUG - 2022-10-05 03:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:23 --> Total execution time: 0.1237
DEBUG - 2022-10-05 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:24 --> Total execution time: 0.1352
DEBUG - 2022-10-05 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:25 --> Total execution time: 0.1269
DEBUG - 2022-10-05 03:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:27 --> Total execution time: 0.1244
DEBUG - 2022-10-05 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:50 --> Total execution time: 0.1380
DEBUG - 2022-10-05 03:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:17:53 --> Total execution time: 0.1486
DEBUG - 2022-10-05 03:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:47:55 --> Total execution time: 0.1466
DEBUG - 2022-10-05 03:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:12 --> Total execution time: 0.1370
DEBUG - 2022-10-05 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:18:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 03:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:20 --> Total execution time: 0.1397
DEBUG - 2022-10-05 03:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:23 --> Total execution time: 0.1305
DEBUG - 2022-10-05 03:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:30 --> Total execution time: 0.1314
DEBUG - 2022-10-05 03:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:39 --> Total execution time: 0.1403
DEBUG - 2022-10-05 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:44 --> Total execution time: 0.1348
DEBUG - 2022-10-05 03:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:45 --> Total execution time: 0.1379
DEBUG - 2022-10-05 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:54 --> Total execution time: 0.1731
DEBUG - 2022-10-05 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:18:54 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:48:54 --> Total execution time: 0.1026
DEBUG - 2022-10-05 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:10 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:10 --> Total execution time: 0.1265
DEBUG - 2022-10-05 03:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:22 --> Total execution time: 0.3685
DEBUG - 2022-10-05 03:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:27 --> Total execution time: 0.1373
DEBUG - 2022-10-05 03:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:31 --> Total execution time: 0.1287
DEBUG - 2022-10-05 03:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:35 --> Total execution time: 0.1372
DEBUG - 2022-10-05 03:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:42 --> Total execution time: 0.1605
DEBUG - 2022-10-05 03:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:42 --> Total execution time: 0.1576
DEBUG - 2022-10-05 03:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:49:54 --> Total execution time: 0.1301
DEBUG - 2022-10-05 03:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:50:06 --> Total execution time: 0.1206
DEBUG - 2022-10-05 03:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:50:13 --> Total execution time: 0.1332
DEBUG - 2022-10-05 03:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:50:22 --> Total execution time: 0.1289
DEBUG - 2022-10-05 03:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:50:24 --> Total execution time: 0.1219
DEBUG - 2022-10-05 03:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:18 --> Total execution time: 0.1287
DEBUG - 2022-10-05 03:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:20 --> Total execution time: 0.1579
DEBUG - 2022-10-05 03:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:32 --> Total execution time: 0.1569
DEBUG - 2022-10-05 03:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:55 --> Total execution time: 0.1334
DEBUG - 2022-10-05 03:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:57 --> Total execution time: 0.1305
DEBUG - 2022-10-05 03:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:01 --> Total execution time: 0.1445
DEBUG - 2022-10-05 03:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:04 --> Total execution time: 0.1474
DEBUG - 2022-10-05 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:17 --> Total execution time: 0.1266
DEBUG - 2022-10-05 03:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:28 --> Total execution time: 0.1053
DEBUG - 2022-10-05 03:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:32 --> Total execution time: 0.0774
DEBUG - 2022-10-05 03:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:41 --> Total execution time: 0.1391
DEBUG - 2022-10-05 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:46 --> Total execution time: 0.1332
DEBUG - 2022-10-05 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:49 --> Total execution time: 0.1371
DEBUG - 2022-10-05 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:55 --> Total execution time: 0.1659
DEBUG - 2022-10-05 03:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:59 --> Total execution time: 0.1316
DEBUG - 2022-10-05 03:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:05 --> Total execution time: 0.2044
DEBUG - 2022-10-05 03:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:08 --> Total execution time: 0.1600
DEBUG - 2022-10-05 03:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:08 --> Total execution time: 0.1355
DEBUG - 2022-10-05 03:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:09 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:09 --> Total execution time: 0.1139
DEBUG - 2022-10-05 03:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:13 --> Total execution time: 0.1241
DEBUG - 2022-10-05 03:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:20 --> Total execution time: 0.1300
DEBUG - 2022-10-05 03:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:23 --> Total execution time: 0.1731
DEBUG - 2022-10-05 03:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:28 --> Total execution time: 0.1267
DEBUG - 2022-10-05 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:33 --> Total execution time: 0.1285
DEBUG - 2022-10-05 03:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:41 --> Total execution time: 0.1686
DEBUG - 2022-10-05 03:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:52 --> Total execution time: 0.1506
DEBUG - 2022-10-05 03:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:02 --> Total execution time: 0.3908
DEBUG - 2022-10-05 03:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:06 --> Total execution time: 0.1380
DEBUG - 2022-10-05 03:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:17 --> Total execution time: 0.1793
DEBUG - 2022-10-05 03:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:21 --> Total execution time: 0.1355
DEBUG - 2022-10-05 03:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:21 --> Total execution time: 0.1450
DEBUG - 2022-10-05 03:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:31 --> Total execution time: 0.1370
DEBUG - 2022-10-05 03:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:39 --> Total execution time: 0.1310
DEBUG - 2022-10-05 03:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:45 --> Total execution time: 0.1695
DEBUG - 2022-10-05 03:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:59 --> Total execution time: 0.3514
DEBUG - 2022-10-05 03:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:00 --> Total execution time: 0.1438
DEBUG - 2022-10-05 03:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:00 --> Total execution time: 0.1317
DEBUG - 2022-10-05 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:05 --> Total execution time: 0.2063
DEBUG - 2022-10-05 03:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:08 --> Total execution time: 0.3648
DEBUG - 2022-10-05 03:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:10 --> Total execution time: 0.1593
DEBUG - 2022-10-05 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:10 --> Total execution time: 0.1417
DEBUG - 2022-10-05 03:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:11 --> Total execution time: 0.0911
DEBUG - 2022-10-05 03:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:13 --> Total execution time: 0.1515
DEBUG - 2022-10-05 03:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:23 --> Total execution time: 0.1488
DEBUG - 2022-10-05 03:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:42 --> Total execution time: 0.2307
DEBUG - 2022-10-05 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:53 --> Total execution time: 0.1322
DEBUG - 2022-10-05 03:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:06 --> Total execution time: 0.3493
DEBUG - 2022-10-05 03:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:10 --> Total execution time: 0.1309
DEBUG - 2022-10-05 03:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:11 --> Total execution time: 0.1935
DEBUG - 2022-10-05 03:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:13 --> Total execution time: 0.1350
DEBUG - 2022-10-05 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:20 --> Total execution time: 0.1714
DEBUG - 2022-10-05 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:20 --> Total execution time: 0.1562
DEBUG - 2022-10-05 03:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:27 --> Total execution time: 0.1610
DEBUG - 2022-10-05 03:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:46 --> Total execution time: 0.1373
DEBUG - 2022-10-05 03:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:27:53 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:53 --> Total execution time: 0.1281
DEBUG - 2022-10-05 03:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:00:11 --> Total execution time: 0.1305
DEBUG - 2022-10-05 03:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:00:46 --> Total execution time: 0.3694
DEBUG - 2022-10-05 03:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:00:59 --> Total execution time: 0.1274
DEBUG - 2022-10-05 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:31:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:31:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:31:07 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-05 03:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:31:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:31:08 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-05 03:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:03:45 --> Total execution time: 0.4293
DEBUG - 2022-10-05 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:00 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:05:01 --> Total execution time: 0.1121
DEBUG - 2022-10-05 03:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:17 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:05:17 --> Total execution time: 0.3767
DEBUG - 2022-10-05 03:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:05:23 --> Total execution time: 0.1657
DEBUG - 2022-10-05 03:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:05:30 --> Total execution time: 0.1359
DEBUG - 2022-10-05 03:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:05:33 --> Total execution time: 0.1436
DEBUG - 2022-10-05 03:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:05:42 --> Total execution time: 0.1308
DEBUG - 2022-10-05 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:05 --> Total execution time: 0.0822
DEBUG - 2022-10-05 03:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:23 --> Total execution time: 0.4010
DEBUG - 2022-10-05 03:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:27 --> Total execution time: 0.1319
DEBUG - 2022-10-05 03:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:31 --> Total execution time: 0.1679
DEBUG - 2022-10-05 03:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:50 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:50 --> Total execution time: 0.1270
DEBUG - 2022-10-05 03:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:57 --> Total execution time: 0.1331
DEBUG - 2022-10-05 03:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:07:02 --> Total execution time: 0.1519
DEBUG - 2022-10-05 03:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:07:06 --> Total execution time: 0.1435
DEBUG - 2022-10-05 03:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:07:10 --> Total execution time: 0.1247
DEBUG - 2022-10-05 03:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:37:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 03:37:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 03:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:08:47 --> Total execution time: 0.1264
DEBUG - 2022-10-05 03:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:09:20 --> Total execution time: 0.3624
DEBUG - 2022-10-05 03:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:09:33 --> Total execution time: 0.1443
DEBUG - 2022-10-05 03:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:09:44 --> Total execution time: 0.1328
DEBUG - 2022-10-05 03:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:09:49 --> Total execution time: 0.1278
DEBUG - 2022-10-05 03:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:11:07 --> Total execution time: 0.1417
DEBUG - 2022-10-05 03:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:11:09 --> Total execution time: 0.1275
DEBUG - 2022-10-05 03:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:11:12 --> Total execution time: 0.1623
DEBUG - 2022-10-05 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:11:22 --> Total execution time: 0.1415
DEBUG - 2022-10-05 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:42:17 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:12:17 --> Total execution time: 0.1047
DEBUG - 2022-10-05 03:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:12:31 --> Total execution time: 0.0793
DEBUG - 2022-10-05 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:12:44 --> Total execution time: 0.1641
DEBUG - 2022-10-05 03:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:13:04 --> Total execution time: 0.1826
DEBUG - 2022-10-05 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:43:57 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:13:57 --> Total execution time: 0.0829
DEBUG - 2022-10-05 03:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:14:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 03:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:14:02 --> Total execution time: 0.1821
DEBUG - 2022-10-05 03:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:14:34 --> Total execution time: 0.1595
DEBUG - 2022-10-05 03:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:14:50 --> Total execution time: 0.1476
DEBUG - 2022-10-05 03:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:14:50 --> Total execution time: 0.1252
DEBUG - 2022-10-05 03:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:16:55 --> Total execution time: 0.3539
DEBUG - 2022-10-05 03:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:17:23 --> Total execution time: 0.1701
DEBUG - 2022-10-05 03:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:17:33 --> Total execution time: 0.1445
DEBUG - 2022-10-05 03:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:18:01 --> Total execution time: 0.1882
DEBUG - 2022-10-05 03:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:18:19 --> Total execution time: 0.1356
DEBUG - 2022-10-05 03:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:18:20 --> Total execution time: 0.1462
DEBUG - 2022-10-05 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:19:45 --> Total execution time: 0.1453
DEBUG - 2022-10-05 03:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:19:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 03:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:20:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:20:14 --> Total execution time: 0.1278
DEBUG - 2022-10-05 03:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:50:35 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:20:35 --> Total execution time: 0.1170
DEBUG - 2022-10-05 03:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:50:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:20:36 --> Total execution time: 0.1371
DEBUG - 2022-10-05 03:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:21:07 --> Total execution time: 0.1726
DEBUG - 2022-10-05 03:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:21:08 --> Total execution time: 0.1585
DEBUG - 2022-10-05 03:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:21:19 --> Total execution time: 0.0912
DEBUG - 2022-10-05 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:06 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:06 --> Total execution time: 0.0953
DEBUG - 2022-10-05 03:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 03:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:17 --> Total execution time: 0.1259
DEBUG - 2022-10-05 03:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:27 --> Total execution time: 0.1344
DEBUG - 2022-10-05 03:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:42 --> Total execution time: 0.1410
DEBUG - 2022-10-05 03:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:44 --> Total execution time: 0.3815
DEBUG - 2022-10-05 03:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:50 --> Total execution time: 0.1600
DEBUG - 2022-10-05 03:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:53 --> Total execution time: 0.1679
DEBUG - 2022-10-05 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:22:54 --> Total execution time: 0.1954
DEBUG - 2022-10-05 03:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:04 --> Total execution time: 0.0932
DEBUG - 2022-10-05 03:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:07 --> Total execution time: 0.3463
DEBUG - 2022-10-05 03:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:13 --> Total execution time: 0.1666
DEBUG - 2022-10-05 03:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:14 --> Total execution time: 0.3578
DEBUG - 2022-10-05 03:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:23 --> Total execution time: 0.1439
DEBUG - 2022-10-05 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:36 --> Total execution time: 0.3661
DEBUG - 2022-10-05 03:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:23:52 --> Total execution time: 0.1409
DEBUG - 2022-10-05 03:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:24:00 --> Total execution time: 0.1351
DEBUG - 2022-10-05 03:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:24:10 --> Total execution time: 0.1399
DEBUG - 2022-10-05 03:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:24:34 --> Total execution time: 0.1374
DEBUG - 2022-10-05 03:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:25:20 --> Total execution time: 0.1428
DEBUG - 2022-10-05 03:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:25:30 --> Total execution time: 0.1389
DEBUG - 2022-10-05 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:25:54 --> Total execution time: 0.1390
DEBUG - 2022-10-05 03:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:03 --> Total execution time: 0.1891
DEBUG - 2022-10-05 03:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:12 --> Total execution time: 0.1382
DEBUG - 2022-10-05 03:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:14 --> Total execution time: 0.1332
DEBUG - 2022-10-05 03:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 03:57:55 --> No URI present. Default controller set.
DEBUG - 2022-10-05 03:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 03:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:27:55 --> Total execution time: 0.1434
DEBUG - 2022-10-05 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:30:02 --> Total execution time: 0.1652
DEBUG - 2022-10-05 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:30:31 --> Total execution time: 0.1542
DEBUG - 2022-10-05 04:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:30:31 --> Total execution time: 0.1407
DEBUG - 2022-10-05 04:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:30:32 --> Total execution time: 0.1410
DEBUG - 2022-10-05 04:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:30:33 --> Total execution time: 0.1406
DEBUG - 2022-10-05 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:30:56 --> Total execution time: 0.1233
DEBUG - 2022-10-05 04:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:01:05 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-10-05 04:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:31:18 --> Total execution time: 0.3804
DEBUG - 2022-10-05 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:31:27 --> Total execution time: 0.1664
DEBUG - 2022-10-05 04:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:31:32 --> Total execution time: 0.0794
DEBUG - 2022-10-05 04:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:31:40 --> Total execution time: 0.1242
DEBUG - 2022-10-05 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:31:53 --> Total execution time: 0.1340
DEBUG - 2022-10-05 04:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:09 --> Total execution time: 0.1350
DEBUG - 2022-10-05 04:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:10 --> Total execution time: 0.1420
DEBUG - 2022-10-05 04:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:18 --> Total execution time: 0.1471
DEBUG - 2022-10-05 04:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:30 --> Total execution time: 0.1269
DEBUG - 2022-10-05 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:36 --> Total execution time: 0.3528
DEBUG - 2022-10-05 04:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:36 --> Total execution time: 0.1518
DEBUG - 2022-10-05 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:46 --> Total execution time: 0.1385
DEBUG - 2022-10-05 04:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:54 --> Total execution time: 0.1287
DEBUG - 2022-10-05 04:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:32:59 --> Total execution time: 0.1409
DEBUG - 2022-10-05 04:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:36:49 --> Total execution time: 0.1897
DEBUG - 2022-10-05 04:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:38:12 --> Total execution time: 0.3724
DEBUG - 2022-10-05 04:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:38:19 --> Total execution time: 0.1293
DEBUG - 2022-10-05 04:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:39:47 --> Total execution time: 0.3686
DEBUG - 2022-10-05 04:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:39:50 --> Total execution time: 0.1411
DEBUG - 2022-10-05 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:44:36 --> Total execution time: 0.1666
DEBUG - 2022-10-05 04:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:15:30 --> Total execution time: 0.1282
DEBUG - 2022-10-05 04:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:34 --> Total execution time: 0.1457
DEBUG - 2022-10-05 04:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:42 --> Total execution time: 0.0782
DEBUG - 2022-10-05 04:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:43 --> Total execution time: 0.1328
DEBUG - 2022-10-05 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:52 --> Total execution time: 0.1433
DEBUG - 2022-10-05 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:53 --> Total execution time: 0.1313
DEBUG - 2022-10-05 04:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:54 --> Total execution time: 0.1350
DEBUG - 2022-10-05 04:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:45:57 --> Total execution time: 0.1319
DEBUG - 2022-10-05 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:46:03 --> Total execution time: 0.1366
DEBUG - 2022-10-05 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:46:19 --> Total execution time: 0.1247
DEBUG - 2022-10-05 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:46:56 --> Total execution time: 0.1313
DEBUG - 2022-10-05 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:47:04 --> Total execution time: 0.1457
DEBUG - 2022-10-05 04:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:47:18 --> Total execution time: 0.1745
DEBUG - 2022-10-05 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:47:35 --> Total execution time: 0.1367
DEBUG - 2022-10-05 04:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:47:37 --> Total execution time: 0.1307
DEBUG - 2022-10-05 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:49:32 --> Total execution time: 0.1264
DEBUG - 2022-10-05 04:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:50:39 --> Total execution time: 0.1430
DEBUG - 2022-10-05 04:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:23:37 --> Total execution time: 0.1239
DEBUG - 2022-10-05 04:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:23:38 --> Total execution time: 0.1260
DEBUG - 2022-10-05 04:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:53:41 --> Total execution time: 0.1505
DEBUG - 2022-10-05 04:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:53:45 --> Total execution time: 0.3405
DEBUG - 2022-10-05 04:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:53:51 --> Total execution time: 0.1771
DEBUG - 2022-10-05 04:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:54:03 --> Total execution time: 0.1388
DEBUG - 2022-10-05 04:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:54:10 --> Total execution time: 0.1286
DEBUG - 2022-10-05 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:55:16 --> Total execution time: 0.1339
DEBUG - 2022-10-05 04:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:55:21 --> Total execution time: 0.1350
DEBUG - 2022-10-05 04:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:57:27 --> Total execution time: 0.1332
DEBUG - 2022-10-05 04:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:57:28 --> Total execution time: 0.1513
DEBUG - 2022-10-05 04:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:57:54 --> Total execution time: 0.1352
DEBUG - 2022-10-05 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:58:34 --> Total execution time: 0.1321
DEBUG - 2022-10-05 04:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:59:27 --> Total execution time: 0.1274
DEBUG - 2022-10-05 04:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:59:58 --> Total execution time: 0.1392
DEBUG - 2022-10-05 04:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:00:04 --> Total execution time: 0.3754
DEBUG - 2022-10-05 04:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:30:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:00:22 --> Total execution time: 0.0876
DEBUG - 2022-10-05 04:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:00:29 --> Total execution time: 0.1373
DEBUG - 2022-10-05 04:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:01:11 --> Total execution time: 0.1356
DEBUG - 2022-10-05 04:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:02:15 --> Total execution time: 0.1987
DEBUG - 2022-10-05 04:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:32:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 04:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:32:55 --> 404 Page Not Found: Teacher/index
DEBUG - 2022-10-05 04:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:03:22 --> Total execution time: 0.1268
DEBUG - 2022-10-05 04:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:03:32 --> Total execution time: 0.1247
DEBUG - 2022-10-05 04:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:05:00 --> Total execution time: 0.1299
DEBUG - 2022-10-05 04:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:05:04 --> Total execution time: 0.1392
DEBUG - 2022-10-05 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:05:09 --> Total execution time: 0.1258
DEBUG - 2022-10-05 04:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:05:36 --> Total execution time: 0.1438
DEBUG - 2022-10-05 04:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:05:38 --> Total execution time: 0.1273
DEBUG - 2022-10-05 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:06:44 --> Total execution time: 0.3486
DEBUG - 2022-10-05 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:07:13 --> Total execution time: 0.0799
DEBUG - 2022-10-05 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:07:50 --> Total execution time: 0.1381
DEBUG - 2022-10-05 04:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:38:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:08:04 --> Total execution time: 0.0870
DEBUG - 2022-10-05 04:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:08:38 --> Total execution time: 0.3411
DEBUG - 2022-10-05 04:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:09:20 --> Total execution time: 0.1246
DEBUG - 2022-10-05 04:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:10:06 --> Total execution time: 0.1257
DEBUG - 2022-10-05 04:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:10:32 --> Total execution time: 0.1437
DEBUG - 2022-10-05 04:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:40:58 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:10:58 --> Total execution time: 0.0862
DEBUG - 2022-10-05 04:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:11:25 --> Total execution time: 0.1244
DEBUG - 2022-10-05 04:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:41:47 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:11:47 --> Total execution time: 0.0827
DEBUG - 2022-10-05 04:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:42:17 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:12:17 --> Total execution time: 0.1380
DEBUG - 2022-10-05 04:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:12:37 --> Total execution time: 0.1337
DEBUG - 2022-10-05 04:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:12:38 --> Total execution time: 0.1535
DEBUG - 2022-10-05 04:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:43:09 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:13:10 --> Total execution time: 0.0892
DEBUG - 2022-10-05 04:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:43:42 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:13:43 --> Total execution time: 0.0848
DEBUG - 2022-10-05 04:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:14:21 --> Total execution time: 0.1046
DEBUG - 2022-10-05 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:15:40 --> Total execution time: 0.1372
DEBUG - 2022-10-05 04:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:16:22 --> Total execution time: 0.3660
DEBUG - 2022-10-05 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:46:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:46:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:46:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:16:59 --> Total execution time: 0.0867
DEBUG - 2022-10-05 15:16:59 --> Total execution time: 0.0960
DEBUG - 2022-10-05 04:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:17:00 --> Total execution time: 0.0811
DEBUG - 2022-10-05 04:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:17:02 --> Total execution time: 0.0825
DEBUG - 2022-10-05 04:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:17:03 --> Total execution time: 0.0830
DEBUG - 2022-10-05 04:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:17:09 --> Total execution time: 0.1307
DEBUG - 2022-10-05 04:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:18:10 --> Total execution time: 0.1317
DEBUG - 2022-10-05 04:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:18:52 --> Total execution time: 0.3468
DEBUG - 2022-10-05 04:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:51:07 --> Total execution time: 0.0814
DEBUG - 2022-10-05 04:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:21:21 --> Total execution time: 0.1285
DEBUG - 2022-10-05 04:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:21:29 --> Total execution time: 0.1524
DEBUG - 2022-10-05 04:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:21:35 --> Total execution time: 0.1653
DEBUG - 2022-10-05 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:21:37 --> Total execution time: 0.1651
DEBUG - 2022-10-05 04:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:21:53 --> Total execution time: 0.1594
DEBUG - 2022-10-05 04:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:22:19 --> Total execution time: 0.2152
DEBUG - 2022-10-05 04:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:09 --> Total execution time: 0.1633
DEBUG - 2022-10-05 04:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:31 --> Total execution time: 0.1204
DEBUG - 2022-10-05 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:36 --> Total execution time: 0.1755
DEBUG - 2022-10-05 04:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:38 --> Total execution time: 0.1638
DEBUG - 2022-10-05 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:43 --> Total execution time: 0.1210
DEBUG - 2022-10-05 04:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:45 --> Total execution time: 0.1777
DEBUG - 2022-10-05 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:47 --> Total execution time: 0.1648
DEBUG - 2022-10-05 04:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:23:48 --> Total execution time: 0.1693
DEBUG - 2022-10-05 04:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:25:18 --> Total execution time: 0.3721
DEBUG - 2022-10-05 04:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:25:25 --> Total execution time: 0.1578
DEBUG - 2022-10-05 04:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:25:25 --> Total execution time: 0.1963
DEBUG - 2022-10-05 04:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:25:57 --> Total execution time: 0.1444
DEBUG - 2022-10-05 04:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:26:04 --> Total execution time: 0.1363
DEBUG - 2022-10-05 04:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:26:24 --> Total execution time: 0.1619
DEBUG - 2022-10-05 04:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:56:51 --> 404 Page Not Found: Wp-includes/shell20211028.php
DEBUG - 2022-10-05 04:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:56:54 --> 404 Page Not Found: Wp-includes/shell20211028.php
DEBUG - 2022-10-05 04:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:56:59 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-10-05 04:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 04:57:02 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-10-05 04:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:03 --> Total execution time: 0.3442
DEBUG - 2022-10-05 04:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:08 --> Total execution time: 0.1338
DEBUG - 2022-10-05 04:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:08 --> Total execution time: 0.3658
DEBUG - 2022-10-05 04:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:14 --> Total execution time: 0.1610
DEBUG - 2022-10-05 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:25 --> Total execution time: 0.1591
DEBUG - 2022-10-05 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 04:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:29 --> Total execution time: 0.1327
DEBUG - 2022-10-05 04:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:30 --> Total execution time: 0.1513
DEBUG - 2022-10-05 04:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:37 --> Total execution time: 0.1385
DEBUG - 2022-10-05 04:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:42 --> Total execution time: 0.1520
DEBUG - 2022-10-05 04:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:43 --> Total execution time: 0.1544
DEBUG - 2022-10-05 04:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:27:55 --> Total execution time: 0.1277
DEBUG - 2022-10-05 04:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:28:07 --> Total execution time: 0.1843
DEBUG - 2022-10-05 04:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:28:16 --> Total execution time: 0.1422
DEBUG - 2022-10-05 04:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:28:23 --> Total execution time: 0.1352
DEBUG - 2022-10-05 04:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 04:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 04:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:28:34 --> Total execution time: 0.1446
DEBUG - 2022-10-05 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:30:02 --> Total execution time: 0.1113
DEBUG - 2022-10-05 05:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:31:17 --> Total execution time: 0.1507
DEBUG - 2022-10-05 05:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:02:01 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:32:01 --> Total execution time: 0.1806
DEBUG - 2022-10-05 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:32:07 --> Total execution time: 0.1816
DEBUG - 2022-10-05 05:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:32:12 --> Total execution time: 0.3429
DEBUG - 2022-10-05 05:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:32:15 --> Total execution time: 0.1454
DEBUG - 2022-10-05 05:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:32:22 --> Total execution time: 0.1304
DEBUG - 2022-10-05 05:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:33:10 --> Total execution time: 0.3572
DEBUG - 2022-10-05 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 05:04:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:34:14 --> Total execution time: 0.0816
DEBUG - 2022-10-05 05:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:06:00 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:36:00 --> Total execution time: 0.3528
DEBUG - 2022-10-05 05:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:36:23 --> Total execution time: 0.1273
DEBUG - 2022-10-05 05:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:07:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:37:08 --> Total execution time: 0.0841
DEBUG - 2022-10-05 05:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:38:32 --> Total execution time: 0.0810
DEBUG - 2022-10-05 05:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:39:30 --> Total execution time: 0.1259
DEBUG - 2022-10-05 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:39:59 --> Total execution time: 0.1298
DEBUG - 2022-10-05 05:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:40:35 --> Total execution time: 0.1356
DEBUG - 2022-10-05 05:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:40:53 --> Total execution time: 0.1762
DEBUG - 2022-10-05 05:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:40:56 --> Total execution time: 0.1351
DEBUG - 2022-10-05 05:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:41:10 --> Total execution time: 0.1636
DEBUG - 2022-10-05 05:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:42:55 --> Total execution time: 0.3373
DEBUG - 2022-10-05 05:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:43:29 --> Total execution time: 0.1726
DEBUG - 2022-10-05 05:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:43:48 --> Total execution time: 0.1724
DEBUG - 2022-10-05 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:16:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:04 --> Total execution time: 0.4205
DEBUG - 2022-10-05 05:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:09 --> Total execution time: 0.1456
DEBUG - 2022-10-05 05:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:47:25 --> Total execution time: 0.3429
DEBUG - 2022-10-05 05:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:48:46 --> Total execution time: 0.0811
DEBUG - 2022-10-05 05:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:49:30 --> Total execution time: 0.1009
DEBUG - 2022-10-05 05:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:19:41 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:49:41 --> Total execution time: 0.0880
DEBUG - 2022-10-05 05:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:49:43 --> Total execution time: 0.1387
DEBUG - 2022-10-05 05:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:49:46 --> Total execution time: 0.1505
DEBUG - 2022-10-05 05:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:49:55 --> Total execution time: 0.1429
DEBUG - 2022-10-05 05:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:50:08 --> Total execution time: 0.1326
DEBUG - 2022-10-05 05:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:50:53 --> Total execution time: 0.1288
DEBUG - 2022-10-05 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:50:54 --> Total execution time: 0.1309
DEBUG - 2022-10-05 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:23:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:53:05 --> Total execution time: 0.1582
DEBUG - 2022-10-05 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:23:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:53:05 --> Total execution time: 0.0785
DEBUG - 2022-10-05 05:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:53:52 --> Total execution time: 0.3877
DEBUG - 2022-10-05 05:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:53:59 --> Total execution time: 0.1656
DEBUG - 2022-10-05 05:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:55:24 --> Total execution time: 0.0847
DEBUG - 2022-10-05 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:55:37 --> Total execution time: 0.1340
DEBUG - 2022-10-05 05:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:56:19 --> Total execution time: 0.1305
DEBUG - 2022-10-05 05:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:56:54 --> Total execution time: 0.2201
DEBUG - 2022-10-05 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:56:57 --> Total execution time: 0.1475
DEBUG - 2022-10-05 05:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:57:26 --> Total execution time: 0.3536
DEBUG - 2022-10-05 05:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:00:59 --> Total execution time: 0.1319
DEBUG - 2022-10-05 05:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:01:06 --> Total execution time: 0.1519
DEBUG - 2022-10-05 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:01:15 --> Total execution time: 0.1307
DEBUG - 2022-10-05 05:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:01:22 --> Total execution time: 0.1282
DEBUG - 2022-10-05 05:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:02:46 --> Total execution time: 0.1261
DEBUG - 2022-10-05 05:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:35:47 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:05:47 --> Total execution time: 0.1808
DEBUG - 2022-10-05 05:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:07:16 --> Total execution time: 0.0813
DEBUG - 2022-10-05 05:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:08:59 --> Total execution time: 0.3900
DEBUG - 2022-10-05 05:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:04 --> Total execution time: 0.2033
DEBUG - 2022-10-05 05:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:04 --> Total execution time: 0.1647
DEBUG - 2022-10-05 05:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:05 --> Total execution time: 0.1835
DEBUG - 2022-10-05 05:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:05 --> Total execution time: 0.1865
DEBUG - 2022-10-05 05:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:07 --> Total execution time: 0.2058
DEBUG - 2022-10-05 05:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:08 --> Total execution time: 0.1796
DEBUG - 2022-10-05 05:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:08 --> Total execution time: 0.1728
DEBUG - 2022-10-05 05:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:09:08 --> Total execution time: 0.1814
DEBUG - 2022-10-05 05:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:44:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:14:25 --> Total execution time: 0.1882
DEBUG - 2022-10-05 05:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:44:26 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:14:26 --> Total execution time: 0.0806
DEBUG - 2022-10-05 05:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:14:39 --> Total execution time: 0.0789
DEBUG - 2022-10-05 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:14:46 --> Total execution time: 0.1333
DEBUG - 2022-10-05 05:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:14:58 --> Total execution time: 0.1498
DEBUG - 2022-10-05 05:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:15:02 --> Total execution time: 0.1783
DEBUG - 2022-10-05 05:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:15:22 --> Total execution time: 0.1364
DEBUG - 2022-10-05 05:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:15:40 --> Total execution time: 0.1253
DEBUG - 2022-10-05 05:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:15:53 --> Total execution time: 0.1538
DEBUG - 2022-10-05 05:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:29 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:29 --> Total execution time: 0.0869
DEBUG - 2022-10-05 05:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:33 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:33 --> Total execution time: 0.0870
DEBUG - 2022-10-05 05:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:35 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:35 --> Total execution time: 0.1545
DEBUG - 2022-10-05 05:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:37 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:37 --> Total execution time: 0.1716
DEBUG - 2022-10-05 05:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:38 --> Total execution time: 0.1263
DEBUG - 2022-10-05 05:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:39 --> Total execution time: 0.1272
DEBUG - 2022-10-05 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:40 --> Total execution time: 0.1305
DEBUG - 2022-10-05 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:40 --> Total execution time: 0.1270
DEBUG - 2022-10-05 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:41 --> Total execution time: 0.1257
DEBUG - 2022-10-05 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:41 --> Total execution time: 0.1260
DEBUG - 2022-10-05 05:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:17:42 --> Total execution time: 0.1297
DEBUG - 2022-10-05 05:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 05:49:16 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-10-05 05:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 05:49:16 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-10-05 05:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:49:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:19:17 --> Total execution time: 0.1171
DEBUG - 2022-10-05 05:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:50:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:20:32 --> Total execution time: 0.0846
DEBUG - 2022-10-05 05:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:54:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:24:32 --> Total execution time: 0.2184
DEBUG - 2022-10-05 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:25:40 --> Total execution time: 0.1566
DEBUG - 2022-10-05 05:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:26:24 --> Total execution time: 0.1429
DEBUG - 2022-10-05 05:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:26:28 --> Total execution time: 0.3830
DEBUG - 2022-10-05 05:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:26:49 --> Total execution time: 0.1281
DEBUG - 2022-10-05 05:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:27:14 --> Total execution time: 0.1552
DEBUG - 2022-10-05 05:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:27:35 --> Total execution time: 0.1443
DEBUG - 2022-10-05 05:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:58:10 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:28:11 --> Total execution time: 0.3528
DEBUG - 2022-10-05 05:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:58:49 --> No URI present. Default controller set.
DEBUG - 2022-10-05 05:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:28:49 --> Total execution time: 0.1299
DEBUG - 2022-10-05 05:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:28:50 --> Total execution time: 0.1791
DEBUG - 2022-10-05 05:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:29:12 --> Total execution time: 0.1458
DEBUG - 2022-10-05 05:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 05:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 05:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:29:43 --> Total execution time: 0.1280
DEBUG - 2022-10-05 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:30:02 --> Total execution time: 0.1343
DEBUG - 2022-10-05 06:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:00:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:30:27 --> Total execution time: 0.1352
DEBUG - 2022-10-05 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:30:30 --> Total execution time: 0.1290
DEBUG - 2022-10-05 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:31:56 --> Total execution time: 0.1263
DEBUG - 2022-10-05 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:14 --> Total execution time: 0.0906
DEBUG - 2022-10-05 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:15 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:15 --> Total execution time: 0.0789
DEBUG - 2022-10-05 06:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:26 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:26 --> Total execution time: 0.0904
DEBUG - 2022-10-05 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:39 --> Total execution time: 0.0808
DEBUG - 2022-10-05 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:40 --> Total execution time: 0.1439
DEBUG - 2022-10-05 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:48 --> Total execution time: 0.1531
DEBUG - 2022-10-05 06:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:32:48 --> Total execution time: 0.1246
DEBUG - 2022-10-05 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:33:00 --> Total execution time: 0.1337
DEBUG - 2022-10-05 06:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:33:04 --> Total execution time: 0.1395
DEBUG - 2022-10-05 06:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:33:11 --> Total execution time: 0.1841
DEBUG - 2022-10-05 06:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:33:40 --> Total execution time: 0.1412
DEBUG - 2022-10-05 06:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:33:44 --> Total execution time: 0.1430
DEBUG - 2022-10-05 06:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:03:44 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:33:44 --> Total execution time: 0.1266
DEBUG - 2022-10-05 06:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:34:20 --> Total execution time: 0.1327
DEBUG - 2022-10-05 06:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:34:22 --> Total execution time: 0.3763
DEBUG - 2022-10-05 06:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:34:55 --> Total execution time: 0.1263
DEBUG - 2022-10-05 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:35:22 --> Total execution time: 0.1380
DEBUG - 2022-10-05 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:35:49 --> Total execution time: 0.1286
DEBUG - 2022-10-05 06:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:36:30 --> Total execution time: 0.1322
DEBUG - 2022-10-05 06:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:36:40 --> Total execution time: 0.1313
DEBUG - 2022-10-05 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:37:07 --> Total execution time: 0.1319
DEBUG - 2022-10-05 06:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:37:29 --> Total execution time: 0.1396
DEBUG - 2022-10-05 06:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:08:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:38:04 --> Total execution time: 0.0862
DEBUG - 2022-10-05 06:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:38:31 --> Total execution time: 0.1278
DEBUG - 2022-10-05 06:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:09:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:39:28 --> Total execution time: 0.0909
DEBUG - 2022-10-05 06:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:09:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:39:29 --> Total execution time: 0.0830
DEBUG - 2022-10-05 06:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:39:32 --> Total execution time: 0.3459
DEBUG - 2022-10-05 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:39:38 --> Total execution time: 0.1449
DEBUG - 2022-10-05 06:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:40:10 --> Total execution time: 0.1431
DEBUG - 2022-10-05 06:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:40:16 --> Total execution time: 0.1622
DEBUG - 2022-10-05 06:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:41:02 --> Total execution time: 0.1432
DEBUG - 2022-10-05 06:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:11:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:41:12 --> Total execution time: 0.0848
DEBUG - 2022-10-05 06:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:41:38 --> Total execution time: 0.1354
DEBUG - 2022-10-05 06:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:41:42 --> Total execution time: 0.3593
DEBUG - 2022-10-05 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:14:57 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:44:58 --> Total execution time: 0.4301
DEBUG - 2022-10-05 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:15:31 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:45:31 --> Total execution time: 0.0813
DEBUG - 2022-10-05 06:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:46:05 --> Total execution time: 0.1387
DEBUG - 2022-10-05 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:46:17 --> Total execution time: 0.1899
DEBUG - 2022-10-05 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:46:28 --> Total execution time: 0.1306
DEBUG - 2022-10-05 06:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:46:32 --> Total execution time: 0.1272
DEBUG - 2022-10-05 06:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:47:53 --> Total execution time: 0.0922
DEBUG - 2022-10-05 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:48:33 --> Total execution time: 0.0889
DEBUG - 2022-10-05 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:48:40 --> Total execution time: 0.1432
DEBUG - 2022-10-05 06:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:48:50 --> Total execution time: 0.1435
DEBUG - 2022-10-05 06:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:49:27 --> Total execution time: 0.2608
DEBUG - 2022-10-05 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:50:31 --> Total execution time: 0.1975
DEBUG - 2022-10-05 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:50:37 --> Total execution time: 0.1369
DEBUG - 2022-10-05 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:50:39 --> Total execution time: 0.1640
DEBUG - 2022-10-05 06:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:51:35 --> Total execution time: 0.1501
DEBUG - 2022-10-05 06:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:52:35 --> Total execution time: 0.1314
DEBUG - 2022-10-05 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:53:02 --> Total execution time: 0.1381
DEBUG - 2022-10-05 06:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:53:11 --> Total execution time: 0.1325
DEBUG - 2022-10-05 06:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:53:14 --> Total execution time: 0.1342
DEBUG - 2022-10-05 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:53:17 --> Total execution time: 0.1371
DEBUG - 2022-10-05 06:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:53:21 --> Total execution time: 0.1405
DEBUG - 2022-10-05 06:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:53:36 --> Total execution time: 0.1338
DEBUG - 2022-10-05 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:54:13 --> Total execution time: 0.1287
DEBUG - 2022-10-05 06:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:54:59 --> Total execution time: 0.1365
DEBUG - 2022-10-05 06:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:55:02 --> Total execution time: 0.5940
DEBUG - 2022-10-05 06:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:55:52 --> Total execution time: 0.0873
DEBUG - 2022-10-05 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:55:59 --> Total execution time: 0.1780
DEBUG - 2022-10-05 06:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:56:01 --> Total execution time: 0.1324
DEBUG - 2022-10-05 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:56:05 --> Total execution time: 0.1651
DEBUG - 2022-10-05 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:56:16 --> Total execution time: 0.1669
DEBUG - 2022-10-05 06:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:56:25 --> Total execution time: 0.1951
DEBUG - 2022-10-05 06:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:56:50 --> Total execution time: 0.1908
DEBUG - 2022-10-05 06:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:56:54 --> Total execution time: 0.1633
DEBUG - 2022-10-05 06:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:57:27 --> Total execution time: 0.3997
DEBUG - 2022-10-05 06:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:57:44 --> Total execution time: 0.3382
DEBUG - 2022-10-05 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:57:51 --> Total execution time: 0.1286
DEBUG - 2022-10-05 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:09 --> Total execution time: 0.1377
DEBUG - 2022-10-05 06:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:11 --> Total execution time: 0.0902
DEBUG - 2022-10-05 06:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:58:17 --> Total execution time: 0.2916
DEBUG - 2022-10-05 06:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:17 --> Total execution time: 0.1384
DEBUG - 2022-10-05 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:22 --> Total execution time: 0.1547
DEBUG - 2022-10-05 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:24 --> Total execution time: 0.1286
DEBUG - 2022-10-05 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:25 --> Total execution time: 0.1279
DEBUG - 2022-10-05 06:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:36 --> Total execution time: 0.0871
DEBUG - 2022-10-05 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:37 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:37 --> Total execution time: 0.0827
DEBUG - 2022-10-05 06:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:58:41 --> Total execution time: 0.1260
DEBUG - 2022-10-05 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:59:08 --> Total execution time: 0.1348
DEBUG - 2022-10-05 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:59:16 --> Total execution time: 0.1319
DEBUG - 2022-10-05 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:00 --> Total execution time: 0.1381
DEBUG - 2022-10-05 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:23 --> Total execution time: 0.0829
DEBUG - 2022-10-05 06:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:29 --> Total execution time: 0.0891
DEBUG - 2022-10-05 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:41 --> Total execution time: 0.2474
DEBUG - 2022-10-05 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:42 --> Total execution time: 0.1256
DEBUG - 2022-10-05 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:48 --> Total execution time: 0.1894
DEBUG - 2022-10-05 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:52 --> Total execution time: 0.1407
DEBUG - 2022-10-05 06:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:54 --> Total execution time: 0.1406
DEBUG - 2022-10-05 06:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:01:03 --> Total execution time: 0.1364
DEBUG - 2022-10-05 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:01:10 --> Total execution time: 0.1754
DEBUG - 2022-10-05 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:01:29 --> Total execution time: 0.1302
DEBUG - 2022-10-05 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:01:31 --> Total execution time: 0.3517
DEBUG - 2022-10-05 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:01:50 --> Total execution time: 0.1457
DEBUG - 2022-10-05 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:01:51 --> Total execution time: 0.1331
DEBUG - 2022-10-05 06:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:13 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:13 --> Total execution time: 0.1376
DEBUG - 2022-10-05 06:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:17 --> Total execution time: 0.1570
DEBUG - 2022-10-05 06:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:23 --> Total execution time: 0.3769
DEBUG - 2022-10-05 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:24 --> Total execution time: 0.1378
DEBUG - 2022-10-05 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:26 --> Total execution time: 0.1343
DEBUG - 2022-10-05 06:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:32:30 --> Total execution time: 0.1259
DEBUG - 2022-10-05 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:32:32 --> Total execution time: 0.1428
DEBUG - 2022-10-05 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:32:33 --> Total execution time: 0.1305
DEBUG - 2022-10-05 06:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:34 --> Total execution time: 0.1303
DEBUG - 2022-10-05 06:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:35 --> Total execution time: 0.1371
DEBUG - 2022-10-05 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:37 --> Total execution time: 0.1314
DEBUG - 2022-10-05 06:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:42 --> Total execution time: 0.1542
DEBUG - 2022-10-05 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:02:52 --> Total execution time: 0.1323
DEBUG - 2022-10-05 06:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:03 --> Total execution time: 0.1290
DEBUG - 2022-10-05 06:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:13 --> Total execution time: 0.1444
DEBUG - 2022-10-05 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:18 --> Total execution time: 0.1444
DEBUG - 2022-10-05 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:22 --> Total execution time: 0.1645
DEBUG - 2022-10-05 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:31 --> Total execution time: 0.1418
DEBUG - 2022-10-05 06:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:36 --> Total execution time: 0.1374
DEBUG - 2022-10-05 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:38 --> Total execution time: 0.1323
DEBUG - 2022-10-05 06:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:45 --> Total execution time: 0.1769
DEBUG - 2022-10-05 06:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:50 --> Total execution time: 0.1628
DEBUG - 2022-10-05 06:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:03:55 --> Total execution time: 0.1441
DEBUG - 2022-10-05 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:01 --> Total execution time: 2.3955
DEBUG - 2022-10-05 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:02 --> Total execution time: 0.1421
DEBUG - 2022-10-05 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:03 --> Total execution time: 0.1312
DEBUG - 2022-10-05 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:34:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:33 --> Total execution time: 0.1276
DEBUG - 2022-10-05 06:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:35 --> Total execution time: 0.2940
DEBUG - 2022-10-05 06:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:40 --> Total execution time: 0.1312
DEBUG - 2022-10-05 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:43 --> Total execution time: 0.1496
DEBUG - 2022-10-05 06:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:46 --> Total execution time: 0.1724
DEBUG - 2022-10-05 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:50 --> Total execution time: 0.1475
DEBUG - 2022-10-05 06:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:53 --> Total execution time: 0.1294
DEBUG - 2022-10-05 06:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:55 --> Total execution time: 0.1261
DEBUG - 2022-10-05 06:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:56 --> Total execution time: 0.1271
DEBUG - 2022-10-05 06:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:04:57 --> Total execution time: 0.1546
DEBUG - 2022-10-05 06:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:05:00 --> Total execution time: 0.1267
DEBUG - 2022-10-05 06:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:05:08 --> Total execution time: 0.1242
DEBUG - 2022-10-05 06:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:05:23 --> Total execution time: 0.1353
DEBUG - 2022-10-05 06:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:05:27 --> Total execution time: 0.1581
DEBUG - 2022-10-05 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:05:32 --> Total execution time: 0.1336
DEBUG - 2022-10-05 06:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:05:49 --> Total execution time: 0.1501
DEBUG - 2022-10-05 06:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:06:01 --> Total execution time: 0.3675
DEBUG - 2022-10-05 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:06:22 --> Total execution time: 0.1446
DEBUG - 2022-10-05 06:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:06:23 --> Total execution time: 0.1303
DEBUG - 2022-10-05 06:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:07:03 --> Total execution time: 0.1467
DEBUG - 2022-10-05 06:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:07:08 --> Total execution time: 0.3982
DEBUG - 2022-10-05 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:07:18 --> Total execution time: 0.1499
DEBUG - 2022-10-05 06:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:07:34 --> Total execution time: 0.1329
DEBUG - 2022-10-05 06:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:07:35 --> Total execution time: 0.1228
DEBUG - 2022-10-05 06:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:07:44 --> Total execution time: 0.3628
DEBUG - 2022-10-05 06:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:08:04 --> Total execution time: 0.4649
DEBUG - 2022-10-05 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:08:07 --> Total execution time: 0.1286
DEBUG - 2022-10-05 06:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:08:11 --> Total execution time: 0.1324
DEBUG - 2022-10-05 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:08:33 --> Total execution time: 0.1370
DEBUG - 2022-10-05 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:08:33 --> Total execution time: 0.1937
DEBUG - 2022-10-05 06:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:05 --> Total execution time: 0.1436
DEBUG - 2022-10-05 06:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:07 --> Total execution time: 0.1808
DEBUG - 2022-10-05 06:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:17 --> Total execution time: 0.1289
DEBUG - 2022-10-05 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:24 --> Total execution time: 0.1797
DEBUG - 2022-10-05 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:32 --> Total execution time: 0.1516
DEBUG - 2022-10-05 06:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:39 --> Total execution time: 0.1650
DEBUG - 2022-10-05 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:41 --> Total execution time: 0.1500
DEBUG - 2022-10-05 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:54 --> Total execution time: 0.1412
DEBUG - 2022-10-05 06:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:58 --> Total execution time: 0.1598
DEBUG - 2022-10-05 06:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:10:19 --> Total execution time: 0.1360
DEBUG - 2022-10-05 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:10:23 --> Total execution time: 0.1728
DEBUG - 2022-10-05 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:10:24 --> Total execution time: 0.1384
DEBUG - 2022-10-05 06:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:10:49 --> Total execution time: 0.1303
DEBUG - 2022-10-05 06:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:10:57 --> Total execution time: 0.1459
DEBUG - 2022-10-05 06:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:11:09 --> Total execution time: 0.1335
DEBUG - 2022-10-05 06:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:41:29 --> Total execution time: 0.1213
DEBUG - 2022-10-05 06:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:11:31 --> Total execution time: 0.1215
DEBUG - 2022-10-05 06:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:11:39 --> Total execution time: 0.1275
DEBUG - 2022-10-05 06:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:11:41 --> Total execution time: 0.1300
DEBUG - 2022-10-05 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:11:47 --> Total execution time: 0.0803
DEBUG - 2022-10-05 06:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:11:52 --> Total execution time: 0.1475
DEBUG - 2022-10-05 06:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:06 --> Total execution time: 0.1996
DEBUG - 2022-10-05 06:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:08 --> Total execution time: 0.3378
DEBUG - 2022-10-05 06:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:09 --> Total execution time: 0.3506
DEBUG - 2022-10-05 06:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:19 --> Total execution time: 0.1405
DEBUG - 2022-10-05 06:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:32 --> Total execution time: 0.1397
DEBUG - 2022-10-05 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:35 --> Total execution time: 0.0879
DEBUG - 2022-10-05 06:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:53 --> Total execution time: 0.1656
DEBUG - 2022-10-05 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:20 --> Total execution time: 0.1335
DEBUG - 2022-10-05 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:38 --> Total execution time: 0.1410
DEBUG - 2022-10-05 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:40 --> Total execution time: 0.1506
DEBUG - 2022-10-05 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:43 --> Total execution time: 0.1426
DEBUG - 2022-10-05 06:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:26 --> Total execution time: 0.3641
DEBUG - 2022-10-05 06:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:32 --> Total execution time: 0.1436
DEBUG - 2022-10-05 06:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:34 --> Total execution time: 0.1427
DEBUG - 2022-10-05 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:40 --> Total execution time: 0.1403
DEBUG - 2022-10-05 06:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:43 --> Total execution time: 0.1351
DEBUG - 2022-10-05 06:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:48 --> Total execution time: 0.3850
DEBUG - 2022-10-05 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:52 --> Total execution time: 0.1457
DEBUG - 2022-10-05 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:57 --> Total execution time: 0.1585
DEBUG - 2022-10-05 06:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:14:58 --> Total execution time: 0.1361
DEBUG - 2022-10-05 06:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:04 --> Total execution time: 0.1485
DEBUG - 2022-10-05 06:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:06 --> Total execution time: 0.1268
DEBUG - 2022-10-05 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:14 --> Total execution time: 0.1254
DEBUG - 2022-10-05 06:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:17 --> Total execution time: 0.1540
DEBUG - 2022-10-05 06:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:20 --> Total execution time: 0.1687
DEBUG - 2022-10-05 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:21 --> Total execution time: 0.1501
DEBUG - 2022-10-05 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:21 --> Total execution time: 0.1752
DEBUG - 2022-10-05 06:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:26 --> Total execution time: 0.1263
DEBUG - 2022-10-05 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:29 --> Total execution time: 0.1649
DEBUG - 2022-10-05 06:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:33 --> Total execution time: 0.1396
DEBUG - 2022-10-05 06:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:41 --> Total execution time: 0.1508
DEBUG - 2022-10-05 06:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:42 --> Total execution time: 0.1353
DEBUG - 2022-10-05 06:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:45:44 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:15:44 --> Total execution time: 0.1072
DEBUG - 2022-10-05 06:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:16:35 --> Total execution time: 0.1363
DEBUG - 2022-10-05 06:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:46:41 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:16:41 --> Total execution time: 0.1663
DEBUG - 2022-10-05 06:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:00 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:00 --> Total execution time: 0.0994
DEBUG - 2022-10-05 06:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:47:18 --> Total execution time: 0.1192
DEBUG - 2022-10-05 06:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:21 --> Total execution time: 0.3811
DEBUG - 2022-10-05 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:47:21 --> Total execution time: 0.1409
DEBUG - 2022-10-05 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:47:21 --> Total execution time: 0.1325
DEBUG - 2022-10-05 06:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:36 --> Total execution time: 0.1147
DEBUG - 2022-10-05 06:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:43 --> Total execution time: 0.1411
DEBUG - 2022-10-05 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:47 --> Total execution time: 0.1522
DEBUG - 2022-10-05 06:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:52 --> Total execution time: 0.1912
DEBUG - 2022-10-05 06:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:54 --> Total execution time: 0.1340
DEBUG - 2022-10-05 06:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:59 --> Total execution time: 0.1324
DEBUG - 2022-10-05 06:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:18:09 --> Total execution time: 1.9383
DEBUG - 2022-10-05 06:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:48:15 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:18:15 --> Total execution time: 0.1421
DEBUG - 2022-10-05 06:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:48:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:48:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 06:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:18:50 --> Total execution time: 0.1338
DEBUG - 2022-10-05 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:04 --> Total execution time: 0.1301
DEBUG - 2022-10-05 06:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:08 --> Total execution time: 0.1379
DEBUG - 2022-10-05 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:12 --> Total execution time: 0.1488
DEBUG - 2022-10-05 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:18 --> Total execution time: 0.1507
DEBUG - 2022-10-05 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:26 --> Total execution time: 0.1599
DEBUG - 2022-10-05 06:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:29 --> Total execution time: 0.2103
DEBUG - 2022-10-05 06:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:37 --> Total execution time: 0.1918
DEBUG - 2022-10-05 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:44 --> Total execution time: 0.1284
DEBUG - 2022-10-05 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:47 --> Total execution time: 0.1511
DEBUG - 2022-10-05 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:49 --> Total execution time: 0.1282
DEBUG - 2022-10-05 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:53 --> Total execution time: 0.1446
DEBUG - 2022-10-05 06:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:54 --> Total execution time: 0.1009
DEBUG - 2022-10-05 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:56 --> Total execution time: 0.1256
DEBUG - 2022-10-05 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:19:59 --> Total execution time: 0.1388
DEBUG - 2022-10-05 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:01 --> Total execution time: 0.4508
DEBUG - 2022-10-05 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:01 --> Total execution time: 0.1266
DEBUG - 2022-10-05 06:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:03 --> Total execution time: 0.1296
DEBUG - 2022-10-05 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:04 --> Total execution time: 0.1260
DEBUG - 2022-10-05 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:05 --> Total execution time: 0.1517
DEBUG - 2022-10-05 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:07 --> Total execution time: 0.1333
DEBUG - 2022-10-05 06:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:07 --> Total execution time: 0.1737
DEBUG - 2022-10-05 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:09 --> Total execution time: 0.1528
DEBUG - 2022-10-05 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:09 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:09 --> Total execution time: 0.1353
DEBUG - 2022-10-05 06:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:11 --> Total execution time: 0.1281
DEBUG - 2022-10-05 06:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:50:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 06:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:13 --> Total execution time: 0.1349
DEBUG - 2022-10-05 06:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:14 --> Total execution time: 0.1194
DEBUG - 2022-10-05 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:50:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-05 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:16 --> Total execution time: 0.1253
DEBUG - 2022-10-05 06:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:17 --> Total execution time: 0.1405
DEBUG - 2022-10-05 06:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:19 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:19 --> Total execution time: 0.1225
DEBUG - 2022-10-05 06:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:32 --> Total execution time: 0.0981
DEBUG - 2022-10-05 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:36 --> Total execution time: 0.0829
DEBUG - 2022-10-05 06:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:42 --> Total execution time: 0.1467
DEBUG - 2022-10-05 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:20:46 --> Total execution time: 0.1657
DEBUG - 2022-10-05 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:03 --> Total execution time: 0.1277
DEBUG - 2022-10-05 06:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:23 --> Total execution time: 0.1405
DEBUG - 2022-10-05 06:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:23 --> Total execution time: 0.1385
DEBUG - 2022-10-05 06:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:29 --> Total execution time: 0.1440
DEBUG - 2022-10-05 06:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:37 --> Total execution time: 0.1439
DEBUG - 2022-10-05 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:44 --> Total execution time: 0.1315
DEBUG - 2022-10-05 06:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:48 --> Total execution time: 0.1411
DEBUG - 2022-10-05 06:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:50 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:50 --> Total execution time: 0.1705
DEBUG - 2022-10-05 06:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:51:51 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:21:51 --> Total execution time: 0.1597
DEBUG - 2022-10-05 06:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:10 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:10 --> Total execution time: 0.1293
DEBUG - 2022-10-05 06:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:16 --> Total execution time: 0.3526
DEBUG - 2022-10-05 06:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:42 --> Total execution time: 0.1306
DEBUG - 2022-10-05 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:47 --> Total execution time: 0.1491
DEBUG - 2022-10-05 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:48 --> Total execution time: 0.1330
DEBUG - 2022-10-05 06:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:56 --> Total execution time: 0.1302
DEBUG - 2022-10-05 06:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:23:16 --> Total execution time: 0.1326
DEBUG - 2022-10-05 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:23:17 --> Total execution time: 0.1274
DEBUG - 2022-10-05 06:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:23:39 --> Total execution time: 0.1387
DEBUG - 2022-10-05 06:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:23:43 --> Total execution time: 0.0805
DEBUG - 2022-10-05 06:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:23:47 --> Total execution time: 0.1558
DEBUG - 2022-10-05 06:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:23:59 --> Total execution time: 0.1359
DEBUG - 2022-10-05 06:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:24:38 --> Total execution time: 0.1403
DEBUG - 2022-10-05 06:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:24:38 --> Total execution time: 0.4167
DEBUG - 2022-10-05 06:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:24:55 --> Total execution time: 0.1264
DEBUG - 2022-10-05 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:17 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 06:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:21 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-05 06:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:22 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-05 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:25 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-05 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:27 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-05 06:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 06:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:32 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-10-05 06:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:25:32 --> Total execution time: 0.1276
DEBUG - 2022-10-05 06:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:33 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-10-05 06:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:36 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-10-05 06:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 06:55:38 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-10-05 06:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:25:41 --> Total execution time: 0.1536
DEBUG - 2022-10-05 06:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:25:52 --> Total execution time: 0.0843
DEBUG - 2022-10-05 06:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:25:53 --> Total execution time: 0.1376
DEBUG - 2022-10-05 06:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:25:53 --> Total execution time: 0.5448
DEBUG - 2022-10-05 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:26:02 --> Total execution time: 0.1743
DEBUG - 2022-10-05 06:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:26:23 --> Total execution time: 0.1372
DEBUG - 2022-10-05 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:26:49 --> Total execution time: 0.1275
DEBUG - 2022-10-05 06:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:27:02 --> Total execution time: 0.1610
DEBUG - 2022-10-05 06:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:27:16 --> Total execution time: 0.1467
DEBUG - 2022-10-05 06:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:27:34 --> Total execution time: 0.1514
DEBUG - 2022-10-05 06:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:27:43 --> Total execution time: 0.1392
DEBUG - 2022-10-05 06:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 06:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:27:45 --> Total execution time: 0.0851
DEBUG - 2022-10-05 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:27:46 --> Total execution time: 0.1454
DEBUG - 2022-10-05 06:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:28:00 --> Total execution time: 0.1636
DEBUG - 2022-10-05 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:28:06 --> Total execution time: 0.1399
DEBUG - 2022-10-05 06:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:28:19 --> Total execution time: 0.1422
DEBUG - 2022-10-05 06:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:28:31 --> Total execution time: 0.1372
DEBUG - 2022-10-05 06:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:28:39 --> Total execution time: 0.1618
DEBUG - 2022-10-05 06:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:28:50 --> Total execution time: 0.1298
DEBUG - 2022-10-05 06:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:29:03 --> Total execution time: 0.1562
DEBUG - 2022-10-05 06:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:29:32 --> Total execution time: 0.1976
DEBUG - 2022-10-05 06:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 06:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 06:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 06:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:29:58 --> Total execution time: 0.1475
DEBUG - 2022-10-05 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:03 --> Total execution time: 0.1205
DEBUG - 2022-10-05 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:06 --> Total execution time: 0.1522
DEBUG - 2022-10-05 07:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:09 --> Total execution time: 0.3595
DEBUG - 2022-10-05 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:13 --> Total execution time: 0.1474
DEBUG - 2022-10-05 07:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:15 --> Total execution time: 0.1531
DEBUG - 2022-10-05 07:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:16 --> Total execution time: 0.1791
DEBUG - 2022-10-05 07:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:18 --> Total execution time: 0.1379
DEBUG - 2022-10-05 07:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:24 --> Total execution time: 0.1797
DEBUG - 2022-10-05 07:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:31 --> Total execution time: 0.1366
DEBUG - 2022-10-05 07:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:32 --> Total execution time: 0.2100
DEBUG - 2022-10-05 07:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:30:59 --> Total execution time: 0.1352
DEBUG - 2022-10-05 07:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:31:21 --> Total execution time: 0.1316
DEBUG - 2022-10-05 07:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:31:39 --> Total execution time: 0.1305
DEBUG - 2022-10-05 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:31:55 --> Total execution time: 0.1768
DEBUG - 2022-10-05 07:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:32:36 --> Total execution time: 0.1801
DEBUG - 2022-10-05 07:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:32:38 --> Total execution time: 0.4010
DEBUG - 2022-10-05 07:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:33:25 --> Total execution time: 0.3762
DEBUG - 2022-10-05 07:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:33:55 --> Total execution time: 0.2797
DEBUG - 2022-10-05 07:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:34:26 --> Total execution time: 0.1742
DEBUG - 2022-10-05 07:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:34:29 --> Total execution time: 0.1418
DEBUG - 2022-10-05 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:35:15 --> Total execution time: 0.1399
DEBUG - 2022-10-05 07:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:35:33 --> Total execution time: 0.1349
DEBUG - 2022-10-05 07:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:35:43 --> Total execution time: 0.1384
DEBUG - 2022-10-05 07:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:05:48 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:35:48 --> Total execution time: 0.1684
DEBUG - 2022-10-05 07:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:35:53 --> Total execution time: 0.1234
DEBUG - 2022-10-05 07:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:35:59 --> Total execution time: 0.1332
DEBUG - 2022-10-05 07:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:36:07 --> Total execution time: 0.1598
DEBUG - 2022-10-05 07:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:36:21 --> Total execution time: 0.1556
DEBUG - 2022-10-05 07:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:06:47 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:36:48 --> Total execution time: 0.3428
DEBUG - 2022-10-05 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:37:35 --> Total execution time: 0.1363
DEBUG - 2022-10-05 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:37:48 --> Total execution time: 0.1660
DEBUG - 2022-10-05 07:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:37:48 --> Total execution time: 0.1327
DEBUG - 2022-10-05 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:38:15 --> Total execution time: 0.1666
DEBUG - 2022-10-05 07:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:38:25 --> Total execution time: 0.1367
DEBUG - 2022-10-05 07:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:38:27 --> Total execution time: 0.3547
DEBUG - 2022-10-05 07:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:38:43 --> Total execution time: 0.1385
DEBUG - 2022-10-05 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:38:52 --> Total execution time: 0.1473
DEBUG - 2022-10-05 07:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:06 --> Total execution time: 0.1799
DEBUG - 2022-10-05 07:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:24 --> Total execution time: 0.3733
DEBUG - 2022-10-05 07:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:25 --> Total execution time: 0.1632
DEBUG - 2022-10-05 07:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:33 --> Total execution time: 0.2166
DEBUG - 2022-10-05 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:34 --> Total execution time: 0.1328
DEBUG - 2022-10-05 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:50 --> Total execution time: 0.1401
DEBUG - 2022-10-05 07:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:51 --> Total execution time: 0.1322
DEBUG - 2022-10-05 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:39:56 --> Total execution time: 0.1777
DEBUG - 2022-10-05 07:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:40:01 --> Total execution time: 0.2337
DEBUG - 2022-10-05 07:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:40:02 --> Total execution time: 0.1989
DEBUG - 2022-10-05 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:40:15 --> Total execution time: 0.1285
DEBUG - 2022-10-05 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:40:40 --> Total execution time: 0.1396
DEBUG - 2022-10-05 07:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:40:57 --> Total execution time: 0.1503
DEBUG - 2022-10-05 07:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:04 --> Total execution time: 0.1748
DEBUG - 2022-10-05 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:05 --> Total execution time: 0.1433
DEBUG - 2022-10-05 07:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:07 --> Total execution time: 0.1290
DEBUG - 2022-10-05 07:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:10 --> Total execution time: 0.1282
DEBUG - 2022-10-05 07:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:13 --> Total execution time: 0.1276
DEBUG - 2022-10-05 07:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:13 --> Total execution time: 0.1271
DEBUG - 2022-10-05 07:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:13 --> Total execution time: 0.1391
DEBUG - 2022-10-05 07:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:14 --> Total execution time: 0.1336
DEBUG - 2022-10-05 07:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:15 --> Total execution time: 0.1282
DEBUG - 2022-10-05 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:50 --> Total execution time: 0.0942
DEBUG - 2022-10-05 07:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:51 --> Total execution time: 0.0895
DEBUG - 2022-10-05 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:41:58 --> Total execution time: 0.1350
DEBUG - 2022-10-05 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:42:14 --> Total execution time: 0.1083
DEBUG - 2022-10-05 07:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:00 --> Total execution time: 0.3793
DEBUG - 2022-10-05 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:02 --> Total execution time: 0.1472
DEBUG - 2022-10-05 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:03 --> Total execution time: 0.1460
DEBUG - 2022-10-05 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:08 --> Total execution time: 0.1435
DEBUG - 2022-10-05 07:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:12 --> Total execution time: 0.1471
DEBUG - 2022-10-05 07:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:20 --> Total execution time: 0.1307
DEBUG - 2022-10-05 07:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:20 --> Total execution time: 0.1452
DEBUG - 2022-10-05 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:23 --> Total execution time: 0.1635
DEBUG - 2022-10-05 07:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:29 --> Total execution time: 0.1332
DEBUG - 2022-10-05 07:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:29 --> Total execution time: 0.1299
DEBUG - 2022-10-05 07:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:45 --> Total execution time: 0.1411
DEBUG - 2022-10-05 07:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:49 --> Total execution time: 0.1326
DEBUG - 2022-10-05 07:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:43:53 --> Total execution time: 0.1697
DEBUG - 2022-10-05 07:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 07:13:55 --> 404 Page Not Found: User/my-courses-
DEBUG - 2022-10-05 07:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:44:00 --> Total execution time: 0.1998
DEBUG - 2022-10-05 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:44:02 --> Total execution time: 0.2098
DEBUG - 2022-10-05 07:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:44:10 --> Total execution time: 0.1449
DEBUG - 2022-10-05 07:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:44:24 --> Total execution time: 0.1355
DEBUG - 2022-10-05 07:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:44:37 --> Total execution time: 0.1515
DEBUG - 2022-10-05 07:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:02 --> Total execution time: 0.1822
DEBUG - 2022-10-05 07:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:21 --> Total execution time: 0.1562
DEBUG - 2022-10-05 07:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:35 --> Total execution time: 0.3589
DEBUG - 2022-10-05 07:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:39 --> Total execution time: 0.1257
DEBUG - 2022-10-05 07:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:42 --> Total execution time: 0.1270
DEBUG - 2022-10-05 07:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:52 --> Total execution time: 0.1633
DEBUG - 2022-10-05 07:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:46:04 --> Total execution time: 0.1412
DEBUG - 2022-10-05 07:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:46:12 --> Total execution time: 0.3581
DEBUG - 2022-10-05 07:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:46:15 --> Total execution time: 0.1456
DEBUG - 2022-10-05 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:46:19 --> Total execution time: 0.1752
DEBUG - 2022-10-05 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:46:20 --> Total execution time: 0.2166
DEBUG - 2022-10-05 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:46:24 --> Total execution time: 0.1742
DEBUG - 2022-10-05 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:02 --> Total execution time: 0.3659
DEBUG - 2022-10-05 07:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:02 --> Total execution time: 0.1341
DEBUG - 2022-10-05 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:03 --> Total execution time: 0.1677
DEBUG - 2022-10-05 07:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:10 --> Total execution time: 0.1592
DEBUG - 2022-10-05 07:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:37 --> Total execution time: 0.1328
DEBUG - 2022-10-05 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:41 --> Total execution time: 0.1335
DEBUG - 2022-10-05 07:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:47:54 --> Total execution time: 0.1372
DEBUG - 2022-10-05 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:07 --> Total execution time: 0.1367
DEBUG - 2022-10-05 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:18 --> Total execution time: 0.1425
DEBUG - 2022-10-05 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:21 --> Total execution time: 0.3633
DEBUG - 2022-10-05 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:22 --> Total execution time: 0.0818
DEBUG - 2022-10-05 07:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:41 --> Total execution time: 0.1297
DEBUG - 2022-10-05 07:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:45 --> Total execution time: 0.1650
DEBUG - 2022-10-05 07:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:55 --> Total execution time: 0.1599
DEBUG - 2022-10-05 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:48:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 07:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:08 --> Total execution time: 0.1399
DEBUG - 2022-10-05 07:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:12 --> Total execution time: 0.1335
DEBUG - 2022-10-05 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:17 --> Total execution time: 0.2055
DEBUG - 2022-10-05 07:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:21 --> Total execution time: 0.1349
DEBUG - 2022-10-05 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:31 --> Total execution time: 0.1317
DEBUG - 2022-10-05 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:33 --> Total execution time: 0.1461
DEBUG - 2022-10-05 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:35 --> Total execution time: 0.1390
DEBUG - 2022-10-05 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:38 --> Total execution time: 0.1402
DEBUG - 2022-10-05 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:38 --> Total execution time: 0.1877
DEBUG - 2022-10-05 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:39 --> Total execution time: 0.1323
DEBUG - 2022-10-05 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:42 --> Total execution time: 0.1654
DEBUG - 2022-10-05 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:50 --> Total execution time: 0.1250
DEBUG - 2022-10-05 07:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:50 --> Total execution time: 0.1309
DEBUG - 2022-10-05 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:56 --> Total execution time: 0.1515
DEBUG - 2022-10-05 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:57 --> Total execution time: 0.1788
DEBUG - 2022-10-05 07:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:49:59 --> Total execution time: 0.1370
DEBUG - 2022-10-05 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:01 --> Total execution time: 0.1616
DEBUG - 2022-10-05 07:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:05 --> Total execution time: 0.1787
DEBUG - 2022-10-05 07:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:12 --> Total execution time: 0.0802
DEBUG - 2022-10-05 07:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:14 --> Total execution time: 0.1814
DEBUG - 2022-10-05 07:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:20 --> Total execution time: 0.1680
DEBUG - 2022-10-05 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:21 --> Total execution time: 0.3353
DEBUG - 2022-10-05 07:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:50:34 --> Total execution time: 0.1375
DEBUG - 2022-10-05 07:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:06 --> Total execution time: 0.1308
DEBUG - 2022-10-05 07:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:19 --> Total execution time: 0.0792
DEBUG - 2022-10-05 07:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:28 --> Total execution time: 0.1341
DEBUG - 2022-10-05 07:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:30 --> Total execution time: 0.1615
DEBUG - 2022-10-05 07:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:36 --> Total execution time: 0.1638
DEBUG - 2022-10-05 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:37 --> Total execution time: 0.1589
DEBUG - 2022-10-05 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:38 --> Total execution time: 0.1485
DEBUG - 2022-10-05 07:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:44 --> Total execution time: 0.1605
DEBUG - 2022-10-05 07:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:51:57 --> Total execution time: 0.1592
DEBUG - 2022-10-05 07:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:21 --> Total execution time: 0.1451
DEBUG - 2022-10-05 07:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:27 --> Total execution time: 0.1603
DEBUG - 2022-10-05 07:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:32 --> Total execution time: 0.3674
DEBUG - 2022-10-05 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:35 --> Total execution time: 0.1347
DEBUG - 2022-10-05 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:36 --> Total execution time: 0.1183
DEBUG - 2022-10-05 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:37 --> Total execution time: 0.1640
DEBUG - 2022-10-05 07:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:41 --> Total execution time: 0.1308
DEBUG - 2022-10-05 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:44 --> Total execution time: 0.1309
DEBUG - 2022-10-05 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:51 --> Total execution time: 0.1322
DEBUG - 2022-10-05 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:54 --> Total execution time: 0.0835
DEBUG - 2022-10-05 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:56 --> Total execution time: 0.1634
DEBUG - 2022-10-05 07:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:52:57 --> Total execution time: 0.1334
DEBUG - 2022-10-05 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:03 --> Total execution time: 0.1354
DEBUG - 2022-10-05 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:03 --> Total execution time: 0.1341
DEBUG - 2022-10-05 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:04 --> Total execution time: 0.1286
DEBUG - 2022-10-05 07:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:10 --> Total execution time: 0.1681
DEBUG - 2022-10-05 07:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:10 --> Total execution time: 0.1617
DEBUG - 2022-10-05 07:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:16 --> Total execution time: 0.1408
DEBUG - 2022-10-05 07:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:23 --> Total execution time: 0.1386
DEBUG - 2022-10-05 07:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:24 --> Total execution time: 0.1397
DEBUG - 2022-10-05 07:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:28 --> Total execution time: 0.1330
DEBUG - 2022-10-05 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:32 --> Total execution time: 0.1379
DEBUG - 2022-10-05 07:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:38 --> Total execution time: 0.1434
DEBUG - 2022-10-05 07:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:42 --> Total execution time: 0.1485
DEBUG - 2022-10-05 07:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:42 --> Total execution time: 0.2695
DEBUG - 2022-10-05 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:50 --> Total execution time: 0.1430
DEBUG - 2022-10-05 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:50 --> Total execution time: 0.1367
DEBUG - 2022-10-05 07:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:51 --> Total execution time: 0.2047
DEBUG - 2022-10-05 07:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:51 --> Total execution time: 0.3199
DEBUG - 2022-10-05 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:54 --> Total execution time: 0.4175
DEBUG - 2022-10-05 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:55:23 --> Total execution time: 0.3595
DEBUG - 2022-10-05 07:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:57:10 --> Total execution time: 0.3777
DEBUG - 2022-10-05 07:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:57:16 --> Total execution time: 0.0893
DEBUG - 2022-10-05 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:57:19 --> Total execution time: 0.1367
DEBUG - 2022-10-05 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:57:59 --> Total execution time: 0.1340
DEBUG - 2022-10-05 07:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:58:06 --> Total execution time: 0.1752
DEBUG - 2022-10-05 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:58:41 --> Total execution time: 0.1686
DEBUG - 2022-10-05 07:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:58:49 --> Total execution time: 0.1366
DEBUG - 2022-10-05 07:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:58:53 --> Total execution time: 0.1831
DEBUG - 2022-10-05 07:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:59:01 --> Total execution time: 0.1378
DEBUG - 2022-10-05 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:59:13 --> Total execution time: 0.1402
DEBUG - 2022-10-05 07:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:59:17 --> Total execution time: 0.1881
DEBUG - 2022-10-05 07:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:06:40 --> Total execution time: 0.5466
DEBUG - 2022-10-05 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:06:52 --> Total execution time: 0.3880
DEBUG - 2022-10-05 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:06:54 --> Total execution time: 0.1691
DEBUG - 2022-10-05 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:07:02 --> Total execution time: 0.1905
DEBUG - 2022-10-05 07:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:07:28 --> Total execution time: 0.4223
DEBUG - 2022-10-05 07:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:37:56 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:07:56 --> Total execution time: 0.0978
DEBUG - 2022-10-05 07:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:39:31 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:09:31 --> Total execution time: 0.1093
DEBUG - 2022-10-05 07:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:09:40 --> Total execution time: 0.0827
DEBUG - 2022-10-05 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:10:06 --> Total execution time: 0.1343
DEBUG - 2022-10-05 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:11:06 --> Total execution time: 0.1421
DEBUG - 2022-10-05 07:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:11:12 --> Total execution time: 0.1352
DEBUG - 2022-10-05 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:11:24 --> Total execution time: 0.1311
DEBUG - 2022-10-05 07:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:12:10 --> Total execution time: 0.3481
DEBUG - 2022-10-05 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:12:35 --> Total execution time: 0.3529
DEBUG - 2022-10-05 07:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:12:41 --> Total execution time: 0.1322
DEBUG - 2022-10-05 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:12:49 --> Total execution time: 0.1352
DEBUG - 2022-10-05 07:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:13:25 --> Total execution time: 0.1409
DEBUG - 2022-10-05 07:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:13:43 --> Total execution time: 0.0841
DEBUG - 2022-10-05 07:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:13:43 --> Total execution time: 0.0719
DEBUG - 2022-10-05 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:13:44 --> Total execution time: 0.0771
DEBUG - 2022-10-05 07:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:13:45 --> Total execution time: 0.1218
DEBUG - 2022-10-05 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:14:32 --> Total execution time: 0.1305
DEBUG - 2022-10-05 07:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:45:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:15:43 --> Total execution time: 0.0841
DEBUG - 2022-10-05 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:15:47 --> Total execution time: 0.1265
DEBUG - 2022-10-05 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:16:14 --> Total execution time: 0.1448
DEBUG - 2022-10-05 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:16:29 --> Total execution time: 0.1436
DEBUG - 2022-10-05 07:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:16:33 --> Total execution time: 0.1414
DEBUG - 2022-10-05 07:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:16:41 --> Total execution time: 0.1492
DEBUG - 2022-10-05 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:16:42 --> Total execution time: 0.1345
DEBUG - 2022-10-05 07:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:17:00 --> Total execution time: 0.1337
DEBUG - 2022-10-05 07:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:17:17 --> Total execution time: 0.1349
DEBUG - 2022-10-05 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:17:23 --> Total execution time: 0.1281
DEBUG - 2022-10-05 07:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:17:29 --> Total execution time: 0.1713
DEBUG - 2022-10-05 07:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:17:32 --> Total execution time: 0.3520
DEBUG - 2022-10-05 07:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:17:46 --> Total execution time: 0.1339
DEBUG - 2022-10-05 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:48:17 --> Total execution time: 0.1506
DEBUG - 2022-10-05 07:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:48:23 --> Total execution time: 0.1495
DEBUG - 2022-10-05 07:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:18:37 --> Total execution time: 0.1267
DEBUG - 2022-10-05 07:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:18:50 --> Total execution time: 0.1374
DEBUG - 2022-10-05 07:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:48:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:18:59 --> Total execution time: 0.0943
DEBUG - 2022-10-05 07:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:49:33 --> Total execution time: 0.1724
DEBUG - 2022-10-05 07:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:49:40 --> Total execution time: 0.1570
DEBUG - 2022-10-05 07:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:19:48 --> Total execution time: 0.1554
DEBUG - 2022-10-05 07:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:19:58 --> Total execution time: 0.1395
DEBUG - 2022-10-05 07:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:20:00 --> Total execution time: 0.1394
DEBUG - 2022-10-05 07:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:20:04 --> Total execution time: 0.1653
DEBUG - 2022-10-05 07:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:20:09 --> Total execution time: 0.1503
DEBUG - 2022-10-05 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:05 --> Total execution time: 0.3547
DEBUG - 2022-10-05 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:10 --> Total execution time: 0.1498
DEBUG - 2022-10-05 07:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:15 --> Total execution time: 0.3580
DEBUG - 2022-10-05 07:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:16 --> Total execution time: 0.1511
DEBUG - 2022-10-05 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:18 --> Total execution time: 0.1330
DEBUG - 2022-10-05 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:23 --> Total execution time: 0.1670
DEBUG - 2022-10-05 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:21:27 --> Total execution time: 0.1819
DEBUG - 2022-10-05 07:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:23 --> Total execution time: 0.1615
DEBUG - 2022-10-05 07:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:24 --> Total execution time: 0.1444
DEBUG - 2022-10-05 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:26 --> Total execution time: 0.0932
DEBUG - 2022-10-05 07:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:26 --> Total execution time: 0.0791
DEBUG - 2022-10-05 07:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:28 --> Total execution time: 0.3552
DEBUG - 2022-10-05 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:32 --> Total execution time: 0.3785
DEBUG - 2022-10-05 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:32 --> Total execution time: 0.1298
DEBUG - 2022-10-05 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:34 --> Total execution time: 0.1256
DEBUG - 2022-10-05 07:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:42 --> Total execution time: 0.1743
DEBUG - 2022-10-05 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:44 --> Total execution time: 0.3965
DEBUG - 2022-10-05 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:50 --> Total execution time: 0.1280
DEBUG - 2022-10-05 07:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:51 --> Total execution time: 0.1452
DEBUG - 2022-10-05 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:22:55 --> Total execution time: 0.1590
DEBUG - 2022-10-05 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:23:00 --> Total execution time: 0.1724
DEBUG - 2022-10-05 07:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:53:25 --> Total execution time: 0.1496
DEBUG - 2022-10-05 07:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:53:29 --> Total execution time: 0.1494
DEBUG - 2022-10-05 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:53:44 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:23:44 --> Total execution time: 0.0857
DEBUG - 2022-10-05 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:07 --> Total execution time: 0.1472
DEBUG - 2022-10-05 07:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:09 --> Total execution time: 0.1570
DEBUG - 2022-10-05 07:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:27 --> Total execution time: 0.1395
DEBUG - 2022-10-05 07:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:35 --> Total execution time: 0.1331
DEBUG - 2022-10-05 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:38 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:38 --> Total execution time: 0.1273
DEBUG - 2022-10-05 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:45 --> Total execution time: 0.1243
DEBUG - 2022-10-05 07:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:24:49 --> Total execution time: 0.1334
DEBUG - 2022-10-05 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:25:18 --> Total execution time: 0.1358
DEBUG - 2022-10-05 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:25:26 --> Total execution time: 0.1554
DEBUG - 2022-10-05 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:26:29 --> Total execution time: 0.1287
DEBUG - 2022-10-05 07:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:26:31 --> Total execution time: 0.1280
DEBUG - 2022-10-05 07:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:57:24 --> Total execution time: 0.1332
DEBUG - 2022-10-05 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 07:57:43 --> Total execution time: 0.1439
DEBUG - 2022-10-05 07:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:57:47 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:27:47 --> Total execution time: 0.1643
DEBUG - 2022-10-05 07:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:29:16 --> Total execution time: 0.3431
DEBUG - 2022-10-05 07:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 07:59:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 07:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 07:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:29:24 --> Total execution time: 0.3833
DEBUG - 2022-10-05 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:30:02 --> Total execution time: 0.1531
DEBUG - 2022-10-05 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:00:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:30:08 --> Total execution time: 0.1546
DEBUG - 2022-10-05 08:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:00:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:30:21 --> Total execution time: 0.1435
DEBUG - 2022-10-05 08:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:00:25 --> Total execution time: 0.1336
DEBUG - 2022-10-05 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:00:27 --> Total execution time: 0.1346
DEBUG - 2022-10-05 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:00:28 --> Total execution time: 0.1697
DEBUG - 2022-10-05 08:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:31:10 --> Total execution time: 2.5186
DEBUG - 2022-10-05 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 08:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:48 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:31:48 --> Total execution time: 0.0817
DEBUG - 2022-10-05 08:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:49 --> 404 Page Not Found: Wp/index
DEBUG - 2022-10-05 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:50 --> 404 Page Not Found: Wordpress/index
DEBUG - 2022-10-05 08:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:51 --> 404 Page Not Found: Esalestrix/index
DEBUG - 2022-10-05 08:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:52 --> 404 Page Not Found: Esalestrix/index
DEBUG - 2022-10-05 08:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:53 --> 404 Page Not Found: Wordpress1/index
DEBUG - 2022-10-05 08:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:54 --> 404 Page Not Found: Old1/index
DEBUG - 2022-10-05 08:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:55 --> 404 Page Not Found: Old2/index
DEBUG - 2022-10-05 08:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:55 --> 404 Page Not Found: Back/index
DEBUG - 2022-10-05 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:56 --> 404 Page Not Found: Copy/index
DEBUG - 2022-10-05 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:31:56 --> Total execution time: 0.1384
DEBUG - 2022-10-05 08:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:57 --> 404 Page Not Found: OLDSITE/index
DEBUG - 2022-10-05 08:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:57 --> 404 Page Not Found: Beta/index
DEBUG - 2022-10-05 08:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:58 --> 404 Page Not Found: Staging/index
DEBUG - 2022-10-05 08:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:58 --> 404 Page Not Found: BKP/index
DEBUG - 2022-10-05 08:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:01:59 --> 404 Page Not Found: Old-site/index
DEBUG - 2022-10-05 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:00 --> 404 Page Not Found: 123/index
DEBUG - 2022-10-05 08:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:01 --> 404 Page Not Found: Oldwebsite/index
DEBUG - 2022-10-05 08:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:02 --> 404 Page Not Found: Old/index
DEBUG - 2022-10-05 08:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:03 --> 404 Page Not Found: WP/index
DEBUG - 2022-10-05 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:04 --> 404 Page Not Found: Blog/index
DEBUG - 2022-10-05 08:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:32:05 --> Total execution time: 0.1663
DEBUG - 2022-10-05 08:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:05 --> 404 Page Not Found: Dev/index
DEBUG - 2022-10-05 08:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:05 --> 404 Page Not Found: Newsite/index
DEBUG - 2022-10-05 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:06 --> 404 Page Not Found: Bkp/index
DEBUG - 2022-10-05 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:07 --> 404 Page Not Found: Test/index
DEBUG - 2022-10-05 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:32:07 --> Total execution time: 0.1591
DEBUG - 2022-10-05 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:07 --> 404 Page Not Found: Home/index
DEBUG - 2022-10-05 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:08 --> 404 Page Not Found: BACKUP/index
DEBUG - 2022-10-05 08:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:09 --> 404 Page Not Found: Old_files/index
DEBUG - 2022-10-05 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:10 --> 404 Page Not Found: Old/index
DEBUG - 2022-10-05 08:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:11 --> 404 Page Not Found: Demo/index
DEBUG - 2022-10-05 08:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:11 --> 404 Page Not Found: Site/index
DEBUG - 2022-10-05 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:12 --> 404 Page Not Found: Wordpress-old/index
DEBUG - 2022-10-05 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:12 --> 404 Page Not Found: Backup/index
DEBUG - 2022-10-05 08:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:13 --> 404 Page Not Found: Members/index
DEBUG - 2022-10-05 08:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:14 --> 404 Page Not Found: Bkp-two/index
DEBUG - 2022-10-05 08:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:15 --> 404 Page Not Found: Sitebackup/index
DEBUG - 2022-10-05 08:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:16 --> 404 Page Not Found: Backup-new/index
DEBUG - 2022-10-05 18:32:16 --> Total execution time: 0.1322
DEBUG - 2022-10-05 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:17 --> 404 Page Not Found: BAK/index
DEBUG - 2022-10-05 08:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:02:18 --> 404 Page Not Found: Site_old/index
DEBUG - 2022-10-05 08:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:23 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:32:23 --> Total execution time: 0.0870
DEBUG - 2022-10-05 18:32:23 --> Total execution time: 1.7608
DEBUG - 2022-10-05 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:32:25 --> Total execution time: 0.1598
DEBUG - 2022-10-05 08:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:32:39 --> Total execution time: 0.1464
DEBUG - 2022-10-05 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:03:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:33:17 --> Total execution time: 0.1644
DEBUG - 2022-10-05 08:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:33:25 --> Total execution time: 1.7940
DEBUG - 2022-10-05 08:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:34:09 --> Total execution time: 0.1312
DEBUG - 2022-10-05 08:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:34:19 --> Total execution time: 0.1679
DEBUG - 2022-10-05 08:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:34:25 --> Total execution time: 0.0909
DEBUG - 2022-10-05 08:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:34:41 --> Total execution time: 0.1403
DEBUG - 2022-10-05 08:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:35:00 --> Total execution time: 0.1386
DEBUG - 2022-10-05 08:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:05:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:35:28 --> Total execution time: 0.3518
DEBUG - 2022-10-05 08:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:36:16 --> Total execution time: 0.1317
DEBUG - 2022-10-05 18:36:16 --> Total execution time: 1.8592
DEBUG - 2022-10-05 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:06:21 --> Total execution time: 0.1316
DEBUG - 2022-10-05 18:36:21 --> Total execution time: 2.1877
DEBUG - 2022-10-05 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:06:23 --> Total execution time: 0.1621
DEBUG - 2022-10-05 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:06:23 --> Total execution time: 0.1557
DEBUG - 2022-10-05 08:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:26 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:36:26 --> Total execution time: 0.1424
DEBUG - 2022-10-05 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:36:54 --> Total execution time: 1.8562
DEBUG - 2022-10-05 08:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:37:18 --> Total execution time: 0.1326
DEBUG - 2022-10-05 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:37:25 --> Total execution time: 0.1337
DEBUG - 2022-10-05 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:37:31 --> Total execution time: 0.2402
DEBUG - 2022-10-05 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:09:13 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:39:13 --> Total execution time: 0.3520
DEBUG - 2022-10-05 08:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:09:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:39:14 --> Total execution time: 0.1432
DEBUG - 2022-10-05 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:39:43 --> Total execution time: 0.1482
DEBUG - 2022-10-05 08:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:39:49 --> Total execution time: 0.1627
DEBUG - 2022-10-05 08:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:10:21 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:40:22 --> Total execution time: 0.1063
DEBUG - 2022-10-05 08:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:10:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:40:26 --> Total execution time: 0.1661
DEBUG - 2022-10-05 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:40:42 --> Total execution time: 0.0843
DEBUG - 2022-10-05 08:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:10:48 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:40:48 --> Total execution time: 0.0874
DEBUG - 2022-10-05 08:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:40:57 --> Total execution time: 0.1318
DEBUG - 2022-10-05 08:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:41:04 --> Total execution time: 0.1347
DEBUG - 2022-10-05 08:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:41:19 --> Total execution time: 0.1437
DEBUG - 2022-10-05 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:44:11 --> Total execution time: 0.4308
DEBUG - 2022-10-05 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:44:23 --> Total execution time: 0.1747
DEBUG - 2022-10-05 08:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:44:52 --> Total execution time: 0.1819
DEBUG - 2022-10-05 08:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:46:16 --> Total execution time: 0.1004
DEBUG - 2022-10-05 08:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:46:35 --> Total execution time: 0.1288
DEBUG - 2022-10-05 08:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:16:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:46:45 --> Total execution time: 0.0913
DEBUG - 2022-10-05 08:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:46:48 --> Total execution time: 0.1273
DEBUG - 2022-10-05 08:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:47:05 --> Total execution time: 0.1356
DEBUG - 2022-10-05 08:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:47:06 --> Total execution time: 0.0790
DEBUG - 2022-10-05 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:47:26 --> Total execution time: 0.1402
DEBUG - 2022-10-05 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:47:33 --> Total execution time: 0.1416
DEBUG - 2022-10-05 08:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:47:37 --> Total execution time: 0.1493
DEBUG - 2022-10-05 08:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:10 --> Total execution time: 0.1262
DEBUG - 2022-10-05 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:27 --> Total execution time: 0.1381
DEBUG - 2022-10-05 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:27 --> Total execution time: 0.3538
DEBUG - 2022-10-05 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:36 --> Total execution time: 0.1368
DEBUG - 2022-10-05 08:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:40 --> Total execution time: 0.1298
DEBUG - 2022-10-05 08:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:40 --> Total execution time: 0.1554
DEBUG - 2022-10-05 08:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:48:47 --> Total execution time: 0.1410
DEBUG - 2022-10-05 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:01 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:01 --> Total execution time: 0.1057
DEBUG - 2022-10-05 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:02 --> Total execution time: 0.1406
DEBUG - 2022-10-05 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:19:26 --> Total execution time: 0.1322
DEBUG - 2022-10-05 08:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:29 --> Total execution time: 0.1362
DEBUG - 2022-10-05 08:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:36 --> Total execution time: 0.1335
DEBUG - 2022-10-05 08:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:37 --> Total execution time: 0.1282
DEBUG - 2022-10-05 08:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:38 --> Total execution time: 0.3750
DEBUG - 2022-10-05 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:41 --> Total execution time: 0.1406
DEBUG - 2022-10-05 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:49:50 --> Total execution time: 0.1359
DEBUG - 2022-10-05 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:04 --> Total execution time: 0.1353
DEBUG - 2022-10-05 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:16 --> Total execution time: 0.1867
DEBUG - 2022-10-05 08:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:41 --> Total execution time: 0.1379
DEBUG - 2022-10-05 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:42 --> Total execution time: 0.1213
DEBUG - 2022-10-05 08:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:47 --> Total execution time: 0.1394
DEBUG - 2022-10-05 08:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:54 --> Total execution time: 0.1390
DEBUG - 2022-10-05 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:54 --> Total execution time: 0.1724
DEBUG - 2022-10-05 08:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:20:59 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:50:59 --> Total execution time: 0.1371
DEBUG - 2022-10-05 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:07 --> Total execution time: 0.1722
DEBUG - 2022-10-05 08:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:07 --> Total execution time: 0.3684
DEBUG - 2022-10-05 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:08 --> Total execution time: 0.1205
DEBUG - 2022-10-05 08:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:15 --> Total execution time: 0.1228
DEBUG - 2022-10-05 08:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:38 --> Total execution time: 0.1265
DEBUG - 2022-10-05 08:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:42 --> Total execution time: 0.1433
DEBUG - 2022-10-05 08:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:46 --> Total execution time: 0.1943
DEBUG - 2022-10-05 08:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:53 --> Total execution time: 0.1462
DEBUG - 2022-10-05 08:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:01 --> Total execution time: 0.1375
DEBUG - 2022-10-05 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:03 --> Total execution time: 0.1859
DEBUG - 2022-10-05 08:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:06 --> Total execution time: 0.1308
DEBUG - 2022-10-05 08:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:07 --> Total execution time: 0.1554
DEBUG - 2022-10-05 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:10 --> Total execution time: 0.1823
DEBUG - 2022-10-05 08:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:11 --> Total execution time: 0.1376
DEBUG - 2022-10-05 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:13 --> Total execution time: 0.1275
DEBUG - 2022-10-05 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:20 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:20 --> Total execution time: 0.1441
DEBUG - 2022-10-05 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:21 --> Total execution time: 0.1936
DEBUG - 2022-10-05 08:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:27 --> Total execution time: 0.1607
DEBUG - 2022-10-05 08:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:22:30 --> Total execution time: 0.1422
DEBUG - 2022-10-05 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:22:33 --> Total execution time: 0.1480
DEBUG - 2022-10-05 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:22:34 --> Total execution time: 0.1358
DEBUG - 2022-10-05 08:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:39 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:39 --> Total execution time: 0.0815
DEBUG - 2022-10-05 08:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:42 --> Total execution time: 0.1306
DEBUG - 2022-10-05 08:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:49 --> Total execution time: 0.1113
DEBUG - 2022-10-05 08:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:02 --> Total execution time: 0.1469
DEBUG - 2022-10-05 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:03 --> Total execution time: 0.1410
DEBUG - 2022-10-05 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:14 --> Total execution time: 0.1509
DEBUG - 2022-10-05 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:21 --> Total execution time: 0.2130
DEBUG - 2022-10-05 08:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:25 --> Total execution time: 0.1509
DEBUG - 2022-10-05 08:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:34 --> Total execution time: 2.4940
DEBUG - 2022-10-05 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:34 --> Total execution time: 2.5514
DEBUG - 2022-10-05 08:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:35 --> Total execution time: 0.1337
DEBUG - 2022-10-05 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:23:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 08:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 08:23:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:47 --> Total execution time: 0.1508
DEBUG - 2022-10-05 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:47 --> Total execution time: 0.1488
DEBUG - 2022-10-05 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:47 --> Total execution time: 0.1515
DEBUG - 2022-10-05 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:53:54 --> Total execution time: 0.2000
DEBUG - 2022-10-05 08:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:00 --> Total execution time: 1.8716
DEBUG - 2022-10-05 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:10 --> Total execution time: 0.1448
DEBUG - 2022-10-05 08:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:14 --> Total execution time: 0.1568
DEBUG - 2022-10-05 08:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:28 --> Total execution time: 1.7700
DEBUG - 2022-10-05 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:44 --> Total execution time: 0.1428
DEBUG - 2022-10-05 08:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:48 --> Total execution time: 0.1811
DEBUG - 2022-10-05 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:53 --> Total execution time: 0.1836
DEBUG - 2022-10-05 08:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:54:58 --> Total execution time: 0.1323
DEBUG - 2022-10-05 08:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:55:04 --> Total execution time: 0.1422
DEBUG - 2022-10-05 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:55:08 --> Total execution time: 0.1338
DEBUG - 2022-10-05 08:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:55:36 --> Total execution time: 0.1604
DEBUG - 2022-10-05 08:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:56:32 --> Total execution time: 0.3793
DEBUG - 2022-10-05 08:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:56:41 --> Total execution time: 0.1954
DEBUG - 2022-10-05 08:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:56:46 --> Total execution time: 0.2155
DEBUG - 2022-10-05 08:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:56:52 --> Total execution time: 0.1285
DEBUG - 2022-10-05 08:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:57:00 --> Total execution time: 0.1361
DEBUG - 2022-10-05 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:27:02 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:57:02 --> Total execution time: 0.0911
DEBUG - 2022-10-05 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:57:16 --> Total execution time: 0.1609
DEBUG - 2022-10-05 08:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:57:25 --> Total execution time: 0.1743
DEBUG - 2022-10-05 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:29:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:59:06 --> Total execution time: 0.1009
DEBUG - 2022-10-05 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:15 --> Total execution time: 0.1301
DEBUG - 2022-10-05 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:19 --> Total execution time: 0.1394
DEBUG - 2022-10-05 08:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:25 --> Total execution time: 0.3612
DEBUG - 2022-10-05 08:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:27 --> Total execution time: 0.1408
DEBUG - 2022-10-05 08:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:34 --> Total execution time: 0.1790
DEBUG - 2022-10-05 08:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:36 --> Total execution time: 0.1747
DEBUG - 2022-10-05 08:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:37 --> Total execution time: 0.1665
DEBUG - 2022-10-05 08:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:45 --> Total execution time: 0.1273
DEBUG - 2022-10-05 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:51 --> Total execution time: 0.1343
DEBUG - 2022-10-05 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:54 --> Total execution time: 0.1970
DEBUG - 2022-10-05 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:00:58 --> Total execution time: 0.1301
DEBUG - 2022-10-05 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:00 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:00 --> Total execution time: 0.0858
DEBUG - 2022-10-05 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:03 --> Total execution time: 0.1744
DEBUG - 2022-10-05 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:07 --> Total execution time: 0.1335
DEBUG - 2022-10-05 08:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:09 --> Total execution time: 0.1633
DEBUG - 2022-10-05 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:15 --> Total execution time: 0.1367
DEBUG - 2022-10-05 08:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:18 --> Total execution time: 0.1440
DEBUG - 2022-10-05 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:01:20 --> Total execution time: 0.3092
DEBUG - 2022-10-05 08:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:02:19 --> Total execution time: 0.1665
DEBUG - 2022-10-05 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:03:34 --> Total execution time: 0.3974
DEBUG - 2022-10-05 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:04:00 --> Total execution time: 0.3554
DEBUG - 2022-10-05 08:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:04:21 --> Total execution time: 0.1652
DEBUG - 2022-10-05 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:04:21 --> Total execution time: 0.2558
DEBUG - 2022-10-05 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:04:21 --> Total execution time: 0.2686
DEBUG - 2022-10-05 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:04:21 --> Total execution time: 0.3477
DEBUG - 2022-10-05 08:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:09 --> Total execution time: 0.1225
DEBUG - 2022-10-05 08:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:10 --> Total execution time: 0.1528
DEBUG - 2022-10-05 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:14 --> Total execution time: 0.1241
DEBUG - 2022-10-05 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:31 --> Total execution time: 0.1402
DEBUG - 2022-10-05 08:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:41 --> Total execution time: 0.4059
DEBUG - 2022-10-05 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:45 --> Total execution time: 0.1447
DEBUG - 2022-10-05 08:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:05:58 --> Total execution time: 0.1608
DEBUG - 2022-10-05 08:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:06:00 --> Total execution time: 0.1345
DEBUG - 2022-10-05 08:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:36:16 --> Total execution time: 0.1326
DEBUG - 2022-10-05 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:36:24 --> Total execution time: 0.1724
DEBUG - 2022-10-05 08:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:07:00 --> Total execution time: 0.1393
DEBUG - 2022-10-05 08:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:07:10 --> Total execution time: 0.1384
DEBUG - 2022-10-05 08:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:07:32 --> Total execution time: 0.3815
DEBUG - 2022-10-05 08:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:37:41 --> Total execution time: 0.1482
DEBUG - 2022-10-05 08:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:37:46 --> Total execution time: 0.1477
DEBUG - 2022-10-05 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:08:20 --> Total execution time: 0.1424
DEBUG - 2022-10-05 08:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:08:31 --> Total execution time: 0.1700
DEBUG - 2022-10-05 08:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:08:33 --> Total execution time: 0.1400
DEBUG - 2022-10-05 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:08:38 --> Total execution time: 0.1387
DEBUG - 2022-10-05 08:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:08:48 --> Total execution time: 0.1397
DEBUG - 2022-10-05 08:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:38:49 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:08:49 --> Total execution time: 0.0976
DEBUG - 2022-10-05 08:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:39:00 --> Total execution time: 0.1086
DEBUG - 2022-10-05 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:39:03 --> Total execution time: 0.1685
DEBUG - 2022-10-05 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:39:04 --> Total execution time: 0.1380
DEBUG - 2022-10-05 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:09:43 --> Total execution time: 0.1323
DEBUG - 2022-10-05 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:11:47 --> Total execution time: 0.1448
DEBUG - 2022-10-05 08:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:42:52 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:12:52 --> Total execution time: 0.0978
DEBUG - 2022-10-05 08:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:12:54 --> Total execution time: 0.1687
DEBUG - 2022-10-05 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:13:05 --> Total execution time: 0.2793
DEBUG - 2022-10-05 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:13:59 --> Total execution time: 0.2950
DEBUG - 2022-10-05 08:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:13:59 --> Total execution time: 0.3618
DEBUG - 2022-10-05 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:14:06 --> Total execution time: 0.1626
DEBUG - 2022-10-05 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:14:26 --> Total execution time: 0.3808
DEBUG - 2022-10-05 08:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:14:35 --> Total execution time: 0.3785
DEBUG - 2022-10-05 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:16:14 --> Total execution time: 0.0863
DEBUG - 2022-10-05 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:16:36 --> Total execution time: 0.1400
DEBUG - 2022-10-05 08:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:16:45 --> Total execution time: 0.1459
DEBUG - 2022-10-05 08:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:16:49 --> Total execution time: 0.1798
DEBUG - 2022-10-05 08:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:16:54 --> Total execution time: 0.1376
DEBUG - 2022-10-05 08:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:17:23 --> Total execution time: 0.0877
DEBUG - 2022-10-05 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:17:29 --> Total execution time: 0.1313
DEBUG - 2022-10-05 08:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:17:46 --> Total execution time: 0.1601
DEBUG - 2022-10-05 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:17:49 --> Total execution time: 0.1356
DEBUG - 2022-10-05 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:17:54 --> Total execution time: 0.1843
DEBUG - 2022-10-05 08:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:18:01 --> Total execution time: 0.2369
DEBUG - 2022-10-05 08:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:18:22 --> Total execution time: 0.1538
DEBUG - 2022-10-05 08:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:18:47 --> Total execution time: 0.1464
DEBUG - 2022-10-05 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:19:10 --> Total execution time: 0.1889
DEBUG - 2022-10-05 08:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:20:36 --> Total execution time: 0.0840
DEBUG - 2022-10-05 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:20:42 --> Total execution time: 0.3434
DEBUG - 2022-10-05 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:20:47 --> Total execution time: 0.1318
DEBUG - 2022-10-05 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:20:54 --> Total execution time: 0.1313
DEBUG - 2022-10-05 08:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:54:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:24:04 --> Total execution time: 0.1545
DEBUG - 2022-10-05 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:54:28 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:24:28 --> Total execution time: 0.1008
DEBUG - 2022-10-05 08:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:24:40 --> Total execution time: 0.0809
DEBUG - 2022-10-05 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:24:49 --> Total execution time: 0.1367
DEBUG - 2022-10-05 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:25:03 --> Total execution time: 0.2202
DEBUG - 2022-10-05 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:58:58 --> No URI present. Default controller set.
DEBUG - 2022-10-05 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:28:58 --> Total execution time: 0.1353
DEBUG - 2022-10-05 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:29:18 --> Total execution time: 0.0847
DEBUG - 2022-10-05 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 08:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:29:35 --> Total execution time: 0.1470
DEBUG - 2022-10-05 08:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 08:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 08:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:29:56 --> Total execution time: 0.1677
DEBUG - 2022-10-05 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:30:02 --> Total execution time: 0.1094
DEBUG - 2022-10-05 09:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:30:11 --> Total execution time: 0.4067
DEBUG - 2022-10-05 09:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:30:23 --> Total execution time: 0.1600
DEBUG - 2022-10-05 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:31:09 --> Total execution time: 0.1505
DEBUG - 2022-10-05 09:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:31:20 --> Total execution time: 0.1657
DEBUG - 2022-10-05 09:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:31:43 --> Total execution time: 0.2072
DEBUG - 2022-10-05 09:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:32:39 --> Total execution time: 0.1616
DEBUG - 2022-10-05 09:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:32:54 --> Total execution time: 0.3921
DEBUG - 2022-10-05 09:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:33:06 --> Total execution time: 0.1470
DEBUG - 2022-10-05 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:33:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:33:20 --> Total execution time: 0.1720
DEBUG - 2022-10-05 09:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:33:43 --> Total execution time: 0.1366
DEBUG - 2022-10-05 09:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:33:55 --> Total execution time: 0.1951
DEBUG - 2022-10-05 09:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:34:16 --> Total execution time: 0.1595
DEBUG - 2022-10-05 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:34:38 --> Total execution time: 0.4269
DEBUG - 2022-10-05 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:35:13 --> Total execution time: 0.1808
DEBUG - 2022-10-05 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:35:48 --> Total execution time: 0.1667
DEBUG - 2022-10-05 09:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:35:56 --> Total execution time: 0.1364
DEBUG - 2022-10-05 09:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:36:01 --> Total execution time: 0.1835
DEBUG - 2022-10-05 09:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:38:53 --> Total execution time: 0.4867
DEBUG - 2022-10-05 09:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:08:55 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:38:55 --> Total execution time: 0.0882
DEBUG - 2022-10-05 09:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:39:01 --> Total execution time: 0.2204
DEBUG - 2022-10-05 09:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:39:41 --> Total execution time: 0.1424
DEBUG - 2022-10-05 09:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:39:42 --> Total execution time: 0.1346
DEBUG - 2022-10-05 09:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:39:45 --> Total execution time: 0.3509
DEBUG - 2022-10-05 09:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:39:51 --> Total execution time: 0.1357
DEBUG - 2022-10-05 09:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:39:54 --> Total execution time: 0.1327
DEBUG - 2022-10-05 09:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:40:12 --> Total execution time: 0.0954
DEBUG - 2022-10-05 09:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:40:14 --> Total execution time: 0.1438
DEBUG - 2022-10-05 09:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:40:54 --> Total execution time: 0.4037
DEBUG - 2022-10-05 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:41:07 --> Total execution time: 0.1264
DEBUG - 2022-10-05 09:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:41:08 --> Total execution time: 0.1308
DEBUG - 2022-10-05 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:41:15 --> Total execution time: 0.1758
DEBUG - 2022-10-05 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:42:02 --> Total execution time: 0.1439
DEBUG - 2022-10-05 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:12:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:42:27 --> Total execution time: 0.0880
DEBUG - 2022-10-05 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:42:35 --> Total execution time: 0.1353
DEBUG - 2022-10-05 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:42:35 --> Total execution time: 0.1430
DEBUG - 2022-10-05 09:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:42:37 --> Total execution time: 0.1328
DEBUG - 2022-10-05 09:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:42:57 --> Total execution time: 0.1718
DEBUG - 2022-10-05 09:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:43:04 --> Total execution time: 0.1267
DEBUG - 2022-10-05 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:43:36 --> Total execution time: 0.0877
DEBUG - 2022-10-05 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:13:43 --> Total execution time: 0.1369
DEBUG - 2022-10-05 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:43:44 --> Total execution time: 0.3538
DEBUG - 2022-10-05 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:13:46 --> Total execution time: 0.1462
DEBUG - 2022-10-05 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:13:47 --> Total execution time: 0.1269
DEBUG - 2022-10-05 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:43:47 --> Total execution time: 0.1894
DEBUG - 2022-10-05 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:14:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:44:25 --> Total execution time: 0.1382
DEBUG - 2022-10-05 09:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:45:23 --> Total execution time: 0.1341
DEBUG - 2022-10-05 09:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:45:23 --> Total execution time: 0.1226
DEBUG - 2022-10-05 09:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:45:27 --> Total execution time: 0.3540
DEBUG - 2022-10-05 09:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:15:54 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:45:54 --> Total execution time: 0.3689
DEBUG - 2022-10-05 09:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:45:59 --> Total execution time: 0.3945
DEBUG - 2022-10-05 09:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:46:18 --> Total execution time: 0.1471
DEBUG - 2022-10-05 09:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:46:25 --> Total execution time: 0.1340
DEBUG - 2022-10-05 09:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:46:27 --> Total execution time: 0.1334
DEBUG - 2022-10-05 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:46:37 --> Total execution time: 0.1521
DEBUG - 2022-10-05 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:46:41 --> Total execution time: 0.1546
DEBUG - 2022-10-05 09:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:46:49 --> Total execution time: 0.1548
DEBUG - 2022-10-05 09:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:47:04 --> Total execution time: 0.1367
DEBUG - 2022-10-05 09:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:47:43 --> Total execution time: 0.1301
DEBUG - 2022-10-05 09:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:47:43 --> Total execution time: 0.1316
DEBUG - 2022-10-05 09:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:21 --> Total execution time: 0.1580
DEBUG - 2022-10-05 09:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:22 --> Total execution time: 0.1823
DEBUG - 2022-10-05 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:39 --> Total execution time: 0.1324
DEBUG - 2022-10-05 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:58 --> Total execution time: 0.1292
DEBUG - 2022-10-05 09:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:50:03 --> Total execution time: 0.1460
DEBUG - 2022-10-05 09:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:51:07 --> Total execution time: 0.1365
DEBUG - 2022-10-05 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:52:55 --> Total execution time: 0.1547
DEBUG - 2022-10-05 09:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:52:56 --> Total execution time: 0.1417
DEBUG - 2022-10-05 09:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:53:13 --> Total execution time: 0.3444
DEBUG - 2022-10-05 09:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:53:46 --> Total execution time: 0.1323
DEBUG - 2022-10-05 09:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:53:47 --> Total execution time: 0.1278
DEBUG - 2022-10-05 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:53:48 --> Total execution time: 0.1330
DEBUG - 2022-10-05 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:54:31 --> Total execution time: 0.3459
DEBUG - 2022-10-05 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:54:36 --> Total execution time: 0.1270
DEBUG - 2022-10-05 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:57:22 --> Total execution time: 0.4521
DEBUG - 2022-10-05 09:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:57:26 --> Total execution time: 0.4743
DEBUG - 2022-10-05 09:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:57:38 --> Total execution time: 0.1437
DEBUG - 2022-10-05 09:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:27:51 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:57:51 --> Total execution time: 0.0868
DEBUG - 2022-10-05 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:28:05 --> Total execution time: 0.1407
DEBUG - 2022-10-05 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:28:14 --> Total execution time: 0.1339
DEBUG - 2022-10-05 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:28:14 --> Total execution time: 0.2497
DEBUG - 2022-10-05 09:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:31:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:01:24 --> Total execution time: 0.1573
DEBUG - 2022-10-05 09:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:31:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:01:24 --> Total execution time: 0.0830
DEBUG - 2022-10-05 09:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:01:34 --> Total execution time: 0.1506
DEBUG - 2022-10-05 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:01:49 --> Total execution time: 0.1373
DEBUG - 2022-10-05 09:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:01:54 --> Total execution time: 0.1396
DEBUG - 2022-10-05 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:02:04 --> Total execution time: 0.1320
DEBUG - 2022-10-05 09:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:02:37 --> Total execution time: 2.2254
DEBUG - 2022-10-05 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 09:32:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:01 --> Total execution time: 0.3846
DEBUG - 2022-10-05 09:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:11 --> Total execution time: 0.0915
DEBUG - 2022-10-05 09:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:16 --> Total execution time: 0.1132
DEBUG - 2022-10-05 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:18 --> Total execution time: 0.1707
DEBUG - 2022-10-05 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:19 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:19 --> Total execution time: 0.0869
DEBUG - 2022-10-05 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:19 --> Total execution time: 0.1567
DEBUG - 2022-10-05 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:21 --> Total execution time: 0.1271
DEBUG - 2022-10-05 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:22 --> Total execution time: 0.0836
DEBUG - 2022-10-05 09:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:24 --> Total execution time: 0.1316
DEBUG - 2022-10-05 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 09:34:26 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-10-05 09:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 09:34:27 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-10-05 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 09:34:28 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-10-05 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 09:34:28 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-10-05 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:34 --> Total execution time: 0.1439
DEBUG - 2022-10-05 09:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:51 --> Total execution time: 0.1374
DEBUG - 2022-10-05 09:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:51 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:52 --> Total execution time: 0.3697
DEBUG - 2022-10-05 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:04:58 --> Total execution time: 0.1672
DEBUG - 2022-10-05 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:35:01 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:05:01 --> Total execution time: 0.1690
DEBUG - 2022-10-05 09:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:05:06 --> Total execution time: 0.1620
DEBUG - 2022-10-05 09:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:05:17 --> Total execution time: 0.1294
DEBUG - 2022-10-05 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:05:49 --> Total execution time: 0.1339
DEBUG - 2022-10-05 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:05:59 --> Total execution time: 0.1332
DEBUG - 2022-10-05 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:06:03 --> Total execution time: 0.1310
DEBUG - 2022-10-05 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:06:12 --> Total execution time: 0.2782
DEBUG - 2022-10-05 09:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:06:19 --> Total execution time: 0.2059
DEBUG - 2022-10-05 09:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:06:19 --> Total execution time: 0.3806
DEBUG - 2022-10-05 09:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:06:51 --> Total execution time: 0.3534
DEBUG - 2022-10-05 09:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:39:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:09:11 --> Total execution time: 0.1363
DEBUG - 2022-10-05 09:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:39:54 --> Total execution time: 0.1717
DEBUG - 2022-10-05 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:39:57 --> Total execution time: 0.1286
DEBUG - 2022-10-05 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:39:57 --> Total execution time: 0.1364
DEBUG - 2022-10-05 09:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:12:33 --> Total execution time: 0.1769
DEBUG - 2022-10-05 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:45:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:15:12 --> Total execution time: 0.1420
DEBUG - 2022-10-05 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:45:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:15:13 --> Total execution time: 0.1297
DEBUG - 2022-10-05 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:16:01 --> Total execution time: 0.0822
DEBUG - 2022-10-05 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:16:08 --> Total execution time: 0.1459
DEBUG - 2022-10-05 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:16:13 --> Total execution time: 0.1718
DEBUG - 2022-10-05 09:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:16:18 --> Total execution time: 0.1381
DEBUG - 2022-10-05 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:17:22 --> Total execution time: 0.1382
DEBUG - 2022-10-05 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:17:35 --> Total execution time: 0.1316
DEBUG - 2022-10-05 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:47:56 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:17:56 --> Total execution time: 0.3985
DEBUG - 2022-10-05 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:48:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:18:11 --> Total execution time: 0.0817
DEBUG - 2022-10-05 09:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:19:09 --> Total execution time: 0.1250
DEBUG - 2022-10-05 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:19:26 --> Total execution time: 0.1268
DEBUG - 2022-10-05 09:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:19:39 --> Total execution time: 0.3927
DEBUG - 2022-10-05 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:19:44 --> Total execution time: 0.1465
DEBUG - 2022-10-05 09:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:50:06 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:20:06 --> Total execution time: 0.1269
DEBUG - 2022-10-05 09:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:20:20 --> Total execution time: 0.5100
DEBUG - 2022-10-05 09:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:20:28 --> Total execution time: 0.2481
DEBUG - 2022-10-05 09:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:22:22 --> Total execution time: 0.2926
DEBUG - 2022-10-05 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:54:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:24:22 --> Total execution time: 0.1022
DEBUG - 2022-10-05 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:24:38 --> Total execution time: 0.1320
DEBUG - 2022-10-05 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:54:42 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:24:43 --> Total execution time: 0.0801
DEBUG - 2022-10-05 09:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:24:53 --> Total execution time: 0.1635
DEBUG - 2022-10-05 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:01 --> Total execution time: 0.1459
DEBUG - 2022-10-05 09:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:07 --> Total execution time: 0.1590
DEBUG - 2022-10-05 09:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:14 --> Total execution time: 0.0846
DEBUG - 2022-10-05 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:16 --> Total execution time: 0.1393
DEBUG - 2022-10-05 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:30 --> Total execution time: 0.0862
DEBUG - 2022-10-05 09:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:33 --> Total execution time: 0.1335
DEBUG - 2022-10-05 09:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:40 --> Total execution time: 0.1479
DEBUG - 2022-10-05 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:41 --> Total execution time: 0.1398
DEBUG - 2022-10-05 09:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:25:59 --> Total execution time: 0.1344
DEBUG - 2022-10-05 09:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:26:09 --> Total execution time: 0.1363
DEBUG - 2022-10-05 09:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:26:20 --> Total execution time: 0.2307
DEBUG - 2022-10-05 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:26:30 --> Total execution time: 0.1409
DEBUG - 2022-10-05 09:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:26:37 --> Total execution time: 0.1521
DEBUG - 2022-10-05 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:26:48 --> Total execution time: 0.1813
DEBUG - 2022-10-05 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:26 --> Total execution time: 0.1348
DEBUG - 2022-10-05 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:47 --> Total execution time: 0.0785
DEBUG - 2022-10-05 09:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:59:18 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:29:19 --> Total execution time: 0.3543
DEBUG - 2022-10-05 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 09:59:23 --> No URI present. Default controller set.
DEBUG - 2022-10-05 09:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 09:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:29:23 --> Total execution time: 0.1331
DEBUG - 2022-10-05 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:30:02 --> Total execution time: 0.1241
DEBUG - 2022-10-05 10:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:31:40 --> Total execution time: 0.1391
DEBUG - 2022-10-05 10:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:02:11 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:32:11 --> Total execution time: 0.0820
DEBUG - 2022-10-05 10:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:33:18 --> Total execution time: 0.1366
DEBUG - 2022-10-05 10:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:34:35 --> Total execution time: 0.0792
DEBUG - 2022-10-05 10:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:34:44 --> Total execution time: 0.1409
DEBUG - 2022-10-05 10:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:34:55 --> Total execution time: 0.1333
DEBUG - 2022-10-05 10:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:34:59 --> Total execution time: 0.1441
DEBUG - 2022-10-05 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:12 --> Total execution time: 0.1274
DEBUG - 2022-10-05 10:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:19 --> Total execution time: 0.1294
DEBUG - 2022-10-05 10:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:29 --> Total execution time: 0.1260
DEBUG - 2022-10-05 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:34 --> Total execution time: 0.1327
DEBUG - 2022-10-05 10:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:40 --> Total execution time: 0.1340
DEBUG - 2022-10-05 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:46 --> Total execution time: 0.1350
DEBUG - 2022-10-05 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:47 --> Total execution time: 0.1280
DEBUG - 2022-10-05 10:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:52 --> Total execution time: 0.3830
DEBUG - 2022-10-05 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:53 --> Total execution time: 0.1474
DEBUG - 2022-10-05 10:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:01 --> Total execution time: 0.1366
DEBUG - 2022-10-05 10:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:06 --> Total execution time: 0.1559
DEBUG - 2022-10-05 10:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:11 --> Total execution time: 0.1270
DEBUG - 2022-10-05 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:25 --> Total execution time: 0.1408
DEBUG - 2022-10-05 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:31 --> Total execution time: 0.1850
DEBUG - 2022-10-05 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:03 --> Total execution time: 0.1303
DEBUG - 2022-10-05 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:05 --> Total execution time: 0.1304
DEBUG - 2022-10-05 10:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:15 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:15 --> Total execution time: 0.0903
DEBUG - 2022-10-05 10:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:16 --> Total execution time: 0.0781
DEBUG - 2022-10-05 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:51 --> Total execution time: 0.0847
DEBUG - 2022-10-05 10:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:58 --> Total execution time: 0.1306
DEBUG - 2022-10-05 10:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:05 --> Total execution time: 0.1633
DEBUG - 2022-10-05 10:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:09 --> Total execution time: 0.1460
DEBUG - 2022-10-05 10:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:16 --> Total execution time: 0.3951
DEBUG - 2022-10-05 10:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:18 --> Total execution time: 0.1729
DEBUG - 2022-10-05 10:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:27 --> Total execution time: 0.2264
DEBUG - 2022-10-05 10:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:40:08 --> Total execution time: 0.1310
DEBUG - 2022-10-05 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:40:14 --> Total execution time: 0.1372
DEBUG - 2022-10-05 10:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:22 --> Total execution time: 0.1361
DEBUG - 2022-10-05 10:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:11:34 --> Total execution time: 0.1289
DEBUG - 2022-10-05 10:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:11:36 --> Total execution time: 0.1328
DEBUG - 2022-10-05 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:11:36 --> Total execution time: 0.1383
DEBUG - 2022-10-05 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:37 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:37 --> Total execution time: 0.1345
DEBUG - 2022-10-05 10:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:11:42 --> Total execution time: 0.1400
DEBUG - 2022-10-05 10:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:11:44 --> Total execution time: 0.1351
DEBUG - 2022-10-05 10:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:11:44 --> Total execution time: 0.1417
DEBUG - 2022-10-05 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:43:56 --> Total execution time: 0.0877
DEBUG - 2022-10-05 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:43:57 --> Total execution time: 0.0851
DEBUG - 2022-10-05 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:43:59 --> Total execution time: 0.1013
DEBUG - 2022-10-05 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:43:59 --> Total execution time: 0.0812
DEBUG - 2022-10-05 20:44:00 --> Total execution time: 2.4701
DEBUG - 2022-10-05 10:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:14:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 10:14:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:34 --> Total execution time: 0.1267
DEBUG - 2022-10-05 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:47 --> Total execution time: 0.1474
DEBUG - 2022-10-05 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:52 --> Total execution time: 0.1609
DEBUG - 2022-10-05 10:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:05 --> Total execution time: 0.0913
DEBUG - 2022-10-05 10:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:07 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:07 --> Total execution time: 0.0818
DEBUG - 2022-10-05 10:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:12 --> Total execution time: 0.0897
DEBUG - 2022-10-05 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:20 --> Total execution time: 0.1401
DEBUG - 2022-10-05 10:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:26 --> Total execution time: 0.1327
DEBUG - 2022-10-05 10:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:33 --> Total execution time: 0.1818
DEBUG - 2022-10-05 10:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:15:37 --> Total execution time: 0.1278
DEBUG - 2022-10-05 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:41 --> Total execution time: 0.1382
DEBUG - 2022-10-05 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:42 --> Total execution time: 0.1419
DEBUG - 2022-10-05 10:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:42 --> Total execution time: 0.1616
DEBUG - 2022-10-05 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:47:27 --> Total execution time: 0.2061
DEBUG - 2022-10-05 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:47:40 --> Total execution time: 0.1428
DEBUG - 2022-10-05 10:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:47:49 --> Total execution time: 0.1653
DEBUG - 2022-10-05 10:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:18:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:48:22 --> Total execution time: 0.0866
DEBUG - 2022-10-05 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:48:27 --> Total execution time: 0.0901
DEBUG - 2022-10-05 10:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:48:36 --> Total execution time: 0.1287
DEBUG - 2022-10-05 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:48:46 --> Total execution time: 0.1597
DEBUG - 2022-10-05 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:48:58 --> Total execution time: 0.1468
DEBUG - 2022-10-05 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:49:09 --> Total execution time: 0.1275
DEBUG - 2022-10-05 10:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:49:13 --> Total execution time: 0.1424
DEBUG - 2022-10-05 10:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:49:18 --> Total execution time: 0.1367
DEBUG - 2022-10-05 10:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:49:21 --> Total execution time: 0.1284
DEBUG - 2022-10-05 10:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:49:25 --> Total execution time: 0.1335
DEBUG - 2022-10-05 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:49:46 --> Total execution time: 0.2011
DEBUG - 2022-10-05 10:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:50:53 --> Total execution time: 0.1693
DEBUG - 2022-10-05 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:53:52 --> Total execution time: 0.1946
DEBUG - 2022-10-05 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:57:14 --> Total execution time: 0.1454
DEBUG - 2022-10-05 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:00 --> Total execution time: 0.3861
DEBUG - 2022-10-05 10:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:06 --> Total execution time: 0.1683
DEBUG - 2022-10-05 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:49 --> Total execution time: 0.1674
DEBUG - 2022-10-05 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:50 --> Total execution time: 0.1656
DEBUG - 2022-10-05 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:58:50 --> Total execution time: 0.1571
DEBUG - 2022-10-05 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:50 --> Total execution time: 0.2173
DEBUG - 2022-10-05 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:58:50 --> Total execution time: 0.2563
DEBUG - 2022-10-05 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:50 --> Total execution time: 0.2311
DEBUG - 2022-10-05 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:58:51 --> Total execution time: 0.1705
DEBUG - 2022-10-05 10:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:59:06 --> Total execution time: 0.3051
DEBUG - 2022-10-05 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:59:24 --> Total execution time: 0.3535
DEBUG - 2022-10-05 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:59:50 --> Total execution time: 0.2534
DEBUG - 2022-10-05 10:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:04 --> Total execution time: 0.1980
DEBUG - 2022-10-05 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:22 --> Total execution time: 0.1431
DEBUG - 2022-10-05 10:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:23 --> Total execution time: 0.1412
DEBUG - 2022-10-05 10:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:24 --> Total execution time: 0.1304
DEBUG - 2022-10-05 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:25 --> Total execution time: 0.2353
DEBUG - 2022-10-05 10:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:40 --> Total execution time: 0.4170
DEBUG - 2022-10-05 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:00 --> Total execution time: 0.1992
DEBUG - 2022-10-05 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:08 --> Total execution time: 0.1560
DEBUG - 2022-10-05 10:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:18 --> Total execution time: 0.2164
DEBUG - 2022-10-05 10:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:26 --> Total execution time: 0.1407
DEBUG - 2022-10-05 10:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:50 --> Total execution time: 0.1352
DEBUG - 2022-10-05 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:53 --> Total execution time: 0.1339
DEBUG - 2022-10-05 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:01:55 --> Total execution time: 0.1501
DEBUG - 2022-10-05 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:05 --> Total execution time: 0.1322
DEBUG - 2022-10-05 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:17 --> Total execution time: 0.1552
DEBUG - 2022-10-05 10:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:21 --> Total execution time: 0.1520
DEBUG - 2022-10-05 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:28 --> Total execution time: 0.1364
DEBUG - 2022-10-05 10:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:32 --> Total execution time: 0.1495
DEBUG - 2022-10-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:38 --> Total execution time: 0.1414
DEBUG - 2022-10-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:38 --> Total execution time: 0.1477
DEBUG - 2022-10-05 10:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:42 --> Total execution time: 0.1343
DEBUG - 2022-10-05 10:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:45 --> Total execution time: 0.1421
DEBUG - 2022-10-05 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:02:55 --> Total execution time: 0.1587
DEBUG - 2022-10-05 10:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:03:06 --> Total execution time: 0.3480
DEBUG - 2022-10-05 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:03:11 --> Total execution time: 0.4153
DEBUG - 2022-10-05 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:04:15 --> Total execution time: 0.1261
DEBUG - 2022-10-05 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:04:28 --> Total execution time: 0.1326
DEBUG - 2022-10-05 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:04:57 --> Total execution time: 0.1595
DEBUG - 2022-10-05 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:05:01 --> Total execution time: 0.1587
DEBUG - 2022-10-05 10:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:05:11 --> Total execution time: 0.1259
DEBUG - 2022-10-05 10:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:09:14 --> Total execution time: 0.1483
DEBUG - 2022-10-05 10:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:09:22 --> Total execution time: 0.0884
DEBUG - 2022-10-05 10:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:42 --> Total execution time: 0.1336
DEBUG - 2022-10-05 10:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:43 --> Total execution time: 0.1310
DEBUG - 2022-10-05 10:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:39:44 --> Total execution time: 0.1195
DEBUG - 2022-10-05 10:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:48 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:09:48 --> Total execution time: 0.1396
DEBUG - 2022-10-05 10:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:09:50 --> Total execution time: 0.3448
DEBUG - 2022-10-05 10:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:40:23 --> Total execution time: 0.1422
DEBUG - 2022-10-05 10:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:40:25 --> Total execution time: 0.1323
DEBUG - 2022-10-05 10:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:40:26 --> Total execution time: 0.1263
DEBUG - 2022-10-05 10:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:40:34 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:10:35 --> Total execution time: 0.1363
DEBUG - 2022-10-05 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:10 --> Total execution time: 0.1485
DEBUG - 2022-10-05 10:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:57 --> Total execution time: 0.1387
DEBUG - 2022-10-05 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:15:07 --> Total execution time: 0.1360
DEBUG - 2022-10-05 10:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:15:34 --> Total execution time: 0.1352
DEBUG - 2022-10-05 10:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:15:47 --> Total execution time: 0.1462
DEBUG - 2022-10-05 10:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:15:58 --> Total execution time: 0.1481
DEBUG - 2022-10-05 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:19 --> Total execution time: 0.1335
DEBUG - 2022-10-05 10:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:26 --> Total execution time: 0.1411
DEBUG - 2022-10-05 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:39 --> Total execution time: 0.1336
DEBUG - 2022-10-05 10:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:40 --> Total execution time: 0.1343
DEBUG - 2022-10-05 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:47:28 --> Total execution time: 0.1843
DEBUG - 2022-10-05 10:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:17:32 --> Total execution time: 0.1341
DEBUG - 2022-10-05 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:17:37 --> Total execution time: 0.1296
DEBUG - 2022-10-05 10:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:18:07 --> Total execution time: 0.1572
DEBUG - 2022-10-05 10:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:49:32 --> Total execution time: 0.0837
DEBUG - 2022-10-05 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:49:36 --> Total execution time: 0.2118
DEBUG - 2022-10-05 10:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:49:37 --> Total execution time: 0.3220
DEBUG - 2022-10-05 10:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:19:37 --> Total execution time: 0.1317
DEBUG - 2022-10-05 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:19:56 --> Total execution time: 0.1375
DEBUG - 2022-10-05 10:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:20:04 --> Total execution time: 0.1664
DEBUG - 2022-10-05 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:20:13 --> Total execution time: 0.1309
DEBUG - 2022-10-05 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:21:35 --> Total execution time: 0.0813
DEBUG - 2022-10-05 10:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:21:38 --> Total execution time: 0.1271
DEBUG - 2022-10-05 10:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:22:32 --> Total execution time: 0.1303
DEBUG - 2022-10-05 10:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:22:39 --> Total execution time: 0.1310
DEBUG - 2022-10-05 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:22:48 --> Total execution time: 0.1307
DEBUG - 2022-10-05 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:23:13 --> Total execution time: 0.3494
DEBUG - 2022-10-05 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:23:33 --> Total execution time: 0.1290
DEBUG - 2022-10-05 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:23:48 --> Total execution time: 0.1317
DEBUG - 2022-10-05 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:52 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:23:52 --> Total execution time: 0.0918
DEBUG - 2022-10-05 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:53:57 --> Total execution time: 0.3437
DEBUG - 2022-10-05 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:53:57 --> Total execution time: 0.1315
DEBUG - 2022-10-05 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:54:00 --> Total execution time: 0.1315
DEBUG - 2022-10-05 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:54:00 --> Total execution time: 0.1319
DEBUG - 2022-10-05 10:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:24:05 --> Total execution time: 0.1830
DEBUG - 2022-10-05 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:54:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 10:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:24:12 --> Total execution time: 0.1489
DEBUG - 2022-10-05 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:24:32 --> Total execution time: 0.1251
DEBUG - 2022-10-05 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:27:24 --> Total execution time: 0.3988
DEBUG - 2022-10-05 10:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:27:32 --> Total execution time: 0.1454
DEBUG - 2022-10-05 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:28:49 --> Total execution time: 0.3816
DEBUG - 2022-10-05 10:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:28:55 --> Total execution time: 0.1253
DEBUG - 2022-10-05 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 10:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 10:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:29:50 --> Total execution time: 0.3431
DEBUG - 2022-10-05 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:01 --> Total execution time: 0.2191
DEBUG - 2022-10-05 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:02 --> Total execution time: 0.1915
DEBUG - 2022-10-05 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:05 --> Total execution time: 0.1633
DEBUG - 2022-10-05 11:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:11 --> Total execution time: 0.1385
DEBUG - 2022-10-05 11:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:13 --> Total execution time: 0.3456
DEBUG - 2022-10-05 11:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:52 --> Total execution time: 0.1335
DEBUG - 2022-10-05 11:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:52 --> Total execution time: 0.1289
DEBUG - 2022-10-05 11:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:53 --> Total execution time: 0.1497
DEBUG - 2022-10-05 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:58 --> Total execution time: 0.1502
DEBUG - 2022-10-05 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:31:00 --> Total execution time: 0.1439
DEBUG - 2022-10-05 11:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:33:23 --> Total execution time: 0.1465
DEBUG - 2022-10-05 11:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:33:49 --> Total execution time: 0.1418
DEBUG - 2022-10-05 11:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:33:51 --> Total execution time: 0.3382
DEBUG - 2022-10-05 11:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:03:53 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:33:53 --> Total execution time: 0.1409
DEBUG - 2022-10-05 11:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:33:54 --> Total execution time: 0.1408
DEBUG - 2022-10-05 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:05 --> Total execution time: 0.1280
DEBUG - 2022-10-05 11:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:44 --> Total execution time: 0.1273
DEBUG - 2022-10-05 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:37:05 --> Total execution time: 0.1418
DEBUG - 2022-10-05 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:37:26 --> Total execution time: 0.1431
DEBUG - 2022-10-05 11:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:37:50 --> Total execution time: 0.1256
DEBUG - 2022-10-05 11:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:38:10 --> Total execution time: 0.3728
DEBUG - 2022-10-05 11:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:39:11 --> Total execution time: 0.1507
DEBUG - 2022-10-05 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:19:44 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:49:44 --> Total execution time: 0.1773
DEBUG - 2022-10-05 11:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:49:59 --> Total execution time: 0.0773
DEBUG - 2022-10-05 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:01 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:02 --> Total execution time: 0.1295
DEBUG - 2022-10-05 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:03 --> Total execution time: 0.1334
DEBUG - 2022-10-05 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:04 --> Total execution time: 0.1346
DEBUG - 2022-10-05 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:04 --> Total execution time: 0.1404
DEBUG - 2022-10-05 11:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:20:22 --> Total execution time: 0.1300
DEBUG - 2022-10-05 11:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:20:23 --> Total execution time: 0.1346
DEBUG - 2022-10-05 11:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:20:24 --> Total execution time: 0.1228
DEBUG - 2022-10-05 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:40 --> Total execution time: 0.0869
DEBUG - 2022-10-05 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:48 --> Total execution time: 0.1410
DEBUG - 2022-10-05 11:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:53 --> Total execution time: 0.4303
DEBUG - 2022-10-05 11:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:50:55 --> Total execution time: 0.1491
DEBUG - 2022-10-05 11:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:51:04 --> Total execution time: 0.1501
DEBUG - 2022-10-05 11:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:51:04 --> Total execution time: 0.1875
DEBUG - 2022-10-05 11:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:51:05 --> Total execution time: 0.1383
DEBUG - 2022-10-05 11:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:51:05 --> Total execution time: 0.1622
DEBUG - 2022-10-05 11:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:10 --> Total execution time: 0.1256
DEBUG - 2022-10-05 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:12 --> Total execution time: 0.1260
DEBUG - 2022-10-05 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:21:13 --> Total execution time: 0.1246
DEBUG - 2022-10-05 11:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:21:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:51:45 --> Total execution time: 0.1455
DEBUG - 2022-10-05 11:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:04 --> Total execution time: 0.1354
DEBUG - 2022-10-05 11:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:06 --> Total execution time: 0.1601
DEBUG - 2022-10-05 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:19 --> Total execution time: 0.1590
DEBUG - 2022-10-05 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:23 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:24 --> Total execution time: 0.1331
DEBUG - 2022-10-05 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:22:24 --> Total execution time: 0.1338
DEBUG - 2022-10-05 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:22:24 --> Total execution time: 0.1389
DEBUG - 2022-10-05 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:25 --> Total execution time: 0.1474
DEBUG - 2022-10-05 11:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:33 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:33 --> Total execution time: 0.1491
DEBUG - 2022-10-05 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:43 --> Total execution time: 0.1309
DEBUG - 2022-10-05 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:49 --> Total execution time: 0.1524
DEBUG - 2022-10-05 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:53:18 --> Total execution time: 0.3766
DEBUG - 2022-10-05 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:53:41 --> Total execution time: 0.1510
DEBUG - 2022-10-05 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:53:42 --> Total execution time: 0.1264
DEBUG - 2022-10-05 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:01 --> Total execution time: 0.2861
DEBUG - 2022-10-05 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:23 --> Total execution time: 0.3564
DEBUG - 2022-10-05 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:24 --> Total execution time: 0.1217
DEBUG - 2022-10-05 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:29 --> Total execution time: 0.1261
DEBUG - 2022-10-05 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:31 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:31 --> Total execution time: 0.1290
DEBUG - 2022-10-05 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:35 --> Total execution time: 0.1265
DEBUG - 2022-10-05 11:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:38 --> Total execution time: 0.2323
DEBUG - 2022-10-05 11:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:50 --> Total execution time: 0.1498
DEBUG - 2022-10-05 11:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:54:58 --> Total execution time: 0.1416
DEBUG - 2022-10-05 11:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:09 --> Total execution time: 0.3714
DEBUG - 2022-10-05 11:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:10 --> Total execution time: 0.1552
DEBUG - 2022-10-05 11:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:20 --> Total execution time: 0.1327
DEBUG - 2022-10-05 11:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:24 --> Total execution time: 0.1358
DEBUG - 2022-10-05 11:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:34 --> Total execution time: 0.1749
DEBUG - 2022-10-05 11:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:36 --> Total execution time: 0.1610
DEBUG - 2022-10-05 11:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:37 --> Total execution time: 0.1681
DEBUG - 2022-10-05 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:10 --> Total execution time: 0.1367
DEBUG - 2022-10-05 11:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:16 --> Total execution time: 0.1360
DEBUG - 2022-10-05 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:20 --> Total execution time: 0.1386
DEBUG - 2022-10-05 11:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:26 --> Total execution time: 0.1961
DEBUG - 2022-10-05 11:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:29 --> Total execution time: 0.1459
DEBUG - 2022-10-05 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:30 --> Total execution time: 0.1255
DEBUG - 2022-10-05 11:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:33 --> Total execution time: 0.1289
DEBUG - 2022-10-05 11:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:50 --> Total execution time: 0.1401
DEBUG - 2022-10-05 11:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:56 --> Total execution time: 0.3783
DEBUG - 2022-10-05 11:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:57:02 --> Total execution time: 0.1403
DEBUG - 2022-10-05 11:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:57:05 --> Total execution time: 0.1488
DEBUG - 2022-10-05 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:57:13 --> Total execution time: 0.1319
DEBUG - 2022-10-05 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:57:15 --> Total execution time: 0.1288
DEBUG - 2022-10-05 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:57:21 --> Total execution time: 0.1468
DEBUG - 2022-10-05 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:59:33 --> Total execution time: 0.2027
DEBUG - 2022-10-05 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:59:34 --> Total execution time: 0.1237
DEBUG - 2022-10-05 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:59:37 --> Total execution time: 0.1500
DEBUG - 2022-10-05 11:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:59:41 --> Total execution time: 0.3640
DEBUG - 2022-10-05 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:59:55 --> Total execution time: 0.1479
DEBUG - 2022-10-05 11:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:30:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:00:43 --> Total execution time: 0.0900
DEBUG - 2022-10-05 11:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:01:00 --> Total execution time: 0.3895
DEBUG - 2022-10-05 11:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:31:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:01:25 --> Total execution time: 0.0831
DEBUG - 2022-10-05 11:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:31:58 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:01:59 --> Total execution time: 0.1142
DEBUG - 2022-10-05 11:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:32:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:02:05 --> Total execution time: 0.0856
DEBUG - 2022-10-05 11:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:03:29 --> Total execution time: 0.1356
DEBUG - 2022-10-05 11:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:03:46 --> Total execution time: 0.1766
DEBUG - 2022-10-05 11:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:03:47 --> Total execution time: 0.1610
DEBUG - 2022-10-05 11:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:34:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:04:30 --> Total execution time: 0.1005
DEBUG - 2022-10-05 11:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:05:16 --> Total execution time: 0.1533
DEBUG - 2022-10-05 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:05:17 --> Total execution time: 0.3809
DEBUG - 2022-10-05 11:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:05:31 --> Total execution time: 0.1335
DEBUG - 2022-10-05 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:05:45 --> Total execution time: 0.1532
DEBUG - 2022-10-05 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:07:16 --> Total execution time: 0.0873
DEBUG - 2022-10-05 11:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:09:55 --> Total execution time: 0.1381
DEBUG - 2022-10-05 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:40:27 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:28 --> Total execution time: 0.3752
DEBUG - 2022-10-05 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:39 --> Total execution time: 0.1315
DEBUG - 2022-10-05 11:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:11 --> Total execution time: 0.1232
DEBUG - 2022-10-05 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:14:53 --> Total execution time: 0.4546
DEBUG - 2022-10-05 11:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:22 --> Total execution time: 0.3503
DEBUG - 2022-10-05 11:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:35 --> Total execution time: 0.1362
DEBUG - 2022-10-05 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:42 --> Total execution time: 0.1288
DEBUG - 2022-10-05 11:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:44 --> Total execution time: 0.1341
DEBUG - 2022-10-05 11:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:47 --> Total execution time: 0.1925
DEBUG - 2022-10-05 11:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:54 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:54 --> Total execution time: 0.0805
DEBUG - 2022-10-05 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:45:55 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:15:55 --> Total execution time: 0.0788
DEBUG - 2022-10-05 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:14 --> Total execution time: 0.1305
DEBUG - 2022-10-05 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:14 --> Total execution time: 0.1254
DEBUG - 2022-10-05 11:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:42 --> Total execution time: 0.1749
DEBUG - 2022-10-05 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:42 --> Total execution time: 0.1362
DEBUG - 2022-10-05 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:44 --> Total execution time: 0.1488
DEBUG - 2022-10-05 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:17:38 --> Total execution time: 0.1385
DEBUG - 2022-10-05 11:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:17:50 --> Total execution time: 0.1415
DEBUG - 2022-10-05 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:17:53 --> Total execution time: 0.1452
DEBUG - 2022-10-05 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:18:08 --> Total execution time: 0.1312
DEBUG - 2022-10-05 11:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:48:15 --> Total execution time: 0.1315
DEBUG - 2022-10-05 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:18:37 --> Total execution time: 0.1909
DEBUG - 2022-10-05 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:19:00 --> Total execution time: 0.1716
DEBUG - 2022-10-05 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:19:15 --> Total execution time: 0.1337
DEBUG - 2022-10-05 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:20:14 --> Total execution time: 0.1247
DEBUG - 2022-10-05 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:50:40 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:20:40 --> Total execution time: 0.0855
DEBUG - 2022-10-05 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:21:02 --> Total execution time: 0.1149
DEBUG - 2022-10-05 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:52:22 --> Total execution time: 0.0817
DEBUG - 2022-10-05 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:52:55 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:22:55 --> Total execution time: 0.0879
DEBUG - 2022-10-05 11:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:22:58 --> Total execution time: 0.0842
DEBUG - 2022-10-05 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:23:00 --> Total execution time: 0.0787
DEBUG - 2022-10-05 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:23:37 --> Total execution time: 0.1484
DEBUG - 2022-10-05 11:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:53:54 --> Total execution time: 0.1330
DEBUG - 2022-10-05 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:53:56 --> Total execution time: 0.1398
DEBUG - 2022-10-05 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:53:57 --> Total execution time: 0.1386
DEBUG - 2022-10-05 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:23:57 --> Total execution time: 0.1243
DEBUG - 2022-10-05 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:25 --> Total execution time: 0.1383
DEBUG - 2022-10-05 11:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:28 --> Total execution time: 0.1433
DEBUG - 2022-10-05 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:37 --> Total execution time: 0.1294
DEBUG - 2022-10-05 11:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:39 --> Total execution time: 0.1342
DEBUG - 2022-10-05 11:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:41 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:41 --> Total execution time: 0.3654
DEBUG - 2022-10-05 11:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:41 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:42 --> Total execution time: 0.1270
DEBUG - 2022-10-05 11:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:48 --> Total execution time: 0.1234
DEBUG - 2022-10-05 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:03 --> Total execution time: 0.1280
DEBUG - 2022-10-05 22:25:06 --> Total execution time: 2.5856
DEBUG - 2022-10-05 11:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 11:55:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 11:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:10 --> Total execution time: 0.3624
DEBUG - 2022-10-05 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:17 --> Total execution time: 0.1407
DEBUG - 2022-10-05 11:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:22 --> Total execution time: 0.1338
DEBUG - 2022-10-05 11:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:30 --> Total execution time: 0.3480
DEBUG - 2022-10-05 11:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:30 --> Total execution time: 0.1443
DEBUG - 2022-10-05 11:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:36 --> Total execution time: 0.1667
DEBUG - 2022-10-05 11:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:37 --> Total execution time: 0.1357
DEBUG - 2022-10-05 11:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:10 --> Total execution time: 0.1374
DEBUG - 2022-10-05 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:23 --> Total execution time: 0.1364
DEBUG - 2022-10-05 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:25 --> Total execution time: 0.1490
DEBUG - 2022-10-05 11:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:30 --> Total execution time: 0.1420
DEBUG - 2022-10-05 11:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:36 --> Total execution time: 0.1839
DEBUG - 2022-10-05 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:50 --> Total execution time: 0.1324
DEBUG - 2022-10-05 11:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:27:07 --> Total execution time: 0.1765
DEBUG - 2022-10-05 11:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:27:09 --> Total execution time: 0.1356
DEBUG - 2022-10-05 11:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:27:23 --> Total execution time: 0.1329
DEBUG - 2022-10-05 11:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:57:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 11:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:27:24 --> Total execution time: 0.0945
DEBUG - 2022-10-05 11:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:06 --> Total execution time: 0.3858
DEBUG - 2022-10-05 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:10 --> Total execution time: 0.3671
DEBUG - 2022-10-05 11:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:21 --> Total execution time: 0.1571
DEBUG - 2022-10-05 11:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:34 --> Total execution time: 0.1356
DEBUG - 2022-10-05 11:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:35 --> Total execution time: 0.1341
DEBUG - 2022-10-05 11:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:29:00 --> Total execution time: 0.1385
DEBUG - 2022-10-05 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:59:14 --> Total execution time: 0.1511
DEBUG - 2022-10-05 11:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 11:59:27 --> Total execution time: 0.2336
DEBUG - 2022-10-05 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:29:44 --> Total execution time: 0.1756
DEBUG - 2022-10-05 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 11:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:29:47 --> Total execution time: 0.1781
DEBUG - 2022-10-05 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:30:02 --> Total execution time: 0.1048
DEBUG - 2022-10-05 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:00:06 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:30:06 --> Total execution time: 0.1119
DEBUG - 2022-10-05 12:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:30:36 --> Total execution time: 0.1538
DEBUG - 2022-10-05 12:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 12:00:49 --> 404 Page Not Found: Wp-commentinphp/index
DEBUG - 2022-10-05 12:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:30:56 --> Total execution time: 0.1295
DEBUG - 2022-10-05 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:31:55 --> Total execution time: 0.1821
DEBUG - 2022-10-05 12:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:32:22 --> Total execution time: 0.1405
DEBUG - 2022-10-05 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:33:39 --> Total execution time: 0.1791
DEBUG - 2022-10-05 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:34:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-05 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:34:20 --> Total execution time: 0.1764
DEBUG - 2022-10-05 12:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:36 --> Total execution time: 0.1347
DEBUG - 2022-10-05 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:04:51 --> Total execution time: 0.1270
DEBUG - 2022-10-05 12:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:13 --> Total execution time: 0.1288
DEBUG - 2022-10-05 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:35:33 --> Total execution time: 0.0791
DEBUG - 2022-10-05 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:35:42 --> Total execution time: 0.1369
DEBUG - 2022-10-05 12:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:05:43 --> Total execution time: 0.1251
DEBUG - 2022-10-05 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:05:53 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:35:54 --> Total execution time: 0.4058
DEBUG - 2022-10-05 12:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:02 --> Total execution time: 0.1691
DEBUG - 2022-10-05 12:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:09 --> Total execution time: 0.1710
DEBUG - 2022-10-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:27 --> Total execution time: 0.1431
DEBUG - 2022-10-05 12:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:27 --> Total execution time: 0.1521
DEBUG - 2022-10-05 12:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:32 --> Total execution time: 0.1731
DEBUG - 2022-10-05 12:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:53 --> Total execution time: 0.1436
DEBUG - 2022-10-05 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:54 --> Total execution time: 0.3568
DEBUG - 2022-10-05 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:36:55 --> Total execution time: 0.1379
DEBUG - 2022-10-05 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:37:18 --> Total execution time: 0.1392
DEBUG - 2022-10-05 12:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:37:30 --> Total execution time: 0.1728
DEBUG - 2022-10-05 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:37:39 --> Total execution time: 0.1686
DEBUG - 2022-10-05 12:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:37:49 --> Total execution time: 0.1417
DEBUG - 2022-10-05 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:38:08 --> Total execution time: 0.1474
DEBUG - 2022-10-05 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:38:16 --> Total execution time: 0.1572
DEBUG - 2022-10-05 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:38:29 --> Total execution time: 0.1612
DEBUG - 2022-10-05 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:40:09 --> Total execution time: 0.1329
DEBUG - 2022-10-05 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:40:21 --> Total execution time: 0.1661
DEBUG - 2022-10-05 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:40:24 --> Total execution time: 0.1347
DEBUG - 2022-10-05 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:40:25 --> Total execution time: 0.3466
DEBUG - 2022-10-05 12:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:40:46 --> Total execution time: 0.3492
DEBUG - 2022-10-05 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:42:16 --> Total execution time: 0.1461
DEBUG - 2022-10-05 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:42:22 --> Total execution time: 0.3703
DEBUG - 2022-10-05 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:42:25 --> Total execution time: 0.1360
DEBUG - 2022-10-05 12:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:42:38 --> Total execution time: 0.1281
DEBUG - 2022-10-05 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:42:43 --> Total execution time: 0.1298
DEBUG - 2022-10-05 12:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:43:00 --> Total execution time: 0.1336
DEBUG - 2022-10-05 12:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:14:00 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:44:01 --> Total execution time: 0.1053
DEBUG - 2022-10-05 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:44:16 --> Total execution time: 0.1312
DEBUG - 2022-10-05 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:45:02 --> Total execution time: 0.1588
DEBUG - 2022-10-05 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:45:03 --> Total execution time: 0.1404
DEBUG - 2022-10-05 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:15:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:45:03 --> Total execution time: 0.1007
DEBUG - 2022-10-05 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:45:04 --> Total execution time: 0.1339
DEBUG - 2022-10-05 12:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:45:47 --> Total execution time: 0.1398
DEBUG - 2022-10-05 12:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:08 --> Total execution time: 0.0876
DEBUG - 2022-10-05 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:12 --> Total execution time: 0.0776
DEBUG - 2022-10-05 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:35 --> Total execution time: 0.1404
DEBUG - 2022-10-05 12:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:40 --> Total execution time: 0.1359
DEBUG - 2022-10-05 12:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:44 --> Total execution time: 0.1564
DEBUG - 2022-10-05 12:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:50 --> Total execution time: 0.1417
DEBUG - 2022-10-05 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:51 --> Total execution time: 0.1671
DEBUG - 2022-10-05 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:59 --> Total execution time: 0.1317
DEBUG - 2022-10-05 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:09 --> Total execution time: 0.3455
DEBUG - 2022-10-05 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:13 --> Total execution time: 0.1303
DEBUG - 2022-10-05 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:30 --> Total execution time: 0.1461
DEBUG - 2022-10-05 12:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:40 --> Total execution time: 0.1377
DEBUG - 2022-10-05 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:44 --> Total execution time: 0.1311
DEBUG - 2022-10-05 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:44 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:44 --> Total execution time: 0.1368
DEBUG - 2022-10-05 12:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:48 --> Total execution time: 0.1528
DEBUG - 2022-10-05 12:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:48 --> Total execution time: 0.1333
DEBUG - 2022-10-05 12:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:50 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:50 --> Total execution time: 0.0825
DEBUG - 2022-10-05 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:52 --> Total execution time: 0.1343
DEBUG - 2022-10-05 12:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:18:53 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:53 --> Total execution time: 0.1329
DEBUG - 2022-10-05 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:49:03 --> Total execution time: 0.1502
DEBUG - 2022-10-05 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:19:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:49:05 --> Total execution time: 0.1995
DEBUG - 2022-10-05 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:49:11 --> Total execution time: 0.1385
DEBUG - 2022-10-05 12:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:49:11 --> Total execution time: 0.1269
DEBUG - 2022-10-05 12:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:49:38 --> Total execution time: 0.1536
DEBUG - 2022-10-05 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:50:41 --> Total execution time: 0.1480
DEBUG - 2022-10-05 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:50:46 --> Total execution time: 0.1343
DEBUG - 2022-10-05 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:50:47 --> Total execution time: 0.1315
DEBUG - 2022-10-05 12:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:52:11 --> Total execution time: 0.0842
DEBUG - 2022-10-05 12:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:55:49 --> Total execution time: 0.4235
DEBUG - 2022-10-05 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:59:45 --> Total execution time: 0.0900
DEBUG - 2022-10-05 12:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:00:31 --> Total execution time: 0.3547
DEBUG - 2022-10-05 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:00:44 --> Total execution time: 0.1261
DEBUG - 2022-10-05 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:00:49 --> Total execution time: 0.1433
DEBUG - 2022-10-05 12:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:47 --> Total execution time: 0.1470
DEBUG - 2022-10-05 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:52 --> Total execution time: 0.1234
DEBUG - 2022-10-05 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:57 --> Total execution time: 0.1368
DEBUG - 2022-10-05 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:58 --> Total execution time: 0.1496
DEBUG - 2022-10-05 12:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:03:07 --> Total execution time: 0.1500
DEBUG - 2022-10-05 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:03:34 --> Total execution time: 0.1562
DEBUG - 2022-10-05 12:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:04 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:05 --> Total execution time: 0.3597
DEBUG - 2022-10-05 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:05 --> Total execution time: 0.1395
DEBUG - 2022-10-05 12:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:16 --> Total execution time: 0.1462
DEBUG - 2022-10-05 12:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:18 --> Total execution time: 0.1300
DEBUG - 2022-10-05 12:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:25 --> Total execution time: 0.1405
DEBUG - 2022-10-05 12:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:29 --> Total execution time: 0.1646
DEBUG - 2022-10-05 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:47 --> Total execution time: 0.1437
DEBUG - 2022-10-05 12:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:04:56 --> Total execution time: 0.1383
DEBUG - 2022-10-05 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:08:41 --> Total execution time: 0.2220
DEBUG - 2022-10-05 12:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:13:57 --> Total execution time: 0.2047
DEBUG - 2022-10-05 12:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:14:16 --> Total execution time: 0.1325
DEBUG - 2022-10-05 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:14:59 --> Total execution time: 0.1346
DEBUG - 2022-10-05 12:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:16:26 --> Total execution time: 0.0873
DEBUG - 2022-10-05 12:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:16:32 --> Total execution time: 0.1477
DEBUG - 2022-10-05 12:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:20:04 --> Total execution time: 0.2128
DEBUG - 2022-10-05 12:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:50:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:20:05 --> Total execution time: 0.0921
DEBUG - 2022-10-05 12:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:20:14 --> Total execution time: 0.0791
DEBUG - 2022-10-05 12:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:20:14 --> Total execution time: 0.1962
DEBUG - 2022-10-05 12:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:21:24 --> Total execution time: 0.0846
DEBUG - 2022-10-05 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:21:28 --> Total execution time: 0.1084
DEBUG - 2022-10-05 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:21:30 --> Total execution time: 0.0800
DEBUG - 2022-10-05 12:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:21:38 --> Total execution time: 0.1301
DEBUG - 2022-10-05 12:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:21:47 --> Total execution time: 0.1708
DEBUG - 2022-10-05 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:52:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:22:36 --> Total execution time: 0.0822
DEBUG - 2022-10-05 12:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:22:54 --> Total execution time: 0.3724
DEBUG - 2022-10-05 12:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:27 --> Total execution time: 0.1345
DEBUG - 2022-10-05 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:39 --> Total execution time: 0.1586
DEBUG - 2022-10-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:48 --> Total execution time: 0.1373
DEBUG - 2022-10-05 12:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:54:56 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:24:56 --> Total execution time: 0.0992
DEBUG - 2022-10-05 12:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:54:57 --> No URI present. Default controller set.
DEBUG - 2022-10-05 12:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:24:57 --> Total execution time: 0.1286
DEBUG - 2022-10-05 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:25:05 --> Total execution time: 0.0848
DEBUG - 2022-10-05 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:25:34 --> Total execution time: 0.1485
DEBUG - 2022-10-05 12:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:25:43 --> Total execution time: 0.1557
DEBUG - 2022-10-05 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 12:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 12:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:25:52 --> Total execution time: 0.2892
DEBUG - 2022-10-05 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:30:03 --> Total execution time: 0.1648
DEBUG - 2022-10-05 13:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:05 --> No URI present. Default controller set.
DEBUG - 2022-10-05 13:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:37:05 --> Total execution time: 0.1928
DEBUG - 2022-10-05 13:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:37:06 --> Total execution time: 0.0834
DEBUG - 2022-10-05 13:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:07:09 --> Total execution time: 0.1377
DEBUG - 2022-10-05 13:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:37:10 --> Total execution time: 0.1435
DEBUG - 2022-10-05 13:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:37:26 --> Total execution time: 0.1390
DEBUG - 2022-10-05 13:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:37:37 --> Total execution time: 0.1379
DEBUG - 2022-10-05 13:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:37:54 --> Total execution time: 0.1419
DEBUG - 2022-10-05 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:45:04 --> Total execution time: 0.2070
DEBUG - 2022-10-05 13:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:45:37 --> Total execution time: 0.1349
DEBUG - 2022-10-05 13:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:46:30 --> Total execution time: 0.1509
DEBUG - 2022-10-05 13:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:31 --> Total execution time: 0.1385
DEBUG - 2022-10-05 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:33 --> Total execution time: 0.3762
DEBUG - 2022-10-05 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:19:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 13:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:49:46 --> Total execution time: 0.3629
DEBUG - 2022-10-05 13:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:51:57 --> Total execution time: 0.1270
DEBUG - 2022-10-05 13:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:51:58 --> Total execution time: 0.0854
DEBUG - 2022-10-05 13:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:51:58 --> Total execution time: 0.0774
DEBUG - 2022-10-05 13:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:52:30 --> Total execution time: 0.0848
DEBUG - 2022-10-05 13:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:52:30 --> Total execution time: 0.0913
DEBUG - 2022-10-05 13:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:52:31 --> Total execution time: 0.0791
DEBUG - 2022-10-05 13:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:52:32 --> Total execution time: 0.0776
DEBUG - 2022-10-05 13:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 13:22:40 --> 404 Page Not Found: Teacher/demyan-rostislav
DEBUG - 2022-10-05 13:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:52:41 --> Total execution time: 0.0843
DEBUG - 2022-10-05 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:52:44 --> Total execution time: 0.0990
DEBUG - 2022-10-05 13:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:54:35 --> Total execution time: 0.3570
DEBUG - 2022-10-05 13:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:54:39 --> Total execution time: 0.1438
DEBUG - 2022-10-05 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:55:11 --> Total execution time: 0.1253
DEBUG - 2022-10-05 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:55:27 --> Total execution time: 0.1454
DEBUG - 2022-10-05 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:55:32 --> Total execution time: 0.1625
DEBUG - 2022-10-05 13:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:22 --> Total execution time: 0.1280
DEBUG - 2022-10-05 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:29 --> Total execution time: 0.1490
DEBUG - 2022-10-05 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:45 --> Total execution time: 0.1315
DEBUG - 2022-10-05 13:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:56 --> Total execution time: 0.1310
DEBUG - 2022-10-05 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:57:11 --> Total execution time: 0.1797
DEBUG - 2022-10-05 13:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:57:29 --> Total execution time: 0.1512
DEBUG - 2022-10-05 13:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:57:41 --> Total execution time: 0.1634
DEBUG - 2022-10-05 13:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:57:47 --> Total execution time: 0.1371
DEBUG - 2022-10-05 13:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:57:56 --> Total execution time: 0.3646
DEBUG - 2022-10-05 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:58:37 --> Total execution time: 0.1421
DEBUG - 2022-10-05 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:59:12 --> Total execution time: 0.0851
DEBUG - 2022-10-05 13:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:59:26 --> Total execution time: 0.1372
DEBUG - 2022-10-05 13:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:59:40 --> Total execution time: 0.1318
DEBUG - 2022-10-05 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:37:56 --> No URI present. Default controller set.
DEBUG - 2022-10-05 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:41:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 13:41:00 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:41:01 --> No URI present. Default controller set.
DEBUG - 2022-10-05 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:51:57 --> No URI present. Default controller set.
DEBUG - 2022-10-05 13:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:53:14 --> No URI present. Default controller set.
DEBUG - 2022-10-05 13:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 13:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 13:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 13:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 14:02:40 --> 404 Page Not Found: Summer-course-starts-from-june/index
DEBUG - 2022-10-05 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:02:40 --> No URI present. Default controller set.
DEBUG - 2022-10-05 14:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:35:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 14:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 14:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 14:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 14:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 14:57:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-05 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 15:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 15:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:03:14 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:03:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 16:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:03:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 16:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:03:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 16:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:03:31 --> No URI present. Default controller set.
DEBUG - 2022-10-05 16:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:03:31 --> No URI present. Default controller set.
DEBUG - 2022-10-05 16:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:04:00 --> No URI present. Default controller set.
DEBUG - 2022-10-05 16:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:05:24 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 16:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:05:24 --> No URI present. Default controller set.
DEBUG - 2022-10-05 16:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:29:03 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-10-05 16:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:29:06 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-10-05 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 16:29:08 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-10-05 16:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:37:38 --> No URI present. Default controller set.
DEBUG - 2022-10-05 16:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 16:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 16:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 16:57:03 --> Total execution time: 0.1285
DEBUG - 2022-10-05 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:00:07 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:00:42 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 17:09:16 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-10-05 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 17:09:20 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-10-05 17:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 17:09:21 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-10-05 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:12:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:12:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:18 --> Total execution time: 0.0817
DEBUG - 2022-10-05 17:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:13:18 --> Total execution time: 0.1226
DEBUG - 2022-10-05 17:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:14:17 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:22:38 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:45:08 --> No URI present. Default controller set.
DEBUG - 2022-10-05 17:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 17:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 17:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 17:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 17:53:10 --> 404 Page Not Found: Stylephp/index
DEBUG - 2022-10-05 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:07:22 --> No URI present. Default controller set.
DEBUG - 2022-10-05 18:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:07:37 --> No URI present. Default controller set.
DEBUG - 2022-10-05 18:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 18:51:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-05 18:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 18:51:19 --> 404 Page Not Found: Course/premium-level-program
DEBUG - 2022-10-05 18:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:38 --> Total execution time: 0.1735
DEBUG - 2022-10-05 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:54 --> Total execution time: 0.1304
DEBUG - 2022-10-05 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 18:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 18:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 18:52:54 --> Total execution time: 0.0743
DEBUG - 2022-10-05 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:23:52 --> No URI present. Default controller set.
DEBUG - 2022-10-05 19:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:30:38 --> No URI present. Default controller set.
DEBUG - 2022-10-05 19:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:35:10 --> No URI present. Default controller set.
DEBUG - 2022-10-05 19:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:35:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 19:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 19:53:03 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-10-05 19:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 19:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 19:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 19:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:09:49 --> No URI present. Default controller set.
DEBUG - 2022-10-05 20:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:22:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 20:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:41:03 --> No URI present. Default controller set.
DEBUG - 2022-10-05 20:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:41:07 --> No URI present. Default controller set.
DEBUG - 2022-10-05 20:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:47 --> Total execution time: 0.1304
DEBUG - 2022-10-05 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:49 --> Total execution time: 0.1272
DEBUG - 2022-10-05 20:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:41:50 --> Total execution time: 0.2667
DEBUG - 2022-10-05 20:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:26 --> Total execution time: 0.1276
DEBUG - 2022-10-05 20:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:28 --> Total execution time: 0.1386
DEBUG - 2022-10-05 20:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 20:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:45:15 --> No URI present. Default controller set.
DEBUG - 2022-10-05 20:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 20:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 20:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 20:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 21:07:37 --> 404 Page Not Found: Product/reselling-course-without-paid-ads
DEBUG - 2022-10-05 21:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:12:54 --> No URI present. Default controller set.
DEBUG - 2022-10-05 21:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:13:06 --> No URI present. Default controller set.
DEBUG - 2022-10-05 21:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:13:24 --> Total execution time: 0.1385
DEBUG - 2022-10-05 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:13:27 --> Total execution time: 0.1652
DEBUG - 2022-10-05 21:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:13:27 --> Total execution time: 0.1299
DEBUG - 2022-10-05 21:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:27 --> Total execution time: 0.1326
DEBUG - 2022-10-05 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:29 --> Total execution time: 0.1455
DEBUG - 2022-10-05 21:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:29 --> Total execution time: 0.3246
DEBUG - 2022-10-05 21:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:14:39 --> Total execution time: 0.1355
DEBUG - 2022-10-05 21:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:16:36 --> No URI present. Default controller set.
DEBUG - 2022-10-05 21:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:18:49 --> No URI present. Default controller set.
DEBUG - 2022-10-05 21:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:43:46 --> No URI present. Default controller set.
DEBUG - 2022-10-05 21:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 21:43:46 --> 404 Page Not Found: Feed/index
DEBUG - 2022-10-05 21:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:52:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 21:52:38 --> 404 Page Not Found: Shop/index
DEBUG - 2022-10-05 21:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:33 --> No URI present. Default controller set.
DEBUG - 2022-10-05 21:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 21:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 21:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 21:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:10:25 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:10:26 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:19:47 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:21:12 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:30:40 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:37:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 22:37:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-05 22:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:42:02 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-05 22:51:16 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-10-05 22:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:02 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:37 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:56:02 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:57:29 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:57:35 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:46 --> No URI present. Default controller set.
DEBUG - 2022-10-05 22:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 22:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 22:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:01:17 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:12:16 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:22:32 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:27:52 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:29:45 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:31:35 --> Total execution time: 0.0876
DEBUG - 2022-10-05 23:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:31:37 --> Total execution time: 0.1309
DEBUG - 2022-10-05 23:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:31:38 --> Total execution time: 0.1277
DEBUG - 2022-10-05 23:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:31:42 --> Total execution time: 0.1284
DEBUG - 2022-10-05 23:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:31:43 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:35:52 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:39 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:40 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:36:41 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:53:30 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:53:31 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-05 23:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-05 23:56:57 --> No URI present. Default controller set.
DEBUG - 2022-10-05 23:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-05 23:56:57 --> Encryption: Auto-configured driver 'openssl'.
