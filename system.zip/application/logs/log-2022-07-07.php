<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-07 00:00:41 --> Total execution time: 0.0406
DEBUG - 2022-07-07 00:03:17 --> Total execution time: 0.0639
DEBUG - 2022-07-07 00:03:20 --> Total execution time: 0.0552
DEBUG - 2022-07-07 00:03:26 --> Total execution time: 0.0851
DEBUG - 2022-07-07 00:03:37 --> Total execution time: 0.0914
DEBUG - 2022-07-07 00:04:47 --> Total execution time: 0.0709
DEBUG - 2022-07-07 00:05:57 --> Total execution time: 0.0574
DEBUG - 2022-07-07 00:06:34 --> Total execution time: 0.0617
DEBUG - 2022-07-07 00:06:36 --> Total execution time: 0.0500
DEBUG - 2022-07-07 00:06:44 --> Total execution time: 0.0537
DEBUG - 2022-07-07 00:06:47 --> Total execution time: 0.0953
DEBUG - 2022-07-07 00:07:00 --> Total execution time: 0.0503
DEBUG - 2022-07-07 00:12:03 --> Total execution time: 0.1009
DEBUG - 2022-07-07 00:12:08 --> Total execution time: 0.0629
DEBUG - 2022-07-07 00:12:13 --> Total execution time: 0.0493
DEBUG - 2022-07-07 00:12:37 --> Total execution time: 0.0599
DEBUG - 2022-07-07 00:13:05 --> Total execution time: 0.0348
DEBUG - 2022-07-07 00:13:33 --> Total execution time: 0.0398
DEBUG - 2022-07-07 00:13:37 --> Total execution time: 0.0425
DEBUG - 2022-07-07 00:13:37 --> Total execution time: 0.0383
DEBUG - 2022-07-07 00:13:51 --> Total execution time: 0.0745
DEBUG - 2022-07-07 00:13:54 --> Total execution time: 0.0328
DEBUG - 2022-07-07 00:14:18 --> Total execution time: 0.0813
DEBUG - 2022-07-07 00:14:20 --> Total execution time: 0.0374
DEBUG - 2022-07-07 00:14:21 --> Total execution time: 0.0669
DEBUG - 2022-07-07 00:14:23 --> Total execution time: 0.0402
DEBUG - 2022-07-07 00:14:35 --> Total execution time: 0.0535
DEBUG - 2022-07-07 00:15:36 --> Total execution time: 0.1665
DEBUG - 2022-07-07 00:30:02 --> Total execution time: 0.2734
DEBUG - 2022-07-07 00:36:53 --> Total execution time: 0.0925
DEBUG - 2022-07-07 00:36:53 --> Total execution time: 0.0346
DEBUG - 2022-07-07 00:36:54 --> Total execution time: 0.0645
DEBUG - 2022-07-07 00:37:46 --> Total execution time: 0.0542
DEBUG - 2022-07-07 00:37:46 --> Total execution time: 0.0500
DEBUG - 2022-07-07 00:37:46 --> Total execution time: 0.1069
DEBUG - 2022-07-07 00:37:46 --> Total execution time: 0.0479
DEBUG - 2022-07-07 00:37:47 --> Total execution time: 0.0739
DEBUG - 2022-07-07 00:37:47 --> Total execution time: 0.1284
DEBUG - 2022-07-07 00:37:47 --> Total execution time: 0.0544
DEBUG - 2022-07-07 00:37:53 --> Total execution time: 0.0537
DEBUG - 2022-07-07 00:37:54 --> Total execution time: 0.0366
DEBUG - 2022-07-07 00:37:55 --> Total execution time: 0.0512
DEBUG - 2022-07-07 00:38:01 --> Total execution time: 0.0563
DEBUG - 2022-07-07 00:48:09 --> Total execution time: 0.1089
DEBUG - 2022-07-07 00:51:31 --> Total execution time: 0.0422
DEBUG - 2022-07-07 00:52:25 --> Total execution time: 0.0589
DEBUG - 2022-07-07 00:54:21 --> Total execution time: 0.0406
DEBUG - 2022-07-07 00:55:29 --> Total execution time: 0.0341
DEBUG - 2022-07-07 00:56:18 --> Total execution time: 0.0537
DEBUG - 2022-07-07 00:57:06 --> Total execution time: 0.0798
DEBUG - 2022-07-07 00:57:13 --> Total execution time: 0.0681
DEBUG - 2022-07-07 00:57:21 --> Total execution time: 0.0683
DEBUG - 2022-07-07 00:57:30 --> Total execution time: 0.0514
DEBUG - 2022-07-07 00:59:25 --> Total execution time: 0.0513
DEBUG - 2022-07-07 00:59:27 --> Total execution time: 0.0635
DEBUG - 2022-07-07 01:08:24 --> Total execution time: 0.2136
DEBUG - 2022-07-07 01:08:26 --> Total execution time: 0.0625
DEBUG - 2022-07-07 01:08:30 --> Total execution time: 0.1277
DEBUG - 2022-07-07 01:08:31 --> Total execution time: 0.0541
DEBUG - 2022-07-07 01:08:31 --> Total execution time: 0.0536
DEBUG - 2022-07-07 01:08:31 --> Total execution time: 0.0535
DEBUG - 2022-07-07 01:08:32 --> Total execution time: 0.0333
DEBUG - 2022-07-07 01:08:41 --> Total execution time: 0.0601
DEBUG - 2022-07-07 01:08:46 --> Total execution time: 0.0562
DEBUG - 2022-07-07 01:08:50 --> Total execution time: 0.0385
DEBUG - 2022-07-07 01:09:26 --> Total execution time: 0.0634
DEBUG - 2022-07-07 01:10:29 --> Total execution time: 0.0492
DEBUG - 2022-07-07 01:16:41 --> Total execution time: 0.1434
DEBUG - 2022-07-07 01:30:03 --> Total execution time: 0.1252
DEBUG - 2022-07-07 01:34:56 --> Total execution time: 0.1776
DEBUG - 2022-07-07 01:40:21 --> Total execution time: 0.1031
DEBUG - 2022-07-07 02:08:42 --> Total execution time: 0.0990
DEBUG - 2022-07-07 02:08:48 --> Total execution time: 0.0508
DEBUG - 2022-07-07 02:08:51 --> Total execution time: 0.0484
DEBUG - 2022-07-07 02:08:54 --> Total execution time: 0.0496
DEBUG - 2022-07-07 02:09:03 --> Total execution time: 0.0745
DEBUG - 2022-07-07 02:09:24 --> Total execution time: 0.0898
DEBUG - 2022-07-07 02:09:42 --> Total execution time: 0.0683
DEBUG - 2022-07-07 02:14:26 --> Total execution time: 0.0574
DEBUG - 2022-07-07 02:14:35 --> Total execution time: 0.0610
DEBUG - 2022-07-07 02:17:56 --> Total execution time: 0.0987
DEBUG - 2022-07-07 02:18:02 --> Total execution time: 0.0826
DEBUG - 2022-07-07 02:18:26 --> Total execution time: 0.0823
DEBUG - 2022-07-07 02:18:34 --> Total execution time: 0.0761
DEBUG - 2022-07-07 02:18:46 --> Total execution time: 0.0819
DEBUG - 2022-07-07 02:18:50 --> Total execution time: 0.0903
DEBUG - 2022-07-07 02:18:55 --> Total execution time: 0.0634
DEBUG - 2022-07-07 02:19:05 --> Total execution time: 0.0549
DEBUG - 2022-07-07 02:19:18 --> Total execution time: 0.0784
DEBUG - 2022-07-07 02:19:29 --> Total execution time: 0.1327
DEBUG - 2022-07-07 02:20:39 --> Total execution time: 1.9041
DEBUG - 2022-07-07 02:20:50 --> Total execution time: 0.0566
DEBUG - 2022-07-07 02:20:55 --> Total execution time: 0.0991
DEBUG - 2022-07-07 02:30:02 --> Total execution time: 0.1212
DEBUG - 2022-07-07 02:31:06 --> Total execution time: 0.0639
DEBUG - 2022-07-07 02:59:59 --> Total execution time: 0.1858
DEBUG - 2022-07-07 03:16:41 --> Total execution time: 0.1905
DEBUG - 2022-07-07 03:16:43 --> Total execution time: 0.0474
DEBUG - 2022-07-07 03:26:29 --> Total execution time: 0.1110
DEBUG - 2022-07-07 03:30:04 --> Total execution time: 0.1004
DEBUG - 2022-07-07 03:30:13 --> Total execution time: 0.0450
DEBUG - 2022-07-07 03:32:22 --> Total execution time: 0.0951
DEBUG - 2022-07-07 03:34:23 --> Total execution time: 0.0386
DEBUG - 2022-07-07 03:37:11 --> Total execution time: 0.0837
DEBUG - 2022-07-07 03:39:28 --> Total execution time: 0.0857
DEBUG - 2022-07-07 03:41:52 --> Total execution time: 0.1004
DEBUG - 2022-07-07 03:44:48 --> Total execution time: 0.0833
DEBUG - 2022-07-07 03:47:01 --> Total execution time: 0.0375
DEBUG - 2022-07-07 04:05:59 --> Total execution time: 0.1757
DEBUG - 2022-07-07 04:30:03 --> Total execution time: 0.2841
DEBUG - 2022-07-07 04:59:30 --> Total execution time: 0.2217
DEBUG - 2022-07-07 04:59:34 --> Total execution time: 0.0407
DEBUG - 2022-07-07 04:59:46 --> Total execution time: 0.0782
DEBUG - 2022-07-07 04:59:53 --> Total execution time: 0.0685
DEBUG - 2022-07-07 04:59:56 --> Total execution time: 0.0630
DEBUG - 2022-07-07 05:00:17 --> Total execution time: 0.0550
DEBUG - 2022-07-07 05:04:56 --> Total execution time: 0.1950
DEBUG - 2022-07-07 05:05:01 --> Total execution time: 0.1232
DEBUG - 2022-07-07 05:05:11 --> Total execution time: 0.0494
DEBUG - 2022-07-07 05:14:55 --> Total execution time: 0.1213
DEBUG - 2022-07-07 05:19:48 --> Total execution time: 0.1058
DEBUG - 2022-07-07 05:26:51 --> Total execution time: 0.1362
DEBUG - 2022-07-07 05:29:04 --> Total execution time: 0.0952
DEBUG - 2022-07-07 05:29:10 --> Total execution time: 0.0483
DEBUG - 2022-07-07 05:30:02 --> Total execution time: 0.1064
DEBUG - 2022-07-07 05:30:36 --> Total execution time: 0.0533
DEBUG - 2022-07-07 05:48:24 --> Total execution time: 0.1337
DEBUG - 2022-07-07 06:19:23 --> Total execution time: 2.5050
DEBUG - 2022-07-07 06:30:03 --> Total execution time: 0.1498
DEBUG - 2022-07-07 07:02:23 --> Total execution time: 0.0541
DEBUG - 2022-07-07 07:27:19 --> Total execution time: 0.1157
DEBUG - 2022-07-07 07:28:12 --> Total execution time: 0.0573
DEBUG - 2022-07-07 07:30:05 --> Total execution time: 0.0510
DEBUG - 2022-07-07 07:30:57 --> Total execution time: 0.0407
DEBUG - 2022-07-07 07:36:14 --> Total execution time: 0.1071
DEBUG - 2022-07-07 07:37:20 --> Total execution time: 0.0414
DEBUG - 2022-07-07 07:37:23 --> Total execution time: 0.0403
DEBUG - 2022-07-07 07:37:31 --> Total execution time: 0.0994
DEBUG - 2022-07-07 07:37:39 --> Total execution time: 0.0757
DEBUG - 2022-07-07 07:37:42 --> Total execution time: 0.0673
DEBUG - 2022-07-07 07:37:52 --> Total execution time: 0.0522
DEBUG - 2022-07-07 07:40:59 --> Total execution time: 0.0824
DEBUG - 2022-07-07 07:41:02 --> Total execution time: 0.0489
DEBUG - 2022-07-07 07:48:14 --> Total execution time: 0.0524
DEBUG - 2022-07-07 07:48:36 --> Total execution time: 0.0513
DEBUG - 2022-07-07 07:48:52 --> Total execution time: 0.0776
DEBUG - 2022-07-07 07:48:59 --> Total execution time: 0.0650
DEBUG - 2022-07-07 07:49:30 --> Total execution time: 0.1859
DEBUG - 2022-07-07 07:49:51 --> Total execution time: 0.0833
DEBUG - 2022-07-07 07:49:57 --> Total execution time: 0.0990
DEBUG - 2022-07-07 07:50:04 --> Total execution time: 0.0627
DEBUG - 2022-07-07 07:50:19 --> Total execution time: 0.0657
DEBUG - 2022-07-07 07:54:25 --> Total execution time: 0.2075
DEBUG - 2022-07-07 07:54:29 --> Total execution time: 0.0591
DEBUG - 2022-07-07 07:54:44 --> Total execution time: 0.0566
DEBUG - 2022-07-07 07:55:00 --> Total execution time: 0.0672
DEBUG - 2022-07-07 07:55:02 --> Total execution time: 0.0550
DEBUG - 2022-07-07 07:55:12 --> Total execution time: 0.0753
DEBUG - 2022-07-07 07:55:38 --> Total execution time: 0.0400
DEBUG - 2022-07-07 07:55:39 --> Total execution time: 0.0431
DEBUG - 2022-07-07 07:55:44 --> Total execution time: 0.0595
DEBUG - 2022-07-07 07:55:47 --> Total execution time: 0.0697
DEBUG - 2022-07-07 07:56:00 --> Total execution time: 0.0722
DEBUG - 2022-07-07 07:56:03 --> Total execution time: 0.0753
DEBUG - 2022-07-07 07:56:48 --> Total execution time: 0.0491
DEBUG - 2022-07-07 07:56:56 --> Total execution time: 0.0485
DEBUG - 2022-07-07 07:57:31 --> Total execution time: 0.0422
DEBUG - 2022-07-07 08:00:16 --> Total execution time: 0.1393
DEBUG - 2022-07-07 08:00:34 --> Total execution time: 0.0581
DEBUG - 2022-07-07 08:00:52 --> Total execution time: 0.0550
DEBUG - 2022-07-07 08:01:05 --> Total execution time: 0.0548
DEBUG - 2022-07-07 08:01:08 --> Total execution time: 0.0690
DEBUG - 2022-07-07 08:01:17 --> Total execution time: 0.0485
DEBUG - 2022-07-07 08:07:08 --> Total execution time: 0.1275
DEBUG - 2022-07-07 08:14:12 --> Total execution time: 0.2127
DEBUG - 2022-07-07 08:17:40 --> Total execution time: 0.1070
DEBUG - 2022-07-07 08:17:44 --> Total execution time: 0.0696
DEBUG - 2022-07-07 08:17:47 --> Total execution time: 0.0575
DEBUG - 2022-07-07 08:17:50 --> Total execution time: 0.0970
DEBUG - 2022-07-07 08:17:59 --> Total execution time: 0.0491
DEBUG - 2022-07-07 08:27:28 --> Total execution time: 0.2256
DEBUG - 2022-07-07 08:27:48 --> Total execution time: 0.0491
DEBUG - 2022-07-07 08:30:03 --> Total execution time: 0.2025
DEBUG - 2022-07-07 08:32:40 --> Total execution time: 0.0526
DEBUG - 2022-07-07 08:32:54 --> Total execution time: 0.0551
DEBUG - 2022-07-07 08:33:11 --> Total execution time: 0.0489
DEBUG - 2022-07-07 08:33:30 --> Total execution time: 0.0475
DEBUG - 2022-07-07 08:33:33 --> Total execution time: 0.0544
DEBUG - 2022-07-07 08:34:01 --> Total execution time: 0.0519
DEBUG - 2022-07-07 08:34:02 --> Total execution time: 0.1291
DEBUG - 2022-07-07 08:34:05 --> Total execution time: 0.0865
DEBUG - 2022-07-07 08:34:05 --> Total execution time: 0.0488
DEBUG - 2022-07-07 08:34:26 --> Total execution time: 0.0368
DEBUG - 2022-07-07 08:42:46 --> Total execution time: 0.1727
DEBUG - 2022-07-07 08:42:52 --> Total execution time: 0.0719
DEBUG - 2022-07-07 08:43:05 --> Total execution time: 0.0633
DEBUG - 2022-07-07 08:43:16 --> Total execution time: 0.0504
DEBUG - 2022-07-07 08:43:20 --> Total execution time: 0.0520
DEBUG - 2022-07-07 08:43:30 --> Total execution time: 0.0598
DEBUG - 2022-07-07 08:43:34 --> Total execution time: 0.0570
DEBUG - 2022-07-07 08:43:41 --> Total execution time: 0.0532
DEBUG - 2022-07-07 08:45:59 --> Total execution time: 0.0430
DEBUG - 2022-07-07 08:48:29 --> Total execution time: 0.1075
DEBUG - 2022-07-07 08:49:20 --> Total execution time: 0.0472
DEBUG - 2022-07-07 08:49:47 --> Total execution time: 0.1484
DEBUG - 2022-07-07 08:49:50 --> Total execution time: 0.0641
DEBUG - 2022-07-07 08:49:54 --> Total execution time: 0.0647
DEBUG - 2022-07-07 08:49:59 --> Total execution time: 0.0533
DEBUG - 2022-07-07 08:50:19 --> Total execution time: 0.0542
DEBUG - 2022-07-07 08:50:24 --> Total execution time: 0.0548
DEBUG - 2022-07-07 08:50:28 --> Total execution time: 0.0806
DEBUG - 2022-07-07 08:50:35 --> Total execution time: 0.0634
DEBUG - 2022-07-07 08:55:30 --> Total execution time: 0.0840
DEBUG - 2022-07-07 08:58:18 --> Total execution time: 0.2164
DEBUG - 2022-07-07 08:58:21 --> Total execution time: 0.0588
DEBUG - 2022-07-07 08:58:24 --> Total execution time: 0.0587
DEBUG - 2022-07-07 08:58:27 --> Total execution time: 0.0579
DEBUG - 2022-07-07 08:58:37 --> Total execution time: 0.0547
DEBUG - 2022-07-07 09:06:57 --> Total execution time: 0.1102
DEBUG - 2022-07-07 09:06:58 --> Total execution time: 0.0398
DEBUG - 2022-07-07 09:07:06 --> Total execution time: 0.0355
DEBUG - 2022-07-07 09:07:16 --> Total execution time: 0.0583
DEBUG - 2022-07-07 09:07:21 --> Total execution time: 0.2600
DEBUG - 2022-07-07 09:07:32 --> Total execution time: 0.0599
DEBUG - 2022-07-07 09:07:58 --> Total execution time: 0.0405
DEBUG - 2022-07-07 09:12:06 --> Total execution time: 1.9734
DEBUG - 2022-07-07 09:12:47 --> Total execution time: 0.0402
DEBUG - 2022-07-07 09:14:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:14:21 --> Total execution time: 0.0476
DEBUG - 2022-07-07 09:14:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:14:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:14:23 --> Total execution time: 0.1815
DEBUG - 2022-07-07 09:14:59 --> Total execution time: 0.0527
DEBUG - 2022-07-07 09:15:12 --> Total execution time: 0.0878
DEBUG - 2022-07-07 09:15:22 --> Total execution time: 0.0539
DEBUG - 2022-07-07 09:15:25 --> Total execution time: 0.0730
DEBUG - 2022-07-07 09:15:41 --> Total execution time: 0.0374
DEBUG - 2022-07-07 09:21:39 --> Total execution time: 0.1254
DEBUG - 2022-07-07 09:21:44 --> Total execution time: 0.0614
DEBUG - 2022-07-07 09:22:02 --> Total execution time: 0.0511
DEBUG - 2022-07-07 09:22:46 --> Total execution time: 0.0539
DEBUG - 2022-07-07 09:22:56 --> Total execution time: 0.0590
DEBUG - 2022-07-07 09:23:03 --> Total execution time: 0.0910
DEBUG - 2022-07-07 09:23:11 --> Total execution time: 0.0679
DEBUG - 2022-07-07 09:24:48 --> Total execution time: 0.0875
DEBUG - 2022-07-07 09:24:56 --> Total execution time: 0.0544
DEBUG - 2022-07-07 09:27:45 --> Total execution time: 0.0449
DEBUG - 2022-07-07 09:27:58 --> Total execution time: 0.0391
DEBUG - 2022-07-07 09:28:20 --> Total execution time: 0.0590
DEBUG - 2022-07-07 09:28:28 --> Total execution time: 0.0801
DEBUG - 2022-07-07 09:28:36 --> Total execution time: 0.1461
DEBUG - 2022-07-07 09:29:00 --> Total execution time: 0.0337
DEBUG - 2022-07-07 09:29:06 --> Total execution time: 0.0820
DEBUG - 2022-07-07 09:29:19 --> Total execution time: 0.0544
DEBUG - 2022-07-07 09:29:25 --> Total execution time: 0.0480
DEBUG - 2022-07-07 09:29:39 --> Total execution time: 0.0487
DEBUG - 2022-07-07 09:29:42 --> Total execution time: 0.0500
DEBUG - 2022-07-07 09:30:02 --> Total execution time: 0.0727
DEBUG - 2022-07-07 09:36:00 --> Total execution time: 0.1116
DEBUG - 2022-07-07 09:36:00 --> Total execution time: 0.0386
DEBUG - 2022-07-07 09:37:30 --> Total execution time: 0.1336
DEBUG - 2022-07-07 09:39:20 --> Total execution time: 0.0600
DEBUG - 2022-07-07 09:39:25 --> Total execution time: 0.0579
DEBUG - 2022-07-07 09:39:34 --> Total execution time: 0.0577
DEBUG - 2022-07-07 09:39:38 --> Total execution time: 0.0517
DEBUG - 2022-07-07 09:39:42 --> Total execution time: 0.0934
DEBUG - 2022-07-07 09:39:49 --> Total execution time: 0.0719
DEBUG - 2022-07-07 09:40:12 --> Total execution time: 0.0743
DEBUG - 2022-07-07 09:41:21 --> Total execution time: 0.0914
DEBUG - 2022-07-07 09:41:25 --> Total execution time: 0.0459
DEBUG - 2022-07-07 09:41:33 --> Total execution time: 0.0421
DEBUG - 2022-07-07 09:53:00 --> Total execution time: 0.3040
DEBUG - 2022-07-07 09:53:05 --> Total execution time: 0.0494
DEBUG - 2022-07-07 09:53:07 --> Total execution time: 0.0429
DEBUG - 2022-07-07 09:55:42 --> Total execution time: 0.1114
DEBUG - 2022-07-07 09:56:00 --> Total execution time: 0.0357
DEBUG - 2022-07-07 09:56:29 --> Total execution time: 0.1752
DEBUG - 2022-07-07 09:56:40 --> Total execution time: 0.1743
DEBUG - 2022-07-07 09:57:07 --> Total execution time: 0.0739
DEBUG - 2022-07-07 09:57:20 --> Total execution time: 0.0769
DEBUG - 2022-07-07 09:57:32 --> Total execution time: 0.0754
DEBUG - 2022-07-07 09:57:35 --> Total execution time: 0.0615
DEBUG - 2022-07-07 09:57:38 --> Total execution time: 0.0393
DEBUG - 2022-07-07 09:57:44 --> Total execution time: 0.0836
DEBUG - 2022-07-07 09:57:45 --> Total execution time: 0.0817
DEBUG - 2022-07-07 09:58:27 --> Total execution time: 0.0392
DEBUG - 2022-07-07 09:58:29 --> Total execution time: 0.0355
DEBUG - 2022-07-07 09:58:34 --> Total execution time: 0.0332
DEBUG - 2022-07-07 09:58:56 --> Total execution time: 0.0854
DEBUG - 2022-07-07 09:59:03 --> Total execution time: 0.0869
DEBUG - 2022-07-07 10:00:56 --> Total execution time: 1.9624
DEBUG - 2022-07-07 10:01:44 --> Total execution time: 0.0660
DEBUG - 2022-07-07 10:02:02 --> Total execution time: 0.0736
DEBUG - 2022-07-07 10:02:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 10:02:16 --> Total execution time: 0.0566
DEBUG - 2022-07-07 10:02:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 10:02:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 10:02:18 --> Total execution time: 0.2125
DEBUG - 2022-07-07 10:02:43 --> Total execution time: 0.0712
DEBUG - 2022-07-07 10:02:58 --> Total execution time: 0.0526
DEBUG - 2022-07-07 10:03:14 --> Total execution time: 0.0600
DEBUG - 2022-07-07 10:03:19 --> Total execution time: 0.0819
DEBUG - 2022-07-07 10:04:23 --> Total execution time: 0.0370
DEBUG - 2022-07-07 10:05:02 --> Total execution time: 0.0566
DEBUG - 2022-07-07 10:05:12 --> Total execution time: 0.0568
DEBUG - 2022-07-07 10:06:00 --> Total execution time: 0.0557
DEBUG - 2022-07-07 10:06:12 --> Total execution time: 0.0446
DEBUG - 2022-07-07 10:07:45 --> Total execution time: 0.1289
DEBUG - 2022-07-07 10:07:53 --> Total execution time: 0.0715
DEBUG - 2022-07-07 10:08:09 --> Total execution time: 0.0867
DEBUG - 2022-07-07 10:08:14 --> Total execution time: 0.0630
DEBUG - 2022-07-07 10:08:39 --> Total execution time: 0.0510
DEBUG - 2022-07-07 10:10:05 --> Total execution time: 0.0762
DEBUG - 2022-07-07 10:10:15 --> Total execution time: 0.0673
DEBUG - 2022-07-07 10:10:17 --> Total execution time: 0.0568
DEBUG - 2022-07-07 10:10:40 --> Total execution time: 0.0527
DEBUG - 2022-07-07 10:10:53 --> Total execution time: 0.0717
DEBUG - 2022-07-07 10:11:11 --> Total execution time: 0.0852
DEBUG - 2022-07-07 10:11:16 --> Total execution time: 0.0629
DEBUG - 2022-07-07 10:12:37 --> Total execution time: 0.0788
DEBUG - 2022-07-07 10:13:01 --> Total execution time: 0.0401
DEBUG - 2022-07-07 10:13:08 --> Total execution time: 0.0352
DEBUG - 2022-07-07 10:13:27 --> Total execution time: 0.0661
DEBUG - 2022-07-07 10:13:31 --> Total execution time: 0.0961
DEBUG - 2022-07-07 10:14:57 --> Total execution time: 0.0437
DEBUG - 2022-07-07 10:18:22 --> Total execution time: 0.1021
DEBUG - 2022-07-07 10:23:17 --> Total execution time: 0.1592
DEBUG - 2022-07-07 10:29:57 --> Total execution time: 0.3062
DEBUG - 2022-07-07 10:29:58 --> Total execution time: 0.0604
DEBUG - 2022-07-07 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:30:02 --> Total execution time: 0.0972
DEBUG - 2022-07-07 00:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:30:07 --> Total execution time: 0.1206
DEBUG - 2022-07-07 00:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:00:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:30:11 --> Total execution time: 0.0895
DEBUG - 2022-07-07 00:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:00:53 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:30:53 --> Total execution time: 0.0439
DEBUG - 2022-07-07 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:20 --> Total execution time: 0.1309
DEBUG - 2022-07-07 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 00:05:22 --> 404 Page Not Found: Tel:9996629781/index
DEBUG - 2022-07-07 00:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:24 --> Total execution time: 0.0347
DEBUG - 2022-07-07 00:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:25 --> Total execution time: 0.0424
DEBUG - 2022-07-07 00:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:27 --> Total execution time: 0.0349
DEBUG - 2022-07-07 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:28 --> Total execution time: 0.0338
DEBUG - 2022-07-07 00:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:29 --> Total execution time: 0.0334
DEBUG - 2022-07-07 00:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:31 --> Total execution time: 0.0485
DEBUG - 2022-07-07 00:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:32 --> Total execution time: 0.0380
DEBUG - 2022-07-07 00:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:33 --> Total execution time: 0.0541
DEBUG - 2022-07-07 00:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:34 --> Total execution time: 0.0388
DEBUG - 2022-07-07 00:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:36 --> Total execution time: 0.0332
DEBUG - 2022-07-07 00:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:05:38 --> Total execution time: 0.0360
DEBUG - 2022-07-07 00:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:06:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:36:19 --> Total execution time: 0.1299
DEBUG - 2022-07-07 00:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:36:57 --> Total execution time: 0.1011
DEBUG - 2022-07-07 00:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:07:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:11 --> Total execution time: 0.0612
DEBUG - 2022-07-07 00:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:07:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:19 --> Total execution time: 0.0402
DEBUG - 2022-07-07 00:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:07:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:43 --> Total execution time: 0.0532
DEBUG - 2022-07-07 00:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:07:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:54 --> Total execution time: 0.1350
DEBUG - 2022-07-07 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:08:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:38:05 --> Total execution time: 0.0415
DEBUG - 2022-07-07 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:08:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:38:05 --> Total execution time: 0.0357
DEBUG - 2022-07-07 00:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:39:08 --> Total execution time: 0.2013
DEBUG - 2022-07-07 00:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 00:09:29 --> 404 Page Not Found: Wp-content/index
DEBUG - 2022-07-07 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:10:04 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:40:04 --> Total execution time: 0.0566
DEBUG - 2022-07-07 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:41:43 --> Total execution time: 2.0545
DEBUG - 2022-07-07 00:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:12:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:42:13 --> Total execution time: 0.0461
DEBUG - 2022-07-07 00:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:12:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 00:12:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 00:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:44:12 --> Total execution time: 0.0655
DEBUG - 2022-07-07 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:44:21 --> Total execution time: 0.0826
DEBUG - 2022-07-07 00:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:44:30 --> Total execution time: 0.1731
DEBUG - 2022-07-07 00:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:45:08 --> Total execution time: 0.0495
DEBUG - 2022-07-07 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:45:24 --> Total execution time: 0.0693
DEBUG - 2022-07-07 00:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:45:37 --> Total execution time: 0.0616
DEBUG - 2022-07-07 00:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:45:45 --> Total execution time: 0.0560
DEBUG - 2022-07-07 00:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:45:58 --> Total execution time: 0.0646
DEBUG - 2022-07-07 00:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 00:18:44 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-07 00:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:18:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:48:44 --> Total execution time: 0.0983
DEBUG - 2022-07-07 00:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:01 --> Total execution time: 0.0386
DEBUG - 2022-07-07 00:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:21 --> Total execution time: 0.0495
DEBUG - 2022-07-07 00:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:26 --> Total execution time: 0.0742
DEBUG - 2022-07-07 00:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:30 --> Total execution time: 0.0554
DEBUG - 2022-07-07 00:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:34 --> Total execution time: 0.0837
DEBUG - 2022-07-07 00:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:42 --> Total execution time: 0.0558
DEBUG - 2022-07-07 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:49 --> Total execution time: 0.0789
DEBUG - 2022-07-07 00:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:53 --> Total execution time: 0.0534
DEBUG - 2022-07-07 00:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:49:57 --> Total execution time: 0.0659
DEBUG - 2022-07-07 00:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:50:00 --> Total execution time: 0.0695
DEBUG - 2022-07-07 00:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:50:09 --> Total execution time: 0.0683
DEBUG - 2022-07-07 00:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 00:20:57 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 00:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:21:49 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:51:49 --> Total execution time: 0.0567
DEBUG - 2022-07-07 00:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:51:53 --> Total execution time: 0.0344
DEBUG - 2022-07-07 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:04 --> Total execution time: 0.0713
DEBUG - 2022-07-07 00:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:11 --> Total execution time: 0.0861
DEBUG - 2022-07-07 00:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:23 --> Total execution time: 0.0573
DEBUG - 2022-07-07 00:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:26 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:26 --> Total execution time: 0.0401
DEBUG - 2022-07-07 00:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:37 --> Total execution time: 0.0554
DEBUG - 2022-07-07 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:38 --> Total execution time: 0.0523
DEBUG - 2022-07-07 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:48 --> Total execution time: 0.0332
DEBUG - 2022-07-07 00:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:00 --> Total execution time: 0.0537
DEBUG - 2022-07-07 00:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:20 --> Total execution time: 0.0623
DEBUG - 2022-07-07 00:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:26 --> Total execution time: 0.0343
DEBUG - 2022-07-07 00:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:26 --> Total execution time: 0.0354
DEBUG - 2022-07-07 00:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:27 --> Total execution time: 0.0341
DEBUG - 2022-07-07 00:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:36 --> Total execution time: 0.0563
DEBUG - 2022-07-07 00:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:40 --> Total execution time: 0.0382
DEBUG - 2022-07-07 00:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:56 --> Total execution time: 0.0646
DEBUG - 2022-07-07 00:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:54:01 --> Total execution time: 0.0336
DEBUG - 2022-07-07 00:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:54:04 --> Total execution time: 0.0622
DEBUG - 2022-07-07 00:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:54:08 --> Total execution time: 0.0351
DEBUG - 2022-07-07 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:54:21 --> Total execution time: 0.0527
DEBUG - 2022-07-07 00:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:54:30 --> Total execution time: 0.0512
DEBUG - 2022-07-07 00:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:56:00 --> Total execution time: 0.0364
DEBUG - 2022-07-07 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:57:00 --> Total execution time: 0.0535
DEBUG - 2022-07-07 00:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:57:15 --> Total execution time: 0.0607
DEBUG - 2022-07-07 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:57:28 --> Total execution time: 0.0555
DEBUG - 2022-07-07 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:57:36 --> Total execution time: 0.0711
DEBUG - 2022-07-07 00:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:58:37 --> Total execution time: 0.0498
DEBUG - 2022-07-07 00:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:01:00 --> Total execution time: 0.1845
DEBUG - 2022-07-07 00:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:01:16 --> Total execution time: 0.0673
DEBUG - 2022-07-07 00:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:01:29 --> Total execution time: 0.0600
DEBUG - 2022-07-07 00:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:01:34 --> Total execution time: 0.0605
DEBUG - 2022-07-07 00:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:01:44 --> Total execution time: 0.0802
DEBUG - 2022-07-07 00:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:01:49 --> Total execution time: 0.1162
DEBUG - 2022-07-07 00:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:02:03 --> Total execution time: 0.0572
DEBUG - 2022-07-07 00:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:32:31 --> Total execution time: 0.0552
DEBUG - 2022-07-07 00:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:32:47 --> Total execution time: 0.0827
DEBUG - 2022-07-07 00:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:34:04 --> Total execution time: 0.0486
DEBUG - 2022-07-07 00:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:34:06 --> Total execution time: 0.0721
DEBUG - 2022-07-07 00:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:34:19 --> Total execution time: 0.0492
DEBUG - 2022-07-07 00:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:06:10 --> Total execution time: 0.0654
DEBUG - 2022-07-07 00:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:52:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:22:25 --> Total execution time: 0.2247
DEBUG - 2022-07-07 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:52:49 --> Total execution time: 0.0525
DEBUG - 2022-07-07 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:52:52 --> Total execution time: 0.0573
DEBUG - 2022-07-07 00:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:52:52 --> Total execution time: 0.1598
DEBUG - 2022-07-07 00:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:24:36 --> Total execution time: 0.0874
DEBUG - 2022-07-07 00:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:25:11 --> Total execution time: 0.0649
DEBUG - 2022-07-07 00:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:25:44 --> Total execution time: 0.0569
DEBUG - 2022-07-07 00:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:25:57 --> Total execution time: 0.0500
DEBUG - 2022-07-07 00:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:25:57 --> Total execution time: 0.0602
DEBUG - 2022-07-07 00:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 00:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:26:03 --> Total execution time: 0.1033
DEBUG - 2022-07-07 00:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:26:07 --> Total execution time: 0.0963
DEBUG - 2022-07-07 00:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:27:28 --> Total execution time: 0.0514
DEBUG - 2022-07-07 00:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 00:57:51 --> No URI present. Default controller set.
DEBUG - 2022-07-07 00:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 00:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:27:51 --> Total execution time: 0.0550
DEBUG - 2022-07-07 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:30:03 --> Total execution time: 0.1705
DEBUG - 2022-07-07 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:01:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:31:07 --> Total execution time: 0.0425
DEBUG - 2022-07-07 01:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:01:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:31:20 --> Total execution time: 0.0360
DEBUG - 2022-07-07 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:31:29 --> Total execution time: 0.0342
DEBUG - 2022-07-07 01:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:31:45 --> Total execution time: 0.0626
DEBUG - 2022-07-07 01:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:03:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:33:13 --> Total execution time: 0.1279
DEBUG - 2022-07-07 01:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:19 --> Total execution time: 0.0714
DEBUG - 2022-07-07 01:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:27 --> Total execution time: 0.0739
DEBUG - 2022-07-07 01:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:35 --> Total execution time: 0.0828
DEBUG - 2022-07-07 01:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:43 --> Total execution time: 0.0504
DEBUG - 2022-07-07 01:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:58 --> Total execution time: 0.0561
DEBUG - 2022-07-07 01:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:35:13 --> Total execution time: 0.0525
DEBUG - 2022-07-07 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:35:19 --> Total execution time: 0.0532
DEBUG - 2022-07-07 01:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:35:22 --> Total execution time: 0.0506
DEBUG - 2022-07-07 01:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:35:38 --> Total execution time: 0.0651
DEBUG - 2022-07-07 01:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:35:50 --> Total execution time: 0.0781
DEBUG - 2022-07-07 01:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:36:22 --> Total execution time: 0.0853
DEBUG - 2022-07-07 01:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:36:33 --> Total execution time: 0.1326
DEBUG - 2022-07-07 01:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:36:37 --> Total execution time: 0.0607
DEBUG - 2022-07-07 01:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:37:18 --> Total execution time: 0.0513
DEBUG - 2022-07-07 01:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:10:37 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:40:37 --> Total execution time: 0.1131
DEBUG - 2022-07-07 01:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:10:49 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:40:49 --> Total execution time: 0.0547
DEBUG - 2022-07-07 01:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:10:53 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:40:53 --> Total execution time: 0.0510
DEBUG - 2022-07-07 01:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:41:02 --> Total execution time: 0.0537
DEBUG - 2022-07-07 01:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:41:29 --> Total execution time: 0.0663
DEBUG - 2022-07-07 01:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:41:51 --> Total execution time: 0.0908
DEBUG - 2022-07-07 01:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:42:06 --> Total execution time: 0.0636
DEBUG - 2022-07-07 01:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:42:17 --> Total execution time: 0.0939
DEBUG - 2022-07-07 01:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:42:26 --> Total execution time: 0.0538
DEBUG - 2022-07-07 01:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:42:35 --> Total execution time: 0.0378
DEBUG - 2022-07-07 01:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:03 --> Total execution time: 0.0668
DEBUG - 2022-07-07 01:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:11 --> Total execution time: 0.0425
DEBUG - 2022-07-07 01:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:45:44 --> Total execution time: 0.0566
DEBUG - 2022-07-07 01:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:45:45 --> Total execution time: 0.0809
DEBUG - 2022-07-07 01:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:45:50 --> Total execution time: 0.0444
DEBUG - 2022-07-07 01:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:45:58 --> Total execution time: 0.0677
DEBUG - 2022-07-07 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:17 --> Total execution time: 0.1135
DEBUG - 2022-07-07 01:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:30 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:30 --> Total execution time: 0.0379
DEBUG - 2022-07-07 01:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:30 --> Total execution time: 0.0717
DEBUG - 2022-07-07 01:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:31 --> Total execution time: 0.0603
DEBUG - 2022-07-07 01:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:39 --> Total execution time: 0.0618
DEBUG - 2022-07-07 01:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:42 --> Total execution time: 0.0629
DEBUG - 2022-07-07 01:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:49 --> Total execution time: 0.0744
DEBUG - 2022-07-07 01:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:46:59 --> Total execution time: 0.0556
DEBUG - 2022-07-07 01:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:47:02 --> Total execution time: 0.0570
DEBUG - 2022-07-07 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:47:03 --> Total execution time: 0.0539
DEBUG - 2022-07-07 01:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:47:06 --> Total execution time: 0.0780
DEBUG - 2022-07-07 01:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:47:51 --> Total execution time: 0.0585
DEBUG - 2022-07-07 01:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:47:57 --> Total execution time: 0.0339
DEBUG - 2022-07-07 01:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 01:19:55 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-07-07 01:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 01:19:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 01:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:02 --> Total execution time: 0.0683
DEBUG - 2022-07-07 01:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:07 --> Total execution time: 0.0402
DEBUG - 2022-07-07 01:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:13 --> Total execution time: 0.0693
DEBUG - 2022-07-07 01:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:22 --> Total execution time: 0.0650
DEBUG - 2022-07-07 01:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:25 --> Total execution time: 0.0566
DEBUG - 2022-07-07 01:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:20:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:52 --> Total execution time: 0.0415
DEBUG - 2022-07-07 01:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:24 --> Total execution time: 0.0762
DEBUG - 2022-07-07 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:30 --> Total execution time: 0.0273
DEBUG - 2022-07-07 01:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:31 --> Total execution time: 0.0530
DEBUG - 2022-07-07 01:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:36 --> Total execution time: 0.1464
DEBUG - 2022-07-07 01:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:38 --> Total execution time: 0.0394
DEBUG - 2022-07-07 01:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:45 --> Total execution time: 0.0598
DEBUG - 2022-07-07 01:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:46 --> Total execution time: 0.0603
DEBUG - 2022-07-07 01:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:52:14 --> Total execution time: 0.0612
DEBUG - 2022-07-07 01:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:52:27 --> Total execution time: 0.0600
DEBUG - 2022-07-07 01:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:52:42 --> Total execution time: 0.0676
DEBUG - 2022-07-07 01:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:52:46 --> Total execution time: 0.0798
DEBUG - 2022-07-07 01:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:52:59 --> Total execution time: 0.0843
DEBUG - 2022-07-07 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:02 --> Total execution time: 0.0756
DEBUG - 2022-07-07 01:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:08 --> Total execution time: 0.0607
DEBUG - 2022-07-07 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:13 --> Total execution time: 0.0565
DEBUG - 2022-07-07 01:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:27 --> Total execution time: 0.0501
DEBUG - 2022-07-07 01:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:31 --> Total execution time: 0.0547
DEBUG - 2022-07-07 01:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:37 --> Total execution time: 0.0533
DEBUG - 2022-07-07 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:40 --> Total execution time: 0.0532
DEBUG - 2022-07-07 01:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:41 --> Total execution time: 0.0595
DEBUG - 2022-07-07 01:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:53:42 --> Total execution time: 0.0646
DEBUG - 2022-07-07 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:05 --> Total execution time: 0.1451
DEBUG - 2022-07-07 01:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:06 --> Total execution time: 0.1153
DEBUG - 2022-07-07 01:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:07 --> Total execution time: 0.5915
DEBUG - 2022-07-07 01:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:09 --> Total execution time: 0.3016
DEBUG - 2022-07-07 01:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:11 --> Total execution time: 0.2482
DEBUG - 2022-07-07 01:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:18 --> Total execution time: 0.0569
DEBUG - 2022-07-07 01:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:25 --> Total execution time: 0.0401
DEBUG - 2022-07-07 01:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:29 --> Total execution time: 0.0526
DEBUG - 2022-07-07 01:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:32 --> Total execution time: 0.0534
DEBUG - 2022-07-07 01:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:41 --> Total execution time: 0.0364
DEBUG - 2022-07-07 01:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:46 --> Total execution time: 0.1543
DEBUG - 2022-07-07 01:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:52 --> Total execution time: 0.1888
DEBUG - 2022-07-07 01:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:55 --> Total execution time: 0.0337
DEBUG - 2022-07-07 01:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:57 --> Total execution time: 0.0805
DEBUG - 2022-07-07 01:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:57 --> Total execution time: 0.0622
DEBUG - 2022-07-07 01:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:59 --> Total execution time: 0.0704
DEBUG - 2022-07-07 01:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:04 --> Total execution time: 0.0551
DEBUG - 2022-07-07 01:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:08 --> Total execution time: 0.0596
DEBUG - 2022-07-07 01:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:09 --> Total execution time: 0.0708
DEBUG - 2022-07-07 01:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:09 --> Total execution time: 0.1618
DEBUG - 2022-07-07 01:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:15 --> Total execution time: 0.0438
DEBUG - 2022-07-07 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:16 --> Total execution time: 0.0908
DEBUG - 2022-07-07 01:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:26 --> Total execution time: 0.0574
DEBUG - 2022-07-07 01:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:30 --> Total execution time: 0.0593
DEBUG - 2022-07-07 01:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:42 --> Total execution time: 0.0772
DEBUG - 2022-07-07 01:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:43 --> Total execution time: 0.0810
DEBUG - 2022-07-07 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:46 --> Total execution time: 0.0574
DEBUG - 2022-07-07 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:50 --> Total execution time: 0.0592
DEBUG - 2022-07-07 01:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:55:57 --> Total execution time: 0.0599
DEBUG - 2022-07-07 01:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:02 --> Total execution time: 0.1014
DEBUG - 2022-07-07 01:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:03 --> Total execution time: 0.0598
DEBUG - 2022-07-07 01:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:04 --> Total execution time: 0.0611
DEBUG - 2022-07-07 01:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:06 --> Total execution time: 0.0972
DEBUG - 2022-07-07 01:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:15 --> Total execution time: 0.0349
DEBUG - 2022-07-07 01:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:18 --> Total execution time: 0.1455
DEBUG - 2022-07-07 01:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:19 --> Total execution time: 0.0508
DEBUG - 2022-07-07 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:37 --> Total execution time: 0.0551
DEBUG - 2022-07-07 01:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:56:46 --> Total execution time: 0.0448
DEBUG - 2022-07-07 01:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:04 --> Total execution time: 0.0555
DEBUG - 2022-07-07 01:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:12 --> Total execution time: 0.0617
DEBUG - 2022-07-07 01:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:13 --> Total execution time: 0.0531
DEBUG - 2022-07-07 01:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:16 --> Total execution time: 0.0557
DEBUG - 2022-07-07 01:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:25 --> Total execution time: 0.0719
DEBUG - 2022-07-07 01:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:30 --> Total execution time: 0.0906
DEBUG - 2022-07-07 01:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:40 --> Total execution time: 0.0812
DEBUG - 2022-07-07 01:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:40 --> Total execution time: 0.0828
DEBUG - 2022-07-07 01:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:57:53 --> Total execution time: 0.0654
DEBUG - 2022-07-07 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:58:04 --> Total execution time: 0.0897
DEBUG - 2022-07-07 01:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:58:17 --> Total execution time: 0.0552
DEBUG - 2022-07-07 01:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:29:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:59:15 --> Total execution time: 0.0471
DEBUG - 2022-07-07 01:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:01:25 --> Total execution time: 0.1061
DEBUG - 2022-07-07 01:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:06 --> Total execution time: 0.0453
DEBUG - 2022-07-07 01:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:20 --> Total execution time: 0.0491
DEBUG - 2022-07-07 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:29 --> Total execution time: 0.0502
DEBUG - 2022-07-07 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:40 --> Total execution time: 0.0587
DEBUG - 2022-07-07 01:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:46 --> Total execution time: 0.0942
DEBUG - 2022-07-07 01:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:54 --> Total execution time: 0.0596
DEBUG - 2022-07-07 01:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:02:55 --> Total execution time: 0.0623
DEBUG - 2022-07-07 01:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:03:03 --> Total execution time: 0.0699
DEBUG - 2022-07-07 01:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:03:11 --> Total execution time: 0.1106
DEBUG - 2022-07-07 01:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:03:23 --> Total execution time: 0.0623
DEBUG - 2022-07-07 01:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:03:28 --> Total execution time: 0.0824
DEBUG - 2022-07-07 01:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:03:49 --> Total execution time: 0.0618
DEBUG - 2022-07-07 01:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:33:59 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:03:59 --> Total execution time: 0.0595
DEBUG - 2022-07-07 01:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:05:34 --> Total execution time: 0.0370
DEBUG - 2022-07-07 01:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 01:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:05:36 --> Total execution time: 0.0454
DEBUG - 2022-07-07 01:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 01:36:51 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 01:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:09:01 --> Total execution time: 0.2043
DEBUG - 2022-07-07 01:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:09:01 --> Total execution time: 0.0688
DEBUG - 2022-07-07 01:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 01:39:33 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 01:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:39:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:09:44 --> Total execution time: 0.0425
DEBUG - 2022-07-07 01:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:39:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:09:46 --> Total execution time: 0.0498
DEBUG - 2022-07-07 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:41:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 01:41:50 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 01:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:14:45 --> Total execution time: 0.1079
DEBUG - 2022-07-07 01:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:22:52 --> Total execution time: 0.1139
DEBUG - 2022-07-07 01:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:22:58 --> Total execution time: 0.0689
DEBUG - 2022-07-07 01:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:25:45 --> Total execution time: 0.2335
DEBUG - 2022-07-07 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:26:06 --> Total execution time: 0.0985
DEBUG - 2022-07-07 01:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:26:19 --> Total execution time: 0.0570
DEBUG - 2022-07-07 01:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:26:43 --> Total execution time: 0.0731
DEBUG - 2022-07-07 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:27:13 --> Total execution time: 0.0582
DEBUG - 2022-07-07 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:27:24 --> Total execution time: 0.1021
DEBUG - 2022-07-07 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:57:47 --> No URI present. Default controller set.
DEBUG - 2022-07-07 01:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:27:47 --> Total execution time: 0.0481
DEBUG - 2022-07-07 01:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:28:05 --> Total execution time: 0.0691
DEBUG - 2022-07-07 01:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:28:12 --> Total execution time: 0.0614
DEBUG - 2022-07-07 01:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:29:07 --> Total execution time: 0.0561
DEBUG - 2022-07-07 01:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 01:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 01:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:29:10 --> Total execution time: 0.0778
DEBUG - 2022-07-07 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:30:03 --> Total execution time: 0.0701
DEBUG - 2022-07-07 02:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:35:05 --> Total execution time: 0.1926
DEBUG - 2022-07-07 02:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:35:20 --> Total execution time: 0.0810
DEBUG - 2022-07-07 02:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:05:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:35:31 --> Total execution time: 0.0402
DEBUG - 2022-07-07 02:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:05:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:35:32 --> Total execution time: 0.0544
DEBUG - 2022-07-07 02:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:36:34 --> Total execution time: 0.0529
DEBUG - 2022-07-07 02:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 02:06:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 02:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:33 --> Total execution time: 0.0374
DEBUG - 2022-07-07 02:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:36 --> Total execution time: 0.0525
DEBUG - 2022-07-07 02:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:49 --> Total execution time: 0.0607
DEBUG - 2022-07-07 02:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:54 --> Total execution time: 0.0682
DEBUG - 2022-07-07 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:55 --> Total execution time: 0.0496
DEBUG - 2022-07-07 02:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:57 --> Total execution time: 0.0698
DEBUG - 2022-07-07 02:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:38:58 --> Total execution time: 0.0336
DEBUG - 2022-07-07 02:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:39:06 --> Total execution time: 0.0587
DEBUG - 2022-07-07 02:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:39:10 --> Total execution time: 0.0593
DEBUG - 2022-07-07 02:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:39:17 --> Total execution time: 0.0850
DEBUG - 2022-07-07 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:39:24 --> Total execution time: 0.0597
DEBUG - 2022-07-07 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:40:12 --> Total execution time: 0.0554
DEBUG - 2022-07-07 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:40:16 --> Total execution time: 0.0645
DEBUG - 2022-07-07 02:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:40:19 --> Total execution time: 0.0759
DEBUG - 2022-07-07 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:40:36 --> Total execution time: 0.0570
DEBUG - 2022-07-07 02:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:40:39 --> Total execution time: 0.0786
DEBUG - 2022-07-07 02:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:40:45 --> Total execution time: 0.0654
DEBUG - 2022-07-07 02:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:01 --> Total execution time: 0.0681
DEBUG - 2022-07-07 02:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:04 --> Total execution time: 0.0553
DEBUG - 2022-07-07 02:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:06 --> Total execution time: 0.0528
DEBUG - 2022-07-07 02:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:12 --> Total execution time: 0.0604
DEBUG - 2022-07-07 02:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:19 --> Total execution time: 0.0680
DEBUG - 2022-07-07 02:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:28 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:28 --> Total execution time: 0.0543
DEBUG - 2022-07-07 02:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:30 --> Total execution time: 0.0544
DEBUG - 2022-07-07 02:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:12:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:42:09 --> Total execution time: 0.0605
DEBUG - 2022-07-07 02:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:12:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:42:21 --> Total execution time: 0.0501
DEBUG - 2022-07-07 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:42:34 --> Total execution time: 1.9822
DEBUG - 2022-07-07 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:12:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 02:12:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 02:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:12:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:42:55 --> Total execution time: 0.0723
DEBUG - 2022-07-07 02:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:13:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:43:20 --> Total execution time: 0.0510
DEBUG - 2022-07-07 02:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:43:33 --> Total execution time: 0.0478
DEBUG - 2022-07-07 02:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:13:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:43:39 --> Total execution time: 0.1285
DEBUG - 2022-07-07 02:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:44:27 --> Total execution time: 0.0597
DEBUG - 2022-07-07 02:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:44:56 --> Total execution time: 0.1314
DEBUG - 2022-07-07 02:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:45:12 --> Total execution time: 0.0808
DEBUG - 2022-07-07 02:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:45:19 --> Total execution time: 0.0699
DEBUG - 2022-07-07 02:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:45:22 --> Total execution time: 0.0722
DEBUG - 2022-07-07 02:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:46:00 --> Total execution time: 0.0595
DEBUG - 2022-07-07 02:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:16:05 --> Total execution time: 0.0741
DEBUG - 2022-07-07 02:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:16:17 --> Total execution time: 0.0594
DEBUG - 2022-07-07 02:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:16:24 --> Total execution time: 0.0540
DEBUG - 2022-07-07 02:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:46:26 --> Total execution time: 0.0655
DEBUG - 2022-07-07 02:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:46:42 --> Total execution time: 0.0580
DEBUG - 2022-07-07 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:46:47 --> Total execution time: 0.0750
DEBUG - 2022-07-07 02:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:46:56 --> Total execution time: 0.0973
DEBUG - 2022-07-07 02:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:31 --> Total execution time: 0.1146
DEBUG - 2022-07-07 02:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:43 --> Total execution time: 0.0740
DEBUG - 2022-07-07 02:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:49 --> Total execution time: 0.0822
DEBUG - 2022-07-07 02:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:51 --> Total execution time: 0.0624
DEBUG - 2022-07-07 02:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:53 --> Total execution time: 0.0559
DEBUG - 2022-07-07 02:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:55 --> Total execution time: 0.0561
DEBUG - 2022-07-07 02:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:00 --> Total execution time: 0.0721
DEBUG - 2022-07-07 02:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:12 --> Total execution time: 0.0650
DEBUG - 2022-07-07 02:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:15 --> Total execution time: 0.0778
DEBUG - 2022-07-07 02:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:50:05 --> Total execution time: 0.0539
DEBUG - 2022-07-07 02:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:50:14 --> Total execution time: 0.0642
DEBUG - 2022-07-07 02:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:50:36 --> Total execution time: 0.0664
DEBUG - 2022-07-07 02:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:50:45 --> Total execution time: 0.0928
DEBUG - 2022-07-07 02:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:50:50 --> Total execution time: 0.0896
DEBUG - 2022-07-07 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:51:19 --> Total execution time: 0.0817
DEBUG - 2022-07-07 02:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:52:10 --> Total execution time: 0.0783
DEBUG - 2022-07-07 02:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:52:46 --> Total execution time: 0.0598
DEBUG - 2022-07-07 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:53:09 --> Total execution time: 0.0551
DEBUG - 2022-07-07 02:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:53:10 --> Total execution time: 0.0631
DEBUG - 2022-07-07 02:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:53:10 --> Total execution time: 0.0625
DEBUG - 2022-07-07 02:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:54:16 --> Total execution time: 0.0516
DEBUG - 2022-07-07 02:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:55:27 --> Total execution time: 0.1480
DEBUG - 2022-07-07 02:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:55:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 02:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:55:50 --> Total execution time: 0.0576
DEBUG - 2022-07-07 02:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:56:28 --> Total execution time: 0.0750
DEBUG - 2022-07-07 02:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:56:52 --> Total execution time: 0.1290
DEBUG - 2022-07-07 02:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:56:59 --> Total execution time: 0.0338
DEBUG - 2022-07-07 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:57:37 --> Total execution time: 0.0550
DEBUG - 2022-07-07 02:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:57:49 --> Total execution time: 0.1212
DEBUG - 2022-07-07 02:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:57:49 --> Total execution time: 0.0879
DEBUG - 2022-07-07 02:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:57:58 --> Total execution time: 0.0542
DEBUG - 2022-07-07 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:03 --> Total execution time: 0.0801
DEBUG - 2022-07-07 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:13 --> Total execution time: 0.0765
DEBUG - 2022-07-07 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:25 --> Total execution time: 0.0792
DEBUG - 2022-07-07 02:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:34 --> Total execution time: 0.1725
DEBUG - 2022-07-07 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:40 --> Total execution time: 0.0623
DEBUG - 2022-07-07 02:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:42 --> Total execution time: 0.0664
DEBUG - 2022-07-07 02:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:43 --> Total execution time: 0.0585
DEBUG - 2022-07-07 02:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:44 --> Total execution time: 0.0726
DEBUG - 2022-07-07 02:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:45 --> Total execution time: 0.0799
DEBUG - 2022-07-07 02:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:45 --> Total execution time: 0.0666
DEBUG - 2022-07-07 02:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:46 --> Total execution time: 0.0804
DEBUG - 2022-07-07 02:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:58:57 --> Total execution time: 0.1062
DEBUG - 2022-07-07 02:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:59:36 --> Total execution time: 0.0815
DEBUG - 2022-07-07 02:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:00:06 --> Total execution time: 0.0681
DEBUG - 2022-07-07 02:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:00:13 --> Total execution time: 0.0648
DEBUG - 2022-07-07 02:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:00:18 --> Total execution time: 0.0642
DEBUG - 2022-07-07 02:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:00:23 --> Total execution time: 0.1128
DEBUG - 2022-07-07 02:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:01:15 --> Total execution time: 0.0906
DEBUG - 2022-07-07 02:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:01:52 --> Total execution time: 0.0549
DEBUG - 2022-07-07 02:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:02:07 --> Total execution time: 0.0642
DEBUG - 2022-07-07 02:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:02:24 --> Total execution time: 0.1323
DEBUG - 2022-07-07 02:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:32:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:02:38 --> Total execution time: 0.0379
DEBUG - 2022-07-07 02:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:02:43 --> Total execution time: 0.0529
DEBUG - 2022-07-07 02:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:02:45 --> Total execution time: 0.0969
DEBUG - 2022-07-07 02:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:02:45 --> Total execution time: 0.0676
DEBUG - 2022-07-07 02:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:03 --> Total execution time: 0.0542
DEBUG - 2022-07-07 02:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:06 --> Total execution time: 0.0536
DEBUG - 2022-07-07 02:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:11 --> Total execution time: 0.0668
DEBUG - 2022-07-07 02:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:14 --> Total execution time: 0.0357
DEBUG - 2022-07-07 02:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:15 --> Total execution time: 0.0785
DEBUG - 2022-07-07 02:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:18 --> Total execution time: 0.0564
DEBUG - 2022-07-07 02:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:30 --> Total execution time: 0.0599
DEBUG - 2022-07-07 02:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:33:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:44 --> Total execution time: 0.1275
DEBUG - 2022-07-07 02:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:05 --> Total execution time: 0.0604
DEBUG - 2022-07-07 02:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:14 --> Total execution time: 0.1376
DEBUG - 2022-07-07 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:17 --> Total execution time: 0.0529
DEBUG - 2022-07-07 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:24 --> Total execution time: 0.0500
DEBUG - 2022-07-07 02:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:34 --> Total execution time: 0.0604
DEBUG - 2022-07-07 02:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:44 --> Total execution time: 0.0489
DEBUG - 2022-07-07 02:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:54 --> Total execution time: 0.0546
DEBUG - 2022-07-07 02:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:34:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:57 --> Total execution time: 0.0455
DEBUG - 2022-07-07 02:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:02 --> Total execution time: 0.0554
DEBUG - 2022-07-07 02:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:06 --> Total execution time: 0.0543
DEBUG - 2022-07-07 02:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:11 --> Total execution time: 0.0601
DEBUG - 2022-07-07 02:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:22 --> Total execution time: 0.0530
DEBUG - 2022-07-07 02:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:23 --> Total execution time: 0.0635
DEBUG - 2022-07-07 02:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:26 --> Total execution time: 0.0606
DEBUG - 2022-07-07 02:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:31 --> Total execution time: 0.0859
DEBUG - 2022-07-07 02:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:40 --> Total execution time: 0.0570
DEBUG - 2022-07-07 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:05:42 --> Total execution time: 0.0802
DEBUG - 2022-07-07 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:35:46 --> Total execution time: 0.0518
DEBUG - 2022-07-07 02:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:35:52 --> Total execution time: 0.0575
DEBUG - 2022-07-07 02:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:35:52 --> Total execution time: 0.1328
DEBUG - 2022-07-07 02:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:08 --> Total execution time: 0.0629
DEBUG - 2022-07-07 02:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:21 --> Total execution time: 0.0867
DEBUG - 2022-07-07 02:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:28 --> Total execution time: 0.0536
DEBUG - 2022-07-07 02:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:39 --> Total execution time: 0.0743
DEBUG - 2022-07-07 02:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:40 --> Total execution time: 0.0686
DEBUG - 2022-07-07 02:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:42 --> Total execution time: 0.0608
DEBUG - 2022-07-07 02:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:44 --> Total execution time: 0.0528
DEBUG - 2022-07-07 02:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:46 --> Total execution time: 0.0657
DEBUG - 2022-07-07 02:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:49 --> Total execution time: 0.0558
DEBUG - 2022-07-07 02:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:36:50 --> Total execution time: 0.0500
DEBUG - 2022-07-07 02:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:36:51 --> Total execution time: 0.0500
DEBUG - 2022-07-07 02:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:36:51 --> Total execution time: 0.0945
DEBUG - 2022-07-07 02:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:06:55 --> Total execution time: 0.0496
DEBUG - 2022-07-07 02:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:37:02 --> Total execution time: 0.0691
DEBUG - 2022-07-07 02:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:07:04 --> Total execution time: 0.0571
DEBUG - 2022-07-07 02:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:37:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:07:58 --> Total execution time: 0.0494
DEBUG - 2022-07-07 02:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:37:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:07:58 --> Total execution time: 0.0312
DEBUG - 2022-07-07 02:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:08:03 --> Total execution time: 0.0339
DEBUG - 2022-07-07 02:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:08:19 --> Total execution time: 0.0617
DEBUG - 2022-07-07 02:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:38:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 02:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:08:27 --> Total execution time: 1.9764
DEBUG - 2022-07-07 02:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:08:27 --> Total execution time: 0.0734
DEBUG - 2022-07-07 02:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 02:38:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 02:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:08:31 --> Total execution time: 0.0791
DEBUG - 2022-07-07 02:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:09:14 --> Total execution time: 0.0708
DEBUG - 2022-07-07 02:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:10:05 --> Total execution time: 0.0351
DEBUG - 2022-07-07 02:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:10:07 --> Total execution time: 0.0509
DEBUG - 2022-07-07 02:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:10:31 --> Total execution time: 0.0626
DEBUG - 2022-07-07 02:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:10:38 --> Total execution time: 0.0335
DEBUG - 2022-07-07 02:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:10:46 --> Total execution time: 0.0693
DEBUG - 2022-07-07 02:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:10:54 --> Total execution time: 0.0752
DEBUG - 2022-07-07 02:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:11:00 --> Total execution time: 0.0633
DEBUG - 2022-07-07 02:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:11:47 --> Total execution time: 0.0663
DEBUG - 2022-07-07 02:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:12:02 --> Total execution time: 0.1575
DEBUG - 2022-07-07 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 02:42:11 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-07 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:12:37 --> Total execution time: 0.0981
DEBUG - 2022-07-07 02:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:12:45 --> Total execution time: 0.0586
DEBUG - 2022-07-07 02:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:12:58 --> Total execution time: 0.1136
DEBUG - 2022-07-07 02:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:12:59 --> Total execution time: 0.0770
DEBUG - 2022-07-07 02:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:43:06 --> Total execution time: 0.0366
DEBUG - 2022-07-07 02:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:13:06 --> Total execution time: 0.0583
DEBUG - 2022-07-07 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:43:09 --> Total execution time: 0.0812
DEBUG - 2022-07-07 02:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:43:10 --> Total execution time: 0.1259
DEBUG - 2022-07-07 02:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:13:31 --> Total execution time: 0.0537
DEBUG - 2022-07-07 02:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:13:57 --> Total execution time: 0.1128
DEBUG - 2022-07-07 02:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:43:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:13:58 --> Total execution time: 0.1137
DEBUG - 2022-07-07 02:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:14:00 --> Total execution time: 0.0841
DEBUG - 2022-07-07 02:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:14:11 --> Total execution time: 0.0569
DEBUG - 2022-07-07 02:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:14:21 --> Total execution time: 0.0647
DEBUG - 2022-07-07 02:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:14:30 --> Total execution time: 0.0737
DEBUG - 2022-07-07 02:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:14:35 --> Total execution time: 0.0510
DEBUG - 2022-07-07 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:15:02 --> Total execution time: 0.2435
DEBUG - 2022-07-07 02:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:15:25 --> Total execution time: 0.0565
DEBUG - 2022-07-07 02:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:15:28 --> Total execution time: 0.0641
DEBUG - 2022-07-07 02:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:15:31 --> Total execution time: 0.0853
DEBUG - 2022-07-07 02:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:15:37 --> Total execution time: 0.0647
DEBUG - 2022-07-07 02:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:49:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:19:15 --> Total execution time: 0.1294
DEBUG - 2022-07-07 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:49:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:19:39 --> Total execution time: 0.0595
DEBUG - 2022-07-07 02:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:57:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:27:15 --> Total execution time: 0.1380
DEBUG - 2022-07-07 02:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:57:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:27:44 --> Total execution time: 0.0510
DEBUG - 2022-07-07 02:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:57:45 --> No URI present. Default controller set.
DEBUG - 2022-07-07 02:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:27:45 --> Total execution time: 0.0542
DEBUG - 2022-07-07 02:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:28:07 --> Total execution time: 0.0363
DEBUG - 2022-07-07 02:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 02:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:28:13 --> Total execution time: 0.0603
DEBUG - 2022-07-07 02:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 02:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 02:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:28:21 --> Total execution time: 0.1804
DEBUG - 2022-07-07 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:30:03 --> Total execution time: 0.0984
DEBUG - 2022-07-07 03:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:30:11 --> Total execution time: 0.0753
DEBUG - 2022-07-07 03:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:30:23 --> Total execution time: 0.1057
DEBUG - 2022-07-07 03:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:30:30 --> Total execution time: 0.1781
DEBUG - 2022-07-07 03:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:30:37 --> Total execution time: 0.1029
DEBUG - 2022-07-07 03:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:33:35 --> Total execution time: 0.0409
DEBUG - 2022-07-07 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:33:44 --> Total execution time: 0.0758
DEBUG - 2022-07-07 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:00 --> Total execution time: 0.0531
DEBUG - 2022-07-07 03:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:08 --> Total execution time: 0.0530
DEBUG - 2022-07-07 03:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 03:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:09 --> Total execution time: 0.0626
DEBUG - 2022-07-07 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:34 --> Total execution time: 0.0907
DEBUG - 2022-07-07 03:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:35:09 --> Total execution time: 0.1105
DEBUG - 2022-07-07 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:35:15 --> Total execution time: 0.1085
DEBUG - 2022-07-07 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:35:55 --> Total execution time: 0.0757
DEBUG - 2022-07-07 03:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:36:15 --> Total execution time: 0.0497
DEBUG - 2022-07-07 03:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:08:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:38:06 --> Total execution time: 0.0454
DEBUG - 2022-07-07 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:39:10 --> Total execution time: 0.0716
DEBUG - 2022-07-07 03:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:39:33 --> Total execution time: 0.0539
DEBUG - 2022-07-07 03:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:40:14 --> Total execution time: 0.0485
DEBUG - 2022-07-07 03:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:40:36 --> Total execution time: 0.0587
DEBUG - 2022-07-07 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:40:47 --> Total execution time: 0.0500
DEBUG - 2022-07-07 03:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:10:54 --> Total execution time: 0.0531
DEBUG - 2022-07-07 03:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:10:56 --> Total execution time: 0.0738
DEBUG - 2022-07-07 03:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:10:56 --> Total execution time: 0.1256
DEBUG - 2022-07-07 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:41:10 --> Total execution time: 0.0438
DEBUG - 2022-07-07 03:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:41:32 --> Total execution time: 0.0599
DEBUG - 2022-07-07 03:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:41:32 --> Total execution time: 0.0491
DEBUG - 2022-07-07 03:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:41:32 --> Total execution time: 0.0684
DEBUG - 2022-07-07 03:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:41:34 --> Total execution time: 0.0518
DEBUG - 2022-07-07 03:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:41:55 --> Total execution time: 0.0534
DEBUG - 2022-07-07 03:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:07 --> Total execution time: 0.0621
DEBUG - 2022-07-07 03:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:08 --> Total execution time: 0.0896
DEBUG - 2022-07-07 03:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:13 --> Total execution time: 0.0926
DEBUG - 2022-07-07 03:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:18 --> Total execution time: 0.0531
DEBUG - 2022-07-07 03:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:28 --> Total execution time: 0.0906
DEBUG - 2022-07-07 03:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:33 --> Total execution time: 0.1443
DEBUG - 2022-07-07 03:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:42:57 --> Total execution time: 0.0539
DEBUG - 2022-07-07 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:13:48 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:43:48 --> Total execution time: 0.0539
DEBUG - 2022-07-07 03:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:45:16 --> Total execution time: 0.0576
DEBUG - 2022-07-07 03:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:16:48 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:46:49 --> Total execution time: 0.0392
DEBUG - 2022-07-07 03:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:18:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:33 --> Total execution time: 0.0356
DEBUG - 2022-07-07 03:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:00 --> Total execution time: 0.0562
DEBUG - 2022-07-07 03:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:07 --> Total execution time: 0.0547
DEBUG - 2022-07-07 03:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:25 --> Total execution time: 0.0692
DEBUG - 2022-07-07 03:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:32 --> Total execution time: 0.0636
DEBUG - 2022-07-07 03:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:51 --> Total execution time: 0.0565
DEBUG - 2022-07-07 03:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:21:41 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:51:41 --> Total execution time: 0.0379
DEBUG - 2022-07-07 03:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:51:47 --> Total execution time: 0.1320
DEBUG - 2022-07-07 03:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:51:55 --> Total execution time: 0.1065
DEBUG - 2022-07-07 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:52:19 --> Total execution time: 0.0755
DEBUG - 2022-07-07 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:52:48 --> Total execution time: 0.0792
DEBUG - 2022-07-07 03:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:52:50 --> Total execution time: 0.0619
DEBUG - 2022-07-07 03:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 03:23:53 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:47 --> Total execution time: 0.0635
DEBUG - 2022-07-07 03:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:03 --> Total execution time: 0.0374
DEBUG - 2022-07-07 03:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 03:26:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 03:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:32 --> Total execution time: 0.0406
DEBUG - 2022-07-07 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:36 --> Total execution time: 0.0376
DEBUG - 2022-07-07 03:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:39 --> Total execution time: 0.0529
DEBUG - 2022-07-07 03:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:42 --> Total execution time: 0.0533
DEBUG - 2022-07-07 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:44 --> Total execution time: 0.0617
DEBUG - 2022-07-07 03:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:46 --> Total execution time: 0.0565
DEBUG - 2022-07-07 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:48 --> Total execution time: 0.0588
DEBUG - 2022-07-07 03:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:06 --> Total execution time: 0.0542
DEBUG - 2022-07-07 03:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:09 --> Total execution time: 0.0583
DEBUG - 2022-07-07 03:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:09 --> Total execution time: 0.0622
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:10 --> Total execution time: 0.0573
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:10 --> Total execution time: 0.0861
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:10 --> Total execution time: 0.0538
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:10 --> Total execution time: 0.0673
DEBUG - 2022-07-07 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:11 --> Total execution time: 0.0616
DEBUG - 2022-07-07 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:11 --> Total execution time: 0.0797
DEBUG - 2022-07-07 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:11 --> Total execution time: 0.0514
DEBUG - 2022-07-07 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:12 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:12 --> Total execution time: 0.0610
DEBUG - 2022-07-07 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:12 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:13 --> Total execution time: 0.0745
DEBUG - 2022-07-07 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:13 --> Total execution time: 0.0656
DEBUG - 2022-07-07 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:14 --> Total execution time: 0.0606
DEBUG - 2022-07-07 03:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:14 --> Total execution time: 0.0813
DEBUG - 2022-07-07 03:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:14 --> Total execution time: 0.0605
DEBUG - 2022-07-07 03:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:15 --> Total execution time: 0.0689
DEBUG - 2022-07-07 03:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:15 --> Total execution time: 0.0799
DEBUG - 2022-07-07 03:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:18 --> Total execution time: 0.0489
DEBUG - 2022-07-07 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:31 --> Total execution time: 0.0534
DEBUG - 2022-07-07 03:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:37 --> Total execution time: 0.0606
DEBUG - 2022-07-07 03:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:41 --> Total execution time: 0.0585
DEBUG - 2022-07-07 03:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:46 --> Total execution time: 0.0828
DEBUG - 2022-07-07 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:52 --> Total execution time: 0.0673
DEBUG - 2022-07-07 03:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:58 --> Total execution time: 0.0665
DEBUG - 2022-07-07 03:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 03:29:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 03:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:13 --> Total execution time: 0.1262
DEBUG - 2022-07-07 03:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:32 --> Total execution time: 0.0510
DEBUG - 2022-07-07 03:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:43 --> Total execution time: 0.1146
DEBUG - 2022-07-07 03:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:44 --> Total execution time: 0.0941
DEBUG - 2022-07-07 03:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:54 --> Total execution time: 0.0773
DEBUG - 2022-07-07 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:30:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:56 --> Total execution time: 0.0436
DEBUG - 2022-07-07 03:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:31:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:01:44 --> Total execution time: 0.0462
DEBUG - 2022-07-07 03:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:01:49 --> Total execution time: 0.0584
DEBUG - 2022-07-07 03:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:01:53 --> Total execution time: 0.0955
DEBUG - 2022-07-07 03:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:22 --> Total execution time: 0.0486
DEBUG - 2022-07-07 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:38 --> Total execution time: 0.0824
DEBUG - 2022-07-07 03:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:50 --> Total execution time: 0.0823
DEBUG - 2022-07-07 03:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:03:02 --> Total execution time: 0.1009
DEBUG - 2022-07-07 03:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:03:15 --> Total execution time: 0.1061
DEBUG - 2022-07-07 03:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:03:19 --> Total execution time: 0.0802
DEBUG - 2022-07-07 03:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:04:31 --> Total execution time: 0.1477
DEBUG - 2022-07-07 03:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:04:32 --> Total execution time: 0.0756
DEBUG - 2022-07-07 03:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:04:57 --> Total execution time: 0.0749
DEBUG - 2022-07-07 03:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:04:58 --> Total execution time: 0.0674
DEBUG - 2022-07-07 03:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:04:58 --> Total execution time: 0.1565
DEBUG - 2022-07-07 03:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:05:17 --> Total execution time: 0.0602
DEBUG - 2022-07-07 03:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:05:57 --> Total execution time: 0.1878
DEBUG - 2022-07-07 03:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:06 --> Total execution time: 0.1311
DEBUG - 2022-07-07 03:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:40:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:10:54 --> Total execution time: 0.0697
DEBUG - 2022-07-07 03:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:10:59 --> Total execution time: 0.0359
DEBUG - 2022-07-07 03:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:11:27 --> Total execution time: 0.0895
DEBUG - 2022-07-07 03:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:11:34 --> Total execution time: 0.0600
DEBUG - 2022-07-07 03:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:11:56 --> Total execution time: 0.0627
DEBUG - 2022-07-07 03:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:12:48 --> Total execution time: 0.0569
DEBUG - 2022-07-07 03:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:12:53 --> Total execution time: 0.0587
DEBUG - 2022-07-07 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:13:59 --> Total execution time: 0.0512
DEBUG - 2022-07-07 03:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:21 --> Total execution time: 0.0529
DEBUG - 2022-07-07 03:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:32 --> Total execution time: 0.0751
DEBUG - 2022-07-07 03:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:50 --> Total execution time: 0.0605
DEBUG - 2022-07-07 03:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:58 --> Total execution time: 0.1011
DEBUG - 2022-07-07 03:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:15:40 --> Total execution time: 0.0751
DEBUG - 2022-07-07 03:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:47:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:17:56 --> Total execution time: 0.1049
DEBUG - 2022-07-07 03:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:04 --> Total execution time: 0.0723
DEBUG - 2022-07-07 03:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:05 --> Total execution time: 0.0743
DEBUG - 2022-07-07 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:10 --> Total execution time: 0.0723
DEBUG - 2022-07-07 03:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:14 --> Total execution time: 0.0581
DEBUG - 2022-07-07 03:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:33 --> Total execution time: 0.0373
DEBUG - 2022-07-07 03:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:42 --> Total execution time: 0.0560
DEBUG - 2022-07-07 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:18:52 --> Total execution time: 0.1390
DEBUG - 2022-07-07 03:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:49:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:19:38 --> Total execution time: 0.0321
DEBUG - 2022-07-07 03:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:49:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:19:38 --> Total execution time: 0.0295
DEBUG - 2022-07-07 03:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:19:50 --> Total execution time: 0.0340
DEBUG - 2022-07-07 03:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:02 --> Total execution time: 0.0743
DEBUG - 2022-07-07 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:15 --> Total execution time: 0.0650
DEBUG - 2022-07-07 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:19 --> Total execution time: 0.0573
DEBUG - 2022-07-07 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:30 --> Total execution time: 0.0742
DEBUG - 2022-07-07 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:34 --> Total execution time: 0.0630
DEBUG - 2022-07-07 03:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:36 --> Total execution time: 0.0519
DEBUG - 2022-07-07 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:46 --> Total execution time: 0.0639
DEBUG - 2022-07-07 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:55 --> Total execution time: 0.0728
DEBUG - 2022-07-07 14:20:55 --> Total execution time: 0.0784
DEBUG - 2022-07-07 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:57 --> Total execution time: 0.0668
DEBUG - 2022-07-07 03:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:20:59 --> Total execution time: 0.0761
DEBUG - 2022-07-07 03:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:00 --> Total execution time: 0.0692
DEBUG - 2022-07-07 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:07 --> Total execution time: 0.0827
DEBUG - 2022-07-07 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:11 --> Total execution time: 0.0549
DEBUG - 2022-07-07 03:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:14 --> Total execution time: 0.0572
DEBUG - 2022-07-07 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:14 --> Total execution time: 0.0706
DEBUG - 2022-07-07 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:16 --> Total execution time: 0.0615
DEBUG - 2022-07-07 03:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:32 --> Total execution time: 0.0490
DEBUG - 2022-07-07 03:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:41 --> Total execution time: 0.0555
DEBUG - 2022-07-07 03:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:45 --> Total execution time: 0.1728
DEBUG - 2022-07-07 03:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:49 --> Total execution time: 0.0565
DEBUG - 2022-07-07 03:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:54 --> Total execution time: 0.0787
DEBUG - 2022-07-07 03:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:21:58 --> Total execution time: 0.0798
DEBUG - 2022-07-07 03:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:04 --> Total execution time: 0.0694
DEBUG - 2022-07-07 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:06 --> Total execution time: 0.0543
DEBUG - 2022-07-07 03:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:09 --> Total execution time: 0.0817
DEBUG - 2022-07-07 03:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:12 --> Total execution time: 0.0910
DEBUG - 2022-07-07 03:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:23 --> Total execution time: 0.0716
DEBUG - 2022-07-07 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:30 --> Total execution time: 0.0876
DEBUG - 2022-07-07 03:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:35 --> Total execution time: 0.0610
DEBUG - 2022-07-07 03:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:39 --> Total execution time: 0.0487
DEBUG - 2022-07-07 03:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:22:49 --> Total execution time: 0.0528
DEBUG - 2022-07-07 03:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:23:04 --> Total execution time: 0.0553
DEBUG - 2022-07-07 03:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:23:42 --> Total execution time: 0.0726
DEBUG - 2022-07-07 03:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:24:26 --> Total execution time: 0.1022
DEBUG - 2022-07-07 03:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:24:33 --> Total execution time: 0.0793
DEBUG - 2022-07-07 03:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 03:55:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:28:07 --> Total execution time: 0.1185
DEBUG - 2022-07-07 03:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:28:16 --> Total execution time: 0.0794
DEBUG - 2022-07-07 03:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:28:20 --> Total execution time: 0.0798
DEBUG - 2022-07-07 03:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:28:25 --> Total execution time: 0.0864
DEBUG - 2022-07-07 03:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:28:28 --> Total execution time: 0.0411
DEBUG - 2022-07-07 03:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:58:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:28:44 --> Total execution time: 0.0484
DEBUG - 2022-07-07 03:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:29:25 --> Total execution time: 0.1412
DEBUG - 2022-07-07 03:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:29:28 --> Total execution time: 0.0526
DEBUG - 2022-07-07 03:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:59:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 03:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:29:33 --> Total execution time: 0.0536
DEBUG - 2022-07-07 03:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:29:43 --> Total execution time: 0.0534
DEBUG - 2022-07-07 03:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 03:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 03:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:29:46 --> Total execution time: 0.0548
DEBUG - 2022-07-07 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:30:03 --> Total execution time: 0.0576
DEBUG - 2022-07-07 04:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:30:24 --> Total execution time: 0.0699
DEBUG - 2022-07-07 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:45 --> Total execution time: 0.0757
DEBUG - 2022-07-07 04:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:32:41 --> Total execution time: 0.0602
DEBUG - 2022-07-07 04:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:36:49 --> Total execution time: 0.2404
DEBUG - 2022-07-07 04:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:06:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:36:52 --> Total execution time: 0.0562
DEBUG - 2022-07-07 04:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:36:56 --> Total execution time: 0.0507
DEBUG - 2022-07-07 04:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:37:22 --> Total execution time: 0.0639
DEBUG - 2022-07-07 04:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:37:27 --> Total execution time: 0.0571
DEBUG - 2022-07-07 04:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:37:32 --> Total execution time: 0.0561
DEBUG - 2022-07-07 04:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:37:37 --> Total execution time: 0.0593
DEBUG - 2022-07-07 04:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:09:18 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:39:18 --> Total execution time: 0.0388
DEBUG - 2022-07-07 04:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:39:40 --> Total execution time: 0.0507
DEBUG - 2022-07-07 04:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:39:40 --> Total execution time: 0.0598
DEBUG - 2022-07-07 04:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:09:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:39:54 --> Total execution time: 0.0611
DEBUG - 2022-07-07 04:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:10:09 --> Total execution time: 0.0528
DEBUG - 2022-07-07 04:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:10:11 --> Total execution time: 0.0568
DEBUG - 2022-07-07 04:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:10:11 --> Total execution time: 0.1204
DEBUG - 2022-07-07 04:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:40:22 --> Total execution time: 0.0492
DEBUG - 2022-07-07 04:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:40:43 --> Total execution time: 0.0516
DEBUG - 2022-07-07 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:40:58 --> Total execution time: 0.0426
DEBUG - 2022-07-07 04:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:41:20 --> Total execution time: 0.0582
DEBUG - 2022-07-07 04:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:41:32 --> Total execution time: 0.0573
DEBUG - 2022-07-07 04:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:41:38 --> Total execution time: 0.0527
DEBUG - 2022-07-07 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:41:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:41:40 --> Total execution time: 0.0500
DEBUG - 2022-07-07 04:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:43:48 --> Total execution time: 0.0713
DEBUG - 2022-07-07 04:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:43:57 --> Total execution time: 0.0559
DEBUG - 2022-07-07 04:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:44:04 --> Total execution time: 0.0498
DEBUG - 2022-07-07 04:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:44:29 --> Total execution time: 0.0613
DEBUG - 2022-07-07 04:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:44:35 --> Total execution time: 0.0564
DEBUG - 2022-07-07 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:44:43 --> Total execution time: 0.0536
DEBUG - 2022-07-07 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:44:53 --> Total execution time: 0.0567
DEBUG - 2022-07-07 04:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:01 --> Total execution time: 0.0542
DEBUG - 2022-07-07 04:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:11 --> Total execution time: 0.0529
DEBUG - 2022-07-07 04:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 04:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:12 --> Total execution time: 0.0581
DEBUG - 2022-07-07 04:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:16:04 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:46:04 --> Total execution time: 0.0520
DEBUG - 2022-07-07 04:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:46:32 --> Total execution time: 0.0510
DEBUG - 2022-07-07 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:46:48 --> Total execution time: 0.0526
DEBUG - 2022-07-07 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:47:35 --> Total execution time: 0.0583
DEBUG - 2022-07-07 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:47:42 --> Total execution time: 0.1579
DEBUG - 2022-07-07 04:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:47:54 --> Total execution time: 0.0495
DEBUG - 2022-07-07 04:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:18:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:48:34 --> Total execution time: 0.1276
DEBUG - 2022-07-07 04:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:48:59 --> Total execution time: 0.0570
DEBUG - 2022-07-07 04:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:02 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:49:02 --> Total execution time: 0.0537
DEBUG - 2022-07-07 04:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:49:27 --> Total execution time: 0.0695
DEBUG - 2022-07-07 04:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:19:33 --> Total execution time: 0.0502
DEBUG - 2022-07-07 04:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:19:34 --> Total execution time: 0.0570
DEBUG - 2022-07-07 04:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:19:34 --> Total execution time: 0.1149
DEBUG - 2022-07-07 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:49:46 --> Total execution time: 0.0353
DEBUG - 2022-07-07 04:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:19:58 --> Total execution time: 0.0581
DEBUG - 2022-07-07 04:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:20:05 --> Total execution time: 0.0604
DEBUG - 2022-07-07 04:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:20:05 --> Total execution time: 0.1441
DEBUG - 2022-07-07 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:21:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:51:59 --> Total execution time: 1.8814
DEBUG - 2022-07-07 04:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 04:22:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:52:14 --> Total execution time: 0.1524
DEBUG - 2022-07-07 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:52:34 --> Total execution time: 0.0713
DEBUG - 2022-07-07 04:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:52:36 --> Total execution time: 0.0826
DEBUG - 2022-07-07 04:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:52:56 --> Total execution time: 0.0769
DEBUG - 2022-07-07 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:00 --> Total execution time: 0.0604
DEBUG - 2022-07-07 04:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:01 --> Total execution time: 0.0633
DEBUG - 2022-07-07 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:06 --> Total execution time: 0.0538
DEBUG - 2022-07-07 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:10 --> Total execution time: 0.0550
DEBUG - 2022-07-07 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-07-07 14:53:11 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-07-07 14:53:11 --> Total execution time: 0.0627
DEBUG - 2022-07-07 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:39 --> Total execution time: 0.0375
DEBUG - 2022-07-07 04:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:40 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:40 --> Total execution time: 0.0484
DEBUG - 2022-07-07 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:53:49 --> Total execution time: 0.1374
DEBUG - 2022-07-07 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:55:32 --> Total execution time: 0.0560
DEBUG - 2022-07-07 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:55:37 --> Total execution time: 0.0511
DEBUG - 2022-07-07 04:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:55:43 --> Total execution time: 0.0962
DEBUG - 2022-07-07 04:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:26:09 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:56:09 --> Total execution time: 0.0642
DEBUG - 2022-07-07 04:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:28:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:58:56 --> Total execution time: 0.2194
DEBUG - 2022-07-07 04:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:59:44 --> Total execution time: 0.0353
DEBUG - 2022-07-07 04:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:32:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:02:39 --> Total execution time: 0.1071
DEBUG - 2022-07-07 04:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:32:41 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:02:41 --> Total execution time: 0.0597
DEBUG - 2022-07-07 04:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:03:47 --> Total execution time: 0.0440
DEBUG - 2022-07-07 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:34:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:04:08 --> Total execution time: 0.0458
DEBUG - 2022-07-07 04:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:34:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:04:14 --> Total execution time: 0.0887
DEBUG - 2022-07-07 04:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:34:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:04:36 --> Total execution time: 0.0862
DEBUG - 2022-07-07 04:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:04:41 --> Total execution time: 0.0730
DEBUG - 2022-07-07 04:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:05:07 --> Total execution time: 0.1527
DEBUG - 2022-07-07 04:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:05:34 --> Total execution time: 0.0605
DEBUG - 2022-07-07 04:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:05:53 --> Total execution time: 0.0547
DEBUG - 2022-07-07 04:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:05:55 --> Total execution time: 0.0601
DEBUG - 2022-07-07 04:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:06:05 --> Total execution time: 0.0842
DEBUG - 2022-07-07 04:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:06:09 --> Total execution time: 0.0676
DEBUG - 2022-07-07 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:37:04 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:07:04 --> Total execution time: 0.0551
DEBUG - 2022-07-07 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:38:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:08:43 --> Total execution time: 0.0383
DEBUG - 2022-07-07 04:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:01 --> Total execution time: 0.1449
DEBUG - 2022-07-07 04:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:03 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:03 --> Total execution time: 0.0523
DEBUG - 2022-07-07 04:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:10 --> Total execution time: 0.0582
DEBUG - 2022-07-07 04:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:11 --> Total execution time: 0.0967
DEBUG - 2022-07-07 04:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:14 --> Total execution time: 0.0818
DEBUG - 2022-07-07 04:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:17 --> Total execution time: 0.0882
DEBUG - 2022-07-07 04:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:20 --> Total execution time: 0.0647
DEBUG - 2022-07-07 04:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:37 --> Total execution time: 0.0642
DEBUG - 2022-07-07 04:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:46 --> Total execution time: 0.0789
DEBUG - 2022-07-07 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:11:53 --> Total execution time: 0.0643
DEBUG - 2022-07-07 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:43:40 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:13:40 --> Total execution time: 0.1358
DEBUG - 2022-07-07 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:13 --> Total execution time: 0.0617
DEBUG - 2022-07-07 04:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:45:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 04:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:15:54 --> Total execution time: 0.0547
DEBUG - 2022-07-07 04:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:16:06 --> Total execution time: 0.1228
DEBUG - 2022-07-07 04:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:47:05 --> Total execution time: 0.0600
DEBUG - 2022-07-07 04:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:17:08 --> Total execution time: 0.0684
DEBUG - 2022-07-07 04:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:47:58 --> Total execution time: 0.1339
DEBUG - 2022-07-07 04:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:22:25 --> Total execution time: 0.1061
DEBUG - 2022-07-07 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:22:58 --> Total execution time: 0.0824
DEBUG - 2022-07-07 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:23:41 --> Total execution time: 0.0794
DEBUG - 2022-07-07 04:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:24:10 --> Total execution time: 0.1122
DEBUG - 2022-07-07 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:24:42 --> Total execution time: 0.0956
DEBUG - 2022-07-07 04:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:24:59 --> Total execution time: 0.0890
DEBUG - 2022-07-07 04:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:25:55 --> Total execution time: 0.0641
DEBUG - 2022-07-07 04:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:27:26 --> Total execution time: 0.1932
DEBUG - 2022-07-07 04:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:27:34 --> Total execution time: 0.0658
DEBUG - 2022-07-07 04:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:28:10 --> Total execution time: 0.0601
DEBUG - 2022-07-07 04:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:29:00 --> Total execution time: 0.0606
DEBUG - 2022-07-07 04:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:29:05 --> Total execution time: 0.0539
DEBUG - 2022-07-07 04:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:59:08 --> Total execution time: 0.0634
DEBUG - 2022-07-07 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:59:10 --> Total execution time: 0.0553
DEBUG - 2022-07-07 04:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 04:59:10 --> Total execution time: 0.0858
DEBUG - 2022-07-07 04:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 04:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 04:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:29:58 --> Total execution time: 0.0658
DEBUG - 2022-07-07 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:02 --> Total execution time: 0.0391
DEBUG - 2022-07-07 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:16 --> Total execution time: 0.0572
DEBUG - 2022-07-07 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:16 --> Total execution time: 0.0578
DEBUG - 2022-07-07 05:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:44 --> Total execution time: 0.0620
DEBUG - 2022-07-07 05:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:49 --> Total execution time: 0.0572
DEBUG - 2022-07-07 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:50 --> Total execution time: 0.0748
DEBUG - 2022-07-07 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:50 --> Total execution time: 0.0558
DEBUG - 2022-07-07 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:00:50 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:30:51 --> Total execution time: 0.1414
DEBUG - 2022-07-07 05:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:02 --> Total execution time: 0.0901
DEBUG - 2022-07-07 05:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:07 --> Total execution time: 0.0371
DEBUG - 2022-07-07 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:23 --> Total execution time: 0.0723
DEBUG - 2022-07-07 05:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:33 --> Total execution time: 0.0843
DEBUG - 2022-07-07 05:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:52 --> Total execution time: 0.0533
DEBUG - 2022-07-07 05:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:55 --> Total execution time: 0.0778
DEBUG - 2022-07-07 05:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:32:12 --> Total execution time: 0.0600
DEBUG - 2022-07-07 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:32:14 --> Total execution time: 0.0633
DEBUG - 2022-07-07 05:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:33:54 --> Total execution time: 0.0550
DEBUG - 2022-07-07 05:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:39:06 --> Total execution time: 0.0414
DEBUG - 2022-07-07 05:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:10:35 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:40:35 --> Total execution time: 0.0513
DEBUG - 2022-07-07 05:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:15:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:45:55 --> Total execution time: 0.1271
DEBUG - 2022-07-07 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 05:16:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:47:36 --> Total execution time: 0.0365
DEBUG - 2022-07-07 05:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:47:47 --> Total execution time: 0.0902
DEBUG - 2022-07-07 05:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:47:52 --> Total execution time: 0.0561
DEBUG - 2022-07-07 05:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:48:03 --> Total execution time: 0.0579
DEBUG - 2022-07-07 05:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:48:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:48:04 --> Total execution time: 0.0489
DEBUG - 2022-07-07 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 05:19:34 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:49:35 --> Total execution time: 0.0532
DEBUG - 2022-07-07 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:50:40 --> Total execution time: 0.1526
DEBUG - 2022-07-07 05:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:50:47 --> Total execution time: 0.0668
DEBUG - 2022-07-07 05:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:51:37 --> Total execution time: 0.0797
DEBUG - 2022-07-07 05:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:22:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 05:22:13 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:52:34 --> Total execution time: 0.0562
DEBUG - 2022-07-07 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:24 --> Total execution time: 0.1426
DEBUG - 2022-07-07 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:29 --> Total execution time: 0.1426
DEBUG - 2022-07-07 05:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:33 --> Total execution time: 0.0601
DEBUG - 2022-07-07 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:34 --> Total execution time: 0.0549
DEBUG - 2022-07-07 05:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:38 --> Total execution time: 0.0553
DEBUG - 2022-07-07 05:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:40 --> Total execution time: 0.0655
DEBUG - 2022-07-07 05:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:43 --> Total execution time: 0.1339
DEBUG - 2022-07-07 05:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:53:51 --> Total execution time: 0.0497
DEBUG - 2022-07-07 05:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:24:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:54:27 --> Total execution time: 0.0612
DEBUG - 2022-07-07 05:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:26:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:56:31 --> Total execution time: 0.1269
DEBUG - 2022-07-07 05:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:56:44 --> Total execution time: 0.0816
DEBUG - 2022-07-07 05:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:26:49 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:56:49 --> Total execution time: 0.0413
DEBUG - 2022-07-07 05:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:27:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:57:14 --> Total execution time: 0.0437
DEBUG - 2022-07-07 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:57:16 --> Total execution time: 0.0621
DEBUG - 2022-07-07 05:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:57:43 --> Total execution time: 0.0680
DEBUG - 2022-07-07 05:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:28:32 --> Total execution time: 0.0684
DEBUG - 2022-07-07 05:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:59:19 --> Total execution time: 0.1378
DEBUG - 2022-07-07 05:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:00:52 --> Total execution time: 0.1538
DEBUG - 2022-07-07 05:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:01:19 --> Total execution time: 0.0609
DEBUG - 2022-07-07 05:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:02:24 --> Total execution time: 0.0670
DEBUG - 2022-07-07 05:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:02:43 --> Total execution time: 0.0743
DEBUG - 2022-07-07 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:02:47 --> Total execution time: 0.2859
DEBUG - 2022-07-07 05:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:02:58 --> Total execution time: 0.0542
DEBUG - 2022-07-07 05:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:04 --> Total execution time: 0.0613
DEBUG - 2022-07-07 05:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:20 --> Total execution time: 0.0877
DEBUG - 2022-07-07 05:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:32 --> Total execution time: 0.0481
DEBUG - 2022-07-07 05:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:33 --> Total execution time: 0.0360
DEBUG - 2022-07-07 05:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:37 --> Total execution time: 0.0797
DEBUG - 2022-07-07 05:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:39 --> Total execution time: 0.0361
DEBUG - 2022-07-07 05:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:45 --> Total execution time: 0.0541
DEBUG - 2022-07-07 05:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:03:55 --> Total execution time: 0.0831
DEBUG - 2022-07-07 05:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:03 --> Total execution time: 0.0765
DEBUG - 2022-07-07 05:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:07 --> Total execution time: 0.0612
DEBUG - 2022-07-07 05:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:11 --> Total execution time: 0.0511
DEBUG - 2022-07-07 05:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:16 --> Total execution time: 0.0491
DEBUG - 2022-07-07 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:17 --> Total execution time: 0.0583
DEBUG - 2022-07-07 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:17 --> Total execution time: 0.0775
DEBUG - 2022-07-07 05:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:19 --> Total execution time: 0.0586
DEBUG - 2022-07-07 05:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:28 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:28 --> Total execution time: 0.0426
DEBUG - 2022-07-07 05:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:30 --> Total execution time: 0.1226
DEBUG - 2022-07-07 05:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:04:40 --> Total execution time: 0.0998
DEBUG - 2022-07-07 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:07 --> Total execution time: 0.0766
DEBUG - 2022-07-07 05:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:08 --> Total execution time: 0.0518
DEBUG - 2022-07-07 05:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:17 --> Total execution time: 0.0552
DEBUG - 2022-07-07 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:25 --> Total execution time: 0.0552
DEBUG - 2022-07-07 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:30 --> Total execution time: 0.0909
DEBUG - 2022-07-07 05:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:36 --> Total execution time: 0.1438
DEBUG - 2022-07-07 05:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:06:52 --> Total execution time: 0.0876
DEBUG - 2022-07-07 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:07:38 --> Total execution time: 0.0901
DEBUG - 2022-07-07 05:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:07:45 --> Total execution time: 0.0614
DEBUG - 2022-07-07 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:08:25 --> Total execution time: 0.0781
DEBUG - 2022-07-07 05:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:39:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:09:36 --> Total execution time: 0.0672
DEBUG - 2022-07-07 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:10:57 --> Total execution time: 0.0458
DEBUG - 2022-07-07 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:06 --> Total execution time: 0.0549
DEBUG - 2022-07-07 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:12 --> Total execution time: 0.0685
DEBUG - 2022-07-07 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:15 --> Total execution time: 0.0765
DEBUG - 2022-07-07 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:20 --> Total execution time: 0.0621
DEBUG - 2022-07-07 05:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:25 --> Total execution time: 0.0614
DEBUG - 2022-07-07 05:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:32 --> Total execution time: 0.0553
DEBUG - 2022-07-07 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:35 --> Total execution time: 0.0922
DEBUG - 2022-07-07 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:40 --> Total execution time: 0.0555
DEBUG - 2022-07-07 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:49 --> Total execution time: 0.0628
DEBUG - 2022-07-07 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:42:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:12:38 --> Total execution time: 0.0371
DEBUG - 2022-07-07 05:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:42:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:12:39 --> Total execution time: 0.0372
DEBUG - 2022-07-07 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:12:50 --> Total execution time: 0.0673
DEBUG - 2022-07-07 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:13:11 --> Total execution time: 0.0558
DEBUG - 2022-07-07 05:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:13:15 --> Total execution time: 0.0634
DEBUG - 2022-07-07 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:13:36 --> Total execution time: 0.0501
DEBUG - 2022-07-07 05:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 05:49:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 05:50:16 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-07 05:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 05:50:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 05:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:51:47 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:21:47 --> Total execution time: 0.1018
DEBUG - 2022-07-07 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:22:21 --> Total execution time: 0.0558
DEBUG - 2022-07-07 05:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:22:28 --> Total execution time: 0.0574
DEBUG - 2022-07-07 05:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:52:37 --> Total execution time: 0.0501
DEBUG - 2022-07-07 05:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:22:37 --> Total execution time: 0.0520
DEBUG - 2022-07-07 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:22:38 --> Total execution time: 0.0495
DEBUG - 2022-07-07 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:22:38 --> Total execution time: 0.0553
DEBUG - 2022-07-07 05:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:23:05 --> Total execution time: 0.1347
DEBUG - 2022-07-07 05:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:23:09 --> Total execution time: 0.0699
DEBUG - 2022-07-07 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:23:18 --> Total execution time: 0.0495
DEBUG - 2022-07-07 05:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:23:24 --> Total execution time: 0.0543
DEBUG - 2022-07-07 05:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:23:34 --> Total execution time: 0.0521
DEBUG - 2022-07-07 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:24:11 --> Total execution time: 0.0572
DEBUG - 2022-07-07 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:24:11 --> Total execution time: 0.0520
DEBUG - 2022-07-07 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:24:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:24:12 --> Total execution time: 0.0453
DEBUG - 2022-07-07 05:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 05:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:25:37 --> Total execution time: 0.0488
DEBUG - 2022-07-07 05:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:27:02 --> Total execution time: 0.1673
DEBUG - 2022-07-07 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:57:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 05:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:27:11 --> Total execution time: 0.0379
DEBUG - 2022-07-07 05:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:27:17 --> Total execution time: 0.0571
DEBUG - 2022-07-07 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:27:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:27:20 --> Total execution time: 0.0646
DEBUG - 2022-07-07 05:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:28:33 --> Total execution time: 0.0854
DEBUG - 2022-07-07 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:28:55 --> Total execution time: 0.0542
DEBUG - 2022-07-07 05:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:28:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 05:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:28:57 --> Total execution time: 0.0594
DEBUG - 2022-07-07 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 05:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 05:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:29:20 --> Total execution time: 0.0542
DEBUG - 2022-07-07 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:30:03 --> Total execution time: 0.1511
DEBUG - 2022-07-07 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:30:29 --> Total execution time: 0.0590
DEBUG - 2022-07-07 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:30:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:30:30 --> Total execution time: 0.0766
DEBUG - 2022-07-07 06:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:31:07 --> Total execution time: 0.0552
DEBUG - 2022-07-07 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:31:18 --> Total execution time: 0.0746
DEBUG - 2022-07-07 06:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:31:25 --> Total execution time: 0.0619
DEBUG - 2022-07-07 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:31:29 --> Total execution time: 0.0500
DEBUG - 2022-07-07 06:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:32:12 --> Total execution time: 0.0563
DEBUG - 2022-07-07 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:32:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:32:13 --> Total execution time: 0.0528
DEBUG - 2022-07-07 06:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:32:29 --> Total execution time: 0.0492
DEBUG - 2022-07-07 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:33:57 --> Total execution time: 0.0506
DEBUG - 2022-07-07 06:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:04:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:34:52 --> Total execution time: 0.0412
DEBUG - 2022-07-07 06:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:35:40 --> Total execution time: 0.0453
DEBUG - 2022-07-07 06:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:37:38 --> Total execution time: 0.0564
DEBUG - 2022-07-07 06:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:37:41 --> Total execution time: 0.0518
DEBUG - 2022-07-07 06:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:37:46 --> Total execution time: 0.0753
DEBUG - 2022-07-07 06:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:37:51 --> Total execution time: 0.0487
DEBUG - 2022-07-07 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:37:56 --> Total execution time: 0.0823
DEBUG - 2022-07-07 06:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:38:04 --> Total execution time: 0.0798
DEBUG - 2022-07-07 06:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:38:13 --> Total execution time: 0.1041
DEBUG - 2022-07-07 06:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:38:29 --> Total execution time: 0.0609
DEBUG - 2022-07-07 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:38:33 --> Total execution time: 0.0675
DEBUG - 2022-07-07 06:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:43:24 --> Total execution time: 0.1362
DEBUG - 2022-07-07 06:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:13:50 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:43:50 --> Total execution time: 0.0421
DEBUG - 2022-07-07 06:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:14:27 --> Total execution time: 0.0379
DEBUG - 2022-07-07 06:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:14:28 --> Total execution time: 0.0604
DEBUG - 2022-07-07 06:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:14:28 --> Total execution time: 0.1139
DEBUG - 2022-07-07 06:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:15:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:46:00 --> Total execution time: 1.9114
DEBUG - 2022-07-07 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:16:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:47:54 --> Total execution time: 0.1432
DEBUG - 2022-07-07 06:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:48:46 --> Total execution time: 0.0527
DEBUG - 2022-07-07 06:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:50:02 --> Total execution time: 0.0746
DEBUG - 2022-07-07 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:50:23 --> Total execution time: 0.0843
DEBUG - 2022-07-07 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:50:33 --> Total execution time: 0.0821
DEBUG - 2022-07-07 06:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:21:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:51:01 --> Total execution time: 0.1676
DEBUG - 2022-07-07 06:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:51:19 --> Total execution time: 0.1090
DEBUG - 2022-07-07 06:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:51:53 --> Total execution time: 0.1045
DEBUG - 2022-07-07 06:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:52:14 --> Total execution time: 0.0451
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:52:15 --> Total execution time: 0.0439
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:16 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-07 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:17 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:17 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:17 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-07 06:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 06:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:19 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-07 06:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:21 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:21 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:22:21 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:53:09 --> Total execution time: 0.1517
DEBUG - 2022-07-07 06:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:53:37 --> Total execution time: 0.0731
DEBUG - 2022-07-07 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:23:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:23:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 06:23:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-07 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:23:50 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:53:50 --> Total execution time: 0.0548
DEBUG - 2022-07-07 06:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:08 --> Total execution time: 0.0568
DEBUG - 2022-07-07 06:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:23 --> Total execution time: 0.0672
DEBUG - 2022-07-07 06:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:25 --> Total execution time: 0.0661
DEBUG - 2022-07-07 06:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:27 --> Total execution time: 0.0774
DEBUG - 2022-07-07 06:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:42 --> Total execution time: 0.0643
DEBUG - 2022-07-07 06:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:46 --> Total execution time: 0.0673
DEBUG - 2022-07-07 06:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:48 --> Total execution time: 0.0906
DEBUG - 2022-07-07 06:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:52 --> Total execution time: 0.0784
DEBUG - 2022-07-07 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:54 --> Total execution time: 0.0693
DEBUG - 2022-07-07 06:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:54:57 --> Total execution time: 0.0696
DEBUG - 2022-07-07 06:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:55:13 --> Total execution time: 0.0595
DEBUG - 2022-07-07 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:25:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:55:21 --> Total execution time: 0.0532
DEBUG - 2022-07-07 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:26:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:56:57 --> Total execution time: 0.0443
DEBUG - 2022-07-07 06:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:26:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:56:58 --> Total execution time: 0.0465
DEBUG - 2022-07-07 06:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:27:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:57:19 --> Total execution time: 0.0542
DEBUG - 2022-07-07 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:28:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:58:29 --> Total execution time: 0.0405
DEBUG - 2022-07-07 06:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:29:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:59:36 --> Total execution time: 0.0392
DEBUG - 2022-07-07 06:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:29:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:59:43 --> Total execution time: 0.0690
DEBUG - 2022-07-07 06:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:31:17 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:01:17 --> Total execution time: 0.0375
DEBUG - 2022-07-07 06:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:31:17 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:01:17 --> Total execution time: 0.0438
DEBUG - 2022-07-07 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:35:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:05:08 --> Total execution time: 0.1432
DEBUG - 2022-07-07 06:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:40:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 06:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:10:08 --> Total execution time: 0.1145
DEBUG - 2022-07-07 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:13:47 --> Total execution time: 0.0621
DEBUG - 2022-07-07 06:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:13:53 --> Total execution time: 0.0536
DEBUG - 2022-07-07 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:00 --> Total execution time: 0.0710
DEBUG - 2022-07-07 06:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:08 --> Total execution time: 0.0522
DEBUG - 2022-07-07 06:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:10 --> Total execution time: 0.0505
DEBUG - 2022-07-07 06:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:12 --> Total execution time: 0.0437
DEBUG - 2022-07-07 06:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:24 --> Total execution time: 0.0805
DEBUG - 2022-07-07 06:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:26 --> Total execution time: 0.0503
DEBUG - 2022-07-07 06:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:33 --> Total execution time: 0.0527
DEBUG - 2022-07-07 06:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 06:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:45 --> Total execution time: 0.0600
DEBUG - 2022-07-07 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:49 --> Total execution time: 0.0673
DEBUG - 2022-07-07 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:14:57 --> Total execution time: 0.0499
DEBUG - 2022-07-07 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:00 --> Total execution time: 0.0638
DEBUG - 2022-07-07 06:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:04 --> Total execution time: 0.0639
DEBUG - 2022-07-07 06:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:06 --> Total execution time: 0.0635
DEBUG - 2022-07-07 06:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:11 --> Total execution time: 0.0944
DEBUG - 2022-07-07 06:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:30 --> Total execution time: 0.0940
DEBUG - 2022-07-07 06:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:40 --> Total execution time: 0.0768
DEBUG - 2022-07-07 06:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:42 --> Total execution time: 0.0723
DEBUG - 2022-07-07 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:51 --> Total execution time: 0.0881
DEBUG - 2022-07-07 06:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:15:57 --> Total execution time: 0.0715
DEBUG - 2022-07-07 06:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 06:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 06:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:27:18 --> Total execution time: 0.1694
DEBUG - 2022-07-07 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:30:04 --> Total execution time: 0.1976
DEBUG - 2022-07-07 07:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:37:25 --> Total execution time: 0.1135
DEBUG - 2022-07-07 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:37:49 --> Total execution time: 0.0683
DEBUG - 2022-07-07 07:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:38:40 --> Total execution time: 0.0668
DEBUG - 2022-07-07 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:38:54 --> Total execution time: 0.0826
DEBUG - 2022-07-07 07:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:39:14 --> Total execution time: 0.0823
DEBUG - 2022-07-07 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:39:35 --> Total execution time: 0.0523
DEBUG - 2022-07-07 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:39:41 --> Total execution time: 0.0623
DEBUG - 2022-07-07 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:39:50 --> Total execution time: 0.0710
DEBUG - 2022-07-07 07:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:39:53 --> Total execution time: 0.0602
DEBUG - 2022-07-07 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:39:56 --> Total execution time: 0.0878
DEBUG - 2022-07-07 07:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:40:04 --> Total execution time: 0.0555
DEBUG - 2022-07-07 07:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:40:21 --> Total execution time: 0.1158
DEBUG - 2022-07-07 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:40:31 --> Total execution time: 0.0606
DEBUG - 2022-07-07 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:41:09 --> Total execution time: 0.1466
DEBUG - 2022-07-07 07:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:11:10 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 07:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:41:37 --> Total execution time: 0.1209
DEBUG - 2022-07-07 07:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:41:52 --> Total execution time: 0.0779
DEBUG - 2022-07-07 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:41:55 --> Total execution time: 0.0536
DEBUG - 2022-07-07 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:41:58 --> Total execution time: 0.0590
DEBUG - 2022-07-07 07:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:41:59 --> Total execution time: 0.0490
DEBUG - 2022-07-07 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:42:05 --> Total execution time: 0.0597
DEBUG - 2022-07-07 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:42:47 --> Total execution time: 0.1374
DEBUG - 2022-07-07 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:13:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:43:25 --> Total execution time: 0.1484
DEBUG - 2022-07-07 07:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:18 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:44:18 --> Total execution time: 0.0416
DEBUG - 2022-07-07 07:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:14:19 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 07:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:14:27 --> Total execution time: 0.0604
DEBUG - 2022-07-07 07:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:14:30 --> Total execution time: 0.0663
DEBUG - 2022-07-07 07:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:14:30 --> Total execution time: 0.1125
DEBUG - 2022-07-07 07:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:14:58 --> Total execution time: 0.0407
DEBUG - 2022-07-07 07:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:15:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 07:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:45:17 --> Total execution time: 2.0697
DEBUG - 2022-07-07 07:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:15:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 07:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:16:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:17:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:47:46 --> Total execution time: 0.0754
DEBUG - 2022-07-07 07:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:50:07 --> Total execution time: 0.2188
DEBUG - 2022-07-07 07:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:50:18 --> Total execution time: 0.0593
DEBUG - 2022-07-07 07:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:20:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:50:55 --> Total execution time: 0.0459
DEBUG - 2022-07-07 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:20:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:50:56 --> Total execution time: 0.0506
DEBUG - 2022-07-07 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:51:02 --> Total execution time: 0.0861
DEBUG - 2022-07-07 07:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:51:13 --> Total execution time: 0.0599
DEBUG - 2022-07-07 07:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:51:27 --> Total execution time: 0.0535
DEBUG - 2022-07-07 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:51:31 --> Total execution time: 0.1226
DEBUG - 2022-07-07 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:51:35 --> Total execution time: 0.0714
DEBUG - 2022-07-07 07:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:24:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:54:27 --> Total execution time: 0.1261
DEBUG - 2022-07-07 07:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:24:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:54:27 --> Total execution time: 0.0871
DEBUG - 2022-07-07 07:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:24:40 --> Total execution time: 0.0677
DEBUG - 2022-07-07 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:24:53 --> Total execution time: 0.0763
DEBUG - 2022-07-07 07:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:25:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:55:06 --> Total execution time: 0.0368
DEBUG - 2022-07-07 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:33:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:03:06 --> Total execution time: 0.1126
DEBUG - 2022-07-07 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:03:47 --> Total execution time: 0.0521
DEBUG - 2022-07-07 07:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:33:59 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:03:59 --> Total execution time: 0.0516
DEBUG - 2022-07-07 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:37:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:07:33 --> Total execution time: 0.1236
DEBUG - 2022-07-07 07:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:07:37 --> Total execution time: 0.0362
DEBUG - 2022-07-07 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:07:40 --> Total execution time: 0.0287
DEBUG - 2022-07-07 07:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:07:41 --> Total execution time: 0.0451
DEBUG - 2022-07-07 07:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:07:41 --> Total execution time: 0.0384
DEBUG - 2022-07-07 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:07:57 --> Total execution time: 0.0512
DEBUG - 2022-07-07 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:20 --> Total execution time: 0.0749
DEBUG - 2022-07-07 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:22 --> Total execution time: 0.0342
DEBUG - 2022-07-07 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:22 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:23 --> Total execution time: 0.1220
DEBUG - 2022-07-07 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:26 --> Total execution time: 0.0300
DEBUG - 2022-07-07 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:31 --> Total execution time: 0.1042
DEBUG - 2022-07-07 07:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:34 --> Total execution time: 0.0401
DEBUG - 2022-07-07 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:41 --> Total execution time: 0.0958
DEBUG - 2022-07-07 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:49 --> Total execution time: 0.0686
DEBUG - 2022-07-07 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:49 --> Total execution time: 0.0577
DEBUG - 2022-07-07 07:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:51 --> Total execution time: 0.0692
DEBUG - 2022-07-07 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:52 --> Total execution time: 0.0628
DEBUG - 2022-07-07 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:08:53 --> Total execution time: 0.0343
DEBUG - 2022-07-07 07:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:09:00 --> Total execution time: 0.0508
DEBUG - 2022-07-07 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:10:52 --> Total execution time: 0.0490
DEBUG - 2022-07-07 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:10:57 --> Total execution time: 0.0717
DEBUG - 2022-07-07 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:11:01 --> Total execution time: 0.0526
DEBUG - 2022-07-07 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:11:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 07:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:11:02 --> Total execution time: 0.0789
DEBUG - 2022-07-07 07:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:42:00 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-07 07:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:42:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 07:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:42:04 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-07 07:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:42:06 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-07 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:12:14 --> Total execution time: 0.0582
DEBUG - 2022-07-07 07:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:12:21 --> Total execution time: 0.0515
DEBUG - 2022-07-07 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:12:26 --> Total execution time: 0.0671
DEBUG - 2022-07-07 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:12:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:12:27 --> Total execution time: 0.0439
DEBUG - 2022-07-07 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:13:04 --> Total execution time: 0.0630
DEBUG - 2022-07-07 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:13:08 --> Total execution time: 0.0540
DEBUG - 2022-07-07 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:13:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:13:09 --> Total execution time: 0.0686
DEBUG - 2022-07-07 07:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:13:56 --> Total execution time: 0.0573
DEBUG - 2022-07-07 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:13:59 --> Total execution time: 0.0489
DEBUG - 2022-07-07 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:44:08 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:14:08 --> Total execution time: 0.0375
DEBUG - 2022-07-07 07:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:09 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:15:09 --> Total execution time: 0.0529
DEBUG - 2022-07-07 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:15:13 --> Total execution time: 0.0526
DEBUG - 2022-07-07 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:15:13 --> Total execution time: 0.0823
DEBUG - 2022-07-07 07:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:15:14 --> Total execution time: 0.0544
DEBUG - 2022-07-07 07:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:15:15 --> Total execution time: 0.0631
DEBUG - 2022-07-07 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:45:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 07:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:16:18 --> Total execution time: 0.0502
DEBUG - 2022-07-07 07:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:16:29 --> Total execution time: 0.0536
DEBUG - 2022-07-07 07:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:16:32 --> Total execution time: 0.0823
DEBUG - 2022-07-07 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:16:39 --> Total execution time: 0.1127
DEBUG - 2022-07-07 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:47:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:17:25 --> Total execution time: 0.0396
DEBUG - 2022-07-07 07:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:47:28 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:17:28 --> Total execution time: 0.0377
DEBUG - 2022-07-07 07:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:47:35 --> 404 Page Not Found: Cache/wp_wrong_datlib.php
DEBUG - 2022-07-07 07:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:47:36 --> Total execution time: 0.0643
DEBUG - 2022-07-07 07:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:47:38 --> Total execution time: 0.0557
DEBUG - 2022-07-07 07:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:47:38 --> Total execution time: 0.0898
DEBUG - 2022-07-07 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:51:18 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:21:19 --> Total execution time: 0.1209
DEBUG - 2022-07-07 07:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:51:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 07:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:21:51 --> Total execution time: 1.8943
DEBUG - 2022-07-07 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:51:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 07:51:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:23:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:23:11 --> Total execution time: 0.0623
DEBUG - 2022-07-07 07:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:23:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 18:23:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 18:23:13 --> Total execution time: 0.2278
DEBUG - 2022-07-07 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:53:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:23:57 --> Total execution time: 0.0472
DEBUG - 2022-07-07 07:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:02 --> Total execution time: 0.0378
DEBUG - 2022-07-07 07:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:18 --> Total execution time: 0.0675
DEBUG - 2022-07-07 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:22 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:22 --> Total execution time: 0.0752
DEBUG - 2022-07-07 07:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:34 --> Total execution time: 0.0517
DEBUG - 2022-07-07 07:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:34 --> Total execution time: 0.0864
DEBUG - 2022-07-07 07:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:36 --> Total execution time: 0.0540
DEBUG - 2022-07-07 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:41 --> Total execution time: 0.0553
DEBUG - 2022-07-07 07:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:49 --> Total execution time: 0.0509
DEBUG - 2022-07-07 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:56 --> Total execution time: 0.0543
DEBUG - 2022-07-07 07:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:24:59 --> Total execution time: 0.0548
DEBUG - 2022-07-07 07:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:55:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:25:00 --> Total execution time: 0.0550
DEBUG - 2022-07-07 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:25:36 --> Total execution time: 0.0527
DEBUG - 2022-07-07 07:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:25:43 --> Total execution time: 0.0496
DEBUG - 2022-07-07 07:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 07:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:26:00 --> Total execution time: 0.0350
DEBUG - 2022-07-07 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:26:03 --> Total execution time: 0.0498
DEBUG - 2022-07-07 07:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:26:24 --> Total execution time: 0.0648
DEBUG - 2022-07-07 07:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:26:46 --> Total execution time: 0.0737
DEBUG - 2022-07-07 07:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:26:50 --> Total execution time: 0.0796
DEBUG - 2022-07-07 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 07:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:27:05 --> Total execution time: 0.1865
DEBUG - 2022-07-07 08:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:30:15 --> Total execution time: 0.3078
DEBUG - 2022-07-07 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:01:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:31:05 --> Total execution time: 0.0504
DEBUG - 2022-07-07 08:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:05:12 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:35:12 --> Total execution time: 0.1568
DEBUG - 2022-07-07 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:36:11 --> Total execution time: 0.0599
DEBUG - 2022-07-07 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:37:44 --> Total execution time: 0.0466
DEBUG - 2022-07-07 08:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:38:24 --> Total execution time: 0.4448
DEBUG - 2022-07-07 08:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:38:25 --> Total execution time: 0.1213
DEBUG - 2022-07-07 08:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:38:34 --> Total execution time: 0.0752
DEBUG - 2022-07-07 08:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:38:41 --> Total execution time: 0.0621
DEBUG - 2022-07-07 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:38:52 --> Total execution time: 0.0621
DEBUG - 2022-07-07 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:08:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-07 08:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:08:56 --> 404 Page Not Found: Lessons/create-images
DEBUG - 2022-07-07 08:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:40:25 --> Total execution time: 0.0656
DEBUG - 2022-07-07 08:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:10:27 --> 404 Page Not Found: Wp-content/index
DEBUG - 2022-07-07 08:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:13:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:43:21 --> Total execution time: 0.1150
DEBUG - 2022-07-07 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:43:39 --> Total execution time: 0.0545
DEBUG - 2022-07-07 08:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:43:46 --> Total execution time: 0.0569
DEBUG - 2022-07-07 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:44:09 --> Total execution time: 0.1048
DEBUG - 2022-07-07 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:14:37 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:44:37 --> Total execution time: 0.0385
DEBUG - 2022-07-07 08:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:44:41 --> Total execution time: 0.1321
DEBUG - 2022-07-07 08:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:14:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:44:42 --> Total execution time: 0.0516
DEBUG - 2022-07-07 08:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:44:59 --> Total execution time: 1.9616
DEBUG - 2022-07-07 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:15:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:45:47 --> Total execution time: 1.6647
DEBUG - 2022-07-07 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:45:48 --> Total execution time: 0.0885
DEBUG - 2022-07-07 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:15:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 08:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:45:57 --> Total execution time: 0.0772
DEBUG - 2022-07-07 08:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:16:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:46:01 --> Total execution time: 0.0352
DEBUG - 2022-07-07 08:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:46:35 --> Total execution time: 0.0325
DEBUG - 2022-07-07 08:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:47:06 --> Total execution time: 0.0620
DEBUG - 2022-07-07 08:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:47:12 --> Total execution time: 0.0570
DEBUG - 2022-07-07 08:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:47:26 --> Total execution time: 0.0596
DEBUG - 2022-07-07 08:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:17:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:47:42 --> Total execution time: 0.0464
DEBUG - 2022-07-07 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:18:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:48:16 --> Total execution time: 0.0588
DEBUG - 2022-07-07 08:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:18:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:48:22 --> Total execution time: 0.0599
DEBUG - 2022-07-07 08:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:48:35 --> Total execution time: 0.0551
DEBUG - 2022-07-07 08:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:19:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:49:06 --> Total execution time: 0.0389
DEBUG - 2022-07-07 08:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:19:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:19:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:49:25 --> Total execution time: 0.0351
DEBUG - 2022-07-07 08:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:19:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:49:57 --> Total execution time: 0.0368
DEBUG - 2022-07-07 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:20:45 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:50:45 --> Total execution time: 0.0783
DEBUG - 2022-07-07 08:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:51:12 --> Total execution time: 0.0528
DEBUG - 2022-07-07 08:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:21:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:51:39 --> Total execution time: 0.0573
DEBUG - 2022-07-07 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:22:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:52:01 --> Total execution time: 0.0910
DEBUG - 2022-07-07 08:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:52:09 --> Total execution time: 0.0543
DEBUG - 2022-07-07 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:23:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:53:52 --> Total execution time: 0.1269
DEBUG - 2022-07-07 08:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:54:05 --> Total execution time: 0.0752
DEBUG - 2022-07-07 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:24:30 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:54:30 --> Total execution time: 0.1520
DEBUG - 2022-07-07 08:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:04 --> Total execution time: 0.0366
DEBUG - 2022-07-07 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:05 --> Total execution time: 0.0506
DEBUG - 2022-07-07 08:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:08 --> Total execution time: 0.0505
DEBUG - 2022-07-07 08:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:11 --> Total execution time: 0.0386
DEBUG - 2022-07-07 08:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:45 --> Total execution time: 0.0505
DEBUG - 2022-07-07 08:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:55 --> Total execution time: 0.0544
DEBUG - 2022-07-07 08:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:56:59 --> Total execution time: 0.0491
DEBUG - 2022-07-07 08:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:57:46 --> Total execution time: 0.0525
DEBUG - 2022-07-07 08:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:57:58 --> Total execution time: 0.0537
DEBUG - 2022-07-07 08:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:58:58 --> Total execution time: 0.0605
DEBUG - 2022-07-07 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:59:46 --> Total execution time: 0.0570
DEBUG - 2022-07-07 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:15 --> Total execution time: 0.0403
DEBUG - 2022-07-07 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:19 --> Total execution time: 0.0324
DEBUG - 2022-07-07 08:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:28 --> Total execution time: 0.0773
DEBUG - 2022-07-07 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:28 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:28 --> Total execution time: 0.0433
DEBUG - 2022-07-07 08:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:35 --> Total execution time: 0.0944
DEBUG - 2022-07-07 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:45 --> Total execution time: 0.0841
DEBUG - 2022-07-07 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:50 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:50 --> Total execution time: 0.0606
DEBUG - 2022-07-07 08:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:55 --> Total execution time: 0.0539
DEBUG - 2022-07-07 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:00:58 --> Total execution time: 0.0535
DEBUG - 2022-07-07 08:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:06 --> Total execution time: 0.1364
DEBUG - 2022-07-07 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:11 --> Total execution time: 0.0545
DEBUG - 2022-07-07 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:14 --> Total execution time: 0.0827
DEBUG - 2022-07-07 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:19 --> Total execution time: 0.0482
DEBUG - 2022-07-07 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:19 --> Total execution time: 0.0535
DEBUG - 2022-07-07 08:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:33 --> Total execution time: 0.0390
DEBUG - 2022-07-07 08:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:01:44 --> Total execution time: 0.0522
DEBUG - 2022-07-07 08:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:02:12 --> Total execution time: 0.0535
DEBUG - 2022-07-07 08:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:02:18 --> Total execution time: 0.0543
DEBUG - 2022-07-07 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:02:23 --> Total execution time: 0.0539
DEBUG - 2022-07-07 08:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:33:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:03:42 --> Total execution time: 0.1407
DEBUG - 2022-07-07 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:03:49 --> Total execution time: 0.0517
DEBUG - 2022-07-07 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:14 --> Total execution time: 0.0514
DEBUG - 2022-07-07 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:34:18 --> Total execution time: 0.0563
DEBUG - 2022-07-07 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:34:21 --> Total execution time: 0.0538
DEBUG - 2022-07-07 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:34:21 --> Total execution time: 0.1138
DEBUG - 2022-07-07 08:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:23 --> Total execution time: 0.0496
DEBUG - 2022-07-07 08:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:24 --> Total execution time: 0.1474
DEBUG - 2022-07-07 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:25 --> Total execution time: 0.0476
DEBUG - 2022-07-07 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:25 --> Total execution time: 0.0539
DEBUG - 2022-07-07 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:29 --> Total execution time: 0.0542
DEBUG - 2022-07-07 08:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:31 --> Total execution time: 0.0723
DEBUG - 2022-07-07 08:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:33 --> Total execution time: 0.0620
DEBUG - 2022-07-07 08:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:48 --> Total execution time: 0.0617
DEBUG - 2022-07-07 08:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:51 --> Total execution time: 0.0775
DEBUG - 2022-07-07 08:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:54 --> Total execution time: 0.0672
DEBUG - 2022-07-07 08:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:56 --> Total execution time: 0.0746
DEBUG - 2022-07-07 08:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:04:58 --> Total execution time: 0.0496
DEBUG - 2022-07-07 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:05:01 --> Total execution time: 0.0696
DEBUG - 2022-07-07 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:05:21 --> Total execution time: 0.0579
DEBUG - 2022-07-07 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:35:45 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:05:45 --> Total execution time: 0.0441
DEBUG - 2022-07-07 08:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:08:58 --> Total execution time: 0.1768
DEBUG - 2022-07-07 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:09:03 --> Total execution time: 0.0989
DEBUG - 2022-07-07 08:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:09:08 --> Total execution time: 0.0617
DEBUG - 2022-07-07 08:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:09:15 --> Total execution time: 0.0795
DEBUG - 2022-07-07 08:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:09:21 --> Total execution time: 0.2225
DEBUG - 2022-07-07 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:09:33 --> Total execution time: 0.0509
DEBUG - 2022-07-07 08:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:39:51 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 08:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:39:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:09:55 --> Total execution time: 0.0585
DEBUG - 2022-07-07 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:41:23 --> Total execution time: 0.0579
DEBUG - 2022-07-07 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:41:23 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:11:24 --> Total execution time: 0.1409
DEBUG - 2022-07-07 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:41:37 --> Total execution time: 0.0619
DEBUG - 2022-07-07 08:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:41:37 --> Total execution time: 0.1441
DEBUG - 2022-07-07 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:42:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:12:25 --> Total execution time: 0.1335
DEBUG - 2022-07-07 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:12:38 --> Total execution time: 0.0339
DEBUG - 2022-07-07 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:42:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:12:44 --> Total execution time: 0.0608
DEBUG - 2022-07-07 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:42:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:12:51 --> Total execution time: 0.0553
DEBUG - 2022-07-07 19:12:53 --> Total execution time: 2.0987
DEBUG - 2022-07-07 08:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:13:03 --> Total execution time: 0.0576
DEBUG - 2022-07-07 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:43:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 08:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:13:19 --> Total execution time: 0.0569
DEBUG - 2022-07-07 08:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:13:56 --> Total execution time: 0.0925
DEBUG - 2022-07-07 08:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:14:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 08:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:14:25 --> Total execution time: 0.0590
DEBUG - 2022-07-07 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:14:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 19:14:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 19:14:26 --> Total execution time: 0.1980
DEBUG - 2022-07-07 08:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:14:50 --> Total execution time: 0.0554
DEBUG - 2022-07-07 08:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:15:05 --> Total execution time: 0.0428
DEBUG - 2022-07-07 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:15:34 --> Total execution time: 0.0642
DEBUG - 2022-07-07 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:15:34 --> Total execution time: 0.0598
DEBUG - 2022-07-07 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:15:40 --> Total execution time: 0.0590
DEBUG - 2022-07-07 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:15:43 --> Total execution time: 0.0974
DEBUG - 2022-07-07 08:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:45:49 --> Total execution time: 0.0670
DEBUG - 2022-07-07 08:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:45:58 --> Total execution time: 0.1199
DEBUG - 2022-07-07 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:18:28 --> Total execution time: 0.2028
DEBUG - 2022-07-07 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:18:40 --> Total execution time: 0.0330
DEBUG - 2022-07-07 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:18:59 --> Total execution time: 0.1427
DEBUG - 2022-07-07 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:02 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:19:02 --> Total execution time: 0.0397
DEBUG - 2022-07-07 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:19:08 --> Total execution time: 0.1330
DEBUG - 2022-07-07 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:19:19 --> Total execution time: 0.0873
DEBUG - 2022-07-07 08:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:19:21 --> Total execution time: 0.0524
DEBUG - 2022-07-07 08:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:19:28 --> Total execution time: 0.0570
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 08:49:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-07 08:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:19:50 --> Total execution time: 0.0655
DEBUG - 2022-07-07 08:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:20:04 --> Total execution time: 0.0599
DEBUG - 2022-07-07 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:22:36 --> Total execution time: 0.1785
DEBUG - 2022-07-07 08:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:52:45 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:22:45 --> Total execution time: 0.0614
DEBUG - 2022-07-07 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:22:49 --> Total execution time: 0.0553
DEBUG - 2022-07-07 08:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:22:50 --> Total execution time: 0.0551
DEBUG - 2022-07-07 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:23:03 --> Total execution time: 0.0615
DEBUG - 2022-07-07 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:23:27 --> Total execution time: 0.0565
DEBUG - 2022-07-07 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:23:34 --> Total execution time: 0.0633
DEBUG - 2022-07-07 08:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:23:58 --> Total execution time: 0.0575
DEBUG - 2022-07-07 08:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:24:52 --> Total execution time: 0.0330
DEBUG - 2022-07-07 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:25:15 --> Total execution time: 0.0651
DEBUG - 2022-07-07 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:25:24 --> Total execution time: 0.0776
DEBUG - 2022-07-07 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:26:10 --> Total execution time: 0.0590
DEBUG - 2022-07-07 08:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:56:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 08:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:26:15 --> Total execution time: 0.0352
DEBUG - 2022-07-07 08:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:26:18 --> Total execution time: 0.0487
DEBUG - 2022-07-07 08:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:56:41 --> Total execution time: 0.0647
DEBUG - 2022-07-07 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:27:03 --> Total execution time: 0.0566
DEBUG - 2022-07-07 08:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:27:13 --> Total execution time: 0.0649
DEBUG - 2022-07-07 08:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:27:30 --> Total execution time: 0.1518
DEBUG - 2022-07-07 08:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 08:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 08:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 08:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:29:58 --> Total execution time: 0.0535
DEBUG - 2022-07-07 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:30:02 --> Total execution time: 0.0702
DEBUG - 2022-07-07 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:01:26 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:31:26 --> Total execution time: 0.0417
DEBUG - 2022-07-07 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:32:01 --> Total execution time: 0.0465
DEBUG - 2022-07-07 09:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:32:15 --> Total execution time: 0.0554
DEBUG - 2022-07-07 09:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:32:20 --> Total execution time: 0.0784
DEBUG - 2022-07-07 09:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:03:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:33:05 --> Total execution time: 0.0360
DEBUG - 2022-07-07 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:03:28 --> Total execution time: 0.0517
DEBUG - 2022-07-07 09:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:03:31 --> Total execution time: 0.0696
DEBUG - 2022-07-07 09:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:03:31 --> Total execution time: 0.1538
DEBUG - 2022-07-07 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 09:09:30 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:42:14 --> Total execution time: 0.2636
DEBUG - 2022-07-07 09:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:42:20 --> Total execution time: 0.0715
DEBUG - 2022-07-07 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:42:28 --> Total execution time: 0.1101
DEBUG - 2022-07-07 09:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:42:42 --> Total execution time: 0.1107
DEBUG - 2022-07-07 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 09:12:43 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 09:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:42:44 --> Total execution time: 0.0542
DEBUG - 2022-07-07 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 09:15:25 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:15:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:45:29 --> Total execution time: 0.0767
DEBUG - 2022-07-07 09:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:15:30 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:45:30 --> Total execution time: 0.0861
DEBUG - 2022-07-07 09:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:45:57 --> Total execution time: 0.3642
DEBUG - 2022-07-07 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:46:43 --> Total execution time: 0.0514
DEBUG - 2022-07-07 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:17:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:47:07 --> Total execution time: 0.0461
DEBUG - 2022-07-07 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:17:23 --> Total execution time: 0.0533
DEBUG - 2022-07-07 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:17:43 --> Total execution time: 0.0771
DEBUG - 2022-07-07 09:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:17:43 --> Total execution time: 0.1216
DEBUG - 2022-07-07 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:18:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:49:01 --> Total execution time: 2.0016
DEBUG - 2022-07-07 09:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:20:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:50:27 --> Total execution time: 0.0484
DEBUG - 2022-07-07 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:50:44 --> Total execution time: 0.0398
DEBUG - 2022-07-07 09:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:51:08 --> Total execution time: 0.0774
DEBUG - 2022-07-07 09:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:51:19 --> Total execution time: 0.0755
DEBUG - 2022-07-07 09:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:51:47 --> Total execution time: 0.0551
DEBUG - 2022-07-07 09:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:51:50 --> Total execution time: 0.0627
DEBUG - 2022-07-07 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:51:56 --> Total execution time: 0.0621
DEBUG - 2022-07-07 09:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:22:09 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:52:09 --> Total execution time: 0.0420
DEBUG - 2022-07-07 09:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:52:30 --> Total execution time: 0.0683
DEBUG - 2022-07-07 09:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:52:32 --> Total execution time: 0.0543
DEBUG - 2022-07-07 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:22:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:52:34 --> Total execution time: 0.0666
DEBUG - 2022-07-07 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:22:44 --> Total execution time: 0.0654
DEBUG - 2022-07-07 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:23:02 --> Total execution time: 0.0675
DEBUG - 2022-07-07 09:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:23:02 --> Total execution time: 0.1457
DEBUG - 2022-07-07 09:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:24:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:54:35 --> Total execution time: 1.4599
DEBUG - 2022-07-07 09:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:54:36 --> Total execution time: 0.0586
DEBUG - 2022-07-07 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:54:43 --> Total execution time: 0.0603
DEBUG - 2022-07-07 09:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:56:25 --> Total execution time: 0.1477
DEBUG - 2022-07-07 09:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:56:36 --> Total execution time: 0.0405
DEBUG - 2022-07-07 09:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:26:44 --> Total execution time: 0.0589
DEBUG - 2022-07-07 09:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:57:03 --> Total execution time: 0.0596
DEBUG - 2022-07-07 09:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:57:52 --> Total execution time: 0.1003
DEBUG - 2022-07-07 09:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:57:53 --> Total execution time: 0.0943
DEBUG - 2022-07-07 09:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:58:38 --> Total execution time: 0.0529
DEBUG - 2022-07-07 09:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:58:39 --> Total execution time: 0.0566
DEBUG - 2022-07-07 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:58:52 --> Total execution time: 0.0882
DEBUG - 2022-07-07 09:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:58:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:58:55 --> Total execution time: 0.0564
DEBUG - 2022-07-07 09:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:58:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 19:58:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 19:58:56 --> Total execution time: 0.2165
DEBUG - 2022-07-07 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:00 --> Total execution time: 0.0829
DEBUG - 2022-07-07 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:03 --> Total execution time: 0.0878
DEBUG - 2022-07-07 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:08 --> Total execution time: 0.0573
DEBUG - 2022-07-07 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:11 --> Total execution time: 0.0587
DEBUG - 2022-07-07 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:12 --> Total execution time: 0.0637
DEBUG - 2022-07-07 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 19:59:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 19:59:13 --> Total execution time: 0.1843
DEBUG - 2022-07-07 09:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:25 --> Total execution time: 0.0686
DEBUG - 2022-07-07 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:28 --> Total execution time: 0.0883
DEBUG - 2022-07-07 09:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:31 --> Total execution time: 0.0609
DEBUG - 2022-07-07 09:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:59:53 --> Total execution time: 0.0498
DEBUG - 2022-07-07 09:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:00:05 --> Total execution time: 0.0659
DEBUG - 2022-07-07 09:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:00:31 --> Total execution time: 0.0683
DEBUG - 2022-07-07 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:30:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:00:55 --> Total execution time: 0.0737
DEBUG - 2022-07-07 09:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:02:52 --> Total execution time: 0.0411
DEBUG - 2022-07-07 09:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:27 --> Total execution time: 0.0334
DEBUG - 2022-07-07 09:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:34 --> Total execution time: 0.0597
DEBUG - 2022-07-07 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:37 --> Total execution time: 0.0757
DEBUG - 2022-07-07 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:42 --> Total execution time: 0.0682
DEBUG - 2022-07-07 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:50 --> Total execution time: 0.0734
DEBUG - 2022-07-07 09:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:06:21 --> Total execution time: 0.0520
DEBUG - 2022-07-07 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:37:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:07:00 --> Total execution time: 0.1300
DEBUG - 2022-07-07 09:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:07:11 --> Total execution time: 0.0774
DEBUG - 2022-07-07 09:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:07:23 --> Total execution time: 0.0545
DEBUG - 2022-07-07 09:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:37:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:07:39 --> Total execution time: 0.0381
DEBUG - 2022-07-07 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:07:55 --> Total execution time: 0.0697
DEBUG - 2022-07-07 09:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:07:58 --> Total execution time: 0.0575
DEBUG - 2022-07-07 09:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:08:00 --> Total execution time: 0.0706
DEBUG - 2022-07-07 09:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:08:10 --> Total execution time: 0.0490
DEBUG - 2022-07-07 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:38:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:08:21 --> Total execution time: 0.0344
DEBUG - 2022-07-07 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:38:31 --> Total execution time: 0.0491
DEBUG - 2022-07-07 09:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:38:59 --> Total execution time: 0.0507
DEBUG - 2022-07-07 09:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:38:59 --> Total execution time: 0.1107
DEBUG - 2022-07-07 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:39:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:09:10 --> Total execution time: 0.0371
DEBUG - 2022-07-07 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:39:10 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:09:10 --> Total execution time: 0.0512
DEBUG - 2022-07-07 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:41:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:41:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:11:32 --> Total execution time: 0.0650
DEBUG - 2022-07-07 20:11:32 --> Total execution time: 0.1167
DEBUG - 2022-07-07 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:41:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:11:46 --> Total execution time: 2.0432
DEBUG - 2022-07-07 09:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 09:41:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 09:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:42:34 --> Total execution time: 0.0494
DEBUG - 2022-07-07 09:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:12:41 --> Total execution time: 0.0530
DEBUG - 2022-07-07 09:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:12:49 --> Total execution time: 0.1028
DEBUG - 2022-07-07 09:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:12:50 --> Total execution time: 0.0967
DEBUG - 2022-07-07 09:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:04 --> Total execution time: 0.0838
DEBUG - 2022-07-07 09:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:23 --> Total execution time: 0.0600
DEBUG - 2022-07-07 09:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:24 --> Total execution time: 0.0637
DEBUG - 2022-07-07 09:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:30 --> Total execution time: 0.0557
DEBUG - 2022-07-07 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 09:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:41 --> Total execution time: 0.0506
DEBUG - 2022-07-07 09:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 20:13:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 20:13:43 --> Total execution time: 0.1830
DEBUG - 2022-07-07 09:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:43:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:13:44 --> Total execution time: 0.0342
DEBUG - 2022-07-07 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:14:05 --> Total execution time: 0.0659
DEBUG - 2022-07-07 09:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 09:44:11 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:44:46 --> Total execution time: 0.0350
DEBUG - 2022-07-07 09:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:44:47 --> Total execution time: 0.0549
DEBUG - 2022-07-07 09:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:44:47 --> Total execution time: 0.1357
DEBUG - 2022-07-07 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:44:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:14:55 --> Total execution time: 0.0634
DEBUG - 2022-07-07 09:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:14:55 --> Total execution time: 0.1342
DEBUG - 2022-07-07 09:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:45:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:15:01 --> Total execution time: 0.0591
DEBUG - 2022-07-07 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:46:28 --> Total execution time: 0.0547
DEBUG - 2022-07-07 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:46:30 --> Total execution time: 0.0571
DEBUG - 2022-07-07 09:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:46:31 --> Total execution time: 0.1198
DEBUG - 2022-07-07 09:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:47:01 --> Total execution time: 0.0521
DEBUG - 2022-07-07 09:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:47:03 --> Total execution time: 0.0494
DEBUG - 2022-07-07 09:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 09:47:03 --> Total execution time: 0.1216
DEBUG - 2022-07-07 09:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:17:48 --> Total execution time: 0.1279
DEBUG - 2022-07-07 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:17:49 --> Total execution time: 0.0483
DEBUG - 2022-07-07 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:18:03 --> Total execution time: 0.0608
DEBUG - 2022-07-07 09:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:18:55 --> Total execution time: 0.1487
DEBUG - 2022-07-07 09:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:19:11 --> Total execution time: 0.0549
DEBUG - 2022-07-07 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:19:29 --> Total execution time: 0.0550
DEBUG - 2022-07-07 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:19:37 --> Total execution time: 0.0615
DEBUG - 2022-07-07 09:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:20:00 --> Total execution time: 0.0516
DEBUG - 2022-07-07 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:51:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:21:13 --> Total execution time: 0.0395
DEBUG - 2022-07-07 09:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:57:23 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:27:23 --> Total execution time: 0.1074
DEBUG - 2022-07-07 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:57:28 --> No URI present. Default controller set.
DEBUG - 2022-07-07 09:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:27:28 --> Total execution time: 0.0361
DEBUG - 2022-07-07 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:28:08 --> Total execution time: 0.1522
DEBUG - 2022-07-07 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:28:14 --> Total execution time: 0.0709
DEBUG - 2022-07-07 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:28:17 --> Total execution time: 0.0564
DEBUG - 2022-07-07 09:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 09:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 09:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:28:22 --> Total execution time: 0.0813
DEBUG - 2022-07-07 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:02 --> Total execution time: 0.0753
DEBUG - 2022-07-07 10:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:15 --> Total execution time: 0.0825
DEBUG - 2022-07-07 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:19 --> Total execution time: 0.0577
DEBUG - 2022-07-07 10:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:33 --> Total execution time: 0.0642
DEBUG - 2022-07-07 10:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:36 --> Total execution time: 0.0549
DEBUG - 2022-07-07 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:47 --> Total execution time: 0.0624
DEBUG - 2022-07-07 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:30:52 --> Total execution time: 0.0497
DEBUG - 2022-07-07 10:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:32:25 --> Total execution time: 0.0714
DEBUG - 2022-07-07 10:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:32:36 --> Total execution time: 0.0695
DEBUG - 2022-07-07 10:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:32:48 --> Total execution time: 0.0570
DEBUG - 2022-07-07 10:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:32:55 --> Total execution time: 0.0536
DEBUG - 2022-07-07 10:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:32:56 --> Total execution time: 0.0529
DEBUG - 2022-07-07 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:33:05 --> Total execution time: 0.0781
DEBUG - 2022-07-07 10:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:33:11 --> Total execution time: 0.1349
DEBUG - 2022-07-07 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:33:38 --> Total execution time: 0.0492
DEBUG - 2022-07-07 10:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:33:39 --> Total execution time: 0.0585
DEBUG - 2022-07-07 10:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:03:41 --> Total execution time: 0.0525
DEBUG - 2022-07-07 10:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:33:50 --> Total execution time: 0.0584
DEBUG - 2022-07-07 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:34:01 --> Total execution time: 0.0820
DEBUG - 2022-07-07 10:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:34:16 --> Total execution time: 0.0556
DEBUG - 2022-07-07 10:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:04:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:34:29 --> Total execution time: 0.0401
DEBUG - 2022-07-07 10:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:34:34 --> Total execution time: 0.0585
DEBUG - 2022-07-07 10:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:34:34 --> Total execution time: 0.0514
DEBUG - 2022-07-07 10:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:34:35 --> Total execution time: 0.0562
DEBUG - 2022-07-07 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:36:49 --> Total execution time: 0.0673
DEBUG - 2022-07-07 10:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:36:52 --> Total execution time: 0.0543
DEBUG - 2022-07-07 10:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:36:58 --> Total execution time: 0.0609
DEBUG - 2022-07-07 10:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:37:06 --> Total execution time: 0.0998
DEBUG - 2022-07-07 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:42:46 --> Total execution time: 0.1562
DEBUG - 2022-07-07 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:15:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:45:58 --> Total execution time: 0.0953
DEBUG - 2022-07-07 10:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:02 --> Total execution time: 0.0425
DEBUG - 2022-07-07 10:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:21 --> Total execution time: 0.0672
DEBUG - 2022-07-07 10:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:22 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:22 --> Total execution time: 0.0402
DEBUG - 2022-07-07 10:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:27 --> Total execution time: 0.0735
DEBUG - 2022-07-07 10:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:30 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:46:30 --> Total execution time: 0.1211
DEBUG - 2022-07-07 10:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:31 --> Total execution time: 0.0591
DEBUG - 2022-07-07 10:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:33 --> Total execution time: 0.0919
DEBUG - 2022-07-07 10:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:36 --> Total execution time: 0.0610
DEBUG - 2022-07-07 10:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:46:41 --> Total execution time: 0.0576
DEBUG - 2022-07-07 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:17:37 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:47:37 --> Total execution time: 0.0541
DEBUG - 2022-07-07 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:47:40 --> Total execution time: 0.0653
DEBUG - 2022-07-07 10:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:18:35 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:48:35 --> Total execution time: 0.0397
DEBUG - 2022-07-07 10:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:19:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:49:16 --> Total execution time: 0.1040
DEBUG - 2022-07-07 10:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:19:48 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:49:48 --> Total execution time: 0.0459
DEBUG - 2022-07-07 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:51:35 --> Total execution time: 0.0345
DEBUG - 2022-07-07 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:22:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:52:21 --> Total execution time: 0.0469
DEBUG - 2022-07-07 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:52:24 --> Total execution time: 0.0487
DEBUG - 2022-07-07 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:52:37 --> Total execution time: 0.0521
DEBUG - 2022-07-07 10:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:52:54 --> Total execution time: 0.0481
DEBUG - 2022-07-07 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:03 --> Total execution time: 0.0520
DEBUG - 2022-07-07 10:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:18 --> Total execution time: 0.0586
DEBUG - 2022-07-07 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:24 --> Total execution time: 0.0590
DEBUG - 2022-07-07 10:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:26 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:26 --> Total execution time: 0.0481
DEBUG - 2022-07-07 10:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:26 --> Total execution time: 0.0586
DEBUG - 2022-07-07 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:29 --> Total execution time: 0.0350
DEBUG - 2022-07-07 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:53:50 --> Total execution time: 0.0587
DEBUG - 2022-07-07 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:05 --> Total execution time: 0.0548
DEBUG - 2022-07-07 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:13 --> Total execution time: 0.0443
DEBUG - 2022-07-07 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:20 --> Total execution time: 0.0530
DEBUG - 2022-07-07 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:21 --> Total execution time: 0.0619
DEBUG - 2022-07-07 10:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:24 --> Total execution time: 0.0363
DEBUG - 2022-07-07 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:31 --> Total execution time: 0.0614
DEBUG - 2022-07-07 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:36 --> Total execution time: 0.0578
DEBUG - 2022-07-07 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:41 --> Total execution time: 0.0523
DEBUG - 2022-07-07 10:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:45 --> Total execution time: 0.0752
DEBUG - 2022-07-07 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:55 --> Total execution time: 0.0517
DEBUG - 2022-07-07 10:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:59 --> Total execution time: 0.0517
DEBUG - 2022-07-07 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:24:59 --> Total execution time: 0.0594
DEBUG - 2022-07-07 10:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:25:02 --> Total execution time: 0.0584
DEBUG - 2022-07-07 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:25:05 --> Total execution time: 0.0480
DEBUG - 2022-07-07 10:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:25:07 --> Total execution time: 0.0484
DEBUG - 2022-07-07 10:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:55:15 --> Total execution time: 0.0580
DEBUG - 2022-07-07 10:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:55:26 --> Total execution time: 0.0815
DEBUG - 2022-07-07 10:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:26:18 --> Total execution time: 0.0606
DEBUG - 2022-07-07 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:26:24 --> Total execution time: 0.1125
DEBUG - 2022-07-07 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:28 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:56:28 --> Total execution time: 0.0359
DEBUG - 2022-07-07 10:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:56:29 --> Total execution time: 0.0545
DEBUG - 2022-07-07 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:56:58 --> Total execution time: 0.0406
DEBUG - 2022-07-07 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:26:58 --> Total execution time: 0.0537
DEBUG - 2022-07-07 10:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:26:58 --> Total execution time: 0.1050
DEBUG - 2022-07-07 10:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:57:18 --> Total execution time: 0.1149
DEBUG - 2022-07-07 10:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:57:26 --> Total execution time: 0.0876
DEBUG - 2022-07-07 10:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:57:27 --> Total execution time: 0.0343
DEBUG - 2022-07-07 10:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:57:37 --> Total execution time: 0.0526
DEBUG - 2022-07-07 10:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:57:40 --> Total execution time: 0.0496
DEBUG - 2022-07-07 10:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:57:53 --> Total execution time: 0.0555
DEBUG - 2022-07-07 10:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:03 --> Total execution time: 0.0483
DEBUG - 2022-07-07 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:15 --> Total execution time: 0.0968
DEBUG - 2022-07-07 10:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:20 --> Total execution time: 0.1198
DEBUG - 2022-07-07 10:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:23 --> Total execution time: 0.1488
DEBUG - 2022-07-07 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:24 --> Total execution time: 0.1116
DEBUG - 2022-07-07 10:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:28 --> Total execution time: 0.0518
DEBUG - 2022-07-07 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:31 --> Total execution time: 0.0489
DEBUG - 2022-07-07 10:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:37 --> Total execution time: 0.0963
DEBUG - 2022-07-07 10:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:38 --> Total execution time: 0.0549
DEBUG - 2022-07-07 10:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:45 --> Total execution time: 0.0608
DEBUG - 2022-07-07 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:50 --> Total execution time: 0.0576
DEBUG - 2022-07-07 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:58:55 --> Total execution time: 0.0531
DEBUG - 2022-07-07 10:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:59:11 --> Total execution time: 0.0343
DEBUG - 2022-07-07 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:59:24 --> Total execution time: 0.0484
DEBUG - 2022-07-07 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:59:34 --> Total execution time: 0.0459
DEBUG - 2022-07-07 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:00 --> Total execution time: 0.0657
DEBUG - 2022-07-07 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:20 --> Total execution time: 0.0674
DEBUG - 2022-07-07 10:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:41 --> Total execution time: 0.0758
DEBUG - 2022-07-07 10:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:44 --> Total execution time: 0.1224
DEBUG - 2022-07-07 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:45 --> Total execution time: 0.0513
DEBUG - 2022-07-07 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:46 --> Total execution time: 0.0522
DEBUG - 2022-07-07 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:46 --> Total execution time: 0.0646
DEBUG - 2022-07-07 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:46 --> Total execution time: 0.0688
DEBUG - 2022-07-07 10:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:56 --> Total execution time: 0.0701
DEBUG - 2022-07-07 10:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:00:57 --> Total execution time: 0.0526
DEBUG - 2022-07-07 10:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:06 --> Total execution time: 0.0557
DEBUG - 2022-07-07 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:08 --> Total execution time: 0.0469
DEBUG - 2022-07-07 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:18 --> Total execution time: 0.0617
DEBUG - 2022-07-07 10:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:19 --> Total execution time: 0.0766
DEBUG - 2022-07-07 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:21 --> Total execution time: 0.0530
DEBUG - 2022-07-07 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:22 --> Total execution time: 0.0545
DEBUG - 2022-07-07 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:01:30 --> Total execution time: 0.0637
DEBUG - 2022-07-07 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:02:06 --> Total execution time: 0.0522
DEBUG - 2022-07-07 10:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:02:06 --> Total execution time: 0.1114
DEBUG - 2022-07-07 10:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:02:14 --> Total execution time: 0.1421
DEBUG - 2022-07-07 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:02:20 --> Total execution time: 0.0824
DEBUG - 2022-07-07 10:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:02:25 --> Total execution time: 0.0632
DEBUG - 2022-07-07 10:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:32:51 --> Total execution time: 0.0514
DEBUG - 2022-07-07 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:32:57 --> Total execution time: 0.0701
DEBUG - 2022-07-07 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:04:26 --> Total execution time: 0.0854
DEBUG - 2022-07-07 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:04:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:04:59 --> Total execution time: 0.0869
DEBUG - 2022-07-07 10:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:03 --> Total execution time: 0.1231
DEBUG - 2022-07-07 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:10 --> Total execution time: 0.1107
DEBUG - 2022-07-07 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:19 --> Total execution time: 0.0536
DEBUG - 2022-07-07 10:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:22 --> Total execution time: 0.0548
DEBUG - 2022-07-07 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:28 --> Total execution time: 0.0798
DEBUG - 2022-07-07 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:30 --> Total execution time: 0.0539
DEBUG - 2022-07-07 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:33 --> Total execution time: 0.0619
DEBUG - 2022-07-07 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:34 --> Total execution time: 0.0590
DEBUG - 2022-07-07 10:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:43 --> Total execution time: 0.0391
DEBUG - 2022-07-07 10:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:45 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:45 --> Total execution time: 0.0562
DEBUG - 2022-07-07 10:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:49 --> Total execution time: 0.0934
DEBUG - 2022-07-07 10:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:05:52 --> Total execution time: 0.0330
DEBUG - 2022-07-07 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:03 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:03 --> Total execution time: 0.1282
DEBUG - 2022-07-07 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:08 --> Total execution time: 0.0557
DEBUG - 2022-07-07 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:10 --> Total execution time: 0.0547
DEBUG - 2022-07-07 10:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:14 --> Total execution time: 0.0614
DEBUG - 2022-07-07 10:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:14 --> Total execution time: 0.0504
DEBUG - 2022-07-07 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:21 --> Total execution time: 0.0499
DEBUG - 2022-07-07 10:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:10 --> Total execution time: 0.1285
DEBUG - 2022-07-07 10:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:19 --> Total execution time: 0.0542
DEBUG - 2022-07-07 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:22 --> Total execution time: 0.0581
DEBUG - 2022-07-07 10:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:32 --> Total execution time: 0.0523
DEBUG - 2022-07-07 10:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:35 --> Total execution time: 0.0502
DEBUG - 2022-07-07 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:51 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:51 --> Total execution time: 0.0588
DEBUG - 2022-07-07 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:54 --> Total execution time: 0.0614
DEBUG - 2022-07-07 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:07:57 --> Total execution time: 0.0542
DEBUG - 2022-07-07 10:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:08:00 --> Total execution time: 0.0581
DEBUG - 2022-07-07 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:08:04 --> Total execution time: 0.0627
DEBUG - 2022-07-07 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:08:22 --> Total execution time: 0.0768
DEBUG - 2022-07-07 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:08:31 --> Total execution time: 0.0375
DEBUG - 2022-07-07 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:08:32 --> Total execution time: 0.0514
DEBUG - 2022-07-07 10:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:38:42 --> Total execution time: 0.0493
DEBUG - 2022-07-07 10:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:38:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:08:43 --> Total execution time: 0.0515
DEBUG - 2022-07-07 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:09:02 --> Total execution time: 0.0591
DEBUG - 2022-07-07 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:09:28 --> Total execution time: 0.0552
DEBUG - 2022-07-07 10:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:09:31 --> Total execution time: 0.0709
DEBUG - 2022-07-07 10:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:09:39 --> Total execution time: 0.0610
DEBUG - 2022-07-07 10:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:09:46 --> Total execution time: 0.0805
DEBUG - 2022-07-07 10:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:40:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:10:00 --> Total execution time: 0.0369
DEBUG - 2022-07-07 10:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:10:36 --> Total execution time: 0.0685
DEBUG - 2022-07-07 10:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:10:36 --> Total execution time: 0.1270
DEBUG - 2022-07-07 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:10:37 --> Total execution time: 0.0678
DEBUG - 2022-07-07 10:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:11:20 --> Total execution time: 0.0683
DEBUG - 2022-07-07 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:11:28 --> Total execution time: 0.0569
DEBUG - 2022-07-07 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:11:53 --> Total execution time: 0.0569
DEBUG - 2022-07-07 10:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:12:14 --> Total execution time: 0.0543
DEBUG - 2022-07-07 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:12:16 --> Total execution time: 0.0547
DEBUG - 2022-07-07 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:12:25 --> Total execution time: 0.0494
DEBUG - 2022-07-07 10:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:12:35 --> Total execution time: 0.0538
DEBUG - 2022-07-07 10:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:12:47 --> Total execution time: 0.0536
DEBUG - 2022-07-07 10:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:42:53 --> Total execution time: 0.0501
DEBUG - 2022-07-07 10:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:12:54 --> Total execution time: 0.0478
DEBUG - 2022-07-07 10:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:13:08 --> Total execution time: 0.0619
DEBUG - 2022-07-07 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:13:23 --> Total execution time: 0.0622
DEBUG - 2022-07-07 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:13:37 --> Total execution time: 0.0551
DEBUG - 2022-07-07 10:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:13:45 --> Total execution time: 0.0491
DEBUG - 2022-07-07 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:06 --> Total execution time: 0.1382
DEBUG - 2022-07-07 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:07 --> Total execution time: 0.0575
DEBUG - 2022-07-07 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:14 --> Total execution time: 0.0569
DEBUG - 2022-07-07 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:17 --> Total execution time: 0.0557
DEBUG - 2022-07-07 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:22 --> Total execution time: 0.0529
DEBUG - 2022-07-07 10:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:28 --> Total execution time: 0.0745
DEBUG - 2022-07-07 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:41 --> Total execution time: 0.0895
DEBUG - 2022-07-07 10:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:46 --> Total execution time: 0.0516
DEBUG - 2022-07-07 10:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:55 --> Total execution time: 0.0638
DEBUG - 2022-07-07 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:16:07 --> Total execution time: 0.0740
DEBUG - 2022-07-07 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:16:13 --> Total execution time: 0.0713
DEBUG - 2022-07-07 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:16:39 --> Total execution time: 0.0975
DEBUG - 2022-07-07 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:16:59 --> Total execution time: 0.0614
DEBUG - 2022-07-07 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:17:10 --> Total execution time: 0.1264
DEBUG - 2022-07-07 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:17:15 --> Total execution time: 0.0698
DEBUG - 2022-07-07 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:17:27 --> Total execution time: 0.0494
DEBUG - 2022-07-07 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:17:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:17:37 --> Total execution time: 0.0577
DEBUG - 2022-07-07 10:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:18:12 --> Total execution time: 0.0755
DEBUG - 2022-07-07 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:18:17 --> Total execution time: 0.0548
DEBUG - 2022-07-07 10:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:19:03 --> Total execution time: 0.0512
DEBUG - 2022-07-07 10:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:19:10 --> Total execution time: 0.0662
DEBUG - 2022-07-07 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:19:54 --> Total execution time: 0.0553
DEBUG - 2022-07-07 10:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:20:07 --> Total execution time: 0.0567
DEBUG - 2022-07-07 10:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:20:13 --> Total execution time: 0.0787
DEBUG - 2022-07-07 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:20:20 --> Total execution time: 0.1434
DEBUG - 2022-07-07 10:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:21:07 --> Total execution time: 0.0785
DEBUG - 2022-07-07 10:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:21:09 --> Total execution time: 0.0514
DEBUG - 2022-07-07 10:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:21:11 --> Total execution time: 0.0793
DEBUG - 2022-07-07 10:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:51:49 --> Total execution time: 0.0570
DEBUG - 2022-07-07 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:21:56 --> Total execution time: 0.0545
DEBUG - 2022-07-07 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:22:00 --> Total execution time: 0.0612
DEBUG - 2022-07-07 10:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:52:17 --> Total execution time: 0.1052
DEBUG - 2022-07-07 10:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:22:55 --> Total execution time: 0.1268
DEBUG - 2022-07-07 10:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:23:37 --> Total execution time: 0.0427
DEBUG - 2022-07-07 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:37 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:23:37 --> Total execution time: 0.0397
DEBUG - 2022-07-07 10:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:23:48 --> Total execution time: 0.0753
DEBUG - 2022-07-07 10:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:23:49 --> Total execution time: 0.0623
DEBUG - 2022-07-07 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:23:54 --> Total execution time: 0.0686
DEBUG - 2022-07-07 10:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:24:07 --> Total execution time: 0.0760
DEBUG - 2022-07-07 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:24:32 --> Total execution time: 0.0488
DEBUG - 2022-07-07 10:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:24:47 --> Total execution time: 0.0554
DEBUG - 2022-07-07 10:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:25:08 --> Total execution time: 0.0573
DEBUG - 2022-07-07 10:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:25:08 --> Total execution time: 0.0644
DEBUG - 2022-07-07 10:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:25:31 --> Total execution time: 0.0675
DEBUG - 2022-07-07 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:25:37 --> Total execution time: 0.0705
DEBUG - 2022-07-07 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:26:03 --> Total execution time: 0.0558
DEBUG - 2022-07-07 10:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:26:03 --> Total execution time: 0.1230
DEBUG - 2022-07-07 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:26:06 --> Total execution time: 0.0630
DEBUG - 2022-07-07 10:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:26:15 --> Total execution time: 0.0983
DEBUG - 2022-07-07 10:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:26:35 --> Total execution time: 0.0554
DEBUG - 2022-07-07 10:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:26:35 --> Total execution time: 0.0842
DEBUG - 2022-07-07 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:10 --> Total execution time: 0.0560
DEBUG - 2022-07-07 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:14 --> Total execution time: 0.0533
DEBUG - 2022-07-07 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:14 --> Total execution time: 0.0764
DEBUG - 2022-07-07 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:15 --> Total execution time: 0.0718
DEBUG - 2022-07-07 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:16 --> Total execution time: 0.0562
DEBUG - 2022-07-07 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:21 --> Total execution time: 0.0697
DEBUG - 2022-07-07 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:34 --> Total execution time: 0.0365
DEBUG - 2022-07-07 10:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:48 --> Total execution time: 0.0548
DEBUG - 2022-07-07 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:27:58 --> Total execution time: 0.0543
DEBUG - 2022-07-07 10:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:28:07 --> Total execution time: 0.0557
DEBUG - 2022-07-07 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:28:10 --> Total execution time: 0.0840
DEBUG - 2022-07-07 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:28:31 --> Total execution time: 0.0549
DEBUG - 2022-07-07 10:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:58:40 --> No URI present. Default controller set.
DEBUG - 2022-07-07 10:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:28:40 --> Total execution time: 0.1628
DEBUG - 2022-07-07 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:28:53 --> Total execution time: 0.0816
DEBUG - 2022-07-07 10:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:29:01 --> Total execution time: 0.0684
DEBUG - 2022-07-07 10:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:29:05 --> Total execution time: 0.0640
DEBUG - 2022-07-07 10:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:29:09 --> Total execution time: 0.1547
DEBUG - 2022-07-07 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:29:13 --> Total execution time: 0.1294
DEBUG - 2022-07-07 10:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:29:30 --> Total execution time: 0.0597
DEBUG - 2022-07-07 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 10:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:29:32 --> Total execution time: 0.0711
DEBUG - 2022-07-07 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:30:02 --> Total execution time: 0.0803
DEBUG - 2022-07-07 11:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:30:34 --> Total execution time: 0.1016
DEBUG - 2022-07-07 11:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:30:46 --> Total execution time: 0.1404
DEBUG - 2022-07-07 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:31:00 --> Total execution time: 0.0514
DEBUG - 2022-07-07 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:31:22 --> Total execution time: 0.1285
DEBUG - 2022-07-07 11:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:02:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:32:20 --> Total execution time: 0.1919
DEBUG - 2022-07-07 11:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:02:21 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-07-07 11:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:02:22 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-07-07 11:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:02:22 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-07-07 11:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:02:22 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-07 11:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:33:10 --> Total execution time: 0.0720
DEBUG - 2022-07-07 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:33:20 --> Total execution time: 0.0510
DEBUG - 2022-07-07 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:35:01 --> Total execution time: 0.0709
DEBUG - 2022-07-07 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:06:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:36:11 --> Total execution time: 0.0457
DEBUG - 2022-07-07 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:07:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:37:07 --> Total execution time: 0.0475
DEBUG - 2022-07-07 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:07:16 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 11:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:07:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:37:27 --> Total execution time: 0.0380
DEBUG - 2022-07-07 11:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:08:07 --> Total execution time: 0.0519
DEBUG - 2022-07-07 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:08:56 --> Total execution time: 0.0521
DEBUG - 2022-07-07 11:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:08:56 --> Total execution time: 0.1240
DEBUG - 2022-07-07 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:10:23 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 11:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:40:56 --> Total execution time: 0.0381
DEBUG - 2022-07-07 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:41:09 --> Total execution time: 0.0774
DEBUG - 2022-07-07 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:11:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:41:32 --> Total execution time: 0.0379
DEBUG - 2022-07-07 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:11:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:41:35 --> Total execution time: 1.9683
DEBUG - 2022-07-07 11:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:41:59 --> Total execution time: 0.0657
DEBUG - 2022-07-07 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:12:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 11:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:42:25 --> Total execution time: 0.1284
DEBUG - 2022-07-07 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:12:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:43:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:43:36 --> Total execution time: 0.0620
DEBUG - 2022-07-07 11:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:43:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 21:43:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 21:43:41 --> Total execution time: 0.1876
DEBUG - 2022-07-07 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:14:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:44:42 --> Total execution time: 0.0355
DEBUG - 2022-07-07 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:44:56 --> Total execution time: 0.0556
DEBUG - 2022-07-07 11:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:14:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:44:58 --> Total execution time: 0.0565
DEBUG - 2022-07-07 11:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:06 --> Total execution time: 0.0868
DEBUG - 2022-07-07 11:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:17 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:17 --> Total execution time: 0.0468
DEBUG - 2022-07-07 11:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:25 --> Total execution time: 0.0426
DEBUG - 2022-07-07 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:38 --> Total execution time: 0.0429
DEBUG - 2022-07-07 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:48 --> Total execution time: 0.0553
DEBUG - 2022-07-07 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:16:48 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:48 --> Total execution time: 0.0499
DEBUG - 2022-07-07 11:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:47:17 --> Total execution time: 0.0486
DEBUG - 2022-07-07 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:47:27 --> Total execution time: 0.0740
DEBUG - 2022-07-07 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:17:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:47:34 --> Total execution time: 0.0299
DEBUG - 2022-07-07 11:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:48:35 --> Total execution time: 0.2115
DEBUG - 2022-07-07 11:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:49:02 --> Total execution time: 0.2382
DEBUG - 2022-07-07 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:50:16 --> Total execution time: 0.0628
DEBUG - 2022-07-07 11:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:50:42 --> Total execution time: 0.0526
DEBUG - 2022-07-07 11:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:50:49 --> Total execution time: 0.1270
DEBUG - 2022-07-07 11:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:50:55 --> Total execution time: 0.0705
DEBUG - 2022-07-07 11:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:51:11 --> Total execution time: 0.0553
DEBUG - 2022-07-07 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:51:35 --> Total execution time: 0.0743
DEBUG - 2022-07-07 11:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:52:09 --> Total execution time: 0.0546
DEBUG - 2022-07-07 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:52:44 --> Total execution time: 0.0869
DEBUG - 2022-07-07 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:23:18 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:18 --> Total execution time: 0.0436
DEBUG - 2022-07-07 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:39 --> Total execution time: 0.0534
DEBUG - 2022-07-07 11:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:57 --> Total execution time: 0.0929
DEBUG - 2022-07-07 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:24:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:54:43 --> Total execution time: 0.0354
DEBUG - 2022-07-07 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:24:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:54:52 --> Total execution time: 0.0973
DEBUG - 2022-07-07 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:25:53 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:55:53 --> Total execution time: 0.1247
DEBUG - 2022-07-07 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:25:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:55:58 --> Total execution time: 0.0358
DEBUG - 2022-07-07 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:56:43 --> Total execution time: 0.0540
DEBUG - 2022-07-07 11:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:57:25 --> Total execution time: 0.0570
DEBUG - 2022-07-07 11:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:57:57 --> Total execution time: 0.0813
DEBUG - 2022-07-07 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:10 --> Total execution time: 0.0568
DEBUG - 2022-07-07 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:27 --> Total execution time: 0.0515
DEBUG - 2022-07-07 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:46 --> Total execution time: 0.0854
DEBUG - 2022-07-07 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:09 --> Total execution time: 0.0379
DEBUG - 2022-07-07 11:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:10 --> Total execution time: 0.0495
DEBUG - 2022-07-07 11:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:20 --> Total execution time: 0.0519
DEBUG - 2022-07-07 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:26 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:26 --> Total execution time: 0.0746
DEBUG - 2022-07-07 21:59:26 --> Total execution time: 0.1451
DEBUG - 2022-07-07 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:27 --> Total execution time: 0.0585
DEBUG - 2022-07-07 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:27 --> Total execution time: 0.1057
DEBUG - 2022-07-07 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:27 --> Total execution time: 0.0399
DEBUG - 2022-07-07 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:29 --> Total execution time: 0.0585
DEBUG - 2022-07-07 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:40 --> Total execution time: 0.0492
DEBUG - 2022-07-07 11:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:44 --> Total execution time: 0.0487
DEBUG - 2022-07-07 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:46 --> Total execution time: 0.0528
DEBUG - 2022-07-07 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:51 --> Total execution time: 0.0681
DEBUG - 2022-07-07 11:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:51 --> Total execution time: 0.0591
DEBUG - 2022-07-07 11:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:30:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:31 --> Total execution time: 0.0357
DEBUG - 2022-07-07 11:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:43 --> Total execution time: 0.0595
DEBUG - 2022-07-07 11:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:49 --> Total execution time: 0.0643
DEBUG - 2022-07-07 11:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:53 --> Total execution time: 0.0512
DEBUG - 2022-07-07 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:54 --> Total execution time: 0.0571
DEBUG - 2022-07-07 11:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:55 --> Total execution time: 0.0510
DEBUG - 2022-07-07 11:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:03 --> Total execution time: 0.0489
DEBUG - 2022-07-07 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:31:09 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:09 --> Total execution time: 0.0558
DEBUG - 2022-07-07 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:11 --> Total execution time: 0.0556
DEBUG - 2022-07-07 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:31:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:42 --> Total execution time: 0.1295
DEBUG - 2022-07-07 11:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:47 --> Total execution time: 0.0507
DEBUG - 2022-07-07 11:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:02:21 --> Total execution time: 0.1112
DEBUG - 2022-07-07 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:02:41 --> Total execution time: 0.0531
DEBUG - 2022-07-07 11:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:02:51 --> Total execution time: 0.0482
DEBUG - 2022-07-07 11:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:09 --> Total execution time: 0.0484
DEBUG - 2022-07-07 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:19 --> Total execution time: 0.0505
DEBUG - 2022-07-07 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:22 --> Total execution time: 0.0563
DEBUG - 2022-07-07 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:31 --> Total execution time: 0.0498
DEBUG - 2022-07-07 11:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:32 --> Total execution time: 0.0601
DEBUG - 2022-07-07 11:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:41 --> Total execution time: 0.0508
DEBUG - 2022-07-07 11:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:58 --> Total execution time: 0.0532
DEBUG - 2022-07-07 11:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:02 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:02 --> Total execution time: 0.0431
DEBUG - 2022-07-07 11:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:23 --> Total execution time: 0.0653
DEBUG - 2022-07-07 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:32 --> Total execution time: 0.0495
DEBUG - 2022-07-07 11:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:34 --> Total execution time: 0.0542
DEBUG - 2022-07-07 11:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:38 --> Total execution time: 0.0603
DEBUG - 2022-07-07 11:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:40 --> Total execution time: 0.0557
DEBUG - 2022-07-07 11:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:45 --> Total execution time: 0.0546
DEBUG - 2022-07-07 11:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:45 --> Total execution time: 0.0561
DEBUG - 2022-07-07 11:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:47 --> Total execution time: 0.0794
DEBUG - 2022-07-07 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:52 --> Total execution time: 0.0607
DEBUG - 2022-07-07 11:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 11:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:53 --> Total execution time: 0.0610
DEBUG - 2022-07-07 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:57 --> Total execution time: 0.0365
DEBUG - 2022-07-07 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:58 --> Total execution time: 0.0513
DEBUG - 2022-07-07 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:34:58 --> Total execution time: 0.0952
DEBUG - 2022-07-07 11:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:35:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:54 --> Total execution time: 1.8702
DEBUG - 2022-07-07 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:35:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 11:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:45 --> Total execution time: 0.1241
DEBUG - 2022-07-07 11:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:49 --> Total execution time: 0.0563
DEBUG - 2022-07-07 11:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 11:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:50 --> Total execution time: 0.0562
DEBUG - 2022-07-07 11:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:14 --> Total execution time: 0.1274
DEBUG - 2022-07-07 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:38:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:25 --> Total execution time: 0.0352
DEBUG - 2022-07-07 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:27 --> Total execution time: 0.0570
DEBUG - 2022-07-07 11:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:45 --> Total execution time: 0.0497
DEBUG - 2022-07-07 11:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:52 --> Total execution time: 0.0544
DEBUG - 2022-07-07 11:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:09:00 --> Total execution time: 0.0451
DEBUG - 2022-07-07 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:09:16 --> Total execution time: 0.0504
DEBUG - 2022-07-07 11:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:09:25 --> Total execution time: 0.0548
DEBUG - 2022-07-07 11:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:09:48 --> Total execution time: 0.0746
DEBUG - 2022-07-07 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:40:05 --> Total execution time: 0.0505
DEBUG - 2022-07-07 11:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:10 --> Total execution time: 0.0801
DEBUG - 2022-07-07 11:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:11 --> Total execution time: 0.0738
DEBUG - 2022-07-07 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:13 --> Total execution time: 0.0553
DEBUG - 2022-07-07 11:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:17 --> Total execution time: 0.0573
DEBUG - 2022-07-07 11:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:21 --> Total execution time: 0.0762
DEBUG - 2022-07-07 11:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 11:41:16 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 11:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:11:50 --> Total execution time: 0.1797
DEBUG - 2022-07-07 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:11:57 --> Total execution time: 0.0568
DEBUG - 2022-07-07 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:45 --> Total execution time: 0.0521
DEBUG - 2022-07-07 11:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:51 --> Total execution time: 0.0549
DEBUG - 2022-07-07 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:57 --> Total execution time: 0.0493
DEBUG - 2022-07-07 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:43:58 --> Total execution time: 0.0504
DEBUG - 2022-07-07 11:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:06 --> Total execution time: 0.0576
DEBUG - 2022-07-07 11:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:09 --> Total execution time: 0.0587
DEBUG - 2022-07-07 11:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:18 --> Total execution time: 0.0486
DEBUG - 2022-07-07 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:22 --> Total execution time: 0.0604
DEBUG - 2022-07-07 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:24 --> Total execution time: 0.0534
DEBUG - 2022-07-07 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:26 --> Total execution time: 0.0479
DEBUG - 2022-07-07 11:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:35 --> Total execution time: 0.0502
DEBUG - 2022-07-07 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:38 --> Total execution time: 0.0489
DEBUG - 2022-07-07 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:38 --> Total execution time: 0.0493
DEBUG - 2022-07-07 11:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:44:40 --> Total execution time: 0.0515
DEBUG - 2022-07-07 11:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:41 --> Total execution time: 0.0602
DEBUG - 2022-07-07 11:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:41 --> Total execution time: 0.0551
DEBUG - 2022-07-07 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:42 --> Total execution time: 0.0518
DEBUG - 2022-07-07 11:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:46 --> Total execution time: 0.0533
DEBUG - 2022-07-07 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:58 --> Total execution time: 0.0607
DEBUG - 2022-07-07 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:15:06 --> Total execution time: 0.0775
DEBUG - 2022-07-07 11:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:15:10 --> Total execution time: 0.0678
DEBUG - 2022-07-07 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:15:31 --> Total execution time: 0.0495
DEBUG - 2022-07-07 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:15:41 --> Total execution time: 0.0549
DEBUG - 2022-07-07 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:15:52 --> Total execution time: 0.0565
DEBUG - 2022-07-07 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:16:01 --> Total execution time: 0.0678
DEBUG - 2022-07-07 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:16:05 --> Total execution time: 0.0538
DEBUG - 2022-07-07 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:17:04 --> Total execution time: 0.0514
DEBUG - 2022-07-07 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:49:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:42 --> Total execution time: 0.0411
DEBUG - 2022-07-07 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:49:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:43 --> Total execution time: 0.0348
DEBUG - 2022-07-07 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:49:56 --> Total execution time: 0.0492
DEBUG - 2022-07-07 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:49:57 --> Total execution time: 0.0536
DEBUG - 2022-07-07 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:49:57 --> Total execution time: 0.1045
DEBUG - 2022-07-07 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:20:11 --> Total execution time: 0.0484
DEBUG - 2022-07-07 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:13 --> Total execution time: 0.0496
DEBUG - 2022-07-07 11:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:24 --> Total execution time: 0.0498
DEBUG - 2022-07-07 11:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:33 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:20:33 --> Total execution time: 0.0508
DEBUG - 2022-07-07 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:20:39 --> Total execution time: 0.0521
DEBUG - 2022-07-07 11:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:01 --> Total execution time: 0.0532
DEBUG - 2022-07-07 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:02 --> Total execution time: 0.0798
DEBUG - 2022-07-07 11:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:02 --> Total execution time: 0.1465
DEBUG - 2022-07-07 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:10 --> Total execution time: 0.0625
DEBUG - 2022-07-07 11:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:16 --> Total execution time: 0.0509
DEBUG - 2022-07-07 11:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:20 --> Total execution time: 0.0556
DEBUG - 2022-07-07 11:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:42 --> Total execution time: 0.0547
DEBUG - 2022-07-07 11:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:43 --> Total execution time: 0.0526
DEBUG - 2022-07-07 11:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:43 --> Total execution time: 0.0823
DEBUG - 2022-07-07 11:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:43 --> Total execution time: 0.0571
DEBUG - 2022-07-07 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:46 --> Total execution time: 0.0537
DEBUG - 2022-07-07 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:47 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:47 --> Total execution time: 0.0599
DEBUG - 2022-07-07 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:47 --> Total execution time: 0.0617
DEBUG - 2022-07-07 11:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:51:47 --> Total execution time: 0.1010
DEBUG - 2022-07-07 11:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:22:29 --> Total execution time: 0.0499
DEBUG - 2022-07-07 11:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:52:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 11:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:22:57 --> Total execution time: 0.0373
DEBUG - 2022-07-07 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:23:02 --> Total execution time: 0.1337
DEBUG - 2022-07-07 11:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:23:08 --> Total execution time: 0.0768
DEBUG - 2022-07-07 11:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:23:45 --> Total execution time: 0.1193
DEBUG - 2022-07-07 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:24:04 --> Total execution time: 0.0523
DEBUG - 2022-07-07 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:24:22 --> Total execution time: 0.1419
DEBUG - 2022-07-07 11:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:24:27 --> Total execution time: 0.0520
DEBUG - 2022-07-07 11:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 11:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:24:44 --> Total execution time: 0.0522
DEBUG - 2022-07-07 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:24:48 --> Total execution time: 0.0549
DEBUG - 2022-07-07 11:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:25:34 --> Total execution time: 0.0525
DEBUG - 2022-07-07 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:25:42 --> Total execution time: 0.0532
DEBUG - 2022-07-07 11:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:28:24 --> Total execution time: 0.1380
DEBUG - 2022-07-07 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 11:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 11:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:28:30 --> Total execution time: 0.0708
DEBUG - 2022-07-07 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:30:04 --> Total execution time: 0.1212
DEBUG - 2022-07-07 12:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:01:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 12:01:33 --> 404 Page Not Found: Author/admin_user
DEBUG - 2022-07-07 12:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:32:32 --> Total execution time: 0.0615
DEBUG - 2022-07-07 12:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:04:22 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:34:22 --> Total execution time: 0.1445
DEBUG - 2022-07-07 12:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:06:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:36:11 --> Total execution time: 0.0356
DEBUG - 2022-07-07 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:37:13 --> Total execution time: 0.1433
DEBUG - 2022-07-07 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:37:21 --> Total execution time: 0.0883
DEBUG - 2022-07-07 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:37:24 --> Total execution time: 0.0540
DEBUG - 2022-07-07 12:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:37:56 --> Total execution time: 0.0768
DEBUG - 2022-07-07 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:37:57 --> Total execution time: 0.0975
DEBUG - 2022-07-07 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:02 --> Total execution time: 0.1558
DEBUG - 2022-07-07 12:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:13 --> Total execution time: 0.0926
DEBUG - 2022-07-07 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:22 --> Total execution time: 0.0541
DEBUG - 2022-07-07 12:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:34 --> Total execution time: 0.0619
DEBUG - 2022-07-07 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:37 --> Total execution time: 0.0701
DEBUG - 2022-07-07 12:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:45 --> Total execution time: 0.0576
DEBUG - 2022-07-07 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:48 --> Total execution time: 0.0669
DEBUG - 2022-07-07 12:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:55 --> Total execution time: 0.0573
DEBUG - 2022-07-07 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:38:58 --> Total execution time: 0.0549
DEBUG - 2022-07-07 12:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:05 --> Total execution time: 0.0586
DEBUG - 2022-07-07 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:08 --> Total execution time: 0.0736
DEBUG - 2022-07-07 12:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:16 --> Total execution time: 0.0758
DEBUG - 2022-07-07 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:20 --> Total execution time: 0.0687
DEBUG - 2022-07-07 12:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:36 --> Total execution time: 0.0719
DEBUG - 2022-07-07 12:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:38 --> Total execution time: 0.0533
DEBUG - 2022-07-07 12:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:41 --> Total execution time: 0.0692
DEBUG - 2022-07-07 12:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:43 --> Total execution time: 0.0522
DEBUG - 2022-07-07 12:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:46 --> Total execution time: 0.0528
DEBUG - 2022-07-07 12:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:48 --> Total execution time: 0.0539
DEBUG - 2022-07-07 12:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:39:51 --> Total execution time: 0.0526
DEBUG - 2022-07-07 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:10:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:40:01 --> Total execution time: 0.0404
DEBUG - 2022-07-07 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:24 --> Total execution time: 0.1114
DEBUG - 2022-07-07 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:24 --> Total execution time: 0.0426
DEBUG - 2022-07-07 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:13 --> Total execution time: 0.0341
DEBUG - 2022-07-07 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:16 --> Total execution time: 0.0557
DEBUG - 2022-07-07 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:28 --> Total execution time: 0.0542
DEBUG - 2022-07-07 12:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:38 --> Total execution time: 0.0580
DEBUG - 2022-07-07 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:47 --> Total execution time: 0.0763
DEBUG - 2022-07-07 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:43:24 --> Total execution time: 0.0660
DEBUG - 2022-07-07 12:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:44:10 --> Total execution time: 0.0526
DEBUG - 2022-07-07 12:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:44:17 --> Total execution time: 0.0547
DEBUG - 2022-07-07 12:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:44:47 --> Total execution time: 0.0530
DEBUG - 2022-07-07 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:44:51 --> Total execution time: 0.0742
DEBUG - 2022-07-07 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:45:04 --> Total execution time: 0.0873
DEBUG - 2022-07-07 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:15:12 --> Total execution time: 0.0570
DEBUG - 2022-07-07 12:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:15:47 --> Total execution time: 0.0529
DEBUG - 2022-07-07 12:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:15:53 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:45:53 --> Total execution time: 0.0353
DEBUG - 2022-07-07 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:00 --> Total execution time: 0.0503
DEBUG - 2022-07-07 12:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:07 --> Total execution time: 0.0585
DEBUG - 2022-07-07 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:09 --> Total execution time: 0.0613
DEBUG - 2022-07-07 12:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:22 --> Total execution time: 0.1211
DEBUG - 2022-07-07 12:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:24 --> Total execution time: 0.0688
DEBUG - 2022-07-07 12:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:33 --> Total execution time: 0.0587
DEBUG - 2022-07-07 12:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:34 --> Total execution time: 0.0634
DEBUG - 2022-07-07 12:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:35 --> Total execution time: 0.0499
DEBUG - 2022-07-07 12:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:36 --> Total execution time: 0.0543
DEBUG - 2022-07-07 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:40 --> Total execution time: 0.0490
DEBUG - 2022-07-07 12:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:44 --> Total execution time: 0.0517
DEBUG - 2022-07-07 12:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:16:45 --> Total execution time: 0.0661
DEBUG - 2022-07-07 12:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:46:47 --> Total execution time: 0.0524
DEBUG - 2022-07-07 12:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:47:29 --> Total execution time: 0.0554
DEBUG - 2022-07-07 12:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:31 --> Total execution time: 0.0513
DEBUG - 2022-07-07 12:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:39 --> Total execution time: 0.0488
DEBUG - 2022-07-07 12:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:40 --> Total execution time: 0.0619
DEBUG - 2022-07-07 12:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:47:48 --> Total execution time: 0.0727
DEBUG - 2022-07-07 12:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:47:49 --> Total execution time: 0.1535
DEBUG - 2022-07-07 12:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:49 --> Total execution time: 0.0786
DEBUG - 2022-07-07 12:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:55 --> Total execution time: 0.0558
DEBUG - 2022-07-07 12:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:47:56 --> Total execution time: 0.1309
DEBUG - 2022-07-07 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:17:58 --> Total execution time: 0.0552
DEBUG - 2022-07-07 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:47:59 --> Total execution time: 0.0549
DEBUG - 2022-07-07 12:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:48:00 --> Total execution time: 0.0574
DEBUG - 2022-07-07 12:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:48:18 --> Total execution time: 0.0675
DEBUG - 2022-07-07 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:48:24 --> Total execution time: 0.0611
DEBUG - 2022-07-07 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:48:36 --> Total execution time: 0.0569
DEBUG - 2022-07-07 12:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:48:39 --> Total execution time: 0.0546
DEBUG - 2022-07-07 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:48:43 --> Total execution time: 0.0595
DEBUG - 2022-07-07 12:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:19:14 --> Total execution time: 0.0544
DEBUG - 2022-07-07 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:19:14 --> Total execution time: 0.0498
DEBUG - 2022-07-07 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:18 --> Total execution time: 0.0565
DEBUG - 2022-07-07 12:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 12:19:19 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-07 12:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:23 --> Total execution time: 0.0778
DEBUG - 2022-07-07 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:33 --> Total execution time: 0.0908
DEBUG - 2022-07-07 12:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:38 --> Total execution time: 0.0692
DEBUG - 2022-07-07 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:45 --> Total execution time: 0.0748
DEBUG - 2022-07-07 12:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:46 --> Total execution time: 0.1226
DEBUG - 2022-07-07 12:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:53 --> Total execution time: 0.0574
DEBUG - 2022-07-07 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:00 --> Total execution time: 0.1268
DEBUG - 2022-07-07 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:05 --> Total execution time: 0.0545
DEBUG - 2022-07-07 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:53 --> Total execution time: 0.0954
DEBUG - 2022-07-07 12:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:37 --> Total execution time: 0.0785
DEBUG - 2022-07-07 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:43 --> Total execution time: 0.0809
DEBUG - 2022-07-07 12:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:52 --> Total execution time: 0.0879
DEBUG - 2022-07-07 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:58 --> Total execution time: 0.0648
DEBUG - 2022-07-07 12:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:52:11 --> Total execution time: 0.2133
DEBUG - 2022-07-07 12:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:52:44 --> Total execution time: 0.0794
DEBUG - 2022-07-07 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:52:57 --> Total execution time: 0.0830
DEBUG - 2022-07-07 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:06 --> Total execution time: 0.0581
DEBUG - 2022-07-07 12:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:20 --> Total execution time: 0.0556
DEBUG - 2022-07-07 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:27 --> Total execution time: 0.0540
DEBUG - 2022-07-07 12:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:31 --> Total execution time: 0.0568
DEBUG - 2022-07-07 12:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:38 --> Total execution time: 0.0856
DEBUG - 2022-07-07 12:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:38 --> Total execution time: 0.0625
DEBUG - 2022-07-07 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:39 --> Total execution time: 0.0879
DEBUG - 2022-07-07 12:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:44 --> Total execution time: 0.0607
DEBUG - 2022-07-07 12:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:49 --> Total execution time: 0.0596
DEBUG - 2022-07-07 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:23:56 --> Total execution time: 0.0498
DEBUG - 2022-07-07 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:54:27 --> Total execution time: 0.0545
DEBUG - 2022-07-07 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:25:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:19 --> Total execution time: 0.0363
DEBUG - 2022-07-07 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:25:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:20 --> Total execution time: 0.0398
DEBUG - 2022-07-07 12:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:24 --> Total execution time: 0.0333
DEBUG - 2022-07-07 12:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:33 --> Total execution time: 0.0570
DEBUG - 2022-07-07 12:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:41 --> Total execution time: 0.0817
DEBUG - 2022-07-07 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:28:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:58:11 --> Total execution time: 0.1349
DEBUG - 2022-07-07 12:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:28:24 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:58:24 --> Total execution time: 0.0514
DEBUG - 2022-07-07 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:29:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:59:25 --> Total execution time: 0.0458
DEBUG - 2022-07-07 12:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:29:35 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:59:35 --> Total execution time: 0.0448
DEBUG - 2022-07-07 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:59:45 --> Total execution time: 0.0602
DEBUG - 2022-07-07 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:59:54 --> Total execution time: 0.0552
DEBUG - 2022-07-07 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:00:18 --> Total execution time: 0.1071
DEBUG - 2022-07-07 12:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:00:46 --> Total execution time: 0.1574
DEBUG - 2022-07-07 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:00:53 --> Total execution time: 0.0580
DEBUG - 2022-07-07 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:00:53 --> Total execution time: 0.0619
DEBUG - 2022-07-07 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:00:59 --> Total execution time: 0.0595
DEBUG - 2022-07-07 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:01:09 --> Total execution time: 0.0530
DEBUG - 2022-07-07 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:31:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:01:20 --> Total execution time: 0.0375
DEBUG - 2022-07-07 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:01:24 --> Total execution time: 0.0936
DEBUG - 2022-07-07 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:01:51 --> Total execution time: 0.1181
DEBUG - 2022-07-07 12:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:03 --> Total execution time: 0.0567
DEBUG - 2022-07-07 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:18 --> Total execution time: 0.0491
DEBUG - 2022-07-07 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:19 --> Total execution time: 0.0543
DEBUG - 2022-07-07 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:19 --> Total execution time: 0.0504
DEBUG - 2022-07-07 12:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:20 --> Total execution time: 0.0558
DEBUG - 2022-07-07 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:21 --> Total execution time: 0.0521
DEBUG - 2022-07-07 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:21 --> Total execution time: 0.0571
DEBUG - 2022-07-07 12:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:43 --> Total execution time: 0.0536
DEBUG - 2022-07-07 12:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:46 --> Total execution time: 0.0519
DEBUG - 2022-07-07 12:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:47 --> Total execution time: 0.0479
DEBUG - 2022-07-07 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:49 --> Total execution time: 0.0535
DEBUG - 2022-07-07 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:32:49 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:49 --> Total execution time: 0.0507
DEBUG - 2022-07-07 12:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:04:07 --> Total execution time: 0.0719
DEBUG - 2022-07-07 12:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:04:19 --> Total execution time: 0.0578
DEBUG - 2022-07-07 12:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:04:25 --> Total execution time: 0.0712
DEBUG - 2022-07-07 12:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:04:41 --> Total execution time: 0.0691
DEBUG - 2022-07-07 12:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:05:02 --> Total execution time: 0.1304
DEBUG - 2022-07-07 12:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:35:34 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:05:34 --> Total execution time: 0.0518
DEBUG - 2022-07-07 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:35:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:05:55 --> Total execution time: 0.0563
DEBUG - 2022-07-07 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:11:15 --> Total execution time: 0.1976
DEBUG - 2022-07-07 12:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:11:18 --> Total execution time: 0.0359
DEBUG - 2022-07-07 12:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:11:38 --> Total execution time: 0.0576
DEBUG - 2022-07-07 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:11:39 --> Total execution time: 0.0509
DEBUG - 2022-07-07 12:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:12:00 --> Total execution time: 0.0507
DEBUG - 2022-07-07 12:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:12:37 --> Total execution time: 0.0775
DEBUG - 2022-07-07 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:12:44 --> Total execution time: 0.0791
DEBUG - 2022-07-07 12:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:12:48 --> Total execution time: 0.0703
DEBUG - 2022-07-07 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:13:01 --> Total execution time: 0.0525
DEBUG - 2022-07-07 12:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:13:40 --> Total execution time: 0.1287
DEBUG - 2022-07-07 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:13:46 --> Total execution time: 0.0540
DEBUG - 2022-07-07 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:17:09 --> Total execution time: 0.0411
DEBUG - 2022-07-07 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:17:28 --> Total execution time: 0.0530
DEBUG - 2022-07-07 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:17:34 --> Total execution time: 0.0605
DEBUG - 2022-07-07 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:17:38 --> Total execution time: 0.0405
DEBUG - 2022-07-07 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:17:41 --> Total execution time: 0.0624
DEBUG - 2022-07-07 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:17:45 --> Total execution time: 0.0640
DEBUG - 2022-07-07 12:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:05 --> Total execution time: 0.0584
DEBUG - 2022-07-07 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:05 --> Total execution time: 0.0623
DEBUG - 2022-07-07 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:05 --> Total execution time: 0.0758
DEBUG - 2022-07-07 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:06 --> Total execution time: 0.0783
DEBUG - 2022-07-07 12:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:13 --> No URI present. Default controller set.
DEBUG - 2022-07-07 12:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:13 --> Total execution time: 0.0364
DEBUG - 2022-07-07 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:16 --> Total execution time: 0.0496
DEBUG - 2022-07-07 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:23 --> Total execution time: 0.0538
DEBUG - 2022-07-07 12:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:27 --> Total execution time: 0.1158
DEBUG - 2022-07-07 12:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:48:35 --> Total execution time: 0.0601
DEBUG - 2022-07-07 12:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:44 --> Total execution time: 0.0603
DEBUG - 2022-07-07 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:19:46 --> Total execution time: 0.1412
DEBUG - 2022-07-07 12:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:19:57 --> Total execution time: 0.0895
DEBUG - 2022-07-07 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:23:03 --> Total execution time: 0.1230
DEBUG - 2022-07-07 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:25:59 --> Total execution time: 0.2212
DEBUG - 2022-07-07 12:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 12:56:47 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-07 12:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:06 --> Total execution time: 0.0890
DEBUG - 2022-07-07 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:09 --> Total execution time: 0.0531
DEBUG - 2022-07-07 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 12:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:20 --> Total execution time: 0.0689
DEBUG - 2022-07-07 12:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 12:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 12:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:26 --> Total execution time: 0.1034
DEBUG - 2022-07-07 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:30:02 --> Total execution time: 0.0766
DEBUG - 2022-07-07 13:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:00:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:30:56 --> Total execution time: 0.0472
DEBUG - 2022-07-07 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:33:26 --> Total execution time: 0.1100
DEBUG - 2022-07-07 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:33:30 --> Total execution time: 0.0505
DEBUG - 2022-07-07 13:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:33:51 --> Total execution time: 0.0492
DEBUG - 2022-07-07 13:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:34:15 --> Total execution time: 0.0567
DEBUG - 2022-07-07 13:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:34:23 --> Total execution time: 0.0727
DEBUG - 2022-07-07 13:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:34:37 --> Total execution time: 0.0801
DEBUG - 2022-07-07 13:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:04:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 13:04:58 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 13:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:35:10 --> Total execution time: 0.0559
DEBUG - 2022-07-07 13:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:36:12 --> Total execution time: 0.0581
DEBUG - 2022-07-07 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:36:19 --> Total execution time: 0.0716
DEBUG - 2022-07-07 13:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:09 --> Total execution time: 0.0708
DEBUG - 2022-07-07 13:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 13:08:09 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 13:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:39:07 --> Total execution time: 0.1389
DEBUG - 2022-07-07 13:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:39:08 --> Total execution time: 0.0667
DEBUG - 2022-07-07 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:39:09 --> Total execution time: 0.0618
DEBUG - 2022-07-07 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:39:09 --> Total execution time: 0.0636
DEBUG - 2022-07-07 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:39:10 --> Total execution time: 0.0765
DEBUG - 2022-07-07 13:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:39:10 --> Total execution time: 0.0539
DEBUG - 2022-07-07 13:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 13:09:41 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-07 13:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:40:35 --> Total execution time: 0.1441
DEBUG - 2022-07-07 13:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:40:41 --> Total execution time: 0.0555
DEBUG - 2022-07-07 13:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 13:10:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:40:47 --> Total execution time: 0.0507
DEBUG - 2022-07-07 13:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:11:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:41:06 --> Total execution time: 0.1239
DEBUG - 2022-07-07 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:42:14 --> Total execution time: 0.0544
DEBUG - 2022-07-07 13:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:14:17 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:44:17 --> Total execution time: 0.0542
DEBUG - 2022-07-07 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:49:38 --> Total execution time: 0.1289
DEBUG - 2022-07-07 13:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:23:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:58 --> Total execution time: 0.0885
DEBUG - 2022-07-07 13:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:07 --> Total execution time: 0.0624
DEBUG - 2022-07-07 13:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:28 --> Total execution time: 0.0756
DEBUG - 2022-07-07 13:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:33 --> Total execution time: 0.0778
DEBUG - 2022-07-07 13:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:48 --> Total execution time: 0.0851
DEBUG - 2022-07-07 13:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:58 --> Total execution time: 0.0334
DEBUG - 2022-07-07 13:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:58 --> Total execution time: 0.0575
DEBUG - 2022-07-07 13:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:55:04 --> Total execution time: 0.0862
DEBUG - 2022-07-07 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:55:26 --> Total execution time: 0.0577
DEBUG - 2022-07-07 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:55:30 --> Total execution time: 0.0578
DEBUG - 2022-07-07 13:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:55:33 --> Total execution time: 0.0623
DEBUG - 2022-07-07 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:55:39 --> Total execution time: 0.0523
DEBUG - 2022-07-07 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:55:54 --> Total execution time: 0.0573
DEBUG - 2022-07-07 13:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:59:43 --> Total execution time: 0.1348
DEBUG - 2022-07-07 13:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:32:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:33:06 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 13:35:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 13:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:39:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 13:39:10 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 13:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:10 --> Total execution time: 0.0531
DEBUG - 2022-07-07 13:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:05 --> No URI present. Default controller set.
DEBUG - 2022-07-07 13:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 13:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 13:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 13:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:16:52 --> No URI present. Default controller set.
DEBUG - 2022-07-07 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:31:35 --> No URI present. Default controller set.
DEBUG - 2022-07-07 14:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 14:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 14:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 14:59:18 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:02:15 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:04:40 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 15:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:06:43 --> No URI present. Default controller set.
DEBUG - 2022-07-07 15:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:17:08 --> Total execution time: 0.0452
DEBUG - 2022-07-07 15:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:17:23 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-07 15:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:17:23 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-07 15:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:17:23 --> No URI present. Default controller set.
DEBUG - 2022-07-07 15:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:31:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:31:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:55:50 --> 404 Page Not Found: Wp-configphp/index
DEBUG - 2022-07-07 15:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:55:51 --> 404 Page Not Found: Wp-configtxt/index
DEBUG - 2022-07-07 15:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:55:52 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-07-07 15:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 15:55:53 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-07-07 15:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 15:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:55 --> No URI present. Default controller set.
DEBUG - 2022-07-07 15:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:55:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 15:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 15:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 15:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 15:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:01:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:01:49 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-07 16:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:09:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 16:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:09:40 --> No URI present. Default controller set.
DEBUG - 2022-07-07 16:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:22:01 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-07 16:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:50:07 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:53:01 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 16:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:55:30 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:56:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:56:51 --> No URI present. Default controller set.
DEBUG - 2022-07-07 16:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:56:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:57:30 --> No URI present. Default controller set.
DEBUG - 2022-07-07 16:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 16:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 16:57:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 16:57:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:00:27 --> No URI present. Default controller set.
DEBUG - 2022-07-07 17:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 17:00:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 17:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:03:59 --> No URI present. Default controller set.
DEBUG - 2022-07-07 17:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 17:03:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 17:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:05:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 17:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 17:05:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 17:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:08:20 --> No URI present. Default controller set.
DEBUG - 2022-07-07 17:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 17:08:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 17:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 17:22:30 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 17:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 17:28:01 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-07 17:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:28:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 17:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 17:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 17:45:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 17:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 17:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:10:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:10:55 --> 404 Page Not Found: Wp-pluginsphp/index
DEBUG - 2022-07-07 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:33:03 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-07 18:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:44:40 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 18:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:47:39 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 18:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:49:56 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 18:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:50:45 --> No URI present. Default controller set.
DEBUG - 2022-07-07 18:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:50:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 18:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 18:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 18:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 18:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 18:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 18:53:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 19:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 19:16:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 19:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 19:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:37:38 --> No URI present. Default controller set.
DEBUG - 2022-07-07 19:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 19:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:51:56 --> No URI present. Default controller set.
DEBUG - 2022-07-07 19:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 19:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 19:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 19:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 19:55:19 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-07 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:19:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 20:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:21:04 --> No URI present. Default controller set.
DEBUG - 2022-07-07 20:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 20:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:14 --> No URI present. Default controller set.
DEBUG - 2022-07-07 20:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:01 --> Total execution time: 0.0710
DEBUG - 2022-07-07 20:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 20:37:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 20:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 20:40:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 20:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:41:25 --> No URI present. Default controller set.
DEBUG - 2022-07-07 20:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 20:41:26 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-07 20:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 20:42:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 20:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:44:15 --> Total execution time: 0.0350
DEBUG - 2022-07-07 20:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:54:54 --> No URI present. Default controller set.
DEBUG - 2022-07-07 20:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 20:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 20:54:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-07-07 20:54:54 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
DEBUG - 2022-07-07 20:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 20:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 20:54:54 --> 404 Page Not Found: Alfacgiapi/perl.alfa
DEBUG - 2022-07-07 21:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 21:09:25 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 21:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 21:15:56 --> 404 Page Not Found: Wp-includes/ID3
DEBUG - 2022-07-07 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 21:15:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 21:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:53:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 21:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 21:56:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 21:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 21:57:22 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-07 21:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 21:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:59:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 21:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 21:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 21:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 21:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:02:46 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:08:24 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:09:00 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:12:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:01 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:43 --> Total execution time: 0.0619
DEBUG - 2022-07-07 22:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:45 --> Total execution time: 0.0607
DEBUG - 2022-07-07 22:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:45 --> Total execution time: 0.1234
DEBUG - 2022-07-07 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:19:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:01 --> Total execution time: 0.0741
DEBUG - 2022-07-07 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:03 --> Total execution time: 0.0848
DEBUG - 2022-07-07 22:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:03 --> Total execution time: 0.0874
DEBUG - 2022-07-07 22:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:21:57 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:28:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:28:23 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-07 22:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:28:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:28:59 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:29:51 --> Total execution time: 0.0699
DEBUG - 2022-07-07 22:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:29:53 --> Total execution time: 0.0484
DEBUG - 2022-07-07 22:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:29:53 --> Total execution time: 0.1117
DEBUG - 2022-07-07 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:30:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-07 22:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:30:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 22:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:30:53 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:31:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-07 22:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:31:21 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:33:37 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:33:40 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-07-07 22:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:33:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 22:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:33:46 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-07 22:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:33:50 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:34:47 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:41:05 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-07 22:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:41:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 22:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:39 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:15 --> Total execution time: 0.0543
DEBUG - 2022-07-07 22:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:17 --> Total execution time: 0.0510
DEBUG - 2022-07-07 22:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:50:17 --> Total execution time: 0.1460
DEBUG - 2022-07-07 22:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:19 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:21 --> Total execution time: 0.0709
DEBUG - 2022-07-07 22:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:26 --> Total execution time: 0.0568
DEBUG - 2022-07-07 22:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:26 --> Total execution time: 0.1122
DEBUG - 2022-07-07 22:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:55:12 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:44 --> Total execution time: 0.0698
DEBUG - 2022-07-07 22:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:55:51 --> Total execution time: 0.1058
DEBUG - 2022-07-07 22:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:56:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:44 --> No URI present. Default controller set.
DEBUG - 2022-07-07 22:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 22:57:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 22:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 22:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 22:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 22:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 23:00:00 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-07 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:02 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:09:29 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:09:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:14:58 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:18:15 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:18:48 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:20:49 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-07 23:20:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-07 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:28:41 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:28:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:28:42 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:29:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:29:16 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:38:07 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:31 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:32 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:36 --> No URI present. Default controller set.
DEBUG - 2022-07-07 23:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:47 --> Total execution time: 0.0590
DEBUG - 2022-07-07 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:50:53 --> Total execution time: 0.1081
DEBUG - 2022-07-07 23:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-07 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-07 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-07 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
