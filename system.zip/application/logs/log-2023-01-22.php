<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-22 15:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:09:42 --> No URI present. Default controller set.
DEBUG - 2023-01-22 15:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:39:43 --> Total execution time: 0.7816
DEBUG - 2023-01-22 15:09:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:09:43 --> No URI present. Default controller set.
DEBUG - 2023-01-22 15:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:39:43 --> Total execution time: 0.0482
DEBUG - 2023-01-22 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:09:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:09:56 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:09:56 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:09:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:09:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:09:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:12:44 --> No URI present. Default controller set.
DEBUG - 2023-01-22 15:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:42:44 --> Total execution time: 0.0510
DEBUG - 2023-01-22 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:12:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:12:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:12:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:12:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:13:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:43:06 --> Total execution time: 0.1610
DEBUG - 2023-01-22 15:17:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:47:56 --> Total execution time: 0.7197
DEBUG - 2023-01-22 15:18:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:18:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:18:30 --> UTF-8 Support Enabled
ERROR - 2023-01-22 15:18:30 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:18:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:18:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:18:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:18:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:18:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:18:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:52:22 --> Total execution time: 0.0548
DEBUG - 2023-01-22 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:22 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:22:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:30 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:22:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:52:57 --> Total execution time: 0.0756
DEBUG - 2023-01-22 15:22:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:57 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:22:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:22:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:22:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:23:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:23:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:23:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:23:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:54:47 --> Total execution time: 0.0720
DEBUG - 2023-01-22 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:55:42 --> Total execution time: 0.0472
DEBUG - 2023-01-22 15:25:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:55:49 --> Total execution time: 0.0565
DEBUG - 2023-01-22 15:25:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:55:52 --> Total execution time: 0.0779
DEBUG - 2023-01-22 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:56:43 --> Total execution time: 0.0615
DEBUG - 2023-01-22 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:26:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:57:33 --> Total execution time: 0.0480
DEBUG - 2023-01-22 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:27:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:27:33 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:27:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:27:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:58:27 --> Total execution time: 0.0619
DEBUG - 2023-01-22 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:28:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:28:27 --> UTF-8 Support Enabled
ERROR - 2023-01-22 15:28:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:28:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:28:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 19:59:53 --> Total execution time: 0.0536
DEBUG - 2023-01-22 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:29:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:29:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:29:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:29:53 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:29:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:29:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:29:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:00:24 --> Total execution time: 0.0541
DEBUG - 2023-01-22 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:00:53 --> Total execution time: 0.0484
DEBUG - 2023-01-22 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:30:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:32:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:02:59 --> Total execution time: 0.0547
DEBUG - 2023-01-22 15:35:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 15:35:03 --> Total execution time: 0.0593
DEBUG - 2023-01-22 15:35:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 15:35:06 --> Total execution time: 0.0411
DEBUG - 2023-01-22 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:05:09 --> Total execution time: 0.1099
DEBUG - 2023-01-22 15:35:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:05:36 --> Total execution time: 0.1045
DEBUG - 2023-01-22 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:07:42 --> Total execution time: 0.0476
DEBUG - 2023-01-22 15:37:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:37:42 --> UTF-8 Support Enabled
ERROR - 2023-01-22 15:37:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:37:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:37:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:08:43 --> Total execution time: 0.0606
DEBUG - 2023-01-22 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:43 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:38:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:38:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:39:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:39:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:39:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:39:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:10:52 --> Total execution time: 0.0606
DEBUG - 2023-01-22 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:13:29 --> Total execution time: 0.0696
DEBUG - 2023-01-22 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:43:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:43:29 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:43:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:43:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:15:08 --> Total execution time: 0.0629
DEBUG - 2023-01-22 15:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:45:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:45:08 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:45:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:45:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:16:32 --> Total execution time: 0.0572
DEBUG - 2023-01-22 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:46:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:46:32 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:46:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:46:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:46:45 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:46:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:46:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:46:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:17:34 --> Total execution time: 0.0507
DEBUG - 2023-01-22 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:47:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:47:35 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:47:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:47:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:47:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:48:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:48:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:48:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:48:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:48:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:18:29 --> Total execution time: 0.0650
DEBUG - 2023-01-22 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:19:04 --> Total execution time: 0.0607
DEBUG - 2023-01-22 15:49:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:19:14 --> Total execution time: 0.0629
DEBUG - 2023-01-22 15:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:50:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:50:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:50:35 --> UTF-8 Support Enabled
ERROR - 2023-01-22 15:50:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:50:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:50:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:50:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:50:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:21:53 --> Total execution time: 0.0662
DEBUG - 2023-01-22 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:51:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:51:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:51:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:51:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:22:33 --> Total execution time: 0.0664
DEBUG - 2023-01-22 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:52:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:52:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:52:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:52:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:23:48 --> Total execution time: 0.0702
DEBUG - 2023-01-22 15:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:53:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:53:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:53:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:53:48 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 15:53:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:53:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 15:53:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 15:55:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:25:20 --> Total execution time: 0.0461
DEBUG - 2023-01-22 15:55:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:25:23 --> Total execution time: 0.0829
DEBUG - 2023-01-22 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:25:25 --> Total execution time: 0.1123
DEBUG - 2023-01-22 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 15:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 15:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 15:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:25:25 --> Total execution time: 0.0639
DEBUG - 2023-01-22 16:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:42:14 --> Total execution time: 0.0652
DEBUG - 2023-01-22 16:12:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:42:56 --> Total execution time: 0.0700
DEBUG - 2023-01-22 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:43:48 --> Total execution time: 0.0482
DEBUG - 2023-01-22 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:13:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:13:48 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:13:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:13:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:44:25 --> Total execution time: 0.0458
DEBUG - 2023-01-22 16:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:14:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:14:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:14:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:14:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:46:20 --> Total execution time: 0.0463
DEBUG - 2023-01-22 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:16:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:16:20 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:16:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:16:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:47:31 --> Total execution time: 0.0563
DEBUG - 2023-01-22 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:17:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:17:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:17:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:17:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:48:44 --> Total execution time: 0.0531
DEBUG - 2023-01-22 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:18:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:18:44 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:18:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:18:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:51:03 --> Total execution time: 0.0593
DEBUG - 2023-01-22 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:51:50 --> Total execution time: 0.0688
DEBUG - 2023-01-22 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:52:16 --> Total execution time: 0.0615
DEBUG - 2023-01-22 16:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:52:46 --> Total execution time: 0.0513
DEBUG - 2023-01-22 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:22:49 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:22:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:22:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:22:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:53:43 --> Total execution time: 0.0674
DEBUG - 2023-01-22 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:23:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:23:43 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:23:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:23:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:54:05 --> Total execution time: 0.0463
DEBUG - 2023-01-22 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:24:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:24:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:56:12 --> Total execution time: 0.0669
DEBUG - 2023-01-22 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:26:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:26:12 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:26:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:26:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 20:58:22 --> Total execution time: 0.0668
DEBUG - 2023-01-22 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:00:29 --> Total execution time: 0.0646
DEBUG - 2023-01-22 16:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:30:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:30:29 --> UTF-8 Support Enabled
ERROR - 2023-01-22 16:30:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:30:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:30:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:06:08 --> Total execution time: 0.0531
DEBUG - 2023-01-22 16:36:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:06:12 --> Total execution time: 0.0471
DEBUG - 2023-01-22 16:36:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:06:15 --> Total execution time: 0.0565
DEBUG - 2023-01-22 16:36:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:06:17 --> Total execution time: 0.0633
DEBUG - 2023-01-22 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:36:23 --> UTF-8 Support Enabled
ERROR - 2023-01-22 16:36:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:36:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:36:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:36:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:09:07 --> Total execution time: 0.0950
DEBUG - 2023-01-22 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:09:13 --> Total execution time: 0.0552
DEBUG - 2023-01-22 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:14 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:39:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:39:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:10:14 --> Total execution time: 0.0566
DEBUG - 2023-01-22 16:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:40:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:40:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:40:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:40:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:11:58 --> Total execution time: 0.0763
DEBUG - 2023-01-22 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:41:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:12:02 --> Total execution time: 0.0782
DEBUG - 2023-01-22 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:02 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:42:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:12:13 --> Total execution time: 0.0566
DEBUG - 2023-01-22 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:13 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:42:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:12:22 --> Total execution time: 0.0625
DEBUG - 2023-01-22 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:42:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:44:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:44:44 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:44:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:44:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:45:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:15:16 --> Total execution time: 0.0553
DEBUG - 2023-01-22 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:45:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:45:32 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:45:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:45:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:16:31 --> Total execution time: 0.0521
DEBUG - 2023-01-22 16:46:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:16:44 --> Total execution time: 0.0597
DEBUG - 2023-01-22 16:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:46:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:50 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:46:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:46:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:46:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:17:31 --> Total execution time: 0.0613
DEBUG - 2023-01-22 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:47:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:47:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:47:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:47:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:18:46 --> Total execution time: 0.0587
DEBUG - 2023-01-22 16:48:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:48:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:48:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:48:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:48:47 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:48:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:48:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:48:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:19:56 --> Total execution time: 0.0476
DEBUG - 2023-01-22 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:49:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:49:56 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:49:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:49:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:21:31 --> Total execution time: 0.0691
DEBUG - 2023-01-22 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:51:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:21:40 --> Total execution time: 0.0573
DEBUG - 2023-01-22 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:40 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:51:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:21:44 --> Total execution time: 0.0853
DEBUG - 2023-01-22 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:51:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:44 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:51:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:51:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:51:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:22:04 --> Total execution time: 0.0679
DEBUG - 2023-01-22 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:52:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:54:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:24:31 --> Total execution time: 0.0523
DEBUG - 2023-01-22 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:54:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:54:32 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:54:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:54:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:55:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:25:20 --> Total execution time: 0.0675
DEBUG - 2023-01-22 16:55:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:55:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:55:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:55:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:55:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:55:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:55:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:55:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:26:03 --> Total execution time: 0.0834
DEBUG - 2023-01-22 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:56:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:56:03 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:56:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:56:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:27:38 --> Total execution time: 0.0745
DEBUG - 2023-01-22 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:57:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:57:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:57:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:57:38 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:57:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:57:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:57:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:29:33 --> Total execution time: 0.0507
DEBUG - 2023-01-22 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:59:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:59:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:59:34 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:59:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:59:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:59:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 16:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:29:40 --> Total execution time: 0.0785
DEBUG - 2023-01-22 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:59:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 16:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:59:41 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 16:59:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 16:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 16:59:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 17:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 17:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:30:01 --> Total execution time: 0.0483
DEBUG - 2023-01-22 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 17:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 17:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:30:33 --> Total execution time: 0.0511
DEBUG - 2023-01-22 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 17:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:33 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-22 17:00:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-22 17:00:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-22 17:03:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-22 17:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-22 17:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-22 17:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-22 21:33:01 --> Total execution time: 0.0724
