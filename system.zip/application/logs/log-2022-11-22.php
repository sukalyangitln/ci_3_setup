<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-22 00:00:35 --> Total execution time: 0.1693
DEBUG - 2022-11-22 00:15:38 --> Total execution time: 0.9675
DEBUG - 2022-11-22 00:15:38 --> Total execution time: 0.1885
DEBUG - 2022-11-22 00:25:34 --> Total execution time: 0.5867
DEBUG - 2022-11-22 00:28:31 --> Total execution time: 0.5695
DEBUG - 2022-11-22 00:30:03 --> Total execution time: 0.4869
DEBUG - 2022-11-22 00:30:17 --> Total execution time: 0.1181
DEBUG - 2022-11-22 00:30:33 --> Total execution time: 0.1759
DEBUG - 2022-11-22 00:31:28 --> Total execution time: 0.1778
DEBUG - 2022-11-22 00:31:59 --> Total execution time: 0.1244
DEBUG - 2022-11-22 00:32:00 --> Total execution time: 0.1111
DEBUG - 2022-11-22 00:39:03 --> Total execution time: 0.1228
DEBUG - 2022-11-22 00:44:00 --> Total execution time: 1.0617
DEBUG - 2022-11-22 00:47:25 --> Total execution time: 0.9375
DEBUG - 2022-11-22 00:47:32 --> Total execution time: 0.2048
DEBUG - 2022-11-22 00:47:43 --> Total execution time: 0.1904
DEBUG - 2022-11-22 00:47:59 --> Total execution time: 0.1772
DEBUG - 2022-11-22 00:49:35 --> Total execution time: 0.1232
DEBUG - 2022-11-22 00:52:17 --> Total execution time: 0.1775
DEBUG - 2022-11-22 01:05:33 --> Total execution time: 0.5354
DEBUG - 2022-11-22 01:27:35 --> Total execution time: 0.5614
DEBUG - 2022-11-22 01:27:36 --> Total execution time: 0.1261
DEBUG - 2022-11-22 01:27:43 --> Total execution time: 0.1110
DEBUG - 2022-11-22 01:29:00 --> Total execution time: 0.1757
DEBUG - 2022-11-22 01:29:08 --> Total execution time: 0.2145
DEBUG - 2022-11-22 01:29:30 --> Total execution time: 0.2693
DEBUG - 2022-11-22 01:29:31 --> Total execution time: 0.2322
DEBUG - 2022-11-22 01:29:31 --> Total execution time: 0.3237
DEBUG - 2022-11-22 01:30:02 --> Total execution time: 0.1398
DEBUG - 2022-11-22 01:30:05 --> Total execution time: 0.1973
DEBUG - 2022-11-22 01:30:17 --> Total execution time: 0.1819
DEBUG - 2022-11-22 01:30:18 --> Total execution time: 0.1962
DEBUG - 2022-11-22 01:30:32 --> Total execution time: 0.2234
DEBUG - 2022-11-22 01:30:52 --> Total execution time: 0.2426
DEBUG - 2022-11-22 01:31:36 --> Total execution time: 0.2164
DEBUG - 2022-11-22 01:32:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 01:32:12 --> Total execution time: 0.2089
DEBUG - 2022-11-22 01:32:20 --> Total execution time: 0.2240
DEBUG - 2022-11-22 01:32:34 --> Total execution time: 0.2108
DEBUG - 2022-11-22 01:32:48 --> Total execution time: 0.5040
DEBUG - 2022-11-22 01:36:31 --> Total execution time: 0.2002
DEBUG - 2022-11-22 01:50:31 --> Total execution time: 0.6351
DEBUG - 2022-11-22 01:59:34 --> Total execution time: 0.1932
DEBUG - 2022-11-22 02:00:18 --> Total execution time: 0.1122
DEBUG - 2022-11-22 02:00:54 --> Total execution time: 0.1830
DEBUG - 2022-11-22 02:11:21 --> Total execution time: 0.6206
DEBUG - 2022-11-22 02:11:33 --> Total execution time: 0.2123
DEBUG - 2022-11-22 02:14:21 --> Total execution time: 0.5110
DEBUG - 2022-11-22 02:15:36 --> Total execution time: 0.1177
DEBUG - 2022-11-22 02:15:53 --> Total execution time: 0.1361
DEBUG - 2022-11-22 02:15:58 --> Total execution time: 0.1812
DEBUG - 2022-11-22 02:16:07 --> Total execution time: 0.2101
DEBUG - 2022-11-22 02:16:27 --> Total execution time: 0.2149
DEBUG - 2022-11-22 02:16:53 --> Total execution time: 0.1973
DEBUG - 2022-11-22 02:17:10 --> Total execution time: 0.1765
DEBUG - 2022-11-22 02:17:16 --> Total execution time: 0.1778
DEBUG - 2022-11-22 02:17:18 --> Total execution time: 0.1696
DEBUG - 2022-11-22 02:21:28 --> Total execution time: 1.1908
DEBUG - 2022-11-22 02:24:40 --> Total execution time: 0.4657
DEBUG - 2022-11-22 02:25:53 --> Total execution time: 0.5712
DEBUG - 2022-11-22 02:30:05 --> Total execution time: 2.2076
DEBUG - 2022-11-22 02:49:06 --> Total execution time: 0.1847
DEBUG - 2022-11-22 02:52:44 --> Total execution time: 1.6350
DEBUG - 2022-11-22 03:02:10 --> Total execution time: 0.5141
DEBUG - 2022-11-22 03:23:54 --> Total execution time: 0.6455
DEBUG - 2022-11-22 03:30:04 --> Total execution time: 1.7254
DEBUG - 2022-11-22 03:57:29 --> Total execution time: 0.6723
DEBUG - 2022-11-22 04:30:04 --> Total execution time: 1.5622
DEBUG - 2022-11-22 04:31:04 --> Total execution time: 0.6475
DEBUG - 2022-11-22 04:50:29 --> Total execution time: 0.6388
DEBUG - 2022-11-22 04:51:05 --> Total execution time: 0.1236
DEBUG - 2022-11-22 05:04:39 --> Total execution time: 0.6935
DEBUG - 2022-11-22 05:11:02 --> Total execution time: 0.6165
DEBUG - 2022-11-22 05:30:03 --> Total execution time: 0.8227
DEBUG - 2022-11-22 05:34:41 --> Total execution time: 2.3302
DEBUG - 2022-11-22 05:56:20 --> Total execution time: 0.6485
DEBUG - 2022-11-22 05:57:07 --> Total execution time: 0.1721
DEBUG - 2022-11-22 05:57:17 --> Total execution time: 0.1715
DEBUG - 2022-11-22 05:57:35 --> Total execution time: 0.1706
DEBUG - 2022-11-22 05:57:55 --> Total execution time: 0.1640
DEBUG - 2022-11-22 05:58:07 --> Total execution time: 0.1689
DEBUG - 2022-11-22 05:58:13 --> Total execution time: 0.1910
DEBUG - 2022-11-22 06:00:10 --> Total execution time: 0.1842
DEBUG - 2022-11-22 06:00:10 --> Total execution time: 0.1696
DEBUG - 2022-11-22 06:00:11 --> Total execution time: 0.1792
DEBUG - 2022-11-22 06:02:26 --> Total execution time: 0.4603
DEBUG - 2022-11-22 06:03:53 --> Total execution time: 0.1743
DEBUG - 2022-11-22 06:03:54 --> Total execution time: 0.1746
DEBUG - 2022-11-22 06:04:03 --> Total execution time: 0.1868
DEBUG - 2022-11-22 06:04:11 --> Total execution time: 0.1750
DEBUG - 2022-11-22 06:04:21 --> Total execution time: 0.1684
DEBUG - 2022-11-22 06:04:28 --> Total execution time: 0.1108
DEBUG - 2022-11-22 06:04:39 --> Total execution time: 0.1126
DEBUG - 2022-11-22 06:04:41 --> Total execution time: 0.1730
DEBUG - 2022-11-22 06:05:03 --> Total execution time: 0.1942
DEBUG - 2022-11-22 06:05:21 --> Total execution time: 0.1951
DEBUG - 2022-11-22 06:06:01 --> Total execution time: 0.2387
DEBUG - 2022-11-22 06:12:36 --> Total execution time: 0.8888
DEBUG - 2022-11-22 06:12:44 --> Total execution time: 0.1733
DEBUG - 2022-11-22 06:13:03 --> Total execution time: 0.1751
DEBUG - 2022-11-22 06:13:24 --> Total execution time: 0.1823
DEBUG - 2022-11-22 06:13:41 --> Total execution time: 0.1835
DEBUG - 2022-11-22 06:13:46 --> Total execution time: 0.1745
DEBUG - 2022-11-22 06:14:01 --> Total execution time: 0.1788
DEBUG - 2022-11-22 06:14:09 --> Total execution time: 0.2186
DEBUG - 2022-11-22 06:14:19 --> Total execution time: 0.1749
DEBUG - 2022-11-22 06:14:49 --> Total execution time: 0.1772
DEBUG - 2022-11-22 06:14:49 --> Total execution time: 0.1752
DEBUG - 2022-11-22 06:15:02 --> Total execution time: 0.2642
DEBUG - 2022-11-22 06:15:30 --> Total execution time: 0.1746
DEBUG - 2022-11-22 06:15:41 --> Total execution time: 0.1763
DEBUG - 2022-11-22 06:15:41 --> Total execution time: 0.1817
DEBUG - 2022-11-22 06:19:40 --> Total execution time: 0.5979
DEBUG - 2022-11-22 06:26:03 --> Total execution time: 0.1926
DEBUG - 2022-11-22 06:26:16 --> Total execution time: 0.1766
DEBUG - 2022-11-22 06:26:47 --> Total execution time: 0.2307
DEBUG - 2022-11-22 06:26:55 --> Total execution time: 0.2161
DEBUG - 2022-11-22 06:27:20 --> Total execution time: 0.1831
DEBUG - 2022-11-22 06:27:27 --> Total execution time: 0.1923
DEBUG - 2022-11-22 06:27:39 --> Total execution time: 0.1887
DEBUG - 2022-11-22 06:27:44 --> Total execution time: 0.2000
DEBUG - 2022-11-22 06:28:01 --> Total execution time: 0.1897
DEBUG - 2022-11-22 06:30:02 --> Total execution time: 0.1467
DEBUG - 2022-11-22 06:31:36 --> Total execution time: 0.1763
DEBUG - 2022-11-22 06:35:19 --> Total execution time: 0.1305
DEBUG - 2022-11-22 06:35:19 --> Total execution time: 0.1112
DEBUG - 2022-11-22 06:35:25 --> Total execution time: 0.1074
DEBUG - 2022-11-22 06:35:32 --> Total execution time: 0.2027
DEBUG - 2022-11-22 06:35:49 --> Total execution time: 0.1878
DEBUG - 2022-11-22 06:36:36 --> Total execution time: 0.1752
DEBUG - 2022-11-22 06:36:48 --> Total execution time: 0.1767
DEBUG - 2022-11-22 06:36:53 --> Total execution time: 0.1771
DEBUG - 2022-11-22 06:37:05 --> Total execution time: 0.1728
DEBUG - 2022-11-22 06:37:14 --> Total execution time: 0.2021
DEBUG - 2022-11-22 06:37:20 --> Total execution time: 0.1725
DEBUG - 2022-11-22 06:40:20 --> Total execution time: 1.1122
DEBUG - 2022-11-22 06:40:27 --> Total execution time: 0.5115
DEBUG - 2022-11-22 06:40:35 --> Total execution time: 0.1795
DEBUG - 2022-11-22 06:41:30 --> Total execution time: 0.1770
DEBUG - 2022-11-22 06:41:35 --> Total execution time: 0.2083
DEBUG - 2022-11-22 06:41:49 --> Total execution time: 0.5191
DEBUG - 2022-11-22 06:41:50 --> Total execution time: 0.1903
DEBUG - 2022-11-22 06:42:04 --> Total execution time: 0.1816
DEBUG - 2022-11-22 06:42:07 --> Total execution time: 0.1799
DEBUG - 2022-11-22 06:42:15 --> Total execution time: 0.1745
DEBUG - 2022-11-22 06:42:23 --> Total execution time: 0.1723
DEBUG - 2022-11-22 06:48:17 --> Total execution time: 0.6950
DEBUG - 2022-11-22 06:51:24 --> Total execution time: 0.1832
DEBUG - 2022-11-22 06:52:48 --> Total execution time: 0.1880
DEBUG - 2022-11-22 06:54:10 --> Total execution time: 0.1723
DEBUG - 2022-11-22 06:54:22 --> Total execution time: 0.2065
DEBUG - 2022-11-22 06:54:25 --> Total execution time: 0.1456
DEBUG - 2022-11-22 06:54:40 --> Total execution time: 0.1913
DEBUG - 2022-11-22 06:54:45 --> Total execution time: 0.1093
DEBUG - 2022-11-22 06:54:53 --> Total execution time: 0.2277
DEBUG - 2022-11-22 06:54:59 --> Total execution time: 0.2133
DEBUG - 2022-11-22 06:55:05 --> Total execution time: 0.1884
DEBUG - 2022-11-22 06:55:16 --> Total execution time: 0.1925
DEBUG - 2022-11-22 06:55:23 --> Total execution time: 0.1799
DEBUG - 2022-11-22 06:55:33 --> Total execution time: 0.1883
DEBUG - 2022-11-22 06:55:38 --> Total execution time: 0.1929
DEBUG - 2022-11-22 06:55:38 --> Total execution time: 0.2161
DEBUG - 2022-11-22 06:55:44 --> Total execution time: 0.1991
DEBUG - 2022-11-22 06:55:46 --> Total execution time: 0.1755
DEBUG - 2022-11-22 06:55:51 --> Total execution time: 0.2003
DEBUG - 2022-11-22 06:56:21 --> Total execution time: 0.1169
DEBUG - 2022-11-22 06:56:21 --> Total execution time: 0.1420
DEBUG - 2022-11-22 06:57:05 --> Total execution time: 0.1109
DEBUG - 2022-11-22 06:57:27 --> Total execution time: 0.1760
DEBUG - 2022-11-22 06:57:56 --> Total execution time: 0.2264
DEBUG - 2022-11-22 06:57:58 --> Total execution time: 0.1833
DEBUG - 2022-11-22 06:58:13 --> Total execution time: 0.1153
DEBUG - 2022-11-22 06:59:18 --> Total execution time: 0.4880
DEBUG - 2022-11-22 06:59:19 --> Total execution time: 0.1904
DEBUG - 2022-11-22 06:59:31 --> Total execution time: 0.1849
DEBUG - 2022-11-22 06:59:42 --> Total execution time: 0.2117
DEBUG - 2022-11-22 06:59:47 --> Total execution time: 0.1715
DEBUG - 2022-11-22 07:00:06 --> Total execution time: 0.1989
DEBUG - 2022-11-22 07:00:17 --> Total execution time: 0.1891
DEBUG - 2022-11-22 07:00:24 --> Total execution time: 0.1884
DEBUG - 2022-11-22 07:00:39 --> Total execution time: 0.1641
DEBUG - 2022-11-22 07:00:43 --> Total execution time: 0.1770
DEBUG - 2022-11-22 07:00:47 --> Total execution time: 0.1724
DEBUG - 2022-11-22 07:00:51 --> Total execution time: 0.1736
DEBUG - 2022-11-22 07:00:53 --> Total execution time: 0.1716
DEBUG - 2022-11-22 07:01:21 --> Total execution time: 0.4654
DEBUG - 2022-11-22 07:01:22 --> Total execution time: 0.1768
DEBUG - 2022-11-22 07:01:26 --> Total execution time: 0.4637
DEBUG - 2022-11-22 07:01:33 --> Total execution time: 0.1926
DEBUG - 2022-11-22 07:01:37 --> Total execution time: 0.1818
DEBUG - 2022-11-22 07:01:47 --> Total execution time: 0.2094
DEBUG - 2022-11-22 07:01:53 --> Total execution time: 0.1729
DEBUG - 2022-11-22 07:03:12 --> Total execution time: 0.1978
DEBUG - 2022-11-22 07:03:34 --> Total execution time: 0.1811
DEBUG - 2022-11-22 07:03:41 --> Total execution time: 0.1742
DEBUG - 2022-11-22 07:03:51 --> Total execution time: 0.2807
DEBUG - 2022-11-22 07:04:18 --> Total execution time: 0.5339
DEBUG - 2022-11-22 07:08:32 --> Total execution time: 0.6712
DEBUG - 2022-11-22 07:10:52 --> Total execution time: 0.2003
DEBUG - 2022-11-22 07:15:37 --> Total execution time: 2.8030
DEBUG - 2022-11-22 07:15:52 --> Total execution time: 2.6786
DEBUG - 2022-11-22 07:16:28 --> Total execution time: 0.1122
DEBUG - 2022-11-22 07:16:28 --> Total execution time: 0.1387
DEBUG - 2022-11-22 07:17:23 --> Total execution time: 0.4862
DEBUG - 2022-11-22 07:17:50 --> Total execution time: 0.1115
DEBUG - 2022-11-22 07:17:50 --> Total execution time: 0.1130
DEBUG - 2022-11-22 07:18:00 --> Total execution time: 0.1184
DEBUG - 2022-11-22 07:18:02 --> Total execution time: 0.2487
DEBUG - 2022-11-22 07:18:13 --> Total execution time: 0.2996
DEBUG - 2022-11-22 07:18:22 --> Total execution time: 0.6135
DEBUG - 2022-11-22 07:18:32 --> Total execution time: 0.4187
DEBUG - 2022-11-22 07:18:38 --> Total execution time: 0.2607
DEBUG - 2022-11-22 07:20:41 --> Total execution time: 0.5685
DEBUG - 2022-11-22 07:20:48 --> Total execution time: 0.1109
DEBUG - 2022-11-22 07:21:13 --> Total execution time: 0.2084
DEBUG - 2022-11-22 07:21:31 --> Total execution time: 0.2505
DEBUG - 2022-11-22 07:21:41 --> Total execution time: 0.2702
DEBUG - 2022-11-22 07:21:50 --> Total execution time: 0.1889
DEBUG - 2022-11-22 07:22:00 --> Total execution time: 0.2021
DEBUG - 2022-11-22 07:22:02 --> Total execution time: 0.1707
DEBUG - 2022-11-22 07:22:17 --> Total execution time: 0.1842
DEBUG - 2022-11-22 07:22:23 --> Total execution time: 0.2025
DEBUG - 2022-11-22 07:22:29 --> Total execution time: 0.1885
DEBUG - 2022-11-22 07:22:48 --> Total execution time: 0.5062
DEBUG - 2022-11-22 07:23:08 --> Total execution time: 0.1929
DEBUG - 2022-11-22 07:23:18 --> Total execution time: 0.1771
DEBUG - 2022-11-22 07:23:26 --> Total execution time: 0.1752
DEBUG - 2022-11-22 07:23:39 --> Total execution time: 0.1738
DEBUG - 2022-11-22 07:23:54 --> Total execution time: 0.1861
DEBUG - 2022-11-22 07:24:10 --> Total execution time: 0.1132
DEBUG - 2022-11-22 07:24:11 --> Total execution time: 0.1189
DEBUG - 2022-11-22 07:24:22 --> Total execution time: 0.1779
DEBUG - 2022-11-22 07:26:16 --> Total execution time: 0.4848
DEBUG - 2022-11-22 07:26:23 --> Total execution time: 0.1772
DEBUG - 2022-11-22 07:26:25 --> Total execution time: 0.1793
DEBUG - 2022-11-22 07:27:10 --> Total execution time: 0.1942
DEBUG - 2022-11-22 07:27:24 --> Total execution time: 0.1891
DEBUG - 2022-11-22 07:27:32 --> Total execution time: 0.1697
DEBUG - 2022-11-22 07:27:37 --> Total execution time: 0.2021
DEBUG - 2022-11-22 07:27:47 --> Total execution time: 0.1697
DEBUG - 2022-11-22 07:27:49 --> Total execution time: 0.1747
DEBUG - 2022-11-22 07:28:01 --> Total execution time: 0.1731
DEBUG - 2022-11-22 07:28:14 --> Total execution time: 0.2174
DEBUG - 2022-11-22 07:28:43 --> Total execution time: 0.1945
DEBUG - 2022-11-22 07:28:54 --> Total execution time: 0.1978
DEBUG - 2022-11-22 07:28:57 --> Total execution time: 0.1691
DEBUG - 2022-11-22 07:29:00 --> Total execution time: 0.2065
DEBUG - 2022-11-22 07:29:01 --> Total execution time: 0.1833
DEBUG - 2022-11-22 07:29:59 --> Total execution time: 0.1072
DEBUG - 2022-11-22 07:30:02 --> Total execution time: 0.1269
DEBUG - 2022-11-22 07:30:17 --> Total execution time: 0.4736
DEBUG - 2022-11-22 07:30:27 --> Total execution time: 0.1806
DEBUG - 2022-11-22 07:31:33 --> Total execution time: 1.3396
DEBUG - 2022-11-22 07:31:49 --> Total execution time: 0.1772
DEBUG - 2022-11-22 07:32:08 --> Total execution time: 0.1795
DEBUG - 2022-11-22 07:33:00 --> Total execution time: 0.1720
DEBUG - 2022-11-22 07:33:09 --> Total execution time: 0.1772
DEBUG - 2022-11-22 07:33:17 --> Total execution time: 0.1917
DEBUG - 2022-11-22 07:33:19 --> Total execution time: 0.1870
DEBUG - 2022-11-22 07:34:30 --> Total execution time: 0.1861
DEBUG - 2022-11-22 07:34:54 --> Total execution time: 0.5823
DEBUG - 2022-11-22 07:38:42 --> Total execution time: 0.4692
DEBUG - 2022-11-22 07:38:46 --> Total execution time: 0.1691
DEBUG - 2022-11-22 07:38:49 --> Total execution time: 0.1737
DEBUG - 2022-11-22 07:38:50 --> Total execution time: 0.1709
DEBUG - 2022-11-22 07:38:54 --> Total execution time: 0.1921
DEBUG - 2022-11-22 07:38:55 --> Total execution time: 0.1797
DEBUG - 2022-11-22 07:38:55 --> Total execution time: 0.1741
DEBUG - 2022-11-22 07:38:55 --> Total execution time: 0.1812
DEBUG - 2022-11-22 07:40:10 --> Total execution time: 0.1727
DEBUG - 2022-11-22 07:40:28 --> Total execution time: 0.5214
DEBUG - 2022-11-22 07:40:29 --> Total execution time: 0.2040
DEBUG - 2022-11-22 07:44:04 --> Total execution time: 6.2364
DEBUG - 2022-11-22 07:44:04 --> Total execution time: 0.2897
DEBUG - 2022-11-22 07:44:10 --> Total execution time: 0.1860
DEBUG - 2022-11-22 07:44:19 --> Total execution time: 0.1853
DEBUG - 2022-11-22 07:46:46 --> Total execution time: 3.6566
DEBUG - 2022-11-22 07:46:49 --> Total execution time: 0.1752
DEBUG - 2022-11-22 07:46:58 --> Total execution time: 0.7384
DEBUG - 2022-11-22 07:47:05 --> Total execution time: 0.2542
DEBUG - 2022-11-22 07:47:21 --> Total execution time: 0.1781
DEBUG - 2022-11-22 07:47:51 --> Total execution time: 0.1869
DEBUG - 2022-11-22 07:48:54 --> Total execution time: 0.1200
DEBUG - 2022-11-22 07:49:26 --> Total execution time: 0.1955
DEBUG - 2022-11-22 07:50:18 --> Total execution time: 0.2211
DEBUG - 2022-11-22 07:50:18 --> Total execution time: 0.1528
DEBUG - 2022-11-22 07:50:24 --> Total execution time: 0.1921
DEBUG - 2022-11-22 07:50:29 --> Total execution time: 0.2076
DEBUG - 2022-11-22 07:51:19 --> Total execution time: 0.1732
DEBUG - 2022-11-22 07:54:21 --> Total execution time: 0.2166
DEBUG - 2022-11-22 07:55:29 --> Total execution time: 3.3117
DEBUG - 2022-11-22 07:56:15 --> Total execution time: 2.0943
DEBUG - 2022-11-22 07:56:59 --> Total execution time: 0.3801
DEBUG - 2022-11-22 07:57:41 --> Total execution time: 4.1137
DEBUG - 2022-11-22 07:58:47 --> Total execution time: 2.6490
DEBUG - 2022-11-22 08:02:37 --> Total execution time: 0.5539
DEBUG - 2022-11-22 08:02:45 --> Total execution time: 0.1099
DEBUG - 2022-11-22 08:03:12 --> Total execution time: 0.2324
DEBUG - 2022-11-22 08:03:37 --> Total execution time: 0.1942
DEBUG - 2022-11-22 08:08:11 --> Total execution time: 0.8155
DEBUG - 2022-11-22 08:11:21 --> Total execution time: 0.2089
DEBUG - 2022-11-22 08:11:49 --> Total execution time: 0.2229
DEBUG - 2022-11-22 08:13:35 --> Total execution time: 0.1455
DEBUG - 2022-11-22 08:13:37 --> Total execution time: 0.1128
DEBUG - 2022-11-22 08:14:24 --> Total execution time: 0.1319
DEBUG - 2022-11-22 08:14:31 --> Total execution time: 0.1956
DEBUG - 2022-11-22 08:14:46 --> Total execution time: 0.1911
DEBUG - 2022-11-22 08:14:51 --> Total execution time: 0.1854
DEBUG - 2022-11-22 08:14:57 --> Total execution time: 0.1134
DEBUG - 2022-11-22 08:14:58 --> Total execution time: 0.2662
DEBUG - 2022-11-22 08:15:01 --> Total execution time: 0.1260
DEBUG - 2022-11-22 08:15:03 --> Total execution time: 0.1113
DEBUG - 2022-11-22 08:15:03 --> Total execution time: 0.1358
DEBUG - 2022-11-22 08:15:04 --> Total execution time: 0.2552
DEBUG - 2022-11-22 08:15:08 --> Total execution time: 0.1787
DEBUG - 2022-11-22 08:15:19 --> Total execution time: 0.1873
DEBUG - 2022-11-22 08:15:21 --> Total execution time: 0.1954
DEBUG - 2022-11-22 08:15:23 --> Total execution time: 0.1788
DEBUG - 2022-11-22 08:16:23 --> Total execution time: 0.1829
DEBUG - 2022-11-22 08:18:30 --> Total execution time: 0.1108
DEBUG - 2022-11-22 08:18:47 --> Total execution time: 0.1075
DEBUG - 2022-11-22 08:20:49 --> Total execution time: 0.1756
DEBUG - 2022-11-22 08:22:44 --> Total execution time: 0.1777
DEBUG - 2022-11-22 08:23:32 --> Total execution time: 0.1177
DEBUG - 2022-11-22 08:24:36 --> Total execution time: 0.1185
DEBUG - 2022-11-22 08:25:40 --> Total execution time: 0.6106
DEBUG - 2022-11-22 08:26:18 --> Total execution time: 0.3861
DEBUG - 2022-11-22 08:26:26 --> Total execution time: 0.2278
DEBUG - 2022-11-22 08:26:33 --> Total execution time: 0.2283
DEBUG - 2022-11-22 08:26:33 --> Total execution time: 0.1874
DEBUG - 2022-11-22 08:26:34 --> Total execution time: 0.2093
DEBUG - 2022-11-22 08:26:35 --> Total execution time: 0.5036
DEBUG - 2022-11-22 08:26:42 --> Total execution time: 0.1801
DEBUG - 2022-11-22 08:26:48 --> Total execution time: 0.1823
DEBUG - 2022-11-22 08:26:57 --> Total execution time: 0.1877
DEBUG - 2022-11-22 08:27:03 --> Total execution time: 0.2132
DEBUG - 2022-11-22 08:27:13 --> Total execution time: 0.1827
DEBUG - 2022-11-22 08:27:26 --> Total execution time: 0.1842
DEBUG - 2022-11-22 08:27:28 --> Total execution time: 0.1823
DEBUG - 2022-11-22 08:27:34 --> Total execution time: 0.1862
DEBUG - 2022-11-22 08:27:53 --> Total execution time: 0.1184
DEBUG - 2022-11-22 08:27:53 --> Total execution time: 0.1542
DEBUG - 2022-11-22 08:27:55 --> Total execution time: 0.1061
DEBUG - 2022-11-22 08:27:55 --> Total execution time: 0.0997
DEBUG - 2022-11-22 08:27:56 --> Total execution time: 0.1662
DEBUG - 2022-11-22 08:27:56 --> Total execution time: 0.1775
DEBUG - 2022-11-22 08:27:57 --> Total execution time: 0.1853
DEBUG - 2022-11-22 08:27:58 --> Total execution time: 0.1703
DEBUG - 2022-11-22 08:27:58 --> Total execution time: 0.1732
DEBUG - 2022-11-22 08:27:59 --> Total execution time: 0.1722
DEBUG - 2022-11-22 08:28:20 --> Total execution time: 0.1909
DEBUG - 2022-11-22 08:28:35 --> Total execution time: 0.1881
DEBUG - 2022-11-22 08:30:02 --> Total execution time: 0.2201
DEBUG - 2022-11-22 08:30:47 --> Total execution time: 0.1340
DEBUG - 2022-11-22 08:38:40 --> Total execution time: 1.0780
DEBUG - 2022-11-22 08:42:13 --> Total execution time: 0.1815
DEBUG - 2022-11-22 08:52:08 --> Total execution time: 0.6305
DEBUG - 2022-11-22 08:52:15 --> Total execution time: 0.1877
DEBUG - 2022-11-22 08:52:22 --> Total execution time: 0.2163
DEBUG - 2022-11-22 08:52:30 --> Total execution time: 0.3034
DEBUG - 2022-11-22 08:52:41 --> Total execution time: 0.3320
DEBUG - 2022-11-22 08:53:17 --> Total execution time: 0.2578
DEBUG - 2022-11-22 08:53:17 --> Total execution time: 0.3332
DEBUG - 2022-11-22 08:56:45 --> Total execution time: 0.4624
DEBUG - 2022-11-22 09:01:32 --> Total execution time: 0.2454
DEBUG - 2022-11-22 09:03:17 --> Total execution time: 0.1942
DEBUG - 2022-11-22 09:03:45 --> Total execution time: 0.1824
DEBUG - 2022-11-22 09:03:59 --> Total execution time: 0.2061
DEBUG - 2022-11-22 09:04:06 --> Total execution time: 0.1766
DEBUG - 2022-11-22 09:04:23 --> Total execution time: 0.2392
DEBUG - 2022-11-22 09:04:38 --> Total execution time: 0.2029
DEBUG - 2022-11-22 09:05:04 --> Total execution time: 0.1192
DEBUG - 2022-11-22 09:07:21 --> Total execution time: 0.1171
DEBUG - 2022-11-22 09:07:28 --> Total execution time: 0.1178
DEBUG - 2022-11-22 09:07:59 --> Total execution time: 0.2359
DEBUG - 2022-11-22 09:08:03 --> Total execution time: 0.4634
DEBUG - 2022-11-22 09:08:19 --> Total execution time: 2.6800
DEBUG - 2022-11-22 09:08:20 --> Total execution time: 0.1900
DEBUG - 2022-11-22 09:08:25 --> Total execution time: 0.2120
DEBUG - 2022-11-22 09:08:37 --> Total execution time: 0.2030
DEBUG - 2022-11-22 09:08:55 --> Total execution time: 0.2439
DEBUG - 2022-11-22 09:09:34 --> Total execution time: 0.1199
DEBUG - 2022-11-22 09:10:20 --> Total execution time: 0.1942
DEBUG - 2022-11-22 09:10:28 --> Total execution time: 0.1106
DEBUG - 2022-11-22 09:10:32 --> Total execution time: 0.1918
DEBUG - 2022-11-22 09:10:39 --> Total execution time: 0.1784
DEBUG - 2022-11-22 09:13:24 --> Total execution time: 1.0229
DEBUG - 2022-11-22 09:15:26 --> Total execution time: 0.1979
DEBUG - 2022-11-22 09:16:14 --> Total execution time: 0.1854
DEBUG - 2022-11-22 09:16:31 --> Total execution time: 0.1989
DEBUG - 2022-11-22 09:19:07 --> Total execution time: 0.2294
DEBUG - 2022-11-22 09:19:22 --> Total execution time: 0.1901
DEBUG - 2022-11-22 09:19:47 --> Total execution time: 0.1898
DEBUG - 2022-11-22 09:22:39 --> Total execution time: 0.2156
DEBUG - 2022-11-22 09:22:39 --> Total execution time: 0.1155
DEBUG - 2022-11-22 09:23:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 09:23:10 --> Total execution time: 0.2198
DEBUG - 2022-11-22 09:25:24 --> Total execution time: 0.5588
DEBUG - 2022-11-22 09:27:21 --> Total execution time: 0.8994
DEBUG - 2022-11-22 09:27:34 --> Total execution time: 0.1061
DEBUG - 2022-11-22 09:30:02 --> Total execution time: 0.2051
DEBUG - 2022-11-22 09:32:08 --> Total execution time: 0.1259
DEBUG - 2022-11-22 09:32:09 --> Total execution time: 0.1125
DEBUG - 2022-11-22 09:33:06 --> Total execution time: 0.1147
DEBUG - 2022-11-22 09:33:12 --> Total execution time: 0.1777
DEBUG - 2022-11-22 09:34:03 --> Total execution time: 0.1691
DEBUG - 2022-11-22 09:34:10 --> Total execution time: 0.1202
DEBUG - 2022-11-22 09:34:13 --> Total execution time: 2.4385
DEBUG - 2022-11-22 09:35:04 --> Total execution time: 0.1118
DEBUG - 2022-11-22 09:35:04 --> Total execution time: 0.1239
DEBUG - 2022-11-22 09:35:06 --> Total execution time: 0.1149
DEBUG - 2022-11-22 09:35:07 --> Total execution time: 0.1134
DEBUG - 2022-11-22 09:36:28 --> Total execution time: 1.6657
DEBUG - 2022-11-22 09:36:30 --> Total execution time: 0.1741
DEBUG - 2022-11-22 09:36:31 --> Total execution time: 0.0998
DEBUG - 2022-11-22 09:38:28 --> Total execution time: 0.2844
DEBUG - 2022-11-22 09:38:43 --> Total execution time: 0.2144
DEBUG - 2022-11-22 09:38:51 --> Total execution time: 0.2188
DEBUG - 2022-11-22 09:38:56 --> Total execution time: 0.2205
DEBUG - 2022-11-22 09:39:57 --> Total execution time: 0.2295
DEBUG - 2022-11-22 09:40:14 --> Total execution time: 0.2134
DEBUG - 2022-11-22 09:40:56 --> Total execution time: 0.2389
DEBUG - 2022-11-22 09:41:00 --> Total execution time: 0.2351
DEBUG - 2022-11-22 09:41:04 --> Total execution time: 0.2153
DEBUG - 2022-11-22 09:41:08 --> Total execution time: 0.2147
DEBUG - 2022-11-22 09:41:09 --> Total execution time: 0.2065
DEBUG - 2022-11-22 09:41:11 --> Total execution time: 0.1917
DEBUG - 2022-11-22 09:41:13 --> Total execution time: 0.1743
DEBUG - 2022-11-22 09:41:17 --> Total execution time: 0.2107
DEBUG - 2022-11-22 09:41:25 --> Total execution time: 0.1828
DEBUG - 2022-11-22 09:47:01 --> Total execution time: 1.1554
DEBUG - 2022-11-22 09:51:08 --> Total execution time: 0.2570
DEBUG - 2022-11-22 09:51:29 --> Total execution time: 0.2227
DEBUG - 2022-11-22 09:52:09 --> Total execution time: 0.4766
DEBUG - 2022-11-22 09:55:59 --> Total execution time: 1.1289
DEBUG - 2022-11-22 09:56:13 --> Total execution time: 0.1887
DEBUG - 2022-11-22 09:57:51 --> Total execution time: 1.1780
DEBUG - 2022-11-22 09:58:24 --> Total execution time: 1.2359
DEBUG - 2022-11-22 09:58:28 --> Total execution time: 0.1926
DEBUG - 2022-11-22 09:58:36 --> Total execution time: 0.1819
DEBUG - 2022-11-22 09:58:40 --> Total execution time: 0.1912
DEBUG - 2022-11-22 09:58:46 --> Total execution time: 0.1835
DEBUG - 2022-11-22 09:58:50 --> Total execution time: 0.1859
DEBUG - 2022-11-22 09:59:33 --> Total execution time: 0.1853
DEBUG - 2022-11-22 09:59:43 --> Total execution time: 0.1968
DEBUG - 2022-11-22 09:59:55 --> Total execution time: 0.1827
DEBUG - 2022-11-22 09:59:59 --> Total execution time: 0.1787
DEBUG - 2022-11-22 10:00:04 --> Total execution time: 0.2877
DEBUG - 2022-11-22 10:00:36 --> Total execution time: 0.1795
DEBUG - 2022-11-22 10:00:52 --> Total execution time: 0.2210
DEBUG - 2022-11-22 10:01:12 --> Total execution time: 0.2020
DEBUG - 2022-11-22 10:01:33 --> Total execution time: 0.2062
DEBUG - 2022-11-22 10:02:07 --> Total execution time: 0.3491
DEBUG - 2022-11-22 10:02:09 --> Total execution time: 0.2231
DEBUG - 2022-11-22 10:02:16 --> Total execution time: 0.1802
DEBUG - 2022-11-22 10:02:20 --> Total execution time: 0.1824
DEBUG - 2022-11-22 10:02:30 --> Total execution time: 0.1912
DEBUG - 2022-11-22 10:03:28 --> Total execution time: 0.2136
DEBUG - 2022-11-22 10:05:11 --> Total execution time: 0.8250
DEBUG - 2022-11-22 10:05:31 --> Total execution time: 0.2096
DEBUG - 2022-11-22 10:05:46 --> Total execution time: 0.1425
DEBUG - 2022-11-22 10:06:32 --> Total execution time: 0.1279
DEBUG - 2022-11-22 10:07:27 --> Total execution time: 0.1649
DEBUG - 2022-11-22 10:07:56 --> Total execution time: 0.2379
DEBUG - 2022-11-22 10:08:02 --> Total execution time: 0.2102
DEBUG - 2022-11-22 10:08:13 --> Total execution time: 0.2037
DEBUG - 2022-11-22 10:08:37 --> Total execution time: 0.1883
DEBUG - 2022-11-22 10:09:38 --> Total execution time: 0.2077
DEBUG - 2022-11-22 10:09:47 --> Total execution time: 0.2203
DEBUG - 2022-11-22 10:09:56 --> Total execution time: 0.1887
DEBUG - 2022-11-22 10:10:01 --> Total execution time: 0.2643
DEBUG - 2022-11-22 10:11:04 --> Total execution time: 0.6311
DEBUG - 2022-11-22 10:11:10 --> Total execution time: 0.2040
DEBUG - 2022-11-22 10:11:13 --> Total execution time: 0.1882
DEBUG - 2022-11-22 10:11:14 --> Total execution time: 0.1796
DEBUG - 2022-11-22 10:11:22 --> Total execution time: 0.2232
DEBUG - 2022-11-22 10:11:36 --> Total execution time: 0.1744
DEBUG - 2022-11-22 10:11:59 --> Total execution time: 0.1568
DEBUG - 2022-11-22 10:14:26 --> Total execution time: 0.2140
DEBUG - 2022-11-22 10:14:28 --> Total execution time: 0.6701
DEBUG - 2022-11-22 10:14:30 --> Total execution time: 0.1883
DEBUG - 2022-11-22 10:14:33 --> Total execution time: 0.1725
DEBUG - 2022-11-22 10:15:00 --> Total execution time: 0.1881
DEBUG - 2022-11-22 10:17:17 --> Total execution time: 0.2385
DEBUG - 2022-11-22 10:17:21 --> Total execution time: 0.3787
DEBUG - 2022-11-22 10:17:22 --> Total execution time: 0.2450
DEBUG - 2022-11-22 10:17:24 --> Total execution time: 0.2047
DEBUG - 2022-11-22 10:17:29 --> Total execution time: 0.2690
DEBUG - 2022-11-22 10:19:17 --> Total execution time: 0.1233
DEBUG - 2022-11-22 10:30:06 --> Total execution time: 3.2154
DEBUG - 2022-11-22 10:33:37 --> Total execution time: 0.1920
DEBUG - 2022-11-22 10:42:47 --> Total execution time: 1.2893
DEBUG - 2022-11-22 10:42:53 --> Total execution time: 0.1175
DEBUG - 2022-11-22 10:42:56 --> Total execution time: 0.1955
DEBUG - 2022-11-22 10:43:06 --> Total execution time: 0.2972
DEBUG - 2022-11-22 10:43:21 --> Total execution time: 0.2760
DEBUG - 2022-11-22 10:47:58 --> Total execution time: 0.1314
DEBUG - 2022-11-22 10:50:29 --> Total execution time: 0.6659
DEBUG - 2022-11-22 10:50:33 --> Total execution time: 0.1755
DEBUG - 2022-11-22 10:50:38 --> Total execution time: 0.2021
DEBUG - 2022-11-22 10:50:45 --> Total execution time: 0.2026
DEBUG - 2022-11-22 10:50:50 --> Total execution time: 0.1941
DEBUG - 2022-11-22 10:53:42 --> Total execution time: 1.9098
DEBUG - 2022-11-22 10:54:44 --> Total execution time: 5.7623
DEBUG - 2022-11-22 10:58:30 --> Total execution time: 4.1003
DEBUG - 2022-11-22 10:58:44 --> Total execution time: 0.2397
DEBUG - 2022-11-22 10:58:56 --> Total execution time: 0.3054
DEBUG - 2022-11-22 10:59:13 --> Total execution time: 0.2087
DEBUG - 2022-11-22 10:59:14 --> Total execution time: 0.1992
DEBUG - 2022-11-22 10:59:22 --> Total execution time: 0.1999
DEBUG - 2022-11-22 10:59:32 --> Total execution time: 0.2210
DEBUG - 2022-11-22 10:59:43 --> Total execution time: 0.1975
DEBUG - 2022-11-22 10:59:48 --> Total execution time: 0.2899
DEBUG - 2022-11-22 10:59:57 --> Total execution time: 0.2011
DEBUG - 2022-11-22 11:00:02 --> Total execution time: 0.5287
DEBUG - 2022-11-22 11:00:03 --> Total execution time: 1.1144
DEBUG - 2022-11-22 11:00:13 --> Total execution time: 0.1800
DEBUG - 2022-11-22 11:01:44 --> Total execution time: 0.2143
DEBUG - 2022-11-22 11:01:52 --> Total execution time: 0.1943
DEBUG - 2022-11-22 11:03:16 --> Total execution time: 0.4948
DEBUG - 2022-11-22 11:03:16 --> Total execution time: 0.7883
DEBUG - 2022-11-22 11:03:18 --> Total execution time: 0.4210
DEBUG - 2022-11-22 11:03:23 --> Total execution time: 0.2441
DEBUG - 2022-11-22 11:03:30 --> Total execution time: 0.2152
DEBUG - 2022-11-22 11:04:04 --> Total execution time: 0.1814
DEBUG - 2022-11-22 11:06:33 --> Total execution time: 0.1806
DEBUG - 2022-11-22 11:06:43 --> Total execution time: 0.3267
DEBUG - 2022-11-22 11:07:10 --> Total execution time: 0.1955
DEBUG - 2022-11-22 11:07:25 --> Total execution time: 0.1908
DEBUG - 2022-11-22 11:07:39 --> Total execution time: 0.2554
DEBUG - 2022-11-22 11:08:05 --> Total execution time: 0.3416
DEBUG - 2022-11-22 11:08:42 --> Total execution time: 0.1224
DEBUG - 2022-11-22 11:08:56 --> Total execution time: 0.1295
DEBUG - 2022-11-22 11:09:04 --> Total execution time: 0.2015
DEBUG - 2022-11-22 11:09:07 --> Total execution time: 0.2059
DEBUG - 2022-11-22 11:09:07 --> Total execution time: 0.1828
DEBUG - 2022-11-22 11:09:13 --> Total execution time: 0.1813
DEBUG - 2022-11-22 11:09:24 --> Total execution time: 0.1977
DEBUG - 2022-11-22 11:09:29 --> Total execution time: 0.1860
DEBUG - 2022-11-22 11:09:32 --> Total execution time: 0.2062
DEBUG - 2022-11-22 11:09:33 --> Total execution time: 0.2125
DEBUG - 2022-11-22 11:09:37 --> Total execution time: 0.1916
DEBUG - 2022-11-22 11:09:57 --> Total execution time: 0.1296
DEBUG - 2022-11-22 11:13:21 --> Total execution time: 1.4242
DEBUG - 2022-11-22 11:13:32 --> Total execution time: 0.1373
DEBUG - 2022-11-22 11:13:47 --> Total execution time: 0.2114
DEBUG - 2022-11-22 11:14:19 --> Total execution time: 0.1261
DEBUG - 2022-11-22 11:14:21 --> Total execution time: 0.1172
DEBUG - 2022-11-22 11:14:31 --> Total execution time: 0.2105
DEBUG - 2022-11-22 11:14:41 --> Total execution time: 0.2827
DEBUG - 2022-11-22 11:15:09 --> Total execution time: 0.1805
DEBUG - 2022-11-22 11:15:12 --> Total execution time: 0.1898
DEBUG - 2022-11-22 11:15:20 --> Total execution time: 0.2409
DEBUG - 2022-11-22 11:15:25 --> Total execution time: 0.1431
DEBUG - 2022-11-22 11:15:50 --> Total execution time: 0.2671
DEBUG - 2022-11-22 11:16:02 --> Total execution time: 0.2551
DEBUG - 2022-11-22 11:16:03 --> Total execution time: 0.2331
DEBUG - 2022-11-22 11:16:07 --> Total execution time: 0.2359
DEBUG - 2022-11-22 11:16:13 --> Total execution time: 2.2840
DEBUG - 2022-11-22 11:16:37 --> Total execution time: 0.1840
DEBUG - 2022-11-22 11:16:44 --> Total execution time: 0.1133
DEBUG - 2022-11-22 11:16:59 --> Total execution time: 0.1817
DEBUG - 2022-11-22 11:17:23 --> Total execution time: 0.1870
DEBUG - 2022-11-22 11:17:27 --> Total execution time: 0.1789
DEBUG - 2022-11-22 11:18:06 --> Total execution time: 3.7031
DEBUG - 2022-11-22 11:18:24 --> Total execution time: 1.6741
DEBUG - 2022-11-22 11:18:29 --> Total execution time: 0.3299
DEBUG - 2022-11-22 11:18:32 --> Total execution time: 0.3986
DEBUG - 2022-11-22 11:18:41 --> Total execution time: 0.2396
DEBUG - 2022-11-22 11:18:46 --> Total execution time: 0.3380
DEBUG - 2022-11-22 11:19:57 --> Total execution time: 3.0872
DEBUG - 2022-11-22 11:20:23 --> Total execution time: 0.1755
DEBUG - 2022-11-22 11:21:17 --> Total execution time: 0.6163
DEBUG - 2022-11-22 11:21:45 --> Total execution time: 0.5081
DEBUG - 2022-11-22 11:22:59 --> Total execution time: 1.8877
DEBUG - 2022-11-22 11:23:18 --> Total execution time: 0.2060
DEBUG - 2022-11-22 11:25:17 --> Total execution time: 1.9313
DEBUG - 2022-11-22 11:25:42 --> Total execution time: 1.6989
DEBUG - 2022-11-22 11:25:46 --> Total execution time: 0.2194
DEBUG - 2022-11-22 11:25:58 --> Total execution time: 0.1716
DEBUG - 2022-11-22 11:26:05 --> Total execution time: 0.1737
DEBUG - 2022-11-22 11:26:15 --> Total execution time: 0.2085
DEBUG - 2022-11-22 11:26:32 --> Total execution time: 0.2156
DEBUG - 2022-11-22 11:26:32 --> Total execution time: 0.2662
DEBUG - 2022-11-22 11:26:34 --> Total execution time: 0.4706
DEBUG - 2022-11-22 11:26:42 --> Total execution time: 0.2006
DEBUG - 2022-11-22 11:26:56 --> Total execution time: 0.1891
DEBUG - 2022-11-22 11:27:00 --> Total execution time: 0.1140
DEBUG - 2022-11-22 11:27:00 --> Total execution time: 0.2332
DEBUG - 2022-11-22 11:27:00 --> Total execution time: 0.1395
DEBUG - 2022-11-22 11:27:01 --> Total execution time: 0.1201
DEBUG - 2022-11-22 11:27:01 --> Total execution time: 0.1757
DEBUG - 2022-11-22 11:27:01 --> Total execution time: 0.1899
DEBUG - 2022-11-22 11:27:06 --> Total execution time: 0.1850
DEBUG - 2022-11-22 11:27:09 --> Total execution time: 0.1200
DEBUG - 2022-11-22 11:27:10 --> Total execution time: 0.1935
DEBUG - 2022-11-22 11:27:10 --> Total execution time: 0.1905
DEBUG - 2022-11-22 11:27:13 --> Total execution time: 0.1112
DEBUG - 2022-11-22 11:27:21 --> Total execution time: 0.1912
DEBUG - 2022-11-22 11:28:16 --> Total execution time: 0.6411
DEBUG - 2022-11-22 11:29:02 --> Total execution time: 0.1133
DEBUG - 2022-11-22 11:29:50 --> Total execution time: 0.1321
DEBUG - 2022-11-22 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:30:03 --> Total execution time: 0.1928
DEBUG - 2022-11-22 00:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:31:55 --> Total execution time: 0.3430
DEBUG - 2022-11-22 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:01:56 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:01:57 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:01:57 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:39 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:40 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:40 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:32:40 --> Total execution time: 0.5743
DEBUG - 2022-11-22 00:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:45 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:45 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:46 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:32:46 --> Total execution time: 0.2270
DEBUG - 2022-11-22 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:47 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:47 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:02:47 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:02:59 --> Total execution time: 0.1976
DEBUG - 2022-11-22 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:01 --> Total execution time: 0.3449
DEBUG - 2022-11-22 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:01 --> Total execution time: 0.2956
DEBUG - 2022-11-22 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:01 --> Total execution time: 0.3277
DEBUG - 2022-11-22 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:01 --> Total execution time: 0.6557
DEBUG - 2022-11-22 00:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:03 --> Total execution time: 0.1961
DEBUG - 2022-11-22 00:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:03 --> Total execution time: 0.4207
DEBUG - 2022-11-22 00:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:33:15 --> Total execution time: 0.5089
DEBUG - 2022-11-22 00:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:17 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:33:18 --> Total execution time: 0.1169
DEBUG - 2022-11-22 00:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:18 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:33:19 --> Total execution time: 0.1113
DEBUG - 2022-11-22 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:36 --> Total execution time: 0.1209
DEBUG - 2022-11-22 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:37 --> Total execution time: 0.1735
DEBUG - 2022-11-22 00:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:37 --> Total execution time: 0.4123
DEBUG - 2022-11-22 00:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:33:37 --> Total execution time: 0.2282
DEBUG - 2022-11-22 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:03:48 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:03:48 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:03:48 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:33:48 --> Total execution time: 0.2437
DEBUG - 2022-11-22 00:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:51 --> Total execution time: 0.1094
DEBUG - 2022-11-22 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:53 --> Total execution time: 0.1835
DEBUG - 2022-11-22 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:03:53 --> Total execution time: 0.1734
DEBUG - 2022-11-22 00:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:15 --> Total execution time: 0.4831
DEBUG - 2022-11-22 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:18 --> Total execution time: 0.2352
DEBUG - 2022-11-22 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:04:19 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:04:19 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:04:19 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:20 --> Total execution time: 0.2024
DEBUG - 2022-11-22 00:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:30 --> Total execution time: 0.2285
DEBUG - 2022-11-22 00:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:33 --> Total execution time: 1.9917
DEBUG - 2022-11-22 00:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:04:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 00:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:43 --> Total execution time: 0.2071
DEBUG - 2022-11-22 00:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:51 --> Total execution time: 0.2239
DEBUG - 2022-11-22 00:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:34:58 --> Total execution time: 0.2265
DEBUG - 2022-11-22 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:05:00 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:05:00 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:05:00 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:03 --> Total execution time: 0.1829
DEBUG - 2022-11-22 00:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:08 --> Total execution time: 1.8449
DEBUG - 2022-11-22 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:09 --> Total execution time: 0.1768
DEBUG - 2022-11-22 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:14 --> Total execution time: 0.2112
DEBUG - 2022-11-22 00:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:17 --> Total execution time: 0.2608
DEBUG - 2022-11-22 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:28 --> Total execution time: 0.1760
DEBUG - 2022-11-22 00:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:35 --> Total execution time: 0.1851
DEBUG - 2022-11-22 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:35:55 --> Total execution time: 0.1876
DEBUG - 2022-11-22 00:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:36:16 --> Total execution time: 0.2168
DEBUG - 2022-11-22 00:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:16 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:17 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:18 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:36 --> 404 Page Not Found: Personal-branding-course/index
DEBUG - 2022-11-22 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:36:37 --> Total execution time: 0.3380
DEBUG - 2022-11-22 00:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:37 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:38 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:38 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:36:42 --> Total execution time: 0.2126
DEBUG - 2022-11-22 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:43 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:43 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:43 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:36:47 --> Total execution time: 0.2709
DEBUG - 2022-11-22 00:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:48 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:48 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:06:49 --> 404 Page Not Found: User/edit-profile
DEBUG - 2022-11-22 00:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:06:51 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:36:52 --> Total execution time: 0.1363
DEBUG - 2022-11-22 00:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:00 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:01 --> Total execution time: 0.2054
DEBUG - 2022-11-22 00:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:02 --> Total execution time: 0.2113
DEBUG - 2022-11-22 00:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:12 --> Total execution time: 0.2241
DEBUG - 2022-11-22 00:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:22 --> Total execution time: 0.1234
DEBUG - 2022-11-22 00:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:23 --> Total execution time: 0.1766
DEBUG - 2022-11-22 00:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:23 --> Total execution time: 0.4038
DEBUG - 2022-11-22 00:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:24 --> Total execution time: 0.1956
DEBUG - 2022-11-22 00:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:26 --> Total execution time: 0.2121
DEBUG - 2022-11-22 00:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:30 --> Total execution time: 0.2568
DEBUG - 2022-11-22 00:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:30 --> Total execution time: 0.2492
DEBUG - 2022-11-22 00:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:33 --> Total execution time: 0.1159
DEBUG - 2022-11-22 00:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:35 --> Total execution time: 0.1971
DEBUG - 2022-11-22 00:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:37:55 --> Total execution time: 0.2389
DEBUG - 2022-11-22 00:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:38:07 --> Total execution time: 0.4766
DEBUG - 2022-11-22 00:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:38:09 --> Total execution time: 0.2057
DEBUG - 2022-11-22 00:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:11 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-11-22 00:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:11 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-11-22 00:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:12 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-11-22 00:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:38:12 --> Total execution time: 0.2482
DEBUG - 2022-11-22 00:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:38:18 --> Total execution time: 0.2641
DEBUG - 2022-11-22 00:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:19 --> 404 Page Not Found: User/dashboard
DEBUG - 2022-11-22 00:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:19 --> 404 Page Not Found: User/dashboard
DEBUG - 2022-11-22 00:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:20 --> 404 Page Not Found: User/dashboard
DEBUG - 2022-11-22 00:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:32 --> 404 Page Not Found: User/my-courses
DEBUG - 2022-11-22 00:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:32 --> 404 Page Not Found: User/my-courses
DEBUG - 2022-11-22 00:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:08:32 --> 404 Page Not Found: User/my-courses
DEBUG - 2022-11-22 00:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:38:32 --> Total execution time: 0.2586
DEBUG - 2022-11-22 00:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:38:35 --> Total execution time: 0.1388
DEBUG - 2022-11-22 00:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:39:06 --> Total execution time: 0.6142
DEBUG - 2022-11-22 00:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:39:19 --> Total execution time: 0.3919
DEBUG - 2022-11-22 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:28 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:39:28 --> Total execution time: 0.1686
DEBUG - 2022-11-22 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:09:40 --> Total execution time: 0.2193
DEBUG - 2022-11-22 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:09:43 --> Total execution time: 0.3402
DEBUG - 2022-11-22 00:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:09:44 --> Total execution time: 0.9897
DEBUG - 2022-11-22 00:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:39:58 --> Total execution time: 0.1781
DEBUG - 2022-11-22 00:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:01 --> Total execution time: 0.2084
DEBUG - 2022-11-22 00:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:13 --> Total execution time: 0.8913
DEBUG - 2022-11-22 00:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:21 --> Total execution time: 0.4921
DEBUG - 2022-11-22 00:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:36 --> Total execution time: 0.6611
DEBUG - 2022-11-22 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:43 --> Total execution time: 0.8831
DEBUG - 2022-11-22 00:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:51 --> Total execution time: 0.2195
DEBUG - 2022-11-22 00:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:57 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:57 --> Total execution time: 0.1373
DEBUG - 2022-11-22 00:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:10:59 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:40:59 --> Total execution time: 0.1105
DEBUG - 2022-11-22 00:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:41:22 --> Total execution time: 0.1341
DEBUG - 2022-11-22 00:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:41:50 --> Total execution time: 0.2160
DEBUG - 2022-11-22 00:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:41:51 --> Total execution time: 0.3320
DEBUG - 2022-11-22 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:42:02 --> Total execution time: 0.6083
DEBUG - 2022-11-22 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:42:05 --> Total execution time: 0.1971
DEBUG - 2022-11-22 00:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:43:07 --> Total execution time: 3.2885
DEBUG - 2022-11-22 00:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:43:10 --> Total execution time: 0.5410
DEBUG - 2022-11-22 00:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:43:23 --> Total execution time: 0.3184
DEBUG - 2022-11-22 00:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:43:31 --> Total execution time: 0.2867
DEBUG - 2022-11-22 00:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:43:45 --> Total execution time: 0.4099
DEBUG - 2022-11-22 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:44:31 --> Total execution time: 0.2169
DEBUG - 2022-11-22 00:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:44:55 --> Total execution time: 0.3515
DEBUG - 2022-11-22 00:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:44:59 --> Total execution time: 0.1848
DEBUG - 2022-11-22 00:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:45:15 --> Total execution time: 0.2264
DEBUG - 2022-11-22 00:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:47:04 --> Total execution time: 0.6892
DEBUG - 2022-11-22 00:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:47:05 --> Total execution time: 0.2035
DEBUG - 2022-11-22 00:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:47:07 --> Total execution time: 0.1881
DEBUG - 2022-11-22 00:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:18:22 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-11-22 00:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:23:40 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:53:40 --> Total execution time: 0.6623
DEBUG - 2022-11-22 00:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:23:41 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:53:41 --> Total execution time: 0.1271
DEBUG - 2022-11-22 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:54:24 --> Total execution time: 2.8926
DEBUG - 2022-11-22 00:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:54:37 --> Total execution time: 0.1593
DEBUG - 2022-11-22 00:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:54:46 --> Total execution time: 0.4016
DEBUG - 2022-11-22 00:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:54:54 --> Total execution time: 0.2667
DEBUG - 2022-11-22 00:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:24:56 --> 404 Page Not Found: Nwt-last-lululemon-all-your-small-things-mini-pouch-bag-highlight-yellow-1037671html/index
DEBUG - 2022-11-22 00:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:55:09 --> Total execution time: 0.2320
DEBUG - 2022-11-22 00:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:55:10 --> Total execution time: 0.2214
DEBUG - 2022-11-22 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:26 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:26 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:55:26 --> Total execution time: 0.1224
DEBUG - 2022-11-22 11:55:26 --> Total execution time: 0.1191
DEBUG - 2022-11-22 00:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:55:34 --> Total execution time: 0.2477
DEBUG - 2022-11-22 00:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:55:38 --> Total execution time: 0.2851
DEBUG - 2022-11-22 00:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:55:38 --> Total execution time: 0.2131
DEBUG - 2022-11-22 00:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:27:00 --> Total execution time: 0.1262
DEBUG - 2022-11-22 00:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:57:40 --> Total execution time: 0.2076
DEBUG - 2022-11-22 00:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:57:57 --> Total execution time: 0.2019
DEBUG - 2022-11-22 00:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:58:04 --> Total execution time: 0.2858
DEBUG - 2022-11-22 00:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 11:58:29 --> Total execution time: 0.1795
DEBUG - 2022-11-22 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:02:53 --> Total execution time: 0.2222
DEBUG - 2022-11-22 00:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:02:56 --> Total execution time: 0.1761
DEBUG - 2022-11-22 00:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:03 --> Total execution time: 0.1763
DEBUG - 2022-11-22 00:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:07 --> Total execution time: 0.1940
DEBUG - 2022-11-22 00:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:25 --> Total execution time: 0.2073
DEBUG - 2022-11-22 00:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:29 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:29 --> Total execution time: 0.1730
DEBUG - 2022-11-22 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:31 --> Total execution time: 0.2762
DEBUG - 2022-11-22 00:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:38 --> Total execution time: 0.1701
DEBUG - 2022-11-22 00:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:40 --> Total execution time: 0.1957
DEBUG - 2022-11-22 00:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:03:55 --> Total execution time: 0.2233
DEBUG - 2022-11-22 00:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:04:11 --> Total execution time: 0.1952
DEBUG - 2022-11-22 00:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:04:20 --> Total execution time: 0.2329
DEBUG - 2022-11-22 00:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:39:41 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:09:46 --> Total execution time: 5.0116
DEBUG - 2022-11-22 00:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:42:38 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:12:42 --> Total execution time: 3.6180
DEBUG - 2022-11-22 00:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:12:45 --> Total execution time: 0.2035
DEBUG - 2022-11-22 00:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:13:47 --> Total execution time: 4.1617
DEBUG - 2022-11-22 00:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 00:44:57 --> 404 Page Not Found: Fossil-green-leather-crossbody-bag-813886html/index
DEBUG - 2022-11-22 00:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:15:03 --> Total execution time: 57.7748
DEBUG - 2022-11-22 00:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:15:04 --> Total execution time: 0.8827
DEBUG - 2022-11-22 00:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:17:12 --> Total execution time: 1.1017
DEBUG - 2022-11-22 00:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:47:42 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:17:42 --> Total execution time: 0.1559
DEBUG - 2022-11-22 00:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 00:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:22:00 --> Total execution time: 0.1792
DEBUG - 2022-11-22 00:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:54:31 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:24:32 --> Total execution time: 0.9090
DEBUG - 2022-11-22 00:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:24:56 --> Total execution time: 0.5495
DEBUG - 2022-11-22 00:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 00:57:51 --> No URI present. Default controller set.
DEBUG - 2022-11-22 00:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 00:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:27:52 --> Total execution time: 0.6757
DEBUG - 2022-11-22 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:30:04 --> Total execution time: 1.8174
DEBUG - 2022-11-22 01:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 01:02:50 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-22 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:02:51 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:32:52 --> Total execution time: 0.8344
DEBUG - 2022-11-22 01:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:03:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:33:45 --> Total execution time: 0.5431
DEBUG - 2022-11-22 01:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:33:50 --> Total execution time: 0.1159
DEBUG - 2022-11-22 01:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:34:26 --> Total execution time: 0.5374
DEBUG - 2022-11-22 01:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:37:33 --> Total execution time: 3.8513
DEBUG - 2022-11-22 01:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:38:25 --> Total execution time: 0.1786
DEBUG - 2022-11-22 01:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:38:54 --> Total execution time: 0.1678
DEBUG - 2022-11-22 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:08:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:38:56 --> Total execution time: 0.1293
DEBUG - 2022-11-22 01:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:39:02 --> Total execution time: 0.1835
DEBUG - 2022-11-22 01:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:39:11 --> Total execution time: 0.2169
DEBUG - 2022-11-22 01:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:39:19 --> Total execution time: 0.1743
DEBUG - 2022-11-22 01:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:40:01 --> Total execution time: 0.2767
DEBUG - 2022-11-22 01:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:43:28 --> Total execution time: 1.2638
DEBUG - 2022-11-22 01:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:43:56 --> Total execution time: 0.2134
DEBUG - 2022-11-22 01:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:44:11 --> Total execution time: 0.2536
DEBUG - 2022-11-22 01:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:44:34 --> Total execution time: 0.2019
DEBUG - 2022-11-22 01:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:45:08 --> Total execution time: 0.2411
DEBUG - 2022-11-22 01:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:45:08 --> Total execution time: 0.1299
DEBUG - 2022-11-22 01:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:45:10 --> Total execution time: 0.1708
DEBUG - 2022-11-22 01:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:45:18 --> Total execution time: 0.1749
DEBUG - 2022-11-22 01:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:46:07 --> Total execution time: 3.1868
DEBUG - 2022-11-22 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:46:08 --> Total execution time: 0.1912
DEBUG - 2022-11-22 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:46:10 --> Total execution time: 0.2353
DEBUG - 2022-11-22 01:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:46:11 --> Total execution time: 0.1876
DEBUG - 2022-11-22 01:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:46:29 --> Total execution time: 0.3830
DEBUG - 2022-11-22 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:10 --> Total execution time: 2.2741
DEBUG - 2022-11-22 01:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:19 --> Total execution time: 0.4313
DEBUG - 2022-11-22 01:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:25 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:25 --> Total execution time: 0.1226
DEBUG - 2022-11-22 01:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:28 --> Total execution time: 0.3689
DEBUG - 2022-11-22 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:43 --> Total execution time: 0.1219
DEBUG - 2022-11-22 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:45 --> Total execution time: 0.1883
DEBUG - 2022-11-22 01:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:51 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:48:51 --> Total execution time: 0.1736
DEBUG - 2022-11-22 01:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:19:00 --> Total execution time: 0.1659
DEBUG - 2022-11-22 01:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:19:03 --> Total execution time: 0.1744
DEBUG - 2022-11-22 01:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:19:04 --> Total execution time: 0.4706
DEBUG - 2022-11-22 01:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:07 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:49:07 --> Total execution time: 0.1718
DEBUG - 2022-11-22 01:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 01:19:08 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 01:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:49:19 --> Total execution time: 0.1755
DEBUG - 2022-11-22 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:49:37 --> Total execution time: 0.1743
DEBUG - 2022-11-22 01:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:49:44 --> Total execution time: 0.1958
DEBUG - 2022-11-22 01:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:49:50 --> Total execution time: 0.1844
DEBUG - 2022-11-22 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:20:11 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:50:12 --> Total execution time: 0.6139
DEBUG - 2022-11-22 01:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:50:44 --> Total execution time: 0.2577
DEBUG - 2022-11-22 01:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:50:54 --> Total execution time: 0.1823
DEBUG - 2022-11-22 01:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:56:50 --> Total execution time: 0.1741
DEBUG - 2022-11-22 01:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:27:29 --> Total execution time: 0.1996
DEBUG - 2022-11-22 01:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:27:33 --> Total execution time: 0.2569
DEBUG - 2022-11-22 01:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:27:33 --> Total execution time: 0.1838
DEBUG - 2022-11-22 01:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 01:27:45 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-22 01:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:58:14 --> Total execution time: 0.1908
DEBUG - 2022-11-22 01:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:58:23 --> Total execution time: 0.1785
DEBUG - 2022-11-22 01:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:28:24 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 12:58:24 --> Total execution time: 0.2101
DEBUG - 2022-11-22 01:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:03:09 --> Total execution time: 0.7566
DEBUG - 2022-11-22 01:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:07:57 --> Total execution time: 4.7927
DEBUG - 2022-11-22 01:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:08:22 --> Total execution time: 0.2559
DEBUG - 2022-11-22 01:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:08:56 --> Total execution time: 0.1101
DEBUG - 2022-11-22 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:09:32 --> Total execution time: 0.1814
DEBUG - 2022-11-22 01:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:39:55 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:09:55 --> Total execution time: 0.1114
DEBUG - 2022-11-22 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:10:15 --> Total execution time: 0.1960
DEBUG - 2022-11-22 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:25 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:10:25 --> Total execution time: 0.1770
DEBUG - 2022-11-22 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:10:37 --> Total execution time: 0.1804
DEBUG - 2022-11-22 01:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:10:43 --> Total execution time: 0.1838
DEBUG - 2022-11-22 01:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:10:47 --> Total execution time: 0.2779
DEBUG - 2022-11-22 01:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:10:55 --> Total execution time: 0.2145
DEBUG - 2022-11-22 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:11:06 --> Total execution time: 0.2590
DEBUG - 2022-11-22 01:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:11:21 --> Total execution time: 0.1724
DEBUG - 2022-11-22 01:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:11:32 --> Total execution time: 0.1740
DEBUG - 2022-11-22 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:11:39 --> Total execution time: 0.1791
DEBUG - 2022-11-22 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:11:46 --> Total execution time: 0.2337
DEBUG - 2022-11-22 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:11:52 --> Total execution time: 0.2610
DEBUG - 2022-11-22 01:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:00 --> Total execution time: 0.1846
DEBUG - 2022-11-22 01:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:00 --> Total execution time: 0.1731
DEBUG - 2022-11-22 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:03 --> Total execution time: 0.2105
DEBUG - 2022-11-22 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:13 --> Total execution time: 0.1698
DEBUG - 2022-11-22 01:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:22 --> Total execution time: 0.2397
DEBUG - 2022-11-22 01:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:26 --> Total execution time: 0.1995
DEBUG - 2022-11-22 01:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:33 --> Total execution time: 0.2049
DEBUG - 2022-11-22 01:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:36 --> Total execution time: 0.2120
DEBUG - 2022-11-22 01:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:45 --> Total execution time: 0.2929
DEBUG - 2022-11-22 01:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:46 --> Total execution time: 0.1799
DEBUG - 2022-11-22 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:12:54 --> Total execution time: 0.1768
DEBUG - 2022-11-22 01:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:13:03 --> Total execution time: 0.3248
DEBUG - 2022-11-22 01:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:13:10 --> Total execution time: 0.2091
DEBUG - 2022-11-22 01:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:43:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:13:21 --> Total execution time: 0.2243
DEBUG - 2022-11-22 01:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:12 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:12 --> Total execution time: 0.4204
DEBUG - 2022-11-22 01:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:17 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:17 --> Total execution time: 0.1791
DEBUG - 2022-11-22 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:19 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:19 --> Total execution time: 0.1779
DEBUG - 2022-11-22 01:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:21 --> Total execution time: 0.1901
DEBUG - 2022-11-22 01:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:22 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:22 --> Total execution time: 0.3243
DEBUG - 2022-11-22 01:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:31 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:31 --> Total execution time: 0.2833
DEBUG - 2022-11-22 01:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:46 --> Total execution time: 0.1901
DEBUG - 2022-11-22 01:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:44:58 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:14:58 --> Total execution time: 0.4717
DEBUG - 2022-11-22 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:45:11 --> Total execution time: 0.2727
DEBUG - 2022-11-22 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:45:13 --> Total execution time: 0.2476
DEBUG - 2022-11-22 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:45:13 --> Total execution time: 0.2100
DEBUG - 2022-11-22 01:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 01:48:27 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-22 01:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:48:27 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:18:28 --> Total execution time: 0.7087
DEBUG - 2022-11-22 01:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:19:59 --> Total execution time: 1.2023
DEBUG - 2022-11-22 01:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:20:35 --> Total execution time: 0.1940
DEBUG - 2022-11-22 01:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:22:05 --> Total execution time: 0.2758
DEBUG - 2022-11-22 01:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:22:14 --> Total execution time: 0.1868
DEBUG - 2022-11-22 01:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:24:44 --> Total execution time: 2.1776
DEBUG - 2022-11-22 01:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 01:54:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:25:25 --> Total execution time: 0.1736
DEBUG - 2022-11-22 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:07 --> Total execution time: 0.2164
DEBUG - 2022-11-22 01:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:07 --> Total execution time: 0.1703
DEBUG - 2022-11-22 01:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-11-22 13:26:09 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 424
DEBUG - 2022-11-22 13:26:09 --> Total execution time: 0.2029
DEBUG - 2022-11-22 01:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:23 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:23 --> Total execution time: 0.1257
DEBUG - 2022-11-22 01:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:29 --> Total execution time: 0.1163
DEBUG - 2022-11-22 01:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:31 --> Total execution time: 1.6293
DEBUG - 2022-11-22 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:35 --> Total execution time: 0.2070
DEBUG - 2022-11-22 01:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:52 --> Total execution time: 0.1996
DEBUG - 2022-11-22 01:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:53 --> Total execution time: 0.1802
DEBUG - 2022-11-22 01:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:55 --> Total execution time: 0.2043
DEBUG - 2022-11-22 01:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:26:58 --> Total execution time: 0.1990
DEBUG - 2022-11-22 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:05 --> Total execution time: 0.1917
DEBUG - 2022-11-22 01:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:11 --> Total execution time: 0.1786
DEBUG - 2022-11-22 01:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:23 --> Total execution time: 0.2012
DEBUG - 2022-11-22 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:25 --> Total execution time: 0.1818
DEBUG - 2022-11-22 01:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:35 --> Total execution time: 0.2704
DEBUG - 2022-11-22 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:36 --> No URI present. Default controller set.
DEBUG - 2022-11-22 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:36 --> Total execution time: 0.1056
DEBUG - 2022-11-22 01:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:27:44 --> Total execution time: 0.2464
DEBUG - 2022-11-22 01:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 01:57:45 --> 404 Page Not Found: Alexander-mcqueen-sneakers-sz-38-31159html/index
DEBUG - 2022-11-22 01:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 01:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 01:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:28:00 --> Total execution time: 0.2242
DEBUG - 2022-11-22 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:30:03 --> Total execution time: 0.2001
DEBUG - 2022-11-22 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:30:05 --> Total execution time: 0.1307
DEBUG - 2022-11-22 02:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:30:13 --> Total execution time: 0.5816
DEBUG - 2022-11-22 02:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 02:00:53 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-22 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:31:24 --> Total execution time: 5.2900
DEBUG - 2022-11-22 02:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:01:27 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:31:27 --> Total execution time: 0.1284
DEBUG - 2022-11-22 02:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:31:32 --> Total execution time: 0.3769
DEBUG - 2022-11-22 02:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:31:40 --> Total execution time: 0.3127
DEBUG - 2022-11-22 02:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:25 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:32:26 --> Total execution time: 0.2009
DEBUG - 2022-11-22 02:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:32:29 --> Total execution time: 0.2956
DEBUG - 2022-11-22 02:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:32:38 --> Total execution time: 0.3165
DEBUG - 2022-11-22 02:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:32:39 --> Total execution time: 0.4651
DEBUG - 2022-11-22 02:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:32:48 --> Total execution time: 0.3033
DEBUG - 2022-11-22 02:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:32:56 --> Total execution time: 0.2257
DEBUG - 2022-11-22 02:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:33:12 --> Total execution time: 0.6111
DEBUG - 2022-11-22 02:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:33:13 --> Total execution time: 0.6762
DEBUG - 2022-11-22 02:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:33:20 --> Total execution time: 0.5017
DEBUG - 2022-11-22 02:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:33:38 --> Total execution time: 0.4943
DEBUG - 2022-11-22 13:33:42 --> Total execution time: 4.4218
DEBUG - 2022-11-22 02:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:33:57 --> Total execution time: 0.3377
DEBUG - 2022-11-22 02:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:02 --> Total execution time: 1.3092
DEBUG - 2022-11-22 02:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:07 --> Total execution time: 0.5012
DEBUG - 2022-11-22 02:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:17 --> Total execution time: 1.1462
DEBUG - 2022-11-22 02:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:18 --> Total execution time: 0.1881
DEBUG - 2022-11-22 02:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:29 --> Total execution time: 0.2467
DEBUG - 2022-11-22 02:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:48 --> Total execution time: 0.2397
DEBUG - 2022-11-22 02:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:34:49 --> Total execution time: 0.1965
DEBUG - 2022-11-22 02:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:07 --> Total execution time: 0.2084
DEBUG - 2022-11-22 02:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:13 --> Total execution time: 0.3022
DEBUG - 2022-11-22 02:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:18 --> Total execution time: 0.2206
DEBUG - 2022-11-22 02:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:27 --> Total execution time: 0.2307
DEBUG - 2022-11-22 02:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:38 --> Total execution time: 0.2699
DEBUG - 2022-11-22 02:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:39 --> Total execution time: 0.1973
DEBUG - 2022-11-22 02:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:54 --> Total execution time: 0.1263
DEBUG - 2022-11-22 02:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:35:58 --> Total execution time: 0.1946
DEBUG - 2022-11-22 02:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:36:10 --> Total execution time: 0.4981
DEBUG - 2022-11-22 02:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:36:17 --> Total execution time: 0.1829
DEBUG - 2022-11-22 02:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:36:27 --> Total execution time: 0.1892
DEBUG - 2022-11-22 02:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:06:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:36:45 --> Total execution time: 0.1275
DEBUG - 2022-11-22 02:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:36:45 --> Total execution time: 0.1268
DEBUG - 2022-11-22 02:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:06:50 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:36:50 --> Total execution time: 0.1052
DEBUG - 2022-11-22 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:08:41 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:38:41 --> Total execution time: 0.1247
DEBUG - 2022-11-22 02:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:08:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:38:44 --> Total execution time: 0.1296
DEBUG - 2022-11-22 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:38:56 --> Total execution time: 0.1313
DEBUG - 2022-11-22 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:39:00 --> Total execution time: 0.1198
DEBUG - 2022-11-22 02:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:09:07 --> Total execution time: 0.1873
DEBUG - 2022-11-22 02:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:09:10 --> Total execution time: 0.1882
DEBUG - 2022-11-22 02:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:09:10 --> Total execution time: 0.2418
DEBUG - 2022-11-22 02:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:09:17 --> Total execution time: 0.1884
DEBUG - 2022-11-22 02:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:39:26 --> Total execution time: 0.2106
DEBUG - 2022-11-22 02:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:39:42 --> Total execution time: 0.1965
DEBUG - 2022-11-22 02:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 02:09:56 --> 404 Page Not Found: Cart/index
DEBUG - 2022-11-22 02:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:09:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 02:09:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 02:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:04 --> Total execution time: 0.1931
DEBUG - 2022-11-22 02:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:06 --> Total execution time: 0.4712
DEBUG - 2022-11-22 02:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:07 --> Total execution time: 0.1795
DEBUG - 2022-11-22 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:13 --> Total execution time: 0.2403
DEBUG - 2022-11-22 02:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:24 --> Total execution time: 0.1959
DEBUG - 2022-11-22 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:30 --> Total execution time: 0.2173
DEBUG - 2022-11-22 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:33 --> Total execution time: 0.1807
DEBUG - 2022-11-22 02:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:33 --> Total execution time: 0.2252
DEBUG - 2022-11-22 02:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:40:41 --> Total execution time: 0.2077
DEBUG - 2022-11-22 02:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:41:12 --> Total execution time: 0.2259
DEBUG - 2022-11-22 02:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:41:48 --> Total execution time: 0.2716
DEBUG - 2022-11-22 02:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:42:39 --> Total execution time: 0.2121
DEBUG - 2022-11-22 02:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:42:48 --> Total execution time: 0.2212
DEBUG - 2022-11-22 02:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:42:59 --> Total execution time: 0.2088
DEBUG - 2022-11-22 02:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:43:07 --> Total execution time: 0.1822
DEBUG - 2022-11-22 02:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:43:40 --> Total execution time: 0.2666
DEBUG - 2022-11-22 02:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:43:43 --> Total execution time: 0.5436
DEBUG - 2022-11-22 02:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:43:44 --> Total execution time: 0.2352
DEBUG - 2022-11-22 02:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:43:57 --> Total execution time: 0.1976
DEBUG - 2022-11-22 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:44:00 --> Total execution time: 0.2367
DEBUG - 2022-11-22 02:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:45:07 --> Total execution time: 0.4875
DEBUG - 2022-11-22 02:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:45:13 --> Total execution time: 0.1731
DEBUG - 2022-11-22 02:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:15:36 --> Total execution time: 0.4952
DEBUG - 2022-11-22 02:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:15:38 --> Total execution time: 0.2484
DEBUG - 2022-11-22 02:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:15:39 --> Total execution time: 0.1973
DEBUG - 2022-11-22 02:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:56:33 --> Total execution time: 0.6288
DEBUG - 2022-11-22 02:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:27:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:57:45 --> Total execution time: 0.9659
DEBUG - 2022-11-22 02:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:58:06 --> Total execution time: 0.5689
DEBUG - 2022-11-22 02:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:58:15 --> Total execution time: 0.2617
DEBUG - 2022-11-22 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:58:25 --> Total execution time: 0.2768
DEBUG - 2022-11-22 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 13:58:42 --> Total execution time: 0.1838
DEBUG - 2022-11-22 02:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:00:12 --> Total execution time: 0.1748
DEBUG - 2022-11-22 02:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:00:45 --> Total execution time: 0.2233
DEBUG - 2022-11-22 02:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:00:49 --> Total execution time: 0.2552
DEBUG - 2022-11-22 02:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:31:16 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:01:16 --> Total execution time: 0.1430
DEBUG - 2022-11-22 02:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:32:16 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:02:16 --> Total execution time: 0.2249
DEBUG - 2022-11-22 02:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:32:25 --> Total execution time: 0.2665
DEBUG - 2022-11-22 02:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:33:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:03:14 --> Total execution time: 0.1799
DEBUG - 2022-11-22 02:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:33:15 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:03:16 --> Total execution time: 0.2057
DEBUG - 2022-11-22 02:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:33:26 --> Total execution time: 0.1304
DEBUG - 2022-11-22 02:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:34:11 --> Total execution time: 0.2779
DEBUG - 2022-11-22 02:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:34:11 --> Total execution time: 0.5745
DEBUG - 2022-11-22 02:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:04:51 --> Total execution time: 0.4967
DEBUG - 2022-11-22 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:04:54 --> Total execution time: 0.1838
DEBUG - 2022-11-22 02:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:05:05 --> Total execution time: 0.1809
DEBUG - 2022-11-22 02:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:05:21 --> Total execution time: 0.1760
DEBUG - 2022-11-22 02:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:05:32 --> Total execution time: 0.3490
DEBUG - 2022-11-22 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:05:42 --> Total execution time: 0.3100
DEBUG - 2022-11-22 02:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:05:53 --> Total execution time: 0.1776
DEBUG - 2022-11-22 02:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:10 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:10 --> Total execution time: 0.1890
DEBUG - 2022-11-22 02:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:11 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:11 --> Total execution time: 0.1284
DEBUG - 2022-11-22 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:14 --> Total execution time: 0.1210
DEBUG - 2022-11-22 02:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:26 --> Total execution time: 0.1290
DEBUG - 2022-11-22 02:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:42 --> Total execution time: 0.2218
DEBUG - 2022-11-22 02:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:49 --> Total execution time: 0.2359
DEBUG - 2022-11-22 02:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:06:54 --> Total execution time: 0.1894
DEBUG - 2022-11-22 02:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:38:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:08:47 --> Total execution time: 0.9788
DEBUG - 2022-11-22 02:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:09:11 --> Total execution time: 0.1789
DEBUG - 2022-11-22 02:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:40:00 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:10:00 --> Total execution time: 0.1256
DEBUG - 2022-11-22 02:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:40:01 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:10:01 --> Total execution time: 0.1242
DEBUG - 2022-11-22 02:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:40:37 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:10:38 --> Total execution time: 0.1243
DEBUG - 2022-11-22 02:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:40:54 --> Total execution time: 0.1802
DEBUG - 2022-11-22 02:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:40:57 --> Total execution time: 0.2377
DEBUG - 2022-11-22 02:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:40:57 --> Total execution time: 0.4529
DEBUG - 2022-11-22 02:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:41:01 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:11:01 --> Total execution time: 0.1233
DEBUG - 2022-11-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:11:13 --> Total execution time: 0.1075
DEBUG - 2022-11-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:11:13 --> Total execution time: 0.1176
DEBUG - 2022-11-22 02:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:11:47 --> Total execution time: 0.1714
DEBUG - 2022-11-22 02:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:12:05 --> Total execution time: 2.1730
DEBUG - 2022-11-22 02:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:12:17 --> Total execution time: 0.1778
DEBUG - 2022-11-22 02:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 02:42:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 02:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:12:21 --> Total execution time: 0.1667
DEBUG - 2022-11-22 02:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:12:39 --> Total execution time: 0.2104
DEBUG - 2022-11-22 02:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:12:50 --> Total execution time: 0.1724
DEBUG - 2022-11-22 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:12:54 --> Total execution time: 0.1838
DEBUG - 2022-11-22 02:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:43:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 02:43:12 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 02:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:13:26 --> Total execution time: 0.1712
DEBUG - 2022-11-22 02:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:13:48 --> Total execution time: 0.1826
DEBUG - 2022-11-22 02:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:44:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:14:14 --> Total execution time: 0.1147
DEBUG - 2022-11-22 02:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:14:20 --> Total execution time: 0.2377
DEBUG - 2022-11-22 02:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:14:51 --> Total execution time: 0.1793
DEBUG - 2022-11-22 02:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:15:13 --> Total execution time: 0.1832
DEBUG - 2022-11-22 02:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:15:47 --> Total execution time: 0.1893
DEBUG - 2022-11-22 02:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:16:45 --> Total execution time: 0.1455
DEBUG - 2022-11-22 02:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:09 --> Total execution time: 0.2034
DEBUG - 2022-11-22 02:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:13 --> Total execution time: 0.1880
DEBUG - 2022-11-22 02:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:14 --> Total execution time: 0.1863
DEBUG - 2022-11-22 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:52 --> Total execution time: 0.1962
DEBUG - 2022-11-22 02:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:55 --> Total execution time: 0.2271
DEBUG - 2022-11-22 02:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:48:55 --> Total execution time: 0.1778
DEBUG - 2022-11-22 02:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:19:39 --> Total execution time: 1.8101
DEBUG - 2022-11-22 02:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:19:51 --> Total execution time: 0.4991
DEBUG - 2022-11-22 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 02:50:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 02:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:20:19 --> Total execution time: 0.1840
DEBUG - 2022-11-22 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:20:36 --> Total execution time: 0.1829
DEBUG - 2022-11-22 02:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:51:41 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:21:41 --> Total execution time: 0.1897
DEBUG - 2022-11-22 02:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:21:48 --> Total execution time: 0.1957
DEBUG - 2022-11-22 02:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:22:17 --> Total execution time: 0.1716
DEBUG - 2022-11-22 02:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:22:46 --> Total execution time: 0.2139
DEBUG - 2022-11-22 02:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:22:48 --> Total execution time: 0.1155
DEBUG - 2022-11-22 02:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:22:57 --> Total execution time: 0.2287
DEBUG - 2022-11-22 02:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:23:07 --> Total execution time: 0.2022
DEBUG - 2022-11-22 02:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:24:55 --> Total execution time: 14.1975
DEBUG - 2022-11-22 02:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:25:01 --> Total execution time: 0.2329
DEBUG - 2022-11-22 02:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:27:00 --> Total execution time: 0.2152
DEBUG - 2022-11-22 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:14 --> Total execution time: 0.1683
DEBUG - 2022-11-22 02:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:20 --> Total execution time: 0.1778
DEBUG - 2022-11-22 02:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:23 --> Total execution time: 0.1688
DEBUG - 2022-11-22 02:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:26 --> Total execution time: 0.1704
DEBUG - 2022-11-22 02:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:31 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:27:31 --> Total execution time: 0.2534
DEBUG - 2022-11-22 02:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:27:57 --> Total execution time: 0.5326
DEBUG - 2022-11-22 02:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:57:58 --> Total execution time: 0.1778
DEBUG - 2022-11-22 02:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:00 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:01 --> Total execution time: 0.4976
DEBUG - 2022-11-22 02:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:05 --> Total execution time: 0.2121
DEBUG - 2022-11-22 02:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:07 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:07 --> Total execution time: 0.1708
DEBUG - 2022-11-22 02:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:11 --> Total execution time: 0.2145
DEBUG - 2022-11-22 02:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:14 --> Total execution time: 0.1715
DEBUG - 2022-11-22 02:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:25 --> Total execution time: 0.1986
DEBUG - 2022-11-22 02:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:28 --> Total execution time: 0.1764
DEBUG - 2022-11-22 02:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 02:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:28:42 --> Total execution time: 0.1754
DEBUG - 2022-11-22 02:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:29:07 --> Total execution time: 0.5665
DEBUG - 2022-11-22 02:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 02:59:47 --> No URI present. Default controller set.
DEBUG - 2022-11-22 02:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 02:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:29:47 --> Total execution time: 0.1210
DEBUG - 2022-11-22 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:30:04 --> Total execution time: 0.1965
DEBUG - 2022-11-22 03:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:30:43 --> Total execution time: 0.1845
DEBUG - 2022-11-22 03:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:30:44 --> Total execution time: 0.2036
DEBUG - 2022-11-22 03:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:00:55 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:30:55 --> Total execution time: 0.1391
DEBUG - 2022-11-22 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:00:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:30:56 --> Total execution time: 0.1142
DEBUG - 2022-11-22 03:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:31:52 --> Total execution time: 0.1744
DEBUG - 2022-11-22 03:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:01:54 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:31:54 --> Total execution time: 0.1149
DEBUG - 2022-11-22 03:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:01:54 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:31:54 --> Total execution time: 0.1438
DEBUG - 2022-11-22 03:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:32:00 --> Total execution time: 0.1113
DEBUG - 2022-11-22 03:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:32:05 --> Total execution time: 0.2387
DEBUG - 2022-11-22 03:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:32:14 --> Total execution time: 0.2573
DEBUG - 2022-11-22 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:32:22 --> Total execution time: 0.1825
DEBUG - 2022-11-22 03:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:03:00 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:33:00 --> Total execution time: 0.1114
DEBUG - 2022-11-22 03:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:34:15 --> Total execution time: 0.2245
DEBUG - 2022-11-22 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:35:15 --> Total execution time: 0.2135
DEBUG - 2022-11-22 03:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:35:24 --> Total execution time: 0.1791
DEBUG - 2022-11-22 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:35:26 --> Total execution time: 0.2073
DEBUG - 2022-11-22 03:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:35:36 --> Total execution time: 0.2080
DEBUG - 2022-11-22 03:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:37:27 --> Total execution time: 0.7586
DEBUG - 2022-11-22 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:37:55 --> Total execution time: 0.5931
DEBUG - 2022-11-22 03:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:37:56 --> Total execution time: 0.1783
DEBUG - 2022-11-22 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:38:01 --> Total execution time: 0.2484
DEBUG - 2022-11-22 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:38:05 --> Total execution time: 0.1768
DEBUG - 2022-11-22 03:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:10 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:38:10 --> Total execution time: 0.1282
DEBUG - 2022-11-22 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:38:14 --> Total execution time: 0.1838
DEBUG - 2022-11-22 03:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:38:21 --> Total execution time: 0.2197
DEBUG - 2022-11-22 03:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:38:50 --> Total execution time: 0.2969
DEBUG - 2022-11-22 03:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:39:02 --> Total execution time: 0.2785
DEBUG - 2022-11-22 03:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:09:09 --> 404 Page Not Found: Course/premium-level-program
DEBUG - 2022-11-22 03:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:13:19 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:43:20 --> Total execution time: 0.5705
DEBUG - 2022-11-22 03:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:43:26 --> Total execution time: 0.1834
DEBUG - 2022-11-22 03:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:43:44 --> Total execution time: 0.3754
DEBUG - 2022-11-22 03:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:43:52 --> Total execution time: 0.2351
DEBUG - 2022-11-22 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:24 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:24 --> Total execution time: 0.5232
DEBUG - 2022-11-22 03:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:32 --> Total execution time: 0.1951
DEBUG - 2022-11-22 03:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:37 --> Total execution time: 0.2286
DEBUG - 2022-11-22 03:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:38 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:38 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:38 --> Total execution time: 0.1372
DEBUG - 2022-11-22 03:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:38 --> Total execution time: 0.4957
DEBUG - 2022-11-22 03:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:41 --> Total execution time: 0.1891
DEBUG - 2022-11-22 03:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:48 --> Total execution time: 0.1913
DEBUG - 2022-11-22 03:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:44:58 --> Total execution time: 0.1917
DEBUG - 2022-11-22 03:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:45:04 --> Total execution time: 0.1743
DEBUG - 2022-11-22 03:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:08 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:45:09 --> Total execution time: 0.1363
DEBUG - 2022-11-22 03:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:24 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:45:24 --> Total execution time: 0.1823
DEBUG - 2022-11-22 03:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:45:30 --> Total execution time: 0.1723
DEBUG - 2022-11-22 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:45:39 --> Total execution time: 0.1917
DEBUG - 2022-11-22 03:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:45:51 --> Total execution time: 0.2912
DEBUG - 2022-11-22 03:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:15:59 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:00 --> Total execution time: 0.1525
DEBUG - 2022-11-22 03:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:00 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:00 --> Total execution time: 0.1354
DEBUG - 2022-11-22 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:02 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:02 --> Total execution time: 0.2246
DEBUG - 2022-11-22 03:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:03 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:03 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:03 --> Total execution time: 0.1224
DEBUG - 2022-11-22 03:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:03 --> Total execution time: 0.1279
DEBUG - 2022-11-22 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:46 --> Total execution time: 0.2140
DEBUG - 2022-11-22 03:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:53 --> Total execution time: 0.7411
DEBUG - 2022-11-22 03:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:16:57 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:58 --> Total execution time: 0.5633
DEBUG - 2022-11-22 03:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:46:58 --> Total execution time: 0.6435
DEBUG - 2022-11-22 03:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:47:01 --> Total execution time: 0.5784
DEBUG - 2022-11-22 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:17:25 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:47:25 --> Total execution time: 0.1828
DEBUG - 2022-11-22 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:47:25 --> Total execution time: 0.1720
DEBUG - 2022-11-22 03:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:48:05 --> Total execution time: 0.2101
DEBUG - 2022-11-22 03:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:48:06 --> Total execution time: 0.1918
DEBUG - 2022-11-22 03:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:48:11 --> Total execution time: 0.3431
DEBUG - 2022-11-22 03:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:48:13 --> Total execution time: 0.1836
DEBUG - 2022-11-22 03:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:48:14 --> Total execution time: 0.2591
DEBUG - 2022-11-22 03:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:19:16 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:49:17 --> Total execution time: 1.8678
DEBUG - 2022-11-22 03:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:19:27 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:49:28 --> Total execution time: 0.4177
DEBUG - 2022-11-22 03:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:19:29 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:49:29 --> Total execution time: 0.2291
DEBUG - 2022-11-22 03:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:49:55 --> Total execution time: 1.1572
DEBUG - 2022-11-22 03:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:20:34 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:50:34 --> Total execution time: 0.5324
DEBUG - 2022-11-22 14:50:37 --> Total execution time: 4.2053
DEBUG - 2022-11-22 14:50:38 --> Total execution time: 4.7385
DEBUG - 2022-11-22 03:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:20:39 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 14:50:39 --> Total execution time: 5.6485
DEBUG - 2022-11-22 03:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:50:39 --> Total execution time: 5.7232
DEBUG - 2022-11-22 03:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:50:41 --> Total execution time: 2.5943
DEBUG - 2022-11-22 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:51:15 --> Total execution time: 1.2955
DEBUG - 2022-11-22 03:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:18 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:51:19 --> Total execution time: 0.4110
DEBUG - 2022-11-22 03:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:19 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:51:20 --> Total execution time: 0.7821
DEBUG - 2022-11-22 03:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:51:28 --> Total execution time: 0.2388
DEBUG - 2022-11-22 03:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:51:38 --> Total execution time: 1.0195
DEBUG - 2022-11-22 03:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:51:50 --> Total execution time: 0.9434
DEBUG - 2022-11-22 03:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:21:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-22 03:21:51 --> Unable to connect to the database
ERROR - 2022-11-22 03:21:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-22 03:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-22 03:22:05 --> Unable to connect to the database
ERROR - 2022-11-22 03:22:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-22 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:05 --> 404 Page Not Found: Contact-us/index
DEBUG - 2022-11-22 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:05 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-22 03:22:05 --> Unable to connect to the database
ERROR - 2022-11-22 03:22:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-22 03:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:06 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-22 03:22:06 --> Unable to connect to the database
ERROR - 2022-11-22 03:22:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-22 03:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:52:08 --> Total execution time: 8.1418
DEBUG - 2022-11-22 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:09 --> 404 Page Not Found: Contact-us/index
DEBUG - 2022-11-22 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 03:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-11-22 03:22:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-22 03:22:10 --> Unable to connect to the database
ERROR - 2022-11-22 03:22:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-22 03:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:52:11 --> Total execution time: 0.6964
DEBUG - 2022-11-22 03:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 03:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:22:12 --> 404 Page Not Found: Contact-us/index
DEBUG - 2022-11-22 03:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:17 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:52:18 --> Total execution time: 0.7846
DEBUG - 2022-11-22 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:52:19 --> Total execution time: 1.7555
DEBUG - 2022-11-22 03:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:32 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:52:33 --> Total execution time: 0.7416
DEBUG - 2022-11-22 03:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:52:58 --> Total execution time: 0.1861
DEBUG - 2022-11-22 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:00 --> Total execution time: 0.1885
DEBUG - 2022-11-22 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:01 --> Total execution time: 0.2128
DEBUG - 2022-11-22 03:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:01 --> Total execution time: 0.2284
DEBUG - 2022-11-22 03:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:02 --> Total execution time: 0.6920
DEBUG - 2022-11-22 03:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:03 --> Total execution time: 0.1563
DEBUG - 2022-11-22 03:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:03 --> Total execution time: 0.4838
DEBUG - 2022-11-22 03:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:03 --> Total execution time: 0.2573
DEBUG - 2022-11-22 03:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:04 --> Total execution time: 0.2209
DEBUG - 2022-11-22 03:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:04 --> Total execution time: 0.1249
DEBUG - 2022-11-22 03:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:05 --> Total execution time: 0.1914
DEBUG - 2022-11-22 03:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:05 --> Total execution time: 0.4125
DEBUG - 2022-11-22 03:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:11 --> Total execution time: 0.1971
DEBUG - 2022-11-22 03:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:13 --> Total execution time: 0.2509
DEBUG - 2022-11-22 03:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:13 --> Total execution time: 0.1844
DEBUG - 2022-11-22 03:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:29 --> Total execution time: 0.1740
DEBUG - 2022-11-22 03:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:53:31 --> Total execution time: 0.1954
DEBUG - 2022-11-22 03:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:23:33 --> Total execution time: 0.2506
DEBUG - 2022-11-22 03:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:09 --> Total execution time: 0.1735
DEBUG - 2022-11-22 03:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:24:10 --> 404 Page Not Found: User/registration-with-package
DEBUG - 2022-11-22 03:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:24:10 --> 404 Page Not Found: User/registration-with-package
DEBUG - 2022-11-22 03:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:24:10 --> 404 Page Not Found: User/registration-with-package
DEBUG - 2022-11-22 03:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:11 --> Total execution time: 0.2074
DEBUG - 2022-11-22 03:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:11 --> Total execution time: 0.4296
DEBUG - 2022-11-22 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:24 --> Total execution time: 0.1842
DEBUG - 2022-11-22 03:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:24:24 --> 404 Page Not Found: User/registration-with-package
DEBUG - 2022-11-22 03:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:24:25 --> 404 Page Not Found: User/registration-with-package
DEBUG - 2022-11-22 03:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:24:25 --> 404 Page Not Found: User/registration-with-package
DEBUG - 2022-11-22 03:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:26 --> Total execution time: 0.1736
DEBUG - 2022-11-22 03:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:26 --> Total execution time: 0.2137
DEBUG - 2022-11-22 03:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:30 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:54:30 --> Total execution time: 0.1976
DEBUG - 2022-11-22 03:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:41 --> Total execution time: 0.1274
DEBUG - 2022-11-22 03:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:42 --> Total execution time: 0.1798
DEBUG - 2022-11-22 03:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:42 --> Total execution time: 0.2034
DEBUG - 2022-11-22 03:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:42 --> Total execution time: 0.4668
DEBUG - 2022-11-22 03:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:43 --> Total execution time: 0.1628
DEBUG - 2022-11-22 03:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:44 --> Total execution time: 0.2254
DEBUG - 2022-11-22 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:44 --> Total execution time: 0.1716
DEBUG - 2022-11-22 03:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:44 --> Total execution time: 0.2258
DEBUG - 2022-11-22 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:45 --> Total execution time: 0.1399
DEBUG - 2022-11-22 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:47 --> Total execution time: 0.2740
DEBUG - 2022-11-22 03:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:24:47 --> Total execution time: 0.6077
DEBUG - 2022-11-22 03:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:51 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:54:52 --> Total execution time: 0.2065
DEBUG - 2022-11-22 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:54:52 --> Total execution time: 0.1798
DEBUG - 2022-11-22 03:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:24:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:54:57 --> Total execution time: 0.2077
DEBUG - 2022-11-22 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:07 --> Total execution time: 0.1298
DEBUG - 2022-11-22 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:07 --> Total execution time: 0.1789
DEBUG - 2022-11-22 03:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:08 --> Total execution time: 0.2058
DEBUG - 2022-11-22 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:08 --> Total execution time: 0.4331
DEBUG - 2022-11-22 03:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:09 --> Total execution time: 0.1299
DEBUG - 2022-11-22 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:10 --> Total execution time: 0.1955
DEBUG - 2022-11-22 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:10 --> Total execution time: 0.1190
DEBUG - 2022-11-22 03:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:10 --> Total execution time: 0.1145
DEBUG - 2022-11-22 03:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:10 --> Total execution time: 0.2092
DEBUG - 2022-11-22 03:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:11 --> Total execution time: 0.1800
DEBUG - 2022-11-22 03:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:12 --> Total execution time: 0.2873
DEBUG - 2022-11-22 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:55:58 --> Total execution time: 2.2225
DEBUG - 2022-11-22 03:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:56:00 --> Total execution time: 0.1975
DEBUG - 2022-11-22 03:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:56:01 --> Total execution time: 0.1896
DEBUG - 2022-11-22 03:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:56:02 --> Total execution time: 0.2686
DEBUG - 2022-11-22 03:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:56:04 --> Total execution time: 0.1956
DEBUG - 2022-11-22 03:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:26:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 03:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:27:50 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:57:51 --> Total execution time: 0.4760
DEBUG - 2022-11-22 03:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:28:01 --> Total execution time: 0.1125
DEBUG - 2022-11-22 03:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:28:02 --> Total execution time: 0.1942
DEBUG - 2022-11-22 03:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:28:02 --> Total execution time: 0.3899
DEBUG - 2022-11-22 03:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:58:02 --> Total execution time: 0.1892
DEBUG - 2022-11-22 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:58:17 --> Total execution time: 0.2781
DEBUG - 2022-11-22 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:58:18 --> Total execution time: 0.1731
DEBUG - 2022-11-22 03:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:58:20 --> Total execution time: 0.1169
DEBUG - 2022-11-22 03:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:29:35 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:59:36 --> Total execution time: 0.3933
DEBUG - 2022-11-22 03:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:59:36 --> Total execution time: 0.4706
DEBUG - 2022-11-22 03:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 14:59:50 --> Total execution time: 0.1901
DEBUG - 2022-11-22 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:00:23 --> Total execution time: 0.1789
DEBUG - 2022-11-22 03:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:04:27 --> Total execution time: 0.1996
DEBUG - 2022-11-22 03:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:05:06 --> Total execution time: 0.1097
DEBUG - 2022-11-22 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:05:51 --> Total execution time: 0.2520
DEBUG - 2022-11-22 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:05:58 --> Total execution time: 0.1806
DEBUG - 2022-11-22 03:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:00 --> Total execution time: 0.2068
DEBUG - 2022-11-22 03:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:08 --> Total execution time: 0.1784
DEBUG - 2022-11-22 03:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:11 --> Total execution time: 0.1887
DEBUG - 2022-11-22 03:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:15 --> Total execution time: 0.2765
DEBUG - 2022-11-22 03:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:21 --> Total execution time: 0.1106
DEBUG - 2022-11-22 03:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:27 --> Total execution time: 0.1806
DEBUG - 2022-11-22 03:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:28 --> Total execution time: 0.2193
DEBUG - 2022-11-22 03:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:36:50 --> Total execution time: 0.1696
DEBUG - 2022-11-22 03:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:59 --> Total execution time: 0.1841
DEBUG - 2022-11-22 03:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:06:59 --> Total execution time: 0.1727
DEBUG - 2022-11-22 03:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:07:16 --> Total execution time: 0.2317
DEBUG - 2022-11-22 03:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:07:17 --> Total execution time: 0.4088
DEBUG - 2022-11-22 03:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:07:19 --> Total execution time: 0.2377
DEBUG - 2022-11-22 03:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:07:27 --> Total execution time: 0.3066
DEBUG - 2022-11-22 03:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:07:31 --> Total execution time: 0.2465
DEBUG - 2022-11-22 03:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:07:52 --> Total execution time: 0.2238
DEBUG - 2022-11-22 03:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:42:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 03:42:07 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 03:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:42:31 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:12:33 --> Total execution time: 1.3994
DEBUG - 2022-11-22 03:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:15:05 --> Total execution time: 0.1793
DEBUG - 2022-11-22 03:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:15:12 --> Total execution time: 0.2187
DEBUG - 2022-11-22 03:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:15:22 --> Total execution time: 0.1850
DEBUG - 2022-11-22 03:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:16:04 --> Total execution time: 0.2606
DEBUG - 2022-11-22 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:02 --> Total execution time: 0.2230
DEBUG - 2022-11-22 03:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:04 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:05 --> Total execution time: 0.4768
DEBUG - 2022-11-22 03:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:05 --> Total execution time: 0.2109
DEBUG - 2022-11-22 03:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:08 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:08 --> Total execution time: 0.1960
DEBUG - 2022-11-22 03:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:13 --> Total execution time: 0.1949
DEBUG - 2022-11-22 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:14 --> Total execution time: 0.1852
DEBUG - 2022-11-22 03:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:17 --> Total execution time: 0.1795
DEBUG - 2022-11-22 03:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:22 --> Total execution time: 0.4819
DEBUG - 2022-11-22 03:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:37 --> Total execution time: 0.2423
DEBUG - 2022-11-22 03:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:38 --> Total execution time: 0.1064
DEBUG - 2022-11-22 03:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:17:46 --> Total execution time: 0.1675
DEBUG - 2022-11-22 03:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:02 --> Total execution time: 0.2196
DEBUG - 2022-11-22 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:02 --> Total execution time: 0.2615
DEBUG - 2022-11-22 03:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:07 --> Total execution time: 0.1944
DEBUG - 2022-11-22 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:09 --> Total execution time: 0.2421
DEBUG - 2022-11-22 03:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:15 --> Total execution time: 0.2358
DEBUG - 2022-11-22 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:16 --> Total execution time: 0.1863
DEBUG - 2022-11-22 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:16 --> Total execution time: 0.1964
DEBUG - 2022-11-22 03:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:19 --> Total execution time: 0.2467
DEBUG - 2022-11-22 03:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:22 --> Total execution time: 0.1801
DEBUG - 2022-11-22 03:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:18:35 --> Total execution time: 0.4308
DEBUG - 2022-11-22 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:19:22 --> Total execution time: 0.2085
DEBUG - 2022-11-22 03:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:19:37 --> Total execution time: 0.2366
DEBUG - 2022-11-22 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:19:54 --> Total execution time: 0.4727
DEBUG - 2022-11-22 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:21:21 --> Total execution time: 0.2320
DEBUG - 2022-11-22 03:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:21:38 --> Total execution time: 0.1960
DEBUG - 2022-11-22 03:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:21:42 --> Total execution time: 0.1926
DEBUG - 2022-11-22 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:52:37 --> Total execution time: 0.2091
DEBUG - 2022-11-22 03:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:52:56 --> Total execution time: 0.3072
DEBUG - 2022-11-22 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:23:52 --> Total execution time: 0.2240
DEBUG - 2022-11-22 03:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:23:56 --> Total execution time: 0.2049
DEBUG - 2022-11-22 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:24:20 --> Total execution time: 0.1342
DEBUG - 2022-11-22 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:24:24 --> Total execution time: 0.2070
DEBUG - 2022-11-22 03:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:24:36 --> Total execution time: 0.2121
DEBUG - 2022-11-22 03:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:24:38 --> Total execution time: 0.2372
DEBUG - 2022-11-22 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:24:52 --> Total execution time: 0.2234
DEBUG - 2022-11-22 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:02 --> Total execution time: 0.2503
DEBUG - 2022-11-22 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:11 --> Total execution time: 0.1849
DEBUG - 2022-11-22 03:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:15 --> Total execution time: 0.2189
DEBUG - 2022-11-22 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:22 --> Total execution time: 0.2420
DEBUG - 2022-11-22 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:23 --> No URI present. Default controller set.
DEBUG - 2022-11-22 03:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:23 --> Total execution time: 0.2286
DEBUG - 2022-11-22 03:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:23 --> Total execution time: 0.1169
DEBUG - 2022-11-22 03:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:29 --> Total execution time: 0.1792
DEBUG - 2022-11-22 03:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:25:49 --> Total execution time: 0.2051
DEBUG - 2022-11-22 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:26:18 --> Total execution time: 0.2587
DEBUG - 2022-11-22 03:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:26:52 --> Total execution time: 0.3498
DEBUG - 2022-11-22 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:26:55 --> Total execution time: 0.2743
DEBUG - 2022-11-22 03:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:26:56 --> Total execution time: 0.6372
DEBUG - 2022-11-22 03:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:26:56 --> Total execution time: 0.7846
DEBUG - 2022-11-22 03:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:26:59 --> Total execution time: 0.3264
DEBUG - 2022-11-22 03:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:28:06 --> Total execution time: 0.2489
DEBUG - 2022-11-22 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:28:09 --> Total execution time: 0.2489
DEBUG - 2022-11-22 03:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:28:25 --> Total execution time: 0.1895
DEBUG - 2022-11-22 03:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:29:18 --> Total execution time: 0.8884
DEBUG - 2022-11-22 03:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:29:20 --> Total execution time: 0.3555
DEBUG - 2022-11-22 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:29:20 --> Total execution time: 0.2740
DEBUG - 2022-11-22 03:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:29:22 --> Total execution time: 0.2112
DEBUG - 2022-11-22 03:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:29:24 --> Total execution time: 0.7323
DEBUG - 2022-11-22 03:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 03:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 03:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:29:35 --> Total execution time: 0.9219
DEBUG - 2022-11-22 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:30:03 --> Total execution time: 0.1788
DEBUG - 2022-11-22 04:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:31:02 --> Total execution time: 0.6030
DEBUG - 2022-11-22 04:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:31:06 --> Total execution time: 0.3609
DEBUG - 2022-11-22 04:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:01:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:31:21 --> Total execution time: 0.1396
DEBUG - 2022-11-22 04:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:32:10 --> Total execution time: 0.2191
DEBUG - 2022-11-22 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:04:37 --> 404 Page Not Found: New-gucci-wool-chunky-knit-tiger-beanie-navy-size-medium-22cm-232781html/index
DEBUG - 2022-11-22 04:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:06:19 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:36:19 --> Total execution time: 0.6303
DEBUG - 2022-11-22 04:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:36:27 --> Total execution time: 0.1188
DEBUG - 2022-11-22 04:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:36:43 --> Total execution time: 0.2370
DEBUG - 2022-11-22 04:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:36:56 --> Total execution time: 0.2529
DEBUG - 2022-11-22 04:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:37:28 --> Total execution time: 0.8073
DEBUG - 2022-11-22 04:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:37:32 --> Total execution time: 0.2432
DEBUG - 2022-11-22 04:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:07 --> Total execution time: 0.2807
DEBUG - 2022-11-22 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:15 --> Total execution time: 0.2542
DEBUG - 2022-11-22 04:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:16 --> Total execution time: 0.2062
DEBUG - 2022-11-22 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:21 --> Total execution time: 0.2223
DEBUG - 2022-11-22 04:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:29 --> Total execution time: 0.2394
DEBUG - 2022-11-22 04:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:35 --> Total execution time: 0.3569
DEBUG - 2022-11-22 04:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:43 --> Total execution time: 0.3020
DEBUG - 2022-11-22 04:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:46 --> Total execution time: 0.1862
DEBUG - 2022-11-22 04:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:38:46 --> Total execution time: 0.3821
DEBUG - 2022-11-22 04:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:39:01 --> Total execution time: 0.1985
DEBUG - 2022-11-22 04:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:39:06 --> Total execution time: 0.2216
DEBUG - 2022-11-22 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:11:07 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:41:07 --> Total execution time: 0.1606
DEBUG - 2022-11-22 04:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:11:08 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:41:08 --> Total execution time: 0.2047
DEBUG - 2022-11-22 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:41:15 --> Total execution time: 0.1401
DEBUG - 2022-11-22 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:11:39 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:41:39 --> Total execution time: 0.1977
DEBUG - 2022-11-22 04:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:42:19 --> Total execution time: 0.5750
DEBUG - 2022-11-22 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:42:23 --> Total execution time: 0.2104
DEBUG - 2022-11-22 04:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:42:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 04:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:42:42 --> Total execution time: 0.2454
DEBUG - 2022-11-22 04:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:43:01 --> Total execution time: 0.2600
DEBUG - 2022-11-22 04:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:13:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:43:21 --> Total execution time: 0.1289
DEBUG - 2022-11-22 04:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:43:48 --> Total execution time: 0.4137
DEBUG - 2022-11-22 04:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:13:48 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:43:49 --> Total execution time: 0.1770
DEBUG - 2022-11-22 04:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:44:00 --> Total execution time: 0.8898
DEBUG - 2022-11-22 04:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:45:14 --> Total execution time: 0.2227
DEBUG - 2022-11-22 04:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:45:25 --> Total execution time: 0.2077
DEBUG - 2022-11-22 04:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:45:39 --> Total execution time: 0.2177
DEBUG - 2022-11-22 04:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:15:40 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-22 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:15:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:45:47 --> Total execution time: 0.1347
DEBUG - 2022-11-22 04:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:46:59 --> Total execution time: 0.1912
DEBUG - 2022-11-22 04:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:47:08 --> Total execution time: 0.1338
DEBUG - 2022-11-22 04:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:47:10 --> Total execution time: 0.2000
DEBUG - 2022-11-22 04:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:48:09 --> Total execution time: 0.5535
DEBUG - 2022-11-22 04:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:18:12 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:48:12 --> Total execution time: 0.1313
DEBUG - 2022-11-22 04:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:48:21 --> Total execution time: 0.2367
DEBUG - 2022-11-22 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:18:39 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:48:39 --> Total execution time: 0.1166
DEBUG - 2022-11-22 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:18:43 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:48:43 --> Total execution time: 0.1286
DEBUG - 2022-11-22 04:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:48:48 --> Total execution time: 0.1393
DEBUG - 2022-11-22 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:49:14 --> Total execution time: 0.2285
DEBUG - 2022-11-22 04:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:49:24 --> Total execution time: 0.2609
DEBUG - 2022-11-22 04:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:49:33 --> Total execution time: 0.4928
DEBUG - 2022-11-22 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:49:38 --> Total execution time: 0.8651
DEBUG - 2022-11-22 04:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:49:40 --> Total execution time: 0.2111
DEBUG - 2022-11-22 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:19:50 --> Total execution time: 0.2954
DEBUG - 2022-11-22 04:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:49:55 --> Total execution time: 0.2027
DEBUG - 2022-11-22 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:50:00 --> Total execution time: 0.1740
DEBUG - 2022-11-22 04:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:50:06 --> Total execution time: 0.2502
DEBUG - 2022-11-22 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:50:17 --> Total execution time: 0.2755
DEBUG - 2022-11-22 04:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:51:11 --> Total execution time: 0.1986
DEBUG - 2022-11-22 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:51:33 --> Total execution time: 0.1999
DEBUG - 2022-11-22 04:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:51:40 --> Total execution time: 0.1802
DEBUG - 2022-11-22 04:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:51:43 --> Total execution time: 0.1822
DEBUG - 2022-11-22 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:02 --> Total execution time: 0.2356
DEBUG - 2022-11-22 04:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:06 --> Total execution time: 0.2056
DEBUG - 2022-11-22 04:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:07 --> Total execution time: 0.2303
DEBUG - 2022-11-22 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:14 --> Total execution time: 0.2786
DEBUG - 2022-11-22 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:15 --> Total execution time: 0.2016
DEBUG - 2022-11-22 04:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:22 --> Total execution time: 0.1869
DEBUG - 2022-11-22 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:30 --> Total execution time: 0.1852
DEBUG - 2022-11-22 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:34 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:34 --> Total execution time: 0.1163
DEBUG - 2022-11-22 04:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:52:37 --> Total execution time: 0.2313
DEBUG - 2022-11-22 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:06 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:53:07 --> Total execution time: 0.2828
DEBUG - 2022-11-22 04:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:53:14 --> Total execution time: 0.1185
DEBUG - 2022-11-22 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:23:27 --> Total execution time: 0.1884
DEBUG - 2022-11-22 04:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:23:29 --> Total execution time: 0.2427
DEBUG - 2022-11-22 04:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:23:29 --> Total execution time: 0.1857
DEBUG - 2022-11-22 04:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:53:30 --> Total execution time: 0.1950
DEBUG - 2022-11-22 04:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:23:45 --> Total execution time: 0.1921
DEBUG - 2022-11-22 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:23:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:53:46 --> Total execution time: 0.1783
DEBUG - 2022-11-22 04:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:24:28 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:54:28 --> Total execution time: 0.1240
DEBUG - 2022-11-22 04:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:54:29 --> Total execution time: 0.5115
DEBUG - 2022-11-22 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:55:20 --> Total execution time: 0.1706
DEBUG - 2022-11-22 04:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:25:36 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:55:36 --> Total execution time: 0.1167
DEBUG - 2022-11-22 04:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:25:36 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:55:37 --> Total execution time: 0.1076
DEBUG - 2022-11-22 04:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:55:41 --> Total execution time: 0.1104
DEBUG - 2022-11-22 04:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:26:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:56:21 --> Total execution time: 0.1142
DEBUG - 2022-11-22 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:27:07 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 04:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:02 --> Total execution time: 0.6890
DEBUG - 2022-11-22 04:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:03 --> Total execution time: 0.2389
DEBUG - 2022-11-22 04:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:14 --> Total execution time: 0.2423
DEBUG - 2022-11-22 04:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:18 --> Total execution time: 0.1784
DEBUG - 2022-11-22 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:32 --> Total execution time: 0.1775
DEBUG - 2022-11-22 04:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:41 --> Total execution time: 0.1950
DEBUG - 2022-11-22 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:47 --> Total execution time: 0.1775
DEBUG - 2022-11-22 04:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:48 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:48 --> Total execution time: 0.1114
DEBUG - 2022-11-22 04:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:50 --> Total execution time: 0.2376
DEBUG - 2022-11-22 04:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:58:55 --> Total execution time: 0.2487
DEBUG - 2022-11-22 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:59:07 --> Total execution time: 0.2012
DEBUG - 2022-11-22 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:29:15 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:59:15 --> Total execution time: 0.1275
DEBUG - 2022-11-22 04:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:29:57 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:59:57 --> Total execution time: 0.1396
DEBUG - 2022-11-22 04:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:30:37 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:00:37 --> Total execution time: 0.1876
DEBUG - 2022-11-22 04:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:00:40 --> Total execution time: 0.1902
DEBUG - 2022-11-22 04:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:00:41 --> Total execution time: 0.1764
DEBUG - 2022-11-22 04:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:01:16 --> Total execution time: 0.1868
DEBUG - 2022-11-22 04:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:31:17 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:01:17 --> Total execution time: 0.2001
DEBUG - 2022-11-22 04:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:31:22 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:01:22 --> Total execution time: 0.4847
DEBUG - 2022-11-22 04:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:31:34 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:01:34 --> Total execution time: 0.1189
DEBUG - 2022-11-22 04:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:31:58 --> 404 Page Not Found: Apple-iphone-11-64-gb-in-product-red-for-tmobile-952854html/index
DEBUG - 2022-11-22 04:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:02:22 --> Total execution time: 0.2012
DEBUG - 2022-11-22 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:03:58 --> Total execution time: 0.2844
DEBUG - 2022-11-22 04:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:04:05 --> Total execution time: 0.3016
DEBUG - 2022-11-22 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:04:07 --> Total execution time: 0.2513
DEBUG - 2022-11-22 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:11 --> Total execution time: 0.3915
DEBUG - 2022-11-22 04:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:49 --> Total execution time: 0.2860
DEBUG - 2022-11-22 04:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:49 --> Total execution time: 0.4535
DEBUG - 2022-11-22 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:50 --> Total execution time: 0.2982
DEBUG - 2022-11-22 04:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:53 --> Total execution time: 0.6905
DEBUG - 2022-11-22 04:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:53 --> Total execution time: 0.3028
DEBUG - 2022-11-22 04:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:58 --> Total execution time: 0.2402
DEBUG - 2022-11-22 04:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:58 --> Total execution time: 0.5189
DEBUG - 2022-11-22 04:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:05:59 --> Total execution time: 0.2321
DEBUG - 2022-11-22 04:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:06:08 --> Total execution time: 0.2926
DEBUG - 2022-11-22 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:06:34 --> Total execution time: 0.4893
DEBUG - 2022-11-22 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:02 --> Total execution time: 0.1947
DEBUG - 2022-11-22 04:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:10 --> Total execution time: 0.1889
DEBUG - 2022-11-22 04:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:12 --> Total execution time: 0.1955
DEBUG - 2022-11-22 04:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:22 --> Total execution time: 0.1888
DEBUG - 2022-11-22 04:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:25 --> Total execution time: 0.1848
DEBUG - 2022-11-22 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:27 --> Total execution time: 0.3742
DEBUG - 2022-11-22 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:32 --> Total execution time: 0.1821
DEBUG - 2022-11-22 04:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:07:51 --> Total execution time: 0.5529
DEBUG - 2022-11-22 04:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:08:08 --> Total execution time: 0.1129
DEBUG - 2022-11-22 04:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:38:37 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:08:38 --> Total execution time: 0.4743
DEBUG - 2022-11-22 04:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:08:46 --> Total execution time: 0.1823
DEBUG - 2022-11-22 04:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:08:54 --> Total execution time: 0.2069
DEBUG - 2022-11-22 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:09:01 --> Total execution time: 0.2541
DEBUG - 2022-11-22 04:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:09:34 --> Total execution time: 0.1859
DEBUG - 2022-11-22 04:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:40:55 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:10:55 --> Total execution time: 0.1782
DEBUG - 2022-11-22 04:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:40:57 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:10:57 --> Total execution time: 0.1219
DEBUG - 2022-11-22 04:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:41:12 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:11:12 --> Total execution time: 0.1387
DEBUG - 2022-11-22 04:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:41:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 04:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:11:15 --> Total execution time: 0.1218
DEBUG - 2022-11-22 04:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:42:24 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:12:24 --> Total execution time: 0.1130
DEBUG - 2022-11-22 04:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:43:28 --> Total execution time: 0.2064
DEBUG - 2022-11-22 04:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:43:30 --> Total execution time: 0.1750
DEBUG - 2022-11-22 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:43:31 --> Total execution time: 0.2268
DEBUG - 2022-11-22 04:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:15:55 --> Total execution time: 0.2046
DEBUG - 2022-11-22 04:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:16:09 --> Total execution time: 0.1898
DEBUG - 2022-11-22 04:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:16:16 --> Total execution time: 0.2484
DEBUG - 2022-11-22 04:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:16:28 --> Total execution time: 0.2095
DEBUG - 2022-11-22 04:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:16:32 --> Total execution time: 0.2496
DEBUG - 2022-11-22 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:16:37 --> Total execution time: 0.2186
DEBUG - 2022-11-22 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:49 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:16:49 --> Total execution time: 0.4923
DEBUG - 2022-11-22 04:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:46:58 --> Total execution time: 0.1225
DEBUG - 2022-11-22 04:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:47:04 --> Total execution time: 0.1957
DEBUG - 2022-11-22 04:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:09 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:17:09 --> Total execution time: 0.1146
DEBUG - 2022-11-22 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 04:47:11 --> Total execution time: 0.1773
DEBUG - 2022-11-22 04:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:17:14 --> Total execution time: 0.1227
DEBUG - 2022-11-22 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:15 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:17:15 --> Total execution time: 0.1177
DEBUG - 2022-11-22 04:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:17:46 --> Total execution time: 0.1883
DEBUG - 2022-11-22 04:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:47:54 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:17:54 --> Total execution time: 0.1352
DEBUG - 2022-11-22 04:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:18:36 --> Total execution time: 0.4740
DEBUG - 2022-11-22 04:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:49:37 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 04:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:49:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:19:56 --> Total execution time: 0.4628
DEBUG - 2022-11-22 04:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:53:52 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:23:53 --> Total execution time: 0.7602
DEBUG - 2022-11-22 04:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:55:04 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:25:04 --> Total execution time: 0.1268
DEBUG - 2022-11-22 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:25:43 --> Total execution time: 0.1159
DEBUG - 2022-11-22 04:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:57:35 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:27:36 --> Total execution time: 0.1211
DEBUG - 2022-11-22 04:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:58:02 --> No URI present. Default controller set.
DEBUG - 2022-11-22 04:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 04:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:28:02 --> Total execution time: 0.1379
DEBUG - 2022-11-22 04:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 04:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 04:59:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-11-22 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:30:03 --> Total execution time: 0.1535
DEBUG - 2022-11-22 05:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:30:39 --> Total execution time: 0.6248
DEBUG - 2022-11-22 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:30:47 --> Total execution time: 0.2578
DEBUG - 2022-11-22 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:30:52 --> Total execution time: 0.1995
DEBUG - 2022-11-22 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:31:04 --> Total execution time: 0.2275
DEBUG - 2022-11-22 05:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:31:16 --> Total execution time: 0.1996
DEBUG - 2022-11-22 05:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:31:20 --> Total execution time: 0.2095
DEBUG - 2022-11-22 05:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:01:55 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:31:55 --> Total execution time: 0.1389
DEBUG - 2022-11-22 05:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:32:04 --> Total execution time: 0.1197
DEBUG - 2022-11-22 05:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:32:26 --> Total execution time: 0.1871
DEBUG - 2022-11-22 05:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:02:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:02:37 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-22 05:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:32:47 --> Total execution time: 0.1954
DEBUG - 2022-11-22 05:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:32:55 --> Total execution time: 0.1944
DEBUG - 2022-11-22 05:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:33:01 --> Total execution time: 0.5712
DEBUG - 2022-11-22 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:33:26 --> Total execution time: 0.2312
DEBUG - 2022-11-22 05:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:03:40 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:33:40 --> Total execution time: 0.2338
DEBUG - 2022-11-22 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:04:27 --> 404 Page Not Found: Courses/index
DEBUG - 2022-11-22 05:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:36:07 --> Total execution time: 0.2092
DEBUG - 2022-11-22 05:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:36:09 --> Total execution time: 0.1795
DEBUG - 2022-11-22 05:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:36:28 --> Total execution time: 0.2384
DEBUG - 2022-11-22 05:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:36:39 --> Total execution time: 0.5196
DEBUG - 2022-11-22 05:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:37:57 --> Total execution time: 1.1879
DEBUG - 2022-11-22 05:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:09:20 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:39:21 --> Total execution time: 1.3095
DEBUG - 2022-11-22 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:39:29 --> Total execution time: 0.1820
DEBUG - 2022-11-22 05:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:40:01 --> Total execution time: 0.2206
DEBUG - 2022-11-22 05:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:40:11 --> Total execution time: 0.1922
DEBUG - 2022-11-22 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:40:26 --> Total execution time: 0.1898
DEBUG - 2022-11-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:40:36 --> Total execution time: 0.1980
DEBUG - 2022-11-22 05:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:40:54 --> Total execution time: 0.1851
DEBUG - 2022-11-22 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:11:07 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:41:08 --> Total execution time: 0.2392
DEBUG - 2022-11-22 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:11:42 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:41:42 --> Total execution time: 0.1804
DEBUG - 2022-11-22 05:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:12:05 --> Total execution time: 0.2034
DEBUG - 2022-11-22 05:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:12:07 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 05:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:12:07 --> Total execution time: 0.1948
DEBUG - 2022-11-22 05:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:12:07 --> Total execution time: 0.1831
DEBUG - 2022-11-22 05:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:42:38 --> Total execution time: 0.5519
DEBUG - 2022-11-22 05:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:43:16 --> Total execution time: 2.3797
DEBUG - 2022-11-22 05:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:13:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:13:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 05:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:46:48 --> Total execution time: 0.6062
DEBUG - 2022-11-22 05:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:48:22 --> Total execution time: 0.1842
DEBUG - 2022-11-22 05:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:48:36 --> Total execution time: 0.1883
DEBUG - 2022-11-22 05:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:49:09 --> Total execution time: 0.1972
DEBUG - 2022-11-22 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:49:36 --> Total execution time: 0.1947
DEBUG - 2022-11-22 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:49:45 --> Total execution time: 0.3435
DEBUG - 2022-11-22 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:18 --> Total execution time: 0.3502
DEBUG - 2022-11-22 05:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:24 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:24 --> Total execution time: 0.1160
DEBUG - 2022-11-22 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:25 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:25 --> Total execution time: 0.1228
DEBUG - 2022-11-22 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:39 --> Total execution time: 0.1930
DEBUG - 2022-11-22 05:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:44 --> Total execution time: 0.1464
DEBUG - 2022-11-22 05:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:47 --> Total execution time: 0.1931
DEBUG - 2022-11-22 05:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:50:50 --> Total execution time: 0.1230
DEBUG - 2022-11-22 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:51:06 --> Total execution time: 0.2394
DEBUG - 2022-11-22 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:51:15 --> Total execution time: 0.1937
DEBUG - 2022-11-22 05:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:51:18 --> Total execution time: 0.1093
DEBUG - 2022-11-22 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:51:18 --> Total execution time: 0.1865
DEBUG - 2022-11-22 05:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:51:26 --> Total execution time: 0.2861
DEBUG - 2022-11-22 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:53:38 --> Total execution time: 0.1871
DEBUG - 2022-11-22 05:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:23:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:53:56 --> Total execution time: 0.1234
DEBUG - 2022-11-22 05:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:54:40 --> Total execution time: 0.1212
DEBUG - 2022-11-22 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:55:11 --> Total execution time: 0.1948
DEBUG - 2022-11-22 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:55:13 --> Total execution time: 0.2037
DEBUG - 2022-11-22 05:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:55:22 --> Total execution time: 0.2711
DEBUG - 2022-11-22 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:55:27 --> Total execution time: 0.1907
DEBUG - 2022-11-22 05:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 16:55:30 --> Total execution time: 0.2730
DEBUG - 2022-11-22 05:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:00:05 --> Total execution time: 1.3831
DEBUG - 2022-11-22 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:00:25 --> Total execution time: 0.1838
DEBUG - 2022-11-22 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:00:30 --> Total execution time: 0.1997
DEBUG - 2022-11-22 05:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:31:36 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:01:36 --> Total execution time: 0.1496
DEBUG - 2022-11-22 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:02:35 --> Total execution time: 0.5513
DEBUG - 2022-11-22 05:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:02:41 --> Total execution time: 0.1877
DEBUG - 2022-11-22 05:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:02:53 --> Total execution time: 0.2165
DEBUG - 2022-11-22 05:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:35:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 05:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:35:45 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 05:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:36:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:06:14 --> Total execution time: 0.1074
DEBUG - 2022-11-22 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:10 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:10 --> Total execution time: 0.1258
DEBUG - 2022-11-22 05:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:16 --> Total execution time: 0.1718
DEBUG - 2022-11-22 05:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:19 --> Total execution time: 0.1719
DEBUG - 2022-11-22 05:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:28 --> Total execution time: 0.2033
DEBUG - 2022-11-22 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:38 --> Total execution time: 0.2087
DEBUG - 2022-11-22 05:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:45 --> Total execution time: 0.2338
DEBUG - 2022-11-22 05:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:07:56 --> Total execution time: 0.1804
DEBUG - 2022-11-22 05:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:08:03 --> Total execution time: 0.1957
DEBUG - 2022-11-22 05:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:08:10 --> Total execution time: 0.1772
DEBUG - 2022-11-22 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:08:16 --> Total execution time: 0.2155
DEBUG - 2022-11-22 05:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:09:01 --> Total execution time: 0.1850
DEBUG - 2022-11-22 05:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:40:50 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:10:51 --> Total execution time: 0.7133
DEBUG - 2022-11-22 05:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:40:59 --> Total execution time: 0.1094
DEBUG - 2022-11-22 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:41:01 --> Total execution time: 0.2252
DEBUG - 2022-11-22 05:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:41:01 --> Total execution time: 0.1783
DEBUG - 2022-11-22 05:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:11:53 --> Total execution time: 0.2066
DEBUG - 2022-11-22 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:12:02 --> Total execution time: 0.3202
DEBUG - 2022-11-22 05:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:12:15 --> Total execution time: 4.0529
DEBUG - 2022-11-22 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:12:31 --> Total execution time: 0.2134
DEBUG - 2022-11-22 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:12:34 --> Total execution time: 0.2416
DEBUG - 2022-11-22 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:12:38 --> Total execution time: 0.2065
DEBUG - 2022-11-22 05:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:15:05 --> Total execution time: 0.2896
DEBUG - 2022-11-22 05:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:15:12 --> Total execution time: 0.2078
DEBUG - 2022-11-22 05:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:15:17 --> Total execution time: 0.2044
DEBUG - 2022-11-22 05:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:16:08 --> Total execution time: 0.1425
DEBUG - 2022-11-22 05:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:16:16 --> Total execution time: 0.2339
DEBUG - 2022-11-22 05:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:16:21 --> Total execution time: 0.2723
DEBUG - 2022-11-22 05:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:16:26 --> Total execution time: 0.1875
DEBUG - 2022-11-22 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:16:40 --> Total execution time: 0.2021
DEBUG - 2022-11-22 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:47:00 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:17:00 --> Total execution time: 0.1191
DEBUG - 2022-11-22 05:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:18 --> Total execution time: 0.8363
DEBUG - 2022-11-22 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:29 --> Total execution time: 0.2095
DEBUG - 2022-11-22 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:37 --> Total execution time: 0.2444
DEBUG - 2022-11-22 05:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:39 --> Total execution time: 0.1741
DEBUG - 2022-11-22 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:53 --> Total execution time: 0.1856
DEBUG - 2022-11-22 05:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:57 --> Total execution time: 0.1082
DEBUG - 2022-11-22 05:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:59 --> Total execution time: 0.1264
DEBUG - 2022-11-22 05:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:19:59 --> Total execution time: 0.1184
DEBUG - 2022-11-22 05:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:00 --> Total execution time: 0.2684
DEBUG - 2022-11-22 05:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:02 --> Total execution time: 0.3993
DEBUG - 2022-11-22 05:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:07 --> Total execution time: 0.2275
DEBUG - 2022-11-22 05:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:17 --> Total execution time: 0.2229
DEBUG - 2022-11-22 05:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:27 --> Total execution time: 0.1823
DEBUG - 2022-11-22 05:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:30 --> Total execution time: 0.1796
DEBUG - 2022-11-22 05:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:32 --> Total execution time: 0.2402
DEBUG - 2022-11-22 05:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:45 --> Total execution time: 0.1194
DEBUG - 2022-11-22 05:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:46 --> Total execution time: 0.1913
DEBUG - 2022-11-22 05:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:54 --> Total execution time: 0.1791
DEBUG - 2022-11-22 05:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:54 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:55 --> Total execution time: 0.4868
DEBUG - 2022-11-22 05:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:55 --> Total execution time: 0.1768
DEBUG - 2022-11-22 05:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:20:57 --> Total execution time: 0.3871
DEBUG - 2022-11-22 05:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:01 --> Total execution time: 0.2257
DEBUG - 2022-11-22 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:02 --> Total execution time: 0.2840
DEBUG - 2022-11-22 05:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:10 --> Total execution time: 0.1901
DEBUG - 2022-11-22 05:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:16 --> Total execution time: 0.2093
DEBUG - 2022-11-22 05:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:23 --> Total execution time: 0.6267
DEBUG - 2022-11-22 05:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:24 --> Total execution time: 0.2283
DEBUG - 2022-11-22 05:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:26 --> Total execution time: 0.1784
DEBUG - 2022-11-22 05:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:46 --> Total execution time: 0.2939
DEBUG - 2022-11-22 05:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:21:57 --> Total execution time: 0.1972
DEBUG - 2022-11-22 05:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:04 --> Total execution time: 0.1998
DEBUG - 2022-11-22 05:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:20 --> Total execution time: 0.1887
DEBUG - 2022-11-22 05:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:27 --> Total execution time: 0.4157
DEBUG - 2022-11-22 05:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:28 --> Total execution time: 0.2051
DEBUG - 2022-11-22 05:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:39 --> Total execution time: 0.1960
DEBUG - 2022-11-22 05:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:45 --> Total execution time: 0.7161
DEBUG - 2022-11-22 05:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:22:57 --> Total execution time: 0.1798
DEBUG - 2022-11-22 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:23:01 --> Total execution time: 0.2749
DEBUG - 2022-11-22 05:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:13 --> No URI present. Default controller set.
DEBUG - 2022-11-22 05:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:23:13 --> Total execution time: 0.4784
DEBUG - 2022-11-22 05:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:23:21 --> Total execution time: 0.2040
DEBUG - 2022-11-22 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:23:23 --> Total execution time: 0.1736
DEBUG - 2022-11-22 05:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:23:31 --> Total execution time: 0.4688
DEBUG - 2022-11-22 05:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:23:32 --> Total execution time: 0.3757
DEBUG - 2022-11-22 05:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:24:08 --> Total execution time: 0.2241
DEBUG - 2022-11-22 05:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 05:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:24:55 --> Total execution time: 0.8106
DEBUG - 2022-11-22 05:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:28:11 --> Total execution time: 0.5710
DEBUG - 2022-11-22 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:28:43 --> Total execution time: 0.1883
DEBUG - 2022-11-22 05:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:28:45 --> Total execution time: 0.5029
DEBUG - 2022-11-22 05:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 05:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:28:48 --> Total execution time: 0.1833
DEBUG - 2022-11-22 05:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 05:59:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 05:59:40 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-22 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:30:03 --> Total execution time: 0.3302
DEBUG - 2022-11-22 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:04:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:34:45 --> Total execution time: 0.3415
DEBUG - 2022-11-22 06:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:05:26 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:35:27 --> Total execution time: 0.4923
DEBUG - 2022-11-22 06:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:38:44 --> Total execution time: 0.1192
DEBUG - 2022-11-22 06:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:11:02 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:41:02 --> Total execution time: 0.1182
DEBUG - 2022-11-22 06:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:41:58 --> Total execution time: 0.1746
DEBUG - 2022-11-22 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:42:02 --> Total execution time: 0.1100
DEBUG - 2022-11-22 06:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:42:21 --> Total execution time: 0.2204
DEBUG - 2022-11-22 06:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:42:43 --> Total execution time: 0.2222
DEBUG - 2022-11-22 06:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:42:47 --> Total execution time: 0.2222
DEBUG - 2022-11-22 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:42:56 --> Total execution time: 0.1819
DEBUG - 2022-11-22 06:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:14:18 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:44:19 --> Total execution time: 0.6953
DEBUG - 2022-11-22 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:44:38 --> Total execution time: 0.1699
DEBUG - 2022-11-22 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:14:42 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:44:42 --> Total execution time: 0.1309
DEBUG - 2022-11-22 06:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:15:54 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:45:54 --> Total execution time: 0.1281
DEBUG - 2022-11-22 06:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:45:56 --> Total execution time: 0.1757
DEBUG - 2022-11-22 06:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:05 --> Total execution time: 0.1708
DEBUG - 2022-11-22 06:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:31 --> Total execution time: 0.2443
DEBUG - 2022-11-22 06:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:40 --> Total execution time: 0.1699
DEBUG - 2022-11-22 06:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:45 --> Total execution time: 0.2411
DEBUG - 2022-11-22 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:57 --> Total execution time: 0.1946
DEBUG - 2022-11-22 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:58 --> Total execution time: 0.1995
DEBUG - 2022-11-22 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:46:58 --> Total execution time: 0.1910
DEBUG - 2022-11-22 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:00 --> Total execution time: 0.1867
DEBUG - 2022-11-22 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:04 --> Total execution time: 0.1749
DEBUG - 2022-11-22 06:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:22 --> Total execution time: 0.1752
DEBUG - 2022-11-22 06:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:30 --> Total execution time: 0.1834
DEBUG - 2022-11-22 06:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:31 --> Total execution time: 0.1914
DEBUG - 2022-11-22 06:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:37 --> Total execution time: 0.1884
DEBUG - 2022-11-22 06:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:52 --> Total execution time: 0.1836
DEBUG - 2022-11-22 06:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:47:57 --> Total execution time: 0.1802
DEBUG - 2022-11-22 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:48:23 --> Total execution time: 0.1958
DEBUG - 2022-11-22 06:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:48:52 --> Total execution time: 0.1799
DEBUG - 2022-11-22 06:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:23:10 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:53:11 --> Total execution time: 0.5657
DEBUG - 2022-11-22 06:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:23:12 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:53:12 --> Total execution time: 0.1769
DEBUG - 2022-11-22 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:53:49 --> Total execution time: 0.5833
DEBUG - 2022-11-22 06:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:53:49 --> Total execution time: 0.5806
DEBUG - 2022-11-22 06:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:53:57 --> Total execution time: 0.1991
DEBUG - 2022-11-22 06:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:54:03 --> Total execution time: 0.1863
DEBUG - 2022-11-22 06:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:24:05 --> Total execution time: 0.1177
DEBUG - 2022-11-22 06:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:54:08 --> Total execution time: 0.1895
DEBUG - 2022-11-22 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:24:09 --> Total execution time: 0.1927
DEBUG - 2022-11-22 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:24:09 --> Total execution time: 0.2357
DEBUG - 2022-11-22 06:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:25:53 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:55:54 --> Total execution time: 0.6427
DEBUG - 2022-11-22 06:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:26:20 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:56:20 --> Total execution time: 0.1152
DEBUG - 2022-11-22 06:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:57:16 --> Total execution time: 0.2136
DEBUG - 2022-11-22 06:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:57:25 --> Total execution time: 0.1873
DEBUG - 2022-11-22 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:57:35 --> Total execution time: 0.2702
DEBUG - 2022-11-22 06:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:57:52 --> Total execution time: 0.3416
DEBUG - 2022-11-22 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:29 --> Total execution time: 0.2077
DEBUG - 2022-11-22 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:29 --> Total execution time: 0.1843
DEBUG - 2022-11-22 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:30 --> Total execution time: 0.1894
DEBUG - 2022-11-22 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:30 --> Total execution time: 0.1893
DEBUG - 2022-11-22 06:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:35 --> Total execution time: 0.2168
DEBUG - 2022-11-22 06:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:42 --> Total execution time: 0.1937
DEBUG - 2022-11-22 06:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:49 --> Total execution time: 0.2203
DEBUG - 2022-11-22 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:58:52 --> Total execution time: 0.4993
DEBUG - 2022-11-22 06:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:59:03 --> Total execution time: 0.2561
DEBUG - 2022-11-22 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:59:09 --> Total execution time: 0.2035
DEBUG - 2022-11-22 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:59:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 06:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:59:49 --> Total execution time: 0.2277
DEBUG - 2022-11-22 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 17:59:59 --> Total execution time: 0.6582
DEBUG - 2022-11-22 06:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:06 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:06 --> Total execution time: 0.3406
DEBUG - 2022-11-22 06:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:07 --> Total execution time: 0.3862
DEBUG - 2022-11-22 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:08 --> Total execution time: 0.2995
DEBUG - 2022-11-22 06:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:08 --> Total execution time: 0.5734
DEBUG - 2022-11-22 06:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:12 --> Total execution time: 0.2434
DEBUG - 2022-11-22 06:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:21 --> Total execution time: 0.1858
DEBUG - 2022-11-22 06:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:24 --> Total execution time: 0.2210
DEBUG - 2022-11-22 06:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:30 --> Total execution time: 0.2126
DEBUG - 2022-11-22 06:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:31 --> Total execution time: 0.2114
DEBUG - 2022-11-22 06:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:36 --> Total execution time: 0.1719
DEBUG - 2022-11-22 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:39 --> Total execution time: 0.2281
DEBUG - 2022-11-22 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:40 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:41 --> Total execution time: 0.5195
DEBUG - 2022-11-22 06:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:41 --> Total execution time: 0.2497
DEBUG - 2022-11-22 06:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:44 --> Total execution time: 0.2207
DEBUG - 2022-11-22 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:52 --> Total execution time: 0.1793
DEBUG - 2022-11-22 06:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:53 --> Total execution time: 0.2068
DEBUG - 2022-11-22 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:00:59 --> Total execution time: 0.2481
DEBUG - 2022-11-22 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:01:34 --> Total execution time: 0.1930
DEBUG - 2022-11-22 06:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:31:49 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:01:50 --> Total execution time: 0.1259
DEBUG - 2022-11-22 06:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:31:55 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:01:55 --> Total execution time: 0.1775
DEBUG - 2022-11-22 06:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:02:26 --> Total execution time: 0.8341
DEBUG - 2022-11-22 06:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:32:27 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:02:27 --> Total execution time: 0.2974
DEBUG - 2022-11-22 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:03:56 --> Total execution time: 0.5854
DEBUG - 2022-11-22 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:04:03 --> Total execution time: 0.2324
DEBUG - 2022-11-22 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:04:19 --> Total execution time: 0.2294
DEBUG - 2022-11-22 06:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:05:30 --> Total execution time: 0.5634
DEBUG - 2022-11-22 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:05:49 --> Total execution time: 0.1891
DEBUG - 2022-11-22 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:05:52 --> Total execution time: 0.1786
DEBUG - 2022-11-22 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:53 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:05:53 --> Total execution time: 0.1121
DEBUG - 2022-11-22 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:53 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:05:53 --> Total execution time: 0.1100
DEBUG - 2022-11-22 06:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:35:58 --> Total execution time: 0.1061
DEBUG - 2022-11-22 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:06:02 --> Total execution time: 0.1981
DEBUG - 2022-11-22 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:06:03 --> Total execution time: 0.2009
DEBUG - 2022-11-22 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:36:13 --> Total execution time: 0.1367
DEBUG - 2022-11-22 06:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:06:14 --> Total execution time: 0.2445
DEBUG - 2022-11-22 06:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:36:19 --> Total execution time: 0.1278
DEBUG - 2022-11-22 06:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:37:10 --> 404 Page Not Found: Author/admin
DEBUG - 2022-11-22 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:08:13 --> Total execution time: 0.9897
DEBUG - 2022-11-22 06:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:08:26 --> Total execution time: 0.4795
DEBUG - 2022-11-22 06:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:09:19 --> Total execution time: 0.1740
DEBUG - 2022-11-22 06:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:10:55 --> Total execution time: 0.2265
DEBUG - 2022-11-22 06:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:41:03 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:11:03 --> Total execution time: 0.1144
DEBUG - 2022-11-22 06:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:41:07 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:11:07 --> Total execution time: 0.1105
DEBUG - 2022-11-22 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:11:36 --> Total execution time: 0.2443
DEBUG - 2022-11-22 06:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:11:53 --> Total execution time: 0.1135
DEBUG - 2022-11-22 06:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:02 --> Total execution time: 0.1860
DEBUG - 2022-11-22 06:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:07 --> Total execution time: 0.1805
DEBUG - 2022-11-22 06:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:14 --> Total execution time: 0.1967
DEBUG - 2022-11-22 06:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:19 --> Total execution time: 0.2163
DEBUG - 2022-11-22 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:22 --> Total execution time: 0.2467
DEBUG - 2022-11-22 06:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:22 --> Total execution time: 0.5337
DEBUG - 2022-11-22 06:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:22 --> Total execution time: 0.2481
DEBUG - 2022-11-22 06:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:22 --> Total execution time: 0.4935
DEBUG - 2022-11-22 06:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:23 --> Total execution time: 0.7797
DEBUG - 2022-11-22 06:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:12:23 --> Total execution time: 1.0453
DEBUG - 2022-11-22 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:13:10 --> Total execution time: 0.2763
DEBUG - 2022-11-22 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:13:10 --> Total execution time: 0.1323
DEBUG - 2022-11-22 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:11 --> Total execution time: 0.5794
DEBUG - 2022-11-22 06:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:18 --> Total execution time: 0.2214
DEBUG - 2022-11-22 06:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:19 --> Total execution time: 0.2099
DEBUG - 2022-11-22 06:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:20 --> Total execution time: 0.3744
DEBUG - 2022-11-22 06:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:47 --> Total execution time: 0.1453
DEBUG - 2022-11-22 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:44:48 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-11-22 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:44:48 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
DEBUG - 2022-11-22 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:44:48 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-11-22 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:44:49 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-11-22 06:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:49 --> Total execution time: 0.2409
DEBUG - 2022-11-22 06:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:44:50 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-11-22 06:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:14:57 --> Total execution time: 0.2202
DEBUG - 2022-11-22 06:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:15:05 --> Total execution time: 0.2204
DEBUG - 2022-11-22 06:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:15:24 --> Total execution time: 0.1816
DEBUG - 2022-11-22 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:15:28 --> Total execution time: 0.1166
DEBUG - 2022-11-22 06:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:15:29 --> Total execution time: 0.1770
DEBUG - 2022-11-22 06:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:15:36 --> Total execution time: 0.1814
DEBUG - 2022-11-22 06:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:15:47 --> Total execution time: 0.2469
DEBUG - 2022-11-22 06:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:16:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 06:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:16:22 --> Total execution time: 0.2111
DEBUG - 2022-11-22 06:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:16:53 --> Total execution time: 0.2098
DEBUG - 2022-11-22 06:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:17:06 --> Total execution time: 0.2380
DEBUG - 2022-11-22 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:17:07 --> Total execution time: 0.1792
DEBUG - 2022-11-22 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:17:21 --> Total execution time: 0.2133
DEBUG - 2022-11-22 06:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:17:34 --> Total execution time: 0.1816
DEBUG - 2022-11-22 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:17:38 --> Total execution time: 0.2137
DEBUG - 2022-11-22 06:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:23:32 --> Total execution time: 0.1850
DEBUG - 2022-11-22 06:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:23:50 --> Total execution time: 0.4447
DEBUG - 2022-11-22 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:23:59 --> Total execution time: 0.7526
DEBUG - 2022-11-22 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:24:12 --> Total execution time: 0.2335
DEBUG - 2022-11-22 06:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:24:12 --> Total execution time: 0.1873
DEBUG - 2022-11-22 06:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:24:18 --> Total execution time: 0.2013
DEBUG - 2022-11-22 06:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:24:23 --> Total execution time: 0.2260
DEBUG - 2022-11-22 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:24:31 --> Total execution time: 0.1850
DEBUG - 2022-11-22 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:54:47 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:24:47 --> Total execution time: 0.1623
DEBUG - 2022-11-22 06:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:04 --> Total execution time: 0.1876
DEBUG - 2022-11-22 06:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:17 --> Total execution time: 0.2166
DEBUG - 2022-11-22 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:32 --> Total execution time: 0.9745
DEBUG - 2022-11-22 06:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:34 --> Total execution time: 0.1182
DEBUG - 2022-11-22 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:41 --> Total execution time: 0.8172
DEBUG - 2022-11-22 06:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:42 --> Total execution time: 0.7100
DEBUG - 2022-11-22 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:48 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:48 --> Total execution time: 0.1712
DEBUG - 2022-11-22 06:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:26:54 --> Total execution time: 0.3534
DEBUG - 2022-11-22 06:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:02 --> Total execution time: 0.2733
DEBUG - 2022-11-22 06:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:57:03 --> Total execution time: 0.2215
DEBUG - 2022-11-22 06:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:57:06 --> Total execution time: 0.2565
DEBUG - 2022-11-22 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:57:06 --> Total execution time: 0.1926
DEBUG - 2022-11-22 06:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:19 --> Total execution time: 0.6352
DEBUG - 2022-11-22 06:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:20 --> Total execution time: 0.1878
DEBUG - 2022-11-22 06:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:20 --> Total execution time: 0.1980
DEBUG - 2022-11-22 06:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:27 --> Total execution time: 0.2125
DEBUG - 2022-11-22 06:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:33 --> Total execution time: 0.1864
DEBUG - 2022-11-22 06:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:40 --> Total execution time: 0.2201
DEBUG - 2022-11-22 06:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:47 --> Total execution time: 1.6806
DEBUG - 2022-11-22 06:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:57:52 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:27:53 --> Total execution time: 0.5014
DEBUG - 2022-11-22 06:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:13 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:13 --> Total execution time: 0.1267
DEBUG - 2022-11-22 06:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:14 --> Total execution time: 0.1819
DEBUG - 2022-11-22 06:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:30 --> Total execution time: 0.1188
DEBUG - 2022-11-22 06:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:33 --> Total execution time: 0.2329
DEBUG - 2022-11-22 06:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:50 --> Total execution time: 0.1894
DEBUG - 2022-11-22 06:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:50 --> Total execution time: 0.1957
DEBUG - 2022-11-22 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:58:58 --> No URI present. Default controller set.
DEBUG - 2022-11-22 06:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:28:58 --> Total execution time: 0.1240
DEBUG - 2022-11-22 06:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:11 --> Total execution time: 0.2338
DEBUG - 2022-11-22 06:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:19 --> Total execution time: 0.1894
DEBUG - 2022-11-22 06:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:22 --> Total execution time: 0.1740
DEBUG - 2022-11-22 06:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:26 --> Total execution time: 0.1975
DEBUG - 2022-11-22 06:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:28 --> Total execution time: 0.1723
DEBUG - 2022-11-22 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 18:29:37 --> Total execution time: 2.2256
DEBUG - 2022-11-22 06:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:38 --> Total execution time: 0.2184
DEBUG - 2022-11-22 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 06:59:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-22 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:43 --> Total execution time: 0.2990
DEBUG - 2022-11-22 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:44 --> Total execution time: 0.1848
DEBUG - 2022-11-22 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 06:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 06:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:29:47 --> Total execution time: 0.2169
DEBUG - 2022-11-22 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:30:04 --> Total execution time: 0.2006
DEBUG - 2022-11-22 07:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:00:15 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:30:15 --> Total execution time: 0.2659
DEBUG - 2022-11-22 07:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:30:23 --> Total execution time: 0.1401
DEBUG - 2022-11-22 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:30:51 --> Total execution time: 0.2227
DEBUG - 2022-11-22 07:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:30:55 --> Total execution time: 1.8862
DEBUG - 2022-11-22 07:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:31:06 --> Total execution time: 0.1842
DEBUG - 2022-11-22 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:31:13 --> Total execution time: 0.2385
DEBUG - 2022-11-22 07:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:31:15 --> Total execution time: 0.5088
DEBUG - 2022-11-22 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:31:27 --> Total execution time: 0.1859
DEBUG - 2022-11-22 07:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:31:29 --> Total execution time: 0.2033
DEBUG - 2022-11-22 07:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:31:39 --> Total execution time: 0.5440
DEBUG - 2022-11-22 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:32:30 --> Total execution time: 0.2172
DEBUG - 2022-11-22 07:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:32:38 --> Total execution time: 0.2258
DEBUG - 2022-11-22 07:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:33:03 --> Total execution time: 0.2324
DEBUG - 2022-11-22 07:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:33:40 --> Total execution time: 0.6614
DEBUG - 2022-11-22 18:33:40 --> Total execution time: 0.7171
DEBUG - 2022-11-22 07:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:33:44 --> Total execution time: 0.8220
DEBUG - 2022-11-22 07:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:33:50 --> Total execution time: 0.5248
DEBUG - 2022-11-22 07:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:33:55 --> Total execution time: 1.9018
DEBUG - 2022-11-22 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:33:59 --> Total execution time: 0.2081
DEBUG - 2022-11-22 07:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:34:52 --> Total execution time: 0.8205
DEBUG - 2022-11-22 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:34:54 --> Total execution time: 0.2871
DEBUG - 2022-11-22 07:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:34:57 --> Total execution time: 0.2400
DEBUG - 2022-11-22 07:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:03 --> Total execution time: 1.0285
DEBUG - 2022-11-22 07:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:12 --> Total execution time: 1.2623
DEBUG - 2022-11-22 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:12 --> Total execution time: 0.2341
DEBUG - 2022-11-22 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:18 --> Total execution time: 0.4149
DEBUG - 2022-11-22 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:18 --> Total execution time: 0.3081
DEBUG - 2022-11-22 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:21 --> Total execution time: 1.6623
DEBUG - 2022-11-22 07:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:26 --> Total execution time: 0.4165
DEBUG - 2022-11-22 07:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:26 --> Total execution time: 0.4927
DEBUG - 2022-11-22 07:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:36 --> Total execution time: 0.4321
DEBUG - 2022-11-22 07:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 07:05:45 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-22 07:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:46 --> Total execution time: 0.3387
DEBUG - 2022-11-22 07:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:51 --> Total execution time: 0.3330
DEBUG - 2022-11-22 07:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:58 --> Total execution time: 0.1797
DEBUG - 2022-11-22 07:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:35:59 --> Total execution time: 0.1725
DEBUG - 2022-11-22 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:36:46 --> Total execution time: 0.1971
DEBUG - 2022-11-22 07:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:37:09 --> Total execution time: 0.1760
DEBUG - 2022-11-22 07:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:37:34 --> Total execution time: 0.1833
DEBUG - 2022-11-22 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:37:39 --> Total execution time: 0.2060
DEBUG - 2022-11-22 07:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:37:44 --> Total execution time: 0.1809
DEBUG - 2022-11-22 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:37:50 --> Total execution time: 0.1901
DEBUG - 2022-11-22 07:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 07:07:53 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-22 07:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:37:57 --> Total execution time: 0.1963
DEBUG - 2022-11-22 07:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:06 --> Total execution time: 0.1801
DEBUG - 2022-11-22 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:08 --> Total execution time: 0.2068
DEBUG - 2022-11-22 07:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:21 --> Total execution time: 0.1830
DEBUG - 2022-11-22 07:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 18:38:25 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-11-22 07:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:26 --> Total execution time: 0.2143
DEBUG - 2022-11-22 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:32 --> Total execution time: 0.1830
DEBUG - 2022-11-22 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:45 --> Total execution time: 0.5268
DEBUG - 2022-11-22 07:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 18:38:45 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-11-22 07:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:46 --> Total execution time: 0.3403
DEBUG - 2022-11-22 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:50 --> Total execution time: 0.2026
DEBUG - 2022-11-22 07:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:53 --> Total execution time: 0.1753
DEBUG - 2022-11-22 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:38:55 --> Total execution time: 0.2447
DEBUG - 2022-11-22 07:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:39:14 --> Total execution time: 0.2697
DEBUG - 2022-11-22 07:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:09 --> Total execution time: 0.5061
DEBUG - 2022-11-22 07:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:12 --> Total execution time: 0.2158
DEBUG - 2022-11-22 07:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:19 --> Total execution time: 0.2182
DEBUG - 2022-11-22 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:41 --> Total execution time: 0.2795
DEBUG - 2022-11-22 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:43 --> Total execution time: 0.1871
DEBUG - 2022-11-22 07:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:46 --> Total execution time: 0.1866
DEBUG - 2022-11-22 07:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:49 --> Total execution time: 0.1737
DEBUG - 2022-11-22 07:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:51 --> Total execution time: 0.4047
DEBUG - 2022-11-22 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:40:54 --> Total execution time: 0.1938
DEBUG - 2022-11-22 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:11:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:41:44 --> Total execution time: 0.5718
DEBUG - 2022-11-22 07:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:07 --> Total execution time: 0.5975
DEBUG - 2022-11-22 07:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:10 --> Total execution time: 0.2155
DEBUG - 2022-11-22 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:25 --> Total execution time: 0.2463
DEBUG - 2022-11-22 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:27 --> Total execution time: 0.1692
DEBUG - 2022-11-22 07:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:33 --> Total execution time: 0.4722
DEBUG - 2022-11-22 07:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:38 --> Total execution time: 0.1966
DEBUG - 2022-11-22 07:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:43 --> Total execution time: 0.1918
DEBUG - 2022-11-22 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:42:53 --> Total execution time: 0.1868
DEBUG - 2022-11-22 07:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:05 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:43:05 --> Total execution time: 0.1968
DEBUG - 2022-11-22 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:43:07 --> Total execution time: 0.1818
DEBUG - 2022-11-22 07:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:43:18 --> Total execution time: 0.1825
DEBUG - 2022-11-22 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:43:26 --> Total execution time: 0.1840
DEBUG - 2022-11-22 07:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:43:31 --> Total execution time: 0.1731
DEBUG - 2022-11-22 07:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:43:35 --> Total execution time: 0.1916
DEBUG - 2022-11-22 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:06 --> Total execution time: 0.5287
DEBUG - 2022-11-22 07:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:24 --> Total execution time: 0.1788
DEBUG - 2022-11-22 07:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:28 --> Total execution time: 0.2016
DEBUG - 2022-11-22 07:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:32 --> Total execution time: 0.1751
DEBUG - 2022-11-22 07:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:33 --> Total execution time: 0.2282
DEBUG - 2022-11-22 07:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:40 --> Total execution time: 0.1933
DEBUG - 2022-11-22 07:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:41 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:41 --> Total execution time: 0.1860
DEBUG - 2022-11-22 07:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:42 --> Total execution time: 0.2096
DEBUG - 2022-11-22 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:43 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:43 --> Total execution time: 0.2149
DEBUG - 2022-11-22 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:43 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:43 --> Total execution time: 0.2489
DEBUG - 2022-11-22 07:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:44 --> Total execution time: 0.1703
DEBUG - 2022-11-22 07:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:44 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:44 --> Total execution time: 0.2177
DEBUG - 2022-11-22 07:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:45 --> Total execution time: 0.1751
DEBUG - 2022-11-22 07:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:45 --> Total execution time: 0.2999
DEBUG - 2022-11-22 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:46 --> Total execution time: 0.1808
DEBUG - 2022-11-22 07:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:46 --> Total execution time: 0.4182
DEBUG - 2022-11-22 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:46 --> Total execution time: 0.1726
DEBUG - 2022-11-22 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:46 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:47 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:47 --> Total execution time: 0.2604
DEBUG - 2022-11-22 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:47 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:47 --> Total execution time: 0.3247
DEBUG - 2022-11-22 07:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:47 --> Total execution time: 0.3919
DEBUG - 2022-11-22 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:47 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:48 --> Total execution time: 0.1950
DEBUG - 2022-11-22 07:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:50 --> Total execution time: 0.1759
DEBUG - 2022-11-22 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:51 --> Total execution time: 0.1738
DEBUG - 2022-11-22 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:51 --> Total execution time: 0.1780
DEBUG - 2022-11-22 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:52 --> Total execution time: 0.2248
DEBUG - 2022-11-22 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 18:44:52 --> Total execution time: 0.2344
DEBUG - 2022-11-22 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:52 --> Total execution time: 0.2382
DEBUG - 2022-11-22 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:52 --> Total execution time: 0.2806
DEBUG - 2022-11-22 07:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:44:53 --> Total execution time: 0.1841
DEBUG - 2022-11-22 07:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:45:38 --> Total execution time: 0.1720
DEBUG - 2022-11-22 07:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:16:05 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:46:05 --> Total execution time: 0.1095
DEBUG - 2022-11-22 07:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 07:16:09 --> 404 Page Not Found: Product/starter-membership
DEBUG - 2022-11-22 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:47:12 --> Total execution time: 0.1891
DEBUG - 2022-11-22 07:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:17:20 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:47:20 --> Total execution time: 0.1858
DEBUG - 2022-11-22 07:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:17:26 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:47:26 --> Total execution time: 0.1264
DEBUG - 2022-11-22 07:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:23:47 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:53:48 --> Total execution time: 0.7822
DEBUG - 2022-11-22 07:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:53:54 --> Total execution time: 0.1742
DEBUG - 2022-11-22 07:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:24:06 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:54:06 --> Total execution time: 0.1202
DEBUG - 2022-11-22 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:24:07 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:54:07 --> Total execution time: 0.1429
DEBUG - 2022-11-22 07:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:24:43 --> Total execution time: 0.1482
DEBUG - 2022-11-22 07:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:24:46 --> Total execution time: 0.3880
DEBUG - 2022-11-22 07:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:24:46 --> Total execution time: 0.2044
DEBUG - 2022-11-22 07:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:01 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:01 --> Total execution time: 0.2019
DEBUG - 2022-11-22 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:05 --> Total execution time: 0.2533
DEBUG - 2022-11-22 07:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:07 --> Total execution time: 0.1068
DEBUG - 2022-11-22 07:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:12 --> Total execution time: 0.1657
DEBUG - 2022-11-22 07:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:21 --> Total execution time: 0.1895
DEBUG - 2022-11-22 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:26 --> Total execution time: 0.2166
DEBUG - 2022-11-22 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:30 --> Total execution time: 0.1827
DEBUG - 2022-11-22 07:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:55:40 --> Total execution time: 0.1791
DEBUG - 2022-11-22 07:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:56:13 --> Total execution time: 0.2244
DEBUG - 2022-11-22 07:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:29:04 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:59:05 --> Total execution time: 0.4761
DEBUG - 2022-11-22 07:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:59:17 --> Total execution time: 0.4893
DEBUG - 2022-11-22 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:59:20 --> Total execution time: 0.1816
DEBUG - 2022-11-22 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 18:59:23 --> Total execution time: 0.0997
DEBUG - 2022-11-22 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:00:06 --> Total execution time: 0.1911
DEBUG - 2022-11-22 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:00:13 --> Total execution time: 0.1806
DEBUG - 2022-11-22 07:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:02:06 --> Total execution time: 0.1980
DEBUG - 2022-11-22 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 07:33:04 --> 404 Page Not Found: Squishmallows-12-wade-the-werewolfskeleton-halloween-2022-new-select-series-366024html/index
DEBUG - 2022-11-22 07:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:03:51 --> Total execution time: 0.1994
DEBUG - 2022-11-22 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:03:52 --> Total execution time: 0.1742
DEBUG - 2022-11-22 07:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:03:58 --> Total execution time: 0.1748
DEBUG - 2022-11-22 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:04:06 --> Total execution time: 0.1930
DEBUG - 2022-11-22 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:14 --> Total execution time: 0.2039
DEBUG - 2022-11-22 07:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:21 --> Total execution time: 0.2245
DEBUG - 2022-11-22 07:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:04:24 --> Total execution time: 0.1904
DEBUG - 2022-11-22 07:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:04:24 --> Total execution time: 0.1098
DEBUG - 2022-11-22 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:04:28 --> Total execution time: 0.1808
DEBUG - 2022-11-22 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:29 --> Total execution time: 0.2103
DEBUG - 2022-11-22 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:35 --> Total execution time: 0.1897
DEBUG - 2022-11-22 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:43 --> Total execution time: 0.1678
DEBUG - 2022-11-22 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:04:46 --> Total execution time: 0.1992
DEBUG - 2022-11-22 07:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:04:49 --> Total execution time: 0.2185
DEBUG - 2022-11-22 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:34:58 --> Total execution time: 0.1785
DEBUG - 2022-11-22 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:09 --> Total execution time: 0.1901
DEBUG - 2022-11-22 07:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:20 --> Total execution time: 0.1716
DEBUG - 2022-11-22 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:24 --> Total execution time: 0.1782
DEBUG - 2022-11-22 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:28 --> Total execution time: 0.1750
DEBUG - 2022-11-22 07:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:45 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:05:45 --> Total execution time: 0.3133
DEBUG - 2022-11-22 07:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:51 --> Total execution time: 0.2195
DEBUG - 2022-11-22 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:05:54 --> Total execution time: 0.1806
DEBUG - 2022-11-22 07:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:35:56 --> Total execution time: 0.1862
DEBUG - 2022-11-22 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:36:00 --> Total execution time: 0.2025
DEBUG - 2022-11-22 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:02 --> Total execution time: 0.1809
DEBUG - 2022-11-22 07:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:05 --> Total execution time: 0.1773
DEBUG - 2022-11-22 07:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:17 --> Total execution time: 0.2627
DEBUG - 2022-11-22 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:36 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:36 --> Total execution time: 0.1788
DEBUG - 2022-11-22 07:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:45 --> Total execution time: 0.3147
DEBUG - 2022-11-22 07:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:48 --> Total execution time: 0.2120
DEBUG - 2022-11-22 07:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:48 --> Total execution time: 0.4694
DEBUG - 2022-11-22 07:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:06:50 --> Total execution time: 0.1882
DEBUG - 2022-11-22 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:00 --> Total execution time: 0.2455
DEBUG - 2022-11-22 07:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:18 --> Total execution time: 0.1843
DEBUG - 2022-11-22 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:23 --> Total execution time: 0.2645
DEBUG - 2022-11-22 07:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:24 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:24 --> Total execution time: 0.1881
DEBUG - 2022-11-22 07:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:29 --> Total execution time: 0.2029
DEBUG - 2022-11-22 07:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:36 --> Total execution time: 0.1847
DEBUG - 2022-11-22 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:45 --> Total execution time: 0.2214
DEBUG - 2022-11-22 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:07:49 --> Total execution time: 0.1772
DEBUG - 2022-11-22 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:08:11 --> Total execution time: 0.1752
DEBUG - 2022-11-22 07:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:08:26 --> Total execution time: 0.2550
DEBUG - 2022-11-22 07:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:08:38 --> Total execution time: 0.1713
DEBUG - 2022-11-22 07:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:08:47 --> Total execution time: 0.7744
DEBUG - 2022-11-22 07:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:08:55 --> Total execution time: 0.3096
DEBUG - 2022-11-22 07:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:09:11 --> Total execution time: 0.4724
DEBUG - 2022-11-22 07:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:09:21 --> Total execution time: 0.2132
DEBUG - 2022-11-22 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:09:42 --> Total execution time: 0.2033
DEBUG - 2022-11-22 07:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:09:48 --> Total execution time: 0.2355
DEBUG - 2022-11-22 07:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:10:11 --> Total execution time: 0.7032
DEBUG - 2022-11-22 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:10:25 --> Total execution time: 0.1851
DEBUG - 2022-11-22 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:10:29 --> Total execution time: 0.1811
DEBUG - 2022-11-22 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:10:37 --> Total execution time: 0.1828
DEBUG - 2022-11-22 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:20 --> Total execution time: 0.5396
DEBUG - 2022-11-22 07:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:21 --> Total execution time: 0.5351
DEBUG - 2022-11-22 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:27 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:28 --> Total execution time: 0.1579
DEBUG - 2022-11-22 07:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:31 --> Total execution time: 0.2034
DEBUG - 2022-11-22 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:40 --> Total execution time: 0.2055
DEBUG - 2022-11-22 07:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:45 --> Total execution time: 0.2009
DEBUG - 2022-11-22 07:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:11:48 --> Total execution time: 0.2158
DEBUG - 2022-11-22 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:42:55 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:12:55 --> Total execution time: 0.1139
DEBUG - 2022-11-22 07:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:42:56 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:12:56 --> Total execution time: 0.1141
DEBUG - 2022-11-22 07:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:42:57 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:12:57 --> Total execution time: 0.1333
DEBUG - 2022-11-22 07:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:13:16 --> Total execution time: 0.1101
DEBUG - 2022-11-22 07:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:13:23 --> Total execution time: 0.1889
DEBUG - 2022-11-22 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:13:24 --> Total execution time: 0.1819
DEBUG - 2022-11-22 07:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:13:33 --> Total execution time: 0.2549
DEBUG - 2022-11-22 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:13:48 --> Total execution time: 0.1874
DEBUG - 2022-11-22 07:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 07:44:15 --> 404 Page Not Found: Nintendo-switch-oled-whiteblack-joycons-free-fast-shipping-700292html/index
DEBUG - 2022-11-22 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:44:20 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:14:20 --> Total execution time: 0.1136
DEBUG - 2022-11-22 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:44:21 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:14:22 --> Total execution time: 0.1075
DEBUG - 2022-11-22 07:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:15:27 --> Total execution time: 0.4877
DEBUG - 2022-11-22 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:45:37 --> Total execution time: 0.1806
DEBUG - 2022-11-22 07:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:15:42 --> Total execution time: 0.5506
DEBUG - 2022-11-22 07:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:45:46 --> Total execution time: 0.2510
DEBUG - 2022-11-22 07:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:16:02 --> Total execution time: 0.2842
DEBUG - 2022-11-22 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:27 --> Total execution time: 0.1818
DEBUG - 2022-11-22 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:36 --> Total execution time: 0.1725
DEBUG - 2022-11-22 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:43 --> Total execution time: 0.2155
DEBUG - 2022-11-22 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:16:43 --> Total execution time: 0.1976
DEBUG - 2022-11-22 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:47 --> Total execution time: 0.2018
DEBUG - 2022-11-22 07:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:16:48 --> Total execution time: 0.1781
DEBUG - 2022-11-22 07:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:46:52 --> Total execution time: 0.1960
DEBUG - 2022-11-22 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:16:56 --> Total execution time: 0.2132
DEBUG - 2022-11-22 07:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:03 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:03 --> Total execution time: 0.1180
DEBUG - 2022-11-22 07:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:09 --> Total execution time: 0.1111
DEBUG - 2022-11-22 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:13 --> Total execution time: 0.1811
DEBUG - 2022-11-22 07:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:21 --> Total execution time: 0.2259
DEBUG - 2022-11-22 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:24 --> Total execution time: 0.2002
DEBUG - 2022-11-22 07:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:28 --> Total execution time: 0.2577
DEBUG - 2022-11-22 07:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:29 --> Total execution time: 0.2578
DEBUG - 2022-11-22 07:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:44 --> Total execution time: 0.1815
DEBUG - 2022-11-22 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:17:56 --> Total execution time: 0.1854
DEBUG - 2022-11-22 07:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:13 --> Total execution time: 0.1864
DEBUG - 2022-11-22 07:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:19 --> Total execution time: 0.1908
DEBUG - 2022-11-22 07:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:20 --> Total execution time: 0.1929
DEBUG - 2022-11-22 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:24 --> Total execution time: 0.1892
DEBUG - 2022-11-22 07:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:28 --> Total execution time: 0.2740
DEBUG - 2022-11-22 07:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:37 --> Total execution time: 0.2190
DEBUG - 2022-11-22 07:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:18:39 --> Total execution time: 0.2534
DEBUG - 2022-11-22 07:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 07:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:05 --> Total execution time: 0.2145
DEBUG - 2022-11-22 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:12 --> Total execution time: 0.1890
DEBUG - 2022-11-22 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 07:49:14 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 07:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:21 --> Total execution time: 0.1807
DEBUG - 2022-11-22 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:26 --> Total execution time: 0.2556
DEBUG - 2022-11-22 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:36 --> Total execution time: 0.2892
DEBUG - 2022-11-22 07:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:44 --> Total execution time: 0.2698
DEBUG - 2022-11-22 07:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:50 --> Total execution time: 0.1800
DEBUG - 2022-11-22 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:19:58 --> Total execution time: 0.2151
DEBUG - 2022-11-22 07:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:20:05 --> Total execution time: 0.1949
DEBUG - 2022-11-22 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:20:12 --> Total execution time: 0.2113
DEBUG - 2022-11-22 07:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:20:17 --> Total execution time: 0.1907
DEBUG - 2022-11-22 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:21:32 --> Total execution time: 0.1918
DEBUG - 2022-11-22 07:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:21:42 --> Total execution time: 0.6026
DEBUG - 2022-11-22 07:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:22:18 --> Total execution time: 0.2128
DEBUG - 2022-11-22 07:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:23:47 --> Total execution time: 0.2121
DEBUG - 2022-11-22 07:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:24:01 --> Total execution time: 0.2485
DEBUG - 2022-11-22 07:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:24:33 --> Total execution time: 0.2105
DEBUG - 2022-11-22 07:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:25:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-22 07:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:25:07 --> Total execution time: 0.2231
DEBUG - 2022-11-22 07:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:34 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:26:34 --> Total execution time: 0.1170
DEBUG - 2022-11-22 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:26:35 --> Total execution time: 0.1141
DEBUG - 2022-11-22 07:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:26:47 --> Total execution time: 0.1949
DEBUG - 2022-11-22 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:26:48 --> Total execution time: 0.2018
DEBUG - 2022-11-22 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:26:56 --> Total execution time: 0.2379
DEBUG - 2022-11-22 07:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:27:29 --> Total execution time: 0.1908
DEBUG - 2022-11-22 07:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:27:33 --> Total execution time: 0.1779
DEBUG - 2022-11-22 07:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:27:47 --> Total execution time: 0.2017
DEBUG - 2022-11-22 07:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:27:59 --> Total execution time: 0.1843
DEBUG - 2022-11-22 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:06 --> No URI present. Default controller set.
DEBUG - 2022-11-22 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:28:06 --> Total execution time: 0.2145
DEBUG - 2022-11-22 07:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:28:20 --> Total execution time: 0.1739
DEBUG - 2022-11-22 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:28:26 --> Total execution time: 0.1981
DEBUG - 2022-11-22 07:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 07:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:28:34 --> Total execution time: 0.1811
DEBUG - 2022-11-22 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:28:51 --> Total execution time: 0.2074
DEBUG - 2022-11-22 07:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 07:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 07:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 19:28:54 --> Total execution time: 0.4696
DEBUG - 2022-11-22 15:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:34 --> No URI present. Default controller set.
DEBUG - 2022-11-22 15:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:24:34 --> Total execution time: 0.0558
DEBUG - 2022-11-22 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:54:38 --> Total execution time: 0.0408
DEBUG - 2022-11-22 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:24:56 --> Total execution time: 0.0433
DEBUG - 2022-11-22 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:24:59 --> Total execution time: 0.1180
DEBUG - 2022-11-22 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:24:59 --> Total execution time: 0.1737
DEBUG - 2022-11-22 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:54:59 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:02 --> Total execution time: 0.0464
DEBUG - 2022-11-22 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:02 --> Total execution time: 0.0758
DEBUG - 2022-11-22 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:04 --> Total execution time: 0.3483
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-22 15:55:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:08 --> Total execution time: 0.0931
DEBUG - 2022-11-22 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:14 --> No URI present. Default controller set.
DEBUG - 2022-11-22 15:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:14 --> Total execution time: 0.0446
DEBUG - 2022-11-22 15:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:17 --> Total execution time: 0.0613
DEBUG - 2022-11-22 15:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:21 --> Total execution time: 0.1029
DEBUG - 2022-11-22 15:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:22 --> Total execution time: 0.1808
DEBUG - 2022-11-22 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:22 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:25 --> Total execution time: 0.1568
DEBUG - 2022-11-22 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:25 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:25 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 15:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:37 --> Total execution time: 0.0715
DEBUG - 2022-11-22 15:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-22 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-22 15:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-22 20:25:43 --> Total execution time: 0.0982
DEBUG - 2022-11-22 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-22 15:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-22 15:55:43 --> 404 Page Not Found: Assets/user_thumbnail
