<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-15 00:00:19 --> Total execution time: 0.0918
DEBUG - 2022-08-15 00:00:25 --> Total execution time: 0.0883
DEBUG - 2022-08-15 00:01:04 --> Total execution time: 0.0585
DEBUG - 2022-08-15 00:13:01 --> Total execution time: 0.0994
DEBUG - 2022-08-15 00:14:19 --> Total execution time: 0.0995
DEBUG - 2022-08-15 00:14:37 --> Total execution time: 0.1092
DEBUG - 2022-08-15 00:14:54 --> Total execution time: 0.1109
DEBUG - 2022-08-15 00:15:12 --> Total execution time: 0.2461
DEBUG - 2022-08-15 00:19:03 --> Total execution time: 0.0996
DEBUG - 2022-08-15 00:27:21 --> Total execution time: 0.1232
DEBUG - 2022-08-15 00:28:13 --> Total execution time: 0.0564
DEBUG - 2022-08-15 00:30:02 --> Total execution time: 0.1349
DEBUG - 2022-08-15 00:31:23 --> Total execution time: 0.0622
DEBUG - 2022-08-15 00:35:27 --> Total execution time: 0.1017
DEBUG - 2022-08-15 00:51:35 --> Total execution time: 0.2593
DEBUG - 2022-08-15 00:51:38 --> Total execution time: 0.1289
DEBUG - 2022-08-15 00:51:44 --> Total execution time: 0.0990
DEBUG - 2022-08-15 00:52:26 --> Total execution time: 0.0795
DEBUG - 2022-08-15 00:52:53 --> Total execution time: 0.0757
DEBUG - 2022-08-15 00:53:02 --> Total execution time: 0.0932
DEBUG - 2022-08-15 00:53:04 --> Total execution time: 0.0999
DEBUG - 2022-08-15 00:53:10 --> Total execution time: 0.1009
DEBUG - 2022-08-15 00:53:29 --> Total execution time: 0.1264
DEBUG - 2022-08-15 00:53:31 --> Total execution time: 0.2835
DEBUG - 2022-08-15 00:53:35 --> Total execution time: 0.0865
DEBUG - 2022-08-15 00:53:50 --> Total execution time: 0.0888
DEBUG - 2022-08-15 00:54:14 --> Total execution time: 0.0777
DEBUG - 2022-08-15 00:55:05 --> Total execution time: 0.2223
DEBUG - 2022-08-15 00:55:20 --> Total execution time: 0.0863
DEBUG - 2022-08-15 00:55:25 --> Total execution time: 0.0769
DEBUG - 2022-08-15 00:55:33 --> Total execution time: 0.0798
DEBUG - 2022-08-15 00:55:40 --> Total execution time: 0.1121
DEBUG - 2022-08-15 00:55:47 --> Total execution time: 0.0861
DEBUG - 2022-08-15 00:56:00 --> Total execution time: 0.1195
DEBUG - 2022-08-15 00:56:17 --> Total execution time: 0.0951
DEBUG - 2022-08-15 01:07:25 --> Total execution time: 0.0570
DEBUG - 2022-08-15 01:08:05 --> Total execution time: 0.0518
DEBUG - 2022-08-15 01:12:20 --> Total execution time: 0.0831
DEBUG - 2022-08-15 01:13:29 --> Total execution time: 0.0844
DEBUG - 2022-08-15 01:30:03 --> Total execution time: 0.1629
DEBUG - 2022-08-15 01:32:58 --> Total execution time: 0.1023
DEBUG - 2022-08-15 01:34:16 --> Total execution time: 0.0783
DEBUG - 2022-08-15 01:34:53 --> Total execution time: 0.0757
DEBUG - 2022-08-15 01:35:46 --> Total execution time: 0.0814
DEBUG - 2022-08-15 01:35:54 --> Total execution time: 0.0755
DEBUG - 2022-08-15 01:58:10 --> Total execution time: 0.1299
DEBUG - 2022-08-15 02:30:02 --> Total execution time: 0.1220
DEBUG - 2022-08-15 02:35:05 --> Total execution time: 0.1274
DEBUG - 2022-08-15 02:48:42 --> Total execution time: 0.1345
DEBUG - 2022-08-15 02:48:51 --> Total execution time: 0.0540
DEBUG - 2022-08-15 02:50:27 --> Total execution time: 0.0801
DEBUG - 2022-08-15 02:51:08 --> Total execution time: 0.1085
DEBUG - 2022-08-15 02:51:20 --> Total execution time: 0.0980
DEBUG - 2022-08-15 02:51:37 --> Total execution time: 0.0831
DEBUG - 2022-08-15 02:51:51 --> Total execution time: 0.0832
DEBUG - 2022-08-15 02:52:06 --> Total execution time: 0.0907
DEBUG - 2022-08-15 03:11:00 --> Total execution time: 0.4765
DEBUG - 2022-08-15 03:11:12 --> Total execution time: 0.0860
DEBUG - 2022-08-15 03:11:24 --> Total execution time: 0.0850
DEBUG - 2022-08-15 03:11:30 --> Total execution time: 0.0836
DEBUG - 2022-08-15 03:11:39 --> Total execution time: 0.1254
DEBUG - 2022-08-15 03:12:13 --> Total execution time: 0.0890
DEBUG - 2022-08-15 03:12:19 --> Total execution time: 0.0864
DEBUG - 2022-08-15 03:14:28 --> Total execution time: 0.1337
DEBUG - 2022-08-15 03:14:37 --> Total execution time: 0.0820
DEBUG - 2022-08-15 03:16:52 --> Total execution time: 0.0836
DEBUG - 2022-08-15 03:17:16 --> Total execution time: 0.0811
DEBUG - 2022-08-15 03:17:21 --> Total execution time: 0.1020
DEBUG - 2022-08-15 03:20:10 --> Total execution time: 0.1153
DEBUG - 2022-08-15 03:20:17 --> Total execution time: 0.0697
DEBUG - 2022-08-15 03:20:23 --> Total execution time: 0.0969
DEBUG - 2022-08-15 03:22:41 --> Total execution time: 0.0760
DEBUG - 2022-08-15 03:22:53 --> Total execution time: 0.0772
DEBUG - 2022-08-15 03:23:01 --> Total execution time: 0.0956
DEBUG - 2022-08-15 03:23:09 --> Total execution time: 0.0854
DEBUG - 2022-08-15 03:23:45 --> Total execution time: 0.0868
DEBUG - 2022-08-15 03:23:48 --> Total execution time: 0.0967
DEBUG - 2022-08-15 03:23:53 --> Total execution time: 0.0800
DEBUG - 2022-08-15 03:24:06 --> Total execution time: 0.1278
DEBUG - 2022-08-15 03:24:47 --> Total execution time: 0.0815
DEBUG - 2022-08-15 03:24:50 --> Total execution time: 0.0830
DEBUG - 2022-08-15 03:30:02 --> Total execution time: 0.1145
DEBUG - 2022-08-15 03:31:19 --> Total execution time: 0.0566
DEBUG - 2022-08-15 03:48:46 --> Total execution time: 0.1311
DEBUG - 2022-08-15 04:04:58 --> Total execution time: 0.1002
DEBUG - 2022-08-15 04:30:02 --> Total execution time: 0.1058
DEBUG - 2022-08-15 04:33:24 --> Total execution time: 0.2534
DEBUG - 2022-08-15 04:35:46 --> Total execution time: 0.0640
DEBUG - 2022-08-15 04:37:36 --> Total execution time: 0.0776
DEBUG - 2022-08-15 05:18:46 --> Total execution time: 0.1183
DEBUG - 2022-08-15 05:21:21 --> Total execution time: 0.1046
DEBUG - 2022-08-15 05:21:37 --> Total execution time: 0.0820
DEBUG - 2022-08-15 05:30:02 --> Total execution time: 0.1204
DEBUG - 2022-08-15 05:32:06 --> Total execution time: 0.0592
DEBUG - 2022-08-15 05:33:48 --> Total execution time: 0.2077
DEBUG - 2022-08-15 05:37:32 --> Total execution time: 0.0786
DEBUG - 2022-08-15 05:42:05 --> Total execution time: 0.1170
DEBUG - 2022-08-15 05:43:06 --> Total execution time: 0.0590
DEBUG - 2022-08-15 05:54:32 --> Total execution time: 0.0784
DEBUG - 2022-08-15 05:59:01 --> Total execution time: 0.1354
DEBUG - 2022-08-15 06:00:40 --> Total execution time: 0.0524
DEBUG - 2022-08-15 06:02:19 --> Total execution time: 0.0590
DEBUG - 2022-08-15 06:02:43 --> Total execution time: 0.2498
DEBUG - 2022-08-15 06:02:53 --> Total execution time: 0.1028
DEBUG - 2022-08-15 06:02:57 --> Total execution time: 0.0899
DEBUG - 2022-08-15 06:03:11 --> Total execution time: 0.0818
DEBUG - 2022-08-15 06:11:55 --> Total execution time: 0.2853
DEBUG - 2022-08-15 06:12:35 --> Total execution time: 0.0726
DEBUG - 2022-08-15 06:12:45 --> Total execution time: 0.0960
DEBUG - 2022-08-15 06:12:46 --> Total execution time: 0.0655
DEBUG - 2022-08-15 06:12:54 --> Total execution time: 0.1190
DEBUG - 2022-08-15 06:13:02 --> Total execution time: 0.1056
DEBUG - 2022-08-15 06:15:09 --> Total execution time: 0.1473
DEBUG - 2022-08-15 06:15:23 --> Total execution time: 0.0510
DEBUG - 2022-08-15 06:15:42 --> Total execution time: 0.0548
DEBUG - 2022-08-15 06:15:47 --> Total execution time: 0.0978
DEBUG - 2022-08-15 06:16:17 --> Total execution time: 0.0854
DEBUG - 2022-08-15 06:16:26 --> Total execution time: 0.0768
DEBUG - 2022-08-15 06:16:35 --> Total execution time: 0.1561
DEBUG - 2022-08-15 06:16:48 --> Total execution time: 0.0896
DEBUG - 2022-08-15 06:16:49 --> Total execution time: 0.1092
DEBUG - 2022-08-15 06:17:04 --> Total execution time: 0.0762
DEBUG - 2022-08-15 06:17:14 --> Total execution time: 0.0884
DEBUG - 2022-08-15 06:17:27 --> Total execution time: 0.1120
DEBUG - 2022-08-15 06:17:44 --> Total execution time: 0.2314
DEBUG - 2022-08-15 06:18:08 --> Total execution time: 0.0562
DEBUG - 2022-08-15 06:18:15 --> Total execution time: 0.1016
DEBUG - 2022-08-15 06:18:16 --> Total execution time: 0.0817
DEBUG - 2022-08-15 06:18:32 --> Total execution time: 0.1097
DEBUG - 2022-08-15 06:18:33 --> Total execution time: 0.0487
DEBUG - 2022-08-15 06:18:38 --> Total execution time: 0.0519
DEBUG - 2022-08-15 06:18:41 --> Total execution time: 0.0808
DEBUG - 2022-08-15 06:22:53 --> Total execution time: 0.1358
DEBUG - 2022-08-15 06:28:25 --> Total execution time: 0.1224
DEBUG - 2022-08-15 06:30:02 --> Total execution time: 0.0925
DEBUG - 2022-08-15 06:44:52 --> Total execution time: 0.1211
DEBUG - 2022-08-15 06:45:05 --> Total execution time: 0.0877
DEBUG - 2022-08-15 06:45:10 --> Total execution time: 0.0781
DEBUG - 2022-08-15 06:45:23 --> Total execution time: 0.1015
DEBUG - 2022-08-15 06:45:29 --> Total execution time: 0.0841
DEBUG - 2022-08-15 06:46:03 --> Total execution time: 0.1126
DEBUG - 2022-08-15 06:46:23 --> Total execution time: 0.0831
DEBUG - 2022-08-15 06:46:33 --> Total execution time: 0.0978
DEBUG - 2022-08-15 06:47:55 --> Total execution time: 0.1704
DEBUG - 2022-08-15 06:48:00 --> Total execution time: 0.1119
DEBUG - 2022-08-15 06:48:10 --> Total execution time: 0.0930
DEBUG - 2022-08-15 06:48:15 --> Total execution time: 0.0832
DEBUG - 2022-08-15 06:48:20 --> Total execution time: 0.0908
DEBUG - 2022-08-15 06:48:24 --> Total execution time: 0.1175
DEBUG - 2022-08-15 06:48:30 --> Total execution time: 0.0833
DEBUG - 2022-08-15 07:02:02 --> Total execution time: 0.0771
DEBUG - 2022-08-15 07:04:18 --> Total execution time: 0.2815
DEBUG - 2022-08-15 07:07:52 --> Total execution time: 0.0814
DEBUG - 2022-08-15 07:22:05 --> Total execution time: 0.1239
DEBUG - 2022-08-15 07:22:44 --> Total execution time: 0.0844
DEBUG - 2022-08-15 07:23:11 --> Total execution time: 0.0492
DEBUG - 2022-08-15 07:23:46 --> Total execution time: 0.0916
DEBUG - 2022-08-15 07:24:06 --> Total execution time: 0.0957
DEBUG - 2022-08-15 07:24:14 --> Total execution time: 0.0932
DEBUG - 2022-08-15 07:25:41 --> Total execution time: 0.0906
DEBUG - 2022-08-15 07:26:47 --> Total execution time: 0.0899
DEBUG - 2022-08-15 07:28:00 --> Total execution time: 0.0581
DEBUG - 2022-08-15 07:29:49 --> Total execution time: 0.1039
DEBUG - 2022-08-15 07:30:02 --> Total execution time: 0.0765
DEBUG - 2022-08-15 07:31:51 --> Total execution time: 0.0938
DEBUG - 2022-08-15 07:31:58 --> Total execution time: 0.1097
DEBUG - 2022-08-15 07:32:10 --> Total execution time: 0.1160
DEBUG - 2022-08-15 07:32:25 --> Total execution time: 0.1027
DEBUG - 2022-08-15 07:32:46 --> Total execution time: 0.1022
DEBUG - 2022-08-15 07:33:02 --> Total execution time: 0.0863
DEBUG - 2022-08-15 07:33:13 --> Total execution time: 0.0826
DEBUG - 2022-08-15 07:33:46 --> Total execution time: 0.0501
DEBUG - 2022-08-15 07:39:18 --> Total execution time: 0.2721
DEBUG - 2022-08-15 07:39:32 --> Total execution time: 0.0758
DEBUG - 2022-08-15 07:39:53 --> Total execution time: 0.0560
DEBUG - 2022-08-15 07:41:33 --> Total execution time: 0.0526
DEBUG - 2022-08-15 07:41:34 --> Total execution time: 0.0508
DEBUG - 2022-08-15 07:41:40 --> Total execution time: 0.0530
DEBUG - 2022-08-15 07:41:41 --> Total execution time: 0.2090
DEBUG - 2022-08-15 07:41:48 --> Total execution time: 0.0886
DEBUG - 2022-08-15 07:41:49 --> Total execution time: 0.0885
DEBUG - 2022-08-15 07:41:53 --> Total execution time: 0.0840
DEBUG - 2022-08-15 07:42:03 --> Total execution time: 0.1079
DEBUG - 2022-08-15 07:42:12 --> Total execution time: 0.1232
DEBUG - 2022-08-15 07:42:31 --> Total execution time: 0.1004
DEBUG - 2022-08-15 07:48:28 --> Total execution time: 0.1130
DEBUG - 2022-08-15 07:48:29 --> Total execution time: 0.0466
DEBUG - 2022-08-15 07:51:12 --> Total execution time: 0.0783
DEBUG - 2022-08-15 07:52:33 --> Total execution time: 0.0903
DEBUG - 2022-08-15 07:53:13 --> Total execution time: 0.0803
DEBUG - 2022-08-15 07:53:48 --> Total execution time: 0.2027
DEBUG - 2022-08-15 07:54:08 --> Total execution time: 0.0609
DEBUG - 2022-08-15 07:54:10 --> Total execution time: 0.0779
DEBUG - 2022-08-15 07:59:05 --> Total execution time: 0.1181
DEBUG - 2022-08-15 08:02:59 --> Total execution time: 0.0803
DEBUG - 2022-08-15 08:04:04 --> Total execution time: 0.0513
DEBUG - 2022-08-15 08:04:49 --> Total execution time: 0.0801
DEBUG - 2022-08-15 08:05:19 --> Total execution time: 0.2161
DEBUG - 2022-08-15 08:05:32 --> Total execution time: 0.0880
DEBUG - 2022-08-15 08:05:48 --> Total execution time: 0.0937
DEBUG - 2022-08-15 08:21:58 --> Total execution time: 0.2081
DEBUG - 2022-08-15 08:22:39 --> Total execution time: 0.0560
DEBUG - 2022-08-15 08:24:35 --> Total execution time: 0.0591
DEBUG - 2022-08-15 08:30:02 --> Total execution time: 0.0602
DEBUG - 2022-08-15 08:31:42 --> Total execution time: 0.0621
DEBUG - 2022-08-15 08:32:18 --> Total execution time: 0.0516
DEBUG - 2022-08-15 08:33:54 --> Total execution time: 0.0564
DEBUG - 2022-08-15 08:34:51 --> Total execution time: 0.0542
DEBUG - 2022-08-15 08:34:53 --> Total execution time: 0.0561
DEBUG - 2022-08-15 08:35:06 --> Total execution time: 0.0514
DEBUG - 2022-08-15 08:35:07 --> Total execution time: 0.0514
DEBUG - 2022-08-15 08:35:15 --> Total execution time: 0.1015
DEBUG - 2022-08-15 08:35:25 --> Total execution time: 0.0816
DEBUG - 2022-08-15 08:35:32 --> Total execution time: 0.0520
DEBUG - 2022-08-15 08:35:33 --> Total execution time: 0.0931
DEBUG - 2022-08-15 08:35:38 --> Total execution time: 0.0890
DEBUG - 2022-08-15 08:35:50 --> Total execution time: 0.1060
DEBUG - 2022-08-15 08:36:00 --> Total execution time: 0.0470
DEBUG - 2022-08-15 08:36:13 --> Total execution time: 0.0842
DEBUG - 2022-08-15 08:36:51 --> Total execution time: 0.1005
DEBUG - 2022-08-15 08:37:01 --> Total execution time: 0.0553
DEBUG - 2022-08-15 08:37:02 --> Total execution time: 0.0850
DEBUG - 2022-08-15 08:37:11 --> Total execution time: 0.1024
DEBUG - 2022-08-15 08:37:19 --> Total execution time: 0.0762
DEBUG - 2022-08-15 08:37:23 --> Total execution time: 0.0813
DEBUG - 2022-08-15 08:37:42 --> Total execution time: 0.0830
DEBUG - 2022-08-15 08:37:46 --> Total execution time: 0.0833
DEBUG - 2022-08-15 08:37:52 --> Total execution time: 0.1146
DEBUG - 2022-08-15 08:38:23 --> Total execution time: 0.0594
DEBUG - 2022-08-15 08:47:06 --> Total execution time: 0.1018
DEBUG - 2022-08-15 08:49:48 --> Total execution time: 2.6929
DEBUG - 2022-08-15 08:50:30 --> Total execution time: 0.0825
DEBUG - 2022-08-15 08:50:32 --> Total execution time: 0.2255
DEBUG - 2022-08-15 08:51:11 --> Total execution time: 0.1054
DEBUG - 2022-08-15 08:51:16 --> Total execution time: 0.1049
DEBUG - 2022-08-15 08:51:27 --> Total execution time: 0.0806
DEBUG - 2022-08-15 08:52:10 --> Total execution time: 0.2126
DEBUG - 2022-08-15 08:54:41 --> Total execution time: 0.2817
DEBUG - 2022-08-15 08:54:43 --> Total execution time: 0.0805
DEBUG - 2022-08-15 08:54:45 --> Total execution time: 0.0843
DEBUG - 2022-08-15 08:55:00 --> Total execution time: 0.0783
DEBUG - 2022-08-15 08:55:01 --> Total execution time: 0.1489
DEBUG - 2022-08-15 08:55:27 --> Total execution time: 0.0571
DEBUG - 2022-08-15 08:55:36 --> Total execution time: 0.0491
DEBUG - 2022-08-15 08:55:41 --> Total execution time: 0.0812
DEBUG - 2022-08-15 08:56:05 --> Total execution time: 0.0826
DEBUG - 2022-08-15 08:56:13 --> Total execution time: 0.0772
DEBUG - 2022-08-15 08:56:24 --> Total execution time: 0.0843
DEBUG - 2022-08-15 08:56:24 --> Total execution time: 0.0797
DEBUG - 2022-08-15 08:56:25 --> Total execution time: 0.0849
DEBUG - 2022-08-15 08:57:04 --> Total execution time: 0.1043
DEBUG - 2022-08-15 08:57:19 --> Total execution time: 0.0836
DEBUG - 2022-08-15 08:57:22 --> Total execution time: 0.2106
DEBUG - 2022-08-15 09:00:02 --> Total execution time: 0.1331
DEBUG - 2022-08-15 09:00:06 --> Total execution time: 0.2235
DEBUG - 2022-08-15 09:00:16 --> Total execution time: 0.0782
DEBUG - 2022-08-15 09:00:20 --> Total execution time: 0.0883
DEBUG - 2022-08-15 09:00:58 --> Total execution time: 0.2144
DEBUG - 2022-08-15 09:01:38 --> Total execution time: 0.0781
DEBUG - 2022-08-15 09:01:57 --> Total execution time: 0.0790
DEBUG - 2022-08-15 09:02:10 --> Total execution time: 0.0950
DEBUG - 2022-08-15 09:02:11 --> Total execution time: 0.0756
DEBUG - 2022-08-15 09:03:44 --> Total execution time: 0.0740
DEBUG - 2022-08-15 09:03:46 --> Total execution time: 0.0777
DEBUG - 2022-08-15 09:04:12 --> Total execution time: 0.0980
DEBUG - 2022-08-15 09:04:22 --> Total execution time: 0.0918
DEBUG - 2022-08-15 09:09:18 --> Total execution time: 0.1335
DEBUG - 2022-08-15 09:09:19 --> Total execution time: 0.2181
DEBUG - 2022-08-15 09:09:35 --> Total execution time: 0.0870
DEBUG - 2022-08-15 09:09:54 --> Total execution time: 0.0865
DEBUG - 2022-08-15 09:10:01 --> Total execution time: 0.0858
DEBUG - 2022-08-15 09:10:14 --> Total execution time: 0.0872
DEBUG - 2022-08-15 09:10:20 --> Total execution time: 0.0932
DEBUG - 2022-08-15 09:10:25 --> Total execution time: 0.0836
DEBUG - 2022-08-15 09:10:29 --> Total execution time: 0.0890
DEBUG - 2022-08-15 09:10:42 --> Total execution time: 0.1090
DEBUG - 2022-08-15 09:10:48 --> Total execution time: 0.1069
DEBUG - 2022-08-15 09:10:52 --> Total execution time: 0.1211
DEBUG - 2022-08-15 09:10:56 --> Total execution time: 0.0785
DEBUG - 2022-08-15 09:11:07 --> Total execution time: 0.0904
DEBUG - 2022-08-15 09:11:14 --> Total execution time: 0.0552
DEBUG - 2022-08-15 09:12:04 --> Total execution time: 0.0506
DEBUG - 2022-08-15 09:12:06 --> Total execution time: 0.0821
DEBUG - 2022-08-15 09:15:32 --> Total execution time: 0.2640
DEBUG - 2022-08-15 09:15:43 --> Total execution time: 0.1170
DEBUG - 2022-08-15 09:15:48 --> Total execution time: 0.0912
DEBUG - 2022-08-15 09:15:55 --> Total execution time: 0.0906
DEBUG - 2022-08-15 09:16:00 --> Total execution time: 0.0906
DEBUG - 2022-08-15 09:16:07 --> Total execution time: 0.0782
DEBUG - 2022-08-15 09:17:34 --> Total execution time: 0.2059
DEBUG - 2022-08-15 09:18:21 --> Total execution time: 0.0558
DEBUG - 2022-08-15 09:18:24 --> Total execution time: 0.0843
DEBUG - 2022-08-15 09:18:31 --> Total execution time: 0.0832
DEBUG - 2022-08-15 09:18:38 --> Total execution time: 0.1102
DEBUG - 2022-08-15 09:19:03 --> Total execution time: 0.0546
DEBUG - 2022-08-15 09:19:29 --> Total execution time: 0.0528
DEBUG - 2022-08-15 09:20:49 --> Total execution time: 0.0849
DEBUG - 2022-08-15 09:26:17 --> Total execution time: 0.1548
DEBUG - 2022-08-15 09:30:03 --> Total execution time: 0.1129
DEBUG - 2022-08-15 09:37:32 --> Total execution time: 0.1280
DEBUG - 2022-08-15 09:47:05 --> Total execution time: 0.1325
DEBUG - 2022-08-15 09:47:07 --> Total execution time: 0.0796
DEBUG - 2022-08-15 09:47:26 --> Total execution time: 0.0887
DEBUG - 2022-08-15 09:47:49 --> Total execution time: 0.0804
DEBUG - 2022-08-15 09:48:06 --> Total execution time: 0.1198
DEBUG - 2022-08-15 09:48:24 --> Total execution time: 0.0761
DEBUG - 2022-08-15 09:48:26 --> Total execution time: 0.1006
DEBUG - 2022-08-15 09:48:33 --> Total execution time: 0.0823
DEBUG - 2022-08-15 09:48:36 --> Total execution time: 0.1148
DEBUG - 2022-08-15 09:48:39 --> Total execution time: 0.0510
DEBUG - 2022-08-15 09:48:53 --> Total execution time: 0.0544
DEBUG - 2022-08-15 09:48:53 --> Total execution time: 0.0924
DEBUG - 2022-08-15 09:49:01 --> Total execution time: 0.1042
DEBUG - 2022-08-15 09:49:09 --> Total execution time: 0.1414
DEBUG - 2022-08-15 09:51:50 --> Total execution time: 0.1040
DEBUG - 2022-08-15 09:54:59 --> Total execution time: 0.2692
DEBUG - 2022-08-15 09:55:05 --> Total execution time: 0.0791
DEBUG - 2022-08-15 09:55:21 --> Total execution time: 0.1063
DEBUG - 2022-08-15 09:55:51 --> Total execution time: 0.0924
DEBUG - 2022-08-15 09:56:00 --> Total execution time: 0.1024
DEBUG - 2022-08-15 09:56:24 --> Total execution time: 0.0594
DEBUG - 2022-08-15 09:58:27 --> Total execution time: 0.0604
DEBUG - 2022-08-15 09:59:57 --> Total execution time: 0.0786
DEBUG - 2022-08-15 10:00:09 --> Total execution time: 0.2179
DEBUG - 2022-08-15 10:00:22 --> Total execution time: 0.0892
DEBUG - 2022-08-15 10:00:48 --> Total execution time: 0.0868
DEBUG - 2022-08-15 10:00:54 --> Total execution time: 0.0902
DEBUG - 2022-08-15 10:01:20 --> Total execution time: 0.0817
DEBUG - 2022-08-15 10:09:28 --> Total execution time: 0.1149
DEBUG - 2022-08-15 10:11:49 --> Total execution time: 0.0892
DEBUG - 2022-08-15 10:12:42 --> Total execution time: 0.0768
DEBUG - 2022-08-15 10:14:17 --> Total execution time: 0.0825
DEBUG - 2022-08-15 10:18:54 --> Total execution time: 0.1095
DEBUG - 2022-08-15 10:23:41 --> Total execution time: 0.1583
DEBUG - 2022-08-15 10:23:44 --> Total execution time: 0.0801
DEBUG - 2022-08-15 10:23:52 --> Total execution time: 0.1195
DEBUG - 2022-08-15 10:24:01 --> Total execution time: 0.1173
DEBUG - 2022-08-15 10:24:42 --> Total execution time: 0.0984
DEBUG - 2022-08-15 10:24:56 --> Total execution time: 0.0843
DEBUG - 2022-08-15 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:30:02 --> Total execution time: 0.1759
DEBUG - 2022-08-15 00:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:30:53 --> Total execution time: 0.0783
DEBUG - 2022-08-15 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:04:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:34:19 --> Total execution time: 0.1087
DEBUG - 2022-08-15 00:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:04:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:34:54 --> Total execution time: 0.0520
DEBUG - 2022-08-15 00:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:08:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:38:20 --> Total execution time: 0.1047
DEBUG - 2022-08-15 00:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:09:50 --> Total execution time: 0.0759
DEBUG - 2022-08-15 00:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:12:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:42:51 --> Total execution time: 0.1110
DEBUG - 2022-08-15 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:14:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:44:20 --> Total execution time: 0.0535
DEBUG - 2022-08-15 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:44:26 --> Total execution time: 0.0811
DEBUG - 2022-08-15 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:44:29 --> Total execution time: 0.0839
DEBUG - 2022-08-15 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:44:49 --> Total execution time: 0.1065
DEBUG - 2022-08-15 00:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:44:55 --> Total execution time: 0.0977
DEBUG - 2022-08-15 00:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:02 --> Total execution time: 0.1341
DEBUG - 2022-08-15 00:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:13 --> Total execution time: 0.0589
DEBUG - 2022-08-15 00:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:14 --> Total execution time: 0.0811
DEBUG - 2022-08-15 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:33 --> Total execution time: 0.0634
DEBUG - 2022-08-15 00:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:33 --> Total execution time: 0.0713
DEBUG - 2022-08-15 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:33 --> Total execution time: 0.0618
DEBUG - 2022-08-15 00:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:34 --> Total execution time: 0.0605
DEBUG - 2022-08-15 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:35 --> Total execution time: 0.0668
DEBUG - 2022-08-15 00:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:43 --> Total execution time: 0.0959
DEBUG - 2022-08-15 00:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:49 --> Total execution time: 0.0847
DEBUG - 2022-08-15 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:53 --> Total execution time: 0.1246
DEBUG - 2022-08-15 00:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:54 --> Total execution time: 0.0927
DEBUG - 2022-08-15 00:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:45:58 --> Total execution time: 0.1080
DEBUG - 2022-08-15 00:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:46:13 --> Total execution time: 0.0821
DEBUG - 2022-08-15 00:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:46:21 --> Total execution time: 0.1425
DEBUG - 2022-08-15 00:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:46:26 --> Total execution time: 0.1106
DEBUG - 2022-08-15 00:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:46:28 --> Total execution time: 0.0748
DEBUG - 2022-08-15 00:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 00:16:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 00:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:48:56 --> Total execution time: 0.1093
DEBUG - 2022-08-15 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:49:48 --> Total execution time: 0.1078
DEBUG - 2022-08-15 00:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:49:56 --> Total execution time: 0.1052
DEBUG - 2022-08-15 00:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:50:03 --> Total execution time: 0.0874
DEBUG - 2022-08-15 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:50:18 --> Total execution time: 0.1148
DEBUG - 2022-08-15 00:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:50:33 --> Total execution time: 0.0863
DEBUG - 2022-08-15 00:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:50:41 --> Total execution time: 0.2142
DEBUG - 2022-08-15 00:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:50:45 --> Total execution time: 0.0819
DEBUG - 2022-08-15 00:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:50:50 --> Total execution time: 0.1017
DEBUG - 2022-08-15 00:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:21:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:51:17 --> Total execution time: 0.2058
DEBUG - 2022-08-15 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:22:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:52:03 --> Total execution time: 0.0901
DEBUG - 2022-08-15 00:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:52:23 --> Total execution time: 2.6088
DEBUG - 2022-08-15 00:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 00:22:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 00:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:58:59 --> Total execution time: 0.2765
DEBUG - 2022-08-15 00:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:29:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 00:29:44 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-08-15 00:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:31:42 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:01:42 --> Total execution time: 0.0601
DEBUG - 2022-08-15 00:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:31:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:01:59 --> Total execution time: 0.0507
DEBUG - 2022-08-15 00:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:37:58 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:07:59 --> Total execution time: 0.1329
DEBUG - 2022-08-15 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:38:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:08:00 --> Total execution time: 0.0510
DEBUG - 2022-08-15 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:08:42 --> Total execution time: 0.0986
DEBUG - 2022-08-15 00:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:09:44 --> Total execution time: 0.2108
DEBUG - 2022-08-15 00:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:43:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:13:34 --> Total execution time: 0.1436
DEBUG - 2022-08-15 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:43:37 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:13:37 --> Total execution time: 0.0544
DEBUG - 2022-08-15 00:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:45:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:15:48 --> Total execution time: 0.2554
DEBUG - 2022-08-15 00:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:50:44 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:20:44 --> Total execution time: 0.2747
DEBUG - 2022-08-15 00:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:53:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 00:53:15 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 00:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:53:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 00:53:15 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 00:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 00:53:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 00:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:24:03 --> Total execution time: 0.1014
DEBUG - 2022-08-15 00:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:55:09 --> No URI present. Default controller set.
DEBUG - 2022-08-15 00:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:25:09 --> Total execution time: 0.0914
DEBUG - 2022-08-15 00:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 00:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 00:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 00:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:28:50 --> Total execution time: 0.0816
DEBUG - 2022-08-15 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:30:02 --> Total execution time: 0.0945
DEBUG - 2022-08-15 01:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:32:17 --> Total execution time: 0.0507
DEBUG - 2022-08-15 01:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:02:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:32:21 --> Total execution time: 0.0895
DEBUG - 2022-08-15 01:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:02:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:32:27 --> Total execution time: 0.0964
DEBUG - 2022-08-15 01:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:08:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:38:03 --> Total execution time: 0.1192
DEBUG - 2022-08-15 01:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:10:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:40:29 --> Total execution time: 0.1041
DEBUG - 2022-08-15 01:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:40:38 --> Total execution time: 0.0501
DEBUG - 2022-08-15 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:10:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:40:39 --> Total execution time: 0.0789
DEBUG - 2022-08-15 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:40:53 --> Total execution time: 0.1083
DEBUG - 2022-08-15 01:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:05 --> Total execution time: 0.1209
DEBUG - 2022-08-15 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:12 --> Total execution time: 0.0830
DEBUG - 2022-08-15 01:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:16 --> Total execution time: 0.0733
DEBUG - 2022-08-15 01:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:17 --> Total execution time: 0.0929
DEBUG - 2022-08-15 01:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:20 --> Total execution time: 0.0879
DEBUG - 2022-08-15 01:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:27 --> Total execution time: 0.0999
DEBUG - 2022-08-15 01:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:34 --> Total execution time: 0.1021
DEBUG - 2022-08-15 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:37 --> Total execution time: 0.0767
DEBUG - 2022-08-15 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:44 --> Total execution time: 0.1473
DEBUG - 2022-08-15 01:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:41:45 --> Total execution time: 0.1108
DEBUG - 2022-08-15 01:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:12:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:42:03 --> Total execution time: 0.0916
DEBUG - 2022-08-15 01:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:42:36 --> Total execution time: 0.0535
DEBUG - 2022-08-15 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:12:43 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:42:43 --> Total execution time: 0.0530
DEBUG - 2022-08-15 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:12:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:42:53 --> Total execution time: 0.0527
DEBUG - 2022-08-15 01:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:12:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:42:58 --> Total execution time: 0.0789
DEBUG - 2022-08-15 01:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:14:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:44:13 --> Total execution time: 0.0847
DEBUG - 2022-08-15 01:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:44:33 --> Total execution time: 0.1083
DEBUG - 2022-08-15 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:44:53 --> Total execution time: 0.0819
DEBUG - 2022-08-15 01:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:44:58 --> Total execution time: 0.1063
DEBUG - 2022-08-15 01:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:45:39 --> Total execution time: 0.0802
DEBUG - 2022-08-15 01:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:17:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:47:19 --> Total execution time: 0.1461
DEBUG - 2022-08-15 01:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:47:58 --> Total execution time: 0.0914
DEBUG - 2022-08-15 01:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:48:16 --> Total execution time: 0.0813
DEBUG - 2022-08-15 01:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:48:25 --> Total execution time: 0.1088
DEBUG - 2022-08-15 01:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:48:35 --> Total execution time: 0.1084
DEBUG - 2022-08-15 01:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:48:39 --> Total execution time: 0.0958
DEBUG - 2022-08-15 01:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:48:50 --> Total execution time: 0.0816
DEBUG - 2022-08-15 01:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:20:46 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:50:46 --> Total execution time: 0.0819
DEBUG - 2022-08-15 01:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:21:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:51:20 --> Total execution time: 0.0531
DEBUG - 2022-08-15 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:52:17 --> Total execution time: 0.0734
DEBUG - 2022-08-15 01:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 01:22:36 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 01:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:24:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:54:18 --> Total execution time: 0.0538
DEBUG - 2022-08-15 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:24:37 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:54:37 --> Total execution time: 0.0540
DEBUG - 2022-08-15 01:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:54:45 --> Total execution time: 0.0721
DEBUG - 2022-08-15 01:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:55:02 --> Total execution time: 0.0527
DEBUG - 2022-08-15 01:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:30 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:55:30 --> Total execution time: 0.0533
DEBUG - 2022-08-15 01:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:55:40 --> Total execution time: 0.0767
DEBUG - 2022-08-15 01:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:55:49 --> Total execution time: 0.0813
DEBUG - 2022-08-15 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:55:52 --> Total execution time: 0.0822
DEBUG - 2022-08-15 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:55:56 --> Total execution time: 0.0789
DEBUG - 2022-08-15 01:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:56:06 --> Total execution time: 0.0884
DEBUG - 2022-08-15 01:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:26:44 --> Total execution time: 0.0835
DEBUG - 2022-08-15 01:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:56:46 --> Total execution time: 0.0758
DEBUG - 2022-08-15 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:26:47 --> Total execution time: 0.0836
DEBUG - 2022-08-15 01:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:26:48 --> Total execution time: 0.0878
DEBUG - 2022-08-15 01:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:56:48 --> Total execution time: 0.0742
DEBUG - 2022-08-15 01:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:56:52 --> Total execution time: 0.0767
DEBUG - 2022-08-15 01:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:57:00 --> Total execution time: 0.0756
DEBUG - 2022-08-15 01:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:27:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:57:01 --> Total execution time: 0.0858
DEBUG - 2022-08-15 01:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:57:10 --> Total execution time: 0.1097
DEBUG - 2022-08-15 01:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:57:19 --> Total execution time: 0.0797
DEBUG - 2022-08-15 01:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:57:31 --> Total execution time: 0.0827
DEBUG - 2022-08-15 01:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:01 --> Total execution time: 0.0741
DEBUG - 2022-08-15 01:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:10 --> Total execution time: 0.0804
DEBUG - 2022-08-15 01:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:16 --> Total execution time: 0.0756
DEBUG - 2022-08-15 01:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:21 --> Total execution time: 0.0856
DEBUG - 2022-08-15 01:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:31 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:31 --> Total execution time: 0.0793
DEBUG - 2022-08-15 01:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:34 --> Total execution time: 0.1025
DEBUG - 2022-08-15 01:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:58:59 --> Total execution time: 0.0852
DEBUG - 2022-08-15 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 01:29:05 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 01:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:59:59 --> Total execution time: 0.2232
DEBUG - 2022-08-15 01:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:04 --> Total execution time: 0.0892
DEBUG - 2022-08-15 01:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:15 --> Total execution time: 0.0806
DEBUG - 2022-08-15 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:28 --> Total execution time: 0.1332
DEBUG - 2022-08-15 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:33 --> Total execution time: 0.0831
DEBUG - 2022-08-15 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:33 --> Total execution time: 0.0759
DEBUG - 2022-08-15 01:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:42 --> Total execution time: 0.0869
DEBUG - 2022-08-15 01:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:30:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:00:48 --> Total execution time: 0.1095
DEBUG - 2022-08-15 01:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:00 --> Total execution time: 0.0766
DEBUG - 2022-08-15 01:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:06 --> Total execution time: 0.0756
DEBUG - 2022-08-15 01:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:20 --> Total execution time: 0.0768
DEBUG - 2022-08-15 01:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:27 --> Total execution time: 0.0773
DEBUG - 2022-08-15 01:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:28 --> Total execution time: 0.0795
DEBUG - 2022-08-15 01:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:28 --> Total execution time: 0.0711
DEBUG - 2022-08-15 01:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:01:28 --> Total execution time: 0.0744
DEBUG - 2022-08-15 01:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:02:19 --> Total execution time: 0.2039
DEBUG - 2022-08-15 01:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:02:24 --> Total execution time: 0.0725
DEBUG - 2022-08-15 01:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:02:34 --> Total execution time: 0.0709
DEBUG - 2022-08-15 01:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:02:38 --> Total execution time: 0.0769
DEBUG - 2022-08-15 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:02:52 --> Total execution time: 0.0806
DEBUG - 2022-08-15 01:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:03:06 --> Total execution time: 0.0740
DEBUG - 2022-08-15 01:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 01:34:38 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 01:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:01 --> Total execution time: 0.2469
DEBUG - 2022-08-15 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:02 --> Total execution time: 0.0785
DEBUG - 2022-08-15 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:02 --> Total execution time: 0.0836
DEBUG - 2022-08-15 01:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:35:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:03 --> Total execution time: 0.0875
DEBUG - 2022-08-15 01:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:02 --> Total execution time: 0.0775
DEBUG - 2022-08-15 01:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:06 --> Total execution time: 0.0836
DEBUG - 2022-08-15 01:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:21 --> Total execution time: 0.0853
DEBUG - 2022-08-15 01:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:25 --> Total execution time: 0.0805
DEBUG - 2022-08-15 01:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:32 --> Total execution time: 0.0728
DEBUG - 2022-08-15 01:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:41 --> Total execution time: 0.0850
DEBUG - 2022-08-15 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:46 --> Total execution time: 0.0792
DEBUG - 2022-08-15 01:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:48 --> Total execution time: 0.0808
DEBUG - 2022-08-15 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:37:49 --> Total execution time: 0.0717
DEBUG - 2022-08-15 01:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:39:20 --> Total execution time: 0.0835
DEBUG - 2022-08-15 01:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:39:22 --> Total execution time: 0.0810
DEBUG - 2022-08-15 01:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:39:23 --> Total execution time: 0.0772
DEBUG - 2022-08-15 01:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:09:25 --> Total execution time: 0.2024
DEBUG - 2022-08-15 01:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:09:50 --> Total execution time: 0.0806
DEBUG - 2022-08-15 01:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:09:57 --> Total execution time: 0.0852
DEBUG - 2022-08-15 01:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:01 --> Total execution time: 0.1518
DEBUG - 2022-08-15 01:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:40:02 --> Total execution time: 0.2538
DEBUG - 2022-08-15 01:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:40:04 --> Total execution time: 0.1008
DEBUG - 2022-08-15 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:40:05 --> Total execution time: 0.1275
DEBUG - 2022-08-15 01:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:19 --> Total execution time: 0.1732
DEBUG - 2022-08-15 01:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:32 --> Total execution time: 0.1095
DEBUG - 2022-08-15 01:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:41 --> Total execution time: 0.1194
DEBUG - 2022-08-15 01:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:42 --> Total execution time: 0.0584
DEBUG - 2022-08-15 01:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:57 --> Total execution time: 0.0709
DEBUG - 2022-08-15 01:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:41:17 --> Total execution time: 0.0849
DEBUG - 2022-08-15 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:41:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:11:18 --> Total execution time: 0.0591
DEBUG - 2022-08-15 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:41:51 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:11:51 --> Total execution time: 0.0511
DEBUG - 2022-08-15 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:41:58 --> No URI present. Default controller set.
DEBUG - 2022-08-15 01:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:11:58 --> Total execution time: 0.0740
DEBUG - 2022-08-15 01:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:14:14 --> Total execution time: 0.0752
DEBUG - 2022-08-15 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:17:54 --> Total execution time: 0.2268
DEBUG - 2022-08-15 01:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:18:51 --> Total execution time: 0.2209
DEBUG - 2022-08-15 01:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 01:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 01:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:19:00 --> Total execution time: 0.0722
DEBUG - 2022-08-15 01:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 01:50:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 01:50:59 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:30:02 --> Total execution time: 0.2040
DEBUG - 2022-08-15 02:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:09:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:39:13 --> Total execution time: 0.1484
DEBUG - 2022-08-15 02:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:07 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:07 --> Total execution time: 0.1134
DEBUG - 2022-08-15 02:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:07 --> Total execution time: 0.0887
DEBUG - 2022-08-15 02:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:18 --> Total execution time: 0.0899
DEBUG - 2022-08-15 02:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:20 --> Total execution time: 0.0981
DEBUG - 2022-08-15 02:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:25 --> Total execution time: 0.0948
DEBUG - 2022-08-15 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 02:17:32 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-08-15 02:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:33 --> Total execution time: 0.0831
DEBUG - 2022-08-15 02:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:47:34 --> Total execution time: 0.0796
DEBUG - 2022-08-15 02:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:52:55 --> Total execution time: 0.1151
DEBUG - 2022-08-15 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:23:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:53:15 --> Total execution time: 0.0711
DEBUG - 2022-08-15 02:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:58:37 --> Total execution time: 0.2667
DEBUG - 2022-08-15 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:30:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:00:02 --> Total execution time: 0.1128
DEBUG - 2022-08-15 02:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:30:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:00:05 --> Total execution time: 0.0578
DEBUG - 2022-08-15 02:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:30:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:00:12 --> Total execution time: 0.0517
DEBUG - 2022-08-15 02:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:00:42 --> Total execution time: 0.0492
DEBUG - 2022-08-15 02:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:01:06 --> Total execution time: 0.0881
DEBUG - 2022-08-15 02:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:01:18 --> Total execution time: 0.1449
DEBUG - 2022-08-15 02:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:01:36 --> Total execution time: 0.1070
DEBUG - 2022-08-15 02:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:01:37 --> Total execution time: 0.1020
DEBUG - 2022-08-15 02:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:01:44 --> Total execution time: 0.0902
DEBUG - 2022-08-15 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:31:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:01:59 --> Total execution time: 0.0622
DEBUG - 2022-08-15 02:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:02:08 --> Total execution time: 0.0806
DEBUG - 2022-08-15 02:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:02:38 --> Total execution time: 0.0931
DEBUG - 2022-08-15 02:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:02:40 --> Total execution time: 0.1021
DEBUG - 2022-08-15 02:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:02:55 --> Total execution time: 0.1129
DEBUG - 2022-08-15 02:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:02:56 --> Total execution time: 0.1047
DEBUG - 2022-08-15 02:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:05 --> Total execution time: 0.0529
DEBUG - 2022-08-15 02:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:08 --> Total execution time: 0.0795
DEBUG - 2022-08-15 02:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:14 --> Total execution time: 0.0520
DEBUG - 2022-08-15 02:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:16 --> Total execution time: 0.0783
DEBUG - 2022-08-15 02:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:22 --> Total execution time: 0.0856
DEBUG - 2022-08-15 02:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:37 --> Total execution time: 0.0889
DEBUG - 2022-08-15 02:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:39 --> Total execution time: 0.0698
DEBUG - 2022-08-15 02:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:42 --> Total execution time: 0.0522
DEBUG - 2022-08-15 02:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:48 --> Total execution time: 0.0817
DEBUG - 2022-08-15 02:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:03:57 --> Total execution time: 0.0887
DEBUG - 2022-08-15 02:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:04:06 --> Total execution time: 0.1014
DEBUG - 2022-08-15 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:04:31 --> Total execution time: 0.0830
DEBUG - 2022-08-15 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:04:34 --> Total execution time: 0.0854
DEBUG - 2022-08-15 02:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:04:43 --> Total execution time: 0.0883
DEBUG - 2022-08-15 02:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:04:53 --> Total execution time: 0.0873
DEBUG - 2022-08-15 02:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:04:53 --> Total execution time: 0.0761
DEBUG - 2022-08-15 02:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:05:08 --> Total execution time: 0.0901
DEBUG - 2022-08-15 02:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:05:14 --> Total execution time: 0.0791
DEBUG - 2022-08-15 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:05:18 --> Total execution time: 0.0778
DEBUG - 2022-08-15 02:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:35:31 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:05:31 --> Total execution time: 0.0805
DEBUG - 2022-08-15 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:05:39 --> Total execution time: 0.0829
DEBUG - 2022-08-15 02:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:05:55 --> Total execution time: 0.0846
DEBUG - 2022-08-15 02:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:06:13 --> Total execution time: 0.0794
DEBUG - 2022-08-15 02:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:06:37 --> Total execution time: 0.0839
DEBUG - 2022-08-15 02:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:06:46 --> Total execution time: 0.0989
DEBUG - 2022-08-15 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:36:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:06:47 --> Total execution time: 0.0494
DEBUG - 2022-08-15 02:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:36:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:06:48 --> Total execution time: 0.0491
DEBUG - 2022-08-15 02:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:06:52 --> Total execution time: 0.0714
DEBUG - 2022-08-15 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:07:28 --> Total execution time: 0.0846
DEBUG - 2022-08-15 02:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:07:40 --> Total execution time: 0.1181
DEBUG - 2022-08-15 02:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:37:55 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:07:55 --> Total execution time: 0.0522
DEBUG - 2022-08-15 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:38:05 --> Total execution time: 0.0759
DEBUG - 2022-08-15 02:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:38:07 --> Total execution time: 0.0783
DEBUG - 2022-08-15 02:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:38:07 --> Total execution time: 0.1939
DEBUG - 2022-08-15 02:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:39:02 --> Total execution time: 0.0784
DEBUG - 2022-08-15 02:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:39:04 --> Total execution time: 0.0850
DEBUG - 2022-08-15 02:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:39:05 --> Total execution time: 0.0804
DEBUG - 2022-08-15 02:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:42:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:12:24 --> Total execution time: 0.1344
DEBUG - 2022-08-15 02:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:13:55 --> Total execution time: 0.0522
DEBUG - 2022-08-15 02:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:14:09 --> Total execution time: 0.1020
DEBUG - 2022-08-15 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:14:41 --> Total execution time: 0.1114
DEBUG - 2022-08-15 02:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:44:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:14:57 --> Total execution time: 0.0534
DEBUG - 2022-08-15 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:45:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:01 --> Total execution time: 0.0772
DEBUG - 2022-08-15 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:01 --> Total execution time: 0.1294
DEBUG - 2022-08-15 02:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:45:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:12 --> Total execution time: 0.0680
DEBUG - 2022-08-15 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:54 --> Total execution time: 0.1106
DEBUG - 2022-08-15 02:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:16:00 --> Total execution time: 2.5037
DEBUG - 2022-08-15 02:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:46:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:16:03 --> Total execution time: 0.0475
DEBUG - 2022-08-15 02:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:46:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 02:46:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 02:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:16:17 --> Total execution time: 0.0856
DEBUG - 2022-08-15 02:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:16:52 --> Total execution time: 0.0830
DEBUG - 2022-08-15 02:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:16:54 --> Total execution time: 0.2291
DEBUG - 2022-08-15 02:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:47:17 --> Total execution time: 0.0722
DEBUG - 2022-08-15 02:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:47:19 --> Total execution time: 0.0860
DEBUG - 2022-08-15 02:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:47:20 --> Total execution time: 0.0723
DEBUG - 2022-08-15 02:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:01 --> Total execution time: 0.0826
DEBUG - 2022-08-15 02:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:04 --> Total execution time: 0.1037
DEBUG - 2022-08-15 02:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:08 --> Total execution time: 0.1319
DEBUG - 2022-08-15 02:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:14 --> Total execution time: 0.1096
DEBUG - 2022-08-15 02:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:20 --> Total execution time: 0.0788
DEBUG - 2022-08-15 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:19:09 --> Total execution time: 0.2052
DEBUG - 2022-08-15 02:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:49:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:19:10 --> Total execution time: 0.1028
DEBUG - 2022-08-15 02:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:49:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:19:17 --> Total execution time: 0.0844
DEBUG - 2022-08-15 02:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:19:30 --> Total execution time: 0.0960
DEBUG - 2022-08-15 02:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:49:48 --> Total execution time: 0.1224
DEBUG - 2022-08-15 02:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:20:02 --> Total execution time: 0.0847
DEBUG - 2022-08-15 02:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:50:44 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:20:44 --> Total execution time: 0.0581
DEBUG - 2022-08-15 02:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:20:51 --> Total execution time: 0.0493
DEBUG - 2022-08-15 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:00 --> Total execution time: 0.0844
DEBUG - 2022-08-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:10 --> Total execution time: 0.2023
DEBUG - 2022-08-15 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:26 --> Total execution time: 0.0873
DEBUG - 2022-08-15 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:28 --> Total execution time: 0.0764
DEBUG - 2022-08-15 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:31 --> Total execution time: 0.0836
DEBUG - 2022-08-15 02:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:39 --> Total execution time: 0.0924
DEBUG - 2022-08-15 02:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:44 --> Total execution time: 0.0812
DEBUG - 2022-08-15 02:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:51 --> Total execution time: 0.1024
DEBUG - 2022-08-15 02:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:21:59 --> Total execution time: 0.1375
DEBUG - 2022-08-15 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:22:09 --> Total execution time: 0.0813
DEBUG - 2022-08-15 02:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:22:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 02:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:22:38 --> Total execution time: 0.1050
DEBUG - 2022-08-15 02:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:52:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:22:41 --> Total execution time: 0.0585
DEBUG - 2022-08-15 02:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:22:44 --> Total execution time: 0.0803
DEBUG - 2022-08-15 02:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:22:48 --> Total execution time: 0.1132
DEBUG - 2022-08-15 02:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:53:00 --> Total execution time: 0.0834
DEBUG - 2022-08-15 02:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:53:03 --> Total execution time: 0.0764
DEBUG - 2022-08-15 02:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:53:03 --> Total execution time: 0.0810
DEBUG - 2022-08-15 02:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:23:13 --> Total execution time: 0.0825
DEBUG - 2022-08-15 02:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:42 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:23:42 --> Total execution time: 0.2527
DEBUG - 2022-08-15 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:23:47 --> Total execution time: 0.0864
DEBUG - 2022-08-15 02:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:23:56 --> Total execution time: 0.0845
DEBUG - 2022-08-15 02:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:23:59 --> Total execution time: 0.0956
DEBUG - 2022-08-15 02:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:00 --> Total execution time: 0.1000
DEBUG - 2022-08-15 02:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:12 --> Total execution time: 1.7063
DEBUG - 2022-08-15 02:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 02:54:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:24 --> Total execution time: 0.0824
DEBUG - 2022-08-15 02:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:27 --> Total execution time: 0.0830
DEBUG - 2022-08-15 02:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:42 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:42 --> Total execution time: 0.0518
DEBUG - 2022-08-15 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 02:54:44 --> 404 Page Not Found: Product-category/uncategorized
DEBUG - 2022-08-15 02:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:51 --> Total execution time: 0.0633
DEBUG - 2022-08-15 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:24:58 --> Total execution time: 0.0897
DEBUG - 2022-08-15 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:25:08 --> Total execution time: 0.1041
DEBUG - 2022-08-15 02:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:55:32 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:25:32 --> Total execution time: 0.0621
DEBUG - 2022-08-15 02:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:26:15 --> Total execution time: 0.0553
DEBUG - 2022-08-15 02:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:26:20 --> Total execution time: 0.0748
DEBUG - 2022-08-15 02:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:26:38 --> Total execution time: 0.0522
DEBUG - 2022-08-15 02:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:26:48 --> Total execution time: 0.0765
DEBUG - 2022-08-15 02:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:26:55 --> Total execution time: 0.1048
DEBUG - 2022-08-15 02:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:27:09 --> Total execution time: 0.2431
DEBUG - 2022-08-15 02:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:57:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 02:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:27:26 --> Total execution time: 0.1155
DEBUG - 2022-08-15 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:27:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 02:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:27:42 --> Total execution time: 0.1118
DEBUG - 2022-08-15 02:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:27:47 --> Total execution time: 0.1063
DEBUG - 2022-08-15 02:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:28:08 --> Total execution time: 0.0846
DEBUG - 2022-08-15 02:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:28:27 --> Total execution time: 0.1072
DEBUG - 2022-08-15 02:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:28:36 --> Total execution time: 0.0866
DEBUG - 2022-08-15 02:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:58:47 --> Total execution time: 0.0760
DEBUG - 2022-08-15 02:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:58:52 --> Total execution time: 0.0811
DEBUG - 2022-08-15 02:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:59:01 --> Total execution time: 0.1076
DEBUG - 2022-08-15 02:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:59:05 --> Total execution time: 0.0824
DEBUG - 2022-08-15 02:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:10 --> Total execution time: 0.1274
DEBUG - 2022-08-15 02:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:59:12 --> Total execution time: 0.0754
DEBUG - 2022-08-15 02:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 02:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:16 --> Total execution time: 0.0900
DEBUG - 2022-08-15 02:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:25 --> Total execution time: 0.0965
DEBUG - 2022-08-15 02:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 02:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:38 --> Total execution time: 0.1093
DEBUG - 2022-08-15 02:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:44 --> Total execution time: 0.1089
DEBUG - 2022-08-15 02:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 02:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 02:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:47 --> Total execution time: 0.0880
DEBUG - 2022-08-15 03:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:00 --> Total execution time: 0.0930
DEBUG - 2022-08-15 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:02 --> Total execution time: 0.0618
DEBUG - 2022-08-15 03:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:07 --> Total execution time: 0.1316
DEBUG - 2022-08-15 03:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:19 --> Total execution time: 0.0533
DEBUG - 2022-08-15 03:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:30 --> Total execution time: 0.0860
DEBUG - 2022-08-15 03:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:39 --> Total execution time: 0.1078
DEBUG - 2022-08-15 03:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:39 --> Total execution time: 0.1111
DEBUG - 2022-08-15 03:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:41 --> Total execution time: 0.1211
DEBUG - 2022-08-15 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:42 --> Total execution time: 0.0851
DEBUG - 2022-08-15 03:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:43 --> Total execution time: 0.0842
DEBUG - 2022-08-15 03:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:48 --> Total execution time: 0.0815
DEBUG - 2022-08-15 03:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:56 --> Total execution time: 0.1042
DEBUG - 2022-08-15 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:38 --> Total execution time: 0.0797
DEBUG - 2022-08-15 03:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:05:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:35:57 --> Total execution time: 0.0561
DEBUG - 2022-08-15 03:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:06:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:36:15 --> Total execution time: 0.2209
DEBUG - 2022-08-15 03:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:06:22 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:36:22 --> Total execution time: 0.0839
DEBUG - 2022-08-15 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:36:37 --> Total execution time: 0.0434
DEBUG - 2022-08-15 03:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 03:07:05 --> 404 Page Not Found: Comments/feed
DEBUG - 2022-08-15 03:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:09:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:39:34 --> Total execution time: 0.1052
DEBUG - 2022-08-15 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:10:14 --> Total execution time: 0.0820
DEBUG - 2022-08-15 03:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:18 --> Total execution time: 0.0473
DEBUG - 2022-08-15 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:10:24 --> Total execution time: 0.0769
DEBUG - 2022-08-15 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:10:24 --> Total execution time: 0.0711
DEBUG - 2022-08-15 03:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:26 --> Total execution time: 0.0720
DEBUG - 2022-08-15 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:48 --> Total execution time: 0.0814
DEBUG - 2022-08-15 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:53 --> Total execution time: 0.0855
DEBUG - 2022-08-15 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:58 --> Total execution time: 0.0815
DEBUG - 2022-08-15 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:10 --> Total execution time: 0.0832
DEBUG - 2022-08-15 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:19 --> Total execution time: 0.0828
DEBUG - 2022-08-15 03:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:24 --> Total execution time: 0.0770
DEBUG - 2022-08-15 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:29 --> Total execution time: 0.0767
DEBUG - 2022-08-15 03:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:37 --> Total execution time: 0.1283
DEBUG - 2022-08-15 03:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:47 --> Total execution time: 0.0774
DEBUG - 2022-08-15 03:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:50 --> Total execution time: 0.0708
DEBUG - 2022-08-15 03:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:53 --> Total execution time: 0.0716
DEBUG - 2022-08-15 03:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:03 --> Total execution time: 0.0873
DEBUG - 2022-08-15 03:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:06 --> Total execution time: 2.2886
DEBUG - 2022-08-15 03:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:17 --> Total execution time: 0.0763
DEBUG - 2022-08-15 03:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 03:12:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 03:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:57 --> Total execution time: 0.2249
DEBUG - 2022-08-15 03:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:59 --> Total execution time: 0.0879
DEBUG - 2022-08-15 03:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:43:02 --> Total execution time: 0.0833
DEBUG - 2022-08-15 03:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:43:38 --> Total execution time: 0.0868
DEBUG - 2022-08-15 03:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:43:49 --> Total execution time: 0.1015
DEBUG - 2022-08-15 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:43:55 --> Total execution time: 0.0738
DEBUG - 2022-08-15 03:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:13:56 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:43:56 --> Total execution time: 0.0774
DEBUG - 2022-08-15 03:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:44:08 --> Total execution time: 0.0722
DEBUG - 2022-08-15 03:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:44:19 --> Total execution time: 0.0830
DEBUG - 2022-08-15 03:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:44:46 --> Total execution time: 0.0781
DEBUG - 2022-08-15 03:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:45:03 --> Total execution time: 0.0922
DEBUG - 2022-08-15 03:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:17:28 --> Total execution time: 0.1412
DEBUG - 2022-08-15 03:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:17:34 --> Total execution time: 0.1026
DEBUG - 2022-08-15 03:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:48:49 --> Total execution time: 0.0963
DEBUG - 2022-08-15 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:48:54 --> Total execution time: 0.0798
DEBUG - 2022-08-15 03:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:49:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 03:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:49:26 --> Total execution time: 0.0848
DEBUG - 2022-08-15 03:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:19:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:49:26 --> Total execution time: 0.0546
DEBUG - 2022-08-15 03:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:21:31 --> Total execution time: 0.0780
DEBUG - 2022-08-15 03:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:23:52 --> Total execution time: 0.1445
DEBUG - 2022-08-15 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:54:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 03:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:54:15 --> Total execution time: 0.1236
DEBUG - 2022-08-15 03:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 03:24:49 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:57:35 --> Total execution time: 0.0764
DEBUG - 2022-08-15 03:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:59:29 --> Total execution time: 0.0835
DEBUG - 2022-08-15 03:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:59:39 --> Total execution time: 0.0871
DEBUG - 2022-08-15 03:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:59:53 --> Total execution time: 0.1019
DEBUG - 2022-08-15 03:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:04 --> Total execution time: 0.0883
DEBUG - 2022-08-15 03:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:02:21 --> Total execution time: 0.0606
DEBUG - 2022-08-15 03:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:32:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:02:21 --> Total execution time: 0.0549
DEBUG - 2022-08-15 03:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:02:23 --> Total execution time: 0.0452
DEBUG - 2022-08-15 03:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:02:23 --> Total execution time: 0.0437
DEBUG - 2022-08-15 03:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:34:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:04:28 --> Total execution time: 0.2744
DEBUG - 2022-08-15 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:34:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:04:54 --> Total execution time: 0.0985
DEBUG - 2022-08-15 03:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 03:35:01 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:35:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:02 --> Total execution time: 0.0843
DEBUG - 2022-08-15 03:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:04 --> Total execution time: 0.0835
DEBUG - 2022-08-15 03:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:35:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:14 --> Total execution time: 0.0815
DEBUG - 2022-08-15 03:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:35:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:26 --> Total execution time: 0.0800
DEBUG - 2022-08-15 03:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:35:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:57 --> Total execution time: 0.0881
DEBUG - 2022-08-15 03:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:36:46 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:06:46 --> Total execution time: 0.0809
DEBUG - 2022-08-15 03:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:08:08 --> Total execution time: 0.1595
DEBUG - 2022-08-15 03:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:08:18 --> Total execution time: 0.0753
DEBUG - 2022-08-15 03:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:08:26 --> Total execution time: 0.0817
DEBUG - 2022-08-15 03:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:08:37 --> Total execution time: 0.0904
DEBUG - 2022-08-15 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:08:41 --> Total execution time: 0.2011
DEBUG - 2022-08-15 03:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:10:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 03:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:10:13 --> Total execution time: 0.1244
DEBUG - 2022-08-15 03:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:42:11 --> Total execution time: 0.0891
DEBUG - 2022-08-15 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:42:17 --> Total execution time: 0.0948
DEBUG - 2022-08-15 03:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:13:39 --> Total execution time: 0.0816
DEBUG - 2022-08-15 03:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:44:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 03:44:08 --> 404 Page Not Found: Teacher/lester-m-brunetti
DEBUG - 2022-08-15 03:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:14:51 --> Total execution time: 0.2136
DEBUG - 2022-08-15 03:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:14:58 --> Total execution time: 0.1362
DEBUG - 2022-08-15 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:15:03 --> Total execution time: 0.0943
DEBUG - 2022-08-15 03:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:45:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:15:06 --> Total execution time: 0.0538
DEBUG - 2022-08-15 03:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:45:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:15:08 --> Total execution time: 0.0555
DEBUG - 2022-08-15 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:16:09 --> Total execution time: 0.2128
DEBUG - 2022-08-15 03:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:16:16 --> Total execution time: 0.1289
DEBUG - 2022-08-15 03:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:46:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:16:33 --> Total execution time: 0.0789
DEBUG - 2022-08-15 03:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:16:35 --> Total execution time: 0.0859
DEBUG - 2022-08-15 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:46:49 --> Total execution time: 0.0848
DEBUG - 2022-08-15 03:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:47:09 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:17:09 --> Total execution time: 0.0732
DEBUG - 2022-08-15 03:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:48:17 --> Total execution time: 0.0983
DEBUG - 2022-08-15 03:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:18:33 --> Total execution time: 0.1173
DEBUG - 2022-08-15 03:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:18:35 --> Total execution time: 0.0867
DEBUG - 2022-08-15 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:20:53 --> Total execution time: 0.2507
DEBUG - 2022-08-15 03:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:21:50 --> Total execution time: 0.0527
DEBUG - 2022-08-15 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:22:11 --> Total execution time: 0.0931
DEBUG - 2022-08-15 03:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:22:15 --> Total execution time: 0.0817
DEBUG - 2022-08-15 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:22:32 --> Total execution time: 0.0864
DEBUG - 2022-08-15 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:22:54 --> Total execution time: 0.0871
DEBUG - 2022-08-15 03:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:01 --> Total execution time: 0.0850
DEBUG - 2022-08-15 03:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:06 --> Total execution time: 0.2216
DEBUG - 2022-08-15 03:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 03:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:10 --> Total execution time: 0.0864
DEBUG - 2022-08-15 03:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:14 --> Total execution time: 0.0787
DEBUG - 2022-08-15 03:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:25 --> Total execution time: 0.0878
DEBUG - 2022-08-15 03:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:39 --> Total execution time: 0.0720
DEBUG - 2022-08-15 03:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:54 --> Total execution time: 0.0761
DEBUG - 2022-08-15 03:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:23:59 --> Total execution time: 0.1359
DEBUG - 2022-08-15 03:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:56:01 --> Total execution time: 0.1614
DEBUG - 2022-08-15 03:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:56:14 --> Total execution time: 0.1034
DEBUG - 2022-08-15 03:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 03:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:27:09 --> Total execution time: 0.0923
DEBUG - 2022-08-15 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 03:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 03:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:27:18 --> Total execution time: 0.0862
DEBUG - 2022-08-15 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:30:03 --> Total execution time: 0.1137
DEBUG - 2022-08-15 04:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:30:25 --> Total execution time: 0.2184
DEBUG - 2022-08-15 04:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:00:57 --> Total execution time: 0.0786
DEBUG - 2022-08-15 04:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:01:05 --> Total execution time: 0.0937
DEBUG - 2022-08-15 04:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:31:08 --> Total execution time: 0.2024
DEBUG - 2022-08-15 04:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:31:13 --> Total execution time: 0.0717
DEBUG - 2022-08-15 04:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:31:21 --> Total execution time: 0.0769
DEBUG - 2022-08-15 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:31:27 --> Total execution time: 0.1430
DEBUG - 2022-08-15 04:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:31:33 --> Total execution time: 0.0886
DEBUG - 2022-08-15 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:32:37 --> Total execution time: 0.0930
DEBUG - 2022-08-15 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:35:35 --> Total execution time: 0.2698
DEBUG - 2022-08-15 04:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:36:48 --> Total execution time: 0.0911
DEBUG - 2022-08-15 04:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:37:33 --> Total execution time: 0.0813
DEBUG - 2022-08-15 04:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:37:49 --> Total execution time: 0.2057
DEBUG - 2022-08-15 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:37:56 --> Total execution time: 0.0854
DEBUG - 2022-08-15 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:05 --> Total execution time: 0.0871
DEBUG - 2022-08-15 04:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:12 --> Total execution time: 0.0845
DEBUG - 2022-08-15 04:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:39 --> Total execution time: 0.2544
DEBUG - 2022-08-15 04:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:42 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:42 --> Total execution time: 0.0971
DEBUG - 2022-08-15 04:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 04:08:50 --> 404 Page Not Found: Courses-v3/index
DEBUG - 2022-08-15 04:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:50 --> Total execution time: 0.1123
DEBUG - 2022-08-15 04:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:56 --> Total execution time: 0.0940
DEBUG - 2022-08-15 04:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:38:59 --> Total execution time: 0.0849
DEBUG - 2022-08-15 04:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:39:03 --> Total execution time: 0.1076
DEBUG - 2022-08-15 04:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:39:12 --> Total execution time: 0.0894
DEBUG - 2022-08-15 04:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:39:13 --> Total execution time: 0.0824
DEBUG - 2022-08-15 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:39:28 --> Total execution time: 0.0841
DEBUG - 2022-08-15 04:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:09:58 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:39:58 --> Total execution time: 0.0548
DEBUG - 2022-08-15 04:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:40:05 --> Total execution time: 0.0503
DEBUG - 2022-08-15 04:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:40:13 --> Total execution time: 0.0785
DEBUG - 2022-08-15 04:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:40:21 --> Total execution time: 0.0784
DEBUG - 2022-08-15 04:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:40:32 --> Total execution time: 0.0813
DEBUG - 2022-08-15 04:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:40:38 --> Total execution time: 0.0803
DEBUG - 2022-08-15 04:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:10:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:40:48 --> Total execution time: 0.1028
DEBUG - 2022-08-15 04:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:41:25 --> Total execution time: 0.0813
DEBUG - 2022-08-15 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:03 --> Total execution time: 0.0786
DEBUG - 2022-08-15 04:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:15 --> Total execution time: 0.0762
DEBUG - 2022-08-15 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:16 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:16 --> Total execution time: 0.0819
DEBUG - 2022-08-15 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:22 --> Total execution time: 0.0840
DEBUG - 2022-08-15 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:22 --> Total execution time: 0.0813
DEBUG - 2022-08-15 04:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:22 --> Total execution time: 0.1207
DEBUG - 2022-08-15 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:23 --> Total execution time: 0.0820
DEBUG - 2022-08-15 04:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:12:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:42:24 --> Total execution time: 0.0825
DEBUG - 2022-08-15 04:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:14:40 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:44:41 --> Total execution time: 0.0516
DEBUG - 2022-08-15 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:44:57 --> Total execution time: 0.2215
DEBUG - 2022-08-15 04:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:07 --> Total execution time: 0.1245
DEBUG - 2022-08-15 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:15:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:26 --> Total execution time: 0.0783
DEBUG - 2022-08-15 04:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:42 --> Total execution time: 0.0864
DEBUG - 2022-08-15 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:46 --> Total execution time: 0.0921
DEBUG - 2022-08-15 04:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:54 --> Total execution time: 0.2050
DEBUG - 2022-08-15 04:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:57 --> Total execution time: 0.0858
DEBUG - 2022-08-15 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:03 --> Total execution time: 0.0873
DEBUG - 2022-08-15 04:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:11 --> Total execution time: 0.0776
DEBUG - 2022-08-15 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:14 --> Total execution time: 0.0557
DEBUG - 2022-08-15 04:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:23 --> Total execution time: 0.1128
DEBUG - 2022-08-15 04:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:16:25 --> Total execution time: 0.0772
DEBUG - 2022-08-15 04:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:16:27 --> Total execution time: 0.0858
DEBUG - 2022-08-15 04:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:16:28 --> Total execution time: 0.0777
DEBUG - 2022-08-15 04:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:36 --> Total execution time: 0.0775
DEBUG - 2022-08-15 04:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:44 --> Total execution time: 0.0863
DEBUG - 2022-08-15 04:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:44 --> Total execution time: 0.0761
DEBUG - 2022-08-15 04:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:54 --> Total execution time: 0.0770
DEBUG - 2022-08-15 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:16:56 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:56 --> Total execution time: 0.0957
DEBUG - 2022-08-15 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:09 --> Total execution time: 2.3374
DEBUG - 2022-08-15 04:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 04:17:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 04:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:17:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:24 --> Total execution time: 0.0798
DEBUG - 2022-08-15 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:37 --> Total execution time: 1.7924
DEBUG - 2022-08-15 04:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:17:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:53 --> Total execution time: 0.0806
DEBUG - 2022-08-15 04:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:01 --> Total execution time: 0.1155
DEBUG - 2022-08-15 04:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:07 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:07 --> Total execution time: 0.0827
DEBUG - 2022-08-15 04:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:25 --> Total execution time: 0.0700
DEBUG - 2022-08-15 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:28 --> Total execution time: 0.0818
DEBUG - 2022-08-15 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:38 --> Total execution time: 1.8491
DEBUG - 2022-08-15 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:50 --> Total execution time: 0.0818
DEBUG - 2022-08-15 04:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:56 --> Total execution time: 0.0830
DEBUG - 2022-08-15 04:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:58 --> Total execution time: 0.0850
DEBUG - 2022-08-15 04:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:49:05 --> Total execution time: 0.1165
DEBUG - 2022-08-15 04:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:49:12 --> Total execution time: 0.0897
DEBUG - 2022-08-15 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:49:13 --> Total execution time: 0.0812
DEBUG - 2022-08-15 04:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:49:17 --> Total execution time: 0.0764
DEBUG - 2022-08-15 04:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:21:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:51:40 --> Total execution time: 0.2491
DEBUG - 2022-08-15 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:51:40 --> Total execution time: 0.0780
DEBUG - 2022-08-15 04:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:51:54 --> Total execution time: 1.9158
DEBUG - 2022-08-15 04:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:52:18 --> Total execution time: 0.0801
DEBUG - 2022-08-15 04:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:23 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:52:23 --> Total execution time: 0.0531
DEBUG - 2022-08-15 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:30 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:52:30 --> Total execution time: 0.0795
DEBUG - 2022-08-15 04:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:52:34 --> Total execution time: 0.0743
DEBUG - 2022-08-15 04:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:22:45 --> Total execution time: 0.0976
DEBUG - 2022-08-15 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:22:46 --> Total execution time: 0.0787
DEBUG - 2022-08-15 04:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:22:46 --> Total execution time: 0.1805
DEBUG - 2022-08-15 04:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:52:54 --> Total execution time: 0.0785
DEBUG - 2022-08-15 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:05 --> Total execution time: 0.1002
DEBUG - 2022-08-15 04:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:14 --> Total execution time: 0.1058
DEBUG - 2022-08-15 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:19 --> Total execution time: 0.0806
DEBUG - 2022-08-15 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:20 --> Total execution time: 0.0758
DEBUG - 2022-08-15 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:24 --> Total execution time: 0.0748
DEBUG - 2022-08-15 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:27 --> Total execution time: 0.0988
DEBUG - 2022-08-15 04:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:23:30 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:53:30 --> Total execution time: 0.0838
DEBUG - 2022-08-15 04:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:55:13 --> Total execution time: 0.0864
DEBUG - 2022-08-15 04:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:55:47 --> Total execution time: 0.0827
DEBUG - 2022-08-15 04:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:56:35 --> Total execution time: 0.0878
DEBUG - 2022-08-15 04:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:56:50 --> Total execution time: 0.1140
DEBUG - 2022-08-15 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:26:57 --> Total execution time: 0.0789
DEBUG - 2022-08-15 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:57:03 --> Total execution time: 0.1093
DEBUG - 2022-08-15 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:57:07 --> Total execution time: 0.0819
DEBUG - 2022-08-15 04:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:57:25 --> Total execution time: 0.0798
DEBUG - 2022-08-15 04:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:57:55 --> Total execution time: 0.0804
DEBUG - 2022-08-15 04:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:58:11 --> Total execution time: 0.1092
DEBUG - 2022-08-15 04:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:28:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:58:14 --> Total execution time: 0.1128
DEBUG - 2022-08-15 04:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:15 --> Total execution time: 0.1286
DEBUG - 2022-08-15 04:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:21 --> Total execution time: 0.0766
DEBUG - 2022-08-15 04:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:30 --> Total execution time: 0.0817
DEBUG - 2022-08-15 04:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:37 --> Total execution time: 0.1202
DEBUG - 2022-08-15 04:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:47 --> Total execution time: 0.0904
DEBUG - 2022-08-15 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:53 --> Total execution time: 0.0853
DEBUG - 2022-08-15 04:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:57 --> Total execution time: 0.0818
DEBUG - 2022-08-15 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:01:00 --> Total execution time: 0.0919
DEBUG - 2022-08-15 04:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:32:04 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:02:04 --> Total execution time: 0.0551
DEBUG - 2022-08-15 04:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:32:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:02:05 --> Total execution time: 0.0513
DEBUG - 2022-08-15 04:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 04:33:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 04:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:35:07 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:05:07 --> Total execution time: 0.0535
DEBUG - 2022-08-15 04:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:35:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:05:41 --> Total execution time: 0.0556
DEBUG - 2022-08-15 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:39:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:09:29 --> Total execution time: 0.1114
DEBUG - 2022-08-15 04:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:11:54 --> Total execution time: 0.2511
DEBUG - 2022-08-15 04:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:04 --> Total execution time: 0.0878
DEBUG - 2022-08-15 04:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:16 --> Total execution time: 0.0777
DEBUG - 2022-08-15 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:20 --> Total execution time: 0.0774
DEBUG - 2022-08-15 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:27 --> Total execution time: 0.0770
DEBUG - 2022-08-15 04:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:34 --> Total execution time: 0.0780
DEBUG - 2022-08-15 04:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:39 --> Total execution time: 0.0766
DEBUG - 2022-08-15 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:49 --> Total execution time: 0.0982
DEBUG - 2022-08-15 04:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:57 --> Total execution time: 0.0951
DEBUG - 2022-08-15 04:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:12:58 --> Total execution time: 0.0757
DEBUG - 2022-08-15 04:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:01 --> Total execution time: 0.1045
DEBUG - 2022-08-15 04:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:11 --> Total execution time: 0.0574
DEBUG - 2022-08-15 04:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:11 --> Total execution time: 0.0517
DEBUG - 2022-08-15 04:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:16 --> Total execution time: 0.0872
DEBUG - 2022-08-15 04:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:19 --> Total execution time: 0.0832
DEBUG - 2022-08-15 04:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:30 --> Total execution time: 0.1106
DEBUG - 2022-08-15 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:31 --> Total execution time: 0.1064
DEBUG - 2022-08-15 04:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:43:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:13:49 --> Total execution time: 0.0555
DEBUG - 2022-08-15 04:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:44:30 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:14:30 --> Total execution time: 0.0520
DEBUG - 2022-08-15 04:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:14:37 --> Total execution time: 0.0829
DEBUG - 2022-08-15 04:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:14:56 --> Total execution time: 0.0844
DEBUG - 2022-08-15 04:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:15:08 --> Total execution time: 0.0938
DEBUG - 2022-08-15 04:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:15:23 --> Total execution time: 0.0787
DEBUG - 2022-08-15 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:46:57 --> Total execution time: 0.0821
DEBUG - 2022-08-15 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:46:59 --> Total execution time: 0.0733
DEBUG - 2022-08-15 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:46:59 --> Total execution time: 0.0808
DEBUG - 2022-08-15 04:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:48:43 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:43 --> Total execution time: 0.0534
DEBUG - 2022-08-15 04:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:13 --> Total execution time: 0.1169
DEBUG - 2022-08-15 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:20 --> Total execution time: 0.1151
DEBUG - 2022-08-15 04:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 04:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:17 --> Total execution time: 0.0924
DEBUG - 2022-08-15 04:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:39 --> Total execution time: 0.0855
DEBUG - 2022-08-15 04:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:50:46 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:46 --> Total execution time: 0.0537
DEBUG - 2022-08-15 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:51:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:02 --> Total execution time: 0.0568
DEBUG - 2022-08-15 04:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:11 --> Total execution time: 0.0786
DEBUG - 2022-08-15 04:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:14 --> Total execution time: 0.0791
DEBUG - 2022-08-15 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:52:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:15 --> Total execution time: 0.0637
DEBUG - 2022-08-15 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:29 --> Total execution time: 0.0855
DEBUG - 2022-08-15 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:23:36 --> Total execution time: 0.0794
DEBUG - 2022-08-15 04:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:24:13 --> Total execution time: 0.1294
DEBUG - 2022-08-15 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:24:38 --> Total execution time: 0.2162
DEBUG - 2022-08-15 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 04:54:41 --> 404 Page Not Found: Event/glow-an-exhibition-with-the-greenway
DEBUG - 2022-08-15 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:57:44 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:27:44 --> Total execution time: 0.1136
DEBUG - 2022-08-15 04:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:58:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:28:03 --> Total execution time: 0.2167
DEBUG - 2022-08-15 04:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 04:59:40 --> No URI present. Default controller set.
DEBUG - 2022-08-15 04:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 04:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:29:40 --> Total execution time: 0.0536
DEBUG - 2022-08-15 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:02 --> Total execution time: 0.0608
DEBUG - 2022-08-15 05:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:00:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:27 --> Total execution time: 0.0519
DEBUG - 2022-08-15 05:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:00:38 --> Total execution time: 0.1475
DEBUG - 2022-08-15 05:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:00:46 --> Total execution time: 0.0969
DEBUG - 2022-08-15 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:00:47 --> Total execution time: 0.1678
DEBUG - 2022-08-15 05:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:19 --> Total execution time: 0.2067
DEBUG - 2022-08-15 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:20 --> Total execution time: 0.0756
DEBUG - 2022-08-15 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:20 --> Total execution time: 0.1064
DEBUG - 2022-08-15 05:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:28 --> Total execution time: 0.0969
DEBUG - 2022-08-15 05:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:07:23 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:37:23 --> Total execution time: 0.2665
DEBUG - 2022-08-15 05:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:09:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:39:24 --> Total execution time: 0.0861
DEBUG - 2022-08-15 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:09:29 --> Total execution time: 0.0978
DEBUG - 2022-08-15 05:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:10:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:40:34 --> Total execution time: 0.0632
DEBUG - 2022-08-15 05:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:10:35 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:40:35 --> Total execution time: 0.0807
DEBUG - 2022-08-15 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:09 --> Total execution time: 0.1185
DEBUG - 2022-08-15 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:12 --> Total execution time: 0.0752
DEBUG - 2022-08-15 05:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:14 --> Total execution time: 0.0754
DEBUG - 2022-08-15 05:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:14 --> Total execution time: 0.0938
DEBUG - 2022-08-15 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:41:31 --> Total execution time: 0.1142
DEBUG - 2022-08-15 05:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:41:37 --> Total execution time: 0.0859
DEBUG - 2022-08-15 05:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:44 --> Total execution time: 0.0768
DEBUG - 2022-08-15 05:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:46 --> Total execution time: 0.0760
DEBUG - 2022-08-15 05:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:11:46 --> Total execution time: 0.0912
DEBUG - 2022-08-15 05:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:08 --> Total execution time: 0.0881
DEBUG - 2022-08-15 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:18 --> Total execution time: 0.0960
DEBUG - 2022-08-15 05:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:34 --> Total execution time: 0.1219
DEBUG - 2022-08-15 05:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:51 --> Total execution time: 0.2360
DEBUG - 2022-08-15 15:42:51 --> Total execution time: 0.2200
DEBUG - 2022-08-15 05:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:59 --> Total execution time: 0.0931
DEBUG - 2022-08-15 05:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:43:09 --> Total execution time: 0.1204
DEBUG - 2022-08-15 05:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:43:20 --> Total execution time: 0.0973
DEBUG - 2022-08-15 05:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:43:26 --> Total execution time: 0.0902
DEBUG - 2022-08-15 05:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:43:28 --> Total execution time: 0.0961
DEBUG - 2022-08-15 05:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:02 --> Total execution time: 0.0856
DEBUG - 2022-08-15 05:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:07 --> Total execution time: 0.0840
DEBUG - 2022-08-15 05:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:09 --> Total execution time: 0.0807
DEBUG - 2022-08-15 05:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:18 --> Total execution time: 0.0827
DEBUG - 2022-08-15 05:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:19 --> Total execution time: 0.0721
DEBUG - 2022-08-15 05:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:23 --> Total execution time: 0.1152
DEBUG - 2022-08-15 05:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:26 --> Total execution time: 0.0835
DEBUG - 2022-08-15 05:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:55 --> Total execution time: 0.1078
DEBUG - 2022-08-15 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:45:07 --> Total execution time: 0.0636
DEBUG - 2022-08-15 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:18:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:48:06 --> Total execution time: 0.2594
DEBUG - 2022-08-15 05:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:50:13 --> Total execution time: 0.0979
DEBUG - 2022-08-15 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 05:23:12 --> 404 Page Not Found: Cart/index
DEBUG - 2022-08-15 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:23:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:13 --> Total execution time: 0.0948
DEBUG - 2022-08-15 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 05:23:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 05:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:23:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:54 --> Total execution time: 0.2025
DEBUG - 2022-08-15 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 05:25:12 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 05:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:57:19 --> Total execution time: 0.0776
DEBUG - 2022-08-15 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:57:29 --> Total execution time: 0.0827
DEBUG - 2022-08-15 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:57:35 --> Total execution time: 0.0748
DEBUG - 2022-08-15 05:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:57:42 --> Total execution time: 0.0999
DEBUG - 2022-08-15 05:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:57:43 --> Total execution time: 0.1226
DEBUG - 2022-08-15 05:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:58:00 --> Total execution time: 0.1344
DEBUG - 2022-08-15 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:58:12 --> Total execution time: 0.1155
DEBUG - 2022-08-15 05:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:58:27 --> Total execution time: 0.0795
DEBUG - 2022-08-15 05:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:58:47 --> Total execution time: 0.0867
DEBUG - 2022-08-15 05:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:58:55 --> Total execution time: 0.1272
DEBUG - 2022-08-15 05:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:59:11 --> Total execution time: 0.1056
DEBUG - 2022-08-15 05:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:29:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:59:15 --> Total execution time: 0.0980
DEBUG - 2022-08-15 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:00:23 --> Total execution time: 2.4796
DEBUG - 2022-08-15 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 05:30:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 05:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:03:54 --> Total execution time: 0.2577
DEBUG - 2022-08-15 05:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:34:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:04:03 --> Total execution time: 0.0574
DEBUG - 2022-08-15 05:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:04:09 --> Total execution time: 0.0783
DEBUG - 2022-08-15 05:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:28 --> Total execution time: 0.0809
DEBUG - 2022-08-15 05:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:28 --> Total execution time: 0.0815
DEBUG - 2022-08-15 05:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:29 --> Total execution time: 0.0759
DEBUG - 2022-08-15 05:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:29 --> Total execution time: 0.0830
DEBUG - 2022-08-15 05:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:29 --> Total execution time: 0.0858
DEBUG - 2022-08-15 05:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:30 --> Total execution time: 0.0825
DEBUG - 2022-08-15 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:32 --> Total execution time: 0.1008
DEBUG - 2022-08-15 05:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:35:32 --> Total execution time: 0.1828
DEBUG - 2022-08-15 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:05:50 --> Total execution time: 0.0574
DEBUG - 2022-08-15 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:35:55 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:05:56 --> Total execution time: 0.0527
DEBUG - 2022-08-15 05:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:06:28 --> Total execution time: 0.0769
DEBUG - 2022-08-15 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 05:37:24 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:07:33 --> Total execution time: 1.8613
DEBUG - 2022-08-15 05:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:07:34 --> Total execution time: 0.0800
DEBUG - 2022-08-15 05:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:07:52 --> Total execution time: 0.1021
DEBUG - 2022-08-15 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:02 --> Total execution time: 0.0815
DEBUG - 2022-08-15 05:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:03 --> Total execution time: 0.0811
DEBUG - 2022-08-15 05:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 05:39:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 05:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:04 --> Total execution time: 0.0806
DEBUG - 2022-08-15 05:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:07 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:07 --> Total execution time: 0.0862
DEBUG - 2022-08-15 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:32 --> Total execution time: 1.6731
DEBUG - 2022-08-15 05:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:34 --> Total execution time: 2.2965
DEBUG - 2022-08-15 05:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:36 --> Total execution time: 1.9944
DEBUG - 2022-08-15 05:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:38 --> Total execution time: 2.8797
DEBUG - 2022-08-15 05:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:39 --> Total execution time: 3.3082
DEBUG - 2022-08-15 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:41 --> Total execution time: 4.3761
DEBUG - 2022-08-15 05:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:43 --> Total execution time: 5.6245
DEBUG - 2022-08-15 05:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:44 --> Total execution time: 6.5190
DEBUG - 2022-08-15 05:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:46 --> Total execution time: 7.1625
DEBUG - 2022-08-15 05:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:48 --> Total execution time: 8.6283
DEBUG - 2022-08-15 05:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:50 --> Total execution time: 8.9160
DEBUG - 2022-08-15 05:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:52 --> Total execution time: 10.1943
DEBUG - 2022-08-15 05:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:09:54 --> Total execution time: 11.1176
DEBUG - 2022-08-15 05:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:55 --> Total execution time: 12.1904
DEBUG - 2022-08-15 05:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:57 --> Total execution time: 12.9778
DEBUG - 2022-08-15 05:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:09:59 --> Total execution time: 14.6160
DEBUG - 2022-08-15 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:01 --> Total execution time: 16.1061
DEBUG - 2022-08-15 05:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:02 --> Total execution time: 17.7471
DEBUG - 2022-08-15 05:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:04 --> Total execution time: 19.2495
DEBUG - 2022-08-15 05:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:06 --> Total execution time: 20.6451
DEBUG - 2022-08-15 05:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:08 --> Total execution time: 19.8405
DEBUG - 2022-08-15 05:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:09 --> Total execution time: 20.3012
DEBUG - 2022-08-15 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:11 --> Total execution time: 20.7530
DEBUG - 2022-08-15 05:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:13 --> Total execution time: 21.7905
DEBUG - 2022-08-15 05:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:10:15 --> Total execution time: 22.4990
DEBUG - 2022-08-15 05:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:08 --> Total execution time: 0.2016
DEBUG - 2022-08-15 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:19 --> Total execution time: 0.0767
DEBUG - 2022-08-15 05:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:25 --> Total execution time: 0.2125
DEBUG - 2022-08-15 05:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:26 --> Total execution time: 0.1109
DEBUG - 2022-08-15 05:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:41 --> Total execution time: 0.1287
DEBUG - 2022-08-15 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:50 --> Total execution time: 0.1068
DEBUG - 2022-08-15 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:12:56 --> Total execution time: 0.1184
DEBUG - 2022-08-15 05:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:13:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 05:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:13:09 --> Total execution time: 0.1063
DEBUG - 2022-08-15 05:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:13:17 --> Total execution time: 0.1106
DEBUG - 2022-08-15 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:13:24 --> Total execution time: 0.0832
DEBUG - 2022-08-15 05:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:13:34 --> Total execution time: 0.1179
DEBUG - 2022-08-15 05:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:14:09 --> Total execution time: 0.1045
DEBUG - 2022-08-15 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:14:47 --> Total execution time: 0.2184
DEBUG - 2022-08-15 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:50:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 05:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:20:03 --> Total execution time: 0.1317
DEBUG - 2022-08-15 05:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:24:59 --> Total execution time: 0.0801
DEBUG - 2022-08-15 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:25:53 --> Total execution time: 0.0813
DEBUG - 2022-08-15 05:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 05:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 05:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 05:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:29:44 --> Total execution time: 0.0782
DEBUG - 2022-08-15 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:30:02 --> Total execution time: 0.0639
DEBUG - 2022-08-15 06:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:02:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:32:27 --> Total execution time: 0.1056
DEBUG - 2022-08-15 06:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:33:20 --> Total execution time: 0.2140
DEBUG - 2022-08-15 06:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:33:30 --> Total execution time: 0.0774
DEBUG - 2022-08-15 06:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:34:43 --> Total execution time: 0.2080
DEBUG - 2022-08-15 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:34:53 --> Total execution time: 0.0780
DEBUG - 2022-08-15 06:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:36:36 --> Total execution time: 0.2204
DEBUG - 2022-08-15 06:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:36:42 --> Total execution time: 0.1201
DEBUG - 2022-08-15 06:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:36:52 --> Total execution time: 0.1178
DEBUG - 2022-08-15 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:36:56 --> Total execution time: 0.1022
DEBUG - 2022-08-15 06:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:36:59 --> Total execution time: 0.1223
DEBUG - 2022-08-15 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:37:07 --> Total execution time: 0.1333
DEBUG - 2022-08-15 06:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:38:17 --> Total execution time: 0.1078
DEBUG - 2022-08-15 06:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:38:21 --> Total execution time: 0.0503
DEBUG - 2022-08-15 06:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:38:46 --> Total execution time: 0.0788
DEBUG - 2022-08-15 06:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:38:47 --> Total execution time: 0.0782
DEBUG - 2022-08-15 06:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:38:57 --> Total execution time: 0.1151
DEBUG - 2022-08-15 06:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:39:42 --> Total execution time: 0.1191
DEBUG - 2022-08-15 06:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:40:35 --> Total execution time: 0.0838
DEBUG - 2022-08-15 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:40:49 --> Total execution time: 0.0835
DEBUG - 2022-08-15 06:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:40:58 --> Total execution time: 0.1100
DEBUG - 2022-08-15 06:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:41:05 --> Total execution time: 0.0502
DEBUG - 2022-08-15 06:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:41:32 --> Total execution time: 0.0876
DEBUG - 2022-08-15 06:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:42:01 --> Total execution time: 0.1295
DEBUG - 2022-08-15 06:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:42:24 --> Total execution time: 0.0833
DEBUG - 2022-08-15 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:46:03 --> Total execution time: 0.0816
DEBUG - 2022-08-15 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:46:21 --> Total execution time: 0.0782
DEBUG - 2022-08-15 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:47 --> Total execution time: 0.2122
DEBUG - 2022-08-15 06:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:56 --> Total execution time: 0.2330
DEBUG - 2022-08-15 06:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:57 --> Total execution time: 0.0825
DEBUG - 2022-08-15 06:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:48:15 --> Total execution time: 0.0893
DEBUG - 2022-08-15 06:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:49:43 --> Total execution time: 0.0500
DEBUG - 2022-08-15 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:49:47 --> Total execution time: 0.0926
DEBUG - 2022-08-15 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:49:55 --> Total execution time: 0.0842
DEBUG - 2022-08-15 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:50:03 --> Total execution time: 0.0899
DEBUG - 2022-08-15 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:50:07 --> Total execution time: 0.0977
DEBUG - 2022-08-15 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:50:20 --> Total execution time: 0.0809
DEBUG - 2022-08-15 06:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:51:29 --> Total execution time: 0.0842
DEBUG - 2022-08-15 06:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:51:36 --> Total execution time: 0.1188
DEBUG - 2022-08-15 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:51:43 --> Total execution time: 0.0856
DEBUG - 2022-08-15 06:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:21 --> Total execution time: 0.1248
DEBUG - 2022-08-15 06:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:25 --> Total execution time: 0.0701
DEBUG - 2022-08-15 06:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:33 --> Total execution time: 0.0990
DEBUG - 2022-08-15 06:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:41 --> Total execution time: 0.0878
DEBUG - 2022-08-15 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:42 --> Total execution time: 0.0791
DEBUG - 2022-08-15 06:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:46 --> Total execution time: 0.1303
DEBUG - 2022-08-15 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:56:55 --> Total execution time: 0.0784
DEBUG - 2022-08-15 06:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:58:59 --> Total execution time: 0.2251
DEBUG - 2022-08-15 06:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:59:06 --> Total execution time: 0.1094
DEBUG - 2022-08-15 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:29:09 --> Total execution time: 0.0812
DEBUG - 2022-08-15 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:29:13 --> Total execution time: 0.0549
DEBUG - 2022-08-15 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:29:13 --> Total execution time: 0.0497
DEBUG - 2022-08-15 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:59:23 --> Total execution time: 0.0980
DEBUG - 2022-08-15 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:00:01 --> Total execution time: 0.1142
DEBUG - 2022-08-15 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:00:02 --> Total execution time: 0.1133
DEBUG - 2022-08-15 06:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:00:06 --> Total execution time: 0.1074
DEBUG - 2022-08-15 06:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:00:10 --> Total execution time: 0.0786
DEBUG - 2022-08-15 06:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:00:31 --> Total execution time: 0.0785
DEBUG - 2022-08-15 06:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:34:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:04:21 --> Total execution time: 0.1218
DEBUG - 2022-08-15 06:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:05:11 --> Total execution time: 0.0829
DEBUG - 2022-08-15 06:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:36:35 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:06:35 --> Total execution time: 0.0475
DEBUG - 2022-08-15 06:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:06:46 --> Total execution time: 0.0782
DEBUG - 2022-08-15 06:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:07:03 --> Total execution time: 0.0936
DEBUG - 2022-08-15 06:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:07:08 --> Total execution time: 0.2142
DEBUG - 2022-08-15 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:07:16 --> Total execution time: 0.0832
DEBUG - 2022-08-15 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:39:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:09:55 --> Total execution time: 0.1041
DEBUG - 2022-08-15 06:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:40:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:10:50 --> Total execution time: 0.2057
DEBUG - 2022-08-15 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:11:00 --> Total execution time: 0.0742
DEBUG - 2022-08-15 06:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:11:21 --> Total execution time: 0.0783
DEBUG - 2022-08-15 06:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:11:24 --> Total execution time: 0.0916
DEBUG - 2022-08-15 06:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:11:29 --> Total execution time: 0.1110
DEBUG - 2022-08-15 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:11:36 --> Total execution time: 0.0862
DEBUG - 2022-08-15 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:41:38 --> Total execution time: 0.0875
DEBUG - 2022-08-15 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:41:40 --> Total execution time: 0.0837
DEBUG - 2022-08-15 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:41:40 --> Total execution time: 0.0816
DEBUG - 2022-08-15 06:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:42:16 --> Total execution time: 0.0560
DEBUG - 2022-08-15 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:42:30 --> Total execution time: 0.0871
DEBUG - 2022-08-15 06:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:42:31 --> Total execution time: 0.0785
DEBUG - 2022-08-15 06:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:12:38 --> Total execution time: 0.0952
DEBUG - 2022-08-15 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:42:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:12:45 --> Total execution time: 0.0523
DEBUG - 2022-08-15 06:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:12:49 --> Total execution time: 0.0857
DEBUG - 2022-08-15 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:43:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:13:35 --> Total execution time: 0.0951
DEBUG - 2022-08-15 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:43:39 --> Total execution time: 0.0873
DEBUG - 2022-08-15 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:43:41 --> Total execution time: 0.0847
DEBUG - 2022-08-15 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:43:41 --> Total execution time: 0.1018
DEBUG - 2022-08-15 06:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:44:43 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:14:43 --> Total execution time: 0.0550
DEBUG - 2022-08-15 06:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:45:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:15:01 --> Total execution time: 0.0837
DEBUG - 2022-08-15 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:45:16 --> Total execution time: 0.0735
DEBUG - 2022-08-15 06:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:45:18 --> Total execution time: 0.0757
DEBUG - 2022-08-15 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:45:18 --> Total execution time: 0.0722
DEBUG - 2022-08-15 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:24 --> Total execution time: 0.0766
DEBUG - 2022-08-15 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:25 --> Total execution time: 0.0930
DEBUG - 2022-08-15 06:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:26 --> Total execution time: 0.0904
DEBUG - 2022-08-15 06:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:37 --> Total execution time: 0.0817
DEBUG - 2022-08-15 06:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:39 --> Total execution time: 0.0823
DEBUG - 2022-08-15 06:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:46:39 --> Total execution time: 0.0810
DEBUG - 2022-08-15 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:16:40 --> Total execution time: 0.0780
DEBUG - 2022-08-15 06:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:17:00 --> Total execution time: 0.0790
DEBUG - 2022-08-15 06:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:17:13 --> Total execution time: 0.2031
DEBUG - 2022-08-15 06:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:47:19 --> Total execution time: 0.0810
DEBUG - 2022-08-15 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:47:21 --> Total execution time: 0.0775
DEBUG - 2022-08-15 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:47:22 --> Total execution time: 0.0714
DEBUG - 2022-08-15 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:17:28 --> Total execution time: 0.0756
DEBUG - 2022-08-15 06:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:17:32 --> Total execution time: 0.0789
DEBUG - 2022-08-15 06:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:17:32 --> Total execution time: 0.0776
DEBUG - 2022-08-15 06:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:18:40 --> Total execution time: 0.0780
DEBUG - 2022-08-15 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:48:56 --> Total execution time: 0.0731
DEBUG - 2022-08-15 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:18:57 --> Total execution time: 0.0706
DEBUG - 2022-08-15 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:48:58 --> Total execution time: 0.0811
DEBUG - 2022-08-15 06:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:01 --> Total execution time: 0.1165
DEBUG - 2022-08-15 06:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:01 --> Total execution time: 0.1439
DEBUG - 2022-08-15 06:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:19:03 --> Total execution time: 0.0901
DEBUG - 2022-08-15 06:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:19:07 --> Total execution time: 0.0738
DEBUG - 2022-08-15 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:16 --> Total execution time: 0.0727
DEBUG - 2022-08-15 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:18 --> Total execution time: 0.0941
DEBUG - 2022-08-15 06:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:19 --> Total execution time: 0.1302
DEBUG - 2022-08-15 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:19:25 --> Total execution time: 0.0754
DEBUG - 2022-08-15 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:19:57 --> Total execution time: 0.0765
DEBUG - 2022-08-15 06:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:50:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:20:10 --> Total execution time: 0.0521
DEBUG - 2022-08-15 06:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:20:14 --> Total execution time: 0.0791
DEBUG - 2022-08-15 06:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:21:10 --> Total execution time: 0.0542
DEBUG - 2022-08-15 06:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:21:15 --> Total execution time: 0.0919
DEBUG - 2022-08-15 06:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:21:17 --> Total execution time: 0.0960
DEBUG - 2022-08-15 06:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:21:44 --> Total execution time: 0.0976
DEBUG - 2022-08-15 06:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:21:50 --> Total execution time: 0.1098
DEBUG - 2022-08-15 06:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:21:57 --> Total execution time: 0.1135
DEBUG - 2022-08-15 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:22:02 --> Total execution time: 0.0766
DEBUG - 2022-08-15 06:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:25:44 --> Total execution time: 0.2832
DEBUG - 2022-08-15 06:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:25:57 --> Total execution time: 0.1146
DEBUG - 2022-08-15 06:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:26:04 --> Total execution time: 0.1108
DEBUG - 2022-08-15 06:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:58:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:28:50 --> Total execution time: 0.1090
DEBUG - 2022-08-15 06:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 06:59:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 06:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 06:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:29:53 --> Total execution time: 0.0793
DEBUG - 2022-08-15 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:30:02 --> Total execution time: 0.0607
DEBUG - 2022-08-15 07:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:00:22 --> Total execution time: 0.0795
DEBUG - 2022-08-15 07:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:00:24 --> Total execution time: 0.0727
DEBUG - 2022-08-15 07:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:00:24 --> Total execution time: 0.0935
DEBUG - 2022-08-15 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:00:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:30:41 --> Total execution time: 0.0835
DEBUG - 2022-08-15 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:00:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:30:41 --> Total execution time: 0.0786
DEBUG - 2022-08-15 07:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:06:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:36:20 --> Total execution time: 0.1250
DEBUG - 2022-08-15 07:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:06:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:36:24 --> Total execution time: 0.0873
DEBUG - 2022-08-15 07:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:36:32 --> Total execution time: 0.0859
DEBUG - 2022-08-15 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:36:39 --> Total execution time: 0.0939
DEBUG - 2022-08-15 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:36:49 --> Total execution time: 0.1516
DEBUG - 2022-08-15 07:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:06 --> Total execution time: 0.1320
DEBUG - 2022-08-15 07:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:10 --> Total execution time: 0.0572
DEBUG - 2022-08-15 07:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:18 --> Total execution time: 0.1164
DEBUG - 2022-08-15 07:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:35 --> Total execution time: 0.0960
DEBUG - 2022-08-15 07:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:37 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:37 --> Total execution time: 0.0629
DEBUG - 2022-08-15 07:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:40 --> Total execution time: 0.0836
DEBUG - 2022-08-15 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:44 --> Total execution time: 0.1183
DEBUG - 2022-08-15 07:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:38:58 --> Total execution time: 0.0595
DEBUG - 2022-08-15 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:09:01 --> Total execution time: 0.1399
DEBUG - 2022-08-15 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:39:19 --> Total execution time: 0.0843
DEBUG - 2022-08-15 07:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:09:20 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-08-15 07:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:09:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:39:38 --> Total execution time: 0.2051
DEBUG - 2022-08-15 07:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:09:47 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-08-15 07:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:39:48 --> Total execution time: 0.0812
DEBUG - 2022-08-15 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:09:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:09:56 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-08-15 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:40:06 --> Total execution time: 0.0808
DEBUG - 2022-08-15 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:40:07 --> Total execution time: 0.0779
DEBUG - 2022-08-15 07:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:41:00 --> Total execution time: 0.1110
DEBUG - 2022-08-15 07:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:41:02 --> Total execution time: 0.1045
DEBUG - 2022-08-15 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:41:09 --> Total execution time: 0.1148
DEBUG - 2022-08-15 07:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:41:15 --> Total execution time: 0.1788
DEBUG - 2022-08-15 07:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:41:30 --> Total execution time: 0.1241
DEBUG - 2022-08-15 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:41:44 --> Total execution time: 0.0809
DEBUG - 2022-08-15 07:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:44:06 --> Total execution time: 0.0533
DEBUG - 2022-08-15 07:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:14:23 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:44:23 --> Total execution time: 0.0560
DEBUG - 2022-08-15 07:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:15:22 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:45:22 --> Total execution time: 0.0548
DEBUG - 2022-08-15 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:48:13 --> Total execution time: 0.1363
DEBUG - 2022-08-15 07:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:48:18 --> Total execution time: 0.0834
DEBUG - 2022-08-15 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:48:28 --> Total execution time: 0.0884
DEBUG - 2022-08-15 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:19:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:49:45 --> Total execution time: 0.0767
DEBUG - 2022-08-15 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:22 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:50:22 --> Total execution time: 0.0525
DEBUG - 2022-08-15 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:50:43 --> Total execution time: 0.0858
DEBUG - 2022-08-15 07:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:50:52 --> Total execution time: 0.0958
DEBUG - 2022-08-15 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:50:52 --> Total execution time: 0.0901
DEBUG - 2022-08-15 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:50:56 --> Total execution time: 0.0820
DEBUG - 2022-08-15 07:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:21:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:51:00 --> Total execution time: 0.0551
DEBUG - 2022-08-15 07:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:21:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:51:53 --> Total execution time: 0.0647
DEBUG - 2022-08-15 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:52:23 --> Total execution time: 0.0787
DEBUG - 2022-08-15 07:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:53:29 --> Total execution time: 0.1054
DEBUG - 2022-08-15 07:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:53:39 --> Total execution time: 0.0717
DEBUG - 2022-08-15 07:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:53:53 --> Total execution time: 0.0788
DEBUG - 2022-08-15 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:01 --> Total execution time: 0.0821
DEBUG - 2022-08-15 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:03 --> Total execution time: 0.0831
DEBUG - 2022-08-15 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:04 --> Total execution time: 0.0829
DEBUG - 2022-08-15 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:54:36 --> Total execution time: 0.0846
DEBUG - 2022-08-15 07:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:38 --> Total execution time: 0.0783
DEBUG - 2022-08-15 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:40 --> Total execution time: 0.0818
DEBUG - 2022-08-15 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:24:40 --> Total execution time: 0.0787
DEBUG - 2022-08-15 07:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:09 --> Total execution time: 2.4427
DEBUG - 2022-08-15 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:19 --> Total execution time: 0.0815
DEBUG - 2022-08-15 07:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:24 --> Total execution time: 0.0867
DEBUG - 2022-08-15 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:26 --> Total execution time: 0.0821
DEBUG - 2022-08-15 07:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:40 --> Total execution time: 0.0879
DEBUG - 2022-08-15 07:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:43 --> Total execution time: 0.1071
DEBUG - 2022-08-15 07:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:55:54 --> Total execution time: 0.0767
DEBUG - 2022-08-15 07:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:26:01 --> 404 Page Not Found: Personal-branding-course/index
DEBUG - 2022-08-15 07:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:27:35 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 07:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:28:22 --> Total execution time: 0.0931
DEBUG - 2022-08-15 07:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:28:23 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:58:23 --> Total execution time: 0.2020
DEBUG - 2022-08-15 07:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:28:36 --> Total execution time: 0.1014
DEBUG - 2022-08-15 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:59:02 --> Total execution time: 0.1131
DEBUG - 2022-08-15 07:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:31:46 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:01:46 --> Total execution time: 0.1490
DEBUG - 2022-08-15 07:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:31:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:01:47 --> Total execution time: 0.0516
DEBUG - 2022-08-15 07:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:01:50 --> Total execution time: 1.9461
DEBUG - 2022-08-15 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:32:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:02:26 --> Total execution time: 0.0635
DEBUG - 2022-08-15 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:10 --> Total execution time: 0.2110
DEBUG - 2022-08-15 07:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:18 --> Total execution time: 0.0901
DEBUG - 2022-08-15 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:42 --> Total execution time: 0.0918
DEBUG - 2022-08-15 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:44 --> Total execution time: 0.0974
DEBUG - 2022-08-15 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:47 --> Total execution time: 0.0723
DEBUG - 2022-08-15 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:47 --> Total execution time: 0.0462
DEBUG - 2022-08-15 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:54 --> Total execution time: 0.0755
DEBUG - 2022-08-15 07:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:03:58 --> Total execution time: 0.0834
DEBUG - 2022-08-15 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:04:00 --> Total execution time: 0.1057
DEBUG - 2022-08-15 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:04:00 --> Total execution time: 0.1353
DEBUG - 2022-08-15 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:04:02 --> Total execution time: 0.1271
DEBUG - 2022-08-15 07:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:04:09 --> Total execution time: 0.0785
DEBUG - 2022-08-15 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:04:17 --> Total execution time: 0.0889
DEBUG - 2022-08-15 07:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:34:25 --> Total execution time: 0.0812
DEBUG - 2022-08-15 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:34:27 --> Total execution time: 0.0828
DEBUG - 2022-08-15 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:34:28 --> Total execution time: 0.0775
DEBUG - 2022-08-15 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:06:04 --> Total execution time: 1.7665
DEBUG - 2022-08-15 07:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:36:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:06:28 --> Total execution time: 0.0803
DEBUG - 2022-08-15 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:06:37 --> Total execution time: 0.0939
DEBUG - 2022-08-15 07:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:06:39 --> Total execution time: 0.2619
DEBUG - 2022-08-15 07:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:06:46 --> Total execution time: 0.0867
DEBUG - 2022-08-15 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:08:29 --> Total execution time: 0.0865
DEBUG - 2022-08-15 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:08:35 --> Total execution time: 0.1200
DEBUG - 2022-08-15 07:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:08:42 --> Total execution time: 0.0963
DEBUG - 2022-08-15 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:08:49 --> Total execution time: 0.2628
DEBUG - 2022-08-15 07:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:08:50 --> Total execution time: 0.2064
DEBUG - 2022-08-15 07:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:09:00 --> Total execution time: 0.0834
DEBUG - 2022-08-15 07:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:09:11 --> Total execution time: 0.0567
DEBUG - 2022-08-15 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:39:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:09:34 --> Total execution time: 0.1202
DEBUG - 2022-08-15 07:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:39:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:09:51 --> Total execution time: 0.0599
DEBUG - 2022-08-15 07:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:40:47 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 07:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:41:06 --> Total execution time: 0.0692
DEBUG - 2022-08-15 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:41:09 --> Total execution time: 0.0964
DEBUG - 2022-08-15 07:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:41:09 --> Total execution time: 0.1880
DEBUG - 2022-08-15 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:42:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:12:59 --> Total execution time: 0.0540
DEBUG - 2022-08-15 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:13:00 --> Total execution time: 0.0491
DEBUG - 2022-08-15 07:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:13:01 --> Total execution time: 0.0926
DEBUG - 2022-08-15 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:13:18 --> Total execution time: 0.0478
DEBUG - 2022-08-15 07:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:13:20 --> Total execution time: 0.1083
DEBUG - 2022-08-15 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:13:58 --> Total execution time: 0.0787
DEBUG - 2022-08-15 07:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:14:07 --> Total execution time: 0.0820
DEBUG - 2022-08-15 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:14:08 --> Total execution time: 0.0810
DEBUG - 2022-08-15 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:14:10 --> Total execution time: 0.0855
DEBUG - 2022-08-15 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:14:28 --> Total execution time: 0.2177
DEBUG - 2022-08-15 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:14:39 --> Total execution time: 0.0805
DEBUG - 2022-08-15 07:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:44:46 --> Total execution time: 0.0890
DEBUG - 2022-08-15 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:15:52 --> Total execution time: 0.2324
DEBUG - 2022-08-15 07:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:16:10 --> Total execution time: 0.1925
DEBUG - 2022-08-15 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:11 --> Total execution time: 0.0505
DEBUG - 2022-08-15 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:16:11 --> Total execution time: 0.0480
DEBUG - 2022-08-15 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:13 --> Total execution time: 0.0834
DEBUG - 2022-08-15 07:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:13 --> Total execution time: 0.1449
DEBUG - 2022-08-15 07:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:14 --> Total execution time: 0.1130
DEBUG - 2022-08-15 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:16:37 --> Total execution time: 0.0867
DEBUG - 2022-08-15 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:16:39 --> Total execution time: 0.0850
DEBUG - 2022-08-15 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:16:41 --> Total execution time: 0.1126
DEBUG - 2022-08-15 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:17:15 --> Total execution time: 0.0858
DEBUG - 2022-08-15 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:17:21 --> Total execution time: 0.0866
DEBUG - 2022-08-15 07:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:48:09 --> Total execution time: 0.0829
DEBUG - 2022-08-15 07:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:48:38 --> Total execution time: 0.0915
DEBUG - 2022-08-15 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:06 --> Total execution time: 0.1141
DEBUG - 2022-08-15 07:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:18 --> Total execution time: 0.1241
DEBUG - 2022-08-15 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:51:22 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-08-15 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:51:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:24 --> Total execution time: 0.1052
DEBUG - 2022-08-15 07:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:26 --> Total execution time: 0.1057
DEBUG - 2022-08-15 07:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 07:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:35 --> Total execution time: 0.1181
DEBUG - 2022-08-15 07:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:45 --> Total execution time: 0.1065
DEBUG - 2022-08-15 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:51 --> Total execution time: 0.1044
DEBUG - 2022-08-15 07:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:21:58 --> Total execution time: 0.1046
DEBUG - 2022-08-15 07:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:22:07 --> Total execution time: 0.0827
DEBUG - 2022-08-15 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:52:44 --> 404 Page Not Found: Designer-bag-bingo-new-choices-fundraiser/index
DEBUG - 2022-08-15 07:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:23:08 --> Total execution time: 0.0820
DEBUG - 2022-08-15 07:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:23:08 --> Total execution time: 0.0933
DEBUG - 2022-08-15 07:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:24:06 --> Total execution time: 0.0830
DEBUG - 2022-08-15 07:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:24:15 --> Total execution time: 0.0901
DEBUG - 2022-08-15 07:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:24:16 --> Total execution time: 0.0975
DEBUG - 2022-08-15 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:24:40 --> Total execution time: 0.1793
DEBUG - 2022-08-15 07:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:55:10 --> 404 Page Not Found: User/pan-kyc
DEBUG - 2022-08-15 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:25:13 --> Total execution time: 0.0851
DEBUG - 2022-08-15 07:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:25:20 --> Total execution time: 0.0921
DEBUG - 2022-08-15 07:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:55:44 --> 404 Page Not Found: User/pan-kyc
DEBUG - 2022-08-15 07:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:55:47 --> 404 Page Not Found: User/pan-kyc
DEBUG - 2022-08-15 07:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:55:50 --> 404 Page Not Found: User/pan-kyc
DEBUG - 2022-08-15 07:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:25:56 --> Total execution time: 0.0849
DEBUG - 2022-08-15 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:25:57 --> Total execution time: 0.0820
DEBUG - 2022-08-15 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:26:09 --> Total execution time: 0.2130
DEBUG - 2022-08-15 07:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:26:09 --> Total execution time: 0.0849
DEBUG - 2022-08-15 07:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:26:10 --> Total execution time: 0.0899
DEBUG - 2022-08-15 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:26:21 --> Total execution time: 0.0826
DEBUG - 2022-08-15 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:56:32 --> 404 Page Not Found: User/pan-kyc
DEBUG - 2022-08-15 07:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 07:56:34 --> 404 Page Not Found: User/pan-kyc
DEBUG - 2022-08-15 07:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:26:39 --> Total execution time: 0.0843
DEBUG - 2022-08-15 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:26:41 --> Total execution time: 0.0858
DEBUG - 2022-08-15 07:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:27:31 --> Total execution time: 0.0550
DEBUG - 2022-08-15 07:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:27:38 --> Total execution time: 0.0782
DEBUG - 2022-08-15 07:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:27:44 --> Total execution time: 0.1107
DEBUG - 2022-08-15 07:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:27:45 --> Total execution time: 0.0828
DEBUG - 2022-08-15 07:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:27:52 --> Total execution time: 0.0840
DEBUG - 2022-08-15 07:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:28:01 --> Total execution time: 0.0817
DEBUG - 2022-08-15 07:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:01 --> Total execution time: 0.1732
DEBUG - 2022-08-15 07:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:01 --> Total execution time: 0.2865
DEBUG - 2022-08-15 07:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:01 --> Total execution time: 0.3525
DEBUG - 2022-08-15 07:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:10 --> Total execution time: 0.1045
DEBUG - 2022-08-15 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:15 --> Total execution time: 0.1413
DEBUG - 2022-08-15 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:16 --> Total execution time: 0.1160
DEBUG - 2022-08-15 07:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:18 --> Total execution time: 0.0759
DEBUG - 2022-08-15 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:25 --> Total execution time: 0.1015
DEBUG - 2022-08-15 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:26 --> Total execution time: 0.1040
DEBUG - 2022-08-15 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:26 --> Total execution time: 0.0802
DEBUG - 2022-08-15 07:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:33 --> Total execution time: 0.0754
DEBUG - 2022-08-15 07:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 07:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:35 --> Total execution time: 0.0750
DEBUG - 2022-08-15 07:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:37 --> Total execution time: 0.0962
DEBUG - 2022-08-15 07:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:42 --> Total execution time: 0.0749
DEBUG - 2022-08-15 07:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:28:52 --> Total execution time: 0.1114
DEBUG - 2022-08-15 07:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:00 --> Total execution time: 0.1038
DEBUG - 2022-08-15 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:05 --> Total execution time: 0.0776
DEBUG - 2022-08-15 07:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:08 --> Total execution time: 0.0793
DEBUG - 2022-08-15 07:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:08 --> Total execution time: 0.0838
DEBUG - 2022-08-15 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:09 --> Total execution time: 0.0799
DEBUG - 2022-08-15 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:09 --> Total execution time: 0.0812
DEBUG - 2022-08-15 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:09 --> Total execution time: 0.0769
DEBUG - 2022-08-15 07:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:19 --> Total execution time: 0.0815
DEBUG - 2022-08-15 07:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 07:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 07:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:22 --> Total execution time: 0.0795
DEBUG - 2022-08-15 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:02 --> Total execution time: 0.0631
DEBUG - 2022-08-15 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:00:43 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:43 --> Total execution time: 0.0988
DEBUG - 2022-08-15 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:48 --> Total execution time: 0.0533
DEBUG - 2022-08-15 08:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:56 --> Total execution time: 0.0923
DEBUG - 2022-08-15 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:31:15 --> Total execution time: 0.1061
DEBUG - 2022-08-15 08:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:01:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:31:53 --> Total execution time: 0.1007
DEBUG - 2022-08-15 08:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:31:58 --> Total execution time: 0.0813
DEBUG - 2022-08-15 08:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:32:05 --> Total execution time: 0.0851
DEBUG - 2022-08-15 08:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:32:18 --> Total execution time: 0.0935
DEBUG - 2022-08-15 08:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:32:25 --> Total execution time: 0.1011
DEBUG - 2022-08-15 08:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:32:29 --> Total execution time: 0.0840
DEBUG - 2022-08-15 08:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:38 --> Total execution time: 0.0731
DEBUG - 2022-08-15 08:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:49 --> Total execution time: 0.0703
DEBUG - 2022-08-15 08:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:54 --> Total execution time: 0.0706
DEBUG - 2022-08-15 08:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:02:57 --> Total execution time: 0.0712
DEBUG - 2022-08-15 08:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:03:03 --> Total execution time: 0.0771
DEBUG - 2022-08-15 08:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:03:06 --> Total execution time: 0.1170
DEBUG - 2022-08-15 08:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:03:09 --> Total execution time: 0.0849
DEBUG - 2022-08-15 08:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:03:11 --> Total execution time: 0.1032
DEBUG - 2022-08-15 08:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:36:07 --> Total execution time: 0.2805
DEBUG - 2022-08-15 08:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:36:13 --> Total execution time: 0.0833
DEBUG - 2022-08-15 08:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:36:27 --> Total execution time: 0.0864
DEBUG - 2022-08-15 08:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:06:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:36:49 --> Total execution time: 0.2629
DEBUG - 2022-08-15 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:07:58 --> Total execution time: 0.0924
DEBUG - 2022-08-15 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:08:01 --> Total execution time: 0.0775
DEBUG - 2022-08-15 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:08:01 --> Total execution time: 0.0740
DEBUG - 2022-08-15 08:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:09:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:39:12 --> Total execution time: 0.0810
DEBUG - 2022-08-15 08:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:46:33 --> Total execution time: 0.3513
DEBUG - 2022-08-15 08:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:47:00 --> Total execution time: 0.0760
DEBUG - 2022-08-15 08:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:47:09 --> Total execution time: 0.0931
DEBUG - 2022-08-15 08:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:47:12 --> Total execution time: 0.1202
DEBUG - 2022-08-15 08:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:47:19 --> Total execution time: 0.0736
DEBUG - 2022-08-15 08:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:47:22 --> Total execution time: 0.0743
DEBUG - 2022-08-15 08:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:47:26 --> Total execution time: 0.2670
DEBUG - 2022-08-15 08:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:18:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:48:34 --> Total execution time: 0.2067
DEBUG - 2022-08-15 08:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:48:38 --> Total execution time: 0.0728
DEBUG - 2022-08-15 08:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:49:01 --> Total execution time: 0.0864
DEBUG - 2022-08-15 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:49:11 --> Total execution time: 0.0823
DEBUG - 2022-08-15 08:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 08:19:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 08:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:49:20 --> Total execution time: 0.0838
DEBUG - 2022-08-15 08:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 08:19:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:49:27 --> Total execution time: 0.0918
DEBUG - 2022-08-15 08:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:49:37 --> Total execution time: 0.0854
DEBUG - 2022-08-15 08:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 08:19:54 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 08:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:20:39 --> Total execution time: 0.0881
DEBUG - 2022-08-15 08:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:20:44 --> Total execution time: 0.1702
DEBUG - 2022-08-15 08:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:50:47 --> Total execution time: 0.0772
DEBUG - 2022-08-15 08:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:50:52 --> Total execution time: 0.0777
DEBUG - 2022-08-15 08:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:51:31 --> Total execution time: 0.0972
DEBUG - 2022-08-15 08:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:22:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:52:08 --> Total execution time: 0.0512
DEBUG - 2022-08-15 08:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:52:25 --> Total execution time: 0.0908
DEBUG - 2022-08-15 08:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:52:42 --> Total execution time: 0.1086
DEBUG - 2022-08-15 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:52:51 --> Total execution time: 0.0786
DEBUG - 2022-08-15 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:22:51 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:52:51 --> Total execution time: 0.0518
DEBUG - 2022-08-15 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 08:22:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:53:00 --> Total execution time: 0.0822
DEBUG - 2022-08-15 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:53:01 --> Total execution time: 0.0815
DEBUG - 2022-08-15 08:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:44 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:53:45 --> Total execution time: 0.2147
DEBUG - 2022-08-15 08:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:53:48 --> Total execution time: 0.0900
DEBUG - 2022-08-15 08:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:53:50 --> Total execution time: 0.0861
DEBUG - 2022-08-15 08:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:53:51 --> Total execution time: 0.1148
DEBUG - 2022-08-15 08:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:04 --> Total execution time: 0.0853
DEBUG - 2022-08-15 08:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 08:24:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 08:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:08 --> Total execution time: 0.1032
DEBUG - 2022-08-15 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:10 --> Total execution time: 0.0845
DEBUG - 2022-08-15 08:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:16 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:16 --> Total execution time: 0.0567
DEBUG - 2022-08-15 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:19 --> Total execution time: 0.0836
DEBUG - 2022-08-15 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:33 --> Total execution time: 0.0850
DEBUG - 2022-08-15 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:46 --> Total execution time: 0.0799
DEBUG - 2022-08-15 08:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:48 --> Total execution time: 0.0705
DEBUG - 2022-08-15 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:51 --> Total execution time: 0.0754
DEBUG - 2022-08-15 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:52 --> Total execution time: 0.0724
DEBUG - 2022-08-15 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:53 --> Total execution time: 0.0762
DEBUG - 2022-08-15 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:54 --> Total execution time: 0.0720
DEBUG - 2022-08-15 08:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:54:59 --> Total execution time: 0.0774
DEBUG - 2022-08-15 08:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:02 --> Total execution time: 0.0740
DEBUG - 2022-08-15 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:02 --> Total execution time: 0.0811
DEBUG - 2022-08-15 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:02 --> Total execution time: 0.0729
DEBUG - 2022-08-15 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:09 --> Total execution time: 0.0808
DEBUG - 2022-08-15 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:11 --> Total execution time: 0.0819
DEBUG - 2022-08-15 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:11 --> Total execution time: 0.0809
DEBUG - 2022-08-15 08:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:12 --> Total execution time: 0.0733
DEBUG - 2022-08-15 08:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:12 --> Total execution time: 0.0714
DEBUG - 2022-08-15 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:15 --> Total execution time: 0.0788
DEBUG - 2022-08-15 08:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:17 --> Total execution time: 0.0777
DEBUG - 2022-08-15 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:19 --> Total execution time: 0.0818
DEBUG - 2022-08-15 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:21 --> Total execution time: 0.0806
DEBUG - 2022-08-15 08:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:22 --> Total execution time: 0.0760
DEBUG - 2022-08-15 08:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:31 --> Total execution time: 0.0844
DEBUG - 2022-08-15 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:33 --> Total execution time: 0.0511
DEBUG - 2022-08-15 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:34 --> Total execution time: 0.0793
DEBUG - 2022-08-15 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:34 --> Total execution time: 0.0902
DEBUG - 2022-08-15 08:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:37 --> Total execution time: 0.0864
DEBUG - 2022-08-15 08:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:37 --> Total execution time: 0.1715
DEBUG - 2022-08-15 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:42 --> Total execution time: 0.0768
DEBUG - 2022-08-15 08:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:45 --> Total execution time: 0.0920
DEBUG - 2022-08-15 08:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:46 --> Total execution time: 0.0774
DEBUG - 2022-08-15 08:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:55:53 --> Total execution time: 0.0843
DEBUG - 2022-08-15 08:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:56:05 --> Total execution time: 0.0798
DEBUG - 2022-08-15 08:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:56:13 --> Total execution time: 0.0839
DEBUG - 2022-08-15 08:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:56:24 --> Total execution time: 0.0902
DEBUG - 2022-08-15 08:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:56:27 --> Total execution time: 0.1122
DEBUG - 2022-08-15 08:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:56:32 --> Total execution time: 0.0796
DEBUG - 2022-08-15 08:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:26:40 --> Total execution time: 0.0785
DEBUG - 2022-08-15 08:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:26:58 --> Total execution time: 0.0872
DEBUG - 2022-08-15 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:57:01 --> Total execution time: 0.0598
DEBUG - 2022-08-15 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:57:02 --> Total execution time: 0.0905
DEBUG - 2022-08-15 08:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:16 --> Total execution time: 0.0752
DEBUG - 2022-08-15 08:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:19 --> Total execution time: 0.0766
DEBUG - 2022-08-15 08:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:23 --> Total execution time: 0.0761
DEBUG - 2022-08-15 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:44 --> Total execution time: 0.0774
DEBUG - 2022-08-15 08:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:49 --> Total execution time: 0.0760
DEBUG - 2022-08-15 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:53 --> Total execution time: 0.0776
DEBUG - 2022-08-15 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:27:54 --> Total execution time: 0.0758
DEBUG - 2022-08-15 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:27:56 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:57:56 --> Total execution time: 0.0838
DEBUG - 2022-08-15 08:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:58:13 --> Total execution time: 2.3147
DEBUG - 2022-08-15 08:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:28:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:58:19 --> Total execution time: 0.0976
DEBUG - 2022-08-15 08:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:29:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:59:26 --> Total execution time: 0.0569
DEBUG - 2022-08-15 08:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:59:52 --> Total execution time: 0.0487
DEBUG - 2022-08-15 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:00:16 --> Total execution time: 0.0767
DEBUG - 2022-08-15 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:30:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:00:53 --> Total execution time: 0.0605
DEBUG - 2022-08-15 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:30:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:00:55 --> Total execution time: 0.2116
DEBUG - 2022-08-15 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:00 --> Total execution time: 0.0770
DEBUG - 2022-08-15 08:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:31:21 --> Total execution time: 0.0489
DEBUG - 2022-08-15 08:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:24 --> Total execution time: 0.0834
DEBUG - 2022-08-15 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:29 --> Total execution time: 0.0848
DEBUG - 2022-08-15 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:41 --> Total execution time: 0.0831
DEBUG - 2022-08-15 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:46 --> Total execution time: 0.0828
DEBUG - 2022-08-15 08:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:47 --> Total execution time: 0.0944
DEBUG - 2022-08-15 08:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:53 --> Total execution time: 0.0805
DEBUG - 2022-08-15 08:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:01:54 --> Total execution time: 0.1054
DEBUG - 2022-08-15 08:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:02:15 --> Total execution time: 0.1034
DEBUG - 2022-08-15 08:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:02:25 --> Total execution time: 0.0839
DEBUG - 2022-08-15 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:02:26 --> Total execution time: 0.0883
DEBUG - 2022-08-15 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:32:32 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:02:32 --> Total execution time: 0.0490
DEBUG - 2022-08-15 08:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:02:45 --> Total execution time: 0.0496
DEBUG - 2022-08-15 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:02 --> Total execution time: 0.1057
DEBUG - 2022-08-15 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:05 --> Total execution time: 0.0753
DEBUG - 2022-08-15 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:10 --> Total execution time: 0.0899
DEBUG - 2022-08-15 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:13 --> Total execution time: 0.0826
DEBUG - 2022-08-15 08:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:20 --> Total execution time: 0.0870
DEBUG - 2022-08-15 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:27 --> Total execution time: 0.0814
DEBUG - 2022-08-15 08:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:31 --> Total execution time: 0.0900
DEBUG - 2022-08-15 08:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:32 --> Total execution time: 0.0873
DEBUG - 2022-08-15 08:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:36 --> Total execution time: 0.0849
DEBUG - 2022-08-15 08:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:41 --> Total execution time: 0.0867
DEBUG - 2022-08-15 08:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:03:47 --> Total execution time: 0.0710
DEBUG - 2022-08-15 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:01 --> Total execution time: 0.0934
DEBUG - 2022-08-15 08:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:05 --> Total execution time: 0.0754
DEBUG - 2022-08-15 08:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:26 --> Total execution time: 0.1085
DEBUG - 2022-08-15 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:27 --> Total execution time: 0.0768
DEBUG - 2022-08-15 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:31 --> Total execution time: 0.0751
DEBUG - 2022-08-15 08:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:36 --> Total execution time: 0.0778
DEBUG - 2022-08-15 08:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:40 --> Total execution time: 0.1389
DEBUG - 2022-08-15 08:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:04:41 --> Total execution time: 0.0774
DEBUG - 2022-08-15 08:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:05:00 --> Total execution time: 0.0763
DEBUG - 2022-08-15 08:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:05:00 --> Total execution time: 0.0782
DEBUG - 2022-08-15 08:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:08:43 --> Total execution time: 0.1050
DEBUG - 2022-08-15 08:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:11:36 --> Total execution time: 0.1299
DEBUG - 2022-08-15 08:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:42:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:12:54 --> Total execution time: 0.2052
DEBUG - 2022-08-15 08:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:12:59 --> Total execution time: 0.0804
DEBUG - 2022-08-15 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:13:23 --> Total execution time: 0.0884
DEBUG - 2022-08-15 08:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:13:39 --> Total execution time: 0.0817
DEBUG - 2022-08-15 08:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:13:46 --> Total execution time: 0.0806
DEBUG - 2022-08-15 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:13:50 --> Total execution time: 0.0857
DEBUG - 2022-08-15 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:13:54 --> Total execution time: 0.0861
DEBUG - 2022-08-15 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:13:59 --> Total execution time: 0.0724
DEBUG - 2022-08-15 08:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:14:02 --> Total execution time: 0.1019
DEBUG - 2022-08-15 08:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:14:05 --> Total execution time: 0.0827
DEBUG - 2022-08-15 08:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:14:07 --> Total execution time: 0.0752
DEBUG - 2022-08-15 08:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:14:09 --> Total execution time: 0.0709
DEBUG - 2022-08-15 08:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:14:46 --> Total execution time: 0.2297
DEBUG - 2022-08-15 08:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:14:58 --> Total execution time: 0.1092
DEBUG - 2022-08-15 08:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:47:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:17:18 --> Total execution time: 0.0697
DEBUG - 2022-08-15 08:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:47:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:17:20 --> Total execution time: 0.0516
DEBUG - 2022-08-15 08:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:17:46 --> Total execution time: 0.0523
DEBUG - 2022-08-15 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:18:16 --> Total execution time: 0.0848
DEBUG - 2022-08-15 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:48:32 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:18:32 --> Total execution time: 0.0520
DEBUG - 2022-08-15 08:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:19:07 --> Total execution time: 0.0888
DEBUG - 2022-08-15 08:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:49:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:19:08 --> Total execution time: 0.0769
DEBUG - 2022-08-15 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:19:08 --> Total execution time: 0.0562
DEBUG - 2022-08-15 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:20:30 --> Total execution time: 0.0705
DEBUG - 2022-08-15 08:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:20:37 --> Total execution time: 0.0788
DEBUG - 2022-08-15 08:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:20:38 --> Total execution time: 0.0762
DEBUG - 2022-08-15 08:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:20:52 --> Total execution time: 0.0816
DEBUG - 2022-08-15 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:02 --> Total execution time: 0.0893
DEBUG - 2022-08-15 08:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:21 --> Total execution time: 0.2698
DEBUG - 2022-08-15 08:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:24 --> Total execution time: 0.0873
DEBUG - 2022-08-15 08:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:42 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:43 --> Total execution time: 0.2077
DEBUG - 2022-08-15 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:46 --> Total execution time: 0.0784
DEBUG - 2022-08-15 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:50 --> Total execution time: 0.0856
DEBUG - 2022-08-15 08:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:21:54 --> Total execution time: 0.0936
DEBUG - 2022-08-15 08:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:08 --> Total execution time: 0.0810
DEBUG - 2022-08-15 08:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:09 --> Total execution time: 0.0906
DEBUG - 2022-08-15 08:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:16 --> Total execution time: 0.0962
DEBUG - 2022-08-15 08:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:19 --> Total execution time: 0.0849
DEBUG - 2022-08-15 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:26 --> Total execution time: 0.0809
DEBUG - 2022-08-15 08:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:29 --> Total execution time: 0.0815
DEBUG - 2022-08-15 08:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:52:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:22:50 --> Total execution time: 0.0517
DEBUG - 2022-08-15 08:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:24:11 --> Total execution time: 0.0983
DEBUG - 2022-08-15 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:54:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 08:54:43 --> 404 Page Not Found: Teacher/harry-j-bryant
DEBUG - 2022-08-15 08:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:56:22 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:26:22 --> Total execution time: 0.0569
DEBUG - 2022-08-15 08:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:56:22 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:26:22 --> Total execution time: 0.0517
DEBUG - 2022-08-15 08:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:56:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:26:59 --> Total execution time: 0.0591
DEBUG - 2022-08-15 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:59:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:29:18 --> Total execution time: 0.1208
DEBUG - 2022-08-15 08:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:29:25 --> Total execution time: 0.0796
DEBUG - 2022-08-15 08:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 08:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 08:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 08:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:29:33 --> Total execution time: 0.0823
DEBUG - 2022-08-15 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:02 --> Total execution time: 0.0555
DEBUG - 2022-08-15 09:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:19 --> Total execution time: 0.1174
DEBUG - 2022-08-15 09:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:34 --> Total execution time: 0.0834
DEBUG - 2022-08-15 09:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:45 --> Total execution time: 0.0827
DEBUG - 2022-08-15 09:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:47 --> Total execution time: 0.0857
DEBUG - 2022-08-15 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:49 --> Total execution time: 0.2577
DEBUG - 2022-08-15 09:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:30:52 --> Total execution time: 0.0882
DEBUG - 2022-08-15 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:54 --> Total execution time: 0.1004
DEBUG - 2022-08-15 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:56 --> Total execution time: 0.0898
DEBUG - 2022-08-15 09:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:00:57 --> Total execution time: 0.0759
DEBUG - 2022-08-15 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:01 --> Total execution time: 0.0908
DEBUG - 2022-08-15 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:01 --> Total execution time: 0.1280
DEBUG - 2022-08-15 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:07 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:07 --> Total execution time: 0.0980
DEBUG - 2022-08-15 09:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:12 --> Total execution time: 0.0769
DEBUG - 2022-08-15 09:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:14 --> Total execution time: 0.2034
DEBUG - 2022-08-15 09:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:18 --> Total execution time: 0.0770
DEBUG - 2022-08-15 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:41 --> Total execution time: 0.0770
DEBUG - 2022-08-15 09:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:31:41 --> Total execution time: 0.0927
DEBUG - 2022-08-15 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:01 --> Total execution time: 0.0840
DEBUG - 2022-08-15 09:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:11 --> Total execution time: 0.1063
DEBUG - 2022-08-15 09:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:20 --> Total execution time: 0.1233
DEBUG - 2022-08-15 09:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:21 --> Total execution time: 0.0790
DEBUG - 2022-08-15 09:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:24 --> Total execution time: 0.0817
DEBUG - 2022-08-15 09:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:28 --> Total execution time: 0.0863
DEBUG - 2022-08-15 09:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:28 --> Total execution time: 0.0865
DEBUG - 2022-08-15 09:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:32 --> Total execution time: 0.0878
DEBUG - 2022-08-15 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:44 --> Total execution time: 0.0895
DEBUG - 2022-08-15 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:44 --> Total execution time: 0.0795
DEBUG - 2022-08-15 09:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:02:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:32:45 --> Total execution time: 0.0735
DEBUG - 2022-08-15 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:03:16 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:33:16 --> Total execution time: 0.0807
DEBUG - 2022-08-15 09:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:33:21 --> Total execution time: 0.1116
DEBUG - 2022-08-15 09:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:34:52 --> Total execution time: 0.0855
DEBUG - 2022-08-15 09:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:34:58 --> Total execution time: 0.1006
DEBUG - 2022-08-15 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:35:01 --> Total execution time: 0.0880
DEBUG - 2022-08-15 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:35:11 --> Total execution time: 0.1111
DEBUG - 2022-08-15 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:35:16 --> Total execution time: 0.0800
DEBUG - 2022-08-15 09:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:35:19 --> Total execution time: 0.0821
DEBUG - 2022-08-15 09:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:36:22 --> Total execution time: 0.0826
DEBUG - 2022-08-15 09:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:36:55 --> Total execution time: 0.0963
DEBUG - 2022-08-15 09:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:04 --> Total execution time: 0.0850
DEBUG - 2022-08-15 09:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:09 --> Total execution time: 0.0848
DEBUG - 2022-08-15 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:19 --> Total execution time: 0.0794
DEBUG - 2022-08-15 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:22 --> Total execution time: 0.0774
DEBUG - 2022-08-15 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:25 --> Total execution time: 0.0971
DEBUG - 2022-08-15 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:25 --> Total execution time: 0.0787
DEBUG - 2022-08-15 09:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:37:28 --> Total execution time: 0.0821
DEBUG - 2022-08-15 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:38:39 --> Total execution time: 0.0814
DEBUG - 2022-08-15 09:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:38:42 --> Total execution time: 0.0879
DEBUG - 2022-08-15 09:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:38:43 --> Total execution time: 0.0766
DEBUG - 2022-08-15 09:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:38:44 --> Total execution time: 0.0876
DEBUG - 2022-08-15 09:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:08:58 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:38:58 --> Total execution time: 0.1039
DEBUG - 2022-08-15 09:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:39:02 --> Total execution time: 0.0726
DEBUG - 2022-08-15 09:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:39:56 --> Total execution time: 0.0759
DEBUG - 2022-08-15 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:12:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:42:49 --> Total execution time: 0.1363
DEBUG - 2022-08-15 09:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:42:55 --> Total execution time: 0.0769
DEBUG - 2022-08-15 09:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:05 --> Total execution time: 0.0526
DEBUG - 2022-08-15 09:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:10 --> Total execution time: 0.0495
DEBUG - 2022-08-15 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:11 --> Total execution time: 0.0714
DEBUG - 2022-08-15 09:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:19 --> Total execution time: 0.0575
DEBUG - 2022-08-15 09:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:22 --> Total execution time: 0.0788
DEBUG - 2022-08-15 09:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:27 --> Total execution time: 0.0815
DEBUG - 2022-08-15 09:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:32 --> Total execution time: 0.0821
DEBUG - 2022-08-15 09:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:37 --> Total execution time: 0.0966
DEBUG - 2022-08-15 09:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:38 --> Total execution time: 0.1390
DEBUG - 2022-08-15 09:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:44 --> Total execution time: 0.0923
DEBUG - 2022-08-15 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:45 --> Total execution time: 0.0710
DEBUG - 2022-08-15 09:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:49 --> Total execution time: 0.0799
DEBUG - 2022-08-15 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:56 --> Total execution time: 0.0529
DEBUG - 2022-08-15 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:44:57 --> Total execution time: 0.2155
DEBUG - 2022-08-15 09:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:58 --> Total execution time: 0.0767
DEBUG - 2022-08-15 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:14:59 --> Total execution time: 0.0812
DEBUG - 2022-08-15 09:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:04 --> Total execution time: 0.0849
DEBUG - 2022-08-15 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:06 --> Total execution time: 0.0795
DEBUG - 2022-08-15 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:11 --> Total execution time: 0.0836
DEBUG - 2022-08-15 09:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:15 --> Total execution time: 0.0497
DEBUG - 2022-08-15 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:28 --> Total execution time: 0.0847
DEBUG - 2022-08-15 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:28 --> Total execution time: 0.0790
DEBUG - 2022-08-15 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:29 --> Total execution time: 0.0863
DEBUG - 2022-08-15 09:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:33 --> Total execution time: 0.0773
DEBUG - 2022-08-15 09:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:45 --> Total execution time: 0.1326
DEBUG - 2022-08-15 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:47 --> Total execution time: 0.0801
DEBUG - 2022-08-15 09:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:50 --> Total execution time: 0.0853
DEBUG - 2022-08-15 09:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:15:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:45:54 --> Total execution time: 0.0807
DEBUG - 2022-08-15 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:46:08 --> Total execution time: 0.0870
DEBUG - 2022-08-15 09:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:46:13 --> Total execution time: 0.0852
DEBUG - 2022-08-15 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:46:23 --> Total execution time: 0.0836
DEBUG - 2022-08-15 09:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:46:26 --> Total execution time: 0.0862
DEBUG - 2022-08-15 09:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:46:31 --> Total execution time: 0.0825
DEBUG - 2022-08-15 09:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:16:58 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:46:58 --> Total execution time: 0.0689
DEBUG - 2022-08-15 09:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:47:03 --> Total execution time: 0.0764
DEBUG - 2022-08-15 09:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:47:19 --> Total execution time: 0.0744
DEBUG - 2022-08-15 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:47:44 --> Total execution time: 0.0840
DEBUG - 2022-08-15 09:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:47:55 --> Total execution time: 0.0829
DEBUG - 2022-08-15 09:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:48:02 --> Total execution time: 0.0868
DEBUG - 2022-08-15 09:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:48:10 --> Total execution time: 0.0917
DEBUG - 2022-08-15 09:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:21:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:51:27 --> Total execution time: 0.1036
DEBUG - 2022-08-15 09:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:51:32 --> Total execution time: 0.0791
DEBUG - 2022-08-15 09:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 09:21:42 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-15 09:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:52:06 --> Total execution time: 0.0915
DEBUG - 2022-08-15 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:52:38 --> Total execution time: 0.0825
DEBUG - 2022-08-15 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:52:44 --> Total execution time: 0.0912
DEBUG - 2022-08-15 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:52:50 --> Total execution time: 0.0959
DEBUG - 2022-08-15 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:52:53 --> Total execution time: 0.0894
DEBUG - 2022-08-15 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:22:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:52:54 --> Total execution time: 0.0527
DEBUG - 2022-08-15 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:59:02 --> Total execution time: 0.1310
DEBUG - 2022-08-15 09:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:59:04 --> Total execution time: 0.0787
DEBUG - 2022-08-15 09:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:27 --> Total execution time: 0.0573
DEBUG - 2022-08-15 09:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:29 --> Total execution time: 0.0597
DEBUG - 2022-08-15 09:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:30 --> Total execution time: 0.0513
DEBUG - 2022-08-15 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:41 --> Total execution time: 0.0910
DEBUG - 2022-08-15 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:52 --> Total execution time: 0.0830
DEBUG - 2022-08-15 09:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 09:30:58 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 09:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:01 --> Total execution time: 0.0914
DEBUG - 2022-08-15 09:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:31:46 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:46 --> Total execution time: 0.0569
DEBUG - 2022-08-15 09:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:51 --> Total execution time: 0.2066
DEBUG - 2022-08-15 09:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:33:16 --> Total execution time: 0.0788
DEBUG - 2022-08-15 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:33:54 --> Total execution time: 0.0766
DEBUG - 2022-08-15 09:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:35:07 --> Total execution time: 0.0718
DEBUG - 2022-08-15 09:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:35:19 --> Total execution time: 0.0790
DEBUG - 2022-08-15 09:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:35:21 --> Total execution time: 0.0784
DEBUG - 2022-08-15 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:35:51 --> Total execution time: 0.0757
DEBUG - 2022-08-15 09:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:07:53 --> Total execution time: 0.1294
DEBUG - 2022-08-15 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:10:29 --> Total execution time: 0.1020
DEBUG - 2022-08-15 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:10:42 --> Total execution time: 0.0969
DEBUG - 2022-08-15 09:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:10:49 --> Total execution time: 0.0856
DEBUG - 2022-08-15 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:10:56 --> Total execution time: 0.0655
DEBUG - 2022-08-15 09:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:10:56 --> Total execution time: 0.0512
DEBUG - 2022-08-15 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:02 --> Total execution time: 0.0858
DEBUG - 2022-08-15 09:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:13 --> Total execution time: 0.0870
DEBUG - 2022-08-15 09:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:18 --> Total execution time: 0.0884
DEBUG - 2022-08-15 09:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:30 --> Total execution time: 0.1111
DEBUG - 2022-08-15 09:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:44 --> Total execution time: 0.0925
DEBUG - 2022-08-15 09:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:46 --> Total execution time: 0.1220
DEBUG - 2022-08-15 09:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:11:51 --> Total execution time: 0.1090
DEBUG - 2022-08-15 09:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:12:05 --> Total execution time: 0.0507
DEBUG - 2022-08-15 09:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:13:41 --> Total execution time: 0.0895
DEBUG - 2022-08-15 09:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:13:49 --> Total execution time: 0.0771
DEBUG - 2022-08-15 09:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 09:44:20 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 09:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:15:40 --> Total execution time: 0.0906
DEBUG - 2022-08-15 09:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:15:41 --> Total execution time: 0.1263
DEBUG - 2022-08-15 09:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:15:42 --> Total execution time: 0.0945
DEBUG - 2022-08-15 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:15:52 --> Total execution time: 0.0780
DEBUG - 2022-08-15 09:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:15:55 --> Total execution time: 0.0871
DEBUG - 2022-08-15 09:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:15:55 --> Total execution time: 0.0881
DEBUG - 2022-08-15 09:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:16:05 --> Total execution time: 0.0840
DEBUG - 2022-08-15 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:16:27 --> Total execution time: 0.0521
DEBUG - 2022-08-15 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:16:34 --> Total execution time: 0.2119
DEBUG - 2022-08-15 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:16:53 --> Total execution time: 0.0823
DEBUG - 2022-08-15 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:17:18 --> Total execution time: 0.1072
DEBUG - 2022-08-15 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:17:40 --> Total execution time: 0.0794
DEBUG - 2022-08-15 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:47:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:17:49 --> Total execution time: 0.0610
DEBUG - 2022-08-15 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:17:49 --> Total execution time: 0.0791
DEBUG - 2022-08-15 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:17:58 --> Total execution time: 0.0850
DEBUG - 2022-08-15 09:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:18:07 --> Total execution time: 0.0837
DEBUG - 2022-08-15 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:18:38 --> Total execution time: 0.1451
DEBUG - 2022-08-15 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:18:54 --> Total execution time: 0.1083
DEBUG - 2022-08-15 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:48:59 --> Total execution time: 0.0546
DEBUG - 2022-08-15 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:49:01 --> Total execution time: 0.0920
DEBUG - 2022-08-15 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:49:03 --> Total execution time: 0.0793
DEBUG - 2022-08-15 09:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:19:08 --> Total execution time: 0.1102
DEBUG - 2022-08-15 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:49:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:19:29 --> Total execution time: 0.0520
DEBUG - 2022-08-15 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:41 --> Total execution time: 0.1180
DEBUG - 2022-08-15 09:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:43 --> Total execution time: 0.1510
DEBUG - 2022-08-15 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:51:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:21:05 --> Total execution time: 0.0523
DEBUG - 2022-08-15 09:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:21:59 --> Total execution time: 0.0861
DEBUG - 2022-08-15 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:08 --> Total execution time: 0.0604
DEBUG - 2022-08-15 09:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:09 --> Total execution time: 0.0789
DEBUG - 2022-08-15 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:15 --> Total execution time: 0.0841
DEBUG - 2022-08-15 09:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:23 --> Total execution time: 0.2166
DEBUG - 2022-08-15 09:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:23 --> Total execution time: 0.0560
DEBUG - 2022-08-15 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:31 --> Total execution time: 0.0873
DEBUG - 2022-08-15 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:32 --> Total execution time: 0.0811
DEBUG - 2022-08-15 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:53 --> Total execution time: 0.0775
DEBUG - 2022-08-15 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:52:56 --> Total execution time: 0.0822
DEBUG - 2022-08-15 09:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:52:56 --> Total execution time: 0.1510
DEBUG - 2022-08-15 09:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:52:56 --> Total execution time: 0.2139
DEBUG - 2022-08-15 09:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:22:58 --> Total execution time: 0.0818
DEBUG - 2022-08-15 09:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:53:01 --> Total execution time: 0.0998
DEBUG - 2022-08-15 09:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:53:02 --> Total execution time: 0.1064
DEBUG - 2022-08-15 09:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:23:05 --> Total execution time: 0.1094
DEBUG - 2022-08-15 09:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:23:11 --> Total execution time: 0.0777
DEBUG - 2022-08-15 09:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:23:11 --> Total execution time: 0.0845
DEBUG - 2022-08-15 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:23:18 --> Total execution time: 0.1054
DEBUG - 2022-08-15 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:23:26 --> Total execution time: 0.0798
DEBUG - 2022-08-15 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:24:00 --> Total execution time: 0.0781
DEBUG - 2022-08-15 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:55:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:25:02 --> Total execution time: 0.0560
DEBUG - 2022-08-15 09:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:26:20 --> Total execution time: 0.0866
DEBUG - 2022-08-15 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:26:25 --> Total execution time: 0.0783
DEBUG - 2022-08-15 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:26:28 --> Total execution time: 0.0782
DEBUG - 2022-08-15 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:26:36 --> Total execution time: 0.0778
DEBUG - 2022-08-15 09:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:26:50 --> Total execution time: 0.0846
DEBUG - 2022-08-15 09:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:27:11 --> Total execution time: 0.0515
DEBUG - 2022-08-15 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:57:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:27:47 --> Total execution time: 0.0631
DEBUG - 2022-08-15 09:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:27:54 --> Total execution time: 0.0765
DEBUG - 2022-08-15 09:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:28:03 --> Total execution time: 0.0791
DEBUG - 2022-08-15 09:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:28:24 --> Total execution time: 0.0770
DEBUG - 2022-08-15 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:28:34 --> Total execution time: 0.1108
DEBUG - 2022-08-15 09:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:28:45 --> Total execution time: 0.1312
DEBUG - 2022-08-15 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:59:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:20 --> Total execution time: 0.0508
DEBUG - 2022-08-15 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:59:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 09:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:21 --> Total execution time: 0.0620
DEBUG - 2022-08-15 09:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:28 --> Total execution time: 0.0531
DEBUG - 2022-08-15 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:36 --> Total execution time: 0.0798
DEBUG - 2022-08-15 09:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 09:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 09:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:50 --> Total execution time: 0.1065
DEBUG - 2022-08-15 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:30:02 --> Total execution time: 0.0525
DEBUG - 2022-08-15 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:35:03 --> Total execution time: 0.3203
DEBUG - 2022-08-15 10:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:35:23 --> Total execution time: 0.1206
DEBUG - 2022-08-15 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:06:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:36:10 --> Total execution time: 0.0590
DEBUG - 2022-08-15 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:06:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:36:10 --> Total execution time: 0.0554
DEBUG - 2022-08-15 10:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:37:39 --> Total execution time: 0.0613
DEBUG - 2022-08-15 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:37:51 --> Total execution time: 0.0805
DEBUG - 2022-08-15 10:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:37:57 --> Total execution time: 0.0849
DEBUG - 2022-08-15 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:37:58 --> Total execution time: 0.0774
DEBUG - 2022-08-15 10:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:37:59 --> Total execution time: 0.2102
DEBUG - 2022-08-15 10:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:38:00 --> Total execution time: 0.0790
DEBUG - 2022-08-15 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:38:02 --> Total execution time: 0.0808
DEBUG - 2022-08-15 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:38:03 --> Total execution time: 0.0776
DEBUG - 2022-08-15 10:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:38:09 --> Total execution time: 0.0858
DEBUG - 2022-08-15 10:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:38:25 --> Total execution time: 0.0780
DEBUG - 2022-08-15 10:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:11:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 10:11:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:13:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:43:55 --> Total execution time: 0.0992
DEBUG - 2022-08-15 10:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:45:24 --> Total execution time: 0.2158
DEBUG - 2022-08-15 10:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:45:32 --> Total execution time: 0.0869
DEBUG - 2022-08-15 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:15:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:45:34 --> Total execution time: 0.0532
DEBUG - 2022-08-15 10:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:45:39 --> Total execution time: 0.0834
DEBUG - 2022-08-15 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:45:45 --> Total execution time: 0.0620
DEBUG - 2022-08-15 10:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:45:50 --> Total execution time: 0.0838
DEBUG - 2022-08-15 10:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:46:33 --> Total execution time: 0.1188
DEBUG - 2022-08-15 10:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:04 --> Total execution time: 0.0893
DEBUG - 2022-08-15 10:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:05 --> Total execution time: 0.1068
DEBUG - 2022-08-15 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:27 --> Total execution time: 0.1024
DEBUG - 2022-08-15 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:47:28 --> Total execution time: 0.1087
DEBUG - 2022-08-15 10:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:28 --> Total execution time: 0.1311
DEBUG - 2022-08-15 10:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:30 --> Total execution time: 0.1085
DEBUG - 2022-08-15 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:33 --> Total execution time: 0.0818
DEBUG - 2022-08-15 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:40 --> Total execution time: 0.0800
DEBUG - 2022-08-15 10:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:47 --> Total execution time: 0.0870
DEBUG - 2022-08-15 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:55 --> Total execution time: 0.0845
DEBUG - 2022-08-15 10:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:55 --> Total execution time: 0.0782
DEBUG - 2022-08-15 10:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:47:55 --> Total execution time: 0.0776
DEBUG - 2022-08-15 10:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:48:02 --> Total execution time: 0.0716
DEBUG - 2022-08-15 10:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:48:05 --> Total execution time: 0.0766
DEBUG - 2022-08-15 10:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:48:40 --> Total execution time: 0.0786
DEBUG - 2022-08-15 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:19:35 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:49:35 --> Total execution time: 0.0550
DEBUG - 2022-08-15 10:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:50:09 --> Total execution time: 0.0616
DEBUG - 2022-08-15 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:25:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:55:54 --> Total execution time: 0.1051
DEBUG - 2022-08-15 10:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:25:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:55:54 --> Total execution time: 0.0528
DEBUG - 2022-08-15 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:25:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:55:57 --> Total execution time: 0.0521
DEBUG - 2022-08-15 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:25:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:55:57 --> Total execution time: 0.0544
DEBUG - 2022-08-15 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:26:07 --> Total execution time: 0.2116
DEBUG - 2022-08-15 10:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:26:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:56:33 --> Total execution time: 0.0565
DEBUG - 2022-08-15 10:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:26:46 --> Total execution time: 0.0777
DEBUG - 2022-08-15 10:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:26:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:56:49 --> Total execution time: 0.0520
DEBUG - 2022-08-15 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:26:51 --> Total execution time: 0.0759
DEBUG - 2022-08-15 10:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:57:24 --> Total execution time: 0.0630
DEBUG - 2022-08-15 10:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:57:28 --> Total execution time: 0.0764
DEBUG - 2022-08-15 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:57:35 --> Total execution time: 0.0984
DEBUG - 2022-08-15 10:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:57:43 --> Total execution time: 0.1044
DEBUG - 2022-08-15 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:58:14 --> Total execution time: 0.0942
DEBUG - 2022-08-15 10:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:58:29 --> Total execution time: 0.2027
DEBUG - 2022-08-15 10:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:58:36 --> Total execution time: 0.2140
DEBUG - 2022-08-15 10:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:58:36 --> Total execution time: 0.1020
DEBUG - 2022-08-15 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:59:01 --> Total execution time: 0.1561
DEBUG - 2022-08-15 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:59:43 --> Total execution time: 0.0982
DEBUG - 2022-08-15 10:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:01:07 --> Total execution time: 0.1433
DEBUG - 2022-08-15 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:31:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:01:29 --> Total execution time: 0.0621
DEBUG - 2022-08-15 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:31:35 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:01:35 --> Total execution time: 0.0563
DEBUG - 2022-08-15 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:02:00 --> Total execution time: 0.0499
DEBUG - 2022-08-15 10:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:02:16 --> Total execution time: 0.0823
DEBUG - 2022-08-15 10:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:02:23 --> Total execution time: 0.1143
DEBUG - 2022-08-15 10:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:02:26 --> Total execution time: 0.1107
DEBUG - 2022-08-15 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:02:42 --> Total execution time: 0.0872
DEBUG - 2022-08-15 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:02 --> Total execution time: 0.1060
DEBUG - 2022-08-15 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:03 --> Total execution time: 0.1129
DEBUG - 2022-08-15 10:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:06 --> Total execution time: 0.1086
DEBUG - 2022-08-15 10:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:07 --> Total execution time: 0.1063
DEBUG - 2022-08-15 10:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:07 --> Total execution time: 0.0846
DEBUG - 2022-08-15 10:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:08 --> Total execution time: 0.1031
DEBUG - 2022-08-15 10:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:03:08 --> Total execution time: 0.0817
DEBUG - 2022-08-15 10:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:09 --> Total execution time: 0.2365
DEBUG - 2022-08-15 10:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:09 --> Total execution time: 0.1736
DEBUG - 2022-08-15 10:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:09 --> Total execution time: 0.0828
DEBUG - 2022-08-15 10:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:10 --> Total execution time: 0.1102
DEBUG - 2022-08-15 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:11 --> Total execution time: 0.0964
DEBUG - 2022-08-15 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:11 --> Total execution time: 0.1030
DEBUG - 2022-08-15 10:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:16 --> Total execution time: 0.0789
DEBUG - 2022-08-15 10:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:24 --> Total execution time: 0.1027
DEBUG - 2022-08-15 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:34 --> Total execution time: 0.0804
DEBUG - 2022-08-15 10:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:36 --> Total execution time: 0.0812
DEBUG - 2022-08-15 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:43 --> Total execution time: 0.2899
DEBUG - 2022-08-15 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:03:49 --> Total execution time: 0.0845
DEBUG - 2022-08-15 10:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:00 --> Total execution time: 0.0889
DEBUG - 2022-08-15 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:01 --> Total execution time: 0.1089
DEBUG - 2022-08-15 10:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:05 --> Total execution time: 0.0971
DEBUG - 2022-08-15 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:11 --> Total execution time: 0.1327
DEBUG - 2022-08-15 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:18 --> Total execution time: 0.0495
DEBUG - 2022-08-15 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:20 --> Total execution time: 0.0773
DEBUG - 2022-08-15 10:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:43 --> Total execution time: 0.0814
DEBUG - 2022-08-15 10:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:46 --> Total execution time: 0.1687
DEBUG - 2022-08-15 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:52 --> Total execution time: 0.1014
DEBUG - 2022-08-15 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:04:54 --> Total execution time: 0.1227
DEBUG - 2022-08-15 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:05:00 --> Total execution time: 0.0471
DEBUG - 2022-08-15 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:05:02 --> Total execution time: 0.0525
DEBUG - 2022-08-15 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:05:15 --> Total execution time: 0.0501
DEBUG - 2022-08-15 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:05:18 --> Total execution time: 0.0962
DEBUG - 2022-08-15 10:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:05:57 --> Total execution time: 0.0936
DEBUG - 2022-08-15 10:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:05:57 --> Total execution time: 0.1032
DEBUG - 2022-08-15 10:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:09 --> Total execution time: 0.1058
DEBUG - 2022-08-15 10:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:23 --> Total execution time: 0.0830
DEBUG - 2022-08-15 10:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:24 --> Total execution time: 0.0760
DEBUG - 2022-08-15 10:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:28 --> Total execution time: 0.0763
DEBUG - 2022-08-15 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:29 --> Total execution time: 0.1530
DEBUG - 2022-08-15 10:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:33 --> Total execution time: 0.0759
DEBUG - 2022-08-15 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:37 --> Total execution time: 0.1313
DEBUG - 2022-08-15 10:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:01 --> Total execution time: 0.1311
DEBUG - 2022-08-15 10:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:03 --> Total execution time: 0.0878
DEBUG - 2022-08-15 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:09 --> Total execution time: 0.2337
DEBUG - 2022-08-15 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:45 --> Total execution time: 0.1322
DEBUG - 2022-08-15 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:50 --> Total execution time: 0.1214
DEBUG - 2022-08-15 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:51 --> Total execution time: 0.1432
DEBUG - 2022-08-15 10:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:07:58 --> Total execution time: 0.1023
DEBUG - 2022-08-15 10:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:02 --> Total execution time: 0.0556
DEBUG - 2022-08-15 10:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:05 --> Total execution time: 0.0859
DEBUG - 2022-08-15 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:09 --> Total execution time: 0.2082
DEBUG - 2022-08-15 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:22 --> Total execution time: 0.0885
DEBUG - 2022-08-15 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:45 --> Total execution time: 0.1024
DEBUG - 2022-08-15 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:49 --> Total execution time: 0.0831
DEBUG - 2022-08-15 10:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:54 --> Total execution time: 0.0960
DEBUG - 2022-08-15 10:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:40:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:48 --> Total execution time: 0.0534
DEBUG - 2022-08-15 10:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:57 --> Total execution time: 0.0495
DEBUG - 2022-08-15 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:11:15 --> Total execution time: 0.0807
DEBUG - 2022-08-15 10:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:11:27 --> Total execution time: 0.1271
DEBUG - 2022-08-15 10:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:12:23 --> Total execution time: 0.0815
DEBUG - 2022-08-15 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:12:26 --> Total execution time: 0.0805
DEBUG - 2022-08-15 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:48:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:18:45 --> Total execution time: 0.1147
DEBUG - 2022-08-15 10:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:48:51 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:18:51 --> Total execution time: 0.0521
DEBUG - 2022-08-15 10:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:49:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:21 --> Total execution time: 0.0531
DEBUG - 2022-08-15 10:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:49:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:33 --> Total execution time: 0.0569
DEBUG - 2022-08-15 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:50:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:29 --> Total execution time: 0.1049
DEBUG - 2022-08-15 10:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:22:46 --> Total execution time: 0.3018
DEBUG - 2022-08-15 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 10:56:48 --> No URI present. Default controller set.
DEBUG - 2022-08-15 10:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 10:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:26:49 --> Total execution time: 0.1094
DEBUG - 2022-08-15 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:30:03 --> Total execution time: 0.1375
DEBUG - 2022-08-15 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:01:07 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:07 --> Total execution time: 0.0539
DEBUG - 2022-08-15 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:01:29 --> Total execution time: 0.0837
DEBUG - 2022-08-15 11:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:01:33 --> Total execution time: 0.0836
DEBUG - 2022-08-15 11:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:01:35 --> Total execution time: 0.0804
DEBUG - 2022-08-15 11:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:33:10 --> Total execution time: 2.5006
DEBUG - 2022-08-15 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 11:03:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:03:27 --> Total execution time: 0.0789
DEBUG - 2022-08-15 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:33:33 --> Total execution time: 0.0804
DEBUG - 2022-08-15 11:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:33:41 --> Total execution time: 0.1048
DEBUG - 2022-08-15 11:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:33:49 --> Total execution time: 0.1402
DEBUG - 2022-08-15 11:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:34:20 --> Total execution time: 0.0950
DEBUG - 2022-08-15 11:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:34:23 --> Total execution time: 0.0825
DEBUG - 2022-08-15 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:34:27 --> Total execution time: 0.0840
DEBUG - 2022-08-15 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:34:36 --> Total execution time: 0.0879
DEBUG - 2022-08-15 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:34:39 --> Total execution time: 0.2475
DEBUG - 2022-08-15 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:34:46 --> Total execution time: 0.1037
DEBUG - 2022-08-15 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:41 --> Total execution time: 0.1168
DEBUG - 2022-08-15 11:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:40:41 --> Total execution time: 0.0956
DEBUG - 2022-08-15 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:41:04 --> Total execution time: 0.0538
DEBUG - 2022-08-15 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:42:10 --> Total execution time: 0.1288
DEBUG - 2022-08-15 11:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:12:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:42:27 --> Total execution time: 0.0638
DEBUG - 2022-08-15 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:44:56 --> Total execution time: 0.1310
DEBUG - 2022-08-15 11:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:16:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:39 --> Total execution time: 0.2080
DEBUG - 2022-08-15 11:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:42 --> Total execution time: 0.0896
DEBUG - 2022-08-15 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:50 --> Total execution time: 0.0863
DEBUG - 2022-08-15 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:54 --> Total execution time: 0.0930
DEBUG - 2022-08-15 11:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:02 --> Total execution time: 0.0803
DEBUG - 2022-08-15 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:35 --> Total execution time: 0.0761
DEBUG - 2022-08-15 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:44 --> Total execution time: 0.0868
DEBUG - 2022-08-15 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:23:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:24 --> Total execution time: 0.1272
DEBUG - 2022-08-15 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:40 --> Total execution time: 0.0501
DEBUG - 2022-08-15 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:41 --> Total execution time: 0.0803
DEBUG - 2022-08-15 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:53 --> Total execution time: 0.1115
DEBUG - 2022-08-15 11:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:54:06 --> Total execution time: 0.1204
DEBUG - 2022-08-15 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:54:10 --> Total execution time: 0.0845
DEBUG - 2022-08-15 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:54:20 --> Total execution time: 0.0793
DEBUG - 2022-08-15 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:54:43 --> Total execution time: 0.0824
DEBUG - 2022-08-15 11:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:25:52 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:55:52 --> Total execution time: 0.0633
DEBUG - 2022-08-15 11:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:26:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:01 --> Total execution time: 0.0524
DEBUG - 2022-08-15 11:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:56 --> Total execution time: 0.2164
DEBUG - 2022-08-15 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 11:28:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 11:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:29:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:59:41 --> Total execution time: 0.0597
DEBUG - 2022-08-15 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:32:04 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:02:04 --> Total execution time: 0.0582
DEBUG - 2022-08-15 11:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:02:16 --> Total execution time: 0.0785
DEBUG - 2022-08-15 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:03:12 --> Total execution time: 0.0728
DEBUG - 2022-08-15 11:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:03:37 --> Total execution time: 0.0795
DEBUG - 2022-08-15 11:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 11:34:38 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:04:58 --> Total execution time: 0.0873
DEBUG - 2022-08-15 11:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:05:55 --> Total execution time: 0.0858
DEBUG - 2022-08-15 11:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:37:22 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:07:22 --> Total execution time: 0.2088
DEBUG - 2022-08-15 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:09:19 --> Total execution time: 0.2074
DEBUG - 2022-08-15 11:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:09:31 --> Total execution time: 0.0851
DEBUG - 2022-08-15 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:39:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:09:53 --> Total execution time: 0.0549
DEBUG - 2022-08-15 11:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:11:32 --> Total execution time: 0.0834
DEBUG - 2022-08-15 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:12:12 --> Total execution time: 0.0818
DEBUG - 2022-08-15 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:13:26 --> Total execution time: 0.0554
DEBUG - 2022-08-15 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:14:54 --> Total execution time: 0.0815
DEBUG - 2022-08-15 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:13 --> Total execution time: 0.1509
DEBUG - 2022-08-15 11:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:23 --> Total execution time: 0.1148
DEBUG - 2022-08-15 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:39 --> Total execution time: 0.0948
DEBUG - 2022-08-15 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:40 --> Total execution time: 0.0834
DEBUG - 2022-08-15 11:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:40 --> Total execution time: 0.0838
DEBUG - 2022-08-15 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:41 --> Total execution time: 0.0852
DEBUG - 2022-08-15 11:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:41 --> Total execution time: 0.1201
DEBUG - 2022-08-15 11:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:51 --> Total execution time: 0.1006
DEBUG - 2022-08-15 11:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:16:18 --> Total execution time: 0.0796
DEBUG - 2022-08-15 11:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:46:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 11:46:50 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:17:23 --> Total execution time: 0.2115
DEBUG - 2022-08-15 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:19:15 --> Total execution time: 0.0827
DEBUG - 2022-08-15 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:19:21 --> Total execution time: 0.1084
DEBUG - 2022-08-15 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:19:21 --> Total execution time: 0.1080
DEBUG - 2022-08-15 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:19:23 --> Total execution time: 0.0801
DEBUG - 2022-08-15 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:21:09 --> Total execution time: 0.0762
DEBUG - 2022-08-15 11:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:52:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 11:52:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 11:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:52:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 11:52:30 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-15 11:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:54:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:24:01 --> Total execution time: 0.0945
DEBUG - 2022-08-15 11:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:28:08 --> Total execution time: 0.2705
DEBUG - 2022-08-15 11:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:58:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 11:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:28:11 --> Total execution time: 0.0858
DEBUG - 2022-08-15 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 11:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 11:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:28:43 --> Total execution time: 0.2091
DEBUG - 2022-08-15 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:30:03 --> Total execution time: 0.0781
DEBUG - 2022-08-15 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:31:53 --> Total execution time: 0.2221
DEBUG - 2022-08-15 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:32:01 --> Total execution time: 0.0956
DEBUG - 2022-08-15 12:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:02:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:32:59 --> Total execution time: 0.0537
DEBUG - 2022-08-15 12:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:04:44 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:34:44 --> Total execution time: 0.0649
DEBUG - 2022-08-15 12:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:35:15 --> Total execution time: 0.0507
DEBUG - 2022-08-15 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:05:30 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:35:30 --> Total execution time: 0.0813
DEBUG - 2022-08-15 12:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:36 --> Total execution time: 0.0827
DEBUG - 2022-08-15 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:38 --> Total execution time: 0.0822
DEBUG - 2022-08-15 12:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:05:39 --> Total execution time: 0.0796
DEBUG - 2022-08-15 12:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:07:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:37:17 --> Total execution time: 0.0534
DEBUG - 2022-08-15 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:07:58 --> Total execution time: 0.0856
DEBUG - 2022-08-15 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:08:00 --> Total execution time: 0.0828
DEBUG - 2022-08-15 12:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:08:01 --> Total execution time: 0.1028
DEBUG - 2022-08-15 12:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:40:07 --> Total execution time: 2.3545
DEBUG - 2022-08-15 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:10:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:40:19 --> Total execution time: 0.0524
DEBUG - 2022-08-15 12:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 12:10:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:10:52 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:40:53 --> Total execution time: 0.0960
DEBUG - 2022-08-15 12:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:17 --> Total execution time: 0.0489
DEBUG - 2022-08-15 12:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:20 --> Total execution time: 0.0436
DEBUG - 2022-08-15 12:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:20 --> Total execution time: 0.0501
DEBUG - 2022-08-15 12:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:47 --> Total execution time: 0.0834
DEBUG - 2022-08-15 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:50 --> Total execution time: 0.0870
DEBUG - 2022-08-15 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:55 --> Total execution time: 0.1578
DEBUG - 2022-08-15 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:41:57 --> Total execution time: 0.0458
DEBUG - 2022-08-15 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:46:04 --> Total execution time: 0.0805
DEBUG - 2022-08-15 12:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:46:21 --> Total execution time: 0.0957
DEBUG - 2022-08-15 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:46:42 --> Total execution time: 0.0891
DEBUG - 2022-08-15 12:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:46:54 --> Total execution time: 0.0826
DEBUG - 2022-08-15 12:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:47:02 --> Total execution time: 0.0901
DEBUG - 2022-08-15 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:47:11 --> Total execution time: 0.0870
DEBUG - 2022-08-15 12:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:47:19 --> Total execution time: 0.0770
DEBUG - 2022-08-15 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:48:55 --> Total execution time: 0.0866
DEBUG - 2022-08-15 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:49:11 --> Total execution time: 0.0898
DEBUG - 2022-08-15 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:49:18 --> Total execution time: 0.0871
DEBUG - 2022-08-15 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:49:32 --> Total execution time: 0.0910
DEBUG - 2022-08-15 12:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:24:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:54:34 --> Total execution time: 0.1224
DEBUG - 2022-08-15 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:04:49 --> Total execution time: 0.0851
DEBUG - 2022-08-15 12:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:36:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:06:34 --> Total execution time: 0.0544
DEBUG - 2022-08-15 12:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:38:00 --> Total execution time: 0.0572
DEBUG - 2022-08-15 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:57 --> Total execution time: 0.0542
DEBUG - 2022-08-15 12:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 12:43:05 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-08-15 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:16:34 --> Total execution time: 0.0813
DEBUG - 2022-08-15 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:47:04 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:17:04 --> Total execution time: 0.0558
DEBUG - 2022-08-15 12:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:50:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:20:10 --> Total execution time: 0.1354
DEBUG - 2022-08-15 12:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:50:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:20:12 --> Total execution time: 0.0585
DEBUG - 2022-08-15 12:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 12:50:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 12:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:20:23 --> Total execution time: 0.0498
DEBUG - 2022-08-15 12:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:20:55 --> Total execution time: 0.1103
DEBUG - 2022-08-15 12:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:21:11 --> Total execution time: 0.1132
DEBUG - 2022-08-15 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:21:23 --> Total execution time: 0.0771
DEBUG - 2022-08-15 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:21:28 --> Total execution time: 0.0809
DEBUG - 2022-08-15 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:22:08 --> Total execution time: 0.0535
DEBUG - 2022-08-15 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:22:16 --> Total execution time: 0.0921
DEBUG - 2022-08-15 12:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:22:17 --> Total execution time: 0.1024
DEBUG - 2022-08-15 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:22:36 --> Total execution time: 0.0772
DEBUG - 2022-08-15 12:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:22:44 --> Total execution time: 0.0769
DEBUG - 2022-08-15 12:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:00 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:23:00 --> Total execution time: 0.0524
DEBUG - 2022-08-15 12:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:53:01 --> Total execution time: 0.0641
DEBUG - 2022-08-15 12:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:23:04 --> Total execution time: 0.0819
DEBUG - 2022-08-15 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:23:29 --> Total execution time: 0.0796
DEBUG - 2022-08-15 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:23:36 --> Total execution time: 0.0833
DEBUG - 2022-08-15 12:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:23:59 --> Total execution time: 0.0951
DEBUG - 2022-08-15 12:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:24:08 --> Total execution time: 0.1026
DEBUG - 2022-08-15 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:24:09 --> Total execution time: 0.0842
DEBUG - 2022-08-15 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:24:23 --> Total execution time: 0.1035
DEBUG - 2022-08-15 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:24:50 --> Total execution time: 0.0803
DEBUG - 2022-08-15 12:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:24:53 --> Total execution time: 0.1123
DEBUG - 2022-08-15 12:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:25:07 --> Total execution time: 0.1047
DEBUG - 2022-08-15 12:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:25:15 --> Total execution time: 0.0805
DEBUG - 2022-08-15 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:25:34 --> Total execution time: 0.0905
DEBUG - 2022-08-15 12:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:25:40 --> Total execution time: 0.2318
DEBUG - 2022-08-15 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:26:02 --> Total execution time: 0.0815
DEBUG - 2022-08-15 12:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:26:15 --> Total execution time: 0.1501
DEBUG - 2022-08-15 12:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:26:27 --> Total execution time: 0.1151
DEBUG - 2022-08-15 12:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:56:38 --> No URI present. Default controller set.
DEBUG - 2022-08-15 12:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:26:38 --> Total execution time: 0.1002
DEBUG - 2022-08-15 12:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:26:43 --> Total execution time: 0.0990
DEBUG - 2022-08-15 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 12:57:17 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-08-15 12:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:27:35 --> Total execution time: 0.0829
DEBUG - 2022-08-15 12:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:28:00 --> Total execution time: 0.1030
DEBUG - 2022-08-15 12:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:28:23 --> Total execution time: 0.0864
DEBUG - 2022-08-15 12:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:29:01 --> Total execution time: 0.1099
DEBUG - 2022-08-15 12:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:29:02 --> Total execution time: 0.2194
DEBUG - 2022-08-15 12:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 12:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:29:12 --> Total execution time: 0.0815
DEBUG - 2022-08-15 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:29:19 --> Total execution time: 0.0834
DEBUG - 2022-08-15 12:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:29:20 --> Total execution time: 0.0861
DEBUG - 2022-08-15 12:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 12:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 12:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:29:28 --> Total execution time: 0.0908
DEBUG - 2022-08-15 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:30:03 --> Total execution time: 0.0525
DEBUG - 2022-08-15 13:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:30:21 --> Total execution time: 0.0823
DEBUG - 2022-08-15 13:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:30:38 --> Total execution time: 0.0986
DEBUG - 2022-08-15 13:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:30:39 --> Total execution time: 0.1021
DEBUG - 2022-08-15 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:30:45 --> Total execution time: 0.0802
DEBUG - 2022-08-15 13:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:30:53 --> Total execution time: 0.0771
DEBUG - 2022-08-15 13:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:31:35 --> Total execution time: 0.0894
DEBUG - 2022-08-15 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:31:45 --> Total execution time: 0.0843
DEBUG - 2022-08-15 13:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:33:47 --> Total execution time: 0.1990
DEBUG - 2022-08-15 13:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:34:53 --> Total execution time: 0.2154
DEBUG - 2022-08-15 13:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:35:00 --> Total execution time: 0.1128
DEBUG - 2022-08-15 13:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:36:45 --> Total execution time: 0.1242
DEBUG - 2022-08-15 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:36:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-15 13:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:36:53 --> Total execution time: 0.1341
DEBUG - 2022-08-15 13:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:37:04 --> Total execution time: 0.0908
DEBUG - 2022-08-15 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:37:11 --> Total execution time: 0.1019
DEBUG - 2022-08-15 13:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:37:26 --> Total execution time: 0.1436
DEBUG - 2022-08-15 13:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:28 --> Total execution time: 0.0847
DEBUG - 2022-08-15 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:38 --> Total execution time: 0.1119
DEBUG - 2022-08-15 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:52 --> Total execution time: 0.0831
DEBUG - 2022-08-15 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:09:37 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:37 --> Total execution time: 0.0590
DEBUG - 2022-08-15 13:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:41:14 --> Total execution time: 0.2160
DEBUG - 2022-08-15 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:41:32 --> Total execution time: 0.0893
DEBUG - 2022-08-15 13:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:41:42 --> Total execution time: 0.1102
DEBUG - 2022-08-15 13:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:42:05 --> Total execution time: 0.0818
DEBUG - 2022-08-15 13:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:12:27 --> Total execution time: 0.0569
DEBUG - 2022-08-15 13:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:12:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:42:29 --> Total execution time: 0.0540
DEBUG - 2022-08-15 13:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:12:30 --> Total execution time: 0.0812
DEBUG - 2022-08-15 13:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:12:31 --> Total execution time: 0.0780
DEBUG - 2022-08-15 13:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:44:35 --> Total execution time: 0.2537
DEBUG - 2022-08-15 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:44:41 --> Total execution time: 0.0844
DEBUG - 2022-08-15 13:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:14:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:44:47 --> Total execution time: 0.0810
DEBUG - 2022-08-15 13:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:49 --> Total execution time: 0.0799
DEBUG - 2022-08-15 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:51 --> Total execution time: 0.0717
DEBUG - 2022-08-15 13:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:15:52 --> Total execution time: 0.0827
DEBUG - 2022-08-15 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:18:05 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:48:05 --> Total execution time: 0.1088
DEBUG - 2022-08-15 23:48:05 --> Total execution time: 0.1087
DEBUG - 2022-08-15 13:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:48:13 --> Total execution time: 0.0826
DEBUG - 2022-08-15 13:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:48:43 --> Total execution time: 0.1053
DEBUG - 2022-08-15 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:48:50 --> Total execution time: 0.0791
DEBUG - 2022-08-15 13:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:49:01 --> Total execution time: 0.4086
DEBUG - 2022-08-15 13:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:49:11 --> Total execution time: 0.1087
DEBUG - 2022-08-15 13:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:00 --> Total execution time: 0.0766
DEBUG - 2022-08-15 13:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:10 --> Total execution time: 0.0807
DEBUG - 2022-08-15 13:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:15 --> Total execution time: 0.0852
DEBUG - 2022-08-15 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:31 --> Total execution time: 0.0929
DEBUG - 2022-08-15 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:31 --> Total execution time: 0.0817
DEBUG - 2022-08-15 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:46 --> Total execution time: 0.0827
DEBUG - 2022-08-15 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 13:20:58 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-08-15 13:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:26:58 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:56:58 --> Total execution time: 0.1216
DEBUG - 2022-08-15 13:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:33 --> Total execution time: 0.2495
DEBUG - 2022-08-15 13:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:35 --> Total execution time: 0.0842
DEBUG - 2022-08-15 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:29:38 --> Total execution time: 0.0855
DEBUG - 2022-08-15 13:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:29:43 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:59:43 --> Total execution time: 0.0806
DEBUG - 2022-08-15 13:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:29:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:59:50 --> Total execution time: 0.0791
DEBUG - 2022-08-15 13:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:59:57 --> Total execution time: 0.0787
DEBUG - 2022-08-15 13:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:30:35 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:30:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:30:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 13:32:04 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-08-15 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:06 --> Total execution time: 0.0798
DEBUG - 2022-08-15 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 13:32:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-08-15 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:16 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:43 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:46 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:51 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:33:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:33 --> Total execution time: 0.0606
DEBUG - 2022-08-15 13:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:36 --> Total execution time: 0.0772
DEBUG - 2022-08-15 13:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:36 --> Total execution time: 0.0932
DEBUG - 2022-08-15 13:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:34:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:36:04 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 13:36:57 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:39:03 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:40:40 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:31 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:46:06 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:46:42 --> Total execution time: 0.0829
DEBUG - 2022-08-15 13:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:46:44 --> Total execution time: 0.0827
DEBUG - 2022-08-15 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:46:45 --> Total execution time: 0.0744
DEBUG - 2022-08-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:47:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:48:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 13:48:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 13:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 13:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 13:51:10 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 13:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 13:58:09 --> No URI present. Default controller set.
DEBUG - 2022-08-15 13:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 13:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:03:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:03:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:03:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:04:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:05:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:18:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:28:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 14:39:34 --> 404 Page Not Found: Event/index
DEBUG - 2022-08-15 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:42:59 --> No URI present. Default controller set.
DEBUG - 2022-08-15 14:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 14:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 14:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 14:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 15:01:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:16:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:16:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:17:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:33 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:36 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 15:23:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 15:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:24:32 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:26:50 --> Total execution time: 0.0831
DEBUG - 2022-08-15 15:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:26:58 --> Total execution time: 0.1369
DEBUG - 2022-08-15 15:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:30:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 15:41:24 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 15:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:42:25 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:45:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:49:04 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 15:52:18 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 15:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 15:52:34 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 15:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:52:38 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:19 --> No URI present. Default controller set.
DEBUG - 2022-08-15 15:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 15:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:24:24 --> No URI present. Default controller set.
DEBUG - 2022-08-15 16:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:40:01 --> No URI present. Default controller set.
DEBUG - 2022-08-15 16:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 16:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 16:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 17:17:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 17:17:57 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 17:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:34:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 17:34:53 --> 404 Page Not Found: Event/index
DEBUG - 2022-08-15 17:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:42:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 17:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 17:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 17:42:26 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 17:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 17:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 17:56:29 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:27:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 18:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 18:29:35 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 18:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:30:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 18:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 18:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 18:36:39 --> 404 Page Not Found: Wp-commentinphp/index
DEBUG - 2022-08-15 18:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 18:38:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 18:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 18:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:18:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 19:26:03 --> 404 Page Not Found: Course-category/development
DEBUG - 2022-08-15 19:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 19:46:40 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 19:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:46:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:54:50 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:55:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:55:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:55:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 19:55:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 19:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 19:55:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 19:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:55:41 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:55:45 --> No URI present. Default controller set.
DEBUG - 2022-08-15 19:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 19:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 19:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 19:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 19:56:52 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 20:01:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 20:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:01:42 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 20:01:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 20:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 20:08:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 20:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:08:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:30:05 --> Total execution time: 0.0615
DEBUG - 2022-08-15 20:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:36:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 20:39:25 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-15 20:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 20:39:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 20:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:39:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:40:36 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:40:52 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:44:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:55:51 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:55:52 --> No URI present. Default controller set.
DEBUG - 2022-08-15 20:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:56:45 --> Total execution time: 0.0538
DEBUG - 2022-08-15 20:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:56:47 --> Total execution time: 0.0837
DEBUG - 2022-08-15 20:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 20:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 20:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 20:56:47 --> Total execution time: 0.0781
DEBUG - 2022-08-15 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:20 --> Total execution time: 0.0800
DEBUG - 2022-08-15 21:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:22 --> Total execution time: 0.1040
DEBUG - 2022-08-15 21:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:23 --> Total execution time: 0.0843
DEBUG - 2022-08-15 21:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:32 --> Total execution time: 0.0827
DEBUG - 2022-08-15 21:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:08:56 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:09:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:12:27 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:12:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:12:37 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-15 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:12:38 --> 404 Page Not Found: Humanstxt/index
DEBUG - 2022-08-15 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:12:38 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-15 21:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:12:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:12:52 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:13:13 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:13:33 --> Total execution time: 0.0514
DEBUG - 2022-08-15 21:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:13:38 --> Total execution time: 0.0859
DEBUG - 2022-08-15 21:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:13:38 --> Total execution time: 0.0767
DEBUG - 2022-08-15 21:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:14:08 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:18:38 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:19:55 --> Total execution time: 0.0786
DEBUG - 2022-08-15 21:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:13 --> Total execution time: 0.0793
DEBUG - 2022-08-15 21:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:22 --> Total execution time: 0.0762
DEBUG - 2022-08-15 21:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:23 --> Total execution time: 0.0763
DEBUG - 2022-08-15 21:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:24 --> Total execution time: 0.0767
DEBUG - 2022-08-15 21:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:22:39 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:23:49 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:24:20 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:30:47 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:40:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:44:23 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:45:56 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:45:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:46:12 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:47:52 --> Total execution time: 0.0964
DEBUG - 2022-08-15 21:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:00 --> Total execution time: 0.0852
DEBUG - 2022-08-15 21:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:00 --> Total execution time: 0.1824
DEBUG - 2022-08-15 21:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:48:56 --> Total execution time: 0.0843
DEBUG - 2022-08-15 21:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:06 --> Total execution time: 0.0787
DEBUG - 2022-08-15 21:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:18 --> Total execution time: 0.0836
DEBUG - 2022-08-15 21:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:22 --> Total execution time: 0.0804
DEBUG - 2022-08-15 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:49:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 21:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:56:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 21:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:57:15 --> No URI present. Default controller set.
DEBUG - 2022-08-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 21:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 21:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 21:59:35 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:04:14 --> No URI present. Default controller set.
DEBUG - 2022-08-15 22:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:15:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 22:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:42 --> Total execution time: 0.0893
DEBUG - 2022-08-15 22:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:44 --> Total execution time: 0.1116
DEBUG - 2022-08-15 22:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:15:45 --> Total execution time: 0.0825
DEBUG - 2022-08-15 22:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 22:17:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 22:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 22:20:49 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-15 22:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:28:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 22:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 22:40:54 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-15 22:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 22:42:52 --> 404 Page Not Found: Reselling-course/index
DEBUG - 2022-08-15 22:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:44:21 --> No URI present. Default controller set.
DEBUG - 2022-08-15 22:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:45:02 --> No URI present. Default controller set.
DEBUG - 2022-08-15 22:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 22:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 22:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 22:53:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-15 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:02:57 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:03:56 --> Total execution time: 0.0888
DEBUG - 2022-08-15 23:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:03:58 --> Total execution time: 0.0786
DEBUG - 2022-08-15 23:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:03:58 --> Total execution time: 0.1068
DEBUG - 2022-08-15 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:04:09 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:09:17 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:09:18 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:13:28 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:27:53 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:36:11 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:38:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:49 --> Total execution time: 0.0787
DEBUG - 2022-08-15 23:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:51 --> Total execution time: 0.0811
DEBUG - 2022-08-15 23:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:51 --> Total execution time: 0.0914
DEBUG - 2022-08-15 23:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:39:56 --> Total execution time: 0.0864
DEBUG - 2022-08-15 23:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:40:03 --> Total execution time: 0.0840
DEBUG - 2022-08-15 23:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:40:06 --> Total execution time: 0.0869
DEBUG - 2022-08-15 23:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:47:34 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-15 23:50:36 --> 404 Page Not Found: Wp-configtxt/index
DEBUG - 2022-08-15 23:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:52:54 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:55:01 --> Total execution time: 0.1657
DEBUG - 2022-08-15 23:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:55:03 --> Total execution time: 0.0931
DEBUG - 2022-08-15 23:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:55:04 --> Total execution time: 0.1017
DEBUG - 2022-08-15 23:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:57:10 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:58:26 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-15 23:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-15 23:58:29 --> No URI present. Default controller set.
DEBUG - 2022-08-15 23:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-15 23:58:29 --> Encryption: Auto-configured driver 'openssl'.
