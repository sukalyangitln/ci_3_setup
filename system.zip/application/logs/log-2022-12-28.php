<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-28 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:07:54 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:37:54 --> Total execution time: 0.6137
DEBUG - 2022-12-28 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:08:28 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:38:28 --> Total execution time: 0.0479
DEBUG - 2022-12-28 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:08:31 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:38:31 --> Total execution time: 0.0471
DEBUG - 2022-12-28 14:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:09:08 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:39:08 --> Total execution time: 0.0635
DEBUG - 2022-12-28 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:09:28 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:39:28 --> Total execution time: 0.0696
DEBUG - 2022-12-28 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:10:44 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:40:44 --> Total execution time: 0.0471
DEBUG - 2022-12-28 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:11:22 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:41:22 --> Total execution time: 0.0527
DEBUG - 2022-12-28 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 14:11:28 --> Total execution time: 0.0831
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 14:12:02 --> Total execution time: 0.0508
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:11 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:42:11 --> Total execution time: 0.0569
DEBUG - 2022-12-28 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 14:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 14:12:25 --> Total execution time: 0.0561
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 14:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 14:12:54 --> Total execution time: 0.0435
DEBUG - 2022-12-28 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:12:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:12:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:12:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:12:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:43:12 --> Total execution time: 0.0451
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:13:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:44:00 --> Total execution time: 0.0619
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:44:02 --> Total execution time: 0.1048
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:44:02 --> Total execution time: 0.0653
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:14:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:14:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 14:14:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 14:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:16:08 --> No URI present. Default controller set.
DEBUG - 2022-12-28 14:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:46:08 --> Total execution time: 0.0700
DEBUG - 2022-12-28 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:09 --> Total execution time: 0.0605
DEBUG - 2022-12-28 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:14 --> Total execution time: 0.0515
DEBUG - 2022-12-28 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:15 --> Total execution time: 0.0703
DEBUG - 2022-12-28 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:21 --> Total execution time: 0.1196
DEBUG - 2022-12-28 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:23 --> Total execution time: 0.0904
DEBUG - 2022-12-28 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:25 --> Total execution time: 0.0598
DEBUG - 2022-12-28 14:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:48:27 --> Total execution time: 0.0846
DEBUG - 2022-12-28 14:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:18:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:49:02 --> Total execution time: 0.0524
DEBUG - 2022-12-28 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:19:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:49:07 --> Total execution time: 0.0775
DEBUG - 2022-12-28 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:19:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:49:13 --> Total execution time: 0.0548
DEBUG - 2022-12-28 14:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:19:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:49:29 --> Total execution time: 0.0763
DEBUG - 2022-12-28 14:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:19:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:50:21 --> Total execution time: 0.0550
DEBUG - 2022-12-28 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:20:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:50:26 --> Total execution time: 0.0537
DEBUG - 2022-12-28 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:20:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:50:46 --> Total execution time: 0.0481
DEBUG - 2022-12-28 14:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:50:54 --> Total execution time: 0.0505
DEBUG - 2022-12-28 14:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:50:57 --> Total execution time: 0.0466
DEBUG - 2022-12-28 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:51:06 --> Total execution time: 0.0477
DEBUG - 2022-12-28 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:51:33 --> Total execution time: 0.0611
DEBUG - 2022-12-28 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:21:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 14:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 14:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 18:51:34 --> Total execution time: 0.0629
DEBUG - 2022-12-28 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 14:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 14:21:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 20:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:37:41 --> No URI present. Default controller set.
DEBUG - 2022-12-28 20:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:37:45 --> No URI present. Default controller set.
DEBUG - 2022-12-28 20:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:37:58 --> No URI present. Default controller set.
DEBUG - 2022-12-28 20:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:02 --> No URI present. Default controller set.
DEBUG - 2022-12-28 20:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:39 --> No URI present. Default controller set.
DEBUG - 2022-12-28 20:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 20:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:39 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 20:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 20:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-28 20:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:38:53 --> Total execution time: 0.0654
DEBUG - 2022-12-28 20:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:54 --> UTF-8 Support Enabled
ERROR - 2022-12-28 20:38:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:38:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:56 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-28 20:38:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:38:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:40:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 20:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 20:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 20:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 20:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 20:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 20:56:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:02:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:02:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:03:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:04:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:07:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:07:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:07:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:09:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:09:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:11:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:11:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:11:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:16:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:17:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:37:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:37:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:39:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:40:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:45:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:46:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:46:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:54:59 --> UTF-8 Support Enabled
ERROR - 2022-12-28 21:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:57 --> UTF-8 Support Enabled
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:55:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:55:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 21:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 21:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 21:56:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 22:02:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:32 --> UTF-8 Support Enabled
ERROR - 2022-12-28 22:02:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 22:02:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 22:02:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-28 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:04:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:04:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:04:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:04:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:05:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:05:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:07:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:07:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:07:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:08:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:09:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:09:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:10:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:28:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:32:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:33:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:37:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:42:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:42:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:42:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:44:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:46:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 22:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 22:52:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 22:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 22:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 22:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 22:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:05:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:05:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:11:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:11:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:11:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:14:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:15:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:21:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:40:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:40:13 --> 404 Page Not Found: admin/Edit-campaign/index
DEBUG - 2022-12-28 23:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:40:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:50:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-28 23:52:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-28 23:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-28 23:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-28 23:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-28 23:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-28 23:55:24 --> Encryption: Auto-configured driver 'openssl'.
