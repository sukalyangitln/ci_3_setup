<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-30 00:10:36 --> Total execution time: 0.1046
DEBUG - 2022-05-30 00:11:01 --> Total execution time: 0.0771
DEBUG - 2022-05-30 00:11:04 --> Total execution time: 0.0624
DEBUG - 2022-05-30 00:11:06 --> Total execution time: 0.0296
DEBUG - 2022-05-30 00:11:18 --> Total execution time: 0.0305
DEBUG - 2022-05-30 00:11:21 --> Total execution time: 0.0359
DEBUG - 2022-05-30 00:13:29 --> Total execution time: 0.1143
DEBUG - 2022-05-30 00:13:29 --> Total execution time: 0.0252
DEBUG - 2022-05-30 00:14:03 --> Total execution time: 0.0648
DEBUG - 2022-05-30 00:14:30 --> Total execution time: 0.0580
DEBUG - 2022-05-30 00:14:30 --> Total execution time: 0.0502
DEBUG - 2022-05-30 00:14:55 --> Total execution time: 0.0303
DEBUG - 2022-05-30 00:17:25 --> Total execution time: 0.0291
DEBUG - 2022-05-30 00:17:30 --> Total execution time: 0.0667
DEBUG - 2022-05-30 00:17:42 --> Total execution time: 0.0316
DEBUG - 2022-05-30 00:17:52 --> Total execution time: 0.0209
DEBUG - 2022-05-30 00:17:59 --> Total execution time: 0.0242
DEBUG - 2022-05-30 00:18:06 --> Total execution time: 0.0339
DEBUG - 2022-05-30 00:18:14 --> Total execution time: 0.0257
DEBUG - 2022-05-30 00:18:53 --> Total execution time: 0.0282
DEBUG - 2022-05-30 00:19:18 --> Total execution time: 0.0263
DEBUG - 2022-05-30 00:19:26 --> Total execution time: 0.0258
DEBUG - 2022-05-30 00:22:16 --> Total execution time: 0.0419
DEBUG - 2022-05-30 00:22:32 --> Total execution time: 0.0231
DEBUG - 2022-05-30 00:22:43 --> Total execution time: 0.0296
DEBUG - 2022-05-30 00:22:44 --> Total execution time: 0.0203
DEBUG - 2022-05-30 00:22:50 --> Total execution time: 0.0292
DEBUG - 2022-05-30 00:22:51 --> Total execution time: 0.0204
DEBUG - 2022-05-30 00:22:55 --> Total execution time: 0.0469
DEBUG - 2022-05-30 00:23:08 --> Total execution time: 0.0301
DEBUG - 2022-05-30 00:25:11 --> Total execution time: 0.0680
DEBUG - 2022-05-30 00:26:00 --> Total execution time: 0.0532
DEBUG - 2022-05-30 00:26:23 --> Total execution time: 0.0380
DEBUG - 2022-05-30 00:26:25 --> Total execution time: 0.0443
DEBUG - 2022-05-30 00:26:40 --> Total execution time: 0.0675
DEBUG - 2022-05-30 00:26:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 00:26:55 --> Total execution time: 0.0689
DEBUG - 2022-05-30 00:27:02 --> Total execution time: 0.0705
DEBUG - 2022-05-30 00:27:14 --> Total execution time: 0.0604
DEBUG - 2022-05-30 00:27:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 00:27:35 --> Total execution time: 0.0648
DEBUG - 2022-05-30 00:27:42 --> Total execution time: 0.0655
DEBUG - 2022-05-30 00:27:59 --> Total execution time: 0.0534
DEBUG - 2022-05-30 00:28:11 --> Total execution time: 0.0591
DEBUG - 2022-05-30 00:28:37 --> Total execution time: 0.0242
DEBUG - 2022-05-30 00:30:02 --> Total execution time: 0.2192
DEBUG - 2022-05-30 00:31:23 --> Total execution time: 0.0296
DEBUG - 2022-05-30 00:38:45 --> Total execution time: 0.0744
DEBUG - 2022-05-30 00:39:02 --> Total execution time: 0.0236
DEBUG - 2022-05-30 00:39:46 --> Total execution time: 0.0303
DEBUG - 2022-05-30 00:39:55 --> Total execution time: 0.0285
DEBUG - 2022-05-30 00:40:06 --> Total execution time: 0.0335
DEBUG - 2022-05-30 00:40:56 --> Total execution time: 0.0566
DEBUG - 2022-05-30 00:41:29 --> Total execution time: 0.0215
DEBUG - 2022-05-30 00:41:57 --> Total execution time: 0.0179
DEBUG - 2022-05-30 00:43:04 --> Total execution time: 0.0228
DEBUG - 2022-05-30 00:45:05 --> Total execution time: 0.0303
DEBUG - 2022-05-30 00:46:58 --> Total execution time: 0.0392
DEBUG - 2022-05-30 00:46:59 --> Total execution time: 0.0274
DEBUG - 2022-05-30 00:47:13 --> Total execution time: 0.0503
DEBUG - 2022-05-30 00:47:38 --> Total execution time: 0.0404
DEBUG - 2022-05-30 00:54:48 --> Total execution time: 0.0370
DEBUG - 2022-05-30 00:56:14 --> Total execution time: 0.0699
DEBUG - 2022-05-30 00:56:14 --> Total execution time: 0.0308
DEBUG - 2022-05-30 00:56:28 --> Total execution time: 0.0309
DEBUG - 2022-05-30 00:56:48 --> Total execution time: 0.0276
DEBUG - 2022-05-30 00:57:04 --> Total execution time: 0.0587
DEBUG - 2022-05-30 00:59:50 --> Total execution time: 0.0414
DEBUG - 2022-05-30 01:00:00 --> Total execution time: 0.0335
DEBUG - 2022-05-30 01:00:04 --> Total execution time: 0.0443
DEBUG - 2022-05-30 01:00:18 --> Total execution time: 0.0347
DEBUG - 2022-05-30 01:03:10 --> Total execution time: 0.0978
DEBUG - 2022-05-30 01:03:19 --> Total execution time: 0.0320
DEBUG - 2022-05-30 01:03:38 --> Total execution time: 0.0491
DEBUG - 2022-05-30 01:03:45 --> Total execution time: 0.0364
DEBUG - 2022-05-30 01:06:00 --> Total execution time: 0.0311
DEBUG - 2022-05-30 01:06:47 --> Total execution time: 0.0212
DEBUG - 2022-05-30 01:09:01 --> Total execution time: 0.0411
DEBUG - 2022-05-30 01:11:47 --> Total execution time: 0.0660
DEBUG - 2022-05-30 01:12:21 --> Total execution time: 0.0532
DEBUG - 2022-05-30 01:12:36 --> Total execution time: 0.0596
DEBUG - 2022-05-30 01:12:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 01:12:54 --> Total execution time: 0.0617
DEBUG - 2022-05-30 01:14:05 --> Total execution time: 0.0287
DEBUG - 2022-05-30 01:17:58 --> Total execution time: 0.0266
DEBUG - 2022-05-30 01:18:24 --> Total execution time: 0.0318
DEBUG - 2022-05-30 01:19:23 --> Total execution time: 0.0288
DEBUG - 2022-05-30 01:19:32 --> Total execution time: 0.0231
DEBUG - 2022-05-30 01:20:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 01:20:43 --> Total execution time: 0.0283
DEBUG - 2022-05-30 01:20:55 --> Total execution time: 0.0202
DEBUG - 2022-05-30 01:21:18 --> Total execution time: 0.0318
DEBUG - 2022-05-30 01:21:31 --> Total execution time: 0.0311
DEBUG - 2022-05-30 01:21:42 --> Total execution time: 0.0353
DEBUG - 2022-05-30 01:25:32 --> Total execution time: 0.0712
DEBUG - 2022-05-30 01:29:17 --> Total execution time: 0.1180
DEBUG - 2022-05-30 01:29:26 --> Total execution time: 0.0305
DEBUG - 2022-05-30 01:29:30 --> Total execution time: 0.0431
DEBUG - 2022-05-30 01:29:41 --> Total execution time: 0.0251
DEBUG - 2022-05-30 01:29:48 --> Total execution time: 0.0240
DEBUG - 2022-05-30 01:30:02 --> Total execution time: 0.0663
DEBUG - 2022-05-30 01:33:53 --> Total execution time: 0.0791
DEBUG - 2022-05-30 01:38:38 --> Total execution time: 0.0787
DEBUG - 2022-05-30 01:43:00 --> Total execution time: 0.0673
DEBUG - 2022-05-30 01:43:45 --> Total execution time: 0.0264
DEBUG - 2022-05-30 01:54:03 --> Total execution time: 0.0973
DEBUG - 2022-05-30 01:57:17 --> Total execution time: 0.0443
DEBUG - 2022-05-30 01:58:45 --> Total execution time: 0.0302
DEBUG - 2022-05-30 01:58:57 --> Total execution time: 0.0363
DEBUG - 2022-05-30 01:59:50 --> Total execution time: 0.9579
DEBUG - 2022-05-30 02:00:04 --> Total execution time: 6.3834
DEBUG - 2022-05-30 02:01:40 --> Total execution time: 0.0203
DEBUG - 2022-05-30 02:08:59 --> Total execution time: 0.0824
DEBUG - 2022-05-30 02:14:29 --> Total execution time: 0.2224
DEBUG - 2022-05-30 02:23:11 --> Total execution time: 0.0778
DEBUG - 2022-05-30 02:27:10 --> Total execution time: 0.2075
DEBUG - 2022-05-30 02:27:11 --> Total execution time: 0.0512
DEBUG - 2022-05-30 02:27:12 --> Total execution time: 0.0702
DEBUG - 2022-05-30 02:27:13 --> Total execution time: 0.0702
DEBUG - 2022-05-30 02:27:14 --> Total execution time: 0.0666
DEBUG - 2022-05-30 02:27:15 --> Total execution time: 0.0682
DEBUG - 2022-05-30 02:30:02 --> Total execution time: 0.1046
DEBUG - 2022-05-30 02:48:35 --> Total execution time: 0.1352
DEBUG - 2022-05-30 02:48:35 --> Total execution time: 0.0649
DEBUG - 2022-05-30 02:48:43 --> Total execution time: 0.0645
DEBUG - 2022-05-30 02:48:52 --> Total execution time: 0.0464
DEBUG - 2022-05-30 02:49:08 --> Total execution time: 0.0301
DEBUG - 2022-05-30 02:49:15 --> Total execution time: 0.0308
DEBUG - 2022-05-30 02:49:25 --> Total execution time: 0.0308
DEBUG - 2022-05-30 02:49:47 --> Total execution time: 0.0381
DEBUG - 2022-05-30 02:49:48 --> Total execution time: 0.0269
DEBUG - 2022-05-30 02:49:49 --> Total execution time: 0.0266
DEBUG - 2022-05-30 02:49:50 --> Total execution time: 0.0309
DEBUG - 2022-05-30 03:30:04 --> Total execution time: 0.1530
DEBUG - 2022-05-30 03:36:10 --> Total execution time: 0.0941
DEBUG - 2022-05-30 03:36:36 --> Total execution time: 0.0269
DEBUG - 2022-05-30 04:30:03 --> Total execution time: 0.2428
DEBUG - 2022-05-30 04:44:29 --> Total execution time: 0.0320
DEBUG - 2022-05-30 04:45:36 --> Total execution time: 1.5243
DEBUG - 2022-05-30 05:30:03 --> Total execution time: 0.2570
DEBUG - 2022-05-30 06:01:46 --> Total execution time: 0.1514
DEBUG - 2022-05-30 06:02:00 --> Total execution time: 0.0201
DEBUG - 2022-05-30 06:02:25 --> Total execution time: 0.0177
DEBUG - 2022-05-30 06:09:35 --> Total execution time: 0.1054
DEBUG - 2022-05-30 06:22:15 --> Total execution time: 0.1041
DEBUG - 2022-05-30 06:22:22 --> Total execution time: 0.0280
DEBUG - 2022-05-30 06:22:33 --> Total execution time: 0.0541
DEBUG - 2022-05-30 06:22:43 --> Total execution time: 0.0459
DEBUG - 2022-05-30 06:22:51 --> Total execution time: 0.0358
DEBUG - 2022-05-30 06:24:14 --> Total execution time: 0.0451
DEBUG - 2022-05-30 06:24:58 --> Total execution time: 0.0257
DEBUG - 2022-05-30 06:28:14 --> Total execution time: 0.0689
DEBUG - 2022-05-30 06:28:28 --> Total execution time: 0.0598
DEBUG - 2022-05-30 06:28:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 06:28:51 --> Total execution time: 0.0559
DEBUG - 2022-05-30 06:30:02 --> Total execution time: 0.0653
DEBUG - 2022-05-30 06:30:13 --> Total execution time: 0.0691
DEBUG - 2022-05-30 06:30:39 --> Total execution time: 0.0574
DEBUG - 2022-05-30 06:30:46 --> Total execution time: 0.0965
DEBUG - 2022-05-30 06:30:52 --> Total execution time: 0.0409
DEBUG - 2022-05-30 06:31:31 --> Total execution time: 0.0491
DEBUG - 2022-05-30 06:31:38 --> Total execution time: 0.0502
DEBUG - 2022-05-30 06:31:42 --> Total execution time: 0.0404
DEBUG - 2022-05-30 06:31:56 --> Total execution time: 0.0685
DEBUG - 2022-05-30 06:32:10 --> Total execution time: 0.0235
DEBUG - 2022-05-30 06:32:13 --> Total execution time: 0.0256
DEBUG - 2022-05-30 06:32:22 --> Total execution time: 0.0251
DEBUG - 2022-05-30 06:32:36 --> Total execution time: 0.0262
DEBUG - 2022-05-30 06:32:47 --> Total execution time: 0.0390
DEBUG - 2022-05-30 06:32:51 --> Total execution time: 0.0356
DEBUG - 2022-05-30 06:32:56 --> Total execution time: 0.0275
DEBUG - 2022-05-30 06:32:59 --> Total execution time: 0.0306
DEBUG - 2022-05-30 06:33:08 --> Total execution time: 0.0292
DEBUG - 2022-05-30 06:33:12 --> Total execution time: 0.0289
DEBUG - 2022-05-30 06:33:33 --> Total execution time: 0.0525
DEBUG - 2022-05-30 06:33:34 --> Total execution time: 0.0644
DEBUG - 2022-05-30 06:33:38 --> Total execution time: 0.0395
DEBUG - 2022-05-30 06:33:41 --> Total execution time: 0.0337
DEBUG - 2022-05-30 06:33:42 --> Total execution time: 0.0548
DEBUG - 2022-05-30 06:33:46 --> Total execution time: 0.0547
DEBUG - 2022-05-30 06:33:50 --> Total execution time: 0.0636
DEBUG - 2022-05-30 06:33:55 --> Total execution time: 0.0650
DEBUG - 2022-05-30 06:33:58 --> Total execution time: 0.0631
DEBUG - 2022-05-30 06:47:22 --> Total execution time: 0.1064
DEBUG - 2022-05-30 06:58:19 --> Total execution time: 0.1010
DEBUG - 2022-05-30 06:58:20 --> Total execution time: 0.0175
DEBUG - 2022-05-30 06:58:47 --> Total execution time: 0.0286
DEBUG - 2022-05-30 06:59:14 --> Total execution time: 0.0228
DEBUG - 2022-05-30 07:01:14 --> Total execution time: 0.0237
DEBUG - 2022-05-30 07:07:21 --> Total execution time: 0.0721
DEBUG - 2022-05-30 07:07:26 --> Total execution time: 0.0337
DEBUG - 2022-05-30 07:07:49 --> Total execution time: 0.0567
DEBUG - 2022-05-30 07:08:02 --> Total execution time: 0.0546
DEBUG - 2022-05-30 07:08:51 --> Total execution time: 0.0222
DEBUG - 2022-05-30 07:08:54 --> Total execution time: 0.0260
DEBUG - 2022-05-30 07:09:08 --> Total execution time: 0.0266
DEBUG - 2022-05-30 07:09:20 --> Total execution time: 0.0875
DEBUG - 2022-05-30 07:09:30 --> Total execution time: 0.0374
DEBUG - 2022-05-30 07:09:42 --> Total execution time: 0.0384
DEBUG - 2022-05-30 07:09:51 --> Total execution time: 0.0307
DEBUG - 2022-05-30 07:09:55 --> Total execution time: 0.0307
DEBUG - 2022-05-30 07:10:02 --> Total execution time: 0.0522
DEBUG - 2022-05-30 07:10:17 --> Total execution time: 0.1190
DEBUG - 2022-05-30 07:10:27 --> Total execution time: 0.0315
DEBUG - 2022-05-30 07:10:53 --> Total execution time: 0.0238
DEBUG - 2022-05-30 07:11:09 --> Total execution time: 0.0226
DEBUG - 2022-05-30 07:11:14 --> Total execution time: 0.0778
DEBUG - 2022-05-30 07:11:35 --> Total execution time: 0.0278
DEBUG - 2022-05-30 07:12:21 --> Total execution time: 0.0254
DEBUG - 2022-05-30 07:12:27 --> Total execution time: 0.0274
DEBUG - 2022-05-30 07:12:35 --> Total execution time: 0.0561
DEBUG - 2022-05-30 07:12:39 --> Total execution time: 0.0183
DEBUG - 2022-05-30 07:14:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:14:05 --> Total execution time: 0.0370
DEBUG - 2022-05-30 07:14:16 --> Total execution time: 0.0421
DEBUG - 2022-05-30 07:14:17 --> Total execution time: 0.0366
DEBUG - 2022-05-30 07:14:21 --> Total execution time: 0.0188
DEBUG - 2022-05-30 07:14:21 --> Total execution time: 0.0179
DEBUG - 2022-05-30 07:14:23 --> Total execution time: 0.0178
DEBUG - 2022-05-30 07:14:23 --> Total execution time: 0.0177
DEBUG - 2022-05-30 07:14:24 --> Total execution time: 0.0178
DEBUG - 2022-05-30 07:14:26 --> Total execution time: 0.0411
DEBUG - 2022-05-30 07:14:38 --> Total execution time: 0.0319
DEBUG - 2022-05-30 07:14:50 --> Total execution time: 0.0557
DEBUG - 2022-05-30 07:15:10 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:15:13 --> Total execution time: 0.0615
DEBUG - 2022-05-30 07:15:52 --> Total execution time: 0.0274
DEBUG - 2022-05-30 07:15:55 --> Total execution time: 0.0187
DEBUG - 2022-05-30 07:16:10 --> Total execution time: 0.0248
DEBUG - 2022-05-30 07:16:35 --> Total execution time: 0.0308
DEBUG - 2022-05-30 07:16:35 --> Total execution time: 0.0254
DEBUG - 2022-05-30 07:16:37 --> Total execution time: 0.0307
DEBUG - 2022-05-30 07:16:41 --> Total execution time: 0.0481
DEBUG - 2022-05-30 07:16:42 --> Total execution time: 0.0292
DEBUG - 2022-05-30 07:18:18 --> Total execution time: 0.0203
DEBUG - 2022-05-30 07:18:57 --> Total execution time: 0.0334
DEBUG - 2022-05-30 07:19:08 --> Total execution time: 0.0247
DEBUG - 2022-05-30 07:19:48 --> Total execution time: 0.0612
DEBUG - 2022-05-30 07:19:51 --> Total execution time: 0.0399
DEBUG - 2022-05-30 07:19:55 --> Total execution time: 0.0387
DEBUG - 2022-05-30 07:20:03 --> Total execution time: 0.0298
DEBUG - 2022-05-30 07:20:06 --> Total execution time: 0.0418
DEBUG - 2022-05-30 07:20:15 --> Total execution time: 0.0323
DEBUG - 2022-05-30 07:20:18 --> Total execution time: 0.0282
DEBUG - 2022-05-30 07:20:24 --> Total execution time: 0.0230
DEBUG - 2022-05-30 07:20:30 --> Total execution time: 0.0303
DEBUG - 2022-05-30 07:20:53 --> Total execution time: 0.0270
DEBUG - 2022-05-30 07:21:12 --> Total execution time: 0.0231
DEBUG - 2022-05-30 07:21:55 --> Total execution time: 0.0423
DEBUG - 2022-05-30 07:23:23 --> Total execution time: 0.0206
DEBUG - 2022-05-30 07:23:56 --> Total execution time: 0.0228
DEBUG - 2022-05-30 07:24:07 --> Total execution time: 1.5486
DEBUG - 2022-05-30 07:24:12 --> Total execution time: 0.0265
DEBUG - 2022-05-30 07:24:37 --> Total execution time: 0.0424
DEBUG - 2022-05-30 07:24:52 --> Total execution time: 0.0468
DEBUG - 2022-05-30 07:24:55 --> Total execution time: 0.0275
DEBUG - 2022-05-30 07:25:10 --> Total execution time: 0.0276
DEBUG - 2022-05-30 07:25:14 --> Total execution time: 1.5118
DEBUG - 2022-05-30 07:26:22 --> Total execution time: 1.5044
DEBUG - 2022-05-30 07:26:32 --> Total execution time: 0.0250
DEBUG - 2022-05-30 07:26:42 --> Total execution time: 0.0242
DEBUG - 2022-05-30 07:26:58 --> Total execution time: 0.0230
DEBUG - 2022-05-30 07:27:24 --> Total execution time: 0.0615
DEBUG - 2022-05-30 07:27:42 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:27:50 --> Total execution time: 0.0272
DEBUG - 2022-05-30 07:27:59 --> Total execution time: 0.0424
DEBUG - 2022-05-30 07:29:33 --> Total execution time: 0.0444
DEBUG - 2022-05-30 07:29:40 --> Total execution time: 0.0479
DEBUG - 2022-05-30 07:30:03 --> Total execution time: 0.0310
DEBUG - 2022-05-30 07:30:33 --> Total execution time: 0.0274
DEBUG - 2022-05-30 07:30:44 --> Total execution time: 1.5026
DEBUG - 2022-05-30 07:32:36 --> Total execution time: 1.6084
DEBUG - 2022-05-30 07:32:54 --> Total execution time: 0.0576
DEBUG - 2022-05-30 07:32:59 --> Total execution time: 0.0224
DEBUG - 2022-05-30 07:33:04 --> Total execution time: 0.0261
DEBUG - 2022-05-30 07:33:18 --> Total execution time: 0.0299
DEBUG - 2022-05-30 07:33:24 --> Total execution time: 0.0444
DEBUG - 2022-05-30 07:33:28 --> Total execution time: 0.0263
DEBUG - 2022-05-30 07:33:36 --> Total execution time: 1.4794
DEBUG - 2022-05-30 07:36:04 --> Total execution time: 1.5388
DEBUG - 2022-05-30 07:36:29 --> Total execution time: 0.0186
DEBUG - 2022-05-30 07:38:07 --> Total execution time: 1.5588
DEBUG - 2022-05-30 07:38:30 --> Total execution time: 0.0301
DEBUG - 2022-05-30 07:38:40 --> Total execution time: 0.0197
DEBUG - 2022-05-30 07:39:36 --> Total execution time: 1.4905
DEBUG - 2022-05-30 07:39:43 --> Total execution time: 0.0385
DEBUG - 2022-05-30 07:39:46 --> Total execution time: 0.0304
DEBUG - 2022-05-30 07:40:09 --> Total execution time: 0.0225
DEBUG - 2022-05-30 07:40:42 --> Total execution time: 0.0224
DEBUG - 2022-05-30 07:40:55 --> Total execution time: 0.0248
DEBUG - 2022-05-30 07:41:15 --> Total execution time: 0.0347
DEBUG - 2022-05-30 07:41:20 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:41:25 --> Total execution time: 0.0462
DEBUG - 2022-05-30 07:41:25 --> Total execution time: 0.0237
DEBUG - 2022-05-30 07:41:28 --> Total execution time: 0.0334
DEBUG - 2022-05-30 07:41:38 --> Total execution time: 0.0511
DEBUG - 2022-05-30 07:41:41 --> Total execution time: 0.0312
DEBUG - 2022-05-30 07:41:45 --> Total execution time: 0.0384
DEBUG - 2022-05-30 07:41:45 --> Total execution time: 0.0278
DEBUG - 2022-05-30 07:41:59 --> Total execution time: 0.0529
DEBUG - 2022-05-30 07:42:02 --> Total execution time: 0.0228
DEBUG - 2022-05-30 07:42:13 --> Total execution time: 1.4979
DEBUG - 2022-05-30 07:42:26 --> Total execution time: 0.0244
DEBUG - 2022-05-30 07:42:31 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:42:43 --> Total execution time: 0.0250
DEBUG - 2022-05-30 07:43:13 --> Total execution time: 0.0255
DEBUG - 2022-05-30 07:43:18 --> Total execution time: 0.0231
DEBUG - 2022-05-30 07:43:18 --> Total execution time: 0.0280
DEBUG - 2022-05-30 07:43:23 --> Total execution time: 0.0688
DEBUG - 2022-05-30 07:43:26 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:43:32 --> Total execution time: 1.4892
DEBUG - 2022-05-30 07:45:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:45:42 --> Total execution time: 0.0230
DEBUG - 2022-05-30 07:45:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:45:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:45:44 --> Total execution time: 0.1531
DEBUG - 2022-05-30 07:45:59 --> Total execution time: 1.5100
DEBUG - 2022-05-30 07:45:59 --> Total execution time: 0.0355
DEBUG - 2022-05-30 07:46:07 --> Total execution time: 0.0433
DEBUG - 2022-05-30 07:46:15 --> Total execution time: 0.0477
DEBUG - 2022-05-30 07:46:33 --> Total execution time: 0.0366
DEBUG - 2022-05-30 07:46:51 --> Total execution time: 0.0260
DEBUG - 2022-05-30 07:47:00 --> Total execution time: 0.0555
DEBUG - 2022-05-30 07:58:33 --> Total execution time: 0.1392
DEBUG - 2022-05-30 07:58:51 --> Total execution time: 0.0259
DEBUG - 2022-05-30 07:59:22 --> Total execution time: 0.0315
DEBUG - 2022-05-30 07:59:32 --> Total execution time: 0.0331
DEBUG - 2022-05-30 07:59:37 --> Total execution time: 0.0404
DEBUG - 2022-05-30 08:01:04 --> Total execution time: 0.0231
DEBUG - 2022-05-30 08:01:34 --> Total execution time: 0.0285
DEBUG - 2022-05-30 08:01:47 --> Total execution time: 0.0258
DEBUG - 2022-05-30 08:02:06 --> Total execution time: 0.0264
DEBUG - 2022-05-30 08:02:13 --> Total execution time: 0.0259
DEBUG - 2022-05-30 08:02:35 --> Total execution time: 0.0483
DEBUG - 2022-05-30 08:02:41 --> Total execution time: 0.0547
DEBUG - 2022-05-30 08:02:56 --> Total execution time: 0.0285
DEBUG - 2022-05-30 08:03:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 08:03:05 --> Total execution time: 0.0686
DEBUG - 2022-05-30 08:03:09 --> Total execution time: 0.0525
DEBUG - 2022-05-30 08:03:15 --> Total execution time: 0.0292
DEBUG - 2022-05-30 08:03:30 --> Total execution time: 0.0206
DEBUG - 2022-05-30 08:03:34 --> Total execution time: 0.0232
DEBUG - 2022-05-30 08:03:41 --> Total execution time: 0.0232
DEBUG - 2022-05-30 08:03:48 --> Total execution time: 0.0273
DEBUG - 2022-05-30 08:03:51 --> Total execution time: 0.0486
DEBUG - 2022-05-30 08:03:56 --> Total execution time: 0.0408
DEBUG - 2022-05-30 08:04:03 --> Total execution time: 0.0336
DEBUG - 2022-05-30 08:04:20 --> Total execution time: 0.0359
DEBUG - 2022-05-30 08:04:50 --> Total execution time: 0.0257
DEBUG - 2022-05-30 08:05:09 --> Total execution time: 0.0540
DEBUG - 2022-05-30 08:05:14 --> Total execution time: 0.0294
DEBUG - 2022-05-30 08:05:22 --> Total execution time: 0.0612
DEBUG - 2022-05-30 08:05:23 --> Total execution time: 0.0362
DEBUG - 2022-05-30 08:05:34 --> Total execution time: 0.0267
DEBUG - 2022-05-30 08:05:37 --> Total execution time: 0.0287
DEBUG - 2022-05-30 08:05:40 --> Total execution time: 0.0451
DEBUG - 2022-05-30 08:05:48 --> Total execution time: 0.0341
DEBUG - 2022-05-30 08:05:53 --> Total execution time: 0.0299
DEBUG - 2022-05-30 08:05:54 --> Total execution time: 0.0302
DEBUG - 2022-05-30 08:06:03 --> Total execution time: 0.0198
DEBUG - 2022-05-30 08:06:04 --> Total execution time: 0.0392
DEBUG - 2022-05-30 08:06:07 --> Total execution time: 0.0384
DEBUG - 2022-05-30 08:06:21 --> Total execution time: 0.0278
DEBUG - 2022-05-30 08:06:22 --> Total execution time: 0.0263
DEBUG - 2022-05-30 08:06:35 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:06:57 --> Total execution time: 0.0408
DEBUG - 2022-05-30 08:07:07 --> Total execution time: 0.0283
DEBUG - 2022-05-30 08:07:17 --> Total execution time: 0.0371
DEBUG - 2022-05-30 08:09:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 08:09:26 --> Total execution time: 0.0438
DEBUG - 2022-05-30 08:09:57 --> Total execution time: 0.1050
DEBUG - 2022-05-30 08:09:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 08:09:58 --> Total execution time: 0.0336
DEBUG - 2022-05-30 08:10:10 --> Total execution time: 0.0511
DEBUG - 2022-05-30 08:10:17 --> Total execution time: 0.0342
DEBUG - 2022-05-30 08:10:31 --> Total execution time: 0.0581
DEBUG - 2022-05-30 08:11:07 --> Total execution time: 0.0495
DEBUG - 2022-05-30 08:11:22 --> Total execution time: 0.1004
DEBUG - 2022-05-30 08:11:31 --> Total execution time: 0.0474
DEBUG - 2022-05-30 08:11:34 --> Total execution time: 0.0430
DEBUG - 2022-05-30 08:11:50 --> Total execution time: 0.0337
DEBUG - 2022-05-30 08:11:50 --> Total execution time: 0.0332
DEBUG - 2022-05-30 08:11:50 --> Total execution time: 0.0274
DEBUG - 2022-05-30 08:11:51 --> Total execution time: 0.0334
DEBUG - 2022-05-30 08:11:52 --> Total execution time: 0.0277
DEBUG - 2022-05-30 08:11:52 --> Total execution time: 0.0781
DEBUG - 2022-05-30 08:12:08 --> Total execution time: 0.0517
DEBUG - 2022-05-30 08:12:12 --> Total execution time: 0.0264
DEBUG - 2022-05-30 08:13:09 --> Total execution time: 0.0254
DEBUG - 2022-05-30 08:13:13 --> Total execution time: 0.0710
DEBUG - 2022-05-30 08:13:20 --> Total execution time: 0.0331
DEBUG - 2022-05-30 08:13:30 --> Total execution time: 0.0267
DEBUG - 2022-05-30 08:13:58 --> Total execution time: 0.0265
DEBUG - 2022-05-30 08:14:09 --> Total execution time: 0.0245
DEBUG - 2022-05-30 08:14:13 --> Total execution time: 0.0312
DEBUG - 2022-05-30 08:14:20 --> Total execution time: 0.0275
DEBUG - 2022-05-30 08:14:24 --> Total execution time: 0.0338
DEBUG - 2022-05-30 08:14:26 --> Total execution time: 0.0182
DEBUG - 2022-05-30 08:14:27 --> Total execution time: 0.0346
DEBUG - 2022-05-30 08:14:32 --> Total execution time: 0.0375
DEBUG - 2022-05-30 08:14:35 --> Total execution time: 0.0333
DEBUG - 2022-05-30 08:14:40 --> Total execution time: 0.0263
DEBUG - 2022-05-30 08:14:43 --> Total execution time: 0.0258
DEBUG - 2022-05-30 08:14:44 --> Total execution time: 0.0261
DEBUG - 2022-05-30 08:14:46 --> Total execution time: 0.0435
DEBUG - 2022-05-30 08:14:47 --> Total execution time: 0.0248
DEBUG - 2022-05-30 08:14:50 --> Total execution time: 0.0455
DEBUG - 2022-05-30 08:14:54 --> Total execution time: 0.0277
DEBUG - 2022-05-30 08:15:03 --> Total execution time: 0.0338
DEBUG - 2022-05-30 08:15:07 --> Total execution time: 0.0202
DEBUG - 2022-05-30 08:15:07 --> Total execution time: 0.0233
DEBUG - 2022-05-30 08:15:07 --> Total execution time: 0.0175
DEBUG - 2022-05-30 08:15:08 --> Total execution time: 0.0299
DEBUG - 2022-05-30 08:15:09 --> Total execution time: 0.0325
DEBUG - 2022-05-30 08:15:39 --> Total execution time: 0.0304
DEBUG - 2022-05-30 08:15:48 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:16:39 --> Total execution time: 0.0330
DEBUG - 2022-05-30 08:16:42 --> Total execution time: 0.0405
DEBUG - 2022-05-30 08:16:49 --> Total execution time: 0.0246
DEBUG - 2022-05-30 08:18:12 --> Total execution time: 0.0355
DEBUG - 2022-05-30 08:18:35 --> Total execution time: 0.0554
DEBUG - 2022-05-30 08:18:37 --> Total execution time: 0.0305
DEBUG - 2022-05-30 08:18:38 --> Total execution time: 0.0242
DEBUG - 2022-05-30 08:18:38 --> Total execution time: 0.0215
DEBUG - 2022-05-30 08:18:45 --> Total execution time: 0.0231
DEBUG - 2022-05-30 08:18:52 --> Total execution time: 0.0277
DEBUG - 2022-05-30 08:19:11 --> Total execution time: 0.0637
DEBUG - 2022-05-30 08:19:30 --> Total execution time: 0.0277
DEBUG - 2022-05-30 08:19:37 --> Total execution time: 0.0446
DEBUG - 2022-05-30 08:19:46 --> Total execution time: 0.0398
DEBUG - 2022-05-30 08:19:50 --> Total execution time: 0.0397
DEBUG - 2022-05-30 08:19:53 --> Total execution time: 0.0451
DEBUG - 2022-05-30 08:20:18 --> Total execution time: 0.0293
DEBUG - 2022-05-30 08:20:23 --> Total execution time: 0.0438
DEBUG - 2022-05-30 08:20:45 --> Total execution time: 0.0772
DEBUG - 2022-05-30 08:20:57 --> Total execution time: 0.0448
DEBUG - 2022-05-30 08:21:06 --> Total execution time: 0.0341
DEBUG - 2022-05-30 08:21:13 --> Total execution time: 0.0318
DEBUG - 2022-05-30 08:21:16 --> Total execution time: 0.0274
DEBUG - 2022-05-30 08:21:21 --> Total execution time: 0.0279
DEBUG - 2022-05-30 08:21:24 --> Total execution time: 0.0300
DEBUG - 2022-05-30 08:21:35 --> Total execution time: 0.0650
DEBUG - 2022-05-30 08:21:46 --> Total execution time: 0.0319
DEBUG - 2022-05-30 08:21:58 --> Total execution time: 0.0896
DEBUG - 2022-05-30 08:22:06 --> Total execution time: 0.0772
DEBUG - 2022-05-30 08:22:15 --> Total execution time: 0.0442
DEBUG - 2022-05-30 08:22:43 --> Total execution time: 0.0756
DEBUG - 2022-05-30 08:22:55 --> Total execution time: 0.0501
DEBUG - 2022-05-30 08:23:02 --> Total execution time: 1.5686
DEBUG - 2022-05-30 08:23:39 --> Total execution time: 0.0308
DEBUG - 2022-05-30 08:23:45 --> Total execution time: 1.4617
DEBUG - 2022-05-30 08:23:58 --> Total execution time: 0.0342
DEBUG - 2022-05-30 08:24:05 --> Total execution time: 2.7484
DEBUG - 2022-05-30 08:24:07 --> Total execution time: 0.0261
DEBUG - 2022-05-30 08:24:13 --> Total execution time: 0.1069
DEBUG - 2022-05-30 08:24:22 --> Total execution time: 0.0281
DEBUG - 2022-05-30 08:29:18 --> Total execution time: 0.1575
DEBUG - 2022-05-30 08:29:18 --> Total execution time: 0.0682
DEBUG - 2022-05-30 08:29:28 --> Total execution time: 0.0679
DEBUG - 2022-05-30 08:29:30 --> Total execution time: 0.0328
DEBUG - 2022-05-30 08:29:47 --> Total execution time: 0.0482
DEBUG - 2022-05-30 08:29:52 --> Total execution time: 0.0343
DEBUG - 2022-05-30 08:30:02 --> Total execution time: 0.0477
DEBUG - 2022-05-30 08:30:04 --> Total execution time: 0.0630
DEBUG - 2022-05-30 08:30:09 --> Total execution time: 0.1203
DEBUG - 2022-05-30 08:30:12 --> Total execution time: 1.5688
DEBUG - 2022-05-30 08:30:13 --> Total execution time: 0.0523
DEBUG - 2022-05-30 08:30:15 --> Total execution time: 0.0336
DEBUG - 2022-05-30 08:30:18 --> Total execution time: 0.0309
DEBUG - 2022-05-30 08:30:37 --> Total execution time: 0.0270
DEBUG - 2022-05-30 08:31:15 --> Total execution time: 0.0230
DEBUG - 2022-05-30 08:31:27 --> Total execution time: 0.0537
DEBUG - 2022-05-30 08:33:53 --> Total execution time: 0.1132
DEBUG - 2022-05-30 08:34:01 --> Total execution time: 0.0643
DEBUG - 2022-05-30 08:37:31 --> Total execution time: 0.0965
DEBUG - 2022-05-30 08:44:01 --> Total execution time: 0.0527
DEBUG - 2022-05-30 08:44:06 --> Total execution time: 0.0440
DEBUG - 2022-05-30 08:45:06 --> Total execution time: 0.0260
DEBUG - 2022-05-30 08:45:19 --> Total execution time: 0.0252
DEBUG - 2022-05-30 08:45:53 --> Total execution time: 0.0928
DEBUG - 2022-05-30 08:45:55 --> Total execution time: 0.0484
DEBUG - 2022-05-30 08:46:03 --> Total execution time: 0.0255
DEBUG - 2022-05-30 09:08:42 --> Total execution time: 0.1484
DEBUG - 2022-05-30 09:08:47 --> Total execution time: 0.0277
DEBUG - 2022-05-30 09:08:56 --> Total execution time: 0.0423
DEBUG - 2022-05-30 09:09:04 --> Total execution time: 0.0673
DEBUG - 2022-05-30 09:15:45 --> Total execution time: 0.0992
DEBUG - 2022-05-30 09:16:42 --> Total execution time: 0.0222
DEBUG - 2022-05-30 09:16:43 --> Total execution time: 0.0247
DEBUG - 2022-05-30 09:16:52 --> Total execution time: 0.0248
DEBUG - 2022-05-30 09:17:02 --> Total execution time: 0.0351
DEBUG - 2022-05-30 09:17:15 --> Total execution time: 0.0384
DEBUG - 2022-05-30 09:17:49 --> Total execution time: 0.0585
DEBUG - 2022-05-30 09:18:05 --> Total execution time: 0.0507
DEBUG - 2022-05-30 09:18:09 --> Total execution time: 0.0350
DEBUG - 2022-05-30 09:18:32 --> Total execution time: 0.0206
DEBUG - 2022-05-30 09:19:50 --> Total execution time: 0.0240
DEBUG - 2022-05-30 09:21:55 --> Total execution time: 0.0870
DEBUG - 2022-05-30 09:22:04 --> Total execution time: 0.0292
DEBUG - 2022-05-30 09:26:55 --> Total execution time: 0.0866
DEBUG - 2022-05-30 09:27:19 --> Total execution time: 0.0427
DEBUG - 2022-05-30 09:27:53 --> Total execution time: 0.0301
DEBUG - 2022-05-30 09:30:02 --> Total execution time: 0.1899
DEBUG - 2022-05-30 09:30:03 --> Total execution time: 0.1515
DEBUG - 2022-05-30 09:30:12 --> Total execution time: 0.0431
DEBUG - 2022-05-30 09:36:32 --> Total execution time: 0.1095
DEBUG - 2022-05-30 09:38:03 --> Total execution time: 0.0238
DEBUG - 2022-05-30 09:38:12 --> Total execution time: 0.0205
DEBUG - 2022-05-30 09:38:24 --> Total execution time: 0.0215
DEBUG - 2022-05-30 09:39:03 --> Total execution time: 0.0376
DEBUG - 2022-05-30 09:39:32 --> Total execution time: 0.0406
DEBUG - 2022-05-30 09:39:38 --> Total execution time: 0.0438
DEBUG - 2022-05-30 09:39:58 --> Total execution time: 0.0258
DEBUG - 2022-05-30 09:40:51 --> Total execution time: 0.0182
DEBUG - 2022-05-30 09:41:03 --> Total execution time: 0.0271
DEBUG - 2022-05-30 09:41:08 --> Total execution time: 0.0301
DEBUG - 2022-05-30 09:41:21 --> Total execution time: 0.0401
DEBUG - 2022-05-30 09:41:29 --> Total execution time: 0.0240
DEBUG - 2022-05-30 09:41:30 --> Total execution time: 0.0312
DEBUG - 2022-05-30 09:42:14 --> Total execution time: 1.5211
DEBUG - 2022-05-30 09:42:24 --> Total execution time: 0.0246
DEBUG - 2022-05-30 09:42:48 --> Total execution time: 0.0306
DEBUG - 2022-05-30 09:42:51 --> Total execution time: 0.0344
DEBUG - 2022-05-30 09:42:54 --> Total execution time: 0.0360
DEBUG - 2022-05-30 09:43:02 --> Total execution time: 0.0307
DEBUG - 2022-05-30 09:43:40 --> Total execution time: 0.0284
DEBUG - 2022-05-30 09:43:46 --> Total execution time: 0.0191
DEBUG - 2022-05-30 09:43:54 --> Total execution time: 0.0262
DEBUG - 2022-05-30 09:43:55 --> Total execution time: 0.0348
DEBUG - 2022-05-30 09:44:00 --> Total execution time: 0.0292
DEBUG - 2022-05-30 09:44:03 --> Total execution time: 0.0325
DEBUG - 2022-05-30 09:44:10 --> Total execution time: 0.0349
DEBUG - 2022-05-30 09:44:18 --> Total execution time: 0.0251
DEBUG - 2022-05-30 09:45:18 --> Total execution time: 0.0236
DEBUG - 2022-05-30 09:46:14 --> Total execution time: 0.0319
DEBUG - 2022-05-30 09:46:17 --> Total execution time: 0.0272
DEBUG - 2022-05-30 09:46:19 --> Total execution time: 0.0439
DEBUG - 2022-05-30 09:46:22 --> Total execution time: 0.0329
DEBUG - 2022-05-30 09:46:27 --> Total execution time: 0.0252
DEBUG - 2022-05-30 09:46:42 --> Total execution time: 1.5311
DEBUG - 2022-05-30 09:46:51 --> Total execution time: 0.0321
DEBUG - 2022-05-30 09:47:02 --> Total execution time: 0.0288
DEBUG - 2022-05-30 09:47:04 --> Total execution time: 0.0412
DEBUG - 2022-05-30 09:47:09 --> Total execution time: 0.0279
DEBUG - 2022-05-30 09:47:12 --> Total execution time: 0.0488
DEBUG - 2022-05-30 09:47:25 --> Total execution time: 0.0180
DEBUG - 2022-05-30 09:47:42 --> Total execution time: 0.0342
DEBUG - 2022-05-30 09:47:43 --> Total execution time: 0.0264
DEBUG - 2022-05-30 09:47:52 --> Total execution time: 0.0287
DEBUG - 2022-05-30 09:48:02 --> Total execution time: 0.0433
DEBUG - 2022-05-30 09:49:16 --> Total execution time: 0.0258
DEBUG - 2022-05-30 09:49:18 --> Total execution time: 0.0275
DEBUG - 2022-05-30 09:49:20 --> Total execution time: 0.0266
DEBUG - 2022-05-30 09:49:22 --> Total execution time: 0.0266
DEBUG - 2022-05-30 09:49:39 --> Total execution time: 0.0213
DEBUG - 2022-05-30 09:49:40 --> Total execution time: 0.0238
DEBUG - 2022-05-30 09:49:42 --> Total execution time: 0.0260
DEBUG - 2022-05-30 09:49:48 --> Total execution time: 0.0417
DEBUG - 2022-05-30 09:50:13 --> Total execution time: 0.0429
DEBUG - 2022-05-30 09:50:18 --> Total execution time: 0.0199
DEBUG - 2022-05-30 09:50:26 --> Total execution time: 0.0404
DEBUG - 2022-05-30 09:51:15 --> Total execution time: 0.0244
DEBUG - 2022-05-30 09:51:47 --> Total execution time: 0.0268
DEBUG - 2022-05-30 09:51:54 --> Total execution time: 0.0351
DEBUG - 2022-05-30 09:51:57 --> Total execution time: 0.0246
DEBUG - 2022-05-30 09:52:06 --> Total execution time: 0.0293
DEBUG - 2022-05-30 09:53:41 --> Total execution time: 0.0185
DEBUG - 2022-05-30 09:53:52 --> Total execution time: 0.0293
DEBUG - 2022-05-30 09:54:00 --> Total execution time: 0.0613
DEBUG - 2022-05-30 09:54:11 --> Total execution time: 0.0354
DEBUG - 2022-05-30 09:54:37 --> Total execution time: 0.0271
DEBUG - 2022-05-30 09:55:06 --> Total execution time: 0.0266
DEBUG - 2022-05-30 09:56:03 --> Total execution time: 0.0300
DEBUG - 2022-05-30 09:56:15 --> Total execution time: 0.0873
DEBUG - 2022-05-30 09:56:22 --> Total execution time: 0.0367
DEBUG - 2022-05-30 09:56:22 --> Total execution time: 0.0335
DEBUG - 2022-05-30 09:56:24 --> Total execution time: 0.0573
DEBUG - 2022-05-30 09:56:24 --> Total execution time: 0.0498
DEBUG - 2022-05-30 09:56:40 --> Total execution time: 0.0260
DEBUG - 2022-05-30 09:57:00 --> Total execution time: 0.0189
DEBUG - 2022-05-30 09:57:11 --> Total execution time: 0.0281
DEBUG - 2022-05-30 09:57:15 --> Total execution time: 0.0264
DEBUG - 2022-05-30 09:57:19 --> Total execution time: 0.0257
DEBUG - 2022-05-30 09:57:20 --> Total execution time: 0.0272
DEBUG - 2022-05-30 09:57:23 --> Total execution time: 0.0257
DEBUG - 2022-05-30 09:57:42 --> Total execution time: 0.0261
DEBUG - 2022-05-30 09:57:49 --> Total execution time: 0.1159
DEBUG - 2022-05-30 09:58:09 --> Total execution time: 0.0282
DEBUG - 2022-05-30 09:58:22 --> Total execution time: 0.0436
DEBUG - 2022-05-30 09:58:26 --> Total execution time: 0.0515
DEBUG - 2022-05-30 09:58:37 --> Total execution time: 0.0244
DEBUG - 2022-05-30 09:58:48 --> Total execution time: 0.0206
DEBUG - 2022-05-30 09:59:02 --> Total execution time: 0.0473
DEBUG - 2022-05-30 09:59:03 --> Total execution time: 0.0230
DEBUG - 2022-05-30 09:59:05 --> Total execution time: 0.0254
DEBUG - 2022-05-30 09:59:06 --> Total execution time: 0.0203
DEBUG - 2022-05-30 09:59:07 --> Total execution time: 0.0221
DEBUG - 2022-05-30 09:59:19 --> Total execution time: 0.0184
DEBUG - 2022-05-30 09:59:53 --> Total execution time: 0.0236
DEBUG - 2022-05-30 10:00:12 --> Total execution time: 0.0270
DEBUG - 2022-05-30 10:00:12 --> Total execution time: 0.0252
DEBUG - 2022-05-30 10:00:14 --> Total execution time: 0.0316
DEBUG - 2022-05-30 10:00:16 --> Total execution time: 0.0293
DEBUG - 2022-05-30 10:00:23 --> Total execution time: 0.0272
DEBUG - 2022-05-30 10:00:31 --> Total execution time: 0.0301
DEBUG - 2022-05-30 10:00:41 --> Total execution time: 0.0327
DEBUG - 2022-05-30 10:00:46 --> Total execution time: 0.0419
DEBUG - 2022-05-30 10:00:58 --> Total execution time: 0.0261
DEBUG - 2022-05-30 10:00:59 --> Total execution time: 0.0278
DEBUG - 2022-05-30 10:01:02 --> Total execution time: 0.0558
DEBUG - 2022-05-30 10:01:11 --> Total execution time: 0.0446
DEBUG - 2022-05-30 10:01:16 --> Total execution time: 0.0573
DEBUG - 2022-05-30 10:01:34 --> Total execution time: 0.0203
DEBUG - 2022-05-30 10:01:40 --> Total execution time: 0.0272
DEBUG - 2022-05-30 10:01:44 --> Total execution time: 0.0179
DEBUG - 2022-05-30 10:01:51 --> Total execution time: 0.0285
DEBUG - 2022-05-30 10:02:08 --> Total execution time: 0.0418
DEBUG - 2022-05-30 10:02:11 --> Total execution time: 0.0244
DEBUG - 2022-05-30 10:02:22 --> Total execution time: 0.0294
DEBUG - 2022-05-30 10:02:46 --> Total execution time: 0.0261
DEBUG - 2022-05-30 10:02:50 --> Total execution time: 0.0234
DEBUG - 2022-05-30 10:03:25 --> Total execution time: 0.0233
DEBUG - 2022-05-30 10:03:49 --> Total execution time: 0.0336
DEBUG - 2022-05-30 10:04:18 --> Total execution time: 0.0215
DEBUG - 2022-05-30 10:04:18 --> Total execution time: 0.0309
DEBUG - 2022-05-30 10:04:24 --> Total execution time: 0.0181
DEBUG - 2022-05-30 10:04:32 --> Total execution time: 0.0303
DEBUG - 2022-05-30 10:04:37 --> Total execution time: 0.1614
DEBUG - 2022-05-30 10:04:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 10:04:38 --> Total execution time: 0.0240
DEBUG - 2022-05-30 10:04:50 --> Total execution time: 0.0628
DEBUG - 2022-05-30 10:04:55 --> Total execution time: 0.0500
DEBUG - 2022-05-30 10:04:56 --> Total execution time: 0.0547
DEBUG - 2022-05-30 10:05:06 --> Total execution time: 0.0235
DEBUG - 2022-05-30 10:05:08 --> Total execution time: 0.0283
DEBUG - 2022-05-30 10:05:18 --> Total execution time: 0.0350
DEBUG - 2022-05-30 10:05:22 --> Total execution time: 0.0292
DEBUG - 2022-05-30 10:05:30 --> Total execution time: 0.0344
DEBUG - 2022-05-30 10:05:42 --> Total execution time: 0.0328
DEBUG - 2022-05-30 10:06:12 --> Total execution time: 0.0313
DEBUG - 2022-05-30 10:06:32 --> Total execution time: 0.0298
DEBUG - 2022-05-30 10:06:52 --> Total execution time: 0.0734
DEBUG - 2022-05-30 10:07:10 --> Total execution time: 0.0247
DEBUG - 2022-05-30 10:07:13 --> Total execution time: 0.0296
DEBUG - 2022-05-30 10:07:15 --> Total execution time: 0.0303
DEBUG - 2022-05-30 10:07:16 --> Total execution time: 0.0352
DEBUG - 2022-05-30 10:07:23 --> Total execution time: 0.0287
DEBUG - 2022-05-30 10:07:25 --> Total execution time: 0.0292
DEBUG - 2022-05-30 10:07:30 --> Total execution time: 0.0378
DEBUG - 2022-05-30 10:07:47 --> Total execution time: 0.0247
DEBUG - 2022-05-30 10:07:53 --> Total execution time: 0.0358
DEBUG - 2022-05-30 10:07:59 --> Total execution time: 0.0233
DEBUG - 2022-05-30 10:08:00 --> Total execution time: 0.0286
DEBUG - 2022-05-30 10:08:06 --> Total execution time: 0.0261
DEBUG - 2022-05-30 10:08:13 --> Total execution time: 0.0245
DEBUG - 2022-05-30 10:08:20 --> Total execution time: 0.0268
DEBUG - 2022-05-30 10:08:27 --> Total execution time: 0.0184
DEBUG - 2022-05-30 10:08:47 --> Total execution time: 0.0369
DEBUG - 2022-05-30 10:08:50 --> Total execution time: 0.0277
DEBUG - 2022-05-30 10:08:59 --> Total execution time: 0.0226
DEBUG - 2022-05-30 10:09:14 --> Total execution time: 0.0311
DEBUG - 2022-05-30 10:09:17 --> Total execution time: 0.0299
DEBUG - 2022-05-30 10:09:59 --> Total execution time: 0.0734
DEBUG - 2022-05-30 10:10:11 --> Total execution time: 0.0550
DEBUG - 2022-05-30 10:10:31 --> Total execution time: 0.0341
DEBUG - 2022-05-30 10:10:40 --> Total execution time: 0.0335
DEBUG - 2022-05-30 10:10:45 --> Total execution time: 0.0279
DEBUG - 2022-05-30 10:10:50 --> Total execution time: 0.0365
DEBUG - 2022-05-30 10:11:08 --> Total execution time: 0.0284
DEBUG - 2022-05-30 10:11:29 --> Total execution time: 0.0258
DEBUG - 2022-05-30 10:11:35 --> Total execution time: 0.0229
DEBUG - 2022-05-30 10:11:37 --> Total execution time: 0.0294
DEBUG - 2022-05-30 10:13:52 --> Total execution time: 0.0846
DEBUG - 2022-05-30 10:13:58 --> Total execution time: 0.0233
DEBUG - 2022-05-30 10:14:11 --> Total execution time: 0.0273
DEBUG - 2022-05-30 10:14:48 --> Total execution time: 0.0258
DEBUG - 2022-05-30 10:15:15 --> Total execution time: 0.0445
DEBUG - 2022-05-30 10:15:19 --> Total execution time: 0.0748
DEBUG - 2022-05-30 10:15:23 --> Total execution time: 0.0261
DEBUG - 2022-05-30 10:15:32 --> Total execution time: 0.0268
DEBUG - 2022-05-30 10:15:54 --> Total execution time: 0.0587
DEBUG - 2022-05-30 10:16:01 --> Total execution time: 0.0388
DEBUG - 2022-05-30 10:16:04 --> Total execution time: 0.0408
DEBUG - 2022-05-30 10:16:06 --> Total execution time: 0.0449
DEBUG - 2022-05-30 10:16:12 --> Total execution time: 0.0243
DEBUG - 2022-05-30 10:16:41 --> Total execution time: 0.0536
DEBUG - 2022-05-30 10:16:48 --> Total execution time: 0.0305
DEBUG - 2022-05-30 10:16:48 --> Total execution time: 0.0230
DEBUG - 2022-05-30 10:17:02 --> Total execution time: 0.0442
DEBUG - 2022-05-30 10:17:13 --> Total execution time: 0.0290
DEBUG - 2022-05-30 10:17:33 --> Total execution time: 0.0222
DEBUG - 2022-05-30 10:17:52 --> Total execution time: 0.0283
DEBUG - 2022-05-30 10:18:03 --> Total execution time: 0.0295
DEBUG - 2022-05-30 10:18:24 --> Total execution time: 0.0187
DEBUG - 2022-05-30 10:18:46 --> Total execution time: 0.0332
DEBUG - 2022-05-30 10:18:51 --> Total execution time: 0.0186
DEBUG - 2022-05-30 10:18:59 --> Total execution time: 0.0206
DEBUG - 2022-05-30 10:18:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 10:19:00 --> Total execution time: 0.0183
DEBUG - 2022-05-30 10:19:28 --> Total execution time: 0.0396
DEBUG - 2022-05-30 10:19:29 --> Total execution time: 0.0284
DEBUG - 2022-05-30 10:19:38 --> Total execution time: 0.0799
DEBUG - 2022-05-30 10:19:55 --> Total execution time: 0.0240
DEBUG - 2022-05-30 10:20:00 --> Total execution time: 0.0300
DEBUG - 2022-05-30 10:20:00 --> Total execution time: 0.0427
DEBUG - 2022-05-30 10:20:04 --> Total execution time: 0.0289
DEBUG - 2022-05-30 10:20:07 --> Total execution time: 0.0290
DEBUG - 2022-05-30 10:20:17 --> Total execution time: 0.0241
DEBUG - 2022-05-30 10:20:28 --> Total execution time: 0.0374
DEBUG - 2022-05-30 10:20:40 --> Total execution time: 0.0280
DEBUG - 2022-05-30 10:20:45 --> Total execution time: 0.0400
DEBUG - 2022-05-30 10:20:53 --> Total execution time: 0.0290
DEBUG - 2022-05-30 10:21:07 --> Total execution time: 0.0279
DEBUG - 2022-05-30 10:21:18 --> Total execution time: 0.0362
DEBUG - 2022-05-30 10:21:21 --> Total execution time: 0.0307
DEBUG - 2022-05-30 10:21:27 --> Total execution time: 0.0238
DEBUG - 2022-05-30 10:21:35 --> Total execution time: 0.0278
DEBUG - 2022-05-30 10:21:36 --> Total execution time: 0.0247
DEBUG - 2022-05-30 10:21:38 --> Total execution time: 0.0308
DEBUG - 2022-05-30 10:21:54 --> Total execution time: 0.0185
DEBUG - 2022-05-30 10:22:00 --> Total execution time: 0.0286
DEBUG - 2022-05-30 10:22:09 --> Total execution time: 0.0380
DEBUG - 2022-05-30 10:22:39 --> Total execution time: 0.0355
DEBUG - 2022-05-30 10:22:53 --> Total execution time: 0.0270
DEBUG - 2022-05-30 10:23:01 --> Total execution time: 0.0448
DEBUG - 2022-05-30 10:23:05 --> Total execution time: 0.0439
DEBUG - 2022-05-30 10:23:10 --> Total execution time: 0.0299
DEBUG - 2022-05-30 10:23:13 --> Total execution time: 0.0328
DEBUG - 2022-05-30 10:23:23 --> Total execution time: 0.0328
DEBUG - 2022-05-30 10:23:26 --> Total execution time: 0.1071
DEBUG - 2022-05-30 10:24:27 --> Total execution time: 0.0399
DEBUG - 2022-05-30 10:25:46 --> Total execution time: 0.0595
DEBUG - 2022-05-30 10:25:51 --> Total execution time: 0.0286
DEBUG - 2022-05-30 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:30:03 --> Total execution time: 0.0766
DEBUG - 2022-05-30 00:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:30:09 --> Total execution time: 0.1297
DEBUG - 2022-05-30 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:30:50 --> Total execution time: 0.0386
DEBUG - 2022-05-30 00:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:31:02 --> Total execution time: 0.0438
DEBUG - 2022-05-30 00:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:01:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-30 00:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:04:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 00:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:34:29 --> Total execution time: 0.1077
DEBUG - 2022-05-30 00:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:34:47 --> Total execution time: 0.0418
DEBUG - 2022-05-30 00:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:34:50 --> Total execution time: 0.0298
DEBUG - 2022-05-30 00:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:35:05 --> Total execution time: 0.0480
DEBUG - 2022-05-30 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:35:20 --> Total execution time: 0.0256
DEBUG - 2022-05-30 00:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:37:35 --> Total execution time: 0.0997
DEBUG - 2022-05-30 00:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:39:24 --> Total execution time: 0.0575
DEBUG - 2022-05-30 00:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:10:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:10:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-30 00:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:41:07 --> Total execution time: 0.0270
DEBUG - 2022-05-30 00:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:41:08 --> Total execution time: 0.0242
DEBUG - 2022-05-30 00:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:41:54 --> Total execution time: 0.0333
DEBUG - 2022-05-30 00:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:44:17 --> Total execution time: 0.0762
DEBUG - 2022-05-30 00:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:47:49 --> Total execution time: 0.1057
DEBUG - 2022-05-30 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:48:01 --> Total execution time: 0.0264
DEBUG - 2022-05-30 00:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:55:02 --> Total execution time: 0.0303
DEBUG - 2022-05-30 00:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:55:15 --> Total execution time: 0.0189
DEBUG - 2022-05-30 00:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:55:58 --> Total execution time: 0.0256
DEBUG - 2022-05-30 00:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:27:51 --> Total execution time: 0.0326
DEBUG - 2022-05-30 00:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:58:01 --> Total execution time: 0.0374
DEBUG - 2022-05-30 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:58:18 --> Total execution time: 4.2633
DEBUG - 2022-05-30 00:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:28:27 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:05 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:29:10 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 00:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:30:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 00:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:00:12 --> Total execution time: 0.0498
DEBUG - 2022-05-30 00:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:00:44 --> Total execution time: 0.0295
DEBUG - 2022-05-30 00:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:00:45 --> Total execution time: 0.0358
DEBUG - 2022-05-30 00:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:01:10 --> Total execution time: 0.0461
DEBUG - 2022-05-30 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:01:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:01:13 --> Total execution time: 0.0481
DEBUG - 2022-05-30 00:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:01:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:01:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:01:14 --> Total execution time: 0.1744
DEBUG - 2022-05-30 00:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:01:16 --> Total execution time: 0.0323
DEBUG - 2022-05-30 00:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:02:00 --> Total execution time: 0.0249
DEBUG - 2022-05-30 00:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:32:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 00:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:02:57 --> Total execution time: 0.0226
DEBUG - 2022-05-30 00:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:03:06 --> Total execution time: 0.0182
DEBUG - 2022-05-30 00:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:03:15 --> Total execution time: 0.0590
DEBUG - 2022-05-30 00:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:03:26 --> Total execution time: 0.0346
DEBUG - 2022-05-30 00:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:03:41 --> Total execution time: 0.0376
DEBUG - 2022-05-30 00:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:03:45 --> Total execution time: 0.0375
DEBUG - 2022-05-30 00:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:03:58 --> Total execution time: 0.0275
DEBUG - 2022-05-30 00:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:38:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:38:37 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 00:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:40:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 00:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:10:00 --> Total execution time: 0.0687
DEBUG - 2022-05-30 00:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:43:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 00:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:13:06 --> Total execution time: 0.1238
DEBUG - 2022-05-30 00:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:13:48 --> Total execution time: 0.0320
DEBUG - 2022-05-30 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:14:07 --> Total execution time: 0.0289
DEBUG - 2022-05-30 00:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:14:11 --> Total execution time: 0.0339
DEBUG - 2022-05-30 00:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:14:16 --> Total execution time: 0.0317
DEBUG - 2022-05-30 00:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:14:47 --> Total execution time: 0.0513
DEBUG - 2022-05-30 00:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:14:51 --> Total execution time: 0.0315
DEBUG - 2022-05-30 00:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:15:13 --> Total execution time: 0.2712
DEBUG - 2022-05-30 00:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:15:22 --> Total execution time: 0.0376
DEBUG - 2022-05-30 00:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:15:40 --> Total execution time: 0.0835
DEBUG - 2022-05-30 00:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:18:06 --> Total execution time: 0.2352
DEBUG - 2022-05-30 00:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:18:52 --> Total execution time: 0.0962
DEBUG - 2022-05-30 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 00:49:43 --> 404 Page Not Found: Wp-sitemapxml/index
DEBUG - 2022-05-30 00:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:23:50 --> Total execution time: 0.1225
DEBUG - 2022-05-30 00:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:24:25 --> Total execution time: 0.0263
DEBUG - 2022-05-30 00:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:25:41 --> Total execution time: 0.0286
DEBUG - 2022-05-30 00:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:25:51 --> Total execution time: 0.0354
DEBUG - 2022-05-30 00:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:25:55 --> Total execution time: 0.0818
DEBUG - 2022-05-30 00:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 00:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 00:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:29:17 --> Total execution time: 0.0312
DEBUG - 2022-05-30 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:30:02 --> Total execution time: 0.1376
DEBUG - 2022-05-30 01:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:30:24 --> Total execution time: 0.0458
DEBUG - 2022-05-30 01:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:34:10 --> Total execution time: 0.0531
DEBUG - 2022-05-30 01:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:34:44 --> Total execution time: 0.0250
DEBUG - 2022-05-30 01:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:36:07 --> Total execution time: 0.1215
DEBUG - 2022-05-30 01:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:36:24 --> Total execution time: 0.0589
DEBUG - 2022-05-30 01:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:06:46 --> Total execution time: 0.0368
DEBUG - 2022-05-30 01:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:06:55 --> Total execution time: 0.0227
DEBUG - 2022-05-30 01:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:06:59 --> Total execution time: 0.0247
DEBUG - 2022-05-30 01:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:07:13 --> Total execution time: 0.0251
DEBUG - 2022-05-30 01:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:07:15 --> Total execution time: 0.0244
DEBUG - 2022-05-30 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:07:17 --> Total execution time: 0.0206
DEBUG - 2022-05-30 01:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:37:19 --> Total execution time: 0.0451
DEBUG - 2022-05-30 01:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:37:25 --> Total execution time: 0.0401
DEBUG - 2022-05-30 01:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:37:25 --> Total execution time: 0.0648
DEBUG - 2022-05-30 01:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:43 --> Total execution time: 0.0586
DEBUG - 2022-05-30 01:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:08:48 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:48 --> Total execution time: 0.0394
DEBUG - 2022-05-30 01:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:52 --> Total execution time: 0.0232
DEBUG - 2022-05-30 01:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:39:14 --> Total execution time: 0.0355
DEBUG - 2022-05-30 01:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:39:29 --> Total execution time: 0.0332
DEBUG - 2022-05-30 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:39:35 --> Total execution time: 0.0330
DEBUG - 2022-05-30 01:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:39:44 --> Total execution time: 0.0343
DEBUG - 2022-05-30 01:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:39:53 --> Total execution time: 0.0501
DEBUG - 2022-05-30 01:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:40:09 --> Total execution time: 0.0374
DEBUG - 2022-05-30 01:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:40:16 --> Total execution time: 0.0893
DEBUG - 2022-05-30 01:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:40:37 --> Total execution time: 0.0470
DEBUG - 2022-05-30 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:40:54 --> Total execution time: 0.0244
DEBUG - 2022-05-30 01:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:40:58 --> Total execution time: 0.0230
DEBUG - 2022-05-30 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:41:13 --> Total execution time: 0.0381
DEBUG - 2022-05-30 01:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:41:24 --> Total execution time: 0.0299
DEBUG - 2022-05-30 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:41:34 --> Total execution time: 0.0614
DEBUG - 2022-05-30 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:41:52 --> Total execution time: 0.0639
DEBUG - 2022-05-30 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:03 --> Total execution time: 0.0435
DEBUG - 2022-05-30 01:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 01:15:13 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-05-30 01:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:15:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:13 --> Total execution time: 0.0428
DEBUG - 2022-05-30 01:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:15:16 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:16 --> Total execution time: 0.0211
DEBUG - 2022-05-30 01:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:47:10 --> Total execution time: 0.0562
DEBUG - 2022-05-30 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:17:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:47:31 --> Total execution time: 0.0299
DEBUG - 2022-05-30 01:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:47:38 --> Total execution time: 0.0380
DEBUG - 2022-05-30 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:47:57 --> Total execution time: 0.0358
DEBUG - 2022-05-30 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:18:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:08 --> Total execution time: 0.0275
DEBUG - 2022-05-30 01:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:17 --> Total execution time: 0.0390
DEBUG - 2022-05-30 01:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:27 --> Total execution time: 0.0297
DEBUG - 2022-05-30 01:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:35 --> Total execution time: 0.0515
DEBUG - 2022-05-30 01:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:18:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:51 --> Total execution time: 0.0254
DEBUG - 2022-05-30 01:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:19:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:49:00 --> Total execution time: 0.0259
DEBUG - 2022-05-30 01:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:49:02 --> Total execution time: 0.0302
DEBUG - 2022-05-30 01:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:49:14 --> Total execution time: 0.0508
DEBUG - 2022-05-30 01:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:21:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:51:54 --> Total execution time: 0.1916
DEBUG - 2022-05-30 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:55:52 --> Total execution time: 0.1508
DEBUG - 2022-05-30 01:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:55:57 --> Total execution time: 0.0352
DEBUG - 2022-05-30 01:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:03 --> Total execution time: 0.0650
DEBUG - 2022-05-30 01:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:06 --> Total execution time: 0.0361
DEBUG - 2022-05-30 01:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:09 --> Total execution time: 0.0464
DEBUG - 2022-05-30 01:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:21 --> Total execution time: 0.0508
DEBUG - 2022-05-30 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:30 --> Total execution time: 0.0413
DEBUG - 2022-05-30 01:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:39 --> Total execution time: 0.0314
DEBUG - 2022-05-30 01:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:56:56 --> Total execution time: 0.0302
DEBUG - 2022-05-30 01:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:10 --> Total execution time: 0.1421
DEBUG - 2022-05-30 01:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:25 --> Total execution time: 0.0643
DEBUG - 2022-05-30 01:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:29 --> Total execution time: 0.0449
DEBUG - 2022-05-30 01:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:43 --> Total execution time: 0.0463
DEBUG - 2022-05-30 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:58 --> Total execution time: 0.0431
DEBUG - 2022-05-30 01:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:03 --> Total execution time: 0.0321
DEBUG - 2022-05-30 01:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:08 --> Total execution time: 0.0443
DEBUG - 2022-05-30 01:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:13 --> Total execution time: 0.0322
DEBUG - 2022-05-30 01:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:21 --> Total execution time: 0.0436
DEBUG - 2022-05-30 01:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:25 --> Total execution time: 0.0404
DEBUG - 2022-05-30 01:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:39 --> Total execution time: 0.0318
DEBUG - 2022-05-30 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:52 --> Total execution time: 0.0399
DEBUG - 2022-05-30 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:28:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:52 --> Total execution time: 0.0617
DEBUG - 2022-05-30 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:59:05 --> Total execution time: 0.0831
DEBUG - 2022-05-30 01:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:29:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:59:29 --> Total execution time: 0.0484
DEBUG - 2022-05-30 01:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:29:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:59:42 --> Total execution time: 0.0310
DEBUG - 2022-05-30 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:30:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:00:36 --> Total execution time: 0.0333
DEBUG - 2022-05-30 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:30:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:00:36 --> Total execution time: 0.0219
DEBUG - 2022-05-30 01:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:13 --> Total execution time: 0.0312
DEBUG - 2022-05-30 01:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:19 --> Total execution time: 0.0927
DEBUG - 2022-05-30 01:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:24 --> Total execution time: 0.0365
DEBUG - 2022-05-30 01:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:30 --> Total execution time: 0.0399
DEBUG - 2022-05-30 01:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:33 --> Total execution time: 0.0732
DEBUG - 2022-05-30 01:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:43 --> Total execution time: 0.0348
DEBUG - 2022-05-30 01:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:49 --> Total execution time: 0.0382
DEBUG - 2022-05-30 01:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:01:52 --> Total execution time: 0.0393
DEBUG - 2022-05-30 01:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:03 --> Total execution time: 0.0949
DEBUG - 2022-05-30 01:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:06 --> Total execution time: 0.0738
DEBUG - 2022-05-30 01:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:32:07 --> Total execution time: 0.0355
DEBUG - 2022-05-30 01:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:11 --> Total execution time: 0.0439
DEBUG - 2022-05-30 01:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:32:14 --> Total execution time: 0.0218
DEBUG - 2022-05-30 01:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:18 --> Total execution time: 0.0287
DEBUG - 2022-05-30 01:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:32:19 --> Total execution time: 0.0254
DEBUG - 2022-05-30 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:22 --> Total execution time: 0.0359
DEBUG - 2022-05-30 01:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:24 --> Total execution time: 0.0284
DEBUG - 2022-05-30 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:26 --> Total execution time: 0.0389
DEBUG - 2022-05-30 01:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:33 --> Total execution time: 0.0336
DEBUG - 2022-05-30 01:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:35 --> Total execution time: 0.0399
DEBUG - 2022-05-30 01:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:38 --> Total execution time: 0.0249
DEBUG - 2022-05-30 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:50 --> Total execution time: 0.0306
DEBUG - 2022-05-30 01:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:52 --> Total execution time: 0.0556
DEBUG - 2022-05-30 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:56 --> Total execution time: 0.0307
DEBUG - 2022-05-30 01:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:57 --> Total execution time: 0.0292
DEBUG - 2022-05-30 01:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:59 --> Total execution time: 0.0320
DEBUG - 2022-05-30 01:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:03:02 --> Total execution time: 0.0902
DEBUG - 2022-05-30 01:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:03:35 --> Total execution time: 0.0317
DEBUG - 2022-05-30 01:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:03:37 --> Total execution time: 0.0316
DEBUG - 2022-05-30 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:03:38 --> Total execution time: 0.0277
DEBUG - 2022-05-30 01:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:03:41 --> Total execution time: 0.0321
DEBUG - 2022-05-30 01:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:03:45 --> Total execution time: 0.1007
DEBUG - 2022-05-30 01:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:04:12 --> Total execution time: 0.0623
DEBUG - 2022-05-30 01:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:34:47 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:04:47 --> Total execution time: 0.0233
DEBUG - 2022-05-30 01:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:35:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:05:22 --> Total execution time: 0.0211
DEBUG - 2022-05-30 01:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:05:54 --> Total execution time: 0.0497
DEBUG - 2022-05-30 01:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:06:03 --> Total execution time: 0.0469
DEBUG - 2022-05-30 01:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:36:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:06:55 --> Total execution time: 0.0219
DEBUG - 2022-05-30 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:37:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:07:00 --> Total execution time: 0.0216
DEBUG - 2022-05-30 01:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:07:19 --> Total execution time: 0.0481
DEBUG - 2022-05-30 01:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:07:33 --> Total execution time: 0.0319
DEBUG - 2022-05-30 01:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:09:29 --> Total execution time: 0.0346
DEBUG - 2022-05-30 01:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:09:54 --> Total execution time: 0.0293
DEBUG - 2022-05-30 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:41:50 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:50 --> Total execution time: 0.0359
DEBUG - 2022-05-30 01:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:44:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:14:41 --> Total execution time: 0.0953
DEBUG - 2022-05-30 01:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:14:45 --> Total execution time: 0.0265
DEBUG - 2022-05-30 01:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:14:54 --> Total execution time: 0.0425
DEBUG - 2022-05-30 01:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:14:59 --> Total execution time: 0.0373
DEBUG - 2022-05-30 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 01:45:00 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-30 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:15:09 --> Total execution time: 0.0325
DEBUG - 2022-05-30 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:45:13 --> Total execution time: 0.0276
DEBUG - 2022-05-30 01:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:15:16 --> Total execution time: 0.0325
DEBUG - 2022-05-30 01:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:00 --> Total execution time: 0.0326
DEBUG - 2022-05-30 01:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:10 --> Total execution time: 0.1344
DEBUG - 2022-05-30 01:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:34 --> Total execution time: 0.0738
DEBUG - 2022-05-30 01:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:37 --> Total execution time: 0.0778
DEBUG - 2022-05-30 01:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:42 --> Total execution time: 0.0860
DEBUG - 2022-05-30 01:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:47 --> Total execution time: 0.0288
DEBUG - 2022-05-30 01:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:49 --> Total execution time: 0.0651
DEBUG - 2022-05-30 01:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:50 --> Total execution time: 0.0770
DEBUG - 2022-05-30 01:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:59 --> Total execution time: 0.0282
DEBUG - 2022-05-30 01:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:41 --> Total execution time: 0.0326
DEBUG - 2022-05-30 01:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:44 --> Total execution time: 0.0363
DEBUG - 2022-05-30 01:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:51 --> Total execution time: 0.0532
DEBUG - 2022-05-30 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:53 --> Total execution time: 0.0317
DEBUG - 2022-05-30 01:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:56 --> Total execution time: 0.0354
DEBUG - 2022-05-30 01:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:19:00 --> Total execution time: 0.0447
DEBUG - 2022-05-30 01:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:19:16 --> Total execution time: 0.0263
DEBUG - 2022-05-30 01:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:19:59 --> Total execution time: 0.0244
DEBUG - 2022-05-30 01:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:20:00 --> Total execution time: 0.0291
DEBUG - 2022-05-30 01:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:50:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:20:01 --> Total execution time: 0.0627
DEBUG - 2022-05-30 01:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:23:19 --> Total execution time: 0.0797
DEBUG - 2022-05-30 01:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:23:23 --> Total execution time: 0.0522
DEBUG - 2022-05-30 01:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:24:16 --> Total execution time: 0.0909
DEBUG - 2022-05-30 01:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:24:17 --> Total execution time: 0.0274
DEBUG - 2022-05-30 01:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:55:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:25:42 --> Total execution time: 0.0297
DEBUG - 2022-05-30 01:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:25:43 --> Total execution time: 0.0246
DEBUG - 2022-05-30 01:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 01:56:10 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-05-30 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:27:09 --> Total execution time: 0.0258
DEBUG - 2022-05-30 01:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:57:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:27:38 --> Total execution time: 0.0352
DEBUG - 2022-05-30 01:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:27:41 --> Total execution time: 0.0327
DEBUG - 2022-05-30 01:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:27:49 --> Total execution time: 0.0382
DEBUG - 2022-05-30 01:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:28:30 --> Total execution time: 0.0365
DEBUG - 2022-05-30 01:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:28:40 --> Total execution time: 0.0537
DEBUG - 2022-05-30 01:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:28:42 --> Total execution time: 0.0368
DEBUG - 2022-05-30 01:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 01:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:28:49 --> Total execution time: 0.0340
DEBUG - 2022-05-30 01:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:58:52 --> Total execution time: 0.0211
DEBUG - 2022-05-30 01:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:28:52 --> Total execution time: 0.0176
DEBUG - 2022-05-30 01:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:58:53 --> Total execution time: 0.0450
DEBUG - 2022-05-30 01:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 01:58:53 --> Total execution time: 0.0544
DEBUG - 2022-05-30 01:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:28:59 --> Total execution time: 0.0296
DEBUG - 2022-05-30 01:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 01:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:29:00 --> Total execution time: 0.0291
DEBUG - 2022-05-30 01:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 01:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 01:59:48 --> 404 Page Not Found: Summer-course-starts-from-june/index
DEBUG - 2022-05-30 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:30:03 --> Total execution time: 0.0449
DEBUG - 2022-05-30 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:02:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:32:36 --> Total execution time: 0.0864
DEBUG - 2022-05-30 02:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:32:48 --> Total execution time: 0.0260
DEBUG - 2022-05-30 02:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:33:21 --> Total execution time: 0.0298
DEBUG - 2022-05-30 02:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:33:51 --> Total execution time: 0.0355
DEBUG - 2022-05-30 02:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:33:58 --> Total execution time: 0.0504
DEBUG - 2022-05-30 02:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:33:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 02:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:33:59 --> Total execution time: 0.0315
DEBUG - 2022-05-30 02:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:34:26 --> Total execution time: 0.0192
DEBUG - 2022-05-30 02:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:35:28 --> Total execution time: 0.0307
DEBUG - 2022-05-30 02:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:36:41 --> Total execution time: 0.0260
DEBUG - 2022-05-30 02:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:36:43 --> Total execution time: 0.0414
DEBUG - 2022-05-30 02:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:06:55 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-05-30 02:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:06:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 02:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:08 --> Total execution time: 0.0789
DEBUG - 2022-05-30 02:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:17 --> Total execution time: 0.0433
DEBUG - 2022-05-30 02:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:45 --> Total execution time: 0.0450
DEBUG - 2022-05-30 02:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:49 --> Total execution time: 0.0350
DEBUG - 2022-05-30 02:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:53 --> Total execution time: 0.0303
DEBUG - 2022-05-30 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:56 --> Total execution time: 0.0289
DEBUG - 2022-05-30 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:00 --> Total execution time: 0.0300
DEBUG - 2022-05-30 02:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:01 --> Total execution time: 0.1368
DEBUG - 2022-05-30 02:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 02:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:37 --> Total execution time: 0.0768
DEBUG - 2022-05-30 02:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:38 --> Total execution time: 0.0692
DEBUG - 2022-05-30 02:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:43 --> Total execution time: 0.0843
DEBUG - 2022-05-30 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:47 --> Total execution time: 0.0497
DEBUG - 2022-05-30 02:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:39:52 --> Total execution time: 0.0597
DEBUG - 2022-05-30 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:40:01 --> Total execution time: 0.0467
DEBUG - 2022-05-30 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:40:12 --> Total execution time: 0.0376
DEBUG - 2022-05-30 02:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:17 --> Total execution time: 0.0884
DEBUG - 2022-05-30 02:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:21 --> Total execution time: 0.0210
DEBUG - 2022-05-30 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:24 --> Total execution time: 0.0424
DEBUG - 2022-05-30 02:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:26 --> Total execution time: 0.0386
DEBUG - 2022-05-30 02:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:30 --> Total execution time: 0.0526
DEBUG - 2022-05-30 02:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:31 --> Total execution time: 0.0584
DEBUG - 2022-05-30 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:31 --> Total execution time: 0.0678
DEBUG - 2022-05-30 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:33 --> Total execution time: 0.0376
DEBUG - 2022-05-30 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:33 --> Total execution time: 0.0455
DEBUG - 2022-05-30 02:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:35 --> Total execution time: 0.0887
DEBUG - 2022-05-30 02:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:44 --> Total execution time: 0.0718
DEBUG - 2022-05-30 02:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:47 --> Total execution time: 0.0273
DEBUG - 2022-05-30 02:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:50 --> Total execution time: 0.0248
DEBUG - 2022-05-30 02:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:52 --> Total execution time: 0.0298
DEBUG - 2022-05-30 02:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:56 --> Total execution time: 0.0308
DEBUG - 2022-05-30 02:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:42:59 --> Total execution time: 0.0565
DEBUG - 2022-05-30 02:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:13:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:43:01 --> Total execution time: 0.0401
DEBUG - 2022-05-30 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:44:06 --> Total execution time: 0.0275
DEBUG - 2022-05-30 02:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:44:20 --> Total execution time: 0.0317
DEBUG - 2022-05-30 02:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:44:33 --> Total execution time: 0.0384
DEBUG - 2022-05-30 02:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:44:47 --> Total execution time: 0.0485
DEBUG - 2022-05-30 02:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:45:24 --> Total execution time: 0.0433
DEBUG - 2022-05-30 02:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:19:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:49:04 --> Total execution time: 0.1827
DEBUG - 2022-05-30 02:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:19:42 --> Total execution time: 0.0434
DEBUG - 2022-05-30 02:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:19:53 --> Total execution time: 0.0713
DEBUG - 2022-05-30 02:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:51:31 --> Total execution time: 0.0918
DEBUG - 2022-05-30 02:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:21:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:51:34 --> Total execution time: 0.0681
DEBUG - 2022-05-30 02:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:51:38 --> Total execution time: 0.0568
DEBUG - 2022-05-30 02:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:51:54 --> Total execution time: 0.0248
DEBUG - 2022-05-30 02:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:52:07 --> Total execution time: 0.0274
DEBUG - 2022-05-30 02:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:52:22 --> Total execution time: 0.0436
DEBUG - 2022-05-30 02:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:52:42 --> Total execution time: 0.0618
DEBUG - 2022-05-30 02:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:52:45 --> Total execution time: 0.0603
DEBUG - 2022-05-30 02:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:22:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:52:54 --> Total execution time: 0.0363
DEBUG - 2022-05-30 02:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 02:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:05 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:05 --> Total execution time: 0.0317
DEBUG - 2022-05-30 12:53:05 --> Total execution time: 0.0723
DEBUG - 2022-05-30 02:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:20 --> Total execution time: 1.5309
DEBUG - 2022-05-30 02:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:22 --> Total execution time: 0.0696
DEBUG - 2022-05-30 02:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:23:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 02:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:25 --> Total execution time: 0.0616
DEBUG - 2022-05-30 02:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:28 --> Total execution time: 0.0586
DEBUG - 2022-05-30 02:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:50 --> Total execution time: 0.0726
DEBUG - 2022-05-30 02:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:53:58 --> Total execution time: 0.1350
DEBUG - 2022-05-30 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:55:06 --> Total execution time: 1.5342
DEBUG - 2022-05-30 02:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:25:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:55:12 --> Total execution time: 0.0372
DEBUG - 2022-05-30 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:25:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:55:17 --> Total execution time: 0.0400
DEBUG - 2022-05-30 02:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:25:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:55:43 --> Total execution time: 0.0258
DEBUG - 2022-05-30 02:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:27:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:57:38 --> Total execution time: 0.0306
DEBUG - 2022-05-30 02:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:57:59 --> Total execution time: 0.0318
DEBUG - 2022-05-30 02:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:58:00 --> Total execution time: 0.0259
DEBUG - 2022-05-30 02:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:58:11 --> Total execution time: 0.0275
DEBUG - 2022-05-30 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:58:13 --> Total execution time: 0.0320
DEBUG - 2022-05-30 02:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:58:19 --> Total execution time: 0.0303
DEBUG - 2022-05-30 02:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:58:34 --> Total execution time: 0.0379
DEBUG - 2022-05-30 02:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:58:45 --> Total execution time: 0.0565
DEBUG - 2022-05-30 02:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:59:00 --> Total execution time: 0.0311
DEBUG - 2022-05-30 02:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:59:05 --> Total execution time: 0.0299
DEBUG - 2022-05-30 02:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:29:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:59:17 --> Total execution time: 0.0267
DEBUG - 2022-05-30 02:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:59:57 --> Total execution time: 1.4818
DEBUG - 2022-05-30 02:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:30:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:30:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 02:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:30:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:00:19 --> Total execution time: 0.0304
DEBUG - 2022-05-30 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:31:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:01:11 --> Total execution time: 0.0298
DEBUG - 2022-05-30 02:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:31:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:01:24 --> Total execution time: 0.0253
DEBUG - 2022-05-30 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:31:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:01:43 --> Total execution time: 0.0212
DEBUG - 2022-05-30 02:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:31:45 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:01:45 --> Total execution time: 0.0301
DEBUG - 2022-05-30 02:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:01:53 --> Total execution time: 0.0221
DEBUG - 2022-05-30 02:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:03:28 --> Total execution time: 0.0261
DEBUG - 2022-05-30 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:33:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:03:41 --> Total execution time: 0.0209
DEBUG - 2022-05-30 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:04:34 --> Total execution time: 0.0327
DEBUG - 2022-05-30 02:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:04:57 --> Total execution time: 0.0779
DEBUG - 2022-05-30 02:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:04:58 --> Total execution time: 0.0276
DEBUG - 2022-05-30 02:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:07 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:07 --> Total execution time: 0.0808
DEBUG - 2022-05-30 02:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:08 --> Total execution time: 0.0504
DEBUG - 2022-05-30 02:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:15 --> Total execution time: 0.0281
DEBUG - 2022-05-30 02:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:22 --> Total execution time: 0.0270
DEBUG - 2022-05-30 02:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:26 --> Total execution time: 0.0260
DEBUG - 2022-05-30 02:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:29 --> Total execution time: 0.0287
DEBUG - 2022-05-30 02:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:32 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:32 --> Total execution time: 0.0269
DEBUG - 2022-05-30 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:42 --> Total execution time: 0.0290
DEBUG - 2022-05-30 02:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:05:47 --> Total execution time: 0.0472
DEBUG - 2022-05-30 02:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:04 --> Total execution time: 0.0298
DEBUG - 2022-05-30 02:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:12 --> Total execution time: 0.0366
DEBUG - 2022-05-30 02:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:13 --> Total execution time: 0.0361
DEBUG - 2022-05-30 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:14 --> Total execution time: 0.0261
DEBUG - 2022-05-30 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:14 --> Total execution time: 0.0252
DEBUG - 2022-05-30 02:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:17 --> Total execution time: 0.0241
DEBUG - 2022-05-30 02:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:31 --> Total execution time: 0.0353
DEBUG - 2022-05-30 02:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:36:33 --> Total execution time: 0.0262
DEBUG - 2022-05-30 02:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:36:35 --> Total execution time: 0.0304
DEBUG - 2022-05-30 02:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:36:35 --> Total execution time: 0.0559
DEBUG - 2022-05-30 02:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:06:57 --> Total execution time: 0.0361
DEBUG - 2022-05-30 02:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:01 --> Total execution time: 0.0509
DEBUG - 2022-05-30 02:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:09 --> Total execution time: 0.0329
DEBUG - 2022-05-30 02:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:22 --> Total execution time: 0.0264
DEBUG - 2022-05-30 02:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:23 --> Total execution time: 0.0264
DEBUG - 2022-05-30 02:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:26 --> Total execution time: 0.0487
DEBUG - 2022-05-30 02:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:31 --> Total execution time: 0.0246
DEBUG - 2022-05-30 02:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:32 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:32 --> Total execution time: 0.0202
DEBUG - 2022-05-30 02:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:34 --> Total execution time: 0.0625
DEBUG - 2022-05-30 02:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:43 --> Total execution time: 0.0561
DEBUG - 2022-05-30 02:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:07:53 --> Total execution time: 0.0267
DEBUG - 2022-05-30 02:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:08:04 --> Total execution time: 0.0360
DEBUG - 2022-05-30 02:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:08:12 --> Total execution time: 0.0416
DEBUG - 2022-05-30 02:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:08:46 --> Total execution time: 0.0273
DEBUG - 2022-05-30 02:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:08:54 --> Total execution time: 0.0300
DEBUG - 2022-05-30 02:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:09:10 --> Total execution time: 0.0364
DEBUG - 2022-05-30 02:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:11:12 --> Total execution time: 0.0819
DEBUG - 2022-05-30 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:11:19 --> Total execution time: 0.0352
DEBUG - 2022-05-30 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:41:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:11:35 --> Total execution time: 0.0234
DEBUG - 2022-05-30 02:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:41:48 --> Total execution time: 0.0441
DEBUG - 2022-05-30 02:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:41:52 --> Total execution time: 0.0467
DEBUG - 2022-05-30 02:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:41:52 --> Total execution time: 0.0704
DEBUG - 2022-05-30 02:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:12:52 --> Total execution time: 0.0377
DEBUG - 2022-05-30 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:13:01 --> Total execution time: 0.0414
DEBUG - 2022-05-30 02:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:43:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 02:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:13:32 --> Total execution time: 0.1024
DEBUG - 2022-05-30 13:13:32 --> Total execution time: 1.7706
DEBUG - 2022-05-30 02:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:43:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 02:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:13:40 --> Total execution time: 0.0655
DEBUG - 2022-05-30 02:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:13:57 --> Total execution time: 0.0606
DEBUG - 2022-05-30 02:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:15:03 --> Total execution time: 0.0269
DEBUG - 2022-05-30 02:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:16:32 --> Total execution time: 0.0365
DEBUG - 2022-05-30 02:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:46:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:16:40 --> Total execution time: 0.0237
DEBUG - 2022-05-30 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:16:49 --> Total execution time: 0.0265
DEBUG - 2022-05-30 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:48:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:18:23 --> Total execution time: 0.0233
DEBUG - 2022-05-30 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:19:25 --> Total execution time: 0.0252
DEBUG - 2022-05-30 02:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:19:29 --> Total execution time: 0.0257
DEBUG - 2022-05-30 02:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:19:31 --> Total execution time: 0.0285
DEBUG - 2022-05-30 02:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:19:45 --> Total execution time: 0.0344
DEBUG - 2022-05-30 02:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:19:49 --> Total execution time: 0.0297
DEBUG - 2022-05-30 02:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:19:53 --> Total execution time: 0.0405
DEBUG - 2022-05-30 02:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:20:03 --> Total execution time: 0.0556
DEBUG - 2022-05-30 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:20:05 --> Total execution time: 0.0341
DEBUG - 2022-05-30 02:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:20:13 --> Total execution time: 4.3555
DEBUG - 2022-05-30 02:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:50:42 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:50:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:50:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:50:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:20:59 --> Total execution time: 0.0388
DEBUG - 2022-05-30 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:51:01 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:51:01 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:51:01 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:01 --> UTF-8 Support Enabled
ERROR - 2022-05-30 02:51:01 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:51:01 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:05 --> Total execution time: 0.0285
DEBUG - 2022-05-30 02:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 02:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:29 --> Total execution time: 0.0487
DEBUG - 2022-05-30 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:36 --> Total execution time: 0.0342
DEBUG - 2022-05-30 02:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:40 --> Total execution time: 0.0249
DEBUG - 2022-05-30 02:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:51 --> Total execution time: 0.0279
DEBUG - 2022-05-30 02:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 02:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:55 --> Total execution time: 0.0274
DEBUG - 2022-05-30 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:51:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-30 13:21:56 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-05-30 13:21:56 --> Total execution time: 0.0388
DEBUG - 2022-05-30 02:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:22:00 --> Total execution time: 0.0355
DEBUG - 2022-05-30 02:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:22:09 --> Total execution time: 0.0424
DEBUG - 2022-05-30 13:22:12 --> Total execution time: 4.4417
DEBUG - 2022-05-30 02:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:52:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:22:16 --> Total execution time: 0.0432
DEBUG - 2022-05-30 02:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 02:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:22:17 --> Total execution time: 0.0283
DEBUG - 2022-05-30 02:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:52:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:22:23 --> Total execution time: 0.0377
DEBUG - 2022-05-30 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:52:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:52:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:52:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:52:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:22:33 --> Total execution time: 0.0255
DEBUG - 2022-05-30 02:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:53:34 --> UTF-8 Support Enabled
ERROR - 2022-05-30 02:53:34 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:53:34 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:53:34 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 02:54:26 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 02:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 02:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:25:43 --> Total execution time: 0.0690
DEBUG - 2022-05-30 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:30:03 --> Total execution time: 0.1397
DEBUG - 2022-05-30 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:34:41 --> Total execution time: 0.0328
DEBUG - 2022-05-30 03:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:35:24 --> Total execution time: 0.0260
DEBUG - 2022-05-30 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:43:44 --> Total execution time: 0.1139
DEBUG - 2022-05-30 03:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:43:52 --> Total execution time: 0.0509
DEBUG - 2022-05-30 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:43:55 --> Total execution time: 0.0599
DEBUG - 2022-05-30 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:44:03 --> Total execution time: 0.0306
DEBUG - 2022-05-30 03:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:44:09 --> Total execution time: 0.0937
DEBUG - 2022-05-30 03:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:44:27 --> Total execution time: 0.0308
DEBUG - 2022-05-30 03:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:44:29 --> Total execution time: 0.0296
DEBUG - 2022-05-30 03:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:47:11 --> Total execution time: 0.0849
DEBUG - 2022-05-30 03:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:56:53 --> Total execution time: 0.2387
DEBUG - 2022-05-30 03:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:00:14 --> Total execution time: 0.1689
DEBUG - 2022-05-30 03:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:01:28 --> Total execution time: 0.0627
DEBUG - 2022-05-30 03:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:32:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:02:19 --> Total execution time: 0.0291
DEBUG - 2022-05-30 03:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:02:32 --> Total execution time: 0.0633
DEBUG - 2022-05-30 03:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:02:41 --> Total execution time: 0.0313
DEBUG - 2022-05-30 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:02:51 --> Total execution time: 0.0625
DEBUG - 2022-05-30 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:35:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:05:09 --> Total execution time: 0.0729
DEBUG - 2022-05-30 03:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:37 --> Total execution time: 0.0247
DEBUG - 2022-05-30 03:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:38:16 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:08:16 --> Total execution time: 0.0233
DEBUG - 2022-05-30 03:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:38:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:08:19 --> Total execution time: 0.0225
DEBUG - 2022-05-30 03:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:38:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:08:22 --> Total execution time: 0.0314
DEBUG - 2022-05-30 03:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:11:00 --> Total execution time: 0.1051
DEBUG - 2022-05-30 03:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:11:28 --> Total execution time: 0.0334
DEBUG - 2022-05-30 03:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:11:44 --> Total execution time: 0.0234
DEBUG - 2022-05-30 03:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:11:52 --> Total execution time: 0.0577
DEBUG - 2022-05-30 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:02 --> Total execution time: 0.0398
DEBUG - 2022-05-30 03:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:09 --> Total execution time: 0.0282
DEBUG - 2022-05-30 03:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 03:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:10 --> Total execution time: 0.0196
DEBUG - 2022-05-30 03:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:15 --> Total execution time: 0.0485
DEBUG - 2022-05-30 03:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:19 --> Total execution time: 0.0393
DEBUG - 2022-05-30 03:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:27 --> Total execution time: 0.0417
DEBUG - 2022-05-30 03:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:32 --> Total execution time: 0.0244
DEBUG - 2022-05-30 03:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:33 --> Total execution time: 0.0233
DEBUG - 2022-05-30 03:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:34 --> Total execution time: 0.0232
DEBUG - 2022-05-30 03:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:35 --> Total execution time: 0.0286
DEBUG - 2022-05-30 03:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:35 --> Total execution time: 0.0257
DEBUG - 2022-05-30 03:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:38 --> Total execution time: 0.0436
DEBUG - 2022-05-30 03:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:39 --> Total execution time: 0.0382
DEBUG - 2022-05-30 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:40 --> Total execution time: 0.0287
DEBUG - 2022-05-30 03:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:12:56 --> Total execution time: 0.0351
DEBUG - 2022-05-30 03:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:44:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:14:31 --> Total execution time: 0.0300
DEBUG - 2022-05-30 03:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:14:33 --> Total execution time: 0.0690
DEBUG - 2022-05-30 03:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:15:58 --> Total execution time: 0.0293
DEBUG - 2022-05-30 03:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:01 --> Total execution time: 0.0335
DEBUG - 2022-05-30 03:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:07 --> Total execution time: 0.0399
DEBUG - 2022-05-30 03:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:13 --> Total execution time: 0.0212
DEBUG - 2022-05-30 03:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:14 --> Total execution time: 0.0212
DEBUG - 2022-05-30 03:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:16 --> Total execution time: 0.0207
DEBUG - 2022-05-30 03:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:20 --> Total execution time: 0.0403
DEBUG - 2022-05-30 03:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:39 --> Total execution time: 0.0771
DEBUG - 2022-05-30 03:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:46 --> Total execution time: 0.0939
DEBUG - 2022-05-30 03:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:17:09 --> Total execution time: 0.0590
DEBUG - 2022-05-30 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:17:28 --> Total execution time: 0.0278
DEBUG - 2022-05-30 03:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:17:34 --> Total execution time: 0.0335
DEBUG - 2022-05-30 03:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:18:06 --> Total execution time: 0.1287
DEBUG - 2022-05-30 03:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:48:21 --> Total execution time: 0.0265
DEBUG - 2022-05-30 03:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:18:37 --> Total execution time: 0.0243
DEBUG - 2022-05-30 03:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:49:57 --> Total execution time: 0.0518
DEBUG - 2022-05-30 03:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:19:57 --> Total execution time: 0.0481
DEBUG - 2022-05-30 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:20:17 --> Total execution time: 0.0292
DEBUG - 2022-05-30 03:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:20:48 --> Total execution time: 0.0675
DEBUG - 2022-05-30 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:20:51 --> Total execution time: 0.0283
DEBUG - 2022-05-30 03:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:20:56 --> Total execution time: 0.0280
DEBUG - 2022-05-30 03:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:21:20 --> Total execution time: 0.0750
DEBUG - 2022-05-30 03:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:21:23 --> Total execution time: 0.0281
DEBUG - 2022-05-30 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:21:30 --> Total execution time: 0.0562
DEBUG - 2022-05-30 03:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:21:33 --> Total execution time: 0.0422
DEBUG - 2022-05-30 03:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:21:54 --> Total execution time: 0.0285
DEBUG - 2022-05-30 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:20 --> Total execution time: 0.0896
DEBUG - 2022-05-30 03:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:21 --> Total execution time: 0.0308
DEBUG - 2022-05-30 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:22 --> Total execution time: 0.0566
DEBUG - 2022-05-30 03:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:24 --> Total execution time: 0.0386
DEBUG - 2022-05-30 03:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:26 --> Total execution time: 0.0329
DEBUG - 2022-05-30 03:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:27 --> Total execution time: 0.0325
DEBUG - 2022-05-30 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:52:30 --> Total execution time: 0.0246
DEBUG - 2022-05-30 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:32 --> Total execution time: 0.0331
DEBUG - 2022-05-30 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:33 --> Total execution time: 0.0325
DEBUG - 2022-05-30 03:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:36 --> Total execution time: 0.0301
DEBUG - 2022-05-30 03:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:40 --> Total execution time: 0.0292
DEBUG - 2022-05-30 03:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:43 --> Total execution time: 0.0393
DEBUG - 2022-05-30 03:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:47 --> Total execution time: 0.0296
DEBUG - 2022-05-30 03:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:49 --> Total execution time: 0.0192
DEBUG - 2022-05-30 03:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:52:50 --> Total execution time: 0.0279
DEBUG - 2022-05-30 03:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:52 --> Total execution time: 0.0287
DEBUG - 2022-05-30 03:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:03 --> Total execution time: 0.0376
DEBUG - 2022-05-30 03:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:05 --> Total execution time: 0.0388
DEBUG - 2022-05-30 03:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:07 --> Total execution time: 0.0322
DEBUG - 2022-05-30 03:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:10 --> Total execution time: 0.0392
DEBUG - 2022-05-30 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:12 --> Total execution time: 0.0318
DEBUG - 2022-05-30 03:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:18 --> Total execution time: 0.0264
DEBUG - 2022-05-30 03:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:24 --> Total execution time: 0.0484
DEBUG - 2022-05-30 03:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:35 --> Total execution time: 0.0257
DEBUG - 2022-05-30 03:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:41 --> Total execution time: 0.0508
DEBUG - 2022-05-30 03:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:44 --> Total execution time: 0.0267
DEBUG - 2022-05-30 03:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:44 --> Total execution time: 0.0328
DEBUG - 2022-05-30 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:04 --> Total execution time: 0.0375
DEBUG - 2022-05-30 03:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:08 --> Total execution time: 0.0421
DEBUG - 2022-05-30 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:22 --> Total execution time: 0.0286
DEBUG - 2022-05-30 03:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:24 --> Total execution time: 0.0292
DEBUG - 2022-05-30 03:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:28 --> Total execution time: 0.0318
DEBUG - 2022-05-30 03:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:53 --> Total execution time: 0.0254
DEBUG - 2022-05-30 03:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:55 --> Total execution time: 0.0337
DEBUG - 2022-05-30 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:24:56 --> Total execution time: 0.0281
DEBUG - 2022-05-30 03:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:00 --> Total execution time: 0.0283
DEBUG - 2022-05-30 03:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:56:03 --> No URI present. Default controller set.
DEBUG - 2022-05-30 03:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:26:03 --> Total execution time: 0.0261
DEBUG - 2022-05-30 03:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 03:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:28:30 --> Total execution time: 0.0420
DEBUG - 2022-05-30 03:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:23 --> Total execution time: 0.0401
DEBUG - 2022-05-30 03:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:51 --> Total execution time: 0.0546
DEBUG - 2022-05-30 03:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 03:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 03:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:54 --> Total execution time: 0.0298
DEBUG - 2022-05-30 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:02 --> Total execution time: 0.0534
DEBUG - 2022-05-30 04:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:00:05 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:06 --> Total execution time: 0.0826
DEBUG - 2022-05-30 04:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:00:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:18 --> Total execution time: 0.0273
DEBUG - 2022-05-30 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:55 --> Total execution time: 0.0331
DEBUG - 2022-05-30 04:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:32:11 --> Total execution time: 0.0351
DEBUG - 2022-05-30 04:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:32:14 --> Total execution time: 0.0584
DEBUG - 2022-05-30 04:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:32:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 04:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:32:20 --> Total execution time: 0.0260
DEBUG - 2022-05-30 04:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:33:37 --> Total execution time: 0.0909
DEBUG - 2022-05-30 04:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:33:44 --> Total execution time: 0.0333
DEBUG - 2022-05-30 04:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:35:00 --> Total execution time: 0.0354
DEBUG - 2022-05-30 04:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:35:25 --> Total execution time: 0.0244
DEBUG - 2022-05-30 04:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:36:00 --> Total execution time: 0.0364
DEBUG - 2022-05-30 04:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:36:52 --> Total execution time: 0.0288
DEBUG - 2022-05-30 04:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:36:55 --> Total execution time: 0.0303
DEBUG - 2022-05-30 04:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:39:31 --> Total execution time: 0.0290
DEBUG - 2022-05-30 04:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:39:40 --> Total execution time: 0.0309
DEBUG - 2022-05-30 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:09:51 --> Total execution time: 0.0274
DEBUG - 2022-05-30 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:09:52 --> Total execution time: 0.0606
DEBUG - 2022-05-30 04:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:09:52 --> Total execution time: 0.0867
DEBUG - 2022-05-30 04:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:39:53 --> Total execution time: 0.0324
DEBUG - 2022-05-30 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:40:13 --> Total execution time: 0.0541
DEBUG - 2022-05-30 04:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:40:16 --> Total execution time: 0.0316
DEBUG - 2022-05-30 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:10:40 --> 404 Page Not Found: Course/premium-level-program
DEBUG - 2022-05-30 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:40:55 --> Total execution time: 0.0410
DEBUG - 2022-05-30 04:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:40:57 --> Total execution time: 0.0354
DEBUG - 2022-05-30 04:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:11:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 04:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:41:11 --> Total execution time: 1.5227
DEBUG - 2022-05-30 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:11:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 04:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:41:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 04:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:41:49 --> Total execution time: 0.0276
DEBUG - 2022-05-30 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:41:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 14:41:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 14:41:50 --> Total execution time: 0.1532
DEBUG - 2022-05-30 04:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:42:38 --> Total execution time: 0.0258
DEBUG - 2022-05-30 04:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:43:56 --> Total execution time: 0.0290
DEBUG - 2022-05-30 04:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:45:37 --> Total execution time: 0.0316
DEBUG - 2022-05-30 04:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:45:57 --> Total execution time: 0.0298
DEBUG - 2022-05-30 04:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:17:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:47:54 --> Total execution time: 0.0266
DEBUG - 2022-05-30 04:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:20:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:50:01 --> Total execution time: 0.0331
DEBUG - 2022-05-30 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:20:10 --> 404 Page Not Found: Wp-sitemapxml/index
DEBUG - 2022-05-30 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:50:30 --> Total execution time: 0.0187
DEBUG - 2022-05-30 04:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:50:55 --> Total execution time: 0.0281
DEBUG - 2022-05-30 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:22:01 --> 404 Page Not Found: Course/premium-level-program
DEBUG - 2022-05-30 04:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:54:29 --> Total execution time: 0.0429
DEBUG - 2022-05-30 04:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:54:30 --> Total execution time: 0.0286
DEBUG - 2022-05-30 04:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:54:33 --> Total execution time: 0.0308
DEBUG - 2022-05-30 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:54:47 --> Total execution time: 0.0456
DEBUG - 2022-05-30 04:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:54:48 --> Total execution time: 0.0283
DEBUG - 2022-05-30 04:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:55:17 --> Total execution time: 0.0245
DEBUG - 2022-05-30 14:55:17 --> Total execution time: 0.0260
DEBUG - 2022-05-30 04:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:20 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:55:20 --> Total execution time: 0.0202
DEBUG - 2022-05-30 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:55:27 --> Total execution time: 0.0463
DEBUG - 2022-05-30 04:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:25:32 --> Total execution time: 0.0278
DEBUG - 2022-05-30 04:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:36 --> Total execution time: 0.0302
DEBUG - 2022-05-30 04:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:25:36 --> Total execution time: 0.0320
DEBUG - 2022-05-30 04:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:55:46 --> Total execution time: 0.0282
DEBUG - 2022-05-30 04:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:04 --> Total execution time: 0.0213
DEBUG - 2022-05-30 04:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:08 --> Total execution time: 0.0338
DEBUG - 2022-05-30 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:17 --> Total execution time: 0.0361
DEBUG - 2022-05-30 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:22 --> Total execution time: 0.0355
DEBUG - 2022-05-30 04:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:25 --> Total execution time: 0.0369
DEBUG - 2022-05-30 04:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:29 --> Total execution time: 0.0401
DEBUG - 2022-05-30 04:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:31 --> Total execution time: 0.0428
DEBUG - 2022-05-30 04:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:56:40 --> Total execution time: 0.0454
DEBUG - 2022-05-30 04:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:27:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:57:18 --> Total execution time: 0.0316
DEBUG - 2022-05-30 04:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:57:49 --> Total execution time: 0.0261
DEBUG - 2022-05-30 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:29:03 --> Total execution time: 0.0331
DEBUG - 2022-05-30 04:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:29:04 --> Total execution time: 0.0271
DEBUG - 2022-05-30 04:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:29:05 --> Total execution time: 0.0489
DEBUG - 2022-05-30 04:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:59:21 --> Total execution time: 0.0289
DEBUG - 2022-05-30 04:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:00:00 --> Total execution time: 0.0227
DEBUG - 2022-05-30 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:05 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:00:05 --> Total execution time: 0.0413
DEBUG - 2022-05-30 04:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:00:29 --> Total execution time: 0.0233
DEBUG - 2022-05-30 04:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:00:32 --> Total execution time: 0.0582
DEBUG - 2022-05-30 04:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:37 --> Total execution time: 0.0391
DEBUG - 2022-05-30 04:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:38 --> Total execution time: 0.0368
DEBUG - 2022-05-30 04:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:38 --> Total execution time: 0.0605
DEBUG - 2022-05-30 04:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:41 --> Total execution time: 0.0259
DEBUG - 2022-05-30 04:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:42 --> Total execution time: 0.0265
DEBUG - 2022-05-30 04:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:42 --> Total execution time: 0.0393
DEBUG - 2022-05-30 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:00:44 --> Total execution time: 0.0612
DEBUG - 2022-05-30 04:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:52 --> Total execution time: 0.0260
DEBUG - 2022-05-30 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:53 --> Total execution time: 0.0428
DEBUG - 2022-05-30 04:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:30:53 --> Total execution time: 0.0527
DEBUG - 2022-05-30 04:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:31:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:01:11 --> Total execution time: 0.0338
DEBUG - 2022-05-30 04:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:01:17 --> Total execution time: 4.5198
DEBUG - 2022-05-30 04:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:31:20 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:02:40 --> Total execution time: 0.0260
DEBUG - 2022-05-30 04:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:02:41 --> Total execution time: 0.0339
DEBUG - 2022-05-30 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:02:48 --> Total execution time: 0.0245
DEBUG - 2022-05-30 04:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:33:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:33:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:33:14 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:33:15 --> 404 Page Not Found: Lessons/pre-written-ads-8
DEBUG - 2022-05-30 04:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:33:51 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:34:54 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:34:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:35:07 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:35:07 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:35:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:35:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:35:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 04:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:09:18 --> Total execution time: 0.1028
DEBUG - 2022-05-30 04:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:09:26 --> Total execution time: 0.0404
DEBUG - 2022-05-30 04:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:10:12 --> Total execution time: 0.0565
DEBUG - 2022-05-30 04:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:11:15 --> Total execution time: 0.0383
DEBUG - 2022-05-30 04:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:11:23 --> Total execution time: 0.0323
DEBUG - 2022-05-30 04:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:47:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:17:31 --> Total execution time: 0.1951
DEBUG - 2022-05-30 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:17:53 --> Total execution time: 0.0559
DEBUG - 2022-05-30 04:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:48:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:18:01 --> Total execution time: 0.0417
DEBUG - 2022-05-30 04:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:18:04 --> Total execution time: 0.0312
DEBUG - 2022-05-30 04:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:18:17 --> Total execution time: 0.0260
DEBUG - 2022-05-30 04:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:18:58 --> Total execution time: 0.0399
DEBUG - 2022-05-30 04:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:19:15 --> Total execution time: 0.0293
DEBUG - 2022-05-30 04:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:19:19 --> Total execution time: 0.0374
DEBUG - 2022-05-30 04:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:19:30 --> Total execution time: 0.0277
DEBUG - 2022-05-30 04:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:19:35 --> Total execution time: 0.0543
DEBUG - 2022-05-30 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:50:10 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:20:10 --> Total execution time: 0.0571
DEBUG - 2022-05-30 04:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:20:11 --> Total execution time: 0.0360
DEBUG - 2022-05-30 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:09 --> Total execution time: 0.0306
DEBUG - 2022-05-30 04:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:14 --> Total execution time: 0.0438
DEBUG - 2022-05-30 04:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:17 --> Total execution time: 0.0327
DEBUG - 2022-05-30 04:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:22 --> Total execution time: 0.0422
DEBUG - 2022-05-30 04:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:24 --> Total execution time: 0.0275
DEBUG - 2022-05-30 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:27 --> Total execution time: 0.0329
DEBUG - 2022-05-30 04:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:36 --> Total execution time: 0.0397
DEBUG - 2022-05-30 04:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:46 --> Total execution time: 0.0416
DEBUG - 2022-05-30 04:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:21:55 --> Total execution time: 0.0288
DEBUG - 2022-05-30 04:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:09 --> Total execution time: 0.0363
DEBUG - 2022-05-30 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:12 --> Total execution time: 0.0291
DEBUG - 2022-05-30 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:13 --> Total execution time: 0.0218
DEBUG - 2022-05-30 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:26 --> Total execution time: 0.0242
DEBUG - 2022-05-30 04:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:35 --> Total execution time: 0.0235
DEBUG - 2022-05-30 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:42 --> Total execution time: 0.0277
DEBUG - 2022-05-30 04:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:52:52 --> 404 Page Not Found: Login/index
DEBUG - 2022-05-30 04:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:52 --> Total execution time: 0.0322
DEBUG - 2022-05-30 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 04:52:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:54 --> Total execution time: 0.0226
DEBUG - 2022-05-30 04:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:22:58 --> Total execution time: 0.0173
DEBUG - 2022-05-30 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:53:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:23:01 --> Total execution time: 0.0552
DEBUG - 2022-05-30 04:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 04:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:42 --> Total execution time: 0.0260
DEBUG - 2022-05-30 04:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 04:58:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 04:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 04:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:28:34 --> Total execution time: 0.0302
DEBUG - 2022-05-30 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:30:03 --> Total execution time: 0.0835
DEBUG - 2022-05-30 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:30:59 --> Total execution time: 0.0211
DEBUG - 2022-05-30 05:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:31:21 --> Total execution time: 0.0257
DEBUG - 2022-05-30 05:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:01:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:31:37 --> Total execution time: 0.0299
DEBUG - 2022-05-30 05:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:31:44 --> Total execution time: 0.0271
DEBUG - 2022-05-30 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:32:06 --> Total execution time: 0.0240
DEBUG - 2022-05-30 05:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:02:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:32:18 --> Total execution time: 0.0257
DEBUG - 2022-05-30 05:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:03:05 --> Total execution time: 0.0469
DEBUG - 2022-05-30 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:03:06 --> Total execution time: 0.0294
DEBUG - 2022-05-30 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:03:06 --> Total execution time: 0.0525
DEBUG - 2022-05-30 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:10 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:33:10 --> Total execution time: 0.0281
DEBUG - 2022-05-30 05:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:03:17 --> Total execution time: 0.0266
DEBUG - 2022-05-30 05:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:19 --> Total execution time: 0.0299
DEBUG - 2022-05-30 05:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:03:19 --> Total execution time: 0.0348
DEBUG - 2022-05-30 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:33:33 --> Total execution time: 0.0352
DEBUG - 2022-05-30 05:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:33:38 --> Total execution time: 0.0374
DEBUG - 2022-05-30 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:33:41 --> Total execution time: 0.0249
DEBUG - 2022-05-30 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:03:48 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:33:48 --> Total execution time: 0.0455
DEBUG - 2022-05-30 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:34:14 --> Total execution time: 0.0286
DEBUG - 2022-05-30 05:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:34:53 --> Total execution time: 0.0267
DEBUG - 2022-05-30 05:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:35:00 --> Total execution time: 0.0307
DEBUG - 2022-05-30 05:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:35:10 --> Total execution time: 0.0454
DEBUG - 2022-05-30 05:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:35:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 05:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:35:11 --> Total execution time: 0.0244
DEBUG - 2022-05-30 05:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:05:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:35:31 --> Total execution time: 0.0222
DEBUG - 2022-05-30 05:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:05:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:35:39 --> Total execution time: 0.0267
DEBUG - 2022-05-30 05:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:36:22 --> Total execution time: 0.0239
DEBUG - 2022-05-30 05:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:36:24 --> Total execution time: 0.0498
DEBUG - 2022-05-30 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:07:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 05:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:07 --> Total execution time: 0.0200
DEBUG - 2022-05-30 05:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:31 --> Total execution time: 0.0518
DEBUG - 2022-05-30 05:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:34 --> Total execution time: 0.0367
DEBUG - 2022-05-30 05:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:36 --> Total execution time: 0.0245
DEBUG - 2022-05-30 05:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:37 --> Total execution time: 0.0505
DEBUG - 2022-05-30 05:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:38 --> Total execution time: 0.0322
DEBUG - 2022-05-30 05:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:46 --> Total execution time: 0.0236
DEBUG - 2022-05-30 05:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:49 --> Total execution time: 0.0253
DEBUG - 2022-05-30 05:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:51 --> Total execution time: 0.0529
DEBUG - 2022-05-30 05:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:38:53 --> Total execution time: 0.0238
DEBUG - 2022-05-30 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:09:04 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-05-30 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:09:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 05:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:09 --> Total execution time: 0.0524
DEBUG - 2022-05-30 05:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:12 --> Total execution time: 0.0687
DEBUG - 2022-05-30 05:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:13 --> Total execution time: 0.0251
DEBUG - 2022-05-30 05:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:22 --> Total execution time: 0.0702
DEBUG - 2022-05-30 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:32 --> Total execution time: 0.0299
DEBUG - 2022-05-30 05:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:39 --> Total execution time: 0.0408
DEBUG - 2022-05-30 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:09:46 --> 404 Page Not Found: Become-an-affiliate/index
DEBUG - 2022-05-30 05:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:49 --> Total execution time: 0.0336
DEBUG - 2022-05-30 05:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:39:52 --> Total execution time: 0.0284
DEBUG - 2022-05-30 05:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:40:00 --> Total execution time: 0.0448
DEBUG - 2022-05-30 05:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:40:09 --> Total execution time: 0.0617
DEBUG - 2022-05-30 05:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:40:19 --> Total execution time: 0.0392
DEBUG - 2022-05-30 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:40:26 --> Total execution time: 0.0419
DEBUG - 2022-05-30 05:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:40:29 --> Total execution time: 0.0245
DEBUG - 2022-05-30 05:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:43:12 --> Total execution time: 0.1352
DEBUG - 2022-05-30 05:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:43:16 --> Total execution time: 0.0310
DEBUG - 2022-05-30 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:43:31 --> Total execution time: 0.0332
DEBUG - 2022-05-30 05:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:43:33 --> Total execution time: 0.0324
DEBUG - 2022-05-30 05:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:43:39 --> Total execution time: 0.0339
DEBUG - 2022-05-30 05:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:43:52 --> Total execution time: 0.0465
DEBUG - 2022-05-30 05:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:04 --> Total execution time: 0.0729
DEBUG - 2022-05-30 05:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:07 --> Total execution time: 0.0509
DEBUG - 2022-05-30 05:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:22 --> Total execution time: 0.0362
DEBUG - 2022-05-30 05:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:23 --> Total execution time: 0.0265
DEBUG - 2022-05-30 05:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:40 --> Total execution time: 0.1171
DEBUG - 2022-05-30 05:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:44 --> Total execution time: 0.0328
DEBUG - 2022-05-30 05:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:55 --> Total execution time: 0.0415
DEBUG - 2022-05-30 05:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:04 --> Total execution time: 0.0430
DEBUG - 2022-05-30 05:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:08 --> Total execution time: 0.0357
DEBUG - 2022-05-30 05:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:11 --> Total execution time: 0.0558
DEBUG - 2022-05-30 05:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:15 --> Total execution time: 0.0752
DEBUG - 2022-05-30 05:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:20 --> Total execution time: 0.0296
DEBUG - 2022-05-30 05:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:24 --> Total execution time: 0.0288
DEBUG - 2022-05-30 05:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:35 --> Total execution time: 0.0323
DEBUG - 2022-05-30 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:47 --> Total execution time: 0.0296
DEBUG - 2022-05-30 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:48 --> Total execution time: 0.0830
DEBUG - 2022-05-30 05:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:49 --> Total execution time: 0.0307
DEBUG - 2022-05-30 05:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:50 --> Total execution time: 0.0328
DEBUG - 2022-05-30 05:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:51 --> Total execution time: 0.0466
DEBUG - 2022-05-30 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:52 --> Total execution time: 0.0313
DEBUG - 2022-05-30 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:52 --> Total execution time: 0.0427
DEBUG - 2022-05-30 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:53 --> Total execution time: 0.0442
DEBUG - 2022-05-30 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:53 --> Total execution time: 0.0276
DEBUG - 2022-05-30 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:53 --> Total execution time: 0.0208
DEBUG - 2022-05-30 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:53 --> Total execution time: 0.0236
DEBUG - 2022-05-30 05:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:54 --> Total execution time: 0.0270
DEBUG - 2022-05-30 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:56 --> Total execution time: 0.0477
DEBUG - 2022-05-30 05:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:46:09 --> Total execution time: 0.0712
DEBUG - 2022-05-30 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:46:27 --> Total execution time: 0.0304
DEBUG - 2022-05-30 05:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:47:00 --> Total execution time: 0.0272
DEBUG - 2022-05-30 05:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:03 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:47:03 --> Total execution time: 0.0161
DEBUG - 2022-05-30 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:47:08 --> Total execution time: 0.0258
DEBUG - 2022-05-30 05:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:47:25 --> Total execution time: 0.0252
DEBUG - 2022-05-30 05:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:47:35 --> Total execution time: 0.0256
DEBUG - 2022-05-30 05:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:48:01 --> Total execution time: 0.0384
DEBUG - 2022-05-30 05:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:48:14 --> Total execution time: 0.0466
DEBUG - 2022-05-30 05:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:48:26 --> Total execution time: 0.0497
DEBUG - 2022-05-30 05:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:19:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:49:05 --> Total execution time: 0.0265
DEBUG - 2022-05-30 05:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:19:21 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:49:21 --> Total execution time: 0.0245
DEBUG - 2022-05-30 05:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:49:48 --> Total execution time: 0.0207
DEBUG - 2022-05-30 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:50:40 --> Total execution time: 0.0365
DEBUG - 2022-05-30 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:50:54 --> Total execution time: 0.0310
DEBUG - 2022-05-30 05:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:50:58 --> Total execution time: 0.0368
DEBUG - 2022-05-30 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:51:12 --> Total execution time: 0.0257
DEBUG - 2022-05-30 05:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:51:29 --> Total execution time: 0.0545
DEBUG - 2022-05-30 05:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:51:42 --> Total execution time: 0.0305
DEBUG - 2022-05-30 05:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:52:16 --> Total execution time: 0.0394
DEBUG - 2022-05-30 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:53:10 --> Total execution time: 0.0288
DEBUG - 2022-05-30 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:53:15 --> Total execution time: 0.0348
DEBUG - 2022-05-30 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:53:35 --> Total execution time: 0.0284
DEBUG - 2022-05-30 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:53:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:53:36 --> Total execution time: 0.0246
DEBUG - 2022-05-30 05:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:55:29 --> Total execution time: 0.0407
DEBUG - 2022-05-30 05:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:55:33 --> Total execution time: 0.0307
DEBUG - 2022-05-30 05:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:55:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 05:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:55:34 --> Total execution time: 0.0287
DEBUG - 2022-05-30 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:59:41 --> Total execution time: 0.0878
DEBUG - 2022-05-30 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:30:21 --> 404 Page Not Found: Courses/index
DEBUG - 2022-05-30 05:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:33:07 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:03:07 --> Total execution time: 0.1017
DEBUG - 2022-05-30 05:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:34:06 --> 404 Page Not Found: Courses/index
DEBUG - 2022-05-30 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:34:36 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-05-30 05:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:04:53 --> Total execution time: 0.0227
DEBUG - 2022-05-30 05:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:35:21 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:05:21 --> Total execution time: 0.0264
DEBUG - 2022-05-30 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:35:49 --> Total execution time: 0.0250
DEBUG - 2022-05-30 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:35:50 --> Total execution time: 0.0338
DEBUG - 2022-05-30 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:35:50 --> Total execution time: 0.0462
DEBUG - 2022-05-30 05:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:36:15 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:06:15 --> Total execution time: 0.0259
DEBUG - 2022-05-30 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:36:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:06:19 --> Total execution time: 0.0281
DEBUG - 2022-05-30 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:36:30 --> Total execution time: 0.0299
DEBUG - 2022-05-30 05:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:36:32 --> Total execution time: 0.0363
DEBUG - 2022-05-30 05:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:36:32 --> Total execution time: 0.0646
DEBUG - 2022-05-30 05:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:36:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:06:55 --> Total execution time: 0.0320
DEBUG - 2022-05-30 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:07:23 --> Total execution time: 0.0295
DEBUG - 2022-05-30 05:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:38:09 --> 404 Page Not Found: 404html/index
DEBUG - 2022-05-30 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:38:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:38:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 05:38:11 --> 404 Page Not Found: 404html/index
DEBUG - 2022-05-30 05:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:39:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:09:54 --> Total execution time: 0.0771
DEBUG - 2022-05-30 05:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:39:56 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:09:56 --> Total execution time: 0.0420
DEBUG - 2022-05-30 05:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:10:02 --> Total execution time: 0.0198
DEBUG - 2022-05-30 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:10:35 --> Total execution time: 0.0238
DEBUG - 2022-05-30 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:10:39 --> Total execution time: 0.0243
DEBUG - 2022-05-30 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:40:41 --> Total execution time: 0.0248
DEBUG - 2022-05-30 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:40:44 --> Total execution time: 0.0322
DEBUG - 2022-05-30 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:40:44 --> Total execution time: 0.0263
DEBUG - 2022-05-30 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:10:48 --> Total execution time: 0.0253
DEBUG - 2022-05-30 05:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:11:10 --> Total execution time: 0.0325
DEBUG - 2022-05-30 05:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:41:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:11:23 --> Total execution time: 0.0504
DEBUG - 2022-05-30 05:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:43:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:13:34 --> Total execution time: 0.1010
DEBUG - 2022-05-30 05:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:13:42 --> Total execution time: 0.0238
DEBUG - 2022-05-30 05:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:14:00 --> Total execution time: 0.0451
DEBUG - 2022-05-30 05:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:14:17 --> Total execution time: 0.0422
DEBUG - 2022-05-30 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:14:21 --> Total execution time: 0.0404
DEBUG - 2022-05-30 05:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:15:07 --> Total execution time: 0.1015
DEBUG - 2022-05-30 05:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:20:24 --> Total execution time: 0.0770
DEBUG - 2022-05-30 05:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:22:24 --> Total execution time: 0.0296
DEBUG - 2022-05-30 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:24:05 --> Total execution time: 0.0282
DEBUG - 2022-05-30 05:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:25:15 --> Total execution time: 1.6369
DEBUG - 2022-05-30 05:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:25:18 --> Total execution time: 0.0403
DEBUG - 2022-05-30 05:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:26:02 --> Total execution time: 0.0306
DEBUG - 2022-05-30 05:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:26:10 --> Total execution time: 0.0379
DEBUG - 2022-05-30 05:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:26:28 --> Total execution time: 0.0378
DEBUG - 2022-05-30 05:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:26:40 --> Total execution time: 0.1373
DEBUG - 2022-05-30 05:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:27:23 --> Total execution time: 0.0513
DEBUG - 2022-05-30 05:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:27:40 --> Total execution time: 0.0924
DEBUG - 2022-05-30 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:57:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:27:41 --> Total execution time: 0.0246
DEBUG - 2022-05-30 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:57:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:27:41 --> Total execution time: 0.0276
DEBUG - 2022-05-30 05:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:27:46 --> Total execution time: 0.0821
DEBUG - 2022-05-30 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:28:27 --> Total execution time: 0.1222
DEBUG - 2022-05-30 05:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:28:31 --> Total execution time: 0.0272
DEBUG - 2022-05-30 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:28:39 --> Total execution time: 0.0340
DEBUG - 2022-05-30 05:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:28:40 --> Total execution time: 0.0490
DEBUG - 2022-05-30 05:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:28:54 --> Total execution time: 0.0217
DEBUG - 2022-05-30 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:08 --> Total execution time: 0.0288
DEBUG - 2022-05-30 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:17 --> Total execution time: 0.0232
DEBUG - 2022-05-30 05:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:28 --> Total execution time: 0.0263
DEBUG - 2022-05-30 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:37 --> Total execution time: 0.0319
DEBUG - 2022-05-30 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 05:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:37 --> Total execution time: 0.0407
DEBUG - 2022-05-30 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:30:02 --> Total execution time: 0.0780
DEBUG - 2022-05-30 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:03 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:03 --> Total execution time: 0.0347
DEBUG - 2022-05-30 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:30 --> Total execution time: 0.0238
DEBUG - 2022-05-30 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:31 --> Total execution time: 0.0354
DEBUG - 2022-05-30 06:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:38 --> Total execution time: 0.0363
DEBUG - 2022-05-30 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:43 --> Total execution time: 0.0440
DEBUG - 2022-05-30 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:32:13 --> Total execution time: 0.0477
DEBUG - 2022-05-30 06:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:33:19 --> Total execution time: 0.0610
DEBUG - 2022-05-30 06:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:33:33 --> Total execution time: 0.0382
DEBUG - 2022-05-30 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:04:18 --> Total execution time: 0.0385
DEBUG - 2022-05-30 06:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:04:22 --> Total execution time: 0.0834
DEBUG - 2022-05-30 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:02 --> Total execution time: 0.0741
DEBUG - 2022-05-30 06:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:31 --> Total execution time: 0.0684
DEBUG - 2022-05-30 06:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:39 --> Total execution time: 0.0603
DEBUG - 2022-05-30 06:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:42 --> Total execution time: 0.0653
DEBUG - 2022-05-30 06:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:45 --> Total execution time: 0.0441
DEBUG - 2022-05-30 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:48 --> Total execution time: 0.0314
DEBUG - 2022-05-30 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:50 --> Total execution time: 0.0289
DEBUG - 2022-05-30 06:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:55 --> Total execution time: 0.0296
DEBUG - 2022-05-30 06:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:09 --> Total execution time: 0.0340
DEBUG - 2022-05-30 06:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:11 --> Total execution time: 0.0356
DEBUG - 2022-05-30 06:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:34 --> Total execution time: 0.0298
DEBUG - 2022-05-30 06:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:41 --> Total execution time: 0.0383
DEBUG - 2022-05-30 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:46 --> Total execution time: 0.0322
DEBUG - 2022-05-30 06:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:49 --> Total execution time: 0.0353
DEBUG - 2022-05-30 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:56 --> Total execution time: 0.0314
DEBUG - 2022-05-30 06:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:04 --> Total execution time: 0.0911
DEBUG - 2022-05-30 06:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:25 --> Total execution time: 0.0277
DEBUG - 2022-05-30 06:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:30 --> Total execution time: 0.0240
DEBUG - 2022-05-30 06:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:31 --> Total execution time: 0.0293
DEBUG - 2022-05-30 06:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:39 --> Total execution time: 0.0505
DEBUG - 2022-05-30 06:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:42 --> Total execution time: 0.0348
DEBUG - 2022-05-30 06:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:43 --> Total execution time: 0.0295
DEBUG - 2022-05-30 06:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:55 --> Total execution time: 0.0891
DEBUG - 2022-05-30 06:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:24 --> Total execution time: 0.0452
DEBUG - 2022-05-30 06:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:25 --> Total execution time: 0.4459
DEBUG - 2022-05-30 06:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:35 --> Total execution time: 0.0297
DEBUG - 2022-05-30 06:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:43 --> Total execution time: 0.0262
DEBUG - 2022-05-30 06:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 06:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:44 --> Total execution time: 0.0269
DEBUG - 2022-05-30 06:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:41:32 --> Total execution time: 0.0290
DEBUG - 2022-05-30 06:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:41:59 --> Total execution time: 0.0349
DEBUG - 2022-05-30 06:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:01 --> Total execution time: 0.0319
DEBUG - 2022-05-30 06:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:03 --> Total execution time: 0.0183
DEBUG - 2022-05-30 06:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:04 --> Total execution time: 0.0288
DEBUG - 2022-05-30 06:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:04 --> Total execution time: 0.0184
DEBUG - 2022-05-30 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:26 --> Total execution time: 0.0245
DEBUG - 2022-05-30 06:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:47 --> Total execution time: 0.0339
DEBUG - 2022-05-30 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:42:49 --> Total execution time: 0.0264
DEBUG - 2022-05-30 06:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:12:53 --> Total execution time: 0.0311
DEBUG - 2022-05-30 06:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:43:03 --> Total execution time: 0.0365
DEBUG - 2022-05-30 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:43:16 --> Total execution time: 0.0549
DEBUG - 2022-05-30 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:13:16 --> Total execution time: 0.0243
DEBUG - 2022-05-30 06:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:13:30 --> Total execution time: 0.0317
DEBUG - 2022-05-30 06:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:13:37 --> Total execution time: 0.0322
DEBUG - 2022-05-30 06:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:43:44 --> Total execution time: 0.0591
DEBUG - 2022-05-30 06:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:02 --> Total execution time: 0.0740
DEBUG - 2022-05-30 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:07 --> Total execution time: 0.0651
DEBUG - 2022-05-30 06:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:10 --> Total execution time: 0.0947
DEBUG - 2022-05-30 06:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 16:44:33 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-05-30 06:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:34 --> Total execution time: 0.0688
DEBUG - 2022-05-30 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:37 --> Total execution time: 0.0276
DEBUG - 2022-05-30 06:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:49 --> Total execution time: 0.1337
DEBUG - 2022-05-30 06:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:44:53 --> Total execution time: 0.0664
DEBUG - 2022-05-30 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:55 --> Total execution time: 0.4095
DEBUG - 2022-05-30 06:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:14:55 --> Total execution time: 0.4387
DEBUG - 2022-05-30 06:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:03 --> Total execution time: 0.0411
DEBUG - 2022-05-30 06:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:05 --> Total execution time: 0.0479
DEBUG - 2022-05-30 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:18 --> Total execution time: 0.0477
DEBUG - 2022-05-30 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:24 --> Total execution time: 0.0859
DEBUG - 2022-05-30 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:24 --> Total execution time: 0.0609
DEBUG - 2022-05-30 06:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:38 --> Total execution time: 0.0657
DEBUG - 2022-05-30 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:39 --> Total execution time: 0.0240
DEBUG - 2022-05-30 06:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:49 --> Total execution time: 0.0571
DEBUG - 2022-05-30 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:45:58 --> Total execution time: 0.0241
DEBUG - 2022-05-30 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:15 --> Total execution time: 0.0367
DEBUG - 2022-05-30 06:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:18 --> Total execution time: 0.0257
DEBUG - 2022-05-30 06:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:19 --> Total execution time: 0.0344
DEBUG - 2022-05-30 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:22 --> Total execution time: 0.0507
DEBUG - 2022-05-30 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:25 --> Total execution time: 0.0301
DEBUG - 2022-05-30 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:28 --> Total execution time: 0.0275
DEBUG - 2022-05-30 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:28 --> Total execution time: 0.0336
DEBUG - 2022-05-30 06:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:33 --> Total execution time: 0.0264
DEBUG - 2022-05-30 06:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:36 --> Total execution time: 0.0330
DEBUG - 2022-05-30 06:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:38 --> Total execution time: 0.0519
DEBUG - 2022-05-30 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:39 --> Total execution time: 0.0320
DEBUG - 2022-05-30 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:46 --> Total execution time: 0.0456
DEBUG - 2022-05-30 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:16:51 --> Total execution time: 0.0296
DEBUG - 2022-05-30 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:46:56 --> Total execution time: 0.0347
DEBUG - 2022-05-30 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:03 --> Total execution time: 0.0353
DEBUG - 2022-05-30 06:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:15 --> Total execution time: 0.0490
DEBUG - 2022-05-30 06:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:19 --> Total execution time: 0.1025
DEBUG - 2022-05-30 06:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:23 --> Total execution time: 0.0951
DEBUG - 2022-05-30 06:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:31 --> Total execution time: 0.0632
DEBUG - 2022-05-30 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:45 --> Total execution time: 0.0374
DEBUG - 2022-05-30 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:47:59 --> Total execution time: 0.0339
DEBUG - 2022-05-30 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:48:25 --> Total execution time: 0.0262
DEBUG - 2022-05-30 06:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:48:46 --> Total execution time: 0.0320
DEBUG - 2022-05-30 06:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:48:59 --> Total execution time: 0.0266
DEBUG - 2022-05-30 06:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:04 --> Total execution time: 0.0536
DEBUG - 2022-05-30 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:12 --> Total execution time: 0.0591
DEBUG - 2022-05-30 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:12 --> Total execution time: 0.0641
DEBUG - 2022-05-30 06:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:29 --> Total execution time: 0.0552
DEBUG - 2022-05-30 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:30 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:30 --> Total execution time: 0.0306
DEBUG - 2022-05-30 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:33 --> Total execution time: 0.0271
DEBUG - 2022-05-30 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:47 --> Total execution time: 0.0876
DEBUG - 2022-05-30 06:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:50:02 --> Total execution time: 0.0458
DEBUG - 2022-05-30 06:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:50:25 --> Total execution time: 0.0321
DEBUG - 2022-05-30 06:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:03 --> Total execution time: 0.0271
DEBUG - 2022-05-30 06:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:16 --> Total execution time: 0.0385
DEBUG - 2022-05-30 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:19 --> Total execution time: 0.0291
DEBUG - 2022-05-30 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:19 --> Total execution time: 0.0303
DEBUG - 2022-05-30 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:30 --> Total execution time: 0.0407
DEBUG - 2022-05-30 06:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:36 --> Total execution time: 0.0337
DEBUG - 2022-05-30 06:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:39 --> Total execution time: 0.0321
DEBUG - 2022-05-30 06:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:41 --> Total execution time: 0.0303
DEBUG - 2022-05-30 06:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:44 --> Total execution time: 0.0434
DEBUG - 2022-05-30 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:51:58 --> Total execution time: 0.0509
DEBUG - 2022-05-30 06:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:52:09 --> Total execution time: 0.0320
DEBUG - 2022-05-30 06:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:52:23 --> Total execution time: 0.0403
DEBUG - 2022-05-30 06:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:52:32 --> Total execution time: 0.0357
DEBUG - 2022-05-30 06:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:52:45 --> Total execution time: 0.0506
DEBUG - 2022-05-30 06:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:52:55 --> Total execution time: 0.0288
DEBUG - 2022-05-30 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:53:02 --> Total execution time: 0.0375
DEBUG - 2022-05-30 06:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:53:07 --> Total execution time: 0.0351
DEBUG - 2022-05-30 06:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:53:13 --> Total execution time: 0.0667
DEBUG - 2022-05-30 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:53:42 --> Total execution time: 0.0309
DEBUG - 2022-05-30 06:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:23:56 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:53:56 --> Total execution time: 0.0436
DEBUG - 2022-05-30 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:53:58 --> Total execution time: 0.0213
DEBUG - 2022-05-30 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:02 --> Total execution time: 0.0379
DEBUG - 2022-05-30 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:09 --> Total execution time: 0.0266
DEBUG - 2022-05-30 06:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:22 --> Total execution time: 0.0433
DEBUG - 2022-05-30 06:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:23 --> Total execution time: 0.0452
DEBUG - 2022-05-30 06:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:36 --> Total execution time: 0.0273
DEBUG - 2022-05-30 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:37 --> Total execution time: 0.0273
DEBUG - 2022-05-30 06:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:41 --> Total execution time: 0.0404
DEBUG - 2022-05-30 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:54 --> Total execution time: 0.0344
DEBUG - 2022-05-30 06:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:54:55 --> Total execution time: 0.0355
DEBUG - 2022-05-30 06:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:55:05 --> Total execution time: 0.0801
DEBUG - 2022-05-30 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:55:17 --> Total execution time: 0.0243
DEBUG - 2022-05-30 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:26:16 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:56:16 --> Total execution time: 0.0236
DEBUG - 2022-05-30 06:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:26:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:56:17 --> Total execution time: 0.0690
DEBUG - 2022-05-30 06:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:27:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:57:14 --> Total execution time: 0.0358
DEBUG - 2022-05-30 06:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:57:14 --> Total execution time: 0.0560
DEBUG - 2022-05-30 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:58:03 --> Total execution time: 0.0418
DEBUG - 2022-05-30 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:59:38 --> Total execution time: 0.0321
DEBUG - 2022-05-30 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:00:32 --> Total execution time: 0.0944
DEBUG - 2022-05-30 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:00:39 --> Total execution time: 0.0395
DEBUG - 2022-05-30 06:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:01:58 --> Total execution time: 0.0322
DEBUG - 2022-05-30 06:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:02:02 --> Total execution time: 0.0567
DEBUG - 2022-05-30 06:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:02:20 --> Total execution time: 0.0326
DEBUG - 2022-05-30 06:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:32:31 --> Total execution time: 0.0303
DEBUG - 2022-05-30 06:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:02:40 --> Total execution time: 0.0285
DEBUG - 2022-05-30 06:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:02:46 --> Total execution time: 0.0274
DEBUG - 2022-05-30 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:03:09 --> Total execution time: 0.0614
DEBUG - 2022-05-30 06:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:03:23 --> Total execution time: 0.0483
DEBUG - 2022-05-30 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:03:28 --> Total execution time: 0.0298
DEBUG - 2022-05-30 06:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:04:42 --> Total execution time: 0.0631
DEBUG - 2022-05-30 06:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:34:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:04:54 --> Total execution time: 0.0308
DEBUG - 2022-05-30 06:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:04:55 --> Total execution time: 0.0364
DEBUG - 2022-05-30 06:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:04:57 --> Total execution time: 0.0240
DEBUG - 2022-05-30 06:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:11:11 --> Total execution time: 0.1722
DEBUG - 2022-05-30 06:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:43:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:13:35 --> Total execution time: 0.1105
DEBUG - 2022-05-30 06:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:13:39 --> Total execution time: 0.0339
DEBUG - 2022-05-30 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:13:47 --> Total execution time: 0.0539
DEBUG - 2022-05-30 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:13:50 --> Total execution time: 0.0340
DEBUG - 2022-05-30 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:14:03 --> Total execution time: 0.0318
DEBUG - 2022-05-30 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:14:17 --> Total execution time: 0.0909
DEBUG - 2022-05-30 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:14:23 --> Total execution time: 0.0879
DEBUG - 2022-05-30 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:14:27 --> Total execution time: 0.0751
DEBUG - 2022-05-30 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:19:04 --> Total execution time: 0.1366
DEBUG - 2022-05-30 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:21:03 --> Total execution time: 0.0292
DEBUG - 2022-05-30 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 06:53:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-30 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:56:45 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:26:45 --> Total execution time: 0.1011
DEBUG - 2022-05-30 06:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:26:49 --> Total execution time: 0.0231
DEBUG - 2022-05-30 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:26:51 --> Total execution time: 0.0249
DEBUG - 2022-05-30 06:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:01 --> Total execution time: 0.0708
DEBUG - 2022-05-30 06:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:04 --> Total execution time: 0.0354
DEBUG - 2022-05-30 06:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:07 --> Total execution time: 0.0668
DEBUG - 2022-05-30 06:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:08 --> Total execution time: 0.0434
DEBUG - 2022-05-30 06:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:18 --> Total execution time: 0.0324
DEBUG - 2022-05-30 06:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:31 --> Total execution time: 0.0257
DEBUG - 2022-05-30 06:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:35 --> Total execution time: 0.0296
DEBUG - 2022-05-30 06:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:40 --> Total execution time: 0.0273
DEBUG - 2022-05-30 06:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:45 --> Total execution time: 0.0384
DEBUG - 2022-05-30 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:46 --> Total execution time: 0.0358
DEBUG - 2022-05-30 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:57:46 --> Total execution time: 0.0300
DEBUG - 2022-05-30 06:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:52 --> Total execution time: 0.0202
DEBUG - 2022-05-30 06:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:27:57 --> Total execution time: 0.0232
DEBUG - 2022-05-30 06:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:10 --> Total execution time: 0.0231
DEBUG - 2022-05-30 06:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:14 --> Total execution time: 0.0263
DEBUG - 2022-05-30 06:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:23 --> Total execution time: 0.0283
DEBUG - 2022-05-30 06:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 06:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:24 --> Total execution time: 0.0317
DEBUG - 2022-05-30 06:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 06:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:33 --> Total execution time: 0.0263
DEBUG - 2022-05-30 06:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:28:41 --> Total execution time: 0.0246
DEBUG - 2022-05-30 06:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:29:11 --> Total execution time: 0.0245
DEBUG - 2022-05-30 06:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 06:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:29:12 --> Total execution time: 0.0415
DEBUG - 2022-05-30 06:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 06:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 06:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:29:16 --> Total execution time: 0.0381
DEBUG - 2022-05-30 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:30:03 --> Total execution time: 0.0285
DEBUG - 2022-05-30 07:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:30:07 --> Total execution time: 0.0407
DEBUG - 2022-05-30 07:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:30:07 --> Total execution time: 0.1376
DEBUG - 2022-05-30 07:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:30:24 --> Total execution time: 0.0323
DEBUG - 2022-05-30 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:30:43 --> Total execution time: 0.0356
DEBUG - 2022-05-30 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:30:52 --> Total execution time: 0.0292
DEBUG - 2022-05-30 07:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:31:02 --> Total execution time: 0.0667
DEBUG - 2022-05-30 07:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:31:16 --> Total execution time: 0.0969
DEBUG - 2022-05-30 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:01:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:31:29 --> Total execution time: 0.0364
DEBUG - 2022-05-30 07:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:31:58 --> Total execution time: 0.0413
DEBUG - 2022-05-30 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:02:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:32:12 --> Total execution time: 0.0226
DEBUG - 2022-05-30 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:02:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:32:18 --> Total execution time: 0.0511
DEBUG - 2022-05-30 07:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:02:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:32:22 --> Total execution time: 0.0265
DEBUG - 2022-05-30 07:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:02:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:32:34 --> Total execution time: 0.0272
DEBUG - 2022-05-30 07:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:02:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:32:40 --> Total execution time: 0.0507
DEBUG - 2022-05-30 07:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:02:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:32:42 --> Total execution time: 0.0254
DEBUG - 2022-05-30 07:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:03:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:33:12 --> Total execution time: 0.0336
DEBUG - 2022-05-30 07:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:03:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:33:22 --> Total execution time: 0.0208
DEBUG - 2022-05-30 07:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:03:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:33:23 --> Total execution time: 0.0259
DEBUG - 2022-05-30 07:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:03:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:33:25 --> Total execution time: 0.0288
DEBUG - 2022-05-30 07:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:03:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:33:42 --> Total execution time: 0.0364
DEBUG - 2022-05-30 07:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:33:52 --> Total execution time: 0.0272
DEBUG - 2022-05-30 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:01 --> Total execution time: 0.0476
DEBUG - 2022-05-30 07:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:04:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-30 07:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:04:24 --> Total execution time: 0.0262
DEBUG - 2022-05-30 07:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:04:25 --> Total execution time: 0.0280
DEBUG - 2022-05-30 07:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:04:25 --> Total execution time: 0.0480
DEBUG - 2022-05-30 07:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:36 --> Total execution time: 0.0443
DEBUG - 2022-05-30 07:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:38 --> Total execution time: 0.0249
DEBUG - 2022-05-30 07:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:40 --> Total execution time: 0.0300
DEBUG - 2022-05-30 07:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:40 --> Total execution time: 0.0335
DEBUG - 2022-05-30 07:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:40 --> Total execution time: 0.0293
DEBUG - 2022-05-30 07:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:41 --> Total execution time: 0.0426
DEBUG - 2022-05-30 07:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:42 --> Total execution time: 0.0498
DEBUG - 2022-05-30 07:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:42 --> Total execution time: 0.0292
DEBUG - 2022-05-30 07:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:04:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:34:44 --> Total execution time: 0.0277
DEBUG - 2022-05-30 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:05:11 --> Total execution time: 0.0321
DEBUG - 2022-05-30 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:05:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:35:11 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:05:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:35:14 --> Total execution time: 0.0369
DEBUG - 2022-05-30 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:05:14 --> Total execution time: 0.0948
DEBUG - 2022-05-30 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:05:20 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:35:20 --> Total execution time: 0.0255
DEBUG - 2022-05-30 07:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:06 --> Total execution time: 0.0422
DEBUG - 2022-05-30 07:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:06 --> Total execution time: 0.0266
DEBUG - 2022-05-30 07:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:09 --> Total execution time: 0.0270
DEBUG - 2022-05-30 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:10 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:10 --> Total execution time: 0.0335
DEBUG - 2022-05-30 07:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:10 --> Total execution time: 0.0640
DEBUG - 2022-05-30 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:11 --> Total execution time: 0.0341
DEBUG - 2022-05-30 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:46 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:46 --> Total execution time: 0.0534
DEBUG - 2022-05-30 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:56 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:56 --> Total execution time: 0.0338
DEBUG - 2022-05-30 07:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:07:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:37:59 --> Total execution time: 0.0283
DEBUG - 2022-05-30 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:09:08 --> Total execution time: 0.0250
DEBUG - 2022-05-30 07:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:39:14 --> Total execution time: 0.0293
DEBUG - 2022-05-30 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:39:57 --> Total execution time: 0.0411
DEBUG - 2022-05-30 07:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:40:48 --> Total execution time: 0.0315
DEBUG - 2022-05-30 07:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:11:14 --> Total execution time: 0.0348
DEBUG - 2022-05-30 07:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:11:25 --> Total execution time: 0.0269
DEBUG - 2022-05-30 07:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:11:28 --> Total execution time: 0.0398
DEBUG - 2022-05-30 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:43:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:43:02 --> Total execution time: 0.0471
DEBUG - 2022-05-30 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:13:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:43:06 --> Total execution time: 1.5414
DEBUG - 2022-05-30 07:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:13:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 07:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:13:48 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-30 07:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:14:35 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:14:37 --> Total execution time: 0.0421
DEBUG - 2022-05-30 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:45:13 --> Total execution time: 0.0283
DEBUG - 2022-05-30 07:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:16:20 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:46:20 --> Total execution time: 0.0287
DEBUG - 2022-05-30 07:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:46:38 --> Total execution time: 1.4605
DEBUG - 2022-05-30 07:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:47:20 --> Total execution time: 0.0462
DEBUG - 2022-05-30 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:47:41 --> Total execution time: 0.0288
DEBUG - 2022-05-30 07:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:47:44 --> Total execution time: 0.0470
DEBUG - 2022-05-30 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:48:20 --> Total execution time: 0.0598
DEBUG - 2022-05-30 07:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:18:50 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:48:50 --> Total execution time: 0.0338
DEBUG - 2022-05-30 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:19:46 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:49:46 --> Total execution time: 0.0242
DEBUG - 2022-05-30 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:49:50 --> Total execution time: 0.0259
DEBUG - 2022-05-30 07:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:50:03 --> Total execution time: 0.0234
DEBUG - 2022-05-30 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:56:06 --> Total execution time: 0.1589
DEBUG - 2022-05-30 07:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:56:20 --> Total execution time: 0.0472
DEBUG - 2022-05-30 07:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:56:26 --> Total execution time: 0.0330
DEBUG - 2022-05-30 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:56:30 --> Total execution time: 0.0535
DEBUG - 2022-05-30 07:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:56:46 --> Total execution time: 0.0205
DEBUG - 2022-05-30 07:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:56:57 --> Total execution time: 0.0547
DEBUG - 2022-05-30 07:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:57:03 --> Total execution time: 0.0408
DEBUG - 2022-05-30 07:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:57:14 --> Total execution time: 0.0292
DEBUG - 2022-05-30 07:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:57:36 --> Total execution time: 0.0360
DEBUG - 2022-05-30 07:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:57:41 --> Total execution time: 0.0554
DEBUG - 2022-05-30 07:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:09 --> Total execution time: 0.0253
DEBUG - 2022-05-30 07:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:28:15 --> Total execution time: 0.0322
DEBUG - 2022-05-30 07:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:28:29 --> Total execution time: 0.0922
DEBUG - 2022-05-30 07:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:52 --> Total execution time: 0.0242
DEBUG - 2022-05-30 07:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:53 --> Total execution time: 0.0222
DEBUG - 2022-05-30 07:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:53 --> Total execution time: 0.0308
DEBUG - 2022-05-30 07:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:57 --> Total execution time: 0.0155
DEBUG - 2022-05-30 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:58 --> Total execution time: 0.0324
DEBUG - 2022-05-30 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:58:59 --> Total execution time: 0.0146
DEBUG - 2022-05-30 07:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:00 --> Total execution time: 0.0162
DEBUG - 2022-05-30 07:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:00 --> Total execution time: 0.0234
DEBUG - 2022-05-30 07:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:01 --> Total execution time: 0.0248
DEBUG - 2022-05-30 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:02 --> Total execution time: 0.0158
DEBUG - 2022-05-30 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:02 --> Total execution time: 0.0142
DEBUG - 2022-05-30 07:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:05 --> Total execution time: 0.0425
DEBUG - 2022-05-30 07:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:29:14 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-05-30 07:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:17 --> Total execution time: 0.0341
DEBUG - 2022-05-30 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:24 --> Total execution time: 0.0321
DEBUG - 2022-05-30 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:24 --> Total execution time: 0.0328
DEBUG - 2022-05-30 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:26 --> Total execution time: 0.0237
DEBUG - 2022-05-30 07:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:29:27 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 07:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:29:27 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 07:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:29:27 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 07:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:31 --> Total execution time: 0.1970
DEBUG - 2022-05-30 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:36 --> Total execution time: 0.0333
DEBUG - 2022-05-30 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:36 --> Total execution time: 0.0359
DEBUG - 2022-05-30 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:59:52 --> Total execution time: 0.0280
DEBUG - 2022-05-30 07:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:00 --> Total execution time: 0.0275
DEBUG - 2022-05-30 07:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:01 --> Total execution time: 0.0347
DEBUG - 2022-05-30 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:03 --> Total execution time: 0.0281
DEBUG - 2022-05-30 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:06 --> Total execution time: 0.0677
DEBUG - 2022-05-30 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:06 --> Total execution time: 0.0231
DEBUG - 2022-05-30 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:30:08 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:30:08 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:30:08 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:08 --> Total execution time: 0.0493
DEBUG - 2022-05-30 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:12 --> Total execution time: 0.0183
DEBUG - 2022-05-30 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:32 --> Total execution time: 0.0510
DEBUG - 2022-05-30 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:33 --> Total execution time: 0.0241
DEBUG - 2022-05-30 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:34 --> Total execution time: 0.0120
DEBUG - 2022-05-30 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:33:56 --> 404 Page Not Found: Wp-sitemap-posts-elementor_library-1xml/index
DEBUG - 2022-05-30 07:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:37:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:07:29 --> Total execution time: 0.0792
DEBUG - 2022-05-30 07:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:37:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:07:29 --> Total execution time: 0.0211
DEBUG - 2022-05-30 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:07:39 --> Total execution time: 0.0204
DEBUG - 2022-05-30 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:08:14 --> Total execution time: 0.0188
DEBUG - 2022-05-30 07:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:08:23 --> Total execution time: 0.0237
DEBUG - 2022-05-30 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:10:22 --> Total execution time: 0.0791
DEBUG - 2022-05-30 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:10:32 --> Total execution time: 0.0419
DEBUG - 2022-05-30 07:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:11:21 --> Total execution time: 0.0201
DEBUG - 2022-05-30 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:42:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:12:34 --> Total execution time: 0.0213
DEBUG - 2022-05-30 07:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:45:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:15:08 --> Total execution time: 0.0498
DEBUG - 2022-05-30 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:17:24 --> Total execution time: 0.1055
DEBUG - 2022-05-30 07:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:47:27 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:17:27 --> Total execution time: 0.0299
DEBUG - 2022-05-30 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:17:30 --> Total execution time: 0.0264
DEBUG - 2022-05-30 07:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:17:49 --> Total execution time: 0.0456
DEBUG - 2022-05-30 07:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:18:00 --> Total execution time: 0.0319
DEBUG - 2022-05-30 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:18:44 --> Total execution time: 0.0481
DEBUG - 2022-05-30 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:18:45 --> Total execution time: 0.0351
DEBUG - 2022-05-30 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:18:46 --> Total execution time: 0.0236
DEBUG - 2022-05-30 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:11 --> Total execution time: 0.0278
DEBUG - 2022-05-30 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:12 --> Total execution time: 0.0242
DEBUG - 2022-05-30 07:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:21 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:21 --> Total execution time: 0.0211
DEBUG - 2022-05-30 07:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:42 --> Total execution time: 0.0278
DEBUG - 2022-05-30 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:49 --> Total execution time: 0.0289
DEBUG - 2022-05-30 07:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:51 --> Total execution time: 0.0675
DEBUG - 2022-05-30 07:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:19:59 --> Total execution time: 0.0370
DEBUG - 2022-05-30 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:06 --> Total execution time: 0.0258
DEBUG - 2022-05-30 07:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:09 --> Total execution time: 0.0226
DEBUG - 2022-05-30 07:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:14 --> Total execution time: 0.0302
DEBUG - 2022-05-30 07:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:15 --> Total execution time: 0.0417
DEBUG - 2022-05-30 07:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:22 --> Total execution time: 0.0684
DEBUG - 2022-05-30 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:30 --> Total execution time: 0.0290
DEBUG - 2022-05-30 07:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:32 --> Total execution time: 0.0476
DEBUG - 2022-05-30 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:39 --> Total execution time: 0.0312
DEBUG - 2022-05-30 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:20:57 --> Total execution time: 0.0284
DEBUG - 2022-05-30 07:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:21:10 --> Total execution time: 0.1019
DEBUG - 2022-05-30 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:21:53 --> Total execution time: 0.0477
DEBUG - 2022-05-30 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:21:54 --> Total execution time: 0.0576
DEBUG - 2022-05-30 07:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:22:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 07:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:22:18 --> Total execution time: 0.0513
DEBUG - 2022-05-30 07:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:22:21 --> Total execution time: 0.0557
DEBUG - 2022-05-30 07:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:22:31 --> Total execution time: 0.0900
DEBUG - 2022-05-30 07:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:22:36 --> Total execution time: 0.0292
DEBUG - 2022-05-30 07:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:23:05 --> Total execution time: 0.0268
DEBUG - 2022-05-30 07:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:23:13 --> Total execution time: 0.0316
DEBUG - 2022-05-30 07:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:23:16 --> Total execution time: 0.0578
DEBUG - 2022-05-30 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:23:19 --> Total execution time: 0.0553
DEBUG - 2022-05-30 07:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:23:25 --> Total execution time: 0.0312
DEBUG - 2022-05-30 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:23:36 --> Total execution time: 0.0456
DEBUG - 2022-05-30 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:26:28 --> Total execution time: 0.0188
DEBUG - 2022-05-30 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:56:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:26:38 --> Total execution time: 0.0241
DEBUG - 2022-05-30 07:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:57:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:27:55 --> Total execution time: 0.0375
DEBUG - 2022-05-30 07:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:28:00 --> Total execution time: 0.0230
DEBUG - 2022-05-30 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:28:07 --> Total execution time: 0.0358
DEBUG - 2022-05-30 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:28:16 --> Total execution time: 0.0533
DEBUG - 2022-05-30 07:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:58:46 --> No URI present. Default controller set.
DEBUG - 2022-05-30 07:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:28:46 --> Total execution time: 0.0231
DEBUG - 2022-05-30 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 07:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 07:59:51 --> UTF-8 Support Enabled
ERROR - 2022-05-30 07:59:51 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 07:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 07:59:51 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:30:02 --> Total execution time: 0.0728
DEBUG - 2022-05-30 08:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:05:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:35:53 --> Total execution time: 0.0865
DEBUG - 2022-05-30 08:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:36:02 --> Total execution time: 0.0204
DEBUG - 2022-05-30 08:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:36:14 --> Total execution time: 0.0232
DEBUG - 2022-05-30 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:36:34 --> Total execution time: 0.0253
DEBUG - 2022-05-30 08:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:36:37 --> Total execution time: 0.1016
DEBUG - 2022-05-30 08:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:36:44 --> Total execution time: 0.0380
DEBUG - 2022-05-30 08:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:36:55 --> Total execution time: 0.0181
DEBUG - 2022-05-30 08:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:03 --> Total execution time: 0.0439
DEBUG - 2022-05-30 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:18 --> Total execution time: 0.0279
DEBUG - 2022-05-30 08:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:20 --> Total execution time: 0.0215
DEBUG - 2022-05-30 08:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:35 --> Total execution time: 0.0380
DEBUG - 2022-05-30 08:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:42 --> Total execution time: 0.0301
DEBUG - 2022-05-30 08:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:44 --> Total execution time: 0.0393
DEBUG - 2022-05-30 08:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:37:52 --> Total execution time: 0.0254
DEBUG - 2022-05-30 08:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:09:45 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:39:45 --> Total execution time: 0.0526
DEBUG - 2022-05-30 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:41:59 --> Total execution time: 0.0809
DEBUG - 2022-05-30 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:14:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:44:37 --> Total execution time: 0.0723
DEBUG - 2022-05-30 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:44:47 --> Total execution time: 0.0259
DEBUG - 2022-05-30 08:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:45:33 --> Total execution time: 0.0314
DEBUG - 2022-05-30 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:45:59 --> Total execution time: 0.0429
DEBUG - 2022-05-30 08:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:46:04 --> Total execution time: 0.0365
DEBUG - 2022-05-30 08:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:46:28 --> Total execution time: 0.0429
DEBUG - 2022-05-30 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:46:41 --> Total execution time: 0.0276
DEBUG - 2022-05-30 08:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:46:59 --> Total execution time: 0.0357
DEBUG - 2022-05-30 08:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:47:23 --> Total execution time: 0.0668
DEBUG - 2022-05-30 08:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:47:39 --> Total execution time: 0.0324
DEBUG - 2022-05-30 08:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:47:52 --> Total execution time: 0.0282
DEBUG - 2022-05-30 08:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:47:56 --> Total execution time: 0.0216
DEBUG - 2022-05-30 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:17:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:47:59 --> Total execution time: 0.0181
DEBUG - 2022-05-30 08:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:00 --> Total execution time: 0.0145
DEBUG - 2022-05-30 08:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:07 --> Total execution time: 0.0280
DEBUG - 2022-05-30 08:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:07 --> Total execution time: 0.0351
DEBUG - 2022-05-30 08:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:24 --> Total execution time: 0.0202
DEBUG - 2022-05-30 08:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:24 --> Total execution time: 0.0182
DEBUG - 2022-05-30 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:18:25 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:18:25 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:18:25 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:25 --> Total execution time: 0.0206
DEBUG - 2022-05-30 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:26 --> Total execution time: 0.0128
DEBUG - 2022-05-30 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:18:27 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:48:27 --> Total execution time: 0.0149
DEBUG - 2022-05-30 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:19:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:49:39 --> Total execution time: 0.0528
DEBUG - 2022-05-30 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:49:48 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:49:59 --> Total execution time: 0.0278
DEBUG - 2022-05-30 08:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:20:55 --> Total execution time: 0.0439
DEBUG - 2022-05-30 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:20:57 --> Total execution time: 0.0260
DEBUG - 2022-05-30 08:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:20:57 --> Total execution time: 0.0533
DEBUG - 2022-05-30 08:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:51:26 --> Total execution time: 0.0232
DEBUG - 2022-05-30 08:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:21:27 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 08:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:21:27 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 08:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:21:27 --> 404 Page Not Found: User/login
DEBUG - 2022-05-30 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:51:36 --> Total execution time: 0.0272
DEBUG - 2022-05-30 08:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:21:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:51:37 --> Total execution time: 0.0209
DEBUG - 2022-05-30 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:52:04 --> Total execution time: 0.0305
DEBUG - 2022-05-30 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:10 --> Total execution time: 0.0195
DEBUG - 2022-05-30 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:10 --> Total execution time: 0.0238
DEBUG - 2022-05-30 08:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:11 --> Total execution time: 0.0249
DEBUG - 2022-05-30 08:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:11 --> Total execution time: 0.0344
DEBUG - 2022-05-30 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:12 --> Total execution time: 0.0391
DEBUG - 2022-05-30 08:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:12 --> Total execution time: 0.0282
DEBUG - 2022-05-30 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:12 --> Total execution time: 0.0201
DEBUG - 2022-05-30 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:13 --> Total execution time: 0.0285
DEBUG - 2022-05-30 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:13 --> Total execution time: 0.0367
DEBUG - 2022-05-30 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:13 --> Total execution time: 0.0618
DEBUG - 2022-05-30 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:13 --> Total execution time: 0.0200
DEBUG - 2022-05-30 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:21 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:52:21 --> Total execution time: 0.0206
DEBUG - 2022-05-30 08:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:52:41 --> Total execution time: 0.0306
DEBUG - 2022-05-30 08:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:52:45 --> Total execution time: 0.0237
DEBUG - 2022-05-30 08:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:22:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:00 --> Total execution time: 0.0423
DEBUG - 2022-05-30 18:53:01 --> Total execution time: 1.5268
DEBUG - 2022-05-30 08:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:03 --> Total execution time: 0.0351
DEBUG - 2022-05-30 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:04 --> Total execution time: 0.0186
DEBUG - 2022-05-30 08:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:05 --> Total execution time: 0.0270
DEBUG - 2022-05-30 08:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:23:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 08:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:13 --> Total execution time: 0.0278
DEBUG - 2022-05-30 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:22 --> Total execution time: 0.0232
DEBUG - 2022-05-30 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:31 --> Total execution time: 0.0237
DEBUG - 2022-05-30 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:53:53 --> Total execution time: 0.0273
DEBUG - 2022-05-30 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:25:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:55:25 --> Total execution time: 0.0206
DEBUG - 2022-05-30 08:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:05 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:57:05 --> Total execution time: 0.0237
DEBUG - 2022-05-30 08:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:57:21 --> Total execution time: 0.0221
DEBUG - 2022-05-30 08:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:57:37 --> Total execution time: 0.0335
DEBUG - 2022-05-30 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:57:37 --> Total execution time: 0.0292
DEBUG - 2022-05-30 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:57:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 08:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:57:38 --> Total execution time: 0.0239
DEBUG - 2022-05-30 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:28:32 --> 404 Page Not Found: Login/index
DEBUG - 2022-05-30 08:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:59:28 --> Total execution time: 0.0233
DEBUG - 2022-05-30 08:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:59:45 --> Total execution time: 0.0368
DEBUG - 2022-05-30 08:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:21 --> Total execution time: 0.0245
DEBUG - 2022-05-30 08:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:22 --> Total execution time: 0.0269
DEBUG - 2022-05-30 08:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:26 --> Total execution time: 0.0492
DEBUG - 2022-05-30 08:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:33 --> Total execution time: 0.0326
DEBUG - 2022-05-30 08:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:38 --> Total execution time: 0.0279
DEBUG - 2022-05-30 08:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:46 --> Total execution time: 0.0273
DEBUG - 2022-05-30 08:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:46 --> Total execution time: 0.0367
DEBUG - 2022-05-30 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:53 --> Total execution time: 0.0340
DEBUG - 2022-05-30 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:03 --> Total execution time: 0.0284
DEBUG - 2022-05-30 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:16 --> Total execution time: 0.0280
DEBUG - 2022-05-30 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:18 --> Total execution time: 0.0355
DEBUG - 2022-05-30 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:22 --> Total execution time: 0.0350
DEBUG - 2022-05-30 08:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:31:31 --> Total execution time: 0.0246
DEBUG - 2022-05-30 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:36 --> Total execution time: 0.0418
DEBUG - 2022-05-30 08:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:41 --> Total execution time: 0.0503
DEBUG - 2022-05-30 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:01:45 --> Total execution time: 0.0433
DEBUG - 2022-05-30 08:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:03:15 --> Total execution time: 0.0256
DEBUG - 2022-05-30 08:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:33:24 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-05-30 08:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:03:24 --> Total execution time: 0.0755
DEBUG - 2022-05-30 08:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:03:37 --> Total execution time: 0.0578
DEBUG - 2022-05-30 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:03:49 --> Total execution time: 0.0237
DEBUG - 2022-05-30 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:33:57 --> Total execution time: 0.0522
DEBUG - 2022-05-30 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:33:59 --> Total execution time: 0.0237
DEBUG - 2022-05-30 08:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:33:59 --> Total execution time: 0.0521
DEBUG - 2022-05-30 08:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:04:00 --> Total execution time: 0.0256
DEBUG - 2022-05-30 08:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:34:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:04:51 --> Total execution time: 0.0301
DEBUG - 2022-05-30 08:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:28 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:28 --> Total execution time: 0.0855
DEBUG - 2022-05-30 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:30 --> Total execution time: 0.0934
DEBUG - 2022-05-30 08:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:34 --> Total execution time: 0.0244
DEBUG - 2022-05-30 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:36 --> Total execution time: 0.0230
DEBUG - 2022-05-30 08:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:48 --> Total execution time: 0.0244
DEBUG - 2022-05-30 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:56 --> Total execution time: 0.0229
DEBUG - 2022-05-30 08:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:07:58 --> Total execution time: 0.0170
DEBUG - 2022-05-30 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:02 --> Total execution time: 0.0177
DEBUG - 2022-05-30 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:05 --> Total execution time: 0.0203
DEBUG - 2022-05-30 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:10 --> Total execution time: 0.0246
DEBUG - 2022-05-30 08:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:17 --> Total execution time: 0.0226
DEBUG - 2022-05-30 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:25 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:25 --> Total execution time: 0.0231
DEBUG - 2022-05-30 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:38:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:08:26 --> Total execution time: 0.0540
DEBUG - 2022-05-30 08:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:09:38 --> Total execution time: 0.0251
DEBUG - 2022-05-30 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:10:14 --> Total execution time: 0.0351
DEBUG - 2022-05-30 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:41:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:11:52 --> Total execution time: 0.0236
DEBUG - 2022-05-30 08:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:12:02 --> Total execution time: 0.0208
DEBUG - 2022-05-30 08:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:12:22 --> Total execution time: 0.0248
DEBUG - 2022-05-30 08:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:12:31 --> Total execution time: 0.0249
DEBUG - 2022-05-30 08:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:12:41 --> Total execution time: 0.0247
DEBUG - 2022-05-30 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:43:06 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 08:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:13:07 --> Total execution time: 0.0308
DEBUG - 2022-05-30 08:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:13:14 --> Total execution time: 0.0233
DEBUG - 2022-05-30 08:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:13:30 --> Total execution time: 0.0330
DEBUG - 2022-05-30 08:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:13:36 --> Total execution time: 0.0245
DEBUG - 2022-05-30 08:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:13:43 --> Total execution time: 0.0230
DEBUG - 2022-05-30 08:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:14:03 --> Total execution time: 0.0278
DEBUG - 2022-05-30 08:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:14:17 --> Total execution time: 0.0233
DEBUG - 2022-05-30 08:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:14:21 --> Total execution time: 0.0265
DEBUG - 2022-05-30 08:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:45:01 --> Total execution time: 0.0260
DEBUG - 2022-05-30 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:45:03 --> Total execution time: 0.0279
DEBUG - 2022-05-30 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:45:03 --> Total execution time: 0.0309
DEBUG - 2022-05-30 08:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:15:32 --> Total execution time: 0.0300
DEBUG - 2022-05-30 08:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:15:44 --> Total execution time: 0.0269
DEBUG - 2022-05-30 08:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:15:49 --> Total execution time: 0.0258
DEBUG - 2022-05-30 08:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:45:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:15:59 --> Total execution time: 0.0435
DEBUG - 2022-05-30 08:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:12 --> Total execution time: 0.0239
DEBUG - 2022-05-30 08:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:21 --> Total execution time: 0.0300
DEBUG - 2022-05-30 08:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:37 --> Total execution time: 0.0241
DEBUG - 2022-05-30 08:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:45 --> Total execution time: 0.0240
DEBUG - 2022-05-30 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:48 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:48 --> Total execution time: 0.0275
DEBUG - 2022-05-30 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:49 --> Total execution time: 0.0349
DEBUG - 2022-05-30 08:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:49 --> Total execution time: 0.0303
DEBUG - 2022-05-30 08:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:52 --> Total execution time: 0.0289
DEBUG - 2022-05-30 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:16:52 --> Total execution time: 0.0235
DEBUG - 2022-05-30 08:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:02 --> Total execution time: 0.0325
DEBUG - 2022-05-30 08:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:05 --> Total execution time: 0.0274
DEBUG - 2022-05-30 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:06 --> Total execution time: 0.0294
DEBUG - 2022-05-30 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:36 --> Total execution time: 0.0236
DEBUG - 2022-05-30 08:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:43 --> Total execution time: 0.0233
DEBUG - 2022-05-30 08:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:46 --> Total execution time: 0.0243
DEBUG - 2022-05-30 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:17:48 --> Total execution time: 0.0328
DEBUG - 2022-05-30 08:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:18:04 --> Total execution time: 0.0496
DEBUG - 2022-05-30 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:18:15 --> Total execution time: 0.0278
DEBUG - 2022-05-30 08:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:18:17 --> Total execution time: 0.0498
DEBUG - 2022-05-30 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:18:21 --> Total execution time: 0.0514
DEBUG - 2022-05-30 08:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:18:25 --> Total execution time: 0.0576
DEBUG - 2022-05-30 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:48:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:18:52 --> Total execution time: 0.0306
DEBUG - 2022-05-30 08:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:50:07 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:20:07 --> Total execution time: 0.0485
DEBUG - 2022-05-30 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:50:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:20:17 --> Total execution time: 0.0265
DEBUG - 2022-05-30 08:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:50:30 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:20:30 --> Total execution time: 0.0323
DEBUG - 2022-05-30 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:50:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:20:38 --> Total execution time: 0.0203
DEBUG - 2022-05-30 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:51:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:21:18 --> Total execution time: 0.0251
DEBUG - 2022-05-30 08:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:51:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:21:29 --> Total execution time: 0.0275
DEBUG - 2022-05-30 08:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:51:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:21:39 --> Total execution time: 0.0275
DEBUG - 2022-05-30 08:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:51:42 --> Total execution time: 0.0275
DEBUG - 2022-05-30 08:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:51:44 --> Total execution time: 0.0288
DEBUG - 2022-05-30 08:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:51:44 --> Total execution time: 0.0551
DEBUG - 2022-05-30 08:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:53:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:23:52 --> Total execution time: 0.0441
DEBUG - 2022-05-30 08:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:23:58 --> Total execution time: 0.0244
DEBUG - 2022-05-30 08:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:24:05 --> Total execution time: 0.0473
DEBUG - 2022-05-30 08:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:24:13 --> Total execution time: 0.0275
DEBUG - 2022-05-30 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:24:28 --> Total execution time: 0.0350
DEBUG - 2022-05-30 08:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:24:36 --> Total execution time: 0.0232
DEBUG - 2022-05-30 08:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:24:43 --> Total execution time: 0.0364
DEBUG - 2022-05-30 08:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:24:57 --> Total execution time: 0.0323
DEBUG - 2022-05-30 08:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:25:11 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:25:23 --> Total execution time: 0.0620
DEBUG - 2022-05-30 08:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:25:32 --> Total execution time: 1.5619
DEBUG - 2022-05-30 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:55:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:25:47 --> Total execution time: 0.0336
DEBUG - 2022-05-30 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:25:48 --> Total execution time: 0.0270
DEBUG - 2022-05-30 08:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:55:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:25:57 --> Total execution time: 0.0542
DEBUG - 2022-05-30 08:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:01 --> Total execution time: 0.0281
DEBUG - 2022-05-30 08:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:02 --> Total execution time: 0.0309
DEBUG - 2022-05-30 08:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:02 --> Total execution time: 0.0272
DEBUG - 2022-05-30 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:04 --> Total execution time: 0.0415
DEBUG - 2022-05-30 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:10 --> Total execution time: 0.0424
DEBUG - 2022-05-30 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 08:56:12 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-30 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:25 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:28 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:28 --> Total execution time: 0.0234
DEBUG - 2022-05-30 08:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:42 --> Total execution time: 0.0344
DEBUG - 2022-05-30 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:44 --> Total execution time: 0.0272
DEBUG - 2022-05-30 08:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:26:54 --> Total execution time: 1.6533
DEBUG - 2022-05-30 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:27:01 --> Total execution time: 0.0398
DEBUG - 2022-05-30 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:27:07 --> Total execution time: 0.0468
DEBUG - 2022-05-30 08:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:57:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:27:19 --> Total execution time: 0.0318
DEBUG - 2022-05-30 08:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:27:30 --> Total execution time: 1.6838
DEBUG - 2022-05-30 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:28:09 --> Total execution time: 0.0352
DEBUG - 2022-05-30 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:28:09 --> Total execution time: 0.0431
DEBUG - 2022-05-30 08:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:28:20 --> Total execution time: 0.0286
DEBUG - 2022-05-30 08:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:28:21 --> Total execution time: 0.0283
DEBUG - 2022-05-30 08:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:28:41 --> Total execution time: 0.0335
DEBUG - 2022-05-30 08:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:28:51 --> Total execution time: 0.0786
DEBUG - 2022-05-30 08:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:00 --> Total execution time: 0.0526
DEBUG - 2022-05-30 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:08 --> Total execution time: 0.0609
DEBUG - 2022-05-30 08:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:10 --> Total execution time: 0.0343
DEBUG - 2022-05-30 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:18 --> Total execution time: 0.0305
DEBUG - 2022-05-30 08:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 08:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:24 --> Total execution time: 0.0287
DEBUG - 2022-05-30 08:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:27 --> Total execution time: 0.0353
DEBUG - 2022-05-30 08:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:32 --> Total execution time: 0.0314
DEBUG - 2022-05-30 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 08:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 08:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:29:41 --> Total execution time: 0.0577
DEBUG - 2022-05-30 09:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:01 --> Total execution time: 0.0763
DEBUG - 2022-05-30 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:02 --> Total execution time: 0.0598
DEBUG - 2022-05-30 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:10 --> Total execution time: 1.5888
DEBUG - 2022-05-30 09:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:11 --> Total execution time: 0.0493
DEBUG - 2022-05-30 09:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:00:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:14 --> Total execution time: 0.0311
DEBUG - 2022-05-30 09:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:42 --> Total execution time: 0.0296
DEBUG - 2022-05-30 09:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:52 --> Total execution time: 0.0540
DEBUG - 2022-05-30 09:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:30:57 --> Total execution time: 0.0528
DEBUG - 2022-05-30 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:03 --> Total execution time: 0.0390
DEBUG - 2022-05-30 09:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:05 --> Total execution time: 0.0277
DEBUG - 2022-05-30 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:08 --> Total execution time: 0.0297
DEBUG - 2022-05-30 09:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:18 --> Total execution time: 0.0770
DEBUG - 2022-05-30 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:26 --> Total execution time: 0.0437
DEBUG - 2022-05-30 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:41 --> Total execution time: 0.0370
DEBUG - 2022-05-30 09:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:31:51 --> Total execution time: 0.0292
DEBUG - 2022-05-30 09:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:07 --> Total execution time: 1.5569
DEBUG - 2022-05-30 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:02:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 09:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:11 --> Total execution time: 0.0346
DEBUG - 2022-05-30 09:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:33 --> Total execution time: 0.0679
DEBUG - 2022-05-30 09:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:42 --> Total execution time: 1.4864
DEBUG - 2022-05-30 09:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:47 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:47 --> Total execution time: 0.0413
DEBUG - 2022-05-30 09:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:54 --> Total execution time: 0.0523
DEBUG - 2022-05-30 09:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:56 --> Total execution time: 0.0238
DEBUG - 2022-05-30 09:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:32:58 --> Total execution time: 0.0453
DEBUG - 2022-05-30 09:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:33:00 --> Total execution time: 0.0275
DEBUG - 2022-05-30 09:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:03:05 --> Total execution time: 0.0255
DEBUG - 2022-05-30 09:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:03:06 --> Total execution time: 0.0430
DEBUG - 2022-05-30 09:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:03:06 --> Total execution time: 0.0242
DEBUG - 2022-05-30 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:33:11 --> Total execution time: 0.0474
DEBUG - 2022-05-30 09:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:33:18 --> Total execution time: 0.0350
DEBUG - 2022-05-30 09:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:33:24 --> Total execution time: 0.0245
DEBUG - 2022-05-30 19:33:25 --> Total execution time: 1.4566
DEBUG - 2022-05-30 09:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:03:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:33:42 --> Total execution time: 0.0273
DEBUG - 2022-05-30 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:04:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:34:01 --> Total execution time: 0.0510
DEBUG - 2022-05-30 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:34:39 --> Total execution time: 1.4829
DEBUG - 2022-05-30 09:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:35:38 --> Total execution time: 0.0429
DEBUG - 2022-05-30 09:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:07:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 09:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:37:06 --> Total execution time: 1.4809
DEBUG - 2022-05-30 09:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:07:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 09:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:37:52 --> Total execution time: 0.0332
DEBUG - 2022-05-30 09:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:07:56 --> Total execution time: 0.0469
DEBUG - 2022-05-30 09:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:07:57 --> Total execution time: 0.0318
DEBUG - 2022-05-30 09:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:07:57 --> Total execution time: 0.0450
DEBUG - 2022-05-30 09:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:39:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 09:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:39:43 --> Total execution time: 0.0401
DEBUG - 2022-05-30 09:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:39:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 19:39:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 19:39:45 --> Total execution time: 0.1660
DEBUG - 2022-05-30 09:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:39:58 --> Total execution time: 1.4858
DEBUG - 2022-05-30 09:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:40:01 --> Total execution time: 0.0513
DEBUG - 2022-05-30 09:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:40:03 --> Total execution time: 0.0493
DEBUG - 2022-05-30 09:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:40:07 --> Total execution time: 0.0651
DEBUG - 2022-05-30 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:10:28 --> Total execution time: 0.0360
DEBUG - 2022-05-30 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:10:29 --> Total execution time: 0.0295
DEBUG - 2022-05-30 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:10:29 --> Total execution time: 0.0453
DEBUG - 2022-05-30 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:15:28 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:45:28 --> Total execution time: 0.1236
DEBUG - 2022-05-30 09:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:16:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:46:19 --> Total execution time: 0.0304
DEBUG - 2022-05-30 09:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:46:24 --> Total execution time: 0.0234
DEBUG - 2022-05-30 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:16:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:46:38 --> Total execution time: 0.0254
DEBUG - 2022-05-30 09:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:17:16 --> 404 Page Not Found: Contact/index
DEBUG - 2022-05-30 09:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:18:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:48:00 --> Total execution time: 0.0292
DEBUG - 2022-05-30 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:18:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:48:35 --> Total execution time: 0.0288
DEBUG - 2022-05-30 09:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:48:36 --> Total execution time: 0.0183
DEBUG - 2022-05-30 09:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:18:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:48:43 --> Total execution time: 0.0252
DEBUG - 2022-05-30 09:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:08 --> Total execution time: 0.0270
DEBUG - 2022-05-30 09:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:17 --> Total execution time: 0.0649
DEBUG - 2022-05-30 09:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:20 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:20 --> Total execution time: 0.0247
DEBUG - 2022-05-30 09:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:23 --> Total execution time: 0.0277
DEBUG - 2022-05-30 09:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:25 --> Total execution time: 0.0317
DEBUG - 2022-05-30 09:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:29 --> Total execution time: 0.0410
DEBUG - 2022-05-30 09:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:33 --> Total execution time: 0.0286
DEBUG - 2022-05-30 09:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:39 --> Total execution time: 0.0272
DEBUG - 2022-05-30 09:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:51 --> Total execution time: 0.0284
DEBUG - 2022-05-30 09:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:49:55 --> Total execution time: 0.0230
DEBUG - 2022-05-30 09:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:50:11 --> Total execution time: 0.0296
DEBUG - 2022-05-30 09:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:22 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:50:22 --> Total execution time: 0.0281
DEBUG - 2022-05-30 09:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:50:24 --> Total execution time: 0.0304
DEBUG - 2022-05-30 09:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:32 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:50:32 --> Total execution time: 0.0506
DEBUG - 2022-05-30 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:50:34 --> Total execution time: 0.0608
DEBUG - 2022-05-30 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:20:35 --> Total execution time: 0.0274
DEBUG - 2022-05-30 09:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:20:36 --> Total execution time: 0.0267
DEBUG - 2022-05-30 09:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:20:36 --> Total execution time: 0.0397
DEBUG - 2022-05-30 09:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:50:42 --> Total execution time: 0.0309
DEBUG - 2022-05-30 09:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:23:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:23:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 19:53:18 --> Total execution time: 0.0834
DEBUG - 2022-05-30 09:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:53:21 --> Total execution time: 1.5362
DEBUG - 2022-05-30 09:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:23:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 09:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:24:06 --> 404 Page Not Found: Contact/index
DEBUG - 2022-05-30 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:24:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:54:35 --> Total execution time: 0.0216
DEBUG - 2022-05-30 09:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:57:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 09:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:57:43 --> Total execution time: 0.0396
DEBUG - 2022-05-30 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:57:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 19:57:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 19:57:44 --> Total execution time: 0.1812
DEBUG - 2022-05-30 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:27:47 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:57:47 --> Total execution time: 0.0331
DEBUG - 2022-05-30 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:57:56 --> Total execution time: 0.0422
DEBUG - 2022-05-30 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:58:10 --> Total execution time: 0.0434
DEBUG - 2022-05-30 09:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:59:06 --> Total execution time: 0.0828
DEBUG - 2022-05-30 09:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:59:09 --> Total execution time: 0.0299
DEBUG - 2022-05-30 09:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:59:22 --> Total execution time: 0.0255
DEBUG - 2022-05-30 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:59:42 --> Total execution time: 0.0382
DEBUG - 2022-05-30 09:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:29:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:59:55 --> Total execution time: 0.0252
DEBUG - 2022-05-30 09:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:00:05 --> Total execution time: 0.0632
DEBUG - 2022-05-30 09:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:00:49 --> Total execution time: 0.0246
DEBUG - 2022-05-30 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:01:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:01:20 --> Total execution time: 0.0416
DEBUG - 2022-05-30 09:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:01:25 --> Total execution time: 0.0330
DEBUG - 2022-05-30 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:01:34 --> Total execution time: 0.0469
DEBUG - 2022-05-30 09:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:02:33 --> Total execution time: 0.0274
DEBUG - 2022-05-30 09:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:03:41 --> Total execution time: 0.0847
DEBUG - 2022-05-30 09:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:04:08 --> Total execution time: 0.0448
DEBUG - 2022-05-30 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:36:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:36:12 --> 404 Page Not Found: Membership-account/your-profile
DEBUG - 2022-05-30 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:36:57 --> Total execution time: 0.1014
DEBUG - 2022-05-30 09:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:37:05 --> Total execution time: 0.0861
DEBUG - 2022-05-30 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:08:37 --> Total execution time: 0.0372
DEBUG - 2022-05-30 09:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:35 --> Total execution time: 0.0306
DEBUG - 2022-05-30 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:39 --> Total execution time: 0.0293
DEBUG - 2022-05-30 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:48 --> Total execution time: 0.0325
DEBUG - 2022-05-30 09:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:51 --> Total execution time: 0.0240
DEBUG - 2022-05-30 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:56 --> Total execution time: 0.0220
DEBUG - 2022-05-30 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:01 --> Total execution time: 0.0524
DEBUG - 2022-05-30 09:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:22 --> Total execution time: 0.0316
DEBUG - 2022-05-30 09:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:25 --> Total execution time: 0.0508
DEBUG - 2022-05-30 09:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:12:52 --> Total execution time: 0.1491
DEBUG - 2022-05-30 09:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:12:52 --> Total execution time: 0.0320
DEBUG - 2022-05-30 09:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:13:36 --> Total execution time: 0.0451
DEBUG - 2022-05-30 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:14:24 --> Total execution time: 0.0608
DEBUG - 2022-05-30 09:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:14:35 --> Total execution time: 0.0511
DEBUG - 2022-05-30 09:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:15:25 --> Total execution time: 0.0304
DEBUG - 2022-05-30 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:15:37 --> Total execution time: 0.0350
DEBUG - 2022-05-30 09:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:15:43 --> Total execution time: 0.0232
DEBUG - 2022-05-30 09:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:15:46 --> Total execution time: 0.0412
DEBUG - 2022-05-30 09:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:15:55 --> Total execution time: 0.0247
DEBUG - 2022-05-30 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:46:04 --> Total execution time: 0.0195
DEBUG - 2022-05-30 09:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:46:40 --> Total execution time: 0.0397
DEBUG - 2022-05-30 09:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:46:49 --> Total execution time: 0.0361
DEBUG - 2022-05-30 09:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:16:51 --> Total execution time: 0.0321
DEBUG - 2022-05-30 09:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:16:59 --> Total execution time: 0.0300
DEBUG - 2022-05-30 09:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:17:06 --> Total execution time: 0.0456
DEBUG - 2022-05-30 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:17:59 --> Total execution time: 0.0344
DEBUG - 2022-05-30 09:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:15 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:15 --> Total execution time: 0.0335
DEBUG - 2022-05-30 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:21 --> Total execution time: 0.0283
DEBUG - 2022-05-30 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:22 --> Total execution time: 0.0615
DEBUG - 2022-05-30 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:28 --> Total execution time: 0.0309
DEBUG - 2022-05-30 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:48:38 --> Total execution time: 0.0306
DEBUG - 2022-05-30 09:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:42 --> Total execution time: 0.0396
DEBUG - 2022-05-30 09:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:47 --> Total execution time: 0.0330
DEBUG - 2022-05-30 09:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:18:52 --> Total execution time: 0.0211
DEBUG - 2022-05-30 09:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:00 --> Total execution time: 0.0487
DEBUG - 2022-05-30 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:02 --> Total execution time: 0.0384
DEBUG - 2022-05-30 09:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:18 --> Total execution time: 0.0640
DEBUG - 2022-05-30 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:25 --> Total execution time: 0.0534
DEBUG - 2022-05-30 09:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:32 --> Total execution time: 0.0268
DEBUG - 2022-05-30 09:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:45 --> Total execution time: 0.0282
DEBUG - 2022-05-30 09:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:58 --> Total execution time: 0.0306
DEBUG - 2022-05-30 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:20:25 --> Total execution time: 0.0310
DEBUG - 2022-05-30 09:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:20:40 --> Total execution time: 0.0336
DEBUG - 2022-05-30 20:20:41 --> Total execution time: 0.0941
DEBUG - 2022-05-30 09:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:20:57 --> Total execution time: 0.0286
DEBUG - 2022-05-30 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:21:01 --> Total execution time: 0.0295
DEBUG - 2022-05-30 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:21:06 --> Total execution time: 0.0276
DEBUG - 2022-05-30 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:21:57 --> Total execution time: 0.0290
DEBUG - 2022-05-30 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:08 --> Total execution time: 0.0472
DEBUG - 2022-05-30 09:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:09 --> Total execution time: 0.0409
DEBUG - 2022-05-30 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:12 --> Total execution time: 0.0461
DEBUG - 2022-05-30 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:18 --> Total execution time: 0.0287
DEBUG - 2022-05-30 09:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:23 --> Total execution time: 0.0327
DEBUG - 2022-05-30 09:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:30 --> Total execution time: 0.0529
DEBUG - 2022-05-30 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:36 --> Total execution time: 0.0319
DEBUG - 2022-05-30 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:23:42 --> Total execution time: 0.0552
DEBUG - 2022-05-30 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:02 --> Total execution time: 0.0339
DEBUG - 2022-05-30 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:02 --> Total execution time: 0.0237
DEBUG - 2022-05-30 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:12 --> Total execution time: 0.0246
DEBUG - 2022-05-30 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:14 --> Total execution time: 0.0287
DEBUG - 2022-05-30 09:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:17 --> Total execution time: 0.0279
DEBUG - 2022-05-30 09:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:54:26 --> Total execution time: 0.0230
DEBUG - 2022-05-30 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:27 --> Total execution time: 0.0289
DEBUG - 2022-05-30 09:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:33 --> Total execution time: 0.0337
DEBUG - 2022-05-30 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:34 --> Total execution time: 0.0286
DEBUG - 2022-05-30 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:41 --> Total execution time: 0.0433
DEBUG - 2022-05-30 09:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:49 --> Total execution time: 0.0270
DEBUG - 2022-05-30 09:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:50 --> No URI present. Default controller set.
DEBUG - 2022-05-30 09:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:50 --> Total execution time: 0.0561
DEBUG - 2022-05-30 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:51 --> Total execution time: 0.0285
DEBUG - 2022-05-30 20:24:53 --> Total execution time: 4.4114
DEBUG - 2022-05-30 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:55 --> Total execution time: 0.0268
DEBUG - 2022-05-30 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:24:59 --> Total execution time: 0.0292
DEBUG - 2022-05-30 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:25:02 --> Total execution time: 0.0817
DEBUG - 2022-05-30 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:25:04 --> Total execution time: 0.0464
DEBUG - 2022-05-30 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:25:13 --> Total execution time: 0.0268
DEBUG - 2022-05-30 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:25:16 --> Total execution time: 0.0334
DEBUG - 2022-05-30 09:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:55:31 --> 404 Page Not Found: Wp-sitemap-posts-lp_lesson-1xml/index
DEBUG - 2022-05-30 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:25:42 --> Total execution time: 0.0313
DEBUG - 2022-05-30 09:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:55:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:55:55 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:55:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:56:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:56:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:56:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:56:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:56:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 09:56:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 09:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:26:23 --> Total execution time: 0.1987
DEBUG - 2022-05-30 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:26:57 --> Total execution time: 0.0324
DEBUG - 2022-05-30 09:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:27:11 --> Total execution time: 0.0273
DEBUG - 2022-05-30 09:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:27:16 --> Total execution time: 0.0266
DEBUG - 2022-05-30 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 09:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 09:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:27:20 --> Total execution time: 0.0300
DEBUG - 2022-05-30 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:30:03 --> Total execution time: 0.1506
DEBUG - 2022-05-30 10:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:13 --> Total execution time: 0.1038
DEBUG - 2022-05-30 10:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:03:33 --> Total execution time: 0.0187
DEBUG - 2022-05-30 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:03:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:35 --> Total execution time: 0.0287
DEBUG - 2022-05-30 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:49 --> Total execution time: 0.0247
DEBUG - 2022-05-30 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:54 --> Total execution time: 0.0373
DEBUG - 2022-05-30 10:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:34:02 --> Total execution time: 0.1021
DEBUG - 2022-05-30 10:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:04:03 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:34:03 --> Total execution time: 0.0428
DEBUG - 2022-05-30 10:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:06:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:14 --> Total execution time: 0.0747
DEBUG - 2022-05-30 10:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:06:28 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:28 --> Total execution time: 0.0236
DEBUG - 2022-05-30 10:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:07:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:06 --> Total execution time: 0.0254
DEBUG - 2022-05-30 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:08 --> Total execution time: 0.0237
DEBUG - 2022-05-30 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:07:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:31 --> Total execution time: 0.0232
DEBUG - 2022-05-30 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:38:31 --> Total execution time: 1.5133
DEBUG - 2022-05-30 10:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:08:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:08:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 10:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:08:47 --> Total execution time: 0.0275
DEBUG - 2022-05-30 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:08:48 --> Total execution time: 0.0346
DEBUG - 2022-05-30 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:08:48 --> Total execution time: 0.0258
DEBUG - 2022-05-30 10:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:08:50 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:38:50 --> Total execution time: 0.0333
DEBUG - 2022-05-30 10:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:09:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:39:42 --> Total execution time: 0.0336
DEBUG - 2022-05-30 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:09:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:39:43 --> Total execution time: 0.0324
DEBUG - 2022-05-30 10:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:10:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:40:34 --> Total execution time: 0.0273
DEBUG - 2022-05-30 10:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:10:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:40:35 --> Total execution time: 0.0469
DEBUG - 2022-05-30 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:10:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:40:37 --> Total execution time: 0.0218
DEBUG - 2022-05-30 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:12:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 10:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:14:50 --> 404 Page Not Found: Membership-account/your-profile
DEBUG - 2022-05-30 10:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:51:18 --> Total execution time: 0.0814
DEBUG - 2022-05-30 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:21:48 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:51:48 --> Total execution time: 0.0361
DEBUG - 2022-05-30 10:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:21:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:51:54 --> Total execution time: 0.0293
DEBUG - 2022-05-30 10:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:12 --> Total execution time: 0.0263
DEBUG - 2022-05-30 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:21 --> Total execution time: 0.0437
DEBUG - 2022-05-30 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:30 --> Total execution time: 0.0220
DEBUG - 2022-05-30 10:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:33 --> Total execution time: 0.0535
DEBUG - 2022-05-30 10:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:41 --> Total execution time: 0.0222
DEBUG - 2022-05-30 10:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:51 --> Total execution time: 0.0291
DEBUG - 2022-05-30 10:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:54 --> Total execution time: 0.0396
DEBUG - 2022-05-30 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:22:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:52:57 --> Total execution time: 0.0586
DEBUG - 2022-05-30 10:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:53:17 --> Total execution time: 0.0519
DEBUG - 2022-05-30 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:58:07 --> Total execution time: 0.0196
DEBUG - 2022-05-30 10:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:00:23 --> Total execution time: 0.5378
DEBUG - 2022-05-30 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:31:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:01:01 --> Total execution time: 0.0531
DEBUG - 2022-05-30 10:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:31:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:01:39 --> Total execution time: 0.0464
DEBUG - 2022-05-30 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:01:56 --> Total execution time: 0.0281
DEBUG - 2022-05-30 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:01:59 --> Total execution time: 0.0467
DEBUG - 2022-05-30 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:02 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:02:02 --> Total execution time: 0.0269
DEBUG - 2022-05-30 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:02:07 --> Total execution time: 0.0276
DEBUG - 2022-05-30 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:02:09 --> Total execution time: 0.0486
DEBUG - 2022-05-30 10:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:02:49 --> Total execution time: 0.0223
DEBUG - 2022-05-30 10:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:02:52 --> Total execution time: 0.0244
DEBUG - 2022-05-30 10:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:03:03 --> Total execution time: 0.0333
DEBUG - 2022-05-30 10:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:03:05 --> Total execution time: 0.0323
DEBUG - 2022-05-30 10:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:03:09 --> Total execution time: 0.0334
DEBUG - 2022-05-30 10:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:03:16 --> Total execution time: 0.0350
DEBUG - 2022-05-30 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:03:27 --> Total execution time: 0.0242
DEBUG - 2022-05-30 10:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:33:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:03:55 --> Total execution time: 0.0259
DEBUG - 2022-05-30 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:01 --> Total execution time: 0.0216
DEBUG - 2022-05-30 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:01 --> Total execution time: 0.0228
DEBUG - 2022-05-30 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:23 --> Total execution time: 0.0210
DEBUG - 2022-05-30 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:31 --> Total execution time: 0.0241
DEBUG - 2022-05-30 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:41 --> Total execution time: 0.0255
DEBUG - 2022-05-30 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:36:44 --> Total execution time: 0.0334
DEBUG - 2022-05-30 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:36:46 --> Total execution time: 0.0266
DEBUG - 2022-05-30 10:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:36:46 --> Total execution time: 0.0452
DEBUG - 2022-05-30 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:55 --> Total execution time: 0.0256
DEBUG - 2022-05-30 10:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:36:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:06:57 --> Total execution time: 0.0388
DEBUG - 2022-05-30 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:41:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:41:27 --> 404 Page Not Found: Shop/index
DEBUG - 2022-05-30 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:11:52 --> Total execution time: 0.0706
DEBUG - 2022-05-30 10:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:42:43 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:42:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 10:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:42:50 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:43:03 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:13:06 --> Total execution time: 0.0708
DEBUG - 2022-05-30 10:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:43:06 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:43:09 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:43:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:43:12 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:44:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:14:58 --> Total execution time: 0.0328
DEBUG - 2022-05-30 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:15:06 --> Total execution time: 0.0639
DEBUG - 2022-05-30 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:15:14 --> Total execution time: 0.0232
DEBUG - 2022-05-30 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:15:20 --> Total execution time: 0.0352
DEBUG - 2022-05-30 10:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:45:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:15:44 --> Total execution time: 0.0347
DEBUG - 2022-05-30 10:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:16:05 --> Total execution time: 0.0240
DEBUG - 2022-05-30 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:46:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:16:13 --> Total execution time: 0.0256
DEBUG - 2022-05-30 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:16:29 --> Total execution time: 0.0229
DEBUG - 2022-05-30 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:46:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:16:39 --> Total execution time: 0.0272
DEBUG - 2022-05-30 10:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:47:09 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:47:13 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:20:21 --> Total execution time: 0.0261
DEBUG - 2022-05-30 10:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:20:25 --> Total execution time: 0.0251
DEBUG - 2022-05-30 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:20:39 --> Total execution time: 0.0384
DEBUG - 2022-05-30 10:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:20:50 --> Total execution time: 0.0428
DEBUG - 2022-05-30 10:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:21:04 --> Total execution time: 0.0592
DEBUG - 2022-05-30 10:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:52:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:14 --> Total execution time: 0.0253
DEBUG - 2022-05-30 10:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:52:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:37 --> Total execution time: 0.0257
DEBUG - 2022-05-30 10:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:02 --> Total execution time: 0.0239
DEBUG - 2022-05-30 10:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:10 --> Total execution time: 0.0231
DEBUG - 2022-05-30 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:38 --> Total execution time: 0.0238
DEBUG - 2022-05-30 10:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:44 --> Total execution time: 0.0273
DEBUG - 2022-05-30 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:56 --> Total execution time: 0.0284
DEBUG - 2022-05-30 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 10:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:58 --> Total execution time: 0.0256
DEBUG - 2022-05-30 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:24:39 --> Total execution time: 0.0257
DEBUG - 2022-05-30 10:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:24:43 --> Total execution time: 0.0306
DEBUG - 2022-05-30 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:25:05 --> Total execution time: 0.1504
DEBUG - 2022-05-30 10:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:25:27 --> Total execution time: 0.0291
DEBUG - 2022-05-30 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:56:27 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:56:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 10:57:34 --> 404 Page Not Found: My-account/index
DEBUG - 2022-05-30 10:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:58:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:09 --> Total execution time: 0.0528
DEBUG - 2022-05-30 10:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:13 --> Total execution time: 0.0276
DEBUG - 2022-05-30 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:52 --> Total execution time: 0.0188
DEBUG - 2022-05-30 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:00 --> Total execution time: 0.0287
DEBUG - 2022-05-30 10:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:09 --> Total execution time: 0.0211
DEBUG - 2022-05-30 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:14 --> Total execution time: 0.0525
DEBUG - 2022-05-30 10:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:31 --> Total execution time: 0.0271
DEBUG - 2022-05-30 10:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:31 --> Total execution time: 0.0480
DEBUG - 2022-05-30 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:38 --> Total execution time: 0.0302
DEBUG - 2022-05-30 10:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:47 --> Total execution time: 0.0339
DEBUG - 2022-05-30 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:51 --> Total execution time: 0.0232
DEBUG - 2022-05-30 10:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:55 --> Total execution time: 0.0381
DEBUG - 2022-05-30 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 10:59:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 10:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 10:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:58 --> Total execution time: 0.0328
DEBUG - 2022-05-30 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:02 --> Total execution time: 0.0268
DEBUG - 2022-05-30 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:03 --> Total execution time: 0.0252
DEBUG - 2022-05-30 11:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:44 --> Total execution time: 0.0440
DEBUG - 2022-05-30 11:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:31:02 --> Total execution time: 0.0318
DEBUG - 2022-05-30 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:31:06 --> Total execution time: 0.0317
DEBUG - 2022-05-30 11:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:31:40 --> Total execution time: 0.0198
DEBUG - 2022-05-30 11:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:31:40 --> Total execution time: 0.0274
DEBUG - 2022-05-30 11:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:01:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:31:53 --> Total execution time: 0.0454
DEBUG - 2022-05-30 11:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:37:30 --> Total execution time: 0.1135
DEBUG - 2022-05-30 11:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:37:50 --> Total execution time: 0.2031
DEBUG - 2022-05-30 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:37:55 --> Total execution time: 0.0316
DEBUG - 2022-05-30 11:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:03 --> Total execution time: 4.6518
DEBUG - 2022-05-30 11:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:08:16 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 11:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:10:40 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 11:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:41:00 --> Total execution time: 0.0412
DEBUG - 2022-05-30 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:12:01 --> Total execution time: 0.0639
DEBUG - 2022-05-30 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:12:03 --> Total execution time: 0.0252
DEBUG - 2022-05-30 11:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:12:03 --> Total execution time: 0.0389
DEBUG - 2022-05-30 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:42:36 --> Total execution time: 0.0231
DEBUG - 2022-05-30 11:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:42:42 --> Total execution time: 0.0321
DEBUG - 2022-05-30 11:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:42:44 --> Total execution time: 0.0321
DEBUG - 2022-05-30 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:42:47 --> Total execution time: 0.0382
DEBUG - 2022-05-30 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:42:54 --> Total execution time: 0.0240
DEBUG - 2022-05-30 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:14:10 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:44:10 --> Total execution time: 0.0315
DEBUG - 2022-05-30 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:44:13 --> Total execution time: 0.0277
DEBUG - 2022-05-30 11:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:44:44 --> Total execution time: 0.0187
DEBUG - 2022-05-30 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:45:44 --> Total execution time: 0.0223
DEBUG - 2022-05-30 11:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:23 --> Total execution time: 0.0401
DEBUG - 2022-05-30 11:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:32 --> Total execution time: 0.0255
DEBUG - 2022-05-30 11:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:34 --> Total execution time: 0.0249
DEBUG - 2022-05-30 11:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:36 --> Total execution time: 0.0264
DEBUG - 2022-05-30 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:38 --> Total execution time: 0.0284
DEBUG - 2022-05-30 11:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:46 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:46 --> Total execution time: 0.0252
DEBUG - 2022-05-30 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:46:50 --> Total execution time: 0.0302
DEBUG - 2022-05-30 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:09 --> Total execution time: 0.0320
DEBUG - 2022-05-30 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:23 --> Total execution time: 0.0229
DEBUG - 2022-05-30 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:29 --> Total execution time: 0.0253
DEBUG - 2022-05-30 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:52 --> Total execution time: 0.0277
DEBUG - 2022-05-30 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:54 --> Total execution time: 0.0261
DEBUG - 2022-05-30 11:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:14 --> Total execution time: 0.0334
DEBUG - 2022-05-30 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:18 --> Total execution time: 0.0248
DEBUG - 2022-05-30 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:22 --> Total execution time: 0.0281
DEBUG - 2022-05-30 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:30 --> Total execution time: 0.0273
DEBUG - 2022-05-30 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:31 --> Total execution time: 0.0231
DEBUG - 2022-05-30 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:45 --> Total execution time: 0.0253
DEBUG - 2022-05-30 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:48:46 --> Total execution time: 0.0278
DEBUG - 2022-05-30 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:49:09 --> Total execution time: 0.0448
DEBUG - 2022-05-30 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:50:03 --> Total execution time: 0.0205
DEBUG - 2022-05-30 11:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:29 --> Total execution time: 0.0204
DEBUG - 2022-05-30 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:31 --> Total execution time: 0.0204
DEBUG - 2022-05-30 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:33 --> Total execution time: 0.0212
DEBUG - 2022-05-30 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:35 --> Total execution time: 0.0253
DEBUG - 2022-05-30 11:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:37 --> Total execution time: 0.0254
DEBUG - 2022-05-30 11:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:39 --> Total execution time: 0.0249
DEBUG - 2022-05-30 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:41 --> Total execution time: 0.0212
DEBUG - 2022-05-30 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:43 --> Total execution time: 0.0214
DEBUG - 2022-05-30 11:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:45 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:45 --> Total execution time: 0.0294
DEBUG - 2022-05-30 11:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:47 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:47 --> Total execution time: 0.0204
DEBUG - 2022-05-30 11:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:49 --> Total execution time: 0.0215
DEBUG - 2022-05-30 11:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:51 --> Total execution time: 0.0207
DEBUG - 2022-05-30 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:53 --> Total execution time: 0.0286
DEBUG - 2022-05-30 11:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:55 --> Total execution time: 0.0278
DEBUG - 2022-05-30 11:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:57 --> Total execution time: 0.0219
DEBUG - 2022-05-30 11:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:21:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:59 --> Total execution time: 0.0318
DEBUG - 2022-05-30 11:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:01 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:52:01 --> Total execution time: 0.0201
DEBUG - 2022-05-30 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:22:02 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-05-30 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:22:02 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-05-30 11:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:22:03 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-05-30 11:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:22:03 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-05-30 11:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:52:07 --> Total execution time: 0.0257
DEBUG - 2022-05-30 11:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:52:08 --> Total execution time: 0.0393
DEBUG - 2022-05-30 11:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:10 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:52:10 --> Total execution time: 0.0308
DEBUG - 2022-05-30 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:52:31 --> Total execution time: 0.0585
DEBUG - 2022-05-30 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:52:40 --> Total execution time: 0.0287
DEBUG - 2022-05-30 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:22:43 --> Total execution time: 0.0253
DEBUG - 2022-05-30 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:22:44 --> Total execution time: 0.0277
DEBUG - 2022-05-30 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:22:44 --> Total execution time: 0.0512
DEBUG - 2022-05-30 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:22:57 --> Total execution time: 0.0245
DEBUG - 2022-05-30 11:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:22:58 --> Total execution time: 0.0287
DEBUG - 2022-05-30 11:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:22:58 --> Total execution time: 0.0335
DEBUG - 2022-05-30 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:53:02 --> Total execution time: 0.0680
DEBUG - 2022-05-30 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:23:11 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:23:11 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:23:21 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 11:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:23:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:53:38 --> Total execution time: 0.0218
DEBUG - 2022-05-30 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:28:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:58:07 --> Total execution time: 1.6279
DEBUG - 2022-05-30 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:28:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 11:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:00 --> Total execution time: 0.0292
DEBUG - 2022-05-30 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 21:59:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 21:59:02 --> Total execution time: 0.1570
DEBUG - 2022-05-30 11:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:21 --> Total execution time: 0.0535
DEBUG - 2022-05-30 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:34 --> Total execution time: 0.0408
DEBUG - 2022-05-30 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:39 --> Total execution time: 0.0259
DEBUG - 2022-05-30 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:51 --> Total execution time: 0.0324
DEBUG - 2022-05-30 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:54 --> Total execution time: 0.0335
DEBUG - 2022-05-30 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:00:55 --> Total execution time: 0.0173
DEBUG - 2022-05-30 11:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:01 --> Total execution time: 0.0239
DEBUG - 2022-05-30 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:26 --> Total execution time: 0.0300
DEBUG - 2022-05-30 11:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:33 --> Total execution time: 0.0267
DEBUG - 2022-05-30 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:42 --> Total execution time: 0.0264
DEBUG - 2022-05-30 11:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:47 --> Total execution time: 0.0171
DEBUG - 2022-05-30 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:50 --> Total execution time: 0.0175
DEBUG - 2022-05-30 11:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:54 --> Total execution time: 0.0176
DEBUG - 2022-05-30 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:34:04 --> Total execution time: 0.0262
DEBUG - 2022-05-30 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:34:05 --> Total execution time: 0.0388
DEBUG - 2022-05-30 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:34:05 --> Total execution time: 0.0589
DEBUG - 2022-05-30 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:04:57 --> Total execution time: 0.0304
DEBUG - 2022-05-30 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:35:13 --> Total execution time: 0.0248
DEBUG - 2022-05-30 11:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:35:14 --> Total execution time: 0.0288
DEBUG - 2022-05-30 11:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:35:14 --> Total execution time: 0.0302
DEBUG - 2022-05-30 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:05:19 --> Total execution time: 0.0233
DEBUG - 2022-05-30 11:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:05:48 --> Total execution time: 0.0247
DEBUG - 2022-05-30 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:06:14 --> Total execution time: 0.0256
DEBUG - 2022-05-30 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:06:37 --> Total execution time: 0.0231
DEBUG - 2022-05-30 11:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:00 --> Total execution time: 0.0315
DEBUG - 2022-05-30 11:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:37:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:03 --> Total execution time: 0.0315
DEBUG - 2022-05-30 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:04 --> Total execution time: 0.0236
DEBUG - 2022-05-30 11:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:04 --> Total execution time: 0.0488
DEBUG - 2022-05-30 11:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:06 --> Total execution time: 0.0232
DEBUG - 2022-05-30 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:38:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:24 --> Total execution time: 0.0243
DEBUG - 2022-05-30 11:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:38 --> Total execution time: 0.0345
DEBUG - 2022-05-30 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:38:44 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-05-30 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:44 --> Total execution time: 0.0182
DEBUG - 2022-05-30 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:46 --> Total execution time: 0.0287
DEBUG - 2022-05-30 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:11 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:12 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:14 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-admin/js
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: _profiler/phpinfo
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Cdn-cgi/scripts
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:17 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:17 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:17 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:18 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:18 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:18 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:18 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:18 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:18 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:19 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:19 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:19 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:09:20 --> Total execution time: 0.0686
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:39:20 --> UTF-8 Support Enabled
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:20 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:21 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:21 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-05-30 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:22 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:22 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:22 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:22 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:22 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:23 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:23 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:23 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:24 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:24 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:24 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:24 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-30 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:24 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 11:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:09:33 --> Total execution time: 0.0205
DEBUG - 2022-05-30 11:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:09:38 --> Total execution time: 0.0566
DEBUG - 2022-05-30 11:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:48 --> 404 Page Not Found: Wp-includes/class.wp.php
DEBUG - 2022-05-30 11:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:39:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-30 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:04 --> Total execution time: 0.0416
DEBUG - 2022-05-30 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:27 --> Total execution time: 0.0474
DEBUG - 2022-05-30 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:39 --> Total execution time: 0.0442
DEBUG - 2022-05-30 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:40 --> Total execution time: 0.0248
DEBUG - 2022-05-30 11:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:45 --> Total execution time: 0.0333
DEBUG - 2022-05-30 11:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:53 --> Total execution time: 0.0456
DEBUG - 2022-05-30 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:20 --> Total execution time: 0.0752
DEBUG - 2022-05-30 11:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:33 --> Total execution time: 0.0333
DEBUG - 2022-05-30 11:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:41 --> Total execution time: 0.0544
DEBUG - 2022-05-30 11:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:41 --> Total execution time: 0.0412
DEBUG - 2022-05-30 11:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:50 --> Total execution time: 0.0483
DEBUG - 2022-05-30 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:57 --> Total execution time: 0.0538
DEBUG - 2022-05-30 11:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:59 --> Total execution time: 0.0517
DEBUG - 2022-05-30 11:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:00 --> Total execution time: 0.0365
DEBUG - 2022-05-30 11:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:17 --> Total execution time: 0.0260
DEBUG - 2022-05-30 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:25 --> Total execution time: 0.0229
DEBUG - 2022-05-30 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:56 --> Total execution time: 0.0269
DEBUG - 2022-05-30 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:12 --> Total execution time: 0.0155
DEBUG - 2022-05-30 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:12 --> Total execution time: 0.0180
DEBUG - 2022-05-30 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:14 --> Total execution time: 0.0418
DEBUG - 2022-05-30 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:22 --> Total execution time: 0.0388
DEBUG - 2022-05-30 11:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:24 --> Total execution time: 0.0358
DEBUG - 2022-05-30 11:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:29 --> Total execution time: 0.0337
DEBUG - 2022-05-30 11:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:29 --> Total execution time: 0.0609
DEBUG - 2022-05-30 11:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:33 --> Total execution time: 0.0940
DEBUG - 2022-05-30 11:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:45 --> Total execution time: 0.0459
DEBUG - 2022-05-30 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:48 --> Total execution time: 0.0196
DEBUG - 2022-05-30 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:49 --> Total execution time: 0.0223
DEBUG - 2022-05-30 11:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:53 --> Total execution time: 0.0230
DEBUG - 2022-05-30 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:57 --> Total execution time: 0.0280
DEBUG - 2022-05-30 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:13:59 --> Total execution time: 0.0369
DEBUG - 2022-05-30 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:14:01 --> Total execution time: 0.0322
DEBUG - 2022-05-30 11:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:14:07 --> Total execution time: 0.0269
DEBUG - 2022-05-30 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:18 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:14:18 --> Total execution time: 0.0295
DEBUG - 2022-05-30 11:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:44:23 --> Total execution time: 0.0255
DEBUG - 2022-05-30 11:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:44:29 --> Total execution time: 0.0326
DEBUG - 2022-05-30 11:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:44:29 --> Total execution time: 0.0425
DEBUG - 2022-05-30 11:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:14:34 --> Total execution time: 0.0472
DEBUG - 2022-05-30 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:44:50 --> Total execution time: 0.0259
DEBUG - 2022-05-30 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:31 --> Total execution time: 0.0338
DEBUG - 2022-05-30 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:45 --> Total execution time: 0.0270
DEBUG - 2022-05-30 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:46 --> Total execution time: 0.0331
DEBUG - 2022-05-30 11:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:46 --> Total execution time: 0.0514
DEBUG - 2022-05-30 11:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:50 --> Total execution time: 0.0338
DEBUG - 2022-05-30 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:45:52 --> Total execution time: 0.0241
DEBUG - 2022-05-30 11:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:56 --> Total execution time: 0.0341
DEBUG - 2022-05-30 11:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:16:04 --> Total execution time: 0.0420
DEBUG - 2022-05-30 11:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:46:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:16:40 --> Total execution time: 1.4748
DEBUG - 2022-05-30 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:46:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 11:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:29 --> Total execution time: 0.0217
DEBUG - 2022-05-30 11:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:34 --> Total execution time: 1.5314
DEBUG - 2022-05-30 11:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:35 --> Total execution time: 0.0231
DEBUG - 2022-05-30 11:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:40 --> Total execution time: 0.0335
DEBUG - 2022-05-30 11:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:41 --> Total execution time: 0.0240
DEBUG - 2022-05-30 11:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:43 --> Total execution time: 0.0423
DEBUG - 2022-05-30 11:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:55 --> Total execution time: 0.0214
DEBUG - 2022-05-30 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:47:57 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:57 --> Total execution time: 0.0293
DEBUG - 2022-05-30 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:04 --> Total execution time: 0.0244
DEBUG - 2022-05-30 11:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:06 --> Total execution time: 0.0380
DEBUG - 2022-05-30 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:07 --> Total execution time: 0.0389
DEBUG - 2022-05-30 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:21 --> Total execution time: 0.0175
DEBUG - 2022-05-30 11:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:34 --> Total execution time: 0.0288
DEBUG - 2022-05-30 11:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:41 --> Total execution time: 0.0413
DEBUG - 2022-05-30 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:55 --> Total execution time: 0.0182
DEBUG - 2022-05-30 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:58 --> Total execution time: 0.0170
DEBUG - 2022-05-30 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:59 --> Total execution time: 0.0560
DEBUG - 2022-05-30 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:04 --> Total execution time: 0.0446
DEBUG - 2022-05-30 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:22 --> Total execution time: 0.0509
DEBUG - 2022-05-30 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:22 --> Total execution time: 0.0233
DEBUG - 2022-05-30 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:23 --> Total execution time: 0.0236
DEBUG - 2022-05-30 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:38 --> Total execution time: 0.0329
DEBUG - 2022-05-30 11:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:45 --> Total execution time: 0.0425
DEBUG - 2022-05-30 11:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:48 --> Total execution time: 0.0229
DEBUG - 2022-05-30 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:49 --> Total execution time: 0.0234
DEBUG - 2022-05-30 11:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:50 --> Total execution time: 0.0187
DEBUG - 2022-05-30 11:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:50 --> Total execution time: 0.0586
DEBUG - 2022-05-30 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:55 --> Total execution time: 0.0293
DEBUG - 2022-05-30 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:56 --> Total execution time: 0.0254
DEBUG - 2022-05-30 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:57 --> Total execution time: 0.0231
DEBUG - 2022-05-30 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:19:59 --> Total execution time: 0.0267
DEBUG - 2022-05-30 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:20:04 --> Total execution time: 0.1049
DEBUG - 2022-05-30 11:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:20:24 --> Total execution time: 0.0228
DEBUG - 2022-05-30 11:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:20:36 --> Total execution time: 0.0792
DEBUG - 2022-05-30 11:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:20:43 --> Total execution time: 0.0436
DEBUG - 2022-05-30 11:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:20:50 --> Total execution time: 0.0432
DEBUG - 2022-05-30 11:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:21:20 --> Total execution time: 0.0451
DEBUG - 2022-05-30 11:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:51:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:21:29 --> Total execution time: 0.0254
DEBUG - 2022-05-30 11:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:21:38 --> Total execution time: 1.4637
DEBUG - 2022-05-30 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:52:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:22:04 --> Total execution time: 0.0278
DEBUG - 2022-05-30 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:22:09 --> Total execution time: 1.4714
DEBUG - 2022-05-30 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:44 --> Total execution time: 0.0422
DEBUG - 2022-05-30 11:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 22:23:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 22:23:46 --> Total execution time: 0.1543
DEBUG - 2022-05-30 11:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 11:53:53 --> 404 Page Not Found: Lessons/paid-method-for-unlimited-leads
DEBUG - 2022-05-30 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:25:07 --> Total execution time: 0.0459
DEBUG - 2022-05-30 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:55:25 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:25:25 --> Total execution time: 0.0206
DEBUG - 2022-05-30 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:55:26 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:25:26 --> Total execution time: 0.0209
DEBUG - 2022-05-30 11:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:25:30 --> Total execution time: 0.0186
DEBUG - 2022-05-30 11:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:25:58 --> Total execution time: 0.0281
DEBUG - 2022-05-30 11:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:03 --> Total execution time: 0.0453
DEBUG - 2022-05-30 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:07 --> Total execution time: 0.0270
DEBUG - 2022-05-30 11:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:11 --> Total execution time: 0.0312
DEBUG - 2022-05-30 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:14 --> Total execution time: 0.0592
DEBUG - 2022-05-30 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:25 --> Total execution time: 0.0278
DEBUG - 2022-05-30 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:29 --> Total execution time: 0.0437
DEBUG - 2022-05-30 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:35 --> Total execution time: 0.0587
DEBUG - 2022-05-30 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:49 --> Total execution time: 0.0434
DEBUG - 2022-05-30 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:27:30 --> Total execution time: 0.0319
DEBUG - 2022-05-30 11:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:27:47 --> Total execution time: 0.0312
DEBUG - 2022-05-30 11:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:57:59 --> Total execution time: 0.0252
DEBUG - 2022-05-30 11:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:09 --> Total execution time: 0.0297
DEBUG - 2022-05-30 11:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:21 --> Total execution time: 0.0483
DEBUG - 2022-05-30 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:23 --> Total execution time: 0.0354
DEBUG - 2022-05-30 11:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:28 --> Total execution time: 0.0425
DEBUG - 2022-05-30 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:36 --> Total execution time: 0.0191
DEBUG - 2022-05-30 11:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:41 --> Total execution time: 0.0180
DEBUG - 2022-05-30 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:48 --> Total execution time: 0.0300
DEBUG - 2022-05-30 11:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:50 --> Total execution time: 0.0376
DEBUG - 2022-05-30 11:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:52 --> Total execution time: 0.0336
DEBUG - 2022-05-30 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:53 --> Total execution time: 0.0325
DEBUG - 2022-05-30 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:54 --> Total execution time: 0.0344
DEBUG - 2022-05-30 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:55 --> Total execution time: 0.0345
DEBUG - 2022-05-30 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:56 --> Total execution time: 0.0431
DEBUG - 2022-05-30 22:28:57 --> Total execution time: 1.6458
DEBUG - 2022-05-30 11:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:28:58 --> Total execution time: 1.7784
DEBUG - 2022-05-30 11:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:58:59 --> Total execution time: 0.0224
DEBUG - 2022-05-30 11:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:09 --> Total execution time: 0.0306
DEBUG - 2022-05-30 11:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:10 --> Total execution time: 0.0264
DEBUG - 2022-05-30 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:13 --> Total execution time: 0.0348
DEBUG - 2022-05-30 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:19 --> Total execution time: 0.0260
DEBUG - 2022-05-30 11:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:33 --> Total execution time: 0.0254
DEBUG - 2022-05-30 11:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 11:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:36 --> Total execution time: 0.0271
DEBUG - 2022-05-30 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 11:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:44 --> Total execution time: 0.0242
DEBUG - 2022-05-30 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:30:03 --> Total execution time: 0.0203
DEBUG - 2022-05-30 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:00:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:30:12 --> Total execution time: 0.0423
DEBUG - 2022-05-30 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:00:50 --> Total execution time: 0.0340
DEBUG - 2022-05-30 12:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:00:59 --> Total execution time: 0.0536
DEBUG - 2022-05-30 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:01:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:31:13 --> Total execution time: 0.0300
DEBUG - 2022-05-30 12:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:32:40 --> Total execution time: 0.0549
DEBUG - 2022-05-30 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:33:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:33:34 --> Total execution time: 0.0689
DEBUG - 2022-05-30 12:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:33:50 --> Total execution time: 0.0283
DEBUG - 2022-05-30 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:03:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:33:55 --> Total execution time: 0.0209
DEBUG - 2022-05-30 12:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:04:07 --> Total execution time: 0.0263
DEBUG - 2022-05-30 12:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:04:08 --> Total execution time: 0.0278
DEBUG - 2022-05-30 12:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:04:08 --> Total execution time: 0.0512
DEBUG - 2022-05-30 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:04:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:34:11 --> Total execution time: 0.0604
DEBUG - 2022-05-30 12:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:34:35 --> Total execution time: 0.0267
DEBUG - 2022-05-30 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:05:05 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:35:05 --> Total execution time: 0.0251
DEBUG - 2022-05-30 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:35:24 --> Total execution time: 0.0251
DEBUG - 2022-05-30 12:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:35:47 --> Total execution time: 0.0312
DEBUG - 2022-05-30 12:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:35:56 --> Total execution time: 0.0720
DEBUG - 2022-05-30 12:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:06:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 12:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:36:21 --> Total execution time: 1.6339
DEBUG - 2022-05-30 12:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:06:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:36:32 --> Total execution time: 0.0832
DEBUG - 2022-05-30 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:36:36 --> Total execution time: 0.0662
DEBUG - 2022-05-30 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:36:44 --> Total execution time: 0.0258
DEBUG - 2022-05-30 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:06:54 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:36:54 --> Total execution time: 0.0201
DEBUG - 2022-05-30 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:07:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:37:43 --> Total execution time: 0.0521
DEBUG - 2022-05-30 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:07:55 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:37:55 --> Total execution time: 0.0398
DEBUG - 2022-05-30 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:00 --> Total execution time: 0.0266
DEBUG - 2022-05-30 12:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 22:38:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 22:38:02 --> Total execution time: 0.1490
DEBUG - 2022-05-30 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:02 --> Total execution time: 0.0234
DEBUG - 2022-05-30 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:20 --> Total execution time: 0.0273
DEBUG - 2022-05-30 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:20 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:20 --> Total execution time: 0.0253
DEBUG - 2022-05-30 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:26 --> Total execution time: 0.0438
DEBUG - 2022-05-30 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:36 --> Total execution time: 0.0460
DEBUG - 2022-05-30 12:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:56 --> Total execution time: 0.0524
DEBUG - 2022-05-30 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:39:03 --> Total execution time: 0.0342
DEBUG - 2022-05-30 12:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:39:17 --> Total execution time: 0.0287
DEBUG - 2022-05-30 12:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:39:25 --> Total execution time: 0.0279
DEBUG - 2022-05-30 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:39:28 --> Total execution time: 0.0830
DEBUG - 2022-05-30 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:09:37 --> Total execution time: 0.0478
DEBUG - 2022-05-30 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:40:11 --> Total execution time: 0.0261
DEBUG - 2022-05-30 12:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:40:17 --> Total execution time: 0.0258
DEBUG - 2022-05-30 12:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:46 --> Total execution time: 0.0239
DEBUG - 2022-05-30 12:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:54 --> Total execution time: 0.0234
DEBUG - 2022-05-30 12:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:10:58 --> Total execution time: 0.0273
DEBUG - 2022-05-30 12:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:11 --> Total execution time: 0.0230
DEBUG - 2022-05-30 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:29 --> Total execution time: 0.0263
DEBUG - 2022-05-30 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:11:58 --> Total execution time: 0.0225
DEBUG - 2022-05-30 22:42:01 --> Total execution time: 4.4275
DEBUG - 2022-05-30 12:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:10 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:12:17 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:13:01 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:14:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:44:59 --> Total execution time: 0.0233
DEBUG - 2022-05-30 12:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:15:35 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:45:35 --> Total execution time: 0.0636
DEBUG - 2022-05-30 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:15:39 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:45:39 --> Total execution time: 0.0311
DEBUG - 2022-05-30 12:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:15:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:45:44 --> Total execution time: 0.0232
DEBUG - 2022-05-30 12:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:45:53 --> Total execution time: 0.0168
DEBUG - 2022-05-30 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:05 --> Total execution time: 0.0272
DEBUG - 2022-05-30 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:07 --> Total execution time: 0.0395
DEBUG - 2022-05-30 12:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:07 --> Total execution time: 0.0449
DEBUG - 2022-05-30 12:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:46:23 --> Total execution time: 0.0311
DEBUG - 2022-05-30 12:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:46:35 --> Total execution time: 0.0357
DEBUG - 2022-05-30 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:16:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:46:43 --> Total execution time: 0.0495
DEBUG - 2022-05-30 12:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:48:16 --> Total execution time: 0.0478
DEBUG - 2022-05-30 12:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:48:27 --> Total execution time: 0.0321
DEBUG - 2022-05-30 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:48:36 --> Total execution time: 0.0328
DEBUG - 2022-05-30 12:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:48:46 --> Total execution time: 0.0323
DEBUG - 2022-05-30 12:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:48:53 --> Total execution time: 0.0307
DEBUG - 2022-05-30 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:18:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:48:57 --> Total execution time: 1.4844
DEBUG - 2022-05-30 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:49:05 --> Total execution time: 0.0402
DEBUG - 2022-05-30 12:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:49:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:49:47 --> Total execution time: 0.0290
DEBUG - 2022-05-30 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:49:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 22:49:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 22:49:48 --> Total execution time: 0.1529
DEBUG - 2022-05-30 12:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:50:01 --> Total execution time: 4.0740
DEBUG - 2022-05-30 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:04 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-30 12:20:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:07 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:08 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:50:25 --> Total execution time: 0.0284
DEBUG - 2022-05-30 12:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:50:29 --> Total execution time: 0.0391
DEBUG - 2022-05-30 12:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:50:43 --> Total execution time: 0.0664
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:20:57 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:50:58 --> Total execution time: 0.0290
DEBUG - 2022-05-30 12:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:51:05 --> Total execution time: 0.0518
DEBUG - 2022-05-30 12:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:51:21 --> Total execution time: 0.0274
DEBUG - 2022-05-30 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:51:30 --> Total execution time: 0.0287
DEBUG - 2022-05-30 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:51:32 --> Total execution time: 0.0428
DEBUG - 2022-05-30 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:51:34 --> Total execution time: 0.0463
DEBUG - 2022-05-30 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:52:48 --> Total execution time: 0.0514
DEBUG - 2022-05-30 12:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:54:31 --> Total execution time: 0.0278
DEBUG - 2022-05-30 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:54:32 --> Total execution time: 0.0290
DEBUG - 2022-05-30 12:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:54:39 --> Total execution time: 0.0278
DEBUG - 2022-05-30 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:54:49 --> Total execution time: 0.0248
DEBUG - 2022-05-30 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:55:24 --> Total execution time: 4.1213
DEBUG - 2022-05-30 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:14 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:26:26 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:28:38 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:58:38 --> Total execution time: 0.0704
DEBUG - 2022-05-30 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:59:52 --> Total execution time: 0.0803
DEBUG - 2022-05-30 12:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:00:15 --> Total execution time: 0.0463
DEBUG - 2022-05-30 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:01:13 --> Total execution time: 0.0704
DEBUG - 2022-05-30 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:01:23 --> Total execution time: 4.3295
DEBUG - 2022-05-30 12:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:31:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:31:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:31:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:32:28 --> UTF-8 Support Enabled
ERROR - 2022-05-30 12:32:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:32:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:03:30 --> Total execution time: 0.0705
DEBUG - 2022-05-30 12:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:03:40 --> Total execution time: 0.0239
DEBUG - 2022-05-30 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:03:56 --> Total execution time: 0.0246
DEBUG - 2022-05-30 12:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:01 --> Total execution time: 0.0304
DEBUG - 2022-05-30 12:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:02 --> Total execution time: 0.0302
DEBUG - 2022-05-30 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:14 --> Total execution time: 0.0697
DEBUG - 2022-05-30 12:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:16 --> Total execution time: 0.0284
DEBUG - 2022-05-30 12:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 12:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:19 --> Total execution time: 0.0347
DEBUG - 2022-05-30 12:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 23:04:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 23:04:20 --> Total execution time: 0.1634
DEBUG - 2022-05-30 12:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:23 --> Total execution time: 0.0312
DEBUG - 2022-05-30 12:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:28 --> Total execution time: 0.0284
DEBUG - 2022-05-30 12:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:50 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:50 --> Total execution time: 0.0273
DEBUG - 2022-05-30 12:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:04:52 --> Total execution time: 0.0330
DEBUG - 2022-05-30 12:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:02 --> Total execution time: 0.0305
DEBUG - 2022-05-30 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:07 --> Total execution time: 0.0184
DEBUG - 2022-05-30 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:07 --> Total execution time: 0.0222
DEBUG - 2022-05-30 12:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:13 --> Total execution time: 0.0404
DEBUG - 2022-05-30 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:19 --> Total execution time: 0.0272
DEBUG - 2022-05-30 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:19 --> Total execution time: 0.0188
DEBUG - 2022-05-30 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:46 --> Total execution time: 0.0784
DEBUG - 2022-05-30 23:05:48 --> Total execution time: 4.1587
DEBUG - 2022-05-30 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:53 --> Total execution time: 0.0274
DEBUG - 2022-05-30 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:05:57 --> Total execution time: 0.0418
DEBUG - 2022-05-30 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:06:10 --> Total execution time: 0.0488
DEBUG - 2022-05-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:31 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:31 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:36:31 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 12:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:06:49 --> Total execution time: 0.0429
DEBUG - 2022-05-30 12:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:06:56 --> Total execution time: 0.0725
DEBUG - 2022-05-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:07:24 --> Total execution time: 0.0270
DEBUG - 2022-05-30 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:07:30 --> Total execution time: 0.0246
DEBUG - 2022-05-30 12:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:07:34 --> Total execution time: 0.0235
DEBUG - 2022-05-30 12:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:07:41 --> Total execution time: 0.0275
DEBUG - 2022-05-30 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:07:41 --> Total execution time: 0.0230
DEBUG - 2022-05-30 12:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:04 --> Total execution time: 0.0477
DEBUG - 2022-05-30 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:06 --> Total execution time: 0.0237
DEBUG - 2022-05-30 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:08 --> Total execution time: 0.0483
DEBUG - 2022-05-30 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:10 --> Total execution time: 0.0169
DEBUG - 2022-05-30 12:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:33 --> Total execution time: 0.0734
DEBUG - 2022-05-30 12:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:34 --> Total execution time: 0.0489
DEBUG - 2022-05-30 12:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:34 --> Total execution time: 0.0696
DEBUG - 2022-05-30 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:35 --> Total execution time: 0.0437
DEBUG - 2022-05-30 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 12:38:35 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-05-30 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:35 --> Total execution time: 0.0335
DEBUG - 2022-05-30 12:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:48 --> Total execution time: 0.0365
DEBUG - 2022-05-30 12:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:49 --> Total execution time: 0.0268
DEBUG - 2022-05-30 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:09:00 --> Total execution time: 0.0613
DEBUG - 2022-05-30 12:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:11:55 --> Total execution time: 0.1015
DEBUG - 2022-05-30 12:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:12:09 --> Total execution time: 0.0358
DEBUG - 2022-05-30 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:43:26 --> Total execution time: 0.0343
DEBUG - 2022-05-30 12:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:43:43 --> Total execution time: 0.0252
DEBUG - 2022-05-30 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:43:55 --> Total execution time: 0.0764
DEBUG - 2022-05-30 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:02 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:02 --> Total execution time: 0.0255
DEBUG - 2022-05-30 12:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:03 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:03 --> Total execution time: 0.0350
DEBUG - 2022-05-30 12:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:07 --> Total execution time: 0.0211
DEBUG - 2022-05-30 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:20 --> Total execution time: 0.0297
DEBUG - 2022-05-30 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:27 --> Total execution time: 0.0495
DEBUG - 2022-05-30 12:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:35 --> Total execution time: 0.1576
DEBUG - 2022-05-30 12:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:14:48 --> Total execution time: 0.0265
DEBUG - 2022-05-30 12:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:45:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:15:58 --> Total execution time: 0.0399
DEBUG - 2022-05-30 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:16:07 --> Total execution time: 0.0653
DEBUG - 2022-05-30 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:16:25 --> Total execution time: 0.0414
DEBUG - 2022-05-30 12:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:46:33 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:16:33 --> Total execution time: 0.0222
DEBUG - 2022-05-30 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:16 --> Total execution time: 0.0568
DEBUG - 2022-05-30 12:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:19:26 --> Total execution time: 0.0795
DEBUG - 2022-05-30 12:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:19:42 --> Total execution time: 0.0287
DEBUG - 2022-05-30 12:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 12:51:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 12:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 12:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:21:58 --> Total execution time: 0.0804
DEBUG - 2022-05-30 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:30:03 --> Total execution time: 0.1629
DEBUG - 2022-05-30 13:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:05:08 --> No URI present. Default controller set.
DEBUG - 2022-05-30 13:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:35:09 --> Total execution time: 0.1008
DEBUG - 2022-05-30 13:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:42:37 --> Total execution time: 0.0779
DEBUG - 2022-05-30 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:14:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 13:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:44:41 --> Total execution time: 0.0294
DEBUG - 2022-05-30 13:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:14:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 13:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:44:42 --> Total execution time: 0.0223
DEBUG - 2022-05-30 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:15:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 13:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:45:04 --> Total execution time: 0.0292
DEBUG - 2022-05-30 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:48:08 --> Total execution time: 0.1112
DEBUG - 2022-05-30 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:53 --> Total execution time: 0.0471
DEBUG - 2022-05-30 13:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:52:12 --> Total execution time: 0.0313
DEBUG - 2022-05-30 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:53:06 --> Total execution time: 0.0275
DEBUG - 2022-05-30 13:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:54:09 --> Total execution time: 0.0307
DEBUG - 2022-05-30 13:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:55:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:55:36 --> Total execution time: 0.0297
DEBUG - 2022-05-30 13:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:56:22 --> Total execution time: 0.0512
DEBUG - 2022-05-30 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:56:33 --> Total execution time: 0.0660
DEBUG - 2022-05-30 13:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:56:38 --> Total execution time: 0.0324
DEBUG - 2022-05-30 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:56:56 --> Total execution time: 0.0535
DEBUG - 2022-05-30 13:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:57:01 --> Total execution time: 0.0302
DEBUG - 2022-05-30 13:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:57:04 --> Total execution time: 0.0457
DEBUG - 2022-05-30 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:33:17 --> No URI present. Default controller set.
DEBUG - 2022-05-30 13:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:35:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 13:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 13:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 13:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 13:52:50 --> 404 Page Not Found: Wp-sitemap-posts-page-1xml/index
DEBUG - 2022-05-30 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:04:20 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:04:37 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:19 --> Total execution time: 0.0185
DEBUG - 2022-05-30 14:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:09 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:16 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 14:10:20 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-30 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:19:30 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 14:21:08 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-30 14:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:28:51 --> Total execution time: 0.0285
DEBUG - 2022-05-30 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:28:58 --> Total execution time: 0.0422
DEBUG - 2022-05-30 14:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 14:30:13 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-30 14:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:31:02 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 14:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 14:33:07 --> No URI present. Default controller set.
DEBUG - 2022-05-30 14:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 14:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:06:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:06:40 --> 404 Page Not Found: Membership-account/index
DEBUG - 2022-05-30 15:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:06:47 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:08:45 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:10:27 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:26:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:26:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:12 --> Total execution time: 0.0242
DEBUG - 2022-05-30 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:27:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:46 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:47 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:47 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:41:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:42:23 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:10 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:10 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:21 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:44:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:46:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:46:26 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:47:12 --> UTF-8 Support Enabled
ERROR - 2022-05-30 15:47:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:13 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:13 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:14 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:14 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:47:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 15:47:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-30 15:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:59:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 15:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:59:46 --> Total execution time: 0.0299
DEBUG - 2022-05-30 15:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 15:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 15:59:52 --> Total execution time: 0.0555
DEBUG - 2022-05-30 15:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 15:59:52 --> Total execution time: 0.0801
DEBUG - 2022-05-30 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:06 --> Total execution time: 0.0626
DEBUG - 2022-05-30 16:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:08 --> Total execution time: 0.0790
DEBUG - 2022-05-30 16:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:08 --> Total execution time: 0.1122
DEBUG - 2022-05-30 16:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:43 --> Total execution time: 0.0300
DEBUG - 2022-05-30 16:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:44 --> Total execution time: 0.0295
DEBUG - 2022-05-30 16:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:47 --> Total execution time: 0.0372
DEBUG - 2022-05-30 16:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:48 --> Total execution time: 0.0344
DEBUG - 2022-05-30 16:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:48 --> Total execution time: 0.0344
DEBUG - 2022-05-30 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:58 --> Total execution time: 0.0254
DEBUG - 2022-05-30 16:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:59 --> Total execution time: 0.0274
DEBUG - 2022-05-30 16:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:00:59 --> Total execution time: 0.0388
DEBUG - 2022-05-30 16:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:00 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:04 --> Total execution time: 0.0308
DEBUG - 2022-05-30 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:06 --> Total execution time: 0.0244
DEBUG - 2022-05-30 16:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:06 --> Total execution time: 0.0496
DEBUG - 2022-05-30 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:34 --> Total execution time: 0.0267
DEBUG - 2022-05-30 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:35 --> Total execution time: 0.0294
DEBUG - 2022-05-30 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:35 --> Total execution time: 0.0256
DEBUG - 2022-05-30 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-30 16:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 16:02:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 16:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:37 --> Total execution time: 0.0903
DEBUG - 2022-05-30 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:02:53 --> Total execution time: 0.0183
DEBUG - 2022-05-30 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:03:08 --> Total execution time: 0.0237
DEBUG - 2022-05-30 16:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:03:10 --> Total execution time: 0.0226
DEBUG - 2022-05-30 16:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 16:10:57 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-30 16:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:14:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:18:27 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:25:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:26:19 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:27:02 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 16:29:32 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-05-30 16:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:30:32 --> No URI present. Default controller set.
DEBUG - 2022-05-30 16:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 16:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 16:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 16:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 17:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 17:15:14 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-30 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 17:15:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 17:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 17:15:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 17:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 17:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 17:15:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 17:15:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 17:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 17:19:44 --> No URI present. Default controller set.
DEBUG - 2022-05-30 17:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 17:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 18:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 18:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 18:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 18:55:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 18:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 18:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 19:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 19:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 19:11:22 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-05-30 19:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 19:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 19:12:55 --> 404 Page Not Found: Courses/index
DEBUG - 2022-05-30 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:12:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 20:12:22 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-30 20:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:12:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 20:12:51 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-05-30 20:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:19:23 --> No URI present. Default controller set.
DEBUG - 2022-05-30 20:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:33:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 20:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:35:10 --> Total execution time: 0.0309
DEBUG - 2022-05-30 20:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:35:24 --> Total execution time: 0.0309
DEBUG - 2022-05-30 20:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:35:44 --> Total execution time: 0.0866
DEBUG - 2022-05-30 20:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:10 --> No URI present. Default controller set.
DEBUG - 2022-05-30 20:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:06 --> Total execution time: 0.0243
DEBUG - 2022-05-30 20:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:23 --> Total execution time: 0.0283
DEBUG - 2022-05-30 20:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:50:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 20:50:46 --> 404 Page Not Found: Lessons/pre-written-ads-10
DEBUG - 2022-05-30 20:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:50:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 20:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:51:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 20:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 20:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 20:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 20:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 20:51:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:04:17 --> Total execution time: 0.0783
DEBUG - 2022-05-30 21:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:04:19 --> Total execution time: 0.0338
DEBUG - 2022-05-30 21:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:04:19 --> Total execution time: 0.0429
DEBUG - 2022-05-30 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:08:51 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:09:12 --> Total execution time: 0.0224
DEBUG - 2022-05-30 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:09:13 --> Total execution time: 0.0359
DEBUG - 2022-05-30 21:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:09:13 --> Total execution time: 0.0363
DEBUG - 2022-05-30 21:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:09:16 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:10:47 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:14:21 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-05-30 21:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:31 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:01 --> Total execution time: 0.0356
DEBUG - 2022-05-30 21:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:16 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:19:47 --> Total execution time: 0.0226
DEBUG - 2022-05-30 21:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:20:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-30 21:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:21:34 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:21:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:24 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:50 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:24:07 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:24:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:29:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:29:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:30:37 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-30 21:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:34:48 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:32 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:32 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:32 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:32 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 21:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:33 --> 404 Page Not Found: D2php/index
DEBUG - 2022-05-30 21:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:34 --> 404 Page Not Found: Infodatphp/index
DEBUG - 2022-05-30 21:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:35 --> 404 Page Not Found: Webdataphp/index
DEBUG - 2022-05-30 21:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:36 --> 404 Page Not Found: Localphp/index
DEBUG - 2022-05-30 21:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:38 --> 404 Page Not Found: Wp-content/local.php
DEBUG - 2022-05-30 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:39 --> 404 Page Not Found: Webphp/index
DEBUG - 2022-05-30 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:40 --> 404 Page Not Found: Getphp/index
DEBUG - 2022-05-30 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:41 --> 404 Page Not Found: Cpphp/index
DEBUG - 2022-05-30 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:41 --> 404 Page Not Found: Wp-roundphp/index
DEBUG - 2022-05-30 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:42 --> 404 Page Not Found: Class-wp-type-registroyphp/index
DEBUG - 2022-05-30 21:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:38:43 --> 404 Page Not Found: Radiophp/index
DEBUG - 2022-05-30 21:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:39:04 --> 404 Page Not Found: User/bank-details
DEBUG - 2022-05-30 21:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:39:04 --> 404 Page Not Found: User/bank-details
DEBUG - 2022-05-30 21:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:39:04 --> 404 Page Not Found: User/bank-details
DEBUG - 2022-05-30 21:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:39:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:39:28 --> 404 Page Not Found: Payment/index.php
DEBUG - 2022-05-30 21:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:40:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:40:19 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 21:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:40:20 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 21:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:40:20 --> 404 Page Not Found: User/affiliate-account
DEBUG - 2022-05-30 21:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 21:40:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-30 21:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:51:14 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:54:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:54:49 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:55:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:57:12 --> No URI present. Default controller set.
DEBUG - 2022-05-30 21:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 21:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 21:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 21:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:59 --> Total execution time: 0.0225
DEBUG - 2022-05-30 22:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:03:59 --> Total execution time: 0.0218
DEBUG - 2022-05-30 22:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:04:06 --> Total execution time: 0.0296
DEBUG - 2022-05-30 22:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 22:09:12 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-05-30 22:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:10:29 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:15:06 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:15:07 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:16:58 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:18:13 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 22:24:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-30 22:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:46:52 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:51:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 22:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 22:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 22:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 22:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:01:40 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:10:32 --> 404 Page Not Found: Courses/index
DEBUG - 2022-05-30 23:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:13:02 --> 404 Page Not Found: Wp-sitemapxml/index
DEBUG - 2022-05-30 23:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:13:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:18:11 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:19:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:19:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-30 23:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:21:03 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:21:04 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:25:59 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:28:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:28:43 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:40 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-05-30 23:33:40 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 23:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:41 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 23:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:41 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 23:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:41 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-05-30 23:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:42 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-05-30 23:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:42 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 23:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:42 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-30 23:33:43 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-30 23:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:43:48 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:43:53 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:51:36 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:54:42 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:57:41 --> No URI present. Default controller set.
DEBUG - 2022-05-30 23:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-30 23:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-30 23:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-30 23:59:52 --> Encryption: Auto-configured driver 'openssl'.
