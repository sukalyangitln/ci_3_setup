<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-17 00:09:40 --> Total execution time: 0.2321
DEBUG - 2022-06-17 00:10:01 --> Total execution time: 0.0516
DEBUG - 2022-06-17 00:10:01 --> Total execution time: 0.1175
DEBUG - 2022-06-17 00:10:01 --> Total execution time: 0.1466
DEBUG - 2022-06-17 00:10:07 --> Total execution time: 0.0796
DEBUG - 2022-06-17 00:11:34 --> Total execution time: 0.1072
DEBUG - 2022-06-17 00:12:10 --> Total execution time: 0.0332
DEBUG - 2022-06-17 00:12:44 --> Total execution time: 0.0418
DEBUG - 2022-06-17 00:12:45 --> Total execution time: 0.0437
DEBUG - 2022-06-17 00:12:47 --> Total execution time: 0.0379
DEBUG - 2022-06-17 00:13:09 --> Total execution time: 0.0459
DEBUG - 2022-06-17 00:13:21 --> Total execution time: 0.0775
DEBUG - 2022-06-17 00:13:34 --> Total execution time: 0.0621
DEBUG - 2022-06-17 00:13:38 --> Total execution time: 0.0553
DEBUG - 2022-06-17 00:15:29 --> Total execution time: 0.0308
DEBUG - 2022-06-17 00:15:29 --> Total execution time: 0.0305
DEBUG - 2022-06-17 00:15:29 --> Total execution time: 0.0287
DEBUG - 2022-06-17 00:15:29 --> Total execution time: 0.0289
DEBUG - 2022-06-17 00:15:29 --> Total execution time: 0.0293
DEBUG - 2022-06-17 00:15:33 --> Total execution time: 0.0267
DEBUG - 2022-06-17 00:15:34 --> Total execution time: 0.0273
DEBUG - 2022-06-17 00:15:36 --> Total execution time: 0.0273
DEBUG - 2022-06-17 00:15:37 --> Total execution time: 0.0281
DEBUG - 2022-06-17 00:16:28 --> Total execution time: 0.0688
DEBUG - 2022-06-17 00:17:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 00:17:16 --> Total execution time: 0.0592
DEBUG - 2022-06-17 00:17:19 --> Total execution time: 0.0651
DEBUG - 2022-06-17 00:17:26 --> Total execution time: 0.0431
DEBUG - 2022-06-17 00:17:29 --> Total execution time: 0.0605
DEBUG - 2022-06-17 00:17:35 --> Total execution time: 0.0467
DEBUG - 2022-06-17 00:17:39 --> Total execution time: 0.0486
DEBUG - 2022-06-17 00:18:41 --> Total execution time: 0.0490
DEBUG - 2022-06-17 00:18:53 --> Total execution time: 0.0532
DEBUG - 2022-06-17 00:18:57 --> Total execution time: 0.0492
DEBUG - 2022-06-17 00:19:22 --> Total execution time: 0.0381
DEBUG - 2022-06-17 00:19:40 --> Total execution time: 0.0548
DEBUG - 2022-06-17 00:20:42 --> Total execution time: 0.0413
DEBUG - 2022-06-17 00:20:46 --> Total execution time: 0.0431
DEBUG - 2022-06-17 00:25:28 --> Total execution time: 0.0411
DEBUG - 2022-06-17 00:30:02 --> Total execution time: 0.2230
DEBUG - 2022-06-17 00:31:43 --> Total execution time: 0.0369
DEBUG - 2022-06-17 00:31:45 --> Total execution time: 0.0379
DEBUG - 2022-06-17 00:31:46 --> Total execution time: 0.0428
DEBUG - 2022-06-17 00:34:31 --> Total execution time: 0.0444
DEBUG - 2022-06-17 00:47:27 --> Total execution time: 0.0434
DEBUG - 2022-06-17 00:47:34 --> Total execution time: 0.0575
DEBUG - 2022-06-17 00:47:39 --> Total execution time: 0.0848
DEBUG - 2022-06-17 00:49:08 --> Total execution time: 0.0319
DEBUG - 2022-06-17 00:57:37 --> Total execution time: 0.1855
DEBUG - 2022-06-17 00:59:02 --> Total execution time: 0.0354
DEBUG - 2022-06-17 01:09:18 --> Total execution time: 0.1117
DEBUG - 2022-06-17 01:23:35 --> Total execution time: 0.1163
DEBUG - 2022-06-17 01:29:54 --> Total execution time: 0.0439
DEBUG - 2022-06-17 01:30:02 --> Total execution time: 0.1099
DEBUG - 2022-06-17 01:41:38 --> Total execution time: 0.0814
DEBUG - 2022-06-17 01:47:36 --> Total execution time: 0.1923
DEBUG - 2022-06-17 01:53:06 --> Total execution time: 0.1730
DEBUG - 2022-06-17 01:54:22 --> Total execution time: 0.0439
DEBUG - 2022-06-17 02:30:03 --> Total execution time: 0.2288
DEBUG - 2022-06-17 02:55:36 --> Total execution time: 0.1470
DEBUG - 2022-06-17 03:20:15 --> Total execution time: 0.1736
DEBUG - 2022-06-17 03:20:34 --> Total execution time: 0.0330
DEBUG - 2022-06-17 03:20:40 --> Total execution time: 0.0293
DEBUG - 2022-06-17 03:20:59 --> Total execution time: 0.0309
DEBUG - 2022-06-17 03:21:00 --> Total execution time: 0.0435
DEBUG - 2022-06-17 03:21:02 --> Total execution time: 0.0371
DEBUG - 2022-06-17 03:21:04 --> Total execution time: 0.0370
DEBUG - 2022-06-17 03:30:03 --> Total execution time: 0.2033
DEBUG - 2022-06-17 03:32:39 --> Total execution time: 0.0441
DEBUG - 2022-06-17 03:45:15 --> Total execution time: 0.0742
DEBUG - 2022-06-17 03:45:17 --> Total execution time: 0.0235
DEBUG - 2022-06-17 03:57:01 --> Total execution time: 0.1570
DEBUG - 2022-06-17 04:27:57 --> Total execution time: 0.2268
DEBUG - 2022-06-17 04:29:29 --> Total execution time: 0.0321
DEBUG - 2022-06-17 04:29:30 --> Total execution time: 0.0416
DEBUG - 2022-06-17 04:29:44 --> Total execution time: 0.0308
DEBUG - 2022-06-17 04:29:55 --> Total execution time: 0.0652
DEBUG - 2022-06-17 04:30:02 --> Total execution time: 0.0677
DEBUG - 2022-06-17 04:30:12 --> Total execution time: 0.0853
DEBUG - 2022-06-17 04:30:37 --> Total execution time: 0.0459
DEBUG - 2022-06-17 04:30:45 --> Total execution time: 0.0919
DEBUG - 2022-06-17 04:30:53 --> Total execution time: 0.0439
DEBUG - 2022-06-17 04:30:57 --> Total execution time: 0.0503
DEBUG - 2022-06-17 04:31:52 --> Total execution time: 0.0462
DEBUG - 2022-06-17 04:32:39 --> Total execution time: 0.0579
DEBUG - 2022-06-17 04:38:26 --> Total execution time: 0.0972
DEBUG - 2022-06-17 04:41:13 --> Total execution time: 0.1148
DEBUG - 2022-06-17 04:42:05 --> Total execution time: 0.0470
DEBUG - 2022-06-17 04:42:15 --> Total execution time: 0.1095
DEBUG - 2022-06-17 05:30:03 --> Total execution time: 0.1205
DEBUG - 2022-06-17 06:09:42 --> Total execution time: 0.1822
DEBUG - 2022-06-17 06:09:44 --> Total execution time: 0.0343
DEBUG - 2022-06-17 06:10:08 --> Total execution time: 0.0294
DEBUG - 2022-06-17 06:10:09 --> Total execution time: 0.0307
DEBUG - 2022-06-17 06:20:13 --> Total execution time: 0.1314
DEBUG - 2022-06-17 06:20:23 --> Total execution time: 0.0638
DEBUG - 2022-06-17 06:20:26 --> Total execution time: 0.1060
DEBUG - 2022-06-17 06:20:34 --> Total execution time: 0.0819
DEBUG - 2022-06-17 06:21:32 --> Total execution time: 0.0333
DEBUG - 2022-06-17 06:21:34 --> Total execution time: 0.0499
DEBUG - 2022-06-17 06:21:35 --> Total execution time: 0.0459
DEBUG - 2022-06-17 06:26:11 --> Total execution time: 0.0381
DEBUG - 2022-06-17 06:30:02 --> Total execution time: 0.1429
DEBUG - 2022-06-17 06:35:08 --> Total execution time: 0.1690
DEBUG - 2022-06-17 06:35:14 --> Total execution time: 0.0619
DEBUG - 2022-06-17 06:39:02 --> Total execution time: 0.1635
DEBUG - 2022-06-17 06:39:15 --> Total execution time: 0.0595
DEBUG - 2022-06-17 06:39:25 --> Total execution time: 0.0501
DEBUG - 2022-06-17 06:39:29 --> Total execution time: 0.0457
DEBUG - 2022-06-17 06:39:36 --> Total execution time: 0.0842
DEBUG - 2022-06-17 06:39:45 --> Total execution time: 0.0501
DEBUG - 2022-06-17 06:39:55 --> Total execution time: 0.0520
DEBUG - 2022-06-17 06:40:06 --> Total execution time: 0.0938
DEBUG - 2022-06-17 06:40:19 --> Total execution time: 0.0914
DEBUG - 2022-06-17 06:42:05 --> Total execution time: 0.0417
DEBUG - 2022-06-17 06:42:14 --> Total execution time: 0.0474
DEBUG - 2022-06-17 06:42:26 --> Total execution time: 0.0379
DEBUG - 2022-06-17 06:42:27 --> Total execution time: 0.0367
DEBUG - 2022-06-17 06:42:50 --> Total execution time: 0.0628
DEBUG - 2022-06-17 06:43:02 --> Total execution time: 0.0480
DEBUG - 2022-06-17 06:48:49 --> Total execution time: 0.0423
DEBUG - 2022-06-17 06:48:54 --> Total execution time: 0.0450
DEBUG - 2022-06-17 06:49:28 --> Total execution time: 0.0406
DEBUG - 2022-06-17 06:49:31 --> Total execution time: 0.0763
DEBUG - 2022-06-17 06:50:27 --> Total execution time: 0.0482
DEBUG - 2022-06-17 06:50:37 --> Total execution time: 0.0413
DEBUG - 2022-06-17 06:50:48 --> Total execution time: 0.0430
DEBUG - 2022-06-17 06:50:52 --> Total execution time: 0.0534
DEBUG - 2022-06-17 06:52:10 --> Total execution time: 0.0444
DEBUG - 2022-06-17 06:52:22 --> Total execution time: 0.0612
DEBUG - 2022-06-17 06:52:26 --> Total execution time: 0.0612
DEBUG - 2022-06-17 06:52:31 --> Total execution time: 0.0472
DEBUG - 2022-06-17 06:52:49 --> Total execution time: 0.0426
DEBUG - 2022-06-17 06:52:55 --> Total execution time: 0.0453
DEBUG - 2022-06-17 06:52:59 --> Total execution time: 0.0471
DEBUG - 2022-06-17 06:53:00 --> Total execution time: 0.0499
DEBUG - 2022-06-17 06:53:03 --> Total execution time: 0.0424
DEBUG - 2022-06-17 06:53:06 --> Total execution time: 0.0435
DEBUG - 2022-06-17 06:53:23 --> Total execution time: 0.0431
DEBUG - 2022-06-17 06:53:27 --> Total execution time: 0.0434
DEBUG - 2022-06-17 06:53:33 --> Total execution time: 0.0432
DEBUG - 2022-06-17 06:53:47 --> Total execution time: 0.0412
DEBUG - 2022-06-17 06:53:52 --> Total execution time: 0.1010
DEBUG - 2022-06-17 06:53:53 --> Total execution time: 0.0444
DEBUG - 2022-06-17 06:53:57 --> Total execution time: 0.0469
DEBUG - 2022-06-17 06:54:00 --> Total execution time: 0.0524
DEBUG - 2022-06-17 06:54:06 --> Total execution time: 0.0651
DEBUG - 2022-06-17 06:54:08 --> Total execution time: 0.0381
DEBUG - 2022-06-17 06:54:11 --> Total execution time: 0.0500
DEBUG - 2022-06-17 06:54:26 --> Total execution time: 0.0440
DEBUG - 2022-06-17 06:55:20 --> Total execution time: 0.0498
DEBUG - 2022-06-17 06:55:26 --> Total execution time: 0.0400
DEBUG - 2022-06-17 06:55:33 --> Total execution time: 0.0413
DEBUG - 2022-06-17 06:55:35 --> Total execution time: 0.0432
DEBUG - 2022-06-17 06:55:38 --> Total execution time: 0.0486
DEBUG - 2022-06-17 06:55:49 --> Total execution time: 0.0384
DEBUG - 2022-06-17 06:56:44 --> Total execution time: 0.0400
DEBUG - 2022-06-17 06:57:18 --> Total execution time: 0.0385
DEBUG - 2022-06-17 07:01:50 --> Total execution time: 0.0423
DEBUG - 2022-06-17 07:04:50 --> Total execution time: 0.0499
DEBUG - 2022-06-17 07:04:56 --> Total execution time: 0.0559
DEBUG - 2022-06-17 07:04:58 --> Total execution time: 0.0522
DEBUG - 2022-06-17 07:05:03 --> Total execution time: 0.0408
DEBUG - 2022-06-17 07:05:09 --> Total execution time: 0.0601
DEBUG - 2022-06-17 07:05:09 --> Total execution time: 0.0346
DEBUG - 2022-06-17 07:05:59 --> Total execution time: 0.0474
DEBUG - 2022-06-17 07:08:02 --> Total execution time: 0.0329
DEBUG - 2022-06-17 07:08:06 --> Total execution time: 0.0269
DEBUG - 2022-06-17 07:08:18 --> Total execution time: 0.0413
DEBUG - 2022-06-17 07:08:30 --> Total execution time: 0.1183
DEBUG - 2022-06-17 07:08:37 --> Total execution time: 0.0419
DEBUG - 2022-06-17 07:08:40 --> Total execution time: 0.0777
DEBUG - 2022-06-17 07:08:47 --> Total execution time: 0.0688
DEBUG - 2022-06-17 07:10:12 --> Total execution time: 0.1052
DEBUG - 2022-06-17 07:10:13 --> Total execution time: 0.0454
DEBUG - 2022-06-17 07:10:14 --> Total execution time: 0.0449
DEBUG - 2022-06-17 07:10:15 --> Total execution time: 0.0463
DEBUG - 2022-06-17 07:11:25 --> Total execution time: 0.0503
DEBUG - 2022-06-17 07:11:29 --> Total execution time: 0.0466
DEBUG - 2022-06-17 07:11:33 --> Total execution time: 0.0674
DEBUG - 2022-06-17 07:11:38 --> Total execution time: 0.0417
DEBUG - 2022-06-17 07:11:46 --> Total execution time: 0.0467
DEBUG - 2022-06-17 07:11:47 --> Total execution time: 0.0433
DEBUG - 2022-06-17 07:11:47 --> Total execution time: 0.0726
DEBUG - 2022-06-17 07:11:48 --> Total execution time: 0.0431
DEBUG - 2022-06-17 07:11:48 --> Total execution time: 0.0525
DEBUG - 2022-06-17 07:11:48 --> Total execution time: 0.0471
DEBUG - 2022-06-17 07:11:49 --> Total execution time: 0.0500
DEBUG - 2022-06-17 07:11:49 --> Total execution time: 0.0499
DEBUG - 2022-06-17 07:11:49 --> Total execution time: 0.0422
DEBUG - 2022-06-17 07:11:55 --> Total execution time: 0.0489
DEBUG - 2022-06-17 07:12:01 --> Total execution time: 0.0419
DEBUG - 2022-06-17 07:12:15 --> Total execution time: 0.0507
DEBUG - 2022-06-17 07:12:19 --> Total execution time: 0.0416
DEBUG - 2022-06-17 07:13:18 --> Total execution time: 0.0466
DEBUG - 2022-06-17 07:13:24 --> Total execution time: 0.0465
DEBUG - 2022-06-17 07:13:45 --> Total execution time: 0.0583
DEBUG - 2022-06-17 07:13:56 --> Total execution time: 0.0750
DEBUG - 2022-06-17 07:14:15 --> Total execution time: 0.0452
DEBUG - 2022-06-17 07:14:21 --> Total execution time: 0.0831
DEBUG - 2022-06-17 07:14:39 --> Total execution time: 0.0460
DEBUG - 2022-06-17 07:14:45 --> Total execution time: 0.0556
DEBUG - 2022-06-17 07:14:49 --> Total execution time: 0.0465
DEBUG - 2022-06-17 07:15:03 --> Total execution time: 0.0477
DEBUG - 2022-06-17 07:17:11 --> Total execution time: 0.0911
DEBUG - 2022-06-17 07:22:42 --> Total execution time: 0.0887
DEBUG - 2022-06-17 07:28:57 --> Total execution time: 0.1054
DEBUG - 2022-06-17 07:30:04 --> Total execution time: 0.0556
DEBUG - 2022-06-17 07:31:44 --> Total execution time: 0.0424
DEBUG - 2022-06-17 07:32:45 --> Total execution time: 0.0304
DEBUG - 2022-06-17 07:32:50 --> Total execution time: 0.0502
DEBUG - 2022-06-17 07:33:32 --> Total execution time: 0.0601
DEBUG - 2022-06-17 07:33:46 --> Total execution time: 0.0962
DEBUG - 2022-06-17 07:34:10 --> Total execution time: 0.0654
DEBUG - 2022-06-17 07:34:23 --> Total execution time: 0.0525
DEBUG - 2022-06-17 07:34:31 --> Total execution time: 0.0859
DEBUG - 2022-06-17 07:34:31 --> Total execution time: 0.0685
DEBUG - 2022-06-17 07:34:32 --> Total execution time: 0.0606
DEBUG - 2022-06-17 07:34:41 --> Total execution time: 0.0476
DEBUG - 2022-06-17 07:34:44 --> Total execution time: 0.0640
DEBUG - 2022-06-17 07:34:45 --> Total execution time: 0.0724
DEBUG - 2022-06-17 07:34:46 --> Total execution time: 0.0703
DEBUG - 2022-06-17 07:34:46 --> Total execution time: 0.0678
DEBUG - 2022-06-17 07:35:38 --> Total execution time: 0.0372
DEBUG - 2022-06-17 07:37:06 --> Total execution time: 0.0380
DEBUG - 2022-06-17 07:45:45 --> Total execution time: 0.1789
DEBUG - 2022-06-17 07:47:00 --> Total execution time: 0.0450
DEBUG - 2022-06-17 07:47:12 --> Total execution time: 0.0468
DEBUG - 2022-06-17 07:48:24 --> Total execution time: 0.0432
DEBUG - 2022-06-17 07:49:04 --> Total execution time: 3.0097
DEBUG - 2022-06-17 07:52:11 --> Total execution time: 0.0443
DEBUG - 2022-06-17 07:52:18 --> Total execution time: 0.0316
DEBUG - 2022-06-17 07:52:25 --> Total execution time: 0.0396
DEBUG - 2022-06-17 07:52:56 --> Total execution time: 0.0475
DEBUG - 2022-06-17 07:53:27 --> Total execution time: 0.0806
DEBUG - 2022-06-17 07:53:53 --> Total execution time: 0.0671
DEBUG - 2022-06-17 07:54:36 --> Total execution time: 0.0379
DEBUG - 2022-06-17 07:54:43 --> Total execution time: 0.0437
DEBUG - 2022-06-17 07:54:47 --> Total execution time: 0.0503
DEBUG - 2022-06-17 07:54:51 --> Total execution time: 0.0445
DEBUG - 2022-06-17 07:54:59 --> Total execution time: 0.0487
DEBUG - 2022-06-17 08:00:27 --> Total execution time: 0.2376
DEBUG - 2022-06-17 08:00:36 --> Total execution time: 0.0616
DEBUG - 2022-06-17 08:01:18 --> Total execution time: 0.0557
DEBUG - 2022-06-17 08:01:28 --> Total execution time: 0.0666
DEBUG - 2022-06-17 08:02:47 --> Total execution time: 0.0431
DEBUG - 2022-06-17 08:03:02 --> Total execution time: 0.0596
DEBUG - 2022-06-17 08:03:05 --> Total execution time: 0.0387
DEBUG - 2022-06-17 08:03:15 --> Total execution time: 0.0302
DEBUG - 2022-06-17 08:03:20 --> Total execution time: 0.0412
DEBUG - 2022-06-17 08:03:27 --> Total execution time: 0.0648
DEBUG - 2022-06-17 08:03:31 --> Total execution time: 0.0409
DEBUG - 2022-06-17 08:03:39 --> Total execution time: 0.0486
DEBUG - 2022-06-17 08:03:40 --> Total execution time: 0.0438
DEBUG - 2022-06-17 08:03:40 --> Total execution time: 0.0585
DEBUG - 2022-06-17 08:03:40 --> Total execution time: 0.0643
DEBUG - 2022-06-17 08:03:43 --> Total execution time: 0.0666
DEBUG - 2022-06-17 08:03:53 --> Total execution time: 0.0447
DEBUG - 2022-06-17 08:03:54 --> Total execution time: 0.0434
DEBUG - 2022-06-17 08:03:57 --> Total execution time: 0.0442
DEBUG - 2022-06-17 08:04:04 --> Total execution time: 0.0542
DEBUG - 2022-06-17 08:04:13 --> Total execution time: 0.0427
DEBUG - 2022-06-17 08:04:18 --> Total execution time: 0.0468
DEBUG - 2022-06-17 08:04:22 --> Total execution time: 0.0617
DEBUG - 2022-06-17 08:04:24 --> Total execution time: 0.0453
DEBUG - 2022-06-17 08:04:27 --> Total execution time: 0.0707
DEBUG - 2022-06-17 08:04:34 --> Total execution time: 0.0418
DEBUG - 2022-06-17 08:04:37 --> Total execution time: 0.0450
DEBUG - 2022-06-17 08:04:37 --> Total execution time: 0.0465
DEBUG - 2022-06-17 08:04:47 --> Total execution time: 0.0432
DEBUG - 2022-06-17 08:04:59 --> Total execution time: 0.0432
DEBUG - 2022-06-17 08:04:59 --> Total execution time: 0.0502
DEBUG - 2022-06-17 08:05:02 --> Total execution time: 0.0803
DEBUG - 2022-06-17 08:05:08 --> Total execution time: 0.0509
DEBUG - 2022-06-17 08:05:11 --> Total execution time: 0.0470
DEBUG - 2022-06-17 08:05:18 --> Total execution time: 0.0475
DEBUG - 2022-06-17 08:05:32 --> Total execution time: 0.0478
DEBUG - 2022-06-17 08:05:33 --> Total execution time: 0.0552
DEBUG - 2022-06-17 08:07:15 --> Total execution time: 0.0446
DEBUG - 2022-06-17 08:12:14 --> Total execution time: 0.1268
DEBUG - 2022-06-17 08:13:17 --> Total execution time: 0.0399
DEBUG - 2022-06-17 08:15:32 --> Total execution time: 0.0411
DEBUG - 2022-06-17 08:15:46 --> Total execution time: 0.0703
DEBUG - 2022-06-17 08:15:49 --> Total execution time: 0.0481
DEBUG - 2022-06-17 08:15:51 --> Total execution time: 0.0588
DEBUG - 2022-06-17 08:15:59 --> Total execution time: 0.0319
DEBUG - 2022-06-17 08:16:00 --> Total execution time: 0.0329
DEBUG - 2022-06-17 08:17:29 --> Total execution time: 0.0289
DEBUG - 2022-06-17 08:17:39 --> Total execution time: 0.0483
DEBUG - 2022-06-17 08:17:44 --> Total execution time: 0.0425
DEBUG - 2022-06-17 08:17:49 --> Total execution time: 0.0434
DEBUG - 2022-06-17 08:17:57 --> Total execution time: 0.0540
DEBUG - 2022-06-17 08:18:25 --> Total execution time: 0.0492
DEBUG - 2022-06-17 08:18:27 --> Total execution time: 0.0491
DEBUG - 2022-06-17 08:18:28 --> Total execution time: 0.0450
DEBUG - 2022-06-17 08:18:37 --> Total execution time: 0.0435
DEBUG - 2022-06-17 08:18:43 --> Total execution time: 0.0681
DEBUG - 2022-06-17 08:19:06 --> Total execution time: 0.0534
DEBUG - 2022-06-17 08:19:09 --> Total execution time: 0.0609
DEBUG - 2022-06-17 08:19:34 --> Total execution time: 0.0435
DEBUG - 2022-06-17 08:19:35 --> Total execution time: 0.0458
DEBUG - 2022-06-17 08:19:40 --> Total execution time: 0.0455
DEBUG - 2022-06-17 08:19:43 --> Total execution time: 0.0454
DEBUG - 2022-06-17 08:19:48 --> Total execution time: 0.0393
DEBUG - 2022-06-17 08:19:51 --> Total execution time: 0.0406
DEBUG - 2022-06-17 08:20:17 --> Total execution time: 0.0326
DEBUG - 2022-06-17 08:20:30 --> Total execution time: 0.0311
DEBUG - 2022-06-17 08:20:37 --> Total execution time: 0.0474
DEBUG - 2022-06-17 08:20:40 --> Total execution time: 0.0675
DEBUG - 2022-06-17 08:20:46 --> Total execution time: 0.0414
DEBUG - 2022-06-17 08:21:48 --> Total execution time: 0.0311
DEBUG - 2022-06-17 08:23:58 --> Total execution time: 0.0406
DEBUG - 2022-06-17 08:24:41 --> Total execution time: 0.0360
DEBUG - 2022-06-17 08:25:11 --> Total execution time: 0.0401
DEBUG - 2022-06-17 08:25:20 --> Total execution time: 0.0316
DEBUG - 2022-06-17 08:25:28 --> Total execution time: 0.0358
DEBUG - 2022-06-17 08:25:37 --> Total execution time: 0.0632
DEBUG - 2022-06-17 08:25:44 --> Total execution time: 0.0587
DEBUG - 2022-06-17 08:25:47 --> Total execution time: 0.0382
DEBUG - 2022-06-17 08:25:52 --> Total execution time: 0.0428
DEBUG - 2022-06-17 08:26:31 --> Total execution time: 0.0491
DEBUG - 2022-06-17 08:26:31 --> Total execution time: 0.0455
DEBUG - 2022-06-17 08:30:03 --> Total execution time: 0.1340
DEBUG - 2022-06-17 08:35:12 --> Total execution time: 0.1627
DEBUG - 2022-06-17 08:35:33 --> Total execution time: 0.0490
DEBUG - 2022-06-17 08:35:44 --> Total execution time: 0.0716
DEBUG - 2022-06-17 08:35:48 --> Total execution time: 0.0483
DEBUG - 2022-06-17 08:36:11 --> Total execution time: 0.0460
DEBUG - 2022-06-17 08:36:21 --> Total execution time: 0.0623
DEBUG - 2022-06-17 08:36:25 --> Total execution time: 0.0553
DEBUG - 2022-06-17 08:36:27 --> Total execution time: 0.0712
DEBUG - 2022-06-17 08:36:32 --> Total execution time: 0.0491
DEBUG - 2022-06-17 08:36:35 --> Total execution time: 0.0406
DEBUG - 2022-06-17 08:36:45 --> Total execution time: 0.0418
DEBUG - 2022-06-17 08:36:49 --> Total execution time: 0.0420
DEBUG - 2022-06-17 08:37:09 --> Total execution time: 0.0445
DEBUG - 2022-06-17 08:37:35 --> Total execution time: 0.0410
DEBUG - 2022-06-17 08:37:51 --> Total execution time: 0.0511
DEBUG - 2022-06-17 08:38:01 --> Total execution time: 0.0667
DEBUG - 2022-06-17 08:38:12 --> Total execution time: 0.0503
DEBUG - 2022-06-17 08:39:11 --> Total execution time: 0.0543
DEBUG - 2022-06-17 08:44:21 --> Total execution time: 0.0452
DEBUG - 2022-06-17 08:44:27 --> Total execution time: 0.0439
DEBUG - 2022-06-17 08:44:32 --> Total execution time: 0.0636
DEBUG - 2022-06-17 08:44:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:44:33 --> Total execution time: 0.0598
DEBUG - 2022-06-17 08:45:07 --> Total execution time: 0.0473
DEBUG - 2022-06-17 08:45:09 --> Total execution time: 0.0874
DEBUG - 2022-06-17 08:45:15 --> Total execution time: 0.0755
DEBUG - 2022-06-17 08:45:19 --> Total execution time: 0.0465
DEBUG - 2022-06-17 08:45:22 --> Total execution time: 0.1210
DEBUG - 2022-06-17 08:45:23 --> Total execution time: 0.0370
DEBUG - 2022-06-17 08:45:24 --> Total execution time: 0.0431
DEBUG - 2022-06-17 08:45:26 --> Total execution time: 0.0548
DEBUG - 2022-06-17 08:45:27 --> Total execution time: 0.0377
DEBUG - 2022-06-17 08:45:30 --> Total execution time: 0.0614
DEBUG - 2022-06-17 08:45:39 --> Total execution time: 0.0433
DEBUG - 2022-06-17 08:45:44 --> Total execution time: 0.0772
DEBUG - 2022-06-17 08:45:49 --> Total execution time: 0.0549
DEBUG - 2022-06-17 08:45:52 --> Total execution time: 0.0724
DEBUG - 2022-06-17 08:46:05 --> Total execution time: 0.1168
DEBUG - 2022-06-17 08:46:16 --> Total execution time: 0.0513
DEBUG - 2022-06-17 08:46:35 --> Total execution time: 0.0439
DEBUG - 2022-06-17 08:46:46 --> Total execution time: 0.0304
DEBUG - 2022-06-17 08:46:56 --> Total execution time: 0.0487
DEBUG - 2022-06-17 08:47:01 --> Total execution time: 0.0584
DEBUG - 2022-06-17 08:47:06 --> Total execution time: 0.0441
DEBUG - 2022-06-17 08:47:09 --> Total execution time: 0.0484
DEBUG - 2022-06-17 08:47:50 --> Total execution time: 0.0465
DEBUG - 2022-06-17 08:49:25 --> Total execution time: 0.0324
DEBUG - 2022-06-17 08:50:01 --> Total execution time: 0.0378
DEBUG - 2022-06-17 08:53:35 --> Total execution time: 0.1501
DEBUG - 2022-06-17 08:53:45 --> Total execution time: 0.0460
DEBUG - 2022-06-17 08:59:01 --> Total execution time: 0.1187
DEBUG - 2022-06-17 09:03:34 --> Total execution time: 0.1004
DEBUG - 2022-06-17 09:03:45 --> Total execution time: 0.0335
DEBUG - 2022-06-17 09:03:47 --> Total execution time: 0.0399
DEBUG - 2022-06-17 09:03:48 --> Total execution time: 0.0510
DEBUG - 2022-06-17 09:04:31 --> Total execution time: 0.0505
DEBUG - 2022-06-17 09:06:48 --> Total execution time: 1.9122
DEBUG - 2022-06-17 09:06:49 --> Total execution time: 0.0462
DEBUG - 2022-06-17 09:07:13 --> Total execution time: 0.0559
DEBUG - 2022-06-17 09:07:40 --> Total execution time: 0.1059
DEBUG - 2022-06-17 09:08:31 --> Total execution time: 0.0803
DEBUG - 2022-06-17 09:08:41 --> Total execution time: 0.1105
DEBUG - 2022-06-17 09:08:50 --> Total execution time: 0.0505
DEBUG - 2022-06-17 09:09:09 --> Total execution time: 0.0425
DEBUG - 2022-06-17 09:11:02 --> Total execution time: 0.0674
DEBUG - 2022-06-17 09:13:43 --> Total execution time: 0.0397
DEBUG - 2022-06-17 09:16:41 --> Total execution time: 0.0400
DEBUG - 2022-06-17 09:16:46 --> Total execution time: 0.0485
DEBUG - 2022-06-17 09:16:56 --> Total execution time: 0.0466
DEBUG - 2022-06-17 09:17:17 --> Total execution time: 0.0520
DEBUG - 2022-06-17 09:17:22 --> Total execution time: 0.0678
DEBUG - 2022-06-17 09:17:32 --> Total execution time: 0.0961
DEBUG - 2022-06-17 09:17:33 --> Total execution time: 0.0376
DEBUG - 2022-06-17 09:17:43 --> Total execution time: 0.0389
DEBUG - 2022-06-17 09:22:08 --> Total execution time: 0.1162
DEBUG - 2022-06-17 09:22:15 --> Total execution time: 0.0542
DEBUG - 2022-06-17 09:22:39 --> Total execution time: 0.0889
DEBUG - 2022-06-17 09:23:03 --> Total execution time: 0.0416
DEBUG - 2022-06-17 09:23:36 --> Total execution time: 0.0394
DEBUG - 2022-06-17 09:23:47 --> Total execution time: 0.0419
DEBUG - 2022-06-17 09:23:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 09:23:48 --> Total execution time: 0.0435
DEBUG - 2022-06-17 09:23:50 --> Total execution time: 0.0411
DEBUG - 2022-06-17 09:24:33 --> Total execution time: 0.0632
DEBUG - 2022-06-17 09:24:34 --> Total execution time: 0.0617
DEBUG - 2022-06-17 09:24:47 --> Total execution time: 0.0349
DEBUG - 2022-06-17 09:24:47 --> Total execution time: 0.0685
DEBUG - 2022-06-17 09:24:52 --> Total execution time: 0.0543
DEBUG - 2022-06-17 09:25:04 --> Total execution time: 0.0963
DEBUG - 2022-06-17 09:25:11 --> Total execution time: 0.0375
DEBUG - 2022-06-17 09:25:13 --> Total execution time: 0.0430
DEBUG - 2022-06-17 09:25:17 --> Total execution time: 0.0763
DEBUG - 2022-06-17 09:25:23 --> Total execution time: 0.0298
DEBUG - 2022-06-17 09:25:24 --> Total execution time: 0.0704
DEBUG - 2022-06-17 09:28:00 --> Total execution time: 0.0970
DEBUG - 2022-06-17 09:30:03 --> Total execution time: 0.0622
DEBUG - 2022-06-17 09:30:21 --> Total execution time: 0.0653
DEBUG - 2022-06-17 09:31:33 --> Total execution time: 0.0524
DEBUG - 2022-06-17 09:31:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 09:31:50 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-06-17 09:31:51 --> Total execution time: 0.0452
DEBUG - 2022-06-17 09:34:28 --> Total execution time: 0.1579
DEBUG - 2022-06-17 09:38:02 --> Total execution time: 0.0862
DEBUG - 2022-06-17 09:41:23 --> Total execution time: 0.0483
DEBUG - 2022-06-17 09:41:41 --> Total execution time: 0.0602
DEBUG - 2022-06-17 09:41:55 --> Total execution time: 0.0487
DEBUG - 2022-06-17 09:42:07 --> Total execution time: 0.0449
DEBUG - 2022-06-17 09:42:17 --> Total execution time: 0.0525
DEBUG - 2022-06-17 09:42:25 --> Total execution time: 0.0422
DEBUG - 2022-06-17 09:42:28 --> Total execution time: 0.0411
DEBUG - 2022-06-17 09:42:34 --> Total execution time: 0.0408
DEBUG - 2022-06-17 09:42:43 --> Total execution time: 0.0448
DEBUG - 2022-06-17 09:43:03 --> Total execution time: 0.0550
DEBUG - 2022-06-17 09:43:09 --> Total execution time: 0.0546
DEBUG - 2022-06-17 09:43:14 --> Total execution time: 0.0491
DEBUG - 2022-06-17 09:43:24 --> Total execution time: 0.0493
DEBUG - 2022-06-17 09:43:30 --> Total execution time: 0.0561
DEBUG - 2022-06-17 09:43:40 --> Total execution time: 0.0724
DEBUG - 2022-06-17 09:43:49 --> Total execution time: 0.0635
DEBUG - 2022-06-17 09:43:52 --> Total execution time: 0.0445
DEBUG - 2022-06-17 09:43:57 --> Total execution time: 0.0725
DEBUG - 2022-06-17 09:44:16 --> Total execution time: 0.0437
DEBUG - 2022-06-17 09:44:29 --> Total execution time: 0.0430
DEBUG - 2022-06-17 09:45:53 --> Total execution time: 0.0434
DEBUG - 2022-06-17 09:45:57 --> Total execution time: 0.0458
DEBUG - 2022-06-17 09:46:01 --> Total execution time: 0.1210
DEBUG - 2022-06-17 09:46:20 --> Total execution time: 0.0302
DEBUG - 2022-06-17 09:46:20 --> Total execution time: 0.0467
DEBUG - 2022-06-17 09:46:30 --> Total execution time: 0.0459
DEBUG - 2022-06-17 09:46:38 --> Total execution time: 0.0540
DEBUG - 2022-06-17 09:47:17 --> Total execution time: 0.1155
DEBUG - 2022-06-17 09:47:37 --> Total execution time: 0.0453
DEBUG - 2022-06-17 09:47:45 --> Total execution time: 0.0512
DEBUG - 2022-06-17 09:47:48 --> Total execution time: 0.0585
DEBUG - 2022-06-17 09:47:51 --> Total execution time: 0.0675
DEBUG - 2022-06-17 09:48:07 --> Total execution time: 0.0554
DEBUG - 2022-06-17 09:48:11 --> Total execution time: 0.0614
DEBUG - 2022-06-17 09:48:15 --> Total execution time: 0.0565
DEBUG - 2022-06-17 09:48:19 --> Total execution time: 0.0384
DEBUG - 2022-06-17 09:48:22 --> Total execution time: 0.0657
DEBUG - 2022-06-17 09:48:24 --> Total execution time: 0.0569
DEBUG - 2022-06-17 09:48:48 --> Total execution time: 0.0381
DEBUG - 2022-06-17 09:56:43 --> Total execution time: 0.2242
DEBUG - 2022-06-17 09:59:01 --> Total execution time: 0.0966
DEBUG - 2022-06-17 09:59:06 --> Total execution time: 0.0583
DEBUG - 2022-06-17 09:59:19 --> Total execution time: 0.0651
DEBUG - 2022-06-17 09:59:27 --> Total execution time: 0.0600
DEBUG - 2022-06-17 09:59:39 --> Total execution time: 0.0615
DEBUG - 2022-06-17 10:00:28 --> Total execution time: 0.0525
DEBUG - 2022-06-17 10:00:33 --> Total execution time: 0.0601
DEBUG - 2022-06-17 10:00:41 --> Total execution time: 0.0415
DEBUG - 2022-06-17 10:01:11 --> Total execution time: 0.0643
DEBUG - 2022-06-17 10:01:26 --> Total execution time: 0.0650
DEBUG - 2022-06-17 10:02:21 --> Total execution time: 0.0431
DEBUG - 2022-06-17 10:02:55 --> Total execution time: 0.0468
DEBUG - 2022-06-17 10:03:03 --> Total execution time: 0.0581
DEBUG - 2022-06-17 10:03:39 --> Total execution time: 0.0463
DEBUG - 2022-06-17 10:03:51 --> Total execution time: 0.0519
DEBUG - 2022-06-17 10:03:54 --> Total execution time: 0.0530
DEBUG - 2022-06-17 10:04:00 --> Total execution time: 0.0531
DEBUG - 2022-06-17 10:04:06 --> Total execution time: 0.1183
DEBUG - 2022-06-17 10:04:06 --> Total execution time: 0.0632
DEBUG - 2022-06-17 10:04:10 --> Total execution time: 0.0875
DEBUG - 2022-06-17 10:04:19 --> Total execution time: 0.0449
DEBUG - 2022-06-17 10:04:24 --> Total execution time: 0.0516
DEBUG - 2022-06-17 10:04:30 --> Total execution time: 0.0755
DEBUG - 2022-06-17 10:04:39 --> Total execution time: 0.0727
DEBUG - 2022-06-17 10:05:20 --> Total execution time: 0.0624
DEBUG - 2022-06-17 10:05:23 --> Total execution time: 0.0451
DEBUG - 2022-06-17 10:09:26 --> Total execution time: 0.0521
DEBUG - 2022-06-17 10:09:42 --> Total execution time: 0.0324
DEBUG - 2022-06-17 10:09:47 --> Total execution time: 0.0403
DEBUG - 2022-06-17 10:09:56 --> Total execution time: 0.0420
DEBUG - 2022-06-17 10:10:11 --> Total execution time: 0.0459
DEBUG - 2022-06-17 10:10:11 --> Total execution time: 0.0458
DEBUG - 2022-06-17 10:12:09 --> Total execution time: 0.0338
DEBUG - 2022-06-17 10:12:27 --> Total execution time: 0.0446
DEBUG - 2022-06-17 10:16:09 --> Total execution time: 0.0955
DEBUG - 2022-06-17 10:16:14 --> Total execution time: 0.0521
DEBUG - 2022-06-17 10:16:22 --> Total execution time: 0.0495
DEBUG - 2022-06-17 10:16:30 --> Total execution time: 0.0475
DEBUG - 2022-06-17 10:16:32 --> Total execution time: 0.0332
DEBUG - 2022-06-17 10:16:33 --> Total execution time: 0.0384
DEBUG - 2022-06-17 10:16:33 --> Total execution time: 0.0598
DEBUG - 2022-06-17 10:16:38 --> Total execution time: 0.0658
DEBUG - 2022-06-17 10:21:14 --> Total execution time: 0.2007
DEBUG - 2022-06-17 10:21:20 --> Total execution time: 0.0418
DEBUG - 2022-06-17 10:21:31 --> Total execution time: 0.0870
DEBUG - 2022-06-17 10:21:37 --> Total execution time: 0.0781
DEBUG - 2022-06-17 10:21:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 10:21:38 --> Total execution time: 0.0557
DEBUG - 2022-06-17 10:21:57 --> Total execution time: 0.1093
DEBUG - 2022-06-17 10:22:20 --> Total execution time: 0.0449
DEBUG - 2022-06-17 10:22:32 --> Total execution time: 0.0529
DEBUG - 2022-06-17 10:22:43 --> Total execution time: 0.0400
DEBUG - 2022-06-17 10:23:11 --> Total execution time: 0.0408
DEBUG - 2022-06-17 10:23:43 --> Total execution time: 0.0719
DEBUG - 2022-06-17 10:23:50 --> Total execution time: 0.0375
DEBUG - 2022-06-17 10:23:53 --> Total execution time: 0.0743
DEBUG - 2022-06-17 10:23:59 --> Total execution time: 0.0391
DEBUG - 2022-06-17 10:24:05 --> Total execution time: 0.0381
DEBUG - 2022-06-17 10:24:10 --> Total execution time: 0.0693
DEBUG - 2022-06-17 10:24:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 10:24:12 --> Total execution time: 0.0383
DEBUG - 2022-06-17 10:24:53 --> Total execution time: 0.0394
DEBUG - 2022-06-17 10:25:03 --> Total execution time: 0.0560
DEBUG - 2022-06-17 10:25:19 --> Total execution time: 0.0290
DEBUG - 2022-06-17 10:26:07 --> Total execution time: 0.0494
DEBUG - 2022-06-17 10:26:11 --> Total execution time: 0.0846
DEBUG - 2022-06-17 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:03 --> Total execution time: 0.1101
DEBUG - 2022-06-17 00:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:42 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:42 --> Total execution time: 0.1082
DEBUG - 2022-06-17 00:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:46 --> Total execution time: 0.1097
DEBUG - 2022-06-17 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:50 --> Total execution time: 0.0386
DEBUG - 2022-06-17 00:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:56 --> Total execution time: 0.0484
DEBUG - 2022-06-17 00:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 00:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:57 --> Total execution time: 0.0385
DEBUG - 2022-06-17 00:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:40 --> Total execution time: 0.0377
DEBUG - 2022-06-17 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:42 --> Total execution time: 0.0506
DEBUG - 2022-06-17 00:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:47 --> Total execution time: 0.0567
DEBUG - 2022-06-17 00:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:51 --> Total execution time: 0.0471
DEBUG - 2022-06-17 00:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:57 --> Total execution time: 0.0404
DEBUG - 2022-06-17 00:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:58 --> Total execution time: 0.0504
DEBUG - 2022-06-17 00:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:32:36 --> Total execution time: 0.0560
DEBUG - 2022-06-17 00:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:32:42 --> Total execution time: 0.0334
DEBUG - 2022-06-17 00:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:03:22 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 00:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:03:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:33:49 --> Total execution time: 0.0680
DEBUG - 2022-06-17 00:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:34:22 --> Total execution time: 0.0432
DEBUG - 2022-06-17 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:35:09 --> Total execution time: 0.1388
DEBUG - 2022-06-17 00:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:06:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:09 --> Total execution time: 0.0492
DEBUG - 2022-06-17 00:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:12 --> Total execution time: 0.1206
DEBUG - 2022-06-17 00:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:22 --> Total execution time: 0.0424
DEBUG - 2022-06-17 00:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:06:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:32 --> Total execution time: 0.0597
DEBUG - 2022-06-17 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:47 --> Total execution time: 0.0454
DEBUG - 2022-06-17 00:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:37:44 --> Total execution time: 0.0384
DEBUG - 2022-06-17 00:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:37:44 --> Total execution time: 0.0345
DEBUG - 2022-06-17 00:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:38:06 --> Total execution time: 0.0543
DEBUG - 2022-06-17 00:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:38:18 --> Total execution time: 0.0452
DEBUG - 2022-06-17 00:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:38:37 --> Total execution time: 0.0721
DEBUG - 2022-06-17 00:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:08:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:28 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:34 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:43 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:09:48 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:10:04 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:10:54 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:10:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:10:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:40:58 --> Total execution time: 0.1082
DEBUG - 2022-06-17 00:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:10:59 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:11:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:11:06 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:11:09 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:42:12 --> Total execution time: 0.0277
DEBUG - 2022-06-17 00:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:42:19 --> Total execution time: 0.0547
DEBUG - 2022-06-17 00:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:42:41 --> Total execution time: 0.0651
DEBUG - 2022-06-17 00:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:43:06 --> Total execution time: 0.0474
DEBUG - 2022-06-17 00:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:43:28 --> Total execution time: 0.0449
DEBUG - 2022-06-17 00:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:43:46 --> Total execution time: 0.0602
DEBUG - 2022-06-17 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:44:09 --> Total execution time: 0.0487
DEBUG - 2022-06-17 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:44:19 --> Total execution time: 0.0433
DEBUG - 2022-06-17 00:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:44:55 --> Total execution time: 0.0632
DEBUG - 2022-06-17 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:45:24 --> Total execution time: 0.0433
DEBUG - 2022-06-17 00:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:15:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:45:25 --> Total execution time: 0.0506
DEBUG - 2022-06-17 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:45:33 --> Total execution time: 0.0445
DEBUG - 2022-06-17 00:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:46:11 --> Total execution time: 0.1052
DEBUG - 2022-06-17 00:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:46:12 --> Total execution time: 0.0632
DEBUG - 2022-06-17 00:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:16:54 --> Total execution time: 0.0413
DEBUG - 2022-06-17 00:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:16:55 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 00:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:46:58 --> Total execution time: 0.0478
DEBUG - 2022-06-17 00:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:48:11 --> Total execution time: 0.1399
DEBUG - 2022-06-17 00:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:20:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:50:48 --> Total execution time: 0.1287
DEBUG - 2022-06-17 00:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:20:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:50:49 --> Total execution time: 0.0345
DEBUG - 2022-06-17 00:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:21:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:51:02 --> Total execution time: 0.0421
DEBUG - 2022-06-17 00:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:21:56 --> Total execution time: 0.0458
DEBUG - 2022-06-17 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:22:03 --> Total execution time: 0.0425
DEBUG - 2022-06-17 00:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:22:03 --> Total execution time: 0.0988
DEBUG - 2022-06-17 00:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:22:25 --> Total execution time: 0.0465
DEBUG - 2022-06-17 00:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:23:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 00:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:53:13 --> Total execution time: 1.9744
DEBUG - 2022-06-17 00:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 00:23:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 00:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:53:48 --> Total execution time: 0.0468
DEBUG - 2022-06-17 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:53:59 --> Total execution time: 0.0630
DEBUG - 2022-06-17 00:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:54:10 --> Total execution time: 0.0683
DEBUG - 2022-06-17 00:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:54:13 --> Total execution time: 0.0781
DEBUG - 2022-06-17 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:54:21 --> Total execution time: 0.0481
DEBUG - 2022-06-17 00:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:25:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:55:30 --> Total execution time: 0.1843
DEBUG - 2022-06-17 00:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:55:36 --> Total execution time: 0.0587
DEBUG - 2022-06-17 00:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:55:44 --> Total execution time: 0.1089
DEBUG - 2022-06-17 00:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:20 --> Total execution time: 0.0510
DEBUG - 2022-06-17 00:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:26:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:27 --> Total execution time: 0.0455
DEBUG - 2022-06-17 00:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:29 --> Total execution time: 0.0430
DEBUG - 2022-06-17 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:48 --> Total execution time: 0.0777
DEBUG - 2022-06-17 00:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:57 --> Total execution time: 0.0442
DEBUG - 2022-06-17 00:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:02 --> Total execution time: 0.0530
DEBUG - 2022-06-17 00:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 00:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:03 --> Total execution time: 0.0398
DEBUG - 2022-06-17 00:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:46 --> Total execution time: 0.1233
DEBUG - 2022-06-17 00:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:51 --> Total execution time: 0.0522
DEBUG - 2022-06-17 00:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:52 --> Total execution time: 0.0578
DEBUG - 2022-06-17 00:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:53 --> Total execution time: 0.0636
DEBUG - 2022-06-17 00:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:13 --> Total execution time: 0.1466
DEBUG - 2022-06-17 00:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:17 --> Total execution time: 0.1231
DEBUG - 2022-06-17 00:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:20 --> Total execution time: 0.0996
DEBUG - 2022-06-17 00:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:28:36 --> Total execution time: 0.0491
DEBUG - 2022-06-17 00:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:28:45 --> Total execution time: 0.0779
DEBUG - 2022-06-17 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:29:04 --> Total execution time: 0.0891
DEBUG - 2022-06-17 00:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:29:11 --> Total execution time: 0.0378
DEBUG - 2022-06-17 00:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:29:13 --> Total execution time: 0.0391
DEBUG - 2022-06-17 00:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:14 --> Total execution time: 0.0557
DEBUG - 2022-06-17 00:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:20 --> Total execution time: 0.0816
DEBUG - 2022-06-17 00:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:23 --> Total execution time: 0.0433
DEBUG - 2022-06-17 00:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:24 --> Total execution time: 0.0458
DEBUG - 2022-06-17 00:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:25 --> Total execution time: 0.0444
DEBUG - 2022-06-17 00:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:26 --> Total execution time: 0.0715
DEBUG - 2022-06-17 00:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:28 --> Total execution time: 0.0439
DEBUG - 2022-06-17 00:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:31 --> Total execution time: 0.0519
DEBUG - 2022-06-17 00:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:33 --> Total execution time: 0.0656
DEBUG - 2022-06-17 00:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:40 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:40 --> Total execution time: 0.0326
DEBUG - 2022-06-17 00:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:41 --> Total execution time: 0.0469
DEBUG - 2022-06-17 00:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:44 --> Total execution time: 0.0508
DEBUG - 2022-06-17 00:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:45 --> Total execution time: 0.0662
DEBUG - 2022-06-17 00:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:59:48 --> Total execution time: 0.1044
DEBUG - 2022-06-17 00:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:00:06 --> Total execution time: 0.0590
DEBUG - 2022-06-17 00:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:01:53 --> Total execution time: 0.0538
DEBUG - 2022-06-17 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:33:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:03:02 --> Total execution time: 0.0316
DEBUG - 2022-06-17 00:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:33:22 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:03:22 --> Total execution time: 0.0414
DEBUG - 2022-06-17 00:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:05:08 --> Total execution time: 0.0587
DEBUG - 2022-06-17 00:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:08:36 --> Total execution time: 0.0968
DEBUG - 2022-06-17 00:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:08:40 --> Total execution time: 0.0393
DEBUG - 2022-06-17 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:09:02 --> Total execution time: 0.0953
DEBUG - 2022-06-17 00:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:09:14 --> Total execution time: 0.0560
DEBUG - 2022-06-17 00:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:09:30 --> Total execution time: 0.0769
DEBUG - 2022-06-17 00:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:09:39 --> Total execution time: 0.0946
DEBUG - 2022-06-17 00:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:09:46 --> Total execution time: 0.0484
DEBUG - 2022-06-17 00:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:07 --> Total execution time: 0.1113
DEBUG - 2022-06-17 00:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:11 --> No URI present. Default controller set.
DEBUG - 2022-06-17 00:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:11 --> Total execution time: 0.0382
DEBUG - 2022-06-17 00:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:13 --> Total execution time: 0.0631
DEBUG - 2022-06-17 00:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:23 --> Total execution time: 0.0392
DEBUG - 2022-06-17 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:24 --> Total execution time: 0.0681
DEBUG - 2022-06-17 00:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:27 --> Total execution time: 0.0467
DEBUG - 2022-06-17 00:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:47 --> Total execution time: 0.0492
DEBUG - 2022-06-17 00:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:10:52 --> Total execution time: 0.0534
DEBUG - 2022-06-17 00:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:11:14 --> Total execution time: 0.0621
DEBUG - 2022-06-17 00:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:11:59 --> Total execution time: 0.0547
DEBUG - 2022-06-17 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:12:02 --> Total execution time: 0.0910
DEBUG - 2022-06-17 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:12:12 --> Total execution time: 0.0916
DEBUG - 2022-06-17 00:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:13:35 --> Total execution time: 0.2401
DEBUG - 2022-06-17 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:13:37 --> Total execution time: 0.1913
DEBUG - 2022-06-17 00:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:13:38 --> Total execution time: 0.1712
DEBUG - 2022-06-17 00:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:15:21 --> Total execution time: 0.0279
DEBUG - 2022-06-17 00:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:15:21 --> Total execution time: 0.0420
DEBUG - 2022-06-17 00:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:18:36 --> Total execution time: 0.2478
DEBUG - 2022-06-17 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:43 --> Total execution time: 0.0423
DEBUG - 2022-06-17 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:26:48 --> Total execution time: 0.2276
DEBUG - 2022-06-17 00:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:28:27 --> Total execution time: 0.1480
DEBUG - 2022-06-17 00:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:28:27 --> Total execution time: 0.0375
DEBUG - 2022-06-17 00:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:28:32 --> Total execution time: 0.0403
DEBUG - 2022-06-17 00:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:28:37 --> Total execution time: 0.1502
DEBUG - 2022-06-17 00:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 00:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 00:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:29:22 --> Total execution time: 0.0392
DEBUG - 2022-06-17 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:30:02 --> Total execution time: 0.0499
DEBUG - 2022-06-17 01:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:02:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:32:46 --> Total execution time: 0.1236
DEBUG - 2022-06-17 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:02:47 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:32:47 --> Total execution time: 0.0361
DEBUG - 2022-06-17 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:32:53 --> Total execution time: 0.0437
DEBUG - 2022-06-17 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:32:53 --> Total execution time: 0.0307
DEBUG - 2022-06-17 01:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:32:59 --> Total execution time: 0.0419
DEBUG - 2022-06-17 01:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:33:06 --> Total execution time: 0.0739
DEBUG - 2022-06-17 01:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:33:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 01:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:33:07 --> Total execution time: 0.0379
DEBUG - 2022-06-17 01:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:02 --> Total execution time: 0.0435
DEBUG - 2022-06-17 01:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:04 --> Total execution time: 0.0462
DEBUG - 2022-06-17 01:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:09 --> Total execution time: 0.0567
DEBUG - 2022-06-17 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:13 --> Total execution time: 0.0548
DEBUG - 2022-06-17 01:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:29 --> Total execution time: 0.0405
DEBUG - 2022-06-17 01:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:39 --> Total execution time: 0.0987
DEBUG - 2022-06-17 01:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:45 --> Total execution time: 0.0514
DEBUG - 2022-06-17 01:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:38:42 --> Total execution time: 0.1171
DEBUG - 2022-06-17 01:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:08:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:38:57 --> Total execution time: 0.0468
DEBUG - 2022-06-17 01:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:08:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:38:57 --> Total execution time: 0.0311
DEBUG - 2022-06-17 01:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:38:58 --> Total execution time: 0.0396
DEBUG - 2022-06-17 01:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:39:01 --> Total execution time: 0.0914
DEBUG - 2022-06-17 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:39:26 --> Total execution time: 0.0494
DEBUG - 2022-06-17 01:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:39:31 --> Total execution time: 0.0519
DEBUG - 2022-06-17 01:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:09:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:39:50 --> Total execution time: 0.1111
DEBUG - 2022-06-17 01:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:07 --> Total execution time: 0.1096
DEBUG - 2022-06-17 01:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:10 --> Total execution time: 0.0475
DEBUG - 2022-06-17 01:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:15 --> Total execution time: 0.0546
DEBUG - 2022-06-17 01:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:10:49 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 01:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:12:05 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:05 --> Total execution time: 0.0424
DEBUG - 2022-06-17 01:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:11 --> Total execution time: 0.0591
DEBUG - 2022-06-17 01:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:15 --> Total execution time: 0.0655
DEBUG - 2022-06-17 01:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:19 --> Total execution time: 0.0619
DEBUG - 2022-06-17 01:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:23 --> Total execution time: 0.0398
DEBUG - 2022-06-17 01:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:13:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 01:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:43:17 --> Total execution time: 0.0810
DEBUG - 2022-06-17 01:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:43:36 --> Total execution time: 0.0424
DEBUG - 2022-06-17 01:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:43:48 --> Total execution time: 0.1267
DEBUG - 2022-06-17 01:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:13:58 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:43:58 --> Total execution time: 0.0385
DEBUG - 2022-06-17 01:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:44:01 --> Total execution time: 0.0544
DEBUG - 2022-06-17 01:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:44:19 --> Total execution time: 0.0993
DEBUG - 2022-06-17 01:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:14:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:44:32 --> Total execution time: 0.0642
DEBUG - 2022-06-17 01:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:14:43 --> Total execution time: 0.0511
DEBUG - 2022-06-17 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:14:45 --> Total execution time: 0.2551
DEBUG - 2022-06-17 01:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:14:46 --> Total execution time: 0.3484
DEBUG - 2022-06-17 01:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:15:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 01:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:23 --> Total execution time: 0.1004
DEBUG - 2022-06-17 01:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:28 --> Total execution time: 0.0510
DEBUG - 2022-06-17 01:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:15:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 01:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:31 --> Total execution time: 2.0570
DEBUG - 2022-06-17 01:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:32 --> Total execution time: 0.1152
DEBUG - 2022-06-17 01:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:32 --> Total execution time: 0.0742
DEBUG - 2022-06-17 01:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:44 --> Total execution time: 0.0900
DEBUG - 2022-06-17 01:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:15:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:53 --> Total execution time: 0.0463
DEBUG - 2022-06-17 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:46:09 --> Total execution time: 1.6184
DEBUG - 2022-06-17 01:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:16:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 01:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:16:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:46:30 --> Total execution time: 0.0447
DEBUG - 2022-06-17 01:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:46:34 --> Total execution time: 0.0791
DEBUG - 2022-06-17 01:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:01 --> Total execution time: 0.0535
DEBUG - 2022-06-17 01:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:02 --> Total execution time: 0.0512
DEBUG - 2022-06-17 01:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:12 --> Total execution time: 0.0428
DEBUG - 2022-06-17 01:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:14 --> Total execution time: 0.0297
DEBUG - 2022-06-17 01:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:42 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:42 --> Total execution time: 0.1401
DEBUG - 2022-06-17 01:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:51 --> Total execution time: 0.0449
DEBUG - 2022-06-17 01:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:57 --> Total execution time: 0.0323
DEBUG - 2022-06-17 01:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:47:58 --> Total execution time: 0.0442
DEBUG - 2022-06-17 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:48:00 --> Total execution time: 0.0387
DEBUG - 2022-06-17 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:48:07 --> Total execution time: 1.5844
DEBUG - 2022-06-17 01:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:18:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:18:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 01:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:18:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:48:26 --> Total execution time: 0.0328
DEBUG - 2022-06-17 01:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:48:41 --> Total execution time: 0.0305
DEBUG - 2022-06-17 01:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:09 --> Total execution time: 0.0725
DEBUG - 2022-06-17 01:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:11 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:11 --> Total execution time: 0.1056
DEBUG - 2022-06-17 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:17 --> Total execution time: 0.0524
DEBUG - 2022-06-17 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:26 --> Total execution time: 0.0470
DEBUG - 2022-06-17 01:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:35 --> Total execution time: 0.0635
DEBUG - 2022-06-17 01:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:38 --> Total execution time: 0.0444
DEBUG - 2022-06-17 01:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:06 --> Total execution time: 0.0298
DEBUG - 2022-06-17 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:13 --> Total execution time: 0.0571
DEBUG - 2022-06-17 01:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:16 --> Total execution time: 0.0473
DEBUG - 2022-06-17 01:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:17 --> Total execution time: 0.0774
DEBUG - 2022-06-17 01:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:19 --> Total execution time: 0.0512
DEBUG - 2022-06-17 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:29 --> Total execution time: 0.0436
DEBUG - 2022-06-17 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:52 --> Total execution time: 0.0422
DEBUG - 2022-06-17 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:53 --> Total execution time: 0.0426
DEBUG - 2022-06-17 01:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:59 --> Total execution time: 0.0688
DEBUG - 2022-06-17 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:00 --> Total execution time: 0.0484
DEBUG - 2022-06-17 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:00 --> Total execution time: 0.0470
DEBUG - 2022-06-17 01:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:01 --> Total execution time: 0.0675
DEBUG - 2022-06-17 01:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:01 --> Total execution time: 0.0484
DEBUG - 2022-06-17 01:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:01 --> Total execution time: 0.0793
DEBUG - 2022-06-17 01:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:02 --> Total execution time: 0.0525
DEBUG - 2022-06-17 01:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:03 --> Total execution time: 0.0460
DEBUG - 2022-06-17 01:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:04 --> Total execution time: 0.0522
DEBUG - 2022-06-17 01:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:11 --> Total execution time: 0.0814
DEBUG - 2022-06-17 01:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:22:19 --> Total execution time: 0.0389
DEBUG - 2022-06-17 01:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:29 --> Total execution time: 0.0423
DEBUG - 2022-06-17 01:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:22:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:55 --> Total execution time: 0.0371
DEBUG - 2022-06-17 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:02 --> Total execution time: 0.0358
DEBUG - 2022-06-17 01:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:04 --> Total execution time: 0.0386
DEBUG - 2022-06-17 01:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:05 --> Total execution time: 0.0293
DEBUG - 2022-06-17 01:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:05 --> Total execution time: 0.0279
DEBUG - 2022-06-17 01:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:22 --> Total execution time: 0.0583
DEBUG - 2022-06-17 01:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:25 --> Total execution time: 0.0323
DEBUG - 2022-06-17 01:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:35 --> Total execution time: 0.0452
DEBUG - 2022-06-17 01:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:53:57 --> Total execution time: 0.0447
DEBUG - 2022-06-17 01:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:54:28 --> Total execution time: 0.0419
DEBUG - 2022-06-17 01:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:54:36 --> Total execution time: 0.0462
DEBUG - 2022-06-17 01:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:54:44 --> Total execution time: 0.0468
DEBUG - 2022-06-17 01:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:54:45 --> Total execution time: 0.0444
DEBUG - 2022-06-17 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:54:51 --> Total execution time: 0.0767
DEBUG - 2022-06-17 01:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:55:05 --> Total execution time: 0.0431
DEBUG - 2022-06-17 01:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:25:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:55:28 --> Total execution time: 0.1039
DEBUG - 2022-06-17 01:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:25:38 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:55:38 --> Total execution time: 0.0447
DEBUG - 2022-06-17 01:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:55:43 --> Total execution time: 0.0415
DEBUG - 2022-06-17 01:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:00 --> Total execution time: 0.0525
DEBUG - 2022-06-17 01:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:13 --> Total execution time: 0.0514
DEBUG - 2022-06-17 01:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:18 --> Total execution time: 0.0491
DEBUG - 2022-06-17 01:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:21 --> Total execution time: 0.0508
DEBUG - 2022-06-17 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:26:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:37 --> Total execution time: 0.0668
DEBUG - 2022-06-17 01:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:32:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:02:36 --> Total execution time: 0.1036
DEBUG - 2022-06-17 01:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:04:47 --> Total execution time: 0.0408
DEBUG - 2022-06-17 01:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:34:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:04:55 --> Total execution time: 0.0433
DEBUG - 2022-06-17 01:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:35:01 --> Total execution time: 0.0428
DEBUG - 2022-06-17 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:35:02 --> Total execution time: 0.0396
DEBUG - 2022-06-17 01:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:35:02 --> Total execution time: 0.0904
DEBUG - 2022-06-17 01:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:37:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 01:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:37:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 01:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:07:32 --> Total execution time: 1.9581
DEBUG - 2022-06-17 01:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:37:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:37:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:07:49 --> Total execution time: 0.1148
DEBUG - 2022-06-17 01:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:07:54 --> Total execution time: 0.0433
DEBUG - 2022-06-17 01:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 01:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:13 --> Total execution time: 0.0483
DEBUG - 2022-06-17 01:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 12:08:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 12:08:15 --> Total execution time: 0.1815
DEBUG - 2022-06-17 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:33 --> Total execution time: 0.0518
DEBUG - 2022-06-17 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:41 --> Total execution time: 0.0433
DEBUG - 2022-06-17 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:41 --> Total execution time: 0.0331
DEBUG - 2022-06-17 01:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:52 --> Total execution time: 0.0611
DEBUG - 2022-06-17 01:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:58 --> Total execution time: 0.0764
DEBUG - 2022-06-17 01:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:09:03 --> Total execution time: 0.0492
DEBUG - 2022-06-17 01:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:09:11 --> Total execution time: 0.0873
DEBUG - 2022-06-17 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:09:32 --> Total execution time: 0.0574
DEBUG - 2022-06-17 01:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:40:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:10:56 --> Total execution time: 0.0338
DEBUG - 2022-06-17 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:11:05 --> Total execution time: 0.0389
DEBUG - 2022-06-17 01:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:11:41 --> Total execution time: 0.0725
DEBUG - 2022-06-17 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:11:52 --> Total execution time: 0.0552
DEBUG - 2022-06-17 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:11:58 --> Total execution time: 0.0807
DEBUG - 2022-06-17 01:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:11:58 --> Total execution time: 0.1071
DEBUG - 2022-06-17 01:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:42:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:12:28 --> Total execution time: 0.0377
DEBUG - 2022-06-17 01:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:12:29 --> Total execution time: 0.0637
DEBUG - 2022-06-17 01:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:12:35 --> Total execution time: 0.0410
DEBUG - 2022-06-17 01:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:12:52 --> Total execution time: 0.0522
DEBUG - 2022-06-17 01:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:13:01 --> Total execution time: 0.0727
DEBUG - 2022-06-17 01:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:13:04 --> Total execution time: 0.0549
DEBUG - 2022-06-17 01:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:13:17 --> Total execution time: 0.1284
DEBUG - 2022-06-17 01:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:13:21 --> Total execution time: 0.0434
DEBUG - 2022-06-17 01:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:13:47 --> Total execution time: 0.1076
DEBUG - 2022-06-17 01:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:01 --> Total execution time: 0.0473
DEBUG - 2022-06-17 01:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:10 --> Total execution time: 0.0515
DEBUG - 2022-06-17 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:18 --> Total execution time: 0.0437
DEBUG - 2022-06-17 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:19 --> Total execution time: 0.0485
DEBUG - 2022-06-17 01:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:24 --> Total execution time: 0.0396
DEBUG - 2022-06-17 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:27 --> Total execution time: 0.0429
DEBUG - 2022-06-17 01:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:33 --> Total execution time: 0.0462
DEBUG - 2022-06-17 01:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:14:39 --> Total execution time: 0.1004
DEBUG - 2022-06-17 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:15:38 --> Total execution time: 0.0431
DEBUG - 2022-06-17 01:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:15:46 --> Total execution time: 0.0490
DEBUG - 2022-06-17 01:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:16:51 --> Total execution time: 0.0430
DEBUG - 2022-06-17 01:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:17:03 --> Total execution time: 0.0404
DEBUG - 2022-06-17 01:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:17:08 --> Total execution time: 0.1256
DEBUG - 2022-06-17 01:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:17:15 --> Total execution time: 0.0769
DEBUG - 2022-06-17 01:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:19:06 --> Total execution time: 0.1036
DEBUG - 2022-06-17 01:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:49:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:19:44 --> Total execution time: 0.0309
DEBUG - 2022-06-17 01:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:20:01 --> Total execution time: 0.0456
DEBUG - 2022-06-17 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:50:04 --> Total execution time: 0.0428
DEBUG - 2022-06-17 01:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:50:06 --> Total execution time: 0.0434
DEBUG - 2022-06-17 01:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:50:06 --> Total execution time: 0.0835
DEBUG - 2022-06-17 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:50:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:20:54 --> Total execution time: 0.0476
DEBUG - 2022-06-17 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:52:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:22:26 --> Total execution time: 0.0456
DEBUG - 2022-06-17 01:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:52:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:22:36 --> Total execution time: 0.0316
DEBUG - 2022-06-17 01:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:52:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:22:59 --> Total execution time: 0.0406
DEBUG - 2022-06-17 01:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:23:14 --> Total execution time: 0.0474
DEBUG - 2022-06-17 01:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:23:18 --> Total execution time: 0.0290
DEBUG - 2022-06-17 01:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:23:22 --> Total execution time: 0.0398
DEBUG - 2022-06-17 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:23:39 --> Total execution time: 0.0594
DEBUG - 2022-06-17 01:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:23:46 --> Total execution time: 0.0606
DEBUG - 2022-06-17 01:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:23:58 --> Total execution time: 0.0767
DEBUG - 2022-06-17 01:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:54:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:24:23 --> Total execution time: 0.0356
DEBUG - 2022-06-17 01:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:54:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:24:46 --> Total execution time: 0.0355
DEBUG - 2022-06-17 01:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:55:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 01:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:25:01 --> Total execution time: 0.0488
DEBUG - 2022-06-17 01:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:55:06 --> Total execution time: 0.0313
DEBUG - 2022-06-17 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:55:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:25:31 --> Total execution time: 1.9307
DEBUG - 2022-06-17 01:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 01:55:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 01:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 01:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 01:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:56:20 --> Total execution time: 0.0576
DEBUG - 2022-06-17 01:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 01:56:20 --> Total execution time: 0.0666
DEBUG - 2022-06-17 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:30:04 --> Total execution time: 0.2053
DEBUG - 2022-06-17 02:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:00:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:30:12 --> Total execution time: 0.0379
DEBUG - 2022-06-17 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:31:13 --> Total execution time: 0.0440
DEBUG - 2022-06-17 02:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:31:39 --> Total execution time: 0.0563
DEBUG - 2022-06-17 02:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:31:57 --> Total execution time: 0.0666
DEBUG - 2022-06-17 02:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:01 --> Total execution time: 0.1823
DEBUG - 2022-06-17 02:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:20 --> Total execution time: 0.1525
DEBUG - 2022-06-17 02:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:29 --> Total execution time: 0.1108
DEBUG - 2022-06-17 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 02:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:37 --> Total execution time: 0.0605
DEBUG - 2022-06-17 02:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 02:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:32:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 02:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:39 --> Total execution time: 0.1860
DEBUG - 2022-06-17 02:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:39 --> Total execution time: 0.0469
DEBUG - 2022-06-17 02:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:44 --> Total execution time: 0.0318
DEBUG - 2022-06-17 02:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:50 --> Total execution time: 0.1777
DEBUG - 2022-06-17 02:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:32:57 --> Total execution time: 0.0454
DEBUG - 2022-06-17 02:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:03 --> Total execution time: 0.0673
DEBUG - 2022-06-17 02:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:10 --> Total execution time: 0.0469
DEBUG - 2022-06-17 02:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:13 --> Total execution time: 0.0725
DEBUG - 2022-06-17 02:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:20 --> Total execution time: 0.0663
DEBUG - 2022-06-17 02:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:26 --> Total execution time: 0.0795
DEBUG - 2022-06-17 02:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:32 --> Total execution time: 0.0907
DEBUG - 2022-06-17 02:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:38 --> Total execution time: 0.0889
DEBUG - 2022-06-17 02:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:39 --> Total execution time: 0.0655
DEBUG - 2022-06-17 02:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:33:51 --> Total execution time: 0.0616
DEBUG - 2022-06-17 02:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:34:06 --> Total execution time: 0.0916
DEBUG - 2022-06-17 02:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:04:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:34:36 --> Total execution time: 0.0425
DEBUG - 2022-06-17 02:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:05:00 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:35:00 --> Total execution time: 0.0574
DEBUG - 2022-06-17 02:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:05:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:35:23 --> Total execution time: 0.0303
DEBUG - 2022-06-17 02:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:05:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:35:24 --> Total execution time: 0.0302
DEBUG - 2022-06-17 02:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:05:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:35:28 --> Total execution time: 0.0426
DEBUG - 2022-06-17 02:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:35:33 --> Total execution time: 0.0328
DEBUG - 2022-06-17 02:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:36:03 --> Total execution time: 0.0553
DEBUG - 2022-06-17 02:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:36:13 --> Total execution time: 0.0685
DEBUG - 2022-06-17 02:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:36:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 02:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:36:14 --> Total execution time: 0.0489
DEBUG - 2022-06-17 02:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:37:01 --> Total execution time: 0.0391
DEBUG - 2022-06-17 02:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:37:02 --> Total execution time: 0.0566
DEBUG - 2022-06-17 02:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:37:08 --> Total execution time: 0.0801
DEBUG - 2022-06-17 02:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:13 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:37:13 --> Total execution time: 0.0409
DEBUG - 2022-06-17 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:37:18 --> Total execution time: 0.0481
DEBUG - 2022-06-17 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:37:46 --> Total execution time: 0.0449
DEBUG - 2022-06-17 02:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:07:51 --> Total execution time: 0.0515
DEBUG - 2022-06-17 02:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:07:52 --> Total execution time: 0.0537
DEBUG - 2022-06-17 02:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:07:52 --> Total execution time: 0.0716
DEBUG - 2022-06-17 02:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:08:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:38:32 --> Total execution time: 0.0948
DEBUG - 2022-06-17 02:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:08:39 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:38:39 --> Total execution time: 0.0416
DEBUG - 2022-06-17 02:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:30 --> Total execution time: 0.0429
DEBUG - 2022-06-17 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:30 --> Total execution time: 0.0497
DEBUG - 2022-06-17 02:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:31 --> Total execution time: 0.0437
DEBUG - 2022-06-17 02:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:46 --> Total execution time: 0.0667
DEBUG - 2022-06-17 02:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:48 --> Total execution time: 0.0446
DEBUG - 2022-06-17 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:10:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:50 --> Total execution time: 0.0352
DEBUG - 2022-06-17 02:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:11:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:41:52 --> Total execution time: 0.1063
DEBUG - 2022-06-17 02:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:42:28 --> Total execution time: 0.0629
DEBUG - 2022-06-17 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:42:31 --> Total execution time: 0.0410
DEBUG - 2022-06-17 02:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:42:34 --> Total execution time: 0.0420
DEBUG - 2022-06-17 02:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:42:45 --> Total execution time: 0.0440
DEBUG - 2022-06-17 02:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:42:52 --> Total execution time: 0.0681
DEBUG - 2022-06-17 02:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:43:10 --> Total execution time: 0.0425
DEBUG - 2022-06-17 02:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:13:16 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:43:16 --> Total execution time: 0.0405
DEBUG - 2022-06-17 02:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:43:18 --> Total execution time: 0.0442
DEBUG - 2022-06-17 02:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:43:21 --> Total execution time: 0.0412
DEBUG - 2022-06-17 02:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:44:17 --> Total execution time: 0.0717
DEBUG - 2022-06-17 02:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:15:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:45:18 --> Total execution time: 0.0918
DEBUG - 2022-06-17 02:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:45:28 --> Total execution time: 0.0406
DEBUG - 2022-06-17 02:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:45:58 --> Total execution time: 0.0731
DEBUG - 2022-06-17 02:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:16:10 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:46:10 --> Total execution time: 0.1081
DEBUG - 2022-06-17 02:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:46:22 --> Total execution time: 0.0736
DEBUG - 2022-06-17 02:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:30 --> Total execution time: 0.0537
DEBUG - 2022-06-17 02:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:37 --> Total execution time: 0.0879
DEBUG - 2022-06-17 02:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:38 --> Total execution time: 0.0541
DEBUG - 2022-06-17 02:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:38 --> Total execution time: 0.0744
DEBUG - 2022-06-17 02:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:40 --> Total execution time: 0.0551
DEBUG - 2022-06-17 02:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:45 --> Total execution time: 0.0334
DEBUG - 2022-06-17 02:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:45 --> Total execution time: 0.0616
DEBUG - 2022-06-17 02:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:52 --> Total execution time: 0.0498
DEBUG - 2022-06-17 02:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:54 --> Total execution time: 0.0514
DEBUG - 2022-06-17 02:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:47:57 --> Total execution time: 0.0606
DEBUG - 2022-06-17 02:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:48:03 --> Total execution time: 0.0648
DEBUG - 2022-06-17 02:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:48:21 --> Total execution time: 0.0513
DEBUG - 2022-06-17 02:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:48:31 --> Total execution time: 0.0707
DEBUG - 2022-06-17 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:48:38 --> Total execution time: 0.0457
DEBUG - 2022-06-17 02:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:18:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:48:41 --> Total execution time: 0.0422
DEBUG - 2022-06-17 02:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:49:00 --> Total execution time: 0.0772
DEBUG - 2022-06-17 02:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:49:04 --> Total execution time: 0.0529
DEBUG - 2022-06-17 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:49:06 --> Total execution time: 0.0419
DEBUG - 2022-06-17 02:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:49:16 --> Total execution time: 0.0477
DEBUG - 2022-06-17 02:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:20:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:50:45 --> Total execution time: 0.0542
DEBUG - 2022-06-17 02:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:51:14 --> Total execution time: 0.0503
DEBUG - 2022-06-17 02:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:23:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:53:55 --> Total execution time: 0.1451
DEBUG - 2022-06-17 02:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:54:13 --> Total execution time: 0.0424
DEBUG - 2022-06-17 02:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:24:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:54:59 --> Total execution time: 0.0424
DEBUG - 2022-06-17 02:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:55:02 --> Total execution time: 0.0457
DEBUG - 2022-06-17 02:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:55:39 --> Total execution time: 0.0402
DEBUG - 2022-06-17 02:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:55:39 --> Total execution time: 0.0491
DEBUG - 2022-06-17 02:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:55:43 --> Total execution time: 0.0520
DEBUG - 2022-06-17 02:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:55:51 --> Total execution time: 0.0616
DEBUG - 2022-06-17 02:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:56:00 --> Total execution time: 0.0790
DEBUG - 2022-06-17 02:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:56:09 --> Total execution time: 0.0414
DEBUG - 2022-06-17 02:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:56:41 --> Total execution time: 0.0433
DEBUG - 2022-06-17 02:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:57:10 --> Total execution time: 0.0439
DEBUG - 2022-06-17 02:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:57:20 --> Total execution time: 0.0707
DEBUG - 2022-06-17 02:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:57:25 --> Total execution time: 0.0563
DEBUG - 2022-06-17 02:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:57:40 --> Total execution time: 0.0619
DEBUG - 2022-06-17 02:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:28:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:58:07 --> Total execution time: 0.0522
DEBUG - 2022-06-17 02:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:59:24 --> Total execution time: 0.0867
DEBUG - 2022-06-17 02:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:29:35 --> Total execution time: 0.0409
DEBUG - 2022-06-17 02:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:29:36 --> Total execution time: 0.0437
DEBUG - 2022-06-17 02:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:29:36 --> Total execution time: 0.0960
DEBUG - 2022-06-17 02:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:59:43 --> Total execution time: 0.0375
DEBUG - 2022-06-17 02:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:00:16 --> Total execution time: 0.0404
DEBUG - 2022-06-17 02:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:00:45 --> Total execution time: 0.0275
DEBUG - 2022-06-17 02:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:00:45 --> Total execution time: 0.0519
DEBUG - 2022-06-17 02:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:01:02 --> Total execution time: 0.0471
DEBUG - 2022-06-17 02:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:01:10 --> Total execution time: 0.0457
DEBUG - 2022-06-17 02:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:01:10 --> Total execution time: 0.0388
DEBUG - 2022-06-17 02:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:01:13 --> Total execution time: 0.0517
DEBUG - 2022-06-17 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:01:14 --> Total execution time: 0.0381
DEBUG - 2022-06-17 02:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:31:15 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:01:15 --> Total execution time: 0.0414
DEBUG - 2022-06-17 02:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:32:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:02:41 --> Total execution time: 0.0452
DEBUG - 2022-06-17 02:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:03:02 --> Total execution time: 0.0288
DEBUG - 2022-06-17 02:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:03:55 --> Total execution time: 0.0487
DEBUG - 2022-06-17 02:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:03:59 --> Total execution time: 0.0623
DEBUG - 2022-06-17 02:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:24 --> Total execution time: 0.0624
DEBUG - 2022-06-17 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:25 --> Total execution time: 0.1272
DEBUG - 2022-06-17 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:33 --> Total execution time: 0.0441
DEBUG - 2022-06-17 02:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:39 --> Total execution time: 0.0615
DEBUG - 2022-06-17 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:45 --> Total execution time: 0.0546
DEBUG - 2022-06-17 02:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:46 --> Total execution time: 0.0802
DEBUG - 2022-06-17 02:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:04:55 --> Total execution time: 0.0574
DEBUG - 2022-06-17 02:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:05:12 --> Total execution time: 0.1192
DEBUG - 2022-06-17 02:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:06:14 --> Total execution time: 0.0428
DEBUG - 2022-06-17 02:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:36:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:06:35 --> Total execution time: 0.1086
DEBUG - 2022-06-17 02:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:07:07 --> Total execution time: 0.0667
DEBUG - 2022-06-17 02:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:37:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:07:25 --> Total execution time: 0.0471
DEBUG - 2022-06-17 02:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:08:00 --> Total execution time: 0.0394
DEBUG - 2022-06-17 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:08:05 --> Total execution time: 0.0391
DEBUG - 2022-06-17 02:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:08:39 --> Total execution time: 0.1095
DEBUG - 2022-06-17 02:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:38:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:08:53 --> Total execution time: 0.0544
DEBUG - 2022-06-17 02:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:39:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:09:25 --> Total execution time: 0.0494
DEBUG - 2022-06-17 02:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:09:28 --> Total execution time: 0.0526
DEBUG - 2022-06-17 02:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:11:04 --> Total execution time: 0.1134
DEBUG - 2022-06-17 02:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:11:06 --> Total execution time: 0.0564
DEBUG - 2022-06-17 02:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:11:54 --> Total execution time: 0.0395
DEBUG - 2022-06-17 02:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:11:59 --> Total execution time: 0.0447
DEBUG - 2022-06-17 02:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:08 --> Total execution time: 0.0577
DEBUG - 2022-06-17 02:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:10 --> Total execution time: 0.0509
DEBUG - 2022-06-17 02:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:17 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:17 --> Total execution time: 0.0983
DEBUG - 2022-06-17 02:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:23 --> Total execution time: 0.0573
DEBUG - 2022-06-17 02:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:32 --> Total execution time: 0.0438
DEBUG - 2022-06-17 02:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:42 --> Total execution time: 0.0699
DEBUG - 2022-06-17 02:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:43 --> Total execution time: 0.0970
DEBUG - 2022-06-17 02:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:44 --> Total execution time: 0.0558
DEBUG - 2022-06-17 02:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 02:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:46 --> Total execution time: 0.0541
DEBUG - 2022-06-17 02:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:42:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:50 --> Total execution time: 0.1102
DEBUG - 2022-06-17 02:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:00 --> Total execution time: 0.0780
DEBUG - 2022-06-17 02:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:08 --> Total execution time: 0.0549
DEBUG - 2022-06-17 02:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:23 --> Total execution time: 0.1176
DEBUG - 2022-06-17 02:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:28 --> Total execution time: 0.0531
DEBUG - 2022-06-17 02:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:38 --> Total execution time: 0.0419
DEBUG - 2022-06-17 13:13:38 --> Total execution time: 0.0465
DEBUG - 2022-06-17 02:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:39 --> Total execution time: 0.0375
DEBUG - 2022-06-17 02:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:42 --> Total execution time: 0.0493
DEBUG - 2022-06-17 02:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:49 --> Total execution time: 0.0626
DEBUG - 2022-06-17 02:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:53 --> Total execution time: 0.0500
DEBUG - 2022-06-17 02:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:54 --> Total execution time: 0.0482
DEBUG - 2022-06-17 02:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:55 --> Total execution time: 0.0480
DEBUG - 2022-06-17 02:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:55 --> Total execution time: 0.0393
DEBUG - 2022-06-17 02:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:12 --> Total execution time: 0.0480
DEBUG - 2022-06-17 02:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:43 --> Total execution time: 0.0442
DEBUG - 2022-06-17 02:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:45 --> Total execution time: 0.0450
DEBUG - 2022-06-17 02:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:47 --> Total execution time: 0.0558
DEBUG - 2022-06-17 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:49 --> Total execution time: 0.0620
DEBUG - 2022-06-17 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:49 --> Total execution time: 0.0419
DEBUG - 2022-06-17 02:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:53 --> Total execution time: 0.0576
DEBUG - 2022-06-17 02:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:54 --> Total execution time: 0.0518
DEBUG - 2022-06-17 02:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:44:55 --> Total execution time: 0.0647
DEBUG - 2022-06-17 02:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:57 --> Total execution time: 0.0417
DEBUG - 2022-06-17 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:15:01 --> Total execution time: 0.0400
DEBUG - 2022-06-17 02:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:27 --> Total execution time: 0.0821
DEBUG - 2022-06-17 02:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:15:27 --> Total execution time: 0.1334
DEBUG - 2022-06-17 02:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:15:34 --> Total execution time: 0.0804
DEBUG - 2022-06-17 02:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:35 --> Total execution time: 0.0435
DEBUG - 2022-06-17 02:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:45:44 --> Total execution time: 0.0420
DEBUG - 2022-06-17 02:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 02:45:59 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 02:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:01 --> Total execution time: 0.0380
DEBUG - 2022-06-17 02:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:08 --> Total execution time: 0.0974
DEBUG - 2022-06-17 02:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:13 --> Total execution time: 0.0594
DEBUG - 2022-06-17 02:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:15 --> Total execution time: 0.1021
DEBUG - 2022-06-17 02:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:23 --> Total execution time: 0.1479
DEBUG - 2022-06-17 02:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:30 --> Total execution time: 0.0433
DEBUG - 2022-06-17 02:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:38 --> Total execution time: 0.0474
DEBUG - 2022-06-17 02:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:46 --> Total execution time: 0.0671
DEBUG - 2022-06-17 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:48 --> Total execution time: 0.0511
DEBUG - 2022-06-17 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:48 --> Total execution time: 0.0431
DEBUG - 2022-06-17 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:49 --> Total execution time: 0.0459
DEBUG - 2022-06-17 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:49 --> Total execution time: 0.0528
DEBUG - 2022-06-17 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:49 --> Total execution time: 0.0578
DEBUG - 2022-06-17 02:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:53 --> Total execution time: 0.0374
DEBUG - 2022-06-17 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:16:54 --> Total execution time: 0.0437
DEBUG - 2022-06-17 02:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:55 --> Total execution time: 0.0883
DEBUG - 2022-06-17 02:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:58 --> Total execution time: 0.0474
DEBUG - 2022-06-17 02:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:46:58 --> Total execution time: 0.0439
DEBUG - 2022-06-17 02:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:00 --> Total execution time: 0.0557
DEBUG - 2022-06-17 02:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:01 --> Total execution time: 0.0957
DEBUG - 2022-06-17 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:01 --> Total execution time: 0.0591
DEBUG - 2022-06-17 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:08 --> Total execution time: 0.0842
DEBUG - 2022-06-17 02:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:14 --> Total execution time: 0.0306
DEBUG - 2022-06-17 02:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:16 --> Total execution time: 0.0702
DEBUG - 2022-06-17 02:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:34 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:34 --> Total execution time: 0.0467
DEBUG - 2022-06-17 02:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:49 --> Total execution time: 0.0311
DEBUG - 2022-06-17 02:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:54 --> Total execution time: 0.0527
DEBUG - 2022-06-17 02:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 02:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:17:59 --> Total execution time: 0.0746
DEBUG - 2022-06-17 02:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:18:04 --> Total execution time: 0.0436
DEBUG - 2022-06-17 02:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:18:04 --> Total execution time: 0.0405
DEBUG - 2022-06-17 02:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:18:14 --> Total execution time: 0.0931
DEBUG - 2022-06-17 02:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 02:48:24 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:18:50 --> Total execution time: 0.0470
DEBUG - 2022-06-17 02:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:18:55 --> Total execution time: 0.0506
DEBUG - 2022-06-17 02:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:18:57 --> Total execution time: 0.0537
DEBUG - 2022-06-17 02:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:19:01 --> Total execution time: 0.0475
DEBUG - 2022-06-17 02:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:19:08 --> Total execution time: 0.0476
DEBUG - 2022-06-17 02:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 02:50:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 02:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:21:11 --> Total execution time: 0.0291
DEBUG - 2022-06-17 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:54:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:24:26 --> Total execution time: 0.1128
DEBUG - 2022-06-17 02:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:55:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:25:01 --> Total execution time: 0.0421
DEBUG - 2022-06-17 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:55:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:25:43 --> Total execution time: 0.0390
DEBUG - 2022-06-17 02:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:26:12 --> Total execution time: 0.0998
DEBUG - 2022-06-17 02:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:26:12 --> Total execution time: 0.0439
DEBUG - 2022-06-17 02:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:10 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:10 --> Total execution time: 0.0551
DEBUG - 2022-06-17 02:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:18 --> Total execution time: 0.0455
DEBUG - 2022-06-17 02:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:23 --> Total execution time: 0.0409
DEBUG - 2022-06-17 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:32 --> Total execution time: 0.0574
DEBUG - 2022-06-17 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:33 --> Total execution time: 0.0398
DEBUG - 2022-06-17 02:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:37 --> Total execution time: 0.0453
DEBUG - 2022-06-17 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:41 --> Total execution time: 0.0406
DEBUG - 2022-06-17 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:49 --> Total execution time: 0.0635
DEBUG - 2022-06-17 02:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 02:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:50 --> Total execution time: 0.0377
DEBUG - 2022-06-17 02:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:27:58 --> Total execution time: 0.0471
DEBUG - 2022-06-17 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:28:09 --> Total execution time: 0.0705
DEBUG - 2022-06-17 02:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 02:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 02:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:28:17 --> Total execution time: 0.0465
DEBUG - 2022-06-17 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:30:03 --> Total execution time: 0.1089
DEBUG - 2022-06-17 03:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:35:36 --> Total execution time: 0.0674
DEBUG - 2022-06-17 03:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:35:45 --> Total execution time: 0.0520
DEBUG - 2022-06-17 03:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:36:00 --> Total execution time: 0.0495
DEBUG - 2022-06-17 03:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:36:21 --> Total execution time: 0.0660
DEBUG - 2022-06-17 03:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:40:37 --> Total execution time: 0.1087
DEBUG - 2022-06-17 03:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:40:40 --> Total execution time: 0.0378
DEBUG - 2022-06-17 03:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:40:44 --> Total execution time: 0.0440
DEBUG - 2022-06-17 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:40:52 --> Total execution time: 0.0416
DEBUG - 2022-06-17 03:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:02 --> Total execution time: 0.0781
DEBUG - 2022-06-17 03:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 03:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:03 --> Total execution time: 0.0394
DEBUG - 2022-06-17 03:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:51 --> Total execution time: 0.0407
DEBUG - 2022-06-17 03:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:52 --> Total execution time: 0.0548
DEBUG - 2022-06-17 03:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 03:13:01 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 03:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:43:45 --> Total execution time: 0.1147
DEBUG - 2022-06-17 03:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:44:58 --> Total execution time: 0.1107
DEBUG - 2022-06-17 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:30 --> Total execution time: 0.0628
DEBUG - 2022-06-17 03:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:47 --> Total execution time: 0.0553
DEBUG - 2022-06-17 03:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:47:44 --> Total execution time: 0.1644
DEBUG - 2022-06-17 03:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:05 --> Total execution time: 0.0906
DEBUG - 2022-06-17 03:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:51 --> Total execution time: 0.0671
DEBUG - 2022-06-17 03:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:53:04 --> Total execution time: 0.0510
DEBUG - 2022-06-17 03:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:53:25 --> Total execution time: 0.0460
DEBUG - 2022-06-17 03:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:14 --> Total execution time: 0.2393
DEBUG - 2022-06-17 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:26:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:19 --> Total execution time: 0.0563
DEBUG - 2022-06-17 03:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:25 --> Total execution time: 0.0535
DEBUG - 2022-06-17 03:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:43 --> Total execution time: 0.0955
DEBUG - 2022-06-17 03:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:30:47 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:00:47 --> Total execution time: 0.0393
DEBUG - 2022-06-17 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:30:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:00:52 --> Total execution time: 0.0343
DEBUG - 2022-06-17 03:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 03:34:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 03:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:07:18 --> Total execution time: 0.1683
DEBUG - 2022-06-17 03:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:40:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:10:50 --> Total execution time: 0.1595
DEBUG - 2022-06-17 03:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:03 --> Total execution time: 0.0567
DEBUG - 2022-06-17 03:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:04 --> Total execution time: 0.1348
DEBUG - 2022-06-17 03:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:13 --> Total execution time: 0.0488
DEBUG - 2022-06-17 03:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:15 --> Total execution time: 0.0396
DEBUG - 2022-06-17 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:22 --> Total execution time: 0.0391
DEBUG - 2022-06-17 03:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:27 --> Total execution time: 0.0508
DEBUG - 2022-06-17 03:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:31 --> Total execution time: 0.0791
DEBUG - 2022-06-17 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:00 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:00 --> Total execution time: 0.0615
DEBUG - 2022-06-17 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 03:42:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 03:42:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 03:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:03 --> Total execution time: 0.0472
DEBUG - 2022-06-17 03:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 03:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:04 --> Total execution time: 0.0459
DEBUG - 2022-06-17 03:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:27 --> Total execution time: 0.0413
DEBUG - 2022-06-17 03:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:28 --> Total execution time: 0.0386
DEBUG - 2022-06-17 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:40 --> Total execution time: 0.0728
DEBUG - 2022-06-17 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:42 --> Total execution time: 0.0922
DEBUG - 2022-06-17 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:43 --> Total execution time: 0.0536
DEBUG - 2022-06-17 03:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:55 --> Total execution time: 0.0464
DEBUG - 2022-06-17 03:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:01 --> Total execution time: 0.0544
DEBUG - 2022-06-17 03:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:40 --> Total execution time: 0.0497
DEBUG - 2022-06-17 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:52 --> Total execution time: 0.0558
DEBUG - 2022-06-17 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:52 --> Total execution time: 0.0876
DEBUG - 2022-06-17 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:52 --> Total execution time: 0.0866
DEBUG - 2022-06-17 03:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:53 --> Total execution time: 0.0883
DEBUG - 2022-06-17 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:56 --> Total execution time: 0.0533
DEBUG - 2022-06-17 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:57 --> Total execution time: 0.0759
DEBUG - 2022-06-17 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:57 --> Total execution time: 0.0556
DEBUG - 2022-06-17 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:57 --> Total execution time: 0.0452
DEBUG - 2022-06-17 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:57 --> Total execution time: 0.0655
DEBUG - 2022-06-17 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:57 --> Total execution time: 0.0471
DEBUG - 2022-06-17 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:57 --> Total execution time: 0.0740
DEBUG - 2022-06-17 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:58 --> Total execution time: 0.1599
DEBUG - 2022-06-17 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:58 --> Total execution time: 0.0941
DEBUG - 2022-06-17 03:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:07 --> Total execution time: 0.0593
DEBUG - 2022-06-17 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:07 --> Total execution time: 0.0507
DEBUG - 2022-06-17 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:12 --> Total execution time: 0.0537
DEBUG - 2022-06-17 03:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:13 --> Total execution time: 0.0622
DEBUG - 2022-06-17 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:25 --> Total execution time: 0.0665
DEBUG - 2022-06-17 03:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:40 --> Total execution time: 0.0542
DEBUG - 2022-06-17 03:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:42 --> Total execution time: 0.0502
DEBUG - 2022-06-17 03:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:42 --> Total execution time: 0.0590
DEBUG - 2022-06-17 03:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:43 --> Total execution time: 0.0458
DEBUG - 2022-06-17 03:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:14:43 --> Total execution time: 0.0543
DEBUG - 2022-06-17 03:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:17:21 --> Total execution time: 0.0672
DEBUG - 2022-06-17 03:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:17:44 --> Total execution time: 0.0455
DEBUG - 2022-06-17 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:17:52 --> Total execution time: 0.0733
DEBUG - 2022-06-17 03:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:19:44 --> Total execution time: 0.0443
DEBUG - 2022-06-17 03:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 03:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:20:43 --> Total execution time: 0.0482
DEBUG - 2022-06-17 03:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:20:50 --> Total execution time: 0.0442
DEBUG - 2022-06-17 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:21:16 --> Total execution time: 0.0503
DEBUG - 2022-06-17 03:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:52:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:22:19 --> Total execution time: 0.0688
DEBUG - 2022-06-17 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:52:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:22:54 --> Total execution time: 0.0341
DEBUG - 2022-06-17 03:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:25:05 --> Total execution time: 0.2249
DEBUG - 2022-06-17 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:26:18 --> Total execution time: 0.0331
DEBUG - 2022-06-17 03:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:27:23 --> Total execution time: 0.1015
DEBUG - 2022-06-17 03:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:27:36 --> Total execution time: 0.0472
DEBUG - 2022-06-17 03:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 03:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 03:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:29:44 --> Total execution time: 0.0887
DEBUG - 2022-06-17 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:30:03 --> Total execution time: 0.0758
DEBUG - 2022-06-17 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:00:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:30:30 --> Total execution time: 0.0431
DEBUG - 2022-06-17 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:30:37 --> Total execution time: 0.0688
DEBUG - 2022-06-17 04:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:01:16 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:31:16 --> Total execution time: 0.0489
DEBUG - 2022-06-17 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:31:25 --> Total execution time: 0.0428
DEBUG - 2022-06-17 04:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:31:42 --> Total execution time: 0.0402
DEBUG - 2022-06-17 04:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:32:00 --> Total execution time: 0.0744
DEBUG - 2022-06-17 04:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:32:10 --> Total execution time: 0.0490
DEBUG - 2022-06-17 04:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:32:34 --> Total execution time: 0.0439
DEBUG - 2022-06-17 04:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:32:41 --> Total execution time: 0.0628
DEBUG - 2022-06-17 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:32:49 --> Total execution time: 0.0524
DEBUG - 2022-06-17 04:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:32:59 --> Total execution time: 0.0547
DEBUG - 2022-06-17 04:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:33:44 --> Total execution time: 0.0492
DEBUG - 2022-06-17 04:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:33:46 --> Total execution time: 0.0507
DEBUG - 2022-06-17 04:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:33:55 --> Total execution time: 0.0472
DEBUG - 2022-06-17 04:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:33:57 --> Total execution time: 0.0440
DEBUG - 2022-06-17 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:34:00 --> Total execution time: 0.0499
DEBUG - 2022-06-17 04:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:04:34 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:34:35 --> Total execution time: 0.0338
DEBUG - 2022-06-17 04:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:34:36 --> Total execution time: 0.0475
DEBUG - 2022-06-17 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:34:38 --> Total execution time: 0.0372
DEBUG - 2022-06-17 04:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:05:08 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-17 04:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:05:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:05:11 --> 404 Page Not Found: Lp-profile/courses
DEBUG - 2022-06-17 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:05:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:35:12 --> Total execution time: 0.0440
DEBUG - 2022-06-17 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:35:30 --> Total execution time: 0.1029
DEBUG - 2022-06-17 04:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:05:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:35:41 --> Total execution time: 0.0639
DEBUG - 2022-06-17 04:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:36:07 --> Total execution time: 0.0572
DEBUG - 2022-06-17 04:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:09:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:39:12 --> Total execution time: 0.0866
DEBUG - 2022-06-17 04:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:09:15 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:39:15 --> Total execution time: 0.0714
DEBUG - 2022-06-17 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:09:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:39:20 --> Total execution time: 0.0464
DEBUG - 2022-06-17 04:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:09:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:39:46 --> Total execution time: 0.0527
DEBUG - 2022-06-17 04:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:39:48 --> Total execution time: 1.9524
DEBUG - 2022-06-17 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:09:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:09:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:10:13 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:40:13 --> Total execution time: 0.0417
DEBUG - 2022-06-17 04:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:40:22 --> Total execution time: 0.0430
DEBUG - 2022-06-17 04:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:40:23 --> Total execution time: 0.0707
DEBUG - 2022-06-17 04:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:10:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:40:28 --> Total execution time: 0.0561
DEBUG - 2022-06-17 04:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:11:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:41:48 --> Total execution time: 0.0475
DEBUG - 2022-06-17 04:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:11:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:41:56 --> Total execution time: 0.0732
DEBUG - 2022-06-17 04:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:45:10 --> Total execution time: 0.1299
DEBUG - 2022-06-17 04:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:16:26 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-17 04:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:17:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:47:48 --> Total execution time: 0.0433
DEBUG - 2022-06-17 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:47:55 --> Total execution time: 0.0320
DEBUG - 2022-06-17 04:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:48:00 --> Total execution time: 0.0443
DEBUG - 2022-06-17 04:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:48:05 --> Total execution time: 0.0538
DEBUG - 2022-06-17 04:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:48:16 --> Total execution time: 0.1248
DEBUG - 2022-06-17 04:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:04 --> Total execution time: 0.0981
DEBUG - 2022-06-17 04:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:13 --> Total execution time: 0.0379
DEBUG - 2022-06-17 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:16 --> Total execution time: 0.0603
DEBUG - 2022-06-17 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:16 --> Total execution time: 0.0485
DEBUG - 2022-06-17 04:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:18 --> Total execution time: 0.0469
DEBUG - 2022-06-17 04:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:23 --> Total execution time: 0.0668
DEBUG - 2022-06-17 04:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:25 --> Total execution time: 0.0936
DEBUG - 2022-06-17 04:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:33 --> Total execution time: 0.0373
DEBUG - 2022-06-17 04:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:42 --> Total execution time: 0.0383
DEBUG - 2022-06-17 04:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:43 --> Total execution time: 0.0475
DEBUG - 2022-06-17 04:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:45 --> Total execution time: 0.0459
DEBUG - 2022-06-17 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:49 --> Total execution time: 0.0383
DEBUG - 2022-06-17 04:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:52 --> Total execution time: 0.0468
DEBUG - 2022-06-17 04:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:49:59 --> Total execution time: 0.0423
DEBUG - 2022-06-17 04:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:50:24 --> Total execution time: 0.0498
DEBUG - 2022-06-17 04:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:50:32 --> Total execution time: 0.0449
DEBUG - 2022-06-17 04:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:21:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:51:28 --> Total execution time: 0.0907
DEBUG - 2022-06-17 04:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:21:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:51:59 --> Total execution time: 0.0334
DEBUG - 2022-06-17 04:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:03 --> Total execution time: 0.0515
DEBUG - 2022-06-17 04:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:10 --> Total execution time: 0.0577
DEBUG - 2022-06-17 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:14 --> Total execution time: 0.0550
DEBUG - 2022-06-17 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:22:14 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:15 --> Total execution time: 0.0573
DEBUG - 2022-06-17 04:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:21 --> Total execution time: 0.0514
DEBUG - 2022-06-17 04:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:23 --> Total execution time: 0.0377
DEBUG - 2022-06-17 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:52:28 --> Total execution time: 0.0389
DEBUG - 2022-06-17 04:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:23:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:23:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:23:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:24:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:24:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:24:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:24:08 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:24:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:24:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:24:42 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 04:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:55:04 --> Total execution time: 0.1029
DEBUG - 2022-06-17 04:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:55:52 --> Total execution time: 0.0951
DEBUG - 2022-06-17 04:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:56:16 --> Total execution time: 0.0746
DEBUG - 2022-06-17 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:56:23 --> Total execution time: 0.0490
DEBUG - 2022-06-17 04:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:56:31 --> Total execution time: 0.0474
DEBUG - 2022-06-17 04:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:56:41 --> Total execution time: 0.0383
DEBUG - 2022-06-17 04:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:26:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:26:47 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 04:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:27:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:57:33 --> Total execution time: 0.0559
DEBUG - 2022-06-17 04:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:27:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:57:52 --> Total execution time: 0.1102
DEBUG - 2022-06-17 04:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:57:58 --> Total execution time: 0.0503
DEBUG - 2022-06-17 04:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:04 --> Total execution time: 0.0469
DEBUG - 2022-06-17 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:07 --> Total execution time: 0.0454
DEBUG - 2022-06-17 04:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:21 --> Total execution time: 0.0521
DEBUG - 2022-06-17 04:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:41 --> Total execution time: 0.1382
DEBUG - 2022-06-17 04:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:41 --> Total execution time: 0.1844
DEBUG - 2022-06-17 04:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:41 --> Total execution time: 0.1427
DEBUG - 2022-06-17 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:44 --> Total execution time: 0.1068
DEBUG - 2022-06-17 04:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:50 --> Total execution time: 0.0513
DEBUG - 2022-06-17 04:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:58:57 --> Total execution time: 0.1107
DEBUG - 2022-06-17 04:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:03 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:03 --> Total execution time: 0.0531
DEBUG - 2022-06-17 04:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:06 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:06 --> Total execution time: 0.0614
DEBUG - 2022-06-17 04:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:29:11 --> Total execution time: 0.0438
DEBUG - 2022-06-17 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:29:13 --> Total execution time: 0.0435
DEBUG - 2022-06-17 04:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:29:13 --> Total execution time: 0.0938
DEBUG - 2022-06-17 04:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:15 --> Total execution time: 0.0467
DEBUG - 2022-06-17 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:19 --> Total execution time: 0.0524
DEBUG - 2022-06-17 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:20 --> Total execution time: 0.0311
DEBUG - 2022-06-17 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:23 --> Total execution time: 0.0468
DEBUG - 2022-06-17 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:28 --> Total execution time: 0.0661
DEBUG - 2022-06-17 04:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:31 --> Total execution time: 0.0531
DEBUG - 2022-06-17 04:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:33 --> Total execution time: 0.0382
DEBUG - 2022-06-17 04:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:29:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:59:44 --> Total execution time: 0.0414
DEBUG - 2022-06-17 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:32:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:02:32 --> Total execution time: 0.1464
DEBUG - 2022-06-17 04:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:02:59 --> Total execution time: 0.0402
DEBUG - 2022-06-17 04:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:03:35 --> Total execution time: 0.0564
DEBUG - 2022-06-17 04:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:03:40 --> Total execution time: 0.0434
DEBUG - 2022-06-17 04:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:03:42 --> Total execution time: 0.0441
DEBUG - 2022-06-17 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:03:45 --> Total execution time: 0.0802
DEBUG - 2022-06-17 04:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:37:42 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-17 04:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:37:46 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 04:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:37:50 --> 404 Page Not Found: Wp-admin/index
DEBUG - 2022-06-17 04:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:37:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:37:57 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:37:59 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:38:31 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:38:41 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:01 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:03 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:09 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:20 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:22 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:26 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:39:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:40:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:40:11 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:40:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 04:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:14:55 --> Total execution time: 0.1767
DEBUG - 2022-06-17 04:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:14:58 --> Total execution time: 0.0667
DEBUG - 2022-06-17 04:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:14:59 --> Total execution time: 0.0529
DEBUG - 2022-06-17 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:48:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:18:37 --> Total execution time: 0.1488
DEBUG - 2022-06-17 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:18:40 --> Total execution time: 0.0392
DEBUG - 2022-06-17 04:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:48:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:18:46 --> Total execution time: 0.0475
DEBUG - 2022-06-17 04:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:48:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:18:46 --> Total execution time: 0.0377
DEBUG - 2022-06-17 04:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:48:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 04:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:49:32 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:55:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 04:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 04:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:25:19 --> Total execution time: 0.1050
DEBUG - 2022-06-17 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 04:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 04:55:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:30:03 --> Total execution time: 0.1869
DEBUG - 2022-06-17 05:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:02:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:32:18 --> Total execution time: 0.1148
DEBUG - 2022-06-17 05:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:02:25 --> Total execution time: 0.0494
DEBUG - 2022-06-17 05:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:02:35 --> Total execution time: 0.0394
DEBUG - 2022-06-17 05:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:02:35 --> Total execution time: 0.1441
DEBUG - 2022-06-17 05:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:02:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:32:46 --> Total execution time: 0.0474
DEBUG - 2022-06-17 05:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:37:03 --> Total execution time: 0.0393
DEBUG - 2022-06-17 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:07:22 --> Total execution time: 0.0483
DEBUG - 2022-06-17 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:37:28 --> Total execution time: 0.0507
DEBUG - 2022-06-17 05:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:37:34 --> Total execution time: 0.0897
DEBUG - 2022-06-17 05:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:37:36 --> Total execution time: 0.1172
DEBUG - 2022-06-17 05:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:37:44 --> Total execution time: 0.0438
DEBUG - 2022-06-17 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:21 --> Total execution time: 0.1029
DEBUG - 2022-06-17 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:21 --> Total execution time: 0.0471
DEBUG - 2022-06-17 05:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:25 --> Total execution time: 0.0317
DEBUG - 2022-06-17 05:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:27 --> Total execution time: 0.0507
DEBUG - 2022-06-17 05:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:31 --> Total execution time: 0.0561
DEBUG - 2022-06-17 05:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:46 --> Total execution time: 0.0388
DEBUG - 2022-06-17 05:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:40:47 --> Total execution time: 0.0451
DEBUG - 2022-06-17 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:41:02 --> Total execution time: 0.0445
DEBUG - 2022-06-17 05:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:41:18 --> Total execution time: 0.0643
DEBUG - 2022-06-17 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:41:22 --> Total execution time: 0.0652
DEBUG - 2022-06-17 05:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:41:24 --> Total execution time: 0.0621
DEBUG - 2022-06-17 05:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:41:29 --> Total execution time: 0.0678
DEBUG - 2022-06-17 05:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:41:50 --> Total execution time: 0.0411
DEBUG - 2022-06-17 05:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:43:15 --> Total execution time: 0.0823
DEBUG - 2022-06-17 05:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:44:17 --> Total execution time: 0.0679
DEBUG - 2022-06-17 05:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:44:21 --> Total execution time: 0.1337
DEBUG - 2022-06-17 05:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:44:33 --> Total execution time: 0.0746
DEBUG - 2022-06-17 05:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:44:55 --> Total execution time: 0.0607
DEBUG - 2022-06-17 05:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:45:03 --> Total execution time: 0.0863
DEBUG - 2022-06-17 05:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:15:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:45:51 --> Total execution time: 0.0404
DEBUG - 2022-06-17 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:16:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:46:27 --> Total execution time: 0.0306
DEBUG - 2022-06-17 05:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:46:46 --> Total execution time: 0.0409
DEBUG - 2022-06-17 05:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:10 --> Total execution time: 0.0420
DEBUG - 2022-06-17 05:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:35 --> Total execution time: 0.0672
DEBUG - 2022-06-17 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:43 --> Total execution time: 0.0727
DEBUG - 2022-06-17 05:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:59 --> Total execution time: 0.0466
DEBUG - 2022-06-17 05:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:50:14 --> Total execution time: 0.0428
DEBUG - 2022-06-17 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:50:33 --> Total execution time: 0.0441
DEBUG - 2022-06-17 05:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:50:48 --> Total execution time: 0.0910
DEBUG - 2022-06-17 05:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:50:59 --> Total execution time: 0.0875
DEBUG - 2022-06-17 05:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:51:04 --> Total execution time: 0.0928
DEBUG - 2022-06-17 05:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:51:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 05:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:51:30 --> Total execution time: 0.0709
DEBUG - 2022-06-17 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:51:45 --> Total execution time: 0.0467
DEBUG - 2022-06-17 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:51:49 --> Total execution time: 0.0391
DEBUG - 2022-06-17 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:52:00 --> Total execution time: 0.0469
DEBUG - 2022-06-17 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:52:00 --> Total execution time: 0.0467
DEBUG - 2022-06-17 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:52:15 --> Total execution time: 0.0677
DEBUG - 2022-06-17 05:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:52:41 --> Total execution time: 0.0458
DEBUG - 2022-06-17 05:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:52:47 --> Total execution time: 0.0881
DEBUG - 2022-06-17 05:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:53:23 --> Total execution time: 0.0814
DEBUG - 2022-06-17 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:53:34 --> Total execution time: 0.0510
DEBUG - 2022-06-17 05:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:53:51 --> Total execution time: 0.0456
DEBUG - 2022-06-17 05:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:53:57 --> Total execution time: 0.0709
DEBUG - 2022-06-17 05:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:54:03 --> Total execution time: 0.0729
DEBUG - 2022-06-17 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:54:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:54:23 --> Total execution time: 0.0764
DEBUG - 2022-06-17 05:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:54:43 --> Total execution time: 0.0455
DEBUG - 2022-06-17 05:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:01 --> Total execution time: 0.0835
DEBUG - 2022-06-17 05:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:05 --> Total execution time: 0.0771
DEBUG - 2022-06-17 05:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:09 --> Total execution time: 0.0712
DEBUG - 2022-06-17 05:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:55:10 --> Total execution time: 0.1177
DEBUG - 2022-06-17 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:10 --> Total execution time: 0.0677
DEBUG - 2022-06-17 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:10 --> Total execution time: 0.0826
DEBUG - 2022-06-17 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:10 --> Total execution time: 0.0496
DEBUG - 2022-06-17 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:10 --> Total execution time: 0.0539
DEBUG - 2022-06-17 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:11 --> Total execution time: 0.0758
DEBUG - 2022-06-17 05:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:17 --> Total execution time: 0.0892
DEBUG - 2022-06-17 05:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:27 --> Total execution time: 0.0563
DEBUG - 2022-06-17 05:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:34 --> Total execution time: 0.0564
DEBUG - 2022-06-17 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:39 --> Total execution time: 0.0353
DEBUG - 2022-06-17 05:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:45 --> Total execution time: 0.0508
DEBUG - 2022-06-17 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:55:52 --> Total execution time: 0.0362
DEBUG - 2022-06-17 05:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:56:00 --> Total execution time: 0.0432
DEBUG - 2022-06-17 05:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:56:05 --> Total execution time: 0.0413
DEBUG - 2022-06-17 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:56:05 --> Total execution time: 0.0376
DEBUG - 2022-06-17 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:56:21 --> Total execution time: 0.0579
DEBUG - 2022-06-17 05:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:56:22 --> Total execution time: 0.0424
DEBUG - 2022-06-17 05:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:56:52 --> Total execution time: 0.0642
DEBUG - 2022-06-17 05:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:57:03 --> Total execution time: 0.0480
DEBUG - 2022-06-17 05:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:57:08 --> Total execution time: 0.0699
DEBUG - 2022-06-17 05:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:57:10 --> Total execution time: 0.0456
DEBUG - 2022-06-17 05:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:57:32 --> Total execution time: 0.0590
DEBUG - 2022-06-17 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:57:42 --> Total execution time: 0.0746
DEBUG - 2022-06-17 05:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:57:52 --> Total execution time: 0.0539
DEBUG - 2022-06-17 05:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:58:06 --> Total execution time: 0.0455
DEBUG - 2022-06-17 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:58:15 --> Total execution time: 0.0507
DEBUG - 2022-06-17 05:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:58:45 --> Total execution time: 0.0386
DEBUG - 2022-06-17 05:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:28 --> Total execution time: 0.0501
DEBUG - 2022-06-17 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:05:37 --> Total execution time: 0.0429
DEBUG - 2022-06-17 05:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:05:41 --> Total execution time: 0.0549
DEBUG - 2022-06-17 05:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:05:48 --> Total execution time: 0.0484
DEBUG - 2022-06-17 05:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:00 --> Total execution time: 0.0579
DEBUG - 2022-06-17 05:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:36:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:44 --> Total execution time: 0.0358
DEBUG - 2022-06-17 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:36:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:47 --> Total execution time: 0.0921
DEBUG - 2022-06-17 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:07:25 --> Total execution time: 2.1560
DEBUG - 2022-06-17 05:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 05:37:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:10:14 --> Total execution time: 0.0411
DEBUG - 2022-06-17 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:10:32 --> Total execution time: 0.0272
DEBUG - 2022-06-17 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:02 --> Total execution time: 0.0424
DEBUG - 2022-06-17 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:05 --> Total execution time: 0.0279
DEBUG - 2022-06-17 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:13 --> Total execution time: 0.0528
DEBUG - 2022-06-17 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:16 --> Total execution time: 0.0673
DEBUG - 2022-06-17 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:16 --> Total execution time: 0.0374
DEBUG - 2022-06-17 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:30 --> Total execution time: 0.0681
DEBUG - 2022-06-17 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:35 --> Total execution time: 0.0397
DEBUG - 2022-06-17 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:40 --> Total execution time: 0.0379
DEBUG - 2022-06-17 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:47 --> Total execution time: 0.0458
DEBUG - 2022-06-17 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:49 --> Total execution time: 0.0399
DEBUG - 2022-06-17 05:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:51 --> Total execution time: 0.0453
DEBUG - 2022-06-17 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:54 --> Total execution time: 0.0484
DEBUG - 2022-06-17 05:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:11:59 --> Total execution time: 0.0304
DEBUG - 2022-06-17 05:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:41:59 --> Total execution time: 0.0390
DEBUG - 2022-06-17 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:02 --> Total execution time: 0.0697
DEBUG - 2022-06-17 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:42:03 --> Total execution time: 0.0479
DEBUG - 2022-06-17 05:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:42:12 --> Total execution time: 0.0379
DEBUG - 2022-06-17 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:42:14 --> Total execution time: 0.0411
DEBUG - 2022-06-17 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:16 --> Total execution time: 0.0715
DEBUG - 2022-06-17 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:23 --> Total execution time: 0.0460
DEBUG - 2022-06-17 05:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:28 --> Total execution time: 0.0452
DEBUG - 2022-06-17 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:32 --> Total execution time: 0.0417
DEBUG - 2022-06-17 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:37 --> Total execution time: 0.0450
DEBUG - 2022-06-17 05:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:40 --> Total execution time: 0.0494
DEBUG - 2022-06-17 05:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:49 --> Total execution time: 0.0630
DEBUG - 2022-06-17 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:12:50 --> Total execution time: 0.0476
DEBUG - 2022-06-17 05:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:03 --> Total execution time: 0.0441
DEBUG - 2022-06-17 05:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:10 --> Total execution time: 0.0395
DEBUG - 2022-06-17 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:20 --> Total execution time: 0.0423
DEBUG - 2022-06-17 05:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:23 --> Total execution time: 0.0460
DEBUG - 2022-06-17 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:31 --> Total execution time: 0.0434
DEBUG - 2022-06-17 05:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:35 --> Total execution time: 0.0411
DEBUG - 2022-06-17 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:38 --> Total execution time: 0.0492
DEBUG - 2022-06-17 05:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:43 --> Total execution time: 0.0577
DEBUG - 2022-06-17 05:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:52 --> Total execution time: 0.0429
DEBUG - 2022-06-17 05:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:13:57 --> Total execution time: 0.0616
DEBUG - 2022-06-17 05:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:01 --> Total execution time: 0.0571
DEBUG - 2022-06-17 05:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:03 --> Total execution time: 0.0420
DEBUG - 2022-06-17 05:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:14 --> Total execution time: 0.0446
DEBUG - 2022-06-17 05:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:16 --> Total execution time: 0.0797
DEBUG - 2022-06-17 05:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:23 --> Total execution time: 0.0480
DEBUG - 2022-06-17 05:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:23 --> Total execution time: 0.0429
DEBUG - 2022-06-17 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:30 --> Total execution time: 0.0408
DEBUG - 2022-06-17 05:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:30 --> Total execution time: 0.0523
DEBUG - 2022-06-17 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:35 --> Total execution time: 0.0516
DEBUG - 2022-06-17 05:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:39 --> Total execution time: 0.0968
DEBUG - 2022-06-17 05:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:39 --> Total execution time: 0.0456
DEBUG - 2022-06-17 05:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:14:45 --> Total execution time: 0.0613
DEBUG - 2022-06-17 05:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:15:37 --> Total execution time: 0.0598
DEBUG - 2022-06-17 05:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:15:38 --> Total execution time: 0.0576
DEBUG - 2022-06-17 05:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:15:51 --> Total execution time: 0.0647
DEBUG - 2022-06-17 05:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:15:52 --> Total execution time: 0.0980
DEBUG - 2022-06-17 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:15:57 --> Total execution time: 0.0466
DEBUG - 2022-06-17 05:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:16:07 --> Total execution time: 0.0704
DEBUG - 2022-06-17 05:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:16:47 --> Total execution time: 0.0875
DEBUG - 2022-06-17 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:17:00 --> Total execution time: 0.0774
DEBUG - 2022-06-17 05:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:17:22 --> Total execution time: 0.0684
DEBUG - 2022-06-17 05:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:17:27 --> Total execution time: 0.0491
DEBUG - 2022-06-17 05:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:17:39 --> Total execution time: 0.0484
DEBUG - 2022-06-17 05:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:17:59 --> Total execution time: 0.0979
DEBUG - 2022-06-17 05:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:18:01 --> Total execution time: 0.1182
DEBUG - 2022-06-17 05:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:18:08 --> Total execution time: 0.1432
DEBUG - 2022-06-17 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:18:16 --> Total execution time: 0.0653
DEBUG - 2022-06-17 05:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:18:21 --> Total execution time: 0.0647
DEBUG - 2022-06-17 05:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:18:29 --> Total execution time: 0.0597
DEBUG - 2022-06-17 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:18:31 --> Total execution time: 0.0490
DEBUG - 2022-06-17 05:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:19:42 --> Total execution time: 0.1016
DEBUG - 2022-06-17 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:19:47 --> Total execution time: 0.0513
DEBUG - 2022-06-17 05:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:19:51 --> Total execution time: 0.0463
DEBUG - 2022-06-17 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:08 --> Total execution time: 0.0595
DEBUG - 2022-06-17 05:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:12 --> Total execution time: 0.0539
DEBUG - 2022-06-17 05:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:22 --> Total execution time: 0.1031
DEBUG - 2022-06-17 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:26 --> Total execution time: 0.0701
DEBUG - 2022-06-17 05:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:29 --> Total execution time: 0.0773
DEBUG - 2022-06-17 05:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:32 --> Total execution time: 0.0530
DEBUG - 2022-06-17 05:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:35 --> Total execution time: 0.0455
DEBUG - 2022-06-17 05:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:39 --> Total execution time: 0.0496
DEBUG - 2022-06-17 05:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:43 --> Total execution time: 0.0777
DEBUG - 2022-06-17 05:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:51 --> Total execution time: 0.0531
DEBUG - 2022-06-17 05:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:52 --> Total execution time: 0.0475
DEBUG - 2022-06-17 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:01 --> Total execution time: 0.0805
DEBUG - 2022-06-17 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:05 --> Total execution time: 0.0453
DEBUG - 2022-06-17 05:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:10 --> Total execution time: 0.0592
DEBUG - 2022-06-17 05:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:11 --> Total execution time: 0.0769
DEBUG - 2022-06-17 05:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:13 --> Total execution time: 0.0724
DEBUG - 2022-06-17 05:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:51:14 --> Total execution time: 0.1035
DEBUG - 2022-06-17 05:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:15 --> Total execution time: 0.0832
DEBUG - 2022-06-17 05:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:51:17 --> Total execution time: 0.0503
DEBUG - 2022-06-17 05:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:51:17 --> Total execution time: 0.0887
DEBUG - 2022-06-17 05:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:30 --> Total execution time: 0.0645
DEBUG - 2022-06-17 05:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:21:43 --> Total execution time: 0.0534
DEBUG - 2022-06-17 05:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:22:58 --> Total execution time: 0.0662
DEBUG - 2022-06-17 05:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:29 --> Total execution time: 0.0932
DEBUG - 2022-06-17 05:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:30 --> Total execution time: 0.0873
DEBUG - 2022-06-17 05:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:34 --> Total execution time: 0.0514
DEBUG - 2022-06-17 05:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:35 --> Total execution time: 0.0425
DEBUG - 2022-06-17 05:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:39 --> Total execution time: 0.0434
DEBUG - 2022-06-17 05:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:44 --> Total execution time: 0.0448
DEBUG - 2022-06-17 05:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:47 --> Total execution time: 0.0453
DEBUG - 2022-06-17 05:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:50 --> Total execution time: 0.0425
DEBUG - 2022-06-17 05:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:23:55 --> Total execution time: 0.0629
DEBUG - 2022-06-17 05:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:24:14 --> Total execution time: 0.0666
DEBUG - 2022-06-17 05:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:24:33 --> Total execution time: 0.0446
DEBUG - 2022-06-17 05:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:24:42 --> Total execution time: 0.0496
DEBUG - 2022-06-17 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:54:47 --> Total execution time: 0.0524
DEBUG - 2022-06-17 05:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:24:55 --> Total execution time: 0.1083
DEBUG - 2022-06-17 05:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:24:56 --> Total execution time: 0.0987
DEBUG - 2022-06-17 05:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:00 --> Total execution time: 0.0409
DEBUG - 2022-06-17 05:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:06 --> Total execution time: 0.0563
DEBUG - 2022-06-17 05:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:33 --> Total execution time: 0.0439
DEBUG - 2022-06-17 05:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:37 --> Total execution time: 0.0547
DEBUG - 2022-06-17 05:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:50 --> Total execution time: 0.0461
DEBUG - 2022-06-17 05:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:54 --> Total execution time: 0.0393
DEBUG - 2022-06-17 05:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:56 --> Total execution time: 0.0440
DEBUG - 2022-06-17 05:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 05:55:57 --> Total execution time: 0.0413
DEBUG - 2022-06-17 05:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:25:57 --> Total execution time: 0.0419
DEBUG - 2022-06-17 05:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:25:57 --> Total execution time: 0.0614
DEBUG - 2022-06-17 05:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:26:09 --> Total execution time: 0.0439
DEBUG - 2022-06-17 05:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:26:09 --> Total execution time: 0.0554
DEBUG - 2022-06-17 05:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:56:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:26:25 --> Total execution time: 0.0374
DEBUG - 2022-06-17 05:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:56:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 05:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 05:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:26:34 --> Total execution time: 0.0517
DEBUG - 2022-06-17 05:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 05:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 05:58:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:30:02 --> Total execution time: 0.1987
DEBUG - 2022-06-17 06:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:01:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:01:34 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 06:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:01:48 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 06:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:01:58 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:02:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:02:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 06:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:02:05 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 06:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:03:11 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 06:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:03:42 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:33:42 --> Total execution time: 0.0579
DEBUG - 2022-06-17 06:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:03:42 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-17 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:34:01 --> Total execution time: 0.0811
DEBUG - 2022-06-17 06:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:34:34 --> Total execution time: 0.0731
DEBUG - 2022-06-17 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:34:41 --> Total execution time: 0.0451
DEBUG - 2022-06-17 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:34:45 --> Total execution time: 0.1617
DEBUG - 2022-06-17 06:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:34:53 --> Total execution time: 0.0979
DEBUG - 2022-06-17 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:35:02 --> Total execution time: 0.1248
DEBUG - 2022-06-17 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:35:11 --> Total execution time: 0.0711
DEBUG - 2022-06-17 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:35:31 --> Total execution time: 0.0857
DEBUG - 2022-06-17 06:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:01 --> Total execution time: 0.0557
DEBUG - 2022-06-17 06:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:08 --> Total execution time: 0.0486
DEBUG - 2022-06-17 06:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:13 --> Total execution time: 0.0492
DEBUG - 2022-06-17 06:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:28 --> Total execution time: 0.0544
DEBUG - 2022-06-17 06:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:29 --> Total execution time: 0.0596
DEBUG - 2022-06-17 06:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:29 --> Total execution time: 0.0492
DEBUG - 2022-06-17 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:36:37 --> Total execution time: 0.0745
DEBUG - 2022-06-17 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:38:51 --> Total execution time: 0.1020
DEBUG - 2022-06-17 06:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:10:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:40:21 --> Total execution time: 0.1830
DEBUG - 2022-06-17 06:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:40:40 --> Total execution time: 1.8844
DEBUG - 2022-06-17 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:10:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 06:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:11:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:41:07 --> Total execution time: 0.0426
DEBUG - 2022-06-17 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:42:17 --> Total execution time: 0.0559
DEBUG - 2022-06-17 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:42:26 --> Total execution time: 0.0494
DEBUG - 2022-06-17 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:15:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:45:30 --> Total execution time: 0.1769
DEBUG - 2022-06-17 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:15:34 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:45:34 --> Total execution time: 0.0503
DEBUG - 2022-06-17 06:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:15:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:45:45 --> Total execution time: 0.0585
DEBUG - 2022-06-17 06:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:16:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:46:04 --> Total execution time: 0.0428
DEBUG - 2022-06-17 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:47:39 --> Total execution time: 0.0563
DEBUG - 2022-06-17 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:47:42 --> Total execution time: 0.0461
DEBUG - 2022-06-17 06:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:47:51 --> Total execution time: 0.0579
DEBUG - 2022-06-17 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:48:04 --> Total execution time: 0.0483
DEBUG - 2022-06-17 06:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:48:15 --> Total execution time: 0.0560
DEBUG - 2022-06-17 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:48:23 --> Total execution time: 0.0540
DEBUG - 2022-06-17 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:19:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:49:55 --> Total execution time: 0.0527
DEBUG - 2022-06-17 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:20:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:50:44 --> Total execution time: 0.0329
DEBUG - 2022-06-17 06:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:21:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:51:09 --> Total execution time: 0.1172
DEBUG - 2022-06-17 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:55:20 --> Total execution time: 0.0468
DEBUG - 2022-06-17 06:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:55:34 --> Total execution time: 0.0577
DEBUG - 2022-06-17 06:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:25:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:55:41 --> Total execution time: 0.0450
DEBUG - 2022-06-17 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:05 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:56:05 --> Total execution time: 0.0450
DEBUG - 2022-06-17 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:26:09 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 06:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:56:16 --> Total execution time: 0.0505
DEBUG - 2022-06-17 06:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:56:33 --> Total execution time: 0.0431
DEBUG - 2022-06-17 06:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:56:44 --> Total execution time: 0.0601
DEBUG - 2022-06-17 06:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:57:13 --> Total execution time: 0.0957
DEBUG - 2022-06-17 06:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:27:35 --> Total execution time: 0.0414
DEBUG - 2022-06-17 06:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:57:45 --> Total execution time: 0.0476
DEBUG - 2022-06-17 06:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:27:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:57:57 --> Total execution time: 0.0416
DEBUG - 2022-06-17 06:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:06 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:06 --> Total execution time: 0.0424
DEBUG - 2022-06-17 06:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:15 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:15 --> Total execution time: 0.0438
DEBUG - 2022-06-17 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:21 --> Total execution time: 0.0393
DEBUG - 2022-06-17 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:25 --> Total execution time: 0.0431
DEBUG - 2022-06-17 06:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:31 --> Total execution time: 0.0595
DEBUG - 2022-06-17 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:53 --> Total execution time: 0.0384
DEBUG - 2022-06-17 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:53 --> Total execution time: 0.0380
DEBUG - 2022-06-17 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:53 --> Total execution time: 0.0394
DEBUG - 2022-06-17 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:58:53 --> Total execution time: 0.0391
DEBUG - 2022-06-17 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:29:59 --> Total execution time: 0.0366
DEBUG - 2022-06-17 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:30:02 --> Total execution time: 0.0806
DEBUG - 2022-06-17 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:30:02 --> Total execution time: 0.1701
DEBUG - 2022-06-17 06:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:30:03 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:00:03 --> Total execution time: 0.0428
DEBUG - 2022-06-17 06:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:00:44 --> Total execution time: 0.0454
DEBUG - 2022-06-17 06:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:30:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:00:56 --> Total execution time: 0.0453
DEBUG - 2022-06-17 06:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:01:03 --> Total execution time: 0.0697
DEBUG - 2022-06-17 06:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:01:11 --> Total execution time: 0.0717
DEBUG - 2022-06-17 06:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:01:22 --> Total execution time: 0.0459
DEBUG - 2022-06-17 06:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:01:25 --> Total execution time: 0.1134
DEBUG - 2022-06-17 06:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:32:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:02:52 --> Total execution time: 0.1033
DEBUG - 2022-06-17 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:02:58 --> Total execution time: 0.0490
DEBUG - 2022-06-17 06:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:03:11 --> Total execution time: 0.0665
DEBUG - 2022-06-17 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:03:16 --> Total execution time: 0.0468
DEBUG - 2022-06-17 06:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:33:23 --> Total execution time: 0.0936
DEBUG - 2022-06-17 06:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:33:25 --> Total execution time: 0.0423
DEBUG - 2022-06-17 06:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:33:25 --> Total execution time: 0.0538
DEBUG - 2022-06-17 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:03:29 --> Total execution time: 0.0819
DEBUG - 2022-06-17 06:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:03:53 --> Total execution time: 0.0530
DEBUG - 2022-06-17 06:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:04:05 --> Total execution time: 0.0634
DEBUG - 2022-06-17 06:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:04:14 --> Total execution time: 0.0466
DEBUG - 2022-06-17 06:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:38:42 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 06:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:11:26 --> Total execution time: 0.1418
DEBUG - 2022-06-17 06:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:11:32 --> Total execution time: 0.0307
DEBUG - 2022-06-17 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:39 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:11:39 --> Total execution time: 0.0296
DEBUG - 2022-06-17 06:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:11:43 --> Total execution time: 0.0520
DEBUG - 2022-06-17 06:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:11:50 --> Total execution time: 0.0409
DEBUG - 2022-06-17 06:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:11:54 --> Total execution time: 0.0749
DEBUG - 2022-06-17 06:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:12:03 --> Total execution time: 0.0454
DEBUG - 2022-06-17 06:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:12:06 --> Total execution time: 0.1259
DEBUG - 2022-06-17 06:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:12:36 --> Total execution time: 0.0550
DEBUG - 2022-06-17 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:12:43 --> Total execution time: 0.0715
DEBUG - 2022-06-17 06:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:13:02 --> Total execution time: 0.0743
DEBUG - 2022-06-17 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:13:10 --> Total execution time: 0.0545
DEBUG - 2022-06-17 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:13:35 --> Total execution time: 0.0616
DEBUG - 2022-06-17 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:13:47 --> Total execution time: 0.0623
DEBUG - 2022-06-17 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:13:51 --> Total execution time: 0.0470
DEBUG - 2022-06-17 06:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:14:01 --> Total execution time: 0.0457
DEBUG - 2022-06-17 06:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:14:15 --> Total execution time: 0.0740
DEBUG - 2022-06-17 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:14:41 --> Total execution time: 0.0709
DEBUG - 2022-06-17 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:18:29 --> Total execution time: 0.1401
DEBUG - 2022-06-17 06:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:18:35 --> Total execution time: 0.0353
DEBUG - 2022-06-17 06:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:48:45 --> Total execution time: 0.0656
DEBUG - 2022-06-17 06:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:48:46 --> Total execution time: 0.0482
DEBUG - 2022-06-17 06:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:48:46 --> Total execution time: 0.0714
DEBUG - 2022-06-17 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:18:57 --> Total execution time: 0.0612
DEBUG - 2022-06-17 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:18:58 --> Total execution time: 0.0636
DEBUG - 2022-06-17 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:19:16 --> Total execution time: 0.0613
DEBUG - 2022-06-17 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:19:26 --> Total execution time: 0.0532
DEBUG - 2022-06-17 06:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:19:29 --> Total execution time: 0.0386
DEBUG - 2022-06-17 06:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:19:37 --> Total execution time: 0.0514
DEBUG - 2022-06-17 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:19:53 --> Total execution time: 0.0483
DEBUG - 2022-06-17 06:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:20:03 --> Total execution time: 0.0472
DEBUG - 2022-06-17 06:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:20:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:20:04 --> Total execution time: 0.0402
DEBUG - 2022-06-17 06:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:21:11 --> Total execution time: 0.0442
DEBUG - 2022-06-17 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:08 --> Total execution time: 0.0592
DEBUG - 2022-06-17 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:09 --> Total execution time: 0.0615
DEBUG - 2022-06-17 06:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:18 --> Total execution time: 0.0675
DEBUG - 2022-06-17 06:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:52:21 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-06-17 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:52:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:24 --> Total execution time: 0.0678
DEBUG - 2022-06-17 06:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:40 --> Total execution time: 0.0960
DEBUG - 2022-06-17 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:48 --> Total execution time: 0.0523
DEBUG - 2022-06-17 06:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:51 --> Total execution time: 0.0664
DEBUG - 2022-06-17 06:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:22:58 --> Total execution time: 0.0737
DEBUG - 2022-06-17 06:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:23:09 --> Total execution time: 0.0990
DEBUG - 2022-06-17 06:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:23:43 --> Total execution time: 0.1246
DEBUG - 2022-06-17 06:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:23:49 --> Total execution time: 0.0473
DEBUG - 2022-06-17 06:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:23:56 --> Total execution time: 0.0627
DEBUG - 2022-06-17 06:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:24:03 --> Total execution time: 0.0661
DEBUG - 2022-06-17 06:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:24:21 --> Total execution time: 0.0435
DEBUG - 2022-06-17 06:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:24:23 --> Total execution time: 0.0704
DEBUG - 2022-06-17 06:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:24:24 --> Total execution time: 0.0890
DEBUG - 2022-06-17 06:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:54:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:24:46 --> Total execution time: 0.0447
DEBUG - 2022-06-17 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:25:03 --> Total execution time: 1.8993
DEBUG - 2022-06-17 06:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 06:55:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 06:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:00 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:00 --> Total execution time: 0.0563
DEBUG - 2022-06-17 06:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:12 --> Total execution time: 0.1058
DEBUG - 2022-06-17 06:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:20 --> Total execution time: 0.0522
DEBUG - 2022-06-17 06:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:24 --> Total execution time: 0.0613
DEBUG - 2022-06-17 06:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:25 --> Total execution time: 0.0621
DEBUG - 2022-06-17 06:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:26 --> Total execution time: 0.0441
DEBUG - 2022-06-17 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:32 --> Total execution time: 0.0454
DEBUG - 2022-06-17 06:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:49 --> Total execution time: 0.0470
DEBUG - 2022-06-17 06:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 06:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:53 --> Total execution time: 0.0413
DEBUG - 2022-06-17 06:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:26:57 --> Total execution time: 0.0768
DEBUG - 2022-06-17 06:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:27:05 --> Total execution time: 0.0641
DEBUG - 2022-06-17 06:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:27:13 --> Total execution time: 0.0661
DEBUG - 2022-06-17 06:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 06:59:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 06:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 06:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:29:20 --> Total execution time: 0.1588
DEBUG - 2022-06-17 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:30:03 --> Total execution time: 0.0950
DEBUG - 2022-06-17 07:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:30:10 --> Total execution time: 1.5287
DEBUG - 2022-06-17 07:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:34:57 --> Total execution time: 1.7225
DEBUG - 2022-06-17 07:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:05:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:35:23 --> Total execution time: 0.1238
DEBUG - 2022-06-17 07:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:35:38 --> Total execution time: 0.0593
DEBUG - 2022-06-17 07:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:36:21 --> Total execution time: 0.0740
DEBUG - 2022-06-17 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:36:45 --> Total execution time: 0.0450
DEBUG - 2022-06-17 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:36:48 --> Total execution time: 0.0775
DEBUG - 2022-06-17 07:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:04 --> Total execution time: 0.0499
DEBUG - 2022-06-17 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:11 --> Total execution time: 1.4797
DEBUG - 2022-06-17 07:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:07:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 07:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:23 --> Total execution time: 0.0482
DEBUG - 2022-06-17 07:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:35 --> Total execution time: 0.0387
DEBUG - 2022-06-17 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:38 --> Total execution time: 0.0384
DEBUG - 2022-06-17 07:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:45 --> Total execution time: 0.0465
DEBUG - 2022-06-17 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:37:56 --> Total execution time: 0.0404
DEBUG - 2022-06-17 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:38:08 --> Total execution time: 0.0489
DEBUG - 2022-06-17 07:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:38:24 --> Total execution time: 0.0686
DEBUG - 2022-06-17 07:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:38:26 --> Total execution time: 0.0460
DEBUG - 2022-06-17 07:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:38:28 --> Total execution time: 0.0654
DEBUG - 2022-06-17 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:38:44 --> Total execution time: 0.0415
DEBUG - 2022-06-17 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:38:53 --> Total execution time: 0.0739
DEBUG - 2022-06-17 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:16 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:40:16 --> Total execution time: 0.1270
DEBUG - 2022-06-17 07:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:40:24 --> Total execution time: 0.0390
DEBUG - 2022-06-17 07:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:40:26 --> Total execution time: 0.0506
DEBUG - 2022-06-17 07:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:40:26 --> Total execution time: 0.0365
DEBUG - 2022-06-17 07:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:40:46 --> Total execution time: 0.0522
DEBUG - 2022-06-17 07:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:40:58 --> Total execution time: 0.0547
DEBUG - 2022-06-17 07:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:41:01 --> Total execution time: 0.0370
DEBUG - 2022-06-17 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:41:31 --> Total execution time: 0.0447
DEBUG - 2022-06-17 07:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:41:32 --> Total execution time: 0.0947
DEBUG - 2022-06-17 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:41:46 --> Total execution time: 0.0468
DEBUG - 2022-06-17 07:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:11:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:41:59 --> Total execution time: 0.0545
DEBUG - 2022-06-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:03 --> Total execution time: 0.0408
DEBUG - 2022-06-17 07:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:27 --> Total execution time: 0.0872
DEBUG - 2022-06-17 07:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:40 --> Total execution time: 0.0628
DEBUG - 2022-06-17 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:42 --> Total execution time: 0.0396
DEBUG - 2022-06-17 07:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:45 --> Total execution time: 0.0596
DEBUG - 2022-06-17 07:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:46 --> Total execution time: 0.0526
DEBUG - 2022-06-17 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:47 --> Total execution time: 0.0368
DEBUG - 2022-06-17 07:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:42:58 --> Total execution time: 0.0493
DEBUG - 2022-06-17 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:43:08 --> Total execution time: 0.0706
DEBUG - 2022-06-17 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:43:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:43:09 --> Total execution time: 0.0458
DEBUG - 2022-06-17 07:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:15 --> Total execution time: 0.0413
DEBUG - 2022-06-17 07:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:16 --> Total execution time: 0.0423
DEBUG - 2022-06-17 07:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:23 --> Total execution time: 0.0424
DEBUG - 2022-06-17 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:36 --> Total execution time: 0.0412
DEBUG - 2022-06-17 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:44 --> Total execution time: 0.0625
DEBUG - 2022-06-17 07:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:45 --> Total execution time: 0.0415
DEBUG - 2022-06-17 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:14:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:44:54 --> Total execution time: 0.0396
DEBUG - 2022-06-17 07:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:46:18 --> Total execution time: 0.0385
DEBUG - 2022-06-17 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:46:19 --> Total execution time: 0.0380
DEBUG - 2022-06-17 07:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:46:21 --> Total execution time: 0.0375
DEBUG - 2022-06-17 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:46:23 --> Total execution time: 0.0389
DEBUG - 2022-06-17 07:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:46:29 --> Total execution time: 0.0643
DEBUG - 2022-06-17 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:46:50 --> Total execution time: 0.0454
DEBUG - 2022-06-17 07:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:47:13 --> Total execution time: 0.0505
DEBUG - 2022-06-17 07:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:47:29 --> Total execution time: 0.0618
DEBUG - 2022-06-17 07:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:47:33 --> Total execution time: 0.0513
DEBUG - 2022-06-17 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:47:56 --> Total execution time: 0.0665
DEBUG - 2022-06-17 07:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:48:07 --> Total execution time: 0.0399
DEBUG - 2022-06-17 07:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:48:10 --> Total execution time: 0.0404
DEBUG - 2022-06-17 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:48:21 --> Total execution time: 0.0456
DEBUG - 2022-06-17 07:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:48:54 --> Total execution time: 0.0412
DEBUG - 2022-06-17 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:48:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:48:56 --> Total execution time: 0.0385
DEBUG - 2022-06-17 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:50:43 --> Total execution time: 0.0457
DEBUG - 2022-06-17 07:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:03 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:03 --> Total execution time: 0.0382
DEBUG - 2022-06-17 07:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:24 --> Total execution time: 0.0453
DEBUG - 2022-06-17 07:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:25 --> Total execution time: 0.0607
DEBUG - 2022-06-17 07:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:35 --> Total execution time: 0.0443
DEBUG - 2022-06-17 07:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:40 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:40 --> Total execution time: 0.0458
DEBUG - 2022-06-17 07:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:41 --> Total execution time: 0.0290
DEBUG - 2022-06-17 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:51 --> Total execution time: 0.1147
DEBUG - 2022-06-17 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:51:52 --> Total execution time: 0.0442
DEBUG - 2022-06-17 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:21:59 --> Total execution time: 0.0402
DEBUG - 2022-06-17 07:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:05 --> Total execution time: 0.0626
DEBUG - 2022-06-17 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:10 --> Total execution time: 0.1230
DEBUG - 2022-06-17 07:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:12 --> Total execution time: 0.1186
DEBUG - 2022-06-17 07:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:13 --> Total execution time: 0.1216
DEBUG - 2022-06-17 07:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:21 --> Total execution time: 0.0435
DEBUG - 2022-06-17 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:23 --> Total execution time: 0.0422
DEBUG - 2022-06-17 07:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:26 --> Total execution time: 0.0374
DEBUG - 2022-06-17 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:38 --> Total execution time: 0.0460
DEBUG - 2022-06-17 07:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:41 --> Total execution time: 0.0446
DEBUG - 2022-06-17 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:43 --> Total execution time: 0.0419
DEBUG - 2022-06-17 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:43 --> Total execution time: 0.0479
DEBUG - 2022-06-17 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:52:45 --> Total execution time: 0.0424
DEBUG - 2022-06-17 07:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:53:42 --> Total execution time: 0.0560
DEBUG - 2022-06-17 07:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:24:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:54:09 --> Total execution time: 0.0909
DEBUG - 2022-06-17 07:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:54:10 --> Total execution time: 0.0270
DEBUG - 2022-06-17 07:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:24:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:54:30 --> Total execution time: 0.0482
DEBUG - 2022-06-17 07:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:24:51 --> Total execution time: 0.0494
DEBUG - 2022-06-17 07:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:24:52 --> Total execution time: 0.0459
DEBUG - 2022-06-17 07:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:24:52 --> Total execution time: 0.0856
DEBUG - 2022-06-17 07:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:55:58 --> Total execution time: 0.0597
DEBUG - 2022-06-17 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:56:20 --> Total execution time: 0.0447
DEBUG - 2022-06-17 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:56:39 --> Total execution time: 0.0438
DEBUG - 2022-06-17 07:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:58:28 --> Total execution time: 0.0413
DEBUG - 2022-06-17 07:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:29:11 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:59:11 --> Total execution time: 0.0339
DEBUG - 2022-06-17 07:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:59:18 --> Total execution time: 0.0374
DEBUG - 2022-06-17 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:59:30 --> Total execution time: 0.0623
DEBUG - 2022-06-17 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:59:36 --> Total execution time: 0.0551
DEBUG - 2022-06-17 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:59:41 --> Total execution time: 0.0711
DEBUG - 2022-06-17 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:00:25 --> Total execution time: 0.0549
DEBUG - 2022-06-17 07:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:00:35 --> Total execution time: 0.0378
DEBUG - 2022-06-17 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:01:04 --> Total execution time: 0.0724
DEBUG - 2022-06-17 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:02:23 --> Total execution time: 0.0465
DEBUG - 2022-06-17 07:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:02:24 --> Total execution time: 0.0665
DEBUG - 2022-06-17 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:02:26 --> Total execution time: 0.0925
DEBUG - 2022-06-17 07:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:02:37 --> Total execution time: 0.0477
DEBUG - 2022-06-17 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:02:38 --> Total execution time: 0.0397
DEBUG - 2022-06-17 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:02:52 --> Total execution time: 0.0427
DEBUG - 2022-06-17 07:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:00 --> Total execution time: 0.0661
DEBUG - 2022-06-17 07:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:18 --> Total execution time: 0.0490
DEBUG - 2022-06-17 07:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:30 --> Total execution time: 0.0489
DEBUG - 2022-06-17 07:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:31 --> Total execution time: 0.0520
DEBUG - 2022-06-17 07:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:36 --> Total execution time: 0.0484
DEBUG - 2022-06-17 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:54 --> Total execution time: 0.0471
DEBUG - 2022-06-17 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:35:31 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 07:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:35:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:05:54 --> Total execution time: 0.0703
DEBUG - 2022-06-17 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:36:49 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:37:00 --> 404 Page Not Found: Refund/esalestrix.in
DEBUG - 2022-06-17 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:37:59 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:08:01 --> Total execution time: 0.1476
DEBUG - 2022-06-17 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:08:11 --> Total execution time: 0.0388
DEBUG - 2022-06-17 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:08:20 --> Total execution time: 0.0455
DEBUG - 2022-06-17 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:08:28 --> Total execution time: 0.0736
DEBUG - 2022-06-17 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:08:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:08:29 --> Total execution time: 0.0382
DEBUG - 2022-06-17 07:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:09:44 --> Total execution time: 0.0447
DEBUG - 2022-06-17 07:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:09:54 --> Total execution time: 0.0675
DEBUG - 2022-06-17 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:40:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:05 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:10:05 --> Total execution time: 0.0676
DEBUG - 2022-06-17 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:10:06 --> Total execution time: 0.0529
DEBUG - 2022-06-17 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:10:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:10:07 --> Total execution time: 0.0510
DEBUG - 2022-06-17 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:40:21 --> Total execution time: 0.0304
DEBUG - 2022-06-17 07:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:40:30 --> Total execution time: 0.0469
DEBUG - 2022-06-17 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:40:31 --> Total execution time: 0.0792
DEBUG - 2022-06-17 07:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:01 --> Total execution time: 0.1087
DEBUG - 2022-06-17 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:04 --> Total execution time: 0.0635
DEBUG - 2022-06-17 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:04 --> Total execution time: 0.0517
DEBUG - 2022-06-17 07:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:11:31 --> Total execution time: 0.1767
DEBUG - 2022-06-17 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:40 --> Total execution time: 0.0480
DEBUG - 2022-06-17 07:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:42 --> Total execution time: 0.0427
DEBUG - 2022-06-17 07:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:41:43 --> Total execution time: 0.0383
DEBUG - 2022-06-17 07:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:41:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:11:49 --> Total execution time: 0.0817
DEBUG - 2022-06-17 07:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:42:00 --> Total execution time: 0.0569
DEBUG - 2022-06-17 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:42:02 --> Total execution time: 0.1468
DEBUG - 2022-06-17 07:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:42:02 --> Total execution time: 0.2409
DEBUG - 2022-06-17 07:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:04 --> Total execution time: 0.0721
DEBUG - 2022-06-17 07:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:23 --> Total execution time: 0.0804
DEBUG - 2022-06-17 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:28 --> Total execution time: 0.0596
DEBUG - 2022-06-17 07:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:33 --> Total execution time: 0.0446
DEBUG - 2022-06-17 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:40 --> Total execution time: 0.0463
DEBUG - 2022-06-17 07:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:44 --> Total execution time: 0.0652
DEBUG - 2022-06-17 07:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:44 --> Total execution time: 0.0386
DEBUG - 2022-06-17 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:45 --> Total execution time: 0.0371
DEBUG - 2022-06-17 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:12:49 --> Total execution time: 0.0477
DEBUG - 2022-06-17 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:01 --> Total execution time: 0.0424
DEBUG - 2022-06-17 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:12 --> Total execution time: 0.1258
DEBUG - 2022-06-17 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:17 --> Total execution time: 0.0879
DEBUG - 2022-06-17 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:18 --> Total execution time: 0.1313
DEBUG - 2022-06-17 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:18 --> Total execution time: 0.0564
DEBUG - 2022-06-17 07:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:29 --> Total execution time: 0.0474
DEBUG - 2022-06-17 07:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:43 --> Total execution time: 0.0642
DEBUG - 2022-06-17 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:44 --> Total execution time: 0.0752
DEBUG - 2022-06-17 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:43:58 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:13:58 --> Total execution time: 0.0401
DEBUG - 2022-06-17 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:05 --> Total execution time: 0.0811
DEBUG - 2022-06-17 07:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:07 --> Total execution time: 0.0770
DEBUG - 2022-06-17 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:14 --> Total execution time: 0.1114
DEBUG - 2022-06-17 07:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:15 --> Total execution time: 0.1062
DEBUG - 2022-06-17 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:20 --> Total execution time: 0.0694
DEBUG - 2022-06-17 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:21 --> Total execution time: 0.0730
DEBUG - 2022-06-17 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:21 --> Total execution time: 0.0640
DEBUG - 2022-06-17 07:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:22 --> Total execution time: 0.0445
DEBUG - 2022-06-17 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:41 --> Total execution time: 0.1020
DEBUG - 2022-06-17 07:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:46 --> Total execution time: 0.0529
DEBUG - 2022-06-17 07:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:47 --> Total execution time: 0.0696
DEBUG - 2022-06-17 07:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:48 --> Total execution time: 0.0545
DEBUG - 2022-06-17 07:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:48 --> Total execution time: 0.0494
DEBUG - 2022-06-17 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:55 --> Total execution time: 0.0481
DEBUG - 2022-06-17 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:14:56 --> Total execution time: 0.0561
DEBUG - 2022-06-17 07:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:02 --> Total execution time: 0.0832
DEBUG - 2022-06-17 07:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:02 --> Total execution time: 0.0745
DEBUG - 2022-06-17 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:03 --> Total execution time: 0.0625
DEBUG - 2022-06-17 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:03 --> Total execution time: 0.0575
DEBUG - 2022-06-17 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:45:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:03 --> Total execution time: 0.0590
DEBUG - 2022-06-17 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:04 --> Total execution time: 0.0535
DEBUG - 2022-06-17 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:04 --> Total execution time: 0.0689
DEBUG - 2022-06-17 07:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:05 --> Total execution time: 0.0662
DEBUG - 2022-06-17 07:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:10 --> Total execution time: 0.0491
DEBUG - 2022-06-17 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:11 --> Total execution time: 0.0751
DEBUG - 2022-06-17 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:17 --> Total execution time: 0.0653
DEBUG - 2022-06-17 07:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:24 --> Total execution time: 0.0487
DEBUG - 2022-06-17 07:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:15:58 --> Total execution time: 0.0433
DEBUG - 2022-06-17 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:16:11 --> Total execution time: 0.0501
DEBUG - 2022-06-17 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:16:19 --> Total execution time: 0.0484
DEBUG - 2022-06-17 07:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:16:28 --> Total execution time: 0.0409
DEBUG - 2022-06-17 07:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:16:54 --> Total execution time: 0.0458
DEBUG - 2022-06-17 07:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:17:28 --> Total execution time: 0.0461
DEBUG - 2022-06-17 07:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:17:38 --> Total execution time: 0.0698
DEBUG - 2022-06-17 07:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:17:49 --> Total execution time: 0.0666
DEBUG - 2022-06-17 07:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:17:51 --> Total execution time: 0.0981
DEBUG - 2022-06-17 07:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:17:59 --> Total execution time: 0.0841
DEBUG - 2022-06-17 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:18:02 --> Total execution time: 0.2141
DEBUG - 2022-06-17 07:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:48:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:18:35 --> Total execution time: 0.0316
DEBUG - 2022-06-17 07:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:18:47 --> Total execution time: 0.0390
DEBUG - 2022-06-17 07:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:06 --> Total execution time: 0.0511
DEBUG - 2022-06-17 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:11 --> Total execution time: 0.0811
DEBUG - 2022-06-17 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:18 --> Total execution time: 0.0400
DEBUG - 2022-06-17 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:20 --> Total execution time: 0.0445
DEBUG - 2022-06-17 07:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:23 --> Total execution time: 0.0635
DEBUG - 2022-06-17 07:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:27 --> Total execution time: 0.0461
DEBUG - 2022-06-17 07:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:34 --> Total execution time: 0.5103
DEBUG - 2022-06-17 07:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:34 --> Total execution time: 0.0751
DEBUG - 2022-06-17 07:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:41 --> Total execution time: 0.0419
DEBUG - 2022-06-17 07:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:44 --> Total execution time: 0.0412
DEBUG - 2022-06-17 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:49:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:19:53 --> Total execution time: 0.0425
DEBUG - 2022-06-17 07:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:01 --> Total execution time: 0.1776
DEBUG - 2022-06-17 07:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:02 --> Total execution time: 0.0440
DEBUG - 2022-06-17 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:04 --> Total execution time: 0.0778
DEBUG - 2022-06-17 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:04 --> Total execution time: 0.1416
DEBUG - 2022-06-17 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:12 --> Total execution time: 0.1902
DEBUG - 2022-06-17 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:12 --> Total execution time: 0.1162
DEBUG - 2022-06-17 07:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:22 --> Total execution time: 0.0640
DEBUG - 2022-06-17 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:38 --> Total execution time: 0.0462
DEBUG - 2022-06-17 07:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:38 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:38 --> Total execution time: 0.0323
DEBUG - 2022-06-17 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:39 --> Total execution time: 0.0419
DEBUG - 2022-06-17 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:39 --> Total execution time: 0.0909
DEBUG - 2022-06-17 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:40 --> Total execution time: 0.0631
DEBUG - 2022-06-17 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:50:40 --> Total execution time: 0.0749
DEBUG - 2022-06-17 07:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:40 --> Total execution time: 0.0731
DEBUG - 2022-06-17 07:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:20:49 --> Total execution time: 0.0426
DEBUG - 2022-06-17 07:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:21:21 --> Total execution time: 0.0410
DEBUG - 2022-06-17 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:21:31 --> Total execution time: 0.0500
DEBUG - 2022-06-17 07:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:21:49 --> Total execution time: 0.0404
DEBUG - 2022-06-17 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:51:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:21:54 --> Total execution time: 0.0656
DEBUG - 2022-06-17 07:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:09 --> Total execution time: 0.0401
DEBUG - 2022-06-17 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:11 --> Total execution time: 0.0437
DEBUG - 2022-06-17 07:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:11 --> Total execution time: 0.0731
DEBUG - 2022-06-17 07:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:34 --> Total execution time: 0.0404
DEBUG - 2022-06-17 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:35 --> Total execution time: 0.0444
DEBUG - 2022-06-17 07:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:52:37 --> Total execution time: 0.0550
DEBUG - 2022-06-17 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:52:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:22:41 --> Total execution time: 0.0445
DEBUG - 2022-06-17 07:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:53:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:23:55 --> Total execution time: 0.1183
DEBUG - 2022-06-17 07:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:04 --> Total execution time: 0.0423
DEBUG - 2022-06-17 07:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:05 --> Total execution time: 0.0437
DEBUG - 2022-06-17 07:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:05 --> Total execution time: 0.1119
DEBUG - 2022-06-17 07:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:19 --> Total execution time: 0.0655
DEBUG - 2022-06-17 07:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:24:25 --> Total execution time: 0.0298
DEBUG - 2022-06-17 07:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:35 --> Total execution time: 0.0396
DEBUG - 2022-06-17 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:39 --> Total execution time: 0.0547
DEBUG - 2022-06-17 07:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:54:39 --> Total execution time: 0.1075
DEBUG - 2022-06-17 07:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:55:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:25:06 --> Total execution time: 2.9384
DEBUG - 2022-06-17 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:55:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 07:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:25:24 --> Total execution time: 0.0995
DEBUG - 2022-06-17 07:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:25:45 --> Total execution time: 0.0397
DEBUG - 2022-06-17 07:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:25:53 --> Total execution time: 0.0408
DEBUG - 2022-06-17 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:57 --> Total execution time: 0.0389
DEBUG - 2022-06-17 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:25:57 --> Total execution time: 0.1126
DEBUG - 2022-06-17 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:55:58 --> Total execution time: 0.0499
DEBUG - 2022-06-17 07:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:55:58 --> Total execution time: 0.0576
DEBUG - 2022-06-17 07:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:00 --> Total execution time: 0.0459
DEBUG - 2022-06-17 07:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:04 --> Total execution time: 0.0484
DEBUG - 2022-06-17 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:08 --> Total execution time: 0.0377
DEBUG - 2022-06-17 07:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:56:13 --> Total execution time: 0.0461
DEBUG - 2022-06-17 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:16 --> Total execution time: 0.0400
DEBUG - 2022-06-17 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:16 --> Total execution time: 0.0471
DEBUG - 2022-06-17 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:24 --> Total execution time: 0.0442
DEBUG - 2022-06-17 07:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:25 --> Total execution time: 0.0380
DEBUG - 2022-06-17 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:56:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:26:43 --> Total execution time: 1.5264
DEBUG - 2022-06-17 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:56:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:04 --> Total execution time: 0.1353
DEBUG - 2022-06-17 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:06 --> Total execution time: 0.0656
DEBUG - 2022-06-17 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:22 --> Total execution time: 0.0454
DEBUG - 2022-06-17 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:23 --> Total execution time: 0.0527
DEBUG - 2022-06-17 07:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:34 --> Total execution time: 0.0502
DEBUG - 2022-06-17 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:35 --> Total execution time: 0.0453
DEBUG - 2022-06-17 07:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:48 --> Total execution time: 0.0489
DEBUG - 2022-06-17 07:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 07:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:58 --> Total execution time: 0.0802
DEBUG - 2022-06-17 07:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:58 --> Total execution time: 0.0496
DEBUG - 2022-06-17 07:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:27:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 18:28:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 18:28:00 --> Total execution time: 0.2036
DEBUG - 2022-06-17 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:28:06 --> Total execution time: 0.0427
DEBUG - 2022-06-17 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:28:11 --> Total execution time: 0.0466
DEBUG - 2022-06-17 07:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:58:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:28:18 --> Total execution time: 0.0614
DEBUG - 2022-06-17 07:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:28:31 --> Total execution time: 1.4865
DEBUG - 2022-06-17 07:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 07:58:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 07:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:02 --> Total execution time: 1.4862
DEBUG - 2022-06-17 07:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:10 --> Total execution time: 0.0648
DEBUG - 2022-06-17 07:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:11 --> Total execution time: 0.0640
DEBUG - 2022-06-17 07:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:13 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:13 --> Total execution time: 0.0406
DEBUG - 2022-06-17 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:16 --> Total execution time: 0.0797
DEBUG - 2022-06-17 07:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:24 --> Total execution time: 0.0632
DEBUG - 2022-06-17 07:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 07:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:26 --> Total execution time: 0.0902
DEBUG - 2022-06-17 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:28 --> Total execution time: 0.0686
DEBUG - 2022-06-17 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:39 --> Total execution time: 0.0681
DEBUG - 2022-06-17 07:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:54 --> Total execution time: 0.1179
DEBUG - 2022-06-17 07:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 07:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 07:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:29:59 --> Total execution time: 0.0459
DEBUG - 2022-06-17 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:03 --> Total execution time: 0.0612
DEBUG - 2022-06-17 08:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:05 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:05 --> Total execution time: 0.1849
DEBUG - 2022-06-17 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:08 --> Total execution time: 0.0766
DEBUG - 2022-06-17 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:11 --> Total execution time: 0.0676
DEBUG - 2022-06-17 08:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:00:17 --> Total execution time: 0.1097
DEBUG - 2022-06-17 08:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:00:19 --> Total execution time: 0.0604
DEBUG - 2022-06-17 08:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:00:19 --> Total execution time: 0.0812
DEBUG - 2022-06-17 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:31 --> Total execution time: 0.0446
DEBUG - 2022-06-17 08:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:30:32 --> Total execution time: 0.0642
DEBUG - 2022-06-17 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:01:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 08:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:01:17 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:31:17 --> Total execution time: 0.0491
DEBUG - 2022-06-17 08:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:32:40 --> Total execution time: 0.1563
DEBUG - 2022-06-17 08:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:03:21 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 08:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:03:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:33:55 --> Total execution time: 0.0913
DEBUG - 2022-06-17 08:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:04:02 --> Total execution time: 0.1434
DEBUG - 2022-06-17 08:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:04:04 --> Total execution time: 0.0454
DEBUG - 2022-06-17 08:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:04:04 --> Total execution time: 0.0532
DEBUG - 2022-06-17 08:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:34:32 --> Total execution time: 0.0412
DEBUG - 2022-06-17 08:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:34:37 --> Total execution time: 0.0423
DEBUG - 2022-06-17 08:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:34:59 --> Total execution time: 0.0390
DEBUG - 2022-06-17 08:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:34:59 --> Total execution time: 0.0433
DEBUG - 2022-06-17 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:01 --> Total execution time: 0.0796
DEBUG - 2022-06-17 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:09 --> Total execution time: 0.0437
DEBUG - 2022-06-17 08:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:13 --> Total execution time: 0.0654
DEBUG - 2022-06-17 08:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:16 --> Total execution time: 0.0335
DEBUG - 2022-06-17 08:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:24 --> Total execution time: 0.0353
DEBUG - 2022-06-17 08:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:25 --> Total execution time: 0.0503
DEBUG - 2022-06-17 08:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:37 --> Total execution time: 0.0274
DEBUG - 2022-06-17 08:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:35:41 --> Total execution time: 0.0639
DEBUG - 2022-06-17 08:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:36:42 --> Total execution time: 0.0450
DEBUG - 2022-06-17 08:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:07 --> Total execution time: 0.0389
DEBUG - 2022-06-17 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:37:18 --> Total execution time: 0.0436
DEBUG - 2022-06-17 08:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:37:21 --> Total execution time: 0.0454
DEBUG - 2022-06-17 08:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:37:30 --> Total execution time: 0.0867
DEBUG - 2022-06-17 08:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:37:43 --> Total execution time: 0.0699
DEBUG - 2022-06-17 08:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:37:51 --> Total execution time: 0.1409
DEBUG - 2022-06-17 08:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:37:54 --> Total execution time: 0.0415
DEBUG - 2022-06-17 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:07:58 --> Total execution time: 0.0471
DEBUG - 2022-06-17 08:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:00 --> Total execution time: 0.0481
DEBUG - 2022-06-17 08:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:08:00 --> Total execution time: 0.0607
DEBUG - 2022-06-17 08:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:08:29 --> Total execution time: 0.0565
DEBUG - 2022-06-17 08:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:08:33 --> Total execution time: 0.0935
DEBUG - 2022-06-17 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:38:53 --> Total execution time: 0.0594
DEBUG - 2022-06-17 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:38:54 --> Total execution time: 0.0636
DEBUG - 2022-06-17 08:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:38:59 --> Total execution time: 0.0707
DEBUG - 2022-06-17 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:00 --> Total execution time: 0.0590
DEBUG - 2022-06-17 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:00 --> Total execution time: 0.0663
DEBUG - 2022-06-17 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:01 --> Total execution time: 0.0880
DEBUG - 2022-06-17 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:01 --> Total execution time: 0.0745
DEBUG - 2022-06-17 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:02 --> Total execution time: 0.0616
DEBUG - 2022-06-17 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:02 --> Total execution time: 0.0531
DEBUG - 2022-06-17 08:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:03 --> Total execution time: 0.0514
DEBUG - 2022-06-17 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:06 --> Total execution time: 0.1119
DEBUG - 2022-06-17 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:41 --> Total execution time: 0.0536
DEBUG - 2022-06-17 08:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:39:52 --> Total execution time: 0.0914
DEBUG - 2022-06-17 08:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:07 --> Total execution time: 0.0881
DEBUG - 2022-06-17 08:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:44 --> Total execution time: 0.1331
DEBUG - 2022-06-17 08:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:45 --> Total execution time: 0.0833
DEBUG - 2022-06-17 08:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:46 --> Total execution time: 0.1665
DEBUG - 2022-06-17 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:49 --> Total execution time: 0.0374
DEBUG - 2022-06-17 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:50 --> Total execution time: 0.1020
DEBUG - 2022-06-17 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:50 --> Total execution time: 0.1401
DEBUG - 2022-06-17 08:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:51 --> Total execution time: 0.1248
DEBUG - 2022-06-17 08:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:51 --> Total execution time: 0.0883
DEBUG - 2022-06-17 08:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:52 --> Total execution time: 0.0909
DEBUG - 2022-06-17 08:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:55 --> Total execution time: 0.0829
DEBUG - 2022-06-17 08:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:56 --> Total execution time: 0.1160
DEBUG - 2022-06-17 08:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:56 --> Total execution time: 0.0779
DEBUG - 2022-06-17 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:40:58 --> Total execution time: 0.0523
DEBUG - 2022-06-17 08:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:04 --> Total execution time: 0.0432
DEBUG - 2022-06-17 08:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:05 --> Total execution time: 0.0922
DEBUG - 2022-06-17 08:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:08 --> Total execution time: 0.0543
DEBUG - 2022-06-17 08:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:11:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:11 --> Total execution time: 0.0663
DEBUG - 2022-06-17 18:41:11 --> Total execution time: 1.5454
DEBUG - 2022-06-17 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:41:15 --> Total execution time: 0.1290
DEBUG - 2022-06-17 08:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:11:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:24 --> Total execution time: 0.0915
DEBUG - 2022-06-17 08:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:26 --> Total execution time: 0.0636
DEBUG - 2022-06-17 08:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:36 --> Total execution time: 0.0760
DEBUG - 2022-06-17 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:45 --> Total execution time: 0.0481
DEBUG - 2022-06-17 08:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:46 --> Total execution time: 0.0736
DEBUG - 2022-06-17 08:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:46 --> Total execution time: 0.0730
DEBUG - 2022-06-17 08:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:41:46 --> Total execution time: 0.0802
DEBUG - 2022-06-17 08:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:03 --> Total execution time: 0.0494
DEBUG - 2022-06-17 08:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-06-17 18:42:05 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-06-17 18:42:05 --> Total execution time: 0.0607
DEBUG - 2022-06-17 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:08 --> Total execution time: 0.1479
DEBUG - 2022-06-17 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:12 --> Total execution time: 0.0430
DEBUG - 2022-06-17 08:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:29 --> Total execution time: 0.0518
DEBUG - 2022-06-17 08:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:36 --> Total execution time: 0.0506
DEBUG - 2022-06-17 08:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:37 --> Total execution time: 0.0425
DEBUG - 2022-06-17 08:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:45 --> Total execution time: 0.0419
DEBUG - 2022-06-17 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:42:49 --> Total execution time: 1.8917
DEBUG - 2022-06-17 08:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:10 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:43:10 --> Total execution time: 0.1086
DEBUG - 2022-06-17 08:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:43:13 --> Total execution time: 0.0708
DEBUG - 2022-06-17 08:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:13:25 --> Total execution time: 0.0871
DEBUG - 2022-06-17 08:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:43:25 --> Total execution time: 0.0722
DEBUG - 2022-06-17 08:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:13:26 --> Total execution time: 0.0509
DEBUG - 2022-06-17 08:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:13:26 --> Total execution time: 0.1013
DEBUG - 2022-06-17 08:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:45:01 --> Total execution time: 0.0418
DEBUG - 2022-06-17 08:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:16:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:46:07 --> Total execution time: 1.5465
DEBUG - 2022-06-17 08:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:16:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:16:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 08:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:46:37 --> Total execution time: 0.0927
DEBUG - 2022-06-17 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:46:42 --> Total execution time: 0.0522
DEBUG - 2022-06-17 08:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:46:51 --> Total execution time: 0.0619
DEBUG - 2022-06-17 08:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:46:57 --> Total execution time: 0.1172
DEBUG - 2022-06-17 08:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:47:50 --> Total execution time: 0.0574
DEBUG - 2022-06-17 08:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:47:57 --> Total execution time: 0.0493
DEBUG - 2022-06-17 08:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:47:58 --> Total execution time: 0.0712
DEBUG - 2022-06-17 08:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:06 --> Total execution time: 0.0564
DEBUG - 2022-06-17 08:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:12 --> Total execution time: 0.1012
DEBUG - 2022-06-17 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:13 --> Total execution time: 0.0557
DEBUG - 2022-06-17 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:15 --> Total execution time: 0.0506
DEBUG - 2022-06-17 08:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:15 --> Total execution time: 0.0510
DEBUG - 2022-06-17 08:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:19 --> Total execution time: 0.0527
DEBUG - 2022-06-17 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:22 --> Total execution time: 0.0359
DEBUG - 2022-06-17 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:26 --> Total execution time: 0.0447
DEBUG - 2022-06-17 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:29 --> Total execution time: 0.0516
DEBUG - 2022-06-17 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:30 --> Total execution time: 0.0438
DEBUG - 2022-06-17 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 18:48:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 18:48:31 --> Total execution time: 0.2022
DEBUG - 2022-06-17 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:31 --> Total execution time: 0.0757
DEBUG - 2022-06-17 08:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:32 --> Total execution time: 0.0764
DEBUG - 2022-06-17 08:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:40 --> Total execution time: 0.0473
DEBUG - 2022-06-17 08:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:49 --> Total execution time: 0.0524
DEBUG - 2022-06-17 08:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:58 --> Total execution time: 0.0895
DEBUG - 2022-06-17 08:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:48:59 --> Total execution time: 0.0448
DEBUG - 2022-06-17 08:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:03 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:03 --> Total execution time: 0.0323
DEBUG - 2022-06-17 08:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:06 --> Total execution time: 0.0976
DEBUG - 2022-06-17 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:07 --> Total execution time: 0.0304
DEBUG - 2022-06-17 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:11 --> Total execution time: 0.0485
DEBUG - 2022-06-17 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:14 --> Total execution time: 0.0414
DEBUG - 2022-06-17 08:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:15 --> Total execution time: 0.0457
DEBUG - 2022-06-17 08:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:16 --> Total execution time: 0.0466
DEBUG - 2022-06-17 08:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:19 --> Total execution time: 0.0598
DEBUG - 2022-06-17 08:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:19 --> Total execution time: 0.0491
DEBUG - 2022-06-17 08:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:24 --> Total execution time: 0.0404
DEBUG - 2022-06-17 08:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:24 --> Total execution time: 0.0463
DEBUG - 2022-06-17 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:26 --> Total execution time: 0.0497
DEBUG - 2022-06-17 08:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:45 --> Total execution time: 0.0736
DEBUG - 2022-06-17 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:56 --> Total execution time: 0.0858
DEBUG - 2022-06-17 08:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:49:57 --> Total execution time: 0.0648
DEBUG - 2022-06-17 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:50:01 --> Total execution time: 0.2506
DEBUG - 2022-06-17 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:50:07 --> Total execution time: 0.1305
DEBUG - 2022-06-17 08:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:50:25 --> Total execution time: 0.0883
DEBUG - 2022-06-17 08:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:50:46 --> Total execution time: 0.0415
DEBUG - 2022-06-17 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:51:08 --> Total execution time: 0.0391
DEBUG - 2022-06-17 08:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:51:23 --> Total execution time: 0.0510
DEBUG - 2022-06-17 08:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:51:39 --> Total execution time: 0.0495
DEBUG - 2022-06-17 08:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:52:11 --> Total execution time: 0.0657
DEBUG - 2022-06-17 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:52:20 --> Total execution time: 0.0428
DEBUG - 2022-06-17 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:52:34 --> Total execution time: 0.0512
DEBUG - 2022-06-17 08:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:52:38 --> Total execution time: 0.0974
DEBUG - 2022-06-17 08:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:52:41 --> Total execution time: 0.0698
DEBUG - 2022-06-17 08:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:53:20 --> Total execution time: 0.0435
DEBUG - 2022-06-17 08:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:53:35 --> Total execution time: 0.1260
DEBUG - 2022-06-17 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:53:37 --> Total execution time: 0.0978
DEBUG - 2022-06-17 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:53:50 --> Total execution time: 0.0448
DEBUG - 2022-06-17 08:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:53:51 --> Total execution time: 0.0514
DEBUG - 2022-06-17 08:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:12 --> Total execution time: 0.0677
DEBUG - 2022-06-17 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:18 --> Total execution time: 0.2552
DEBUG - 2022-06-17 08:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:26 --> Total execution time: 0.0710
DEBUG - 2022-06-17 08:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:29 --> Total execution time: 0.0704
DEBUG - 2022-06-17 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:33 --> Total execution time: 0.0728
DEBUG - 2022-06-17 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:38 --> Total execution time: 0.0687
DEBUG - 2022-06-17 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:41 --> Total execution time: 0.0510
DEBUG - 2022-06-17 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:49 --> Total execution time: 0.0532
DEBUG - 2022-06-17 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:54:53 --> Total execution time: 0.0592
DEBUG - 2022-06-17 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:25 --> Total execution time: 0.0905
DEBUG - 2022-06-17 08:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:32 --> Total execution time: 0.0382
DEBUG - 2022-06-17 08:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:36 --> Total execution time: 0.0432
DEBUG - 2022-06-17 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:41 --> Total execution time: 0.0695
DEBUG - 2022-06-17 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:53 --> Total execution time: 0.0423
DEBUG - 2022-06-17 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:54 --> Total execution time: 0.0398
DEBUG - 2022-06-17 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:55:55 --> Total execution time: 0.0535
DEBUG - 2022-06-17 08:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:56:34 --> Total execution time: 0.0580
DEBUG - 2022-06-17 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:56:42 --> Total execution time: 0.0542
DEBUG - 2022-06-17 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:56:42 --> Total execution time: 0.0385
DEBUG - 2022-06-17 08:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:56:59 --> Total execution time: 0.0424
DEBUG - 2022-06-17 08:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:57:25 --> Total execution time: 0.0616
DEBUG - 2022-06-17 08:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:57:49 --> Total execution time: 0.0517
DEBUG - 2022-06-17 08:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:58:14 --> Total execution time: 0.0528
DEBUG - 2022-06-17 08:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:58:15 --> Total execution time: 0.0388
DEBUG - 2022-06-17 08:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:58:17 --> Total execution time: 0.0610
DEBUG - 2022-06-17 08:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:58:18 --> Total execution time: 0.0601
DEBUG - 2022-06-17 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:58:22 --> Total execution time: 0.0849
DEBUG - 2022-06-17 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:58:55 --> Total execution time: 0.0993
DEBUG - 2022-06-17 08:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:59:00 --> Total execution time: 0.0526
DEBUG - 2022-06-17 08:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:59:07 --> Total execution time: 0.0787
DEBUG - 2022-06-17 08:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:59:26 --> Total execution time: 0.1444
DEBUG - 2022-06-17 08:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:30:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:00:04 --> Total execution time: 0.1153
DEBUG - 2022-06-17 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:00:59 --> Total execution time: 0.1440
DEBUG - 2022-06-17 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:01:38 --> Total execution time: 0.0440
DEBUG - 2022-06-17 08:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:01:49 --> Total execution time: 0.0791
DEBUG - 2022-06-17 08:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:01:58 --> Total execution time: 0.0575
DEBUG - 2022-06-17 08:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:02:01 --> Total execution time: 0.0728
DEBUG - 2022-06-17 08:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:02:06 --> Total execution time: 0.0654
DEBUG - 2022-06-17 08:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:02:39 --> Total execution time: 0.1098
DEBUG - 2022-06-17 08:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:02:39 --> Total execution time: 0.0489
DEBUG - 2022-06-17 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:02:54 --> Total execution time: 0.0512
DEBUG - 2022-06-17 08:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:03:44 --> Total execution time: 0.0527
DEBUG - 2022-06-17 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:03 --> Total execution time: 0.0723
DEBUG - 2022-06-17 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:19 --> Total execution time: 0.0484
DEBUG - 2022-06-17 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:26 --> Total execution time: 0.0605
DEBUG - 2022-06-17 08:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:31 --> Total execution time: 0.0576
DEBUG - 2022-06-17 08:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:38 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:38 --> Total execution time: 0.0353
DEBUG - 2022-06-17 08:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:41 --> Total execution time: 0.0637
DEBUG - 2022-06-17 08:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:50 --> Total execution time: 0.0640
DEBUG - 2022-06-17 08:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:56 --> Total execution time: 0.1021
DEBUG - 2022-06-17 08:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:00 --> Total execution time: 0.0554
DEBUG - 2022-06-17 08:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:05 --> Total execution time: 0.0642
DEBUG - 2022-06-17 08:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:17 --> Total execution time: 0.0469
DEBUG - 2022-06-17 08:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:17 --> Total execution time: 0.0300
DEBUG - 2022-06-17 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:21 --> Total execution time: 0.0633
DEBUG - 2022-06-17 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:40 --> Total execution time: 0.0465
DEBUG - 2022-06-17 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:47 --> Total execution time: 0.0904
DEBUG - 2022-06-17 08:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:49 --> Total execution time: 0.0430
DEBUG - 2022-06-17 08:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:05:50 --> Total execution time: 0.0380
DEBUG - 2022-06-17 08:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:17 --> Total execution time: 0.0445
DEBUG - 2022-06-17 08:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:28 --> Total execution time: 0.1118
DEBUG - 2022-06-17 08:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:30 --> Total execution time: 0.1331
DEBUG - 2022-06-17 08:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:33 --> Total execution time: 0.1185
DEBUG - 2022-06-17 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:35 --> Total execution time: 0.0454
DEBUG - 2022-06-17 08:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:38 --> Total execution time: 0.0532
DEBUG - 2022-06-17 08:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:06:41 --> Total execution time: 0.0593
DEBUG - 2022-06-17 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:07:21 --> Total execution time: 0.0532
DEBUG - 2022-06-17 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:07:30 --> Total execution time: 0.0724
DEBUG - 2022-06-17 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:07:31 --> Total execution time: 0.0498
DEBUG - 2022-06-17 08:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:07:32 --> Total execution time: 0.0649
DEBUG - 2022-06-17 08:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:07:48 --> Total execution time: 0.0506
DEBUG - 2022-06-17 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:07:52 --> Total execution time: 0.0541
DEBUG - 2022-06-17 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:04 --> Total execution time: 0.0480
DEBUG - 2022-06-17 08:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:06 --> Total execution time: 0.0353
DEBUG - 2022-06-17 08:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:07 --> Total execution time: 0.0563
DEBUG - 2022-06-17 08:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:38:12 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-17 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:26 --> Total execution time: 0.0415
DEBUG - 2022-06-17 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:27 --> Total execution time: 0.0378
DEBUG - 2022-06-17 08:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:31 --> Total execution time: 0.0380
DEBUG - 2022-06-17 08:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:31 --> Total execution time: 0.0341
DEBUG - 2022-06-17 08:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:39 --> Total execution time: 0.0393
DEBUG - 2022-06-17 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:47 --> Total execution time: 0.0427
DEBUG - 2022-06-17 08:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:08:48 --> Total execution time: 0.0751
DEBUG - 2022-06-17 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:09:06 --> Total execution time: 0.0384
DEBUG - 2022-06-17 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:09:13 --> Total execution time: 0.0609
DEBUG - 2022-06-17 08:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:09:14 --> Total execution time: 0.0538
DEBUG - 2022-06-17 08:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:09:39 --> Total execution time: 0.0308
DEBUG - 2022-06-17 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:09:41 --> Total execution time: 0.0440
DEBUG - 2022-06-17 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:05 --> Total execution time: 0.0391
DEBUG - 2022-06-17 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:05 --> Total execution time: 0.0484
DEBUG - 2022-06-17 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:06 --> Total execution time: 0.0520
DEBUG - 2022-06-17 08:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:08 --> Total execution time: 0.0496
DEBUG - 2022-06-17 08:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:10 --> Total execution time: 0.0502
DEBUG - 2022-06-17 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 19:10:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 19:10:12 --> Total execution time: 0.1838
DEBUG - 2022-06-17 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:17 --> Total execution time: 0.0501
DEBUG - 2022-06-17 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:17 --> Total execution time: 0.0493
DEBUG - 2022-06-17 08:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:19 --> Total execution time: 0.0508
DEBUG - 2022-06-17 08:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:21 --> Total execution time: 0.0381
DEBUG - 2022-06-17 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:24 --> Total execution time: 0.0467
DEBUG - 2022-06-17 08:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 08:40:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:31 --> Total execution time: 0.0356
DEBUG - 2022-06-17 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:31 --> Total execution time: 0.0423
DEBUG - 2022-06-17 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:31 --> Total execution time: 0.0721
DEBUG - 2022-06-17 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:35 --> Total execution time: 0.0607
DEBUG - 2022-06-17 08:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:39 --> Total execution time: 0.0503
DEBUG - 2022-06-17 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:49 --> Total execution time: 0.0724
DEBUG - 2022-06-17 08:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:10:58 --> Total execution time: 0.0484
DEBUG - 2022-06-17 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:11:07 --> Total execution time: 0.0441
DEBUG - 2022-06-17 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:11:17 --> Total execution time: 0.0748
DEBUG - 2022-06-17 08:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:12:58 --> Total execution time: 0.1112
DEBUG - 2022-06-17 08:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:13:19 --> Total execution time: 0.0516
DEBUG - 2022-06-17 08:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:13:25 --> Total execution time: 0.0477
DEBUG - 2022-06-17 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:13:35 --> Total execution time: 0.0534
DEBUG - 2022-06-17 08:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:13:45 --> Total execution time: 0.0597
DEBUG - 2022-06-17 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:13:50 --> Total execution time: 0.0899
DEBUG - 2022-06-17 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:43:58 --> Total execution time: 0.0628
DEBUG - 2022-06-17 08:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:14:01 --> Total execution time: 0.0638
DEBUG - 2022-06-17 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:14:06 --> Total execution time: 0.0881
DEBUG - 2022-06-17 08:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:14:27 --> Total execution time: 0.0631
DEBUG - 2022-06-17 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:14:31 --> Total execution time: 0.0509
DEBUG - 2022-06-17 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:14:35 --> Total execution time: 0.0547
DEBUG - 2022-06-17 08:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:14:53 --> Total execution time: 0.0732
DEBUG - 2022-06-17 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:19 --> Total execution time: 0.0839
DEBUG - 2022-06-17 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:20 --> Total execution time: 0.0703
DEBUG - 2022-06-17 08:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:24 --> Total execution time: 0.0512
DEBUG - 2022-06-17 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:33 --> Total execution time: 0.0630
DEBUG - 2022-06-17 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:39 --> Total execution time: 0.0348
DEBUG - 2022-06-17 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:48 --> Total execution time: 0.0420
DEBUG - 2022-06-17 08:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:53 --> Total execution time: 0.0423
DEBUG - 2022-06-17 08:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:46:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:16:54 --> Total execution time: 0.0307
DEBUG - 2022-06-17 08:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:17:23 --> Total execution time: 0.0567
DEBUG - 2022-06-17 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:17:56 --> Total execution time: 0.0455
DEBUG - 2022-06-17 08:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:48:17 --> Total execution time: 0.0567
DEBUG - 2022-06-17 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:48:32 --> Total execution time: 0.0937
DEBUG - 2022-06-17 08:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:18:36 --> Total execution time: 0.0517
DEBUG - 2022-06-17 08:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:49:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:19:26 --> Total execution time: 0.0426
DEBUG - 2022-06-17 08:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:19:36 --> Total execution time: 0.0534
DEBUG - 2022-06-17 08:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:20:32 --> Total execution time: 0.0720
DEBUG - 2022-06-17 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:21:06 --> Total execution time: 0.1951
DEBUG - 2022-06-17 08:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:21:07 --> Total execution time: 0.0807
DEBUG - 2022-06-17 08:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:51:38 --> Total execution time: 0.0599
DEBUG - 2022-06-17 08:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:22:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 08:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:22:02 --> Total execution time: 0.0776
DEBUG - 2022-06-17 08:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:22:12 --> Total execution time: 0.0805
DEBUG - 2022-06-17 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:22:31 --> Total execution time: 0.0933
DEBUG - 2022-06-17 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:22:49 --> Total execution time: 0.1004
DEBUG - 2022-06-17 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:22:59 --> Total execution time: 0.0685
DEBUG - 2022-06-17 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 08:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:23:05 --> Total execution time: 0.0889
DEBUG - 2022-06-17 08:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:23:15 --> Total execution time: 0.0737
DEBUG - 2022-06-17 08:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:23:18 --> Total execution time: 0.0915
DEBUG - 2022-06-17 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:23:22 --> Total execution time: 0.0553
DEBUG - 2022-06-17 08:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:23:26 --> Total execution time: 0.0760
DEBUG - 2022-06-17 08:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:23:30 --> Total execution time: 0.0530
DEBUG - 2022-06-17 08:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:28:34 --> Total execution time: 0.1670
DEBUG - 2022-06-17 08:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:28:37 --> Total execution time: 0.0396
DEBUG - 2022-06-17 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:28:48 --> Total execution time: 0.0535
DEBUG - 2022-06-17 08:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:00 --> Total execution time: 0.0936
DEBUG - 2022-06-17 08:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:07 --> Total execution time: 0.0620
DEBUG - 2022-06-17 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:08 --> Total execution time: 0.0513
DEBUG - 2022-06-17 08:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:11 --> Total execution time: 0.0501
DEBUG - 2022-06-17 08:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:16 --> Total execution time: 0.0410
DEBUG - 2022-06-17 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:41 --> Total execution time: 0.0353
DEBUG - 2022-06-17 08:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 08:59:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 08:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 08:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:56 --> Total execution time: 0.0385
DEBUG - 2022-06-17 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:00 --> Total execution time: 0.0645
DEBUG - 2022-06-17 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:02 --> Total execution time: 0.0502
DEBUG - 2022-06-17 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:15 --> Total execution time: 0.0451
DEBUG - 2022-06-17 09:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:26 --> Total execution time: 0.0422
DEBUG - 2022-06-17 09:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:31 --> Total execution time: 0.0670
DEBUG - 2022-06-17 09:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:40 --> Total execution time: 0.0490
DEBUG - 2022-06-17 09:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:40 --> Total execution time: 0.0388
DEBUG - 2022-06-17 09:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:30:48 --> Total execution time: 0.0783
DEBUG - 2022-06-17 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:00:49 --> Total execution time: 0.0484
DEBUG - 2022-06-17 09:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:00:51 --> Total execution time: 0.0444
DEBUG - 2022-06-17 09:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:00:51 --> Total execution time: 0.0875
DEBUG - 2022-06-17 09:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:31:06 --> Total execution time: 0.0489
DEBUG - 2022-06-17 09:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:31:06 --> Total execution time: 0.0393
DEBUG - 2022-06-17 09:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:31:17 --> Total execution time: 0.0682
DEBUG - 2022-06-17 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:35:01 --> Total execution time: 0.1108
DEBUG - 2022-06-17 09:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:35:07 --> Total execution time: 0.0334
DEBUG - 2022-06-17 09:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:35:07 --> Total execution time: 0.0394
DEBUG - 2022-06-17 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:05:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:35:37 --> Total execution time: 0.0307
DEBUG - 2022-06-17 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:35:37 --> Total execution time: 0.0303
DEBUG - 2022-06-17 09:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:05:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 09:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:35:47 --> Total execution time: 0.0442
DEBUG - 2022-06-17 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:06:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:36:51 --> Total execution time: 0.0334
DEBUG - 2022-06-17 09:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:09:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:39:37 --> Total execution time: 0.0843
DEBUG - 2022-06-17 09:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:09:47 --> Total execution time: 0.0665
DEBUG - 2022-06-17 09:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:09:49 --> Total execution time: 0.0581
DEBUG - 2022-06-17 09:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:09:49 --> Total execution time: 0.1127
DEBUG - 2022-06-17 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:11:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 09:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:41:03 --> Total execution time: 1.9621
DEBUG - 2022-06-17 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:11:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:11:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 09:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:42:54 --> Total execution time: 0.0529
DEBUG - 2022-06-17 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:13:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:43:21 --> Total execution time: 0.0947
DEBUG - 2022-06-17 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:43:39 --> Total execution time: 0.1186
DEBUG - 2022-06-17 09:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:43:40 --> Total execution time: 0.0647
DEBUG - 2022-06-17 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:43:43 --> Total execution time: 0.0613
DEBUG - 2022-06-17 09:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:43:44 --> Total execution time: 0.0701
DEBUG - 2022-06-17 09:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:44:23 --> Total execution time: 0.0507
DEBUG - 2022-06-17 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:44:24 --> Total execution time: 0.0474
DEBUG - 2022-06-17 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:45:01 --> Total execution time: 0.0292
DEBUG - 2022-06-17 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:45:02 --> Total execution time: 0.0629
DEBUG - 2022-06-17 09:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:45:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 09:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:45:04 --> Total execution time: 0.0616
DEBUG - 2022-06-17 09:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:45:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 19:45:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 19:45:05 --> Total execution time: 0.2047
DEBUG - 2022-06-17 09:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:15:30 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 09:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:47:55 --> Total execution time: 0.1177
DEBUG - 2022-06-17 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:18:03 --> 404 Page Not Found: Lessons/facebook-ads-account-issue
DEBUG - 2022-06-17 09:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:18:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:50:01 --> Total execution time: 0.0624
DEBUG - 2022-06-17 09:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:20:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:23:57 --> 404 Page Not Found: Wp-configphp/index
DEBUG - 2022-06-17 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:23:57 --> 404 Page Not Found: Wp-configtxt/index
DEBUG - 2022-06-17 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:25:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:55:56 --> Total execution time: 0.0835
DEBUG - 2022-06-17 09:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:57:36 --> Total execution time: 0.1099
DEBUG - 2022-06-17 09:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:27:51 --> Total execution time: 0.0415
DEBUG - 2022-06-17 09:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:57:54 --> Total execution time: 0.0549
DEBUG - 2022-06-17 09:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:58:21 --> Total execution time: 0.0454
DEBUG - 2022-06-17 09:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:31:10 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:01:10 --> Total execution time: 0.0897
DEBUG - 2022-06-17 09:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:31:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:01:13 --> Total execution time: 0.0408
DEBUG - 2022-06-17 09:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:31:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:01:18 --> Total execution time: 0.0415
DEBUG - 2022-06-17 09:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:01:43 --> Total execution time: 0.0314
DEBUG - 2022-06-17 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:02:05 --> Total execution time: 0.0463
DEBUG - 2022-06-17 09:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:02:26 --> Total execution time: 0.0505
DEBUG - 2022-06-17 09:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:02:45 --> Total execution time: 0.0653
DEBUG - 2022-06-17 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:03:01 --> Total execution time: 0.0460
DEBUG - 2022-06-17 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:03:01 --> Total execution time: 0.0813
DEBUG - 2022-06-17 09:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:03:20 --> Total execution time: 0.0663
DEBUG - 2022-06-17 09:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:33:35 --> Total execution time: 0.0504
DEBUG - 2022-06-17 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:03:39 --> Total execution time: 0.0680
DEBUG - 2022-06-17 09:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:03:41 --> Total execution time: 0.0592
DEBUG - 2022-06-17 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:03:52 --> Total execution time: 0.0399
DEBUG - 2022-06-17 09:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:34:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:04:14 --> Total execution time: 0.0652
DEBUG - 2022-06-17 09:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:04:15 --> Total execution time: 0.0649
DEBUG - 2022-06-17 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:04:18 --> Total execution time: 0.0686
DEBUG - 2022-06-17 09:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:04:25 --> Total execution time: 0.0408
DEBUG - 2022-06-17 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:04:38 --> Total execution time: 0.0602
DEBUG - 2022-06-17 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:06:49 --> Total execution time: 0.0390
DEBUG - 2022-06-17 09:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:10:20 --> Total execution time: 0.0934
DEBUG - 2022-06-17 09:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:40:37 --> Total execution time: 0.0452
DEBUG - 2022-06-17 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:42 --> Total execution time: 0.0658
DEBUG - 2022-06-17 09:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:40:43 --> Total execution time: 0.0608
DEBUG - 2022-06-17 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:10:51 --> Total execution time: 0.0290
DEBUG - 2022-06-17 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:10:59 --> Total execution time: 0.0506
DEBUG - 2022-06-17 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:06 --> Total execution time: 0.0442
DEBUG - 2022-06-17 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:11 --> Total execution time: 0.0727
DEBUG - 2022-06-17 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:12 --> Total execution time: 0.1010
DEBUG - 2022-06-17 09:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:29 --> Total execution time: 0.0478
DEBUG - 2022-06-17 09:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:44 --> Total execution time: 0.0501
DEBUG - 2022-06-17 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:56 --> Total execution time: 0.0481
DEBUG - 2022-06-17 09:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:12:02 --> Total execution time: 0.0778
DEBUG - 2022-06-17 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:12:08 --> Total execution time: 0.0658
DEBUG - 2022-06-17 09:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:12:14 --> Total execution time: 0.0509
DEBUG - 2022-06-17 09:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:12:23 --> Total execution time: 0.0705
DEBUG - 2022-06-17 09:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:42:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:12:44 --> Total execution time: 0.0576
DEBUG - 2022-06-17 09:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:42:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:12:50 --> Total execution time: 0.0317
DEBUG - 2022-06-17 09:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:03 --> Total execution time: 0.0425
DEBUG - 2022-06-17 09:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:18 --> Total execution time: 0.0514
DEBUG - 2022-06-17 09:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:22 --> Total execution time: 0.0434
DEBUG - 2022-06-17 09:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:43:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:43:23 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:25 --> Total execution time: 0.0583
DEBUG - 2022-06-17 09:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:47 --> Total execution time: 0.0642
DEBUG - 2022-06-17 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:14:09 --> Total execution time: 0.0635
DEBUG - 2022-06-17 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:14:46 --> Total execution time: 0.2456
DEBUG - 2022-06-17 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:44:51 --> Total execution time: 0.0630
DEBUG - 2022-06-17 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:44:52 --> Total execution time: 0.0504
DEBUG - 2022-06-17 09:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:44:52 --> Total execution time: 0.0968
DEBUG - 2022-06-17 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:44:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:14:55 --> Total execution time: 0.0307
DEBUG - 2022-06-17 09:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:45:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:15:08 --> Total execution time: 0.1019
DEBUG - 2022-06-17 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:15:18 --> Total execution time: 0.0527
DEBUG - 2022-06-17 09:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:16:18 --> Total execution time: 0.0402
DEBUG - 2022-06-17 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:53:40 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:23:41 --> Total execution time: 0.1059
DEBUG - 2022-06-17 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:23:42 --> Total execution time: 0.0432
DEBUG - 2022-06-17 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:24:00 --> Total execution time: 0.0414
DEBUG - 2022-06-17 09:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:24:05 --> Total execution time: 0.0401
DEBUG - 2022-06-17 09:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:26:12 --> Total execution time: 0.0833
DEBUG - 2022-06-17 09:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:26:13 --> Total execution time: 0.0389
DEBUG - 2022-06-17 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:26:15 --> Total execution time: 0.0387
DEBUG - 2022-06-17 09:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:26:46 --> Total execution time: 1.9553
DEBUG - 2022-06-17 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 09:56:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:57:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:27:30 --> Total execution time: 0.0301
DEBUG - 2022-06-17 09:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:27:33 --> Total execution time: 0.0408
DEBUG - 2022-06-17 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:28:47 --> Total execution time: 0.0457
DEBUG - 2022-06-17 09:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:28:54 --> Total execution time: 0.0311
DEBUG - 2022-06-17 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:20 --> Total execution time: 0.0557
DEBUG - 2022-06-17 09:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 09:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 09:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:34 --> Total execution time: 0.0819
DEBUG - 2022-06-17 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:02 --> Total execution time: 0.0772
DEBUG - 2022-06-17 10:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:11 --> Total execution time: 0.0813
DEBUG - 2022-06-17 10:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:00:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:27 --> Total execution time: 0.0332
DEBUG - 2022-06-17 10:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:00:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:43 --> Total execution time: 0.0512
DEBUG - 2022-06-17 10:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:31:01 --> Total execution time: 0.1078
DEBUG - 2022-06-17 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:31:21 --> Total execution time: 0.1121
DEBUG - 2022-06-17 10:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:31:22 --> Total execution time: 0.0550
DEBUG - 2022-06-17 10:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:01:37 --> Total execution time: 0.0538
DEBUG - 2022-06-17 10:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:32:25 --> Total execution time: 0.0533
DEBUG - 2022-06-17 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:02:55 --> Total execution time: 0.0399
DEBUG - 2022-06-17 10:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:47 --> Total execution time: 0.0818
DEBUG - 2022-06-17 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:59 --> Total execution time: 0.0564
DEBUG - 2022-06-17 10:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:04:38 --> Total execution time: 0.0417
DEBUG - 2022-06-17 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:35:08 --> Total execution time: 0.0917
DEBUG - 2022-06-17 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:35:37 --> Total execution time: 0.0594
DEBUG - 2022-06-17 10:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:35:42 --> Total execution time: 0.0841
DEBUG - 2022-06-17 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:36:18 --> Total execution time: 0.0370
DEBUG - 2022-06-17 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:06:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:36:29 --> Total execution time: 0.1120
DEBUG - 2022-06-17 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:41:53 --> Total execution time: 0.1118
DEBUG - 2022-06-17 10:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:41:56 --> Total execution time: 0.0712
DEBUG - 2022-06-17 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:44:11 --> Total execution time: 0.1853
DEBUG - 2022-06-17 10:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:44:17 --> Total execution time: 0.0595
DEBUG - 2022-06-17 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:44:33 --> Total execution time: 0.0848
DEBUG - 2022-06-17 10:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:45:38 --> Total execution time: 0.1092
DEBUG - 2022-06-17 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:45:45 --> Total execution time: 0.0515
DEBUG - 2022-06-17 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:49:24 --> Total execution time: 0.1376
DEBUG - 2022-06-17 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:19:46 --> Total execution time: 0.0667
DEBUG - 2022-06-17 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:19:58 --> Total execution time: 0.0971
DEBUG - 2022-06-17 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:20:17 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:50:17 --> Total execution time: 0.0406
DEBUG - 2022-06-17 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:20:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:50:50 --> Total execution time: 0.0408
DEBUG - 2022-06-17 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:20:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:50:50 --> Total execution time: 0.0317
DEBUG - 2022-06-17 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:20:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:50:52 --> Total execution time: 0.0324
DEBUG - 2022-06-17 10:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:51:04 --> Total execution time: 0.0335
DEBUG - 2022-06-17 10:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:51:35 --> Total execution time: 0.0472
DEBUG - 2022-06-17 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:51:47 --> Total execution time: 0.0804
DEBUG - 2022-06-17 10:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:17 --> Total execution time: 0.0522
DEBUG - 2022-06-17 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:21 --> Total execution time: 0.0424
DEBUG - 2022-06-17 10:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:26 --> Total execution time: 0.0483
DEBUG - 2022-06-17 10:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:26 --> Total execution time: 0.0663
DEBUG - 2022-06-17 10:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:27 --> Total execution time: 0.0455
DEBUG - 2022-06-17 10:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:27 --> Total execution time: 0.0438
DEBUG - 2022-06-17 10:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:28 --> Total execution time: 0.0421
DEBUG - 2022-06-17 10:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:28 --> Total execution time: 0.0446
DEBUG - 2022-06-17 10:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:31 --> Total execution time: 0.0598
DEBUG - 2022-06-17 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:52:44 --> Total execution time: 0.0436
DEBUG - 2022-06-17 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:06 --> Total execution time: 0.0975
DEBUG - 2022-06-17 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:06 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:53:06 --> Total execution time: 0.1626
DEBUG - 2022-06-17 10:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:06 --> Total execution time: 0.2510
DEBUG - 2022-06-17 10:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:06 --> Total execution time: 0.2482
DEBUG - 2022-06-17 10:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:07 --> Total execution time: 0.0965
DEBUG - 2022-06-17 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:08 --> Total execution time: 0.0588
DEBUG - 2022-06-17 10:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:12 --> Total execution time: 0.0530
DEBUG - 2022-06-17 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:28 --> Total execution time: 0.0560
DEBUG - 2022-06-17 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:38 --> Total execution time: 0.0416
DEBUG - 2022-06-17 10:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:45 --> Total execution time: 0.1698
DEBUG - 2022-06-17 10:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:45 --> Total execution time: 0.0478
DEBUG - 2022-06-17 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:59 --> Total execution time: 0.0456
DEBUG - 2022-06-17 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 10:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:00 --> Total execution time: 0.0468
DEBUG - 2022-06-17 10:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:04 --> Total execution time: 0.0738
DEBUG - 2022-06-17 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:10 --> Total execution time: 0.1144
DEBUG - 2022-06-17 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 10:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:42 --> Total execution time: 0.0758
DEBUG - 2022-06-17 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:51 --> Total execution time: 0.0756
DEBUG - 2022-06-17 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:05 --> Total execution time: 0.0842
DEBUG - 2022-06-17 10:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:09 --> Total execution time: 0.0701
DEBUG - 2022-06-17 10:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:13 --> Total execution time: 0.0783
DEBUG - 2022-06-17 10:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:24 --> Total execution time: 0.0559
DEBUG - 2022-06-17 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:31 --> Total execution time: 0.0403
DEBUG - 2022-06-17 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:33 --> Total execution time: 0.0559
DEBUG - 2022-06-17 10:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:35 --> Total execution time: 0.0774
DEBUG - 2022-06-17 10:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:54 --> Total execution time: 0.0435
DEBUG - 2022-06-17 10:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:55:54 --> Total execution time: 0.0552
DEBUG - 2022-06-17 10:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:04 --> Total execution time: 0.0376
DEBUG - 2022-06-17 10:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:05 --> Total execution time: 0.0869
DEBUG - 2022-06-17 10:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:14 --> Total execution time: 0.0459
DEBUG - 2022-06-17 10:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:19 --> Total execution time: 0.0730
DEBUG - 2022-06-17 10:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:20 --> Total execution time: 0.0557
DEBUG - 2022-06-17 10:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:21 --> Total execution time: 0.0358
DEBUG - 2022-06-17 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:23 --> Total execution time: 0.0427
DEBUG - 2022-06-17 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:26 --> Total execution time: 0.0422
DEBUG - 2022-06-17 10:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:29 --> Total execution time: 0.0465
DEBUG - 2022-06-17 10:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:35 --> Total execution time: 0.1683
DEBUG - 2022-06-17 10:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:41 --> Total execution time: 0.0819
DEBUG - 2022-06-17 10:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:42 --> Total execution time: 0.0443
DEBUG - 2022-06-17 10:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:43 --> Total execution time: 0.0673
DEBUG - 2022-06-17 10:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:47 --> Total execution time: 0.0501
DEBUG - 2022-06-17 10:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:56:54 --> Total execution time: 0.0426
DEBUG - 2022-06-17 10:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:02 --> Total execution time: 0.0438
DEBUG - 2022-06-17 10:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:11 --> Total execution time: 0.0772
DEBUG - 2022-06-17 10:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:12 --> Total execution time: 0.0751
DEBUG - 2022-06-17 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:17 --> Total execution time: 0.0450
DEBUG - 2022-06-17 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:20 --> Total execution time: 0.0405
DEBUG - 2022-06-17 10:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:28 --> Total execution time: 0.0435
DEBUG - 2022-06-17 10:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:29 --> Total execution time: 0.0274
DEBUG - 2022-06-17 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:31 --> Total execution time: 0.0331
DEBUG - 2022-06-17 10:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:33 --> Total execution time: 0.0227
DEBUG - 2022-06-17 10:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:38 --> Total execution time: 0.0600
DEBUG - 2022-06-17 10:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:38 --> Total execution time: 0.0369
DEBUG - 2022-06-17 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:47 --> Total execution time: 0.0407
DEBUG - 2022-06-17 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:47 --> Total execution time: 0.0300
DEBUG - 2022-06-17 10:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:53 --> Total execution time: 0.0490
DEBUG - 2022-06-17 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:58:00 --> Total execution time: 0.0640
DEBUG - 2022-06-17 10:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:58:06 --> Total execution time: 0.0732
DEBUG - 2022-06-17 10:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:28:10 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:58:10 --> Total execution time: 0.0653
DEBUG - 2022-06-17 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:58:14 --> Total execution time: 0.1093
DEBUG - 2022-06-17 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:58:51 --> Total execution time: 0.0382
DEBUG - 2022-06-17 10:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:59:08 --> Total execution time: 0.0419
DEBUG - 2022-06-17 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:59:30 --> Total execution time: 0.0638
DEBUG - 2022-06-17 10:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:59:36 --> Total execution time: 0.0462
DEBUG - 2022-06-17 10:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:59:40 --> Total execution time: 0.0526
DEBUG - 2022-06-17 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:59:45 --> Total execution time: 0.0437
DEBUG - 2022-06-17 10:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:59:52 --> Total execution time: 0.0382
DEBUG - 2022-06-17 10:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:30:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:00:01 --> Total execution time: 0.1211
DEBUG - 2022-06-17 10:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:30:15 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:00:15 --> Total execution time: 0.0458
DEBUG - 2022-06-17 10:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:00:24 --> Total execution time: 0.0424
DEBUG - 2022-06-17 10:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:30:40 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:00:40 --> Total execution time: 0.0507
DEBUG - 2022-06-17 10:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:31:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:01:04 --> Total execution time: 0.0558
DEBUG - 2022-06-17 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:31:32 --> Total execution time: 0.0421
DEBUG - 2022-06-17 10:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:33:16 --> Total execution time: 0.0501
DEBUG - 2022-06-17 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:33:56 --> Total execution time: 0.0788
DEBUG - 2022-06-17 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:33:56 --> Total execution time: 0.1079
DEBUG - 2022-06-17 10:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:07 --> Total execution time: 0.1737
DEBUG - 2022-06-17 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:26 --> Total execution time: 0.0982
DEBUG - 2022-06-17 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:39 --> Total execution time: 0.0518
DEBUG - 2022-06-17 10:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:46 --> Total execution time: 0.0537
DEBUG - 2022-06-17 10:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:50 --> Total execution time: 0.0469
DEBUG - 2022-06-17 10:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:35:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:05:21 --> Total execution time: 0.0399
DEBUG - 2022-06-17 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:05:54 --> Total execution time: 0.0548
DEBUG - 2022-06-17 10:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:06 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:06:06 --> Total execution time: 0.0442
DEBUG - 2022-06-17 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:08 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:06:08 --> Total execution time: 0.0297
DEBUG - 2022-06-17 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:18 --> Total execution time: 0.0468
DEBUG - 2022-06-17 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:22 --> Total execution time: 0.0485
DEBUG - 2022-06-17 10:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:22 --> Total execution time: 0.0691
DEBUG - 2022-06-17 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:44 --> Total execution time: 0.0421
DEBUG - 2022-06-17 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:36:45 --> Total execution time: 0.0389
DEBUG - 2022-06-17 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:37:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:07:49 --> Total execution time: 1.9852
DEBUG - 2022-06-17 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 10:37:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:08:50 --> Total execution time: 0.0524
DEBUG - 2022-06-17 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:02 --> Total execution time: 0.0774
DEBUG - 2022-06-17 10:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:07 --> Total execution time: 0.0601
DEBUG - 2022-06-17 10:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:13 --> Total execution time: 0.0448
DEBUG - 2022-06-17 10:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:23 --> Total execution time: 0.0600
DEBUG - 2022-06-17 10:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:30 --> Total execution time: 0.0686
DEBUG - 2022-06-17 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:36 --> Total execution time: 0.0439
DEBUG - 2022-06-17 10:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:49 --> Total execution time: 1.5133
DEBUG - 2022-06-17 10:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:34 --> Total execution time: 0.1092
DEBUG - 2022-06-17 10:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:39 --> Total execution time: 0.0479
DEBUG - 2022-06-17 10:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:50 --> Total execution time: 0.0515
DEBUG - 2022-06-17 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:28 --> Total execution time: 0.1115
DEBUG - 2022-06-17 10:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:31 --> Total execution time: 0.0674
DEBUG - 2022-06-17 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:34 --> Total execution time: 0.0443
DEBUG - 2022-06-17 10:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:40 --> Total execution time: 0.0380
DEBUG - 2022-06-17 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:12:42 --> Total execution time: 0.0442
DEBUG - 2022-06-17 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:13:02 --> Total execution time: 0.0405
DEBUG - 2022-06-17 10:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:14:36 --> Total execution time: 0.0583
DEBUG - 2022-06-17 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:00 --> Total execution time: 0.0455
DEBUG - 2022-06-17 10:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:02 --> Total execution time: 0.0987
DEBUG - 2022-06-17 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:13 --> Total execution time: 0.0535
DEBUG - 2022-06-17 10:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:58 --> Total execution time: 0.0993
DEBUG - 2022-06-17 10:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:16:02 --> Total execution time: 0.0529
DEBUG - 2022-06-17 10:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:16:07 --> Total execution time: 0.0657
DEBUG - 2022-06-17 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:16:28 --> Total execution time: 0.0619
DEBUG - 2022-06-17 10:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:16:32 --> Total execution time: 0.0463
DEBUG - 2022-06-17 10:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:52:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:22:33 --> Total execution time: 0.1159
DEBUG - 2022-06-17 10:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:52:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:22:33 --> Total execution time: 0.0311
DEBUG - 2022-06-17 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 10:53:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:55:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 10:55:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 10:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:25:46 --> Total execution time: 0.0827
DEBUG - 2022-06-17 10:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:25:49 --> Total execution time: 0.0441
DEBUG - 2022-06-17 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:19 --> Total execution time: 0.0343
DEBUG - 2022-06-17 10:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:26:28 --> Total execution time: 0.0341
DEBUG - 2022-06-17 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:58 --> Total execution time: 0.0460
DEBUG - 2022-06-17 10:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:56:58 --> Total execution time: 0.0910
DEBUG - 2022-06-17 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:14 --> Total execution time: 0.0413
DEBUG - 2022-06-17 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:22 --> Total execution time: 0.0401
DEBUG - 2022-06-17 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:34 --> Total execution time: 0.0403
DEBUG - 2022-06-17 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:45 --> Total execution time: 0.0413
DEBUG - 2022-06-17 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 10:57:47 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:58 --> Total execution time: 0.0377
DEBUG - 2022-06-17 10:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:59 --> Total execution time: 0.0414
DEBUG - 2022-06-17 10:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:59 --> Total execution time: 0.0878
DEBUG - 2022-06-17 10:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:59 --> Total execution time: 0.1168
DEBUG - 2022-06-17 10:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:57:59 --> Total execution time: 0.1504
DEBUG - 2022-06-17 10:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:00 --> Total execution time: 0.0450
DEBUG - 2022-06-17 10:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:00 --> Total execution time: 0.0439
DEBUG - 2022-06-17 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:01 --> Total execution time: 0.0533
DEBUG - 2022-06-17 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:01 --> Total execution time: 0.0737
DEBUG - 2022-06-17 10:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:02 --> Total execution time: 0.0584
DEBUG - 2022-06-17 10:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:28:02 --> Total execution time: 0.0506
DEBUG - 2022-06-17 10:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:03 --> Total execution time: 0.0568
DEBUG - 2022-06-17 10:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:04 --> Total execution time: 0.0462
DEBUG - 2022-06-17 10:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:04 --> Total execution time: 0.0541
DEBUG - 2022-06-17 10:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:05 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:28:05 --> Total execution time: 0.0403
DEBUG - 2022-06-17 10:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 10:58:48 --> Total execution time: 0.0397
DEBUG - 2022-06-17 10:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:59:16 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:16 --> Total execution time: 0.0791
DEBUG - 2022-06-17 10:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:59:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:36 --> Total execution time: 0.0415
DEBUG - 2022-06-17 10:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:59:42 --> No URI present. Default controller set.
DEBUG - 2022-06-17 10:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:42 --> Total execution time: 0.1060
DEBUG - 2022-06-17 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 10:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 10:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:58 --> Total execution time: 0.1904
DEBUG - 2022-06-17 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:02 --> Total execution time: 0.0710
DEBUG - 2022-06-17 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:06 --> Total execution time: 0.1655
DEBUG - 2022-06-17 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:00:07 --> Total execution time: 0.0808
DEBUG - 2022-06-17 11:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:00:08 --> Total execution time: 0.0512
DEBUG - 2022-06-17 11:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:00:09 --> Total execution time: 0.0895
DEBUG - 2022-06-17 11:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:09 --> Total execution time: 0.0472
DEBUG - 2022-06-17 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:24 --> Total execution time: 0.1174
DEBUG - 2022-06-17 11:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:27 --> Total execution time: 0.0485
DEBUG - 2022-06-17 11:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:38 --> Total execution time: 0.0546
DEBUG - 2022-06-17 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:41 --> Total execution time: 0.0944
DEBUG - 2022-06-17 11:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 11:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:42 --> Total execution time: 0.0562
DEBUG - 2022-06-17 11:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:42 --> Total execution time: 0.0667
DEBUG - 2022-06-17 11:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:30:44 --> Total execution time: 0.0703
DEBUG - 2022-06-17 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:00:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:31:01 --> Total execution time: 1.9121
DEBUG - 2022-06-17 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 11:01:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:31:32 --> Total execution time: 0.1119
DEBUG - 2022-06-17 11:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:01:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:31:52 --> Total execution time: 0.0335
DEBUG - 2022-06-17 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:33:45 --> Total execution time: 0.0452
DEBUG - 2022-06-17 11:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:04:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:34:29 --> Total execution time: 0.0338
DEBUG - 2022-06-17 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:05:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:35:07 --> Total execution time: 0.0606
DEBUG - 2022-06-17 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:05:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:35:51 --> Total execution time: 0.0396
DEBUG - 2022-06-17 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:36:03 --> Total execution time: 0.0417
DEBUG - 2022-06-17 11:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:36:16 --> Total execution time: 0.0471
DEBUG - 2022-06-17 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:36:37 --> Total execution time: 0.0509
DEBUG - 2022-06-17 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:36:46 --> Total execution time: 0.1022
DEBUG - 2022-06-17 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:40:22 --> Total execution time: 0.0809
DEBUG - 2022-06-17 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:10:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:40:35 --> Total execution time: 0.0601
DEBUG - 2022-06-17 11:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:40:37 --> Total execution time: 0.0394
DEBUG - 2022-06-17 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:40:39 --> Total execution time: 0.0377
DEBUG - 2022-06-17 11:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:40:41 --> Total execution time: 0.0420
DEBUG - 2022-06-17 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:41:05 --> Total execution time: 0.0439
DEBUG - 2022-06-17 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:41:24 --> Total execution time: 0.0380
DEBUG - 2022-06-17 11:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:41:48 --> Total execution time: 0.0468
DEBUG - 2022-06-17 11:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:42:26 --> Total execution time: 0.0371
DEBUG - 2022-06-17 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:42:41 --> Total execution time: 0.0396
DEBUG - 2022-06-17 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:42:59 --> Total execution time: 0.0432
DEBUG - 2022-06-17 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:43:26 --> Total execution time: 0.0468
DEBUG - 2022-06-17 11:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:44:19 --> Total execution time: 0.0528
DEBUG - 2022-06-17 11:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:44:27 --> Total execution time: 0.0638
DEBUG - 2022-06-17 11:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:15:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:45:57 --> Total execution time: 0.0395
DEBUG - 2022-06-17 11:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:03 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:46:03 --> Total execution time: 0.0396
DEBUG - 2022-06-17 11:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:46:11 --> Total execution time: 0.1846
DEBUG - 2022-06-17 11:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:46:22 --> Total execution time: 0.0477
DEBUG - 2022-06-17 11:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:16:24 --> Total execution time: 0.0488
DEBUG - 2022-06-17 11:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:46:31 --> Total execution time: 0.0590
DEBUG - 2022-06-17 11:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:42 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:46:42 --> Total execution time: 0.0554
DEBUG - 2022-06-17 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:16:56 --> Total execution time: 0.0424
DEBUG - 2022-06-17 11:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:16:56 --> Total execution time: 0.0787
DEBUG - 2022-06-17 11:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:47:18 --> Total execution time: 1.4638
DEBUG - 2022-06-17 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 11:17:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:47:27 --> Total execution time: 0.0475
DEBUG - 2022-06-17 11:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:47:37 --> Total execution time: 0.0412
DEBUG - 2022-06-17 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:47:45 --> Total execution time: 0.0736
DEBUG - 2022-06-17 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:17:57 --> Total execution time: 0.0702
DEBUG - 2022-06-17 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:17:58 --> Total execution time: 0.0443
DEBUG - 2022-06-17 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:17:58 --> Total execution time: 0.0913
DEBUG - 2022-06-17 11:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:03 --> Total execution time: 0.0445
DEBUG - 2022-06-17 11:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:05 --> Total execution time: 0.0443
DEBUG - 2022-06-17 11:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:05 --> Total execution time: 0.0770
DEBUG - 2022-06-17 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:24 --> Total execution time: 0.0508
DEBUG - 2022-06-17 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:29 --> Total execution time: 0.0514
DEBUG - 2022-06-17 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:30 --> Total execution time: 0.0429
DEBUG - 2022-06-17 11:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:31 --> Total execution time: 0.0636
DEBUG - 2022-06-17 11:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:31 --> Total execution time: 0.0420
DEBUG - 2022-06-17 11:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:31 --> Total execution time: 0.0814
DEBUG - 2022-06-17 11:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:34 --> Total execution time: 0.0353
DEBUG - 2022-06-17 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:41 --> Total execution time: 0.0409
DEBUG - 2022-06-17 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:19:44 --> Total execution time: 0.0413
DEBUG - 2022-06-17 11:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:53 --> Total execution time: 0.0632
DEBUG - 2022-06-17 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:20:01 --> Total execution time: 0.0930
DEBUG - 2022-06-17 11:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:20:01 --> Total execution time: 0.1969
DEBUG - 2022-06-17 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:05 --> Total execution time: 0.0376
DEBUG - 2022-06-17 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:08 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:08 --> Total execution time: 0.0442
DEBUG - 2022-06-17 11:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:12 --> Total execution time: 0.0431
DEBUG - 2022-06-17 11:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:23 --> Total execution time: 0.0434
DEBUG - 2022-06-17 11:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 11:20:24 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 11:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:27 --> Total execution time: 0.0372
DEBUG - 2022-06-17 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:37 --> Total execution time: 0.0438
DEBUG - 2022-06-17 11:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:50:44 --> Total execution time: 0.0463
DEBUG - 2022-06-17 11:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:21:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:51:01 --> Total execution time: 0.0472
DEBUG - 2022-06-17 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:21:34 --> Total execution time: 0.0382
DEBUG - 2022-06-17 11:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:21:36 --> Total execution time: 0.0414
DEBUG - 2022-06-17 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:21:38 --> Total execution time: 0.0401
DEBUG - 2022-06-17 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:52:05 --> Total execution time: 0.0522
DEBUG - 2022-06-17 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:22:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:52:50 --> Total execution time: 0.0362
DEBUG - 2022-06-17 11:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:23:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:53:10 --> Total execution time: 1.8843
DEBUG - 2022-06-17 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:54:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:54:49 --> Total execution time: 0.0439
DEBUG - 2022-06-17 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:54:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 21:54:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 21:54:52 --> Total execution time: 0.2612
DEBUG - 2022-06-17 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:26:22 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:56:22 --> Total execution time: 0.0384
DEBUG - 2022-06-17 11:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:27:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:57:07 --> Total execution time: 0.0369
DEBUG - 2022-06-17 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:30:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:00:30 --> Total execution time: 0.0912
DEBUG - 2022-06-17 11:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:00:34 --> Total execution time: 0.0338
DEBUG - 2022-06-17 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:30:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:00:45 --> Total execution time: 0.0466
DEBUG - 2022-06-17 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:00:46 --> Total execution time: 0.0520
DEBUG - 2022-06-17 11:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:04 --> Total execution time: 0.0556
DEBUG - 2022-06-17 11:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:40 --> Total execution time: 0.0763
DEBUG - 2022-06-17 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:42 --> Total execution time: 0.0377
DEBUG - 2022-06-17 11:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:47 --> Total execution time: 0.0393
DEBUG - 2022-06-17 11:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:32:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:02:33 --> Total execution time: 0.0615
DEBUG - 2022-06-17 11:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:02:56 --> Total execution time: 0.0603
DEBUG - 2022-06-17 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:03:22 --> Total execution time: 0.0578
DEBUG - 2022-06-17 11:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:33:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:03:32 --> Total execution time: 0.0548
DEBUG - 2022-06-17 11:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:03:44 --> Total execution time: 0.0721
DEBUG - 2022-06-17 11:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:33:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:03:57 --> Total execution time: 0.0546
DEBUG - 2022-06-17 11:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:33:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:03:57 --> Total execution time: 0.0344
DEBUG - 2022-06-17 11:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:01 --> Total execution time: 0.1990
DEBUG - 2022-06-17 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:03 --> Total execution time: 0.0696
DEBUG - 2022-06-17 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:04 --> Total execution time: 0.1091
DEBUG - 2022-06-17 11:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:09 --> Total execution time: 0.0537
DEBUG - 2022-06-17 11:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:10 --> Total execution time: 0.0388
DEBUG - 2022-06-17 11:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:34:10 --> Total execution time: 0.1117
DEBUG - 2022-06-17 11:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:04:25 --> Total execution time: 0.2170
DEBUG - 2022-06-17 11:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:05:02 --> Total execution time: 0.0380
DEBUG - 2022-06-17 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:05:08 --> Total execution time: 0.0568
DEBUG - 2022-06-17 11:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:05:26 --> Total execution time: 0.0486
DEBUG - 2022-06-17 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:38:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:08:31 --> Total execution time: 0.1454
DEBUG - 2022-06-17 11:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:08:40 --> Total execution time: 0.0410
DEBUG - 2022-06-17 11:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:08:48 --> Total execution time: 0.1107
DEBUG - 2022-06-17 11:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:08:53 --> Total execution time: 0.0583
DEBUG - 2022-06-17 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:38:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:08:57 --> Total execution time: 0.0373
DEBUG - 2022-06-17 11:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:03 --> Total execution time: 0.1015
DEBUG - 2022-06-17 11:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:04 --> Total execution time: 0.0271
DEBUG - 2022-06-17 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:11 --> Total execution time: 0.0643
DEBUG - 2022-06-17 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:17 --> Total execution time: 0.0398
DEBUG - 2022-06-17 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:18 --> Total execution time: 0.0458
DEBUG - 2022-06-17 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:23 --> Total execution time: 0.0394
DEBUG - 2022-06-17 11:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:31 --> Total execution time: 0.0350
DEBUG - 2022-06-17 11:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:34 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:34 --> Total execution time: 0.1029
DEBUG - 2022-06-17 11:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:38 --> Total execution time: 0.0842
DEBUG - 2022-06-17 11:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:09:42 --> Total execution time: 0.0552
DEBUG - 2022-06-17 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:00 --> Total execution time: 0.0361
DEBUG - 2022-06-17 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:09 --> Total execution time: 0.0389
DEBUG - 2022-06-17 11:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:16 --> Total execution time: 0.0767
DEBUG - 2022-06-17 11:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:21 --> Total execution time: 0.0354
DEBUG - 2022-06-17 11:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:22 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:22 --> Total execution time: 0.0429
DEBUG - 2022-06-17 11:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:23 --> Total execution time: 0.0320
DEBUG - 2022-06-17 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:29 --> Total execution time: 0.0685
DEBUG - 2022-06-17 11:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:50 --> Total execution time: 0.0583
DEBUG - 2022-06-17 11:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:10:58 --> Total execution time: 0.0413
DEBUG - 2022-06-17 11:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:11:37 --> Total execution time: 0.0377
DEBUG - 2022-06-17 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:11:39 --> Total execution time: 0.0469
DEBUG - 2022-06-17 11:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:12:02 --> Total execution time: 0.0376
DEBUG - 2022-06-17 11:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:12:14 --> Total execution time: 0.0384
DEBUG - 2022-06-17 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:12:29 --> Total execution time: 0.0369
DEBUG - 2022-06-17 11:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:42:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:12:50 --> Total execution time: 0.0403
DEBUG - 2022-06-17 11:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:44:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:14:20 --> Total execution time: 0.0454
DEBUG - 2022-06-17 11:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:14:30 --> Total execution time: 0.0554
DEBUG - 2022-06-17 11:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:14:36 --> Total execution time: 0.0432
DEBUG - 2022-06-17 11:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:15:39 --> Total execution time: 0.0410
DEBUG - 2022-06-17 11:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:15:44 --> Total execution time: 0.0411
DEBUG - 2022-06-17 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:15:47 --> Total execution time: 0.0371
DEBUG - 2022-06-17 11:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:15:57 --> Total execution time: 0.0833
DEBUG - 2022-06-17 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:05 --> Total execution time: 0.0594
DEBUG - 2022-06-17 11:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:18 --> Total execution time: 0.0519
DEBUG - 2022-06-17 11:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:27 --> Total execution time: 0.0394
DEBUG - 2022-06-17 11:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:31 --> Total execution time: 0.0565
DEBUG - 2022-06-17 11:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:36 --> Total execution time: 0.1104
DEBUG - 2022-06-17 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:44 --> Total execution time: 0.0316
DEBUG - 2022-06-17 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:16:57 --> Total execution time: 0.0582
DEBUG - 2022-06-17 11:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:02 --> Total execution time: 0.0418
DEBUG - 2022-06-17 11:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:19 --> Total execution time: 0.0516
DEBUG - 2022-06-17 11:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:24 --> Total execution time: 0.0474
DEBUG - 2022-06-17 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:38 --> Total execution time: 0.0456
DEBUG - 2022-06-17 11:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:40 --> Total execution time: 0.0471
DEBUG - 2022-06-17 11:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:43 --> Total execution time: 0.0448
DEBUG - 2022-06-17 11:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:43 --> Total execution time: 0.0504
DEBUG - 2022-06-17 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:48 --> Total execution time: 0.0657
DEBUG - 2022-06-17 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:17:57 --> Total execution time: 0.0480
DEBUG - 2022-06-17 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:00 --> Total execution time: 0.0448
DEBUG - 2022-06-17 11:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:03 --> Total execution time: 0.0501
DEBUG - 2022-06-17 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:05 --> Total execution time: 0.0683
DEBUG - 2022-06-17 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:26 --> Total execution time: 0.0362
DEBUG - 2022-06-17 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:36 --> Total execution time: 0.0456
DEBUG - 2022-06-17 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:43 --> Total execution time: 0.0409
DEBUG - 2022-06-17 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:53 --> Total execution time: 0.1249
DEBUG - 2022-06-17 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:48:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:18:58 --> Total execution time: 0.0499
DEBUG - 2022-06-17 11:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:02 --> Total execution time: 0.0564
DEBUG - 2022-06-17 11:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:03 --> Total execution time: 0.0467
DEBUG - 2022-06-17 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:14 --> Total execution time: 0.0450
DEBUG - 2022-06-17 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:27 --> Total execution time: 0.0548
DEBUG - 2022-06-17 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:35 --> Total execution time: 0.0437
DEBUG - 2022-06-17 11:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:39 --> Total execution time: 0.0443
DEBUG - 2022-06-17 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:42 --> Total execution time: 0.0551
DEBUG - 2022-06-17 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 11:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:45 --> Total execution time: 0.0472
DEBUG - 2022-06-17 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:46 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:46 --> Total execution time: 0.0455
DEBUG - 2022-06-17 11:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:52 --> Total execution time: 0.0437
DEBUG - 2022-06-17 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:52 --> Total execution time: 0.0412
DEBUG - 2022-06-17 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:50:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:20:02 --> Total execution time: 0.0418
DEBUG - 2022-06-17 11:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:20:27 --> Total execution time: 0.0443
DEBUG - 2022-06-17 11:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:20:39 --> Total execution time: 0.1138
DEBUG - 2022-06-17 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:50:45 --> Total execution time: 0.0461
DEBUG - 2022-06-17 11:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:50:53 --> Total execution time: 0.1128
DEBUG - 2022-06-17 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:21:11 --> Total execution time: 0.0514
DEBUG - 2022-06-17 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:51:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:21:41 --> Total execution time: 0.1039
DEBUG - 2022-06-17 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:21:42 --> Total execution time: 0.1002
DEBUG - 2022-06-17 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:21:59 --> Total execution time: 0.0463
DEBUG - 2022-06-17 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:51:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:21:59 --> Total execution time: 0.0796
DEBUG - 2022-06-17 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:22:07 --> Total execution time: 0.0507
DEBUG - 2022-06-17 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:22:17 --> Total execution time: 0.0658
DEBUG - 2022-06-17 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:22:20 --> Total execution time: 0.0433
DEBUG - 2022-06-17 11:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:52:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:22:56 --> Total execution time: 0.0424
DEBUG - 2022-06-17 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:53:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:20 --> Total execution time: 0.0421
DEBUG - 2022-06-17 11:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:21 --> Total execution time: 0.0696
DEBUG - 2022-06-17 11:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:52 --> Total execution time: 0.0394
DEBUG - 2022-06-17 11:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:24:15 --> Total execution time: 0.0414
DEBUG - 2022-06-17 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:25:40 --> Total execution time: 0.0416
DEBUG - 2022-06-17 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:25:54 --> Total execution time: 0.0402
DEBUG - 2022-06-17 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:07 --> Total execution time: 0.0473
DEBUG - 2022-06-17 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:08 --> Total execution time: 0.0406
DEBUG - 2022-06-17 11:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:17 --> Total execution time: 0.0399
DEBUG - 2022-06-17 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:21 --> Total execution time: 0.0557
DEBUG - 2022-06-17 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:23 --> Total execution time: 0.0417
DEBUG - 2022-06-17 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:25 --> Total execution time: 0.0433
DEBUG - 2022-06-17 11:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:28 --> Total execution time: 0.0505
DEBUG - 2022-06-17 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:42 --> Total execution time: 0.0565
DEBUG - 2022-06-17 11:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:48 --> Total execution time: 0.0452
DEBUG - 2022-06-17 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 11:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:26:54 --> Total execution time: 0.0643
DEBUG - 2022-06-17 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:27:30 --> Total execution time: 0.0550
DEBUG - 2022-06-17 11:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 11:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 11:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:28:13 --> Total execution time: 0.0457
DEBUG - 2022-06-17 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:30:03 --> Total execution time: 0.0762
DEBUG - 2022-06-17 12:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:30:37 --> Total execution time: 0.0495
DEBUG - 2022-06-17 12:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:18 --> Total execution time: 0.1175
DEBUG - 2022-06-17 12:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:19 --> Total execution time: 0.0858
DEBUG - 2022-06-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:19 --> Total execution time: 0.0638
DEBUG - 2022-06-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:20 --> Total execution time: 0.0915
DEBUG - 2022-06-17 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:20 --> Total execution time: 0.1223
DEBUG - 2022-06-17 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:20 --> Total execution time: 0.0809
DEBUG - 2022-06-17 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:21 --> Total execution time: 0.0914
DEBUG - 2022-06-17 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:21 --> Total execution time: 0.0799
DEBUG - 2022-06-17 12:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:31:51 --> Total execution time: 0.0397
DEBUG - 2022-06-17 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:02:08 --> Total execution time: 0.0370
DEBUG - 2022-06-17 12:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:02:08 --> Total execution time: 0.0264
DEBUG - 2022-06-17 12:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:32:18 --> Total execution time: 0.0579
DEBUG - 2022-06-17 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:32:46 --> Total execution time: 0.0864
DEBUG - 2022-06-17 12:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:32:48 --> Total execution time: 0.0713
DEBUG - 2022-06-17 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:32:54 --> Total execution time: 0.0673
DEBUG - 2022-06-17 12:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:33:03 --> Total execution time: 0.1001
DEBUG - 2022-06-17 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:17 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:36:17 --> Total execution time: 0.1339
DEBUG - 2022-06-17 12:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:36:34 --> Total execution time: 0.0409
DEBUG - 2022-06-17 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:36:46 --> Total execution time: 0.0452
DEBUG - 2022-06-17 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:36:46 --> Total execution time: 0.0577
DEBUG - 2022-06-17 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:36:49 --> Total execution time: 0.0410
DEBUG - 2022-06-17 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:36:59 --> Total execution time: 0.1483
DEBUG - 2022-06-17 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:02 --> Total execution time: 0.0405
DEBUG - 2022-06-17 12:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:08 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:08 --> Total execution time: 0.0417
DEBUG - 2022-06-17 12:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:10 --> Total execution time: 0.0408
DEBUG - 2022-06-17 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:18 --> Total execution time: 0.0403
DEBUG - 2022-06-17 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:20 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:20 --> Total execution time: 0.0514
DEBUG - 2022-06-17 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:24 --> Total execution time: 0.0418
DEBUG - 2022-06-17 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:33 --> Total execution time: 0.0391
DEBUG - 2022-06-17 12:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:41 --> Total execution time: 0.0453
DEBUG - 2022-06-17 12:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:49 --> Total execution time: 0.0448
DEBUG - 2022-06-17 12:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:51 --> Total execution time: 0.0931
DEBUG - 2022-06-17 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:56 --> Total execution time: 0.0466
DEBUG - 2022-06-17 12:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:59 --> Total execution time: 0.0400
DEBUG - 2022-06-17 12:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:06 --> Total execution time: 0.0383
DEBUG - 2022-06-17 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:10 --> Total execution time: 0.0530
DEBUG - 2022-06-17 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:14 --> Total execution time: 0.0394
DEBUG - 2022-06-17 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:16 --> Total execution time: 0.0448
DEBUG - 2022-06-17 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:20 --> Total execution time: 0.0411
DEBUG - 2022-06-17 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:28 --> Total execution time: 0.0653
DEBUG - 2022-06-17 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:28 --> Total execution time: 0.0479
DEBUG - 2022-06-17 12:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:36 --> Total execution time: 0.0538
DEBUG - 2022-06-17 12:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:46 --> Total execution time: 0.0753
DEBUG - 2022-06-17 12:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:39:17 --> Total execution time: 0.0557
DEBUG - 2022-06-17 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:39:21 --> Total execution time: 0.1062
DEBUG - 2022-06-17 12:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:39:55 --> Total execution time: 0.0759
DEBUG - 2022-06-17 12:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:05 --> Total execution time: 0.0457
DEBUG - 2022-06-17 12:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:15 --> Total execution time: 0.0547
DEBUG - 2022-06-17 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:23 --> Total execution time: 0.0549
DEBUG - 2022-06-17 12:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:33 --> Total execution time: 0.0424
DEBUG - 2022-06-17 12:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:45 --> Total execution time: 0.0456
DEBUG - 2022-06-17 12:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:54 --> Total execution time: 0.0661
DEBUG - 2022-06-17 12:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:43:39 --> Total execution time: 0.0398
DEBUG - 2022-06-17 12:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:44:07 --> Total execution time: 0.1155
DEBUG - 2022-06-17 12:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:44:10 --> Total execution time: 0.0462
DEBUG - 2022-06-17 12:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:44:14 --> Total execution time: 0.0517
DEBUG - 2022-06-17 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:44:22 --> Total execution time: 0.0442
DEBUG - 2022-06-17 12:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:45:22 --> Total execution time: 0.0639
DEBUG - 2022-06-17 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:10 --> Total execution time: 0.0445
DEBUG - 2022-06-17 12:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:43 --> Total execution time: 0.0701
DEBUG - 2022-06-17 12:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:54 --> Total execution time: 0.0446
DEBUG - 2022-06-17 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:47:36 --> Total execution time: 0.0404
DEBUG - 2022-06-17 12:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:48:21 --> Total execution time: 0.0556
DEBUG - 2022-06-17 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:50:48 --> Total execution time: 0.1015
DEBUG - 2022-06-17 12:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:51:27 --> Total execution time: 0.0415
DEBUG - 2022-06-17 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:51:29 --> Total execution time: 0.0412
DEBUG - 2022-06-17 12:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:33 --> Total execution time: 0.1096
DEBUG - 2022-06-17 12:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:24:36 --> Total execution time: 0.0391
DEBUG - 2022-06-17 12:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:41 --> Total execution time: 0.0490
DEBUG - 2022-06-17 12:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:46 --> Total execution time: 0.0870
DEBUG - 2022-06-17 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:47 --> Total execution time: 0.0966
DEBUG - 2022-06-17 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:52 --> Total execution time: 0.0694
DEBUG - 2022-06-17 12:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:57 --> Total execution time: 0.0922
DEBUG - 2022-06-17 12:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:56:31 --> Total execution time: 0.0407
DEBUG - 2022-06-17 12:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:58:27 --> Total execution time: 0.0437
DEBUG - 2022-06-17 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 12:29:38 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:59:50 --> Total execution time: 0.0539
DEBUG - 2022-06-17 12:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:00:32 --> Total execution time: 0.0399
DEBUG - 2022-06-17 12:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 12:31:35 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-17 12:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 12:31:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 12:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:02:04 --> Total execution time: 0.0552
DEBUG - 2022-06-17 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 12:32:06 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 12:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:02:09 --> Total execution time: 0.0420
DEBUG - 2022-06-17 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:02:59 --> Total execution time: 0.1068
DEBUG - 2022-06-17 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:03:01 --> Total execution time: 0.0478
DEBUG - 2022-06-17 12:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:03:12 --> Total execution time: 0.0479
DEBUG - 2022-06-17 12:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:03:29 --> Total execution time: 0.0416
DEBUG - 2022-06-17 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:34:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 12:34:14 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 12:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:04:20 --> Total execution time: 0.0491
DEBUG - 2022-06-17 12:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:35:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:26 --> Total execution time: 0.0458
DEBUG - 2022-06-17 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:35:27 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:27 --> Total execution time: 0.0435
DEBUG - 2022-06-17 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:38 --> Total execution time: 0.0301
DEBUG - 2022-06-17 12:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:47 --> Total execution time: 0.0924
DEBUG - 2022-06-17 12:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:04 --> Total execution time: 0.0361
DEBUG - 2022-06-17 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:14 --> Total execution time: 0.0439
DEBUG - 2022-06-17 12:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:17 --> Total execution time: 0.0923
DEBUG - 2022-06-17 12:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:26 --> Total execution time: 0.0476
DEBUG - 2022-06-17 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:34 --> Total execution time: 0.0485
DEBUG - 2022-06-17 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:16 --> Total execution time: 0.0398
DEBUG - 2022-06-17 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:05 --> Total execution time: 0.0431
DEBUG - 2022-06-17 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:39:51 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:51 --> Total execution time: 0.0376
DEBUG - 2022-06-17 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:53 --> Total execution time: 0.0516
DEBUG - 2022-06-17 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:54 --> Total execution time: 0.0504
DEBUG - 2022-06-17 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:04 --> Total execution time: 0.0367
DEBUG - 2022-06-17 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:05 --> Total execution time: 0.0407
DEBUG - 2022-06-17 12:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:40:05 --> Total execution time: 0.0854
DEBUG - 2022-06-17 12:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:27 --> Total execution time: 0.0297
DEBUG - 2022-06-17 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:40 --> Total execution time: 0.0572
DEBUG - 2022-06-17 12:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:41:11 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:11 --> Total execution time: 0.0337
DEBUG - 2022-06-17 12:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:20 --> Total execution time: 0.0439
DEBUG - 2022-06-17 12:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:18:48 --> Total execution time: 0.0880
DEBUG - 2022-06-17 12:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:53 --> Total execution time: 0.0946
DEBUG - 2022-06-17 12:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:38 --> Total execution time: 0.0599
DEBUG - 2022-06-17 12:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:23:17 --> Total execution time: 0.0907
DEBUG - 2022-06-17 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 12:56:32 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 12:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:27:27 --> Total execution time: 0.0789
DEBUG - 2022-06-17 12:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 12:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:29:02 --> Total execution time: 0.0593
DEBUG - 2022-06-17 12:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:29:06 --> Total execution time: 0.0387
DEBUG - 2022-06-17 12:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 12:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:29:11 --> Total execution time: 0.0929
DEBUG - 2022-06-17 12:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:29:14 --> Total execution time: 0.0528
DEBUG - 2022-06-17 12:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:29:17 --> Total execution time: 0.0483
DEBUG - 2022-06-17 12:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 12:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 12:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:29:25 --> Total execution time: 0.0390
DEBUG - 2022-06-17 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:30:03 --> Total execution time: 0.0352
DEBUG - 2022-06-17 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:31:05 --> Total execution time: 0.0573
DEBUG - 2022-06-17 13:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:32:22 --> Total execution time: 0.0393
DEBUG - 2022-06-17 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:19 --> Total execution time: 0.0379
DEBUG - 2022-06-17 13:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:47 --> Total execution time: 0.0516
DEBUG - 2022-06-17 13:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:26 --> Total execution time: 0.0839
DEBUG - 2022-06-17 13:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:30 --> Total execution time: 0.0399
DEBUG - 2022-06-17 13:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:40 --> Total execution time: 0.0878
DEBUG - 2022-06-17 13:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:42 --> Total execution time: 0.0510
DEBUG - 2022-06-17 13:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:47 --> Total execution time: 0.0634
DEBUG - 2022-06-17 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:56 --> Total execution time: 0.0819
DEBUG - 2022-06-17 13:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:07 --> Total execution time: 0.0601
DEBUG - 2022-06-17 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:11 --> Total execution time: 0.0721
DEBUG - 2022-06-17 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:54 --> Total execution time: 0.0484
DEBUG - 2022-06-17 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:54 --> Total execution time: 0.0478
DEBUG - 2022-06-17 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:56 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:56 --> Total execution time: 0.0307
DEBUG - 2022-06-17 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:57 --> Total execution time: 0.0277
DEBUG - 2022-06-17 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:57 --> Total execution time: 0.0329
DEBUG - 2022-06-17 13:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:08:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:59 --> Total execution time: 0.0393
DEBUG - 2022-06-17 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:39:42 --> Total execution time: 0.0465
DEBUG - 2022-06-17 13:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:04 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:04 --> Total execution time: 0.0448
DEBUG - 2022-06-17 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:29 --> Total execution time: 0.0382
DEBUG - 2022-06-17 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:31 --> Total execution time: 0.0424
DEBUG - 2022-06-17 13:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:34 --> Total execution time: 0.0422
DEBUG - 2022-06-17 13:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:47 --> Total execution time: 0.0269
DEBUG - 2022-06-17 13:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:11:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:55 --> Total execution time: 0.0506
DEBUG - 2022-06-17 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:12:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:42:14 --> Total execution time: 0.0473
DEBUG - 2022-06-17 13:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:42:25 --> Total execution time: 0.0436
DEBUG - 2022-06-17 13:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:12:35 --> Total execution time: 0.0505
DEBUG - 2022-06-17 13:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:12 --> Total execution time: 0.0459
DEBUG - 2022-06-17 13:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:13:12 --> Total execution time: 0.1055
DEBUG - 2022-06-17 13:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:14:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 13:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:44:35 --> Total execution time: 2.0413
DEBUG - 2022-06-17 13:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 13:14:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:19 --> Total execution time: 0.1009
DEBUG - 2022-06-17 13:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:23 --> Total execution time: 0.0460
DEBUG - 2022-06-17 13:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:29 --> Total execution time: 0.0429
DEBUG - 2022-06-17 13:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:32 --> Total execution time: 0.0517
DEBUG - 2022-06-17 13:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:40 --> Total execution time: 0.0667
DEBUG - 2022-06-17 13:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:49 --> Total execution time: 0.0622
DEBUG - 2022-06-17 13:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:49 --> Total execution time: 0.0502
DEBUG - 2022-06-17 13:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:49 --> Total execution time: 0.0480
DEBUG - 2022-06-17 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:05 --> Total execution time: 0.0727
DEBUG - 2022-06-17 13:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:07 --> Total execution time: 0.0494
DEBUG - 2022-06-17 13:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:10 --> Total execution time: 0.0474
DEBUG - 2022-06-17 13:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:53 --> Total execution time: 0.0547
DEBUG - 2022-06-17 13:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:16:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:54 --> Total execution time: 0.0538
DEBUG - 2022-06-17 13:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:47:56 --> Total execution time: 0.0431
DEBUG - 2022-06-17 13:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:18:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:35 --> Total execution time: 0.0329
DEBUG - 2022-06-17 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:22:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:52:45 --> Total execution time: 0.0855
DEBUG - 2022-06-17 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:28:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:58:57 --> Total execution time: 0.1087
DEBUG - 2022-06-17 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:29:39 --> Total execution time: 0.0516
DEBUG - 2022-06-17 13:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:30:47 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:31:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:31:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:32:19 --> Total execution time: 0.0527
DEBUG - 2022-06-17 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:32:48 --> Total execution time: 0.0405
DEBUG - 2022-06-17 13:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:32:48 --> Total execution time: 0.0764
DEBUG - 2022-06-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:33:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:33:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:33:46 --> Total execution time: 0.0385
DEBUG - 2022-06-17 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:34:07 --> Total execution time: 0.0428
DEBUG - 2022-06-17 13:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:34:07 --> Total execution time: 0.0843
DEBUG - 2022-06-17 13:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:34:21 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:34:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:34:57 --> Total execution time: 0.0391
DEBUG - 2022-06-17 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:35:00 --> Total execution time: 0.0389
DEBUG - 2022-06-17 13:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:35:00 --> Total execution time: 0.0854
DEBUG - 2022-06-17 13:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:38:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:16 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:22 --> Total execution time: 0.0411
DEBUG - 2022-06-17 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:23 --> Total execution time: 0.0456
DEBUG - 2022-06-17 13:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:23 --> Total execution time: 0.0888
DEBUG - 2022-06-17 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:46:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:46:33 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:48 --> Total execution time: 0.0918
DEBUG - 2022-06-17 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:50 --> Total execution time: 0.0417
DEBUG - 2022-06-17 13:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:46:50 --> Total execution time: 0.0428
DEBUG - 2022-06-17 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:14 --> Total execution time: 0.0450
DEBUG - 2022-06-17 13:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:15 --> Total execution time: 0.0492
DEBUG - 2022-06-17 13:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:15 --> Total execution time: 0.0955
DEBUG - 2022-06-17 13:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:27 --> Total execution time: 0.0470
DEBUG - 2022-06-17 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:28 --> Total execution time: 0.0516
DEBUG - 2022-06-17 13:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:28 --> Total execution time: 0.0631
DEBUG - 2022-06-17 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:47 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 13:49:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:50:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:51:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:51:50 --> Total execution time: 0.0427
DEBUG - 2022-06-17 13:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:08 --> Total execution time: 0.0482
DEBUG - 2022-06-17 13:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:08 --> Total execution time: 0.0970
DEBUG - 2022-06-17 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:23 --> Total execution time: 0.0527
DEBUG - 2022-06-17 13:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:24 --> Total execution time: 0.0465
DEBUG - 2022-06-17 13:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:24 --> Total execution time: 0.1029
DEBUG - 2022-06-17 13:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:52:59 --> Total execution time: 0.0460
DEBUG - 2022-06-17 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:53:19 --> Total execution time: 0.0684
DEBUG - 2022-06-17 13:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:53:19 --> Total execution time: 0.1106
DEBUG - 2022-06-17 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:55:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 13:56:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:56:38 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:56:43 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 13:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 13:59:44 --> No URI present. Default controller set.
DEBUG - 2022-06-17 13:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 13:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:05:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 14:05:02 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 14:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 14:07:28 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:07:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:07:32 --> No URI present. Default controller set.
DEBUG - 2022-06-17 14:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:19 --> No URI present. Default controller set.
DEBUG - 2022-06-17 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 14:09:30 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 14:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:35 --> Total execution time: 0.0439
DEBUG - 2022-06-17 14:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:37 --> Total execution time: 0.0589
DEBUG - 2022-06-17 14:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:09:37 --> Total execution time: 0.1116
DEBUG - 2022-06-17 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 14:11:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 14:31:47 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 14:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 14:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 14:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 14:41:23 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 15:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:22:23 --> No URI present. Default controller set.
DEBUG - 2022-06-17 15:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:31:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:31:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 15:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:31:29 --> No URI present. Default controller set.
DEBUG - 2022-06-17 15:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:33:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:39:17 --> 404 Page Not Found: Git/HEAD
DEBUG - 2022-06-17 15:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:39:47 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 15:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:42:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 15:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 15:44:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 15:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:45:38 --> No URI present. Default controller set.
DEBUG - 2022-06-17 15:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:47:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 15:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 15:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 15:48:12 --> No URI present. Default controller set.
DEBUG - 2022-06-17 15:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 15:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:01 --> Total execution time: 0.0598
DEBUG - 2022-06-17 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 16:06:03 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 16:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 16:20:03 --> 404 Page Not Found: Home-3/esalestrix.in
DEBUG - 2022-06-17 16:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 16:26:46 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-17 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 16:44:37 --> 404 Page Not Found: Lessons/bearish-chart-pattern
DEBUG - 2022-06-17 16:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 16:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 16:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 16:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 16:59:21 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-17 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 17:12:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 17:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 17:15:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 17:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 17:17:16 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 17:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:29:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 17:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:29:37 --> No URI present. Default controller set.
DEBUG - 2022-06-17 17:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:29:45 --> Total execution time: 0.0431
DEBUG - 2022-06-17 17:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:29:46 --> Total execution time: 0.0649
DEBUG - 2022-06-17 17:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:29:46 --> Total execution time: 0.0927
DEBUG - 2022-06-17 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:32:26 --> Total execution time: 0.0561
DEBUG - 2022-06-17 17:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:32:27 --> Total execution time: 0.0648
DEBUG - 2022-06-17 17:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:32:27 --> Total execution time: 0.0900
DEBUG - 2022-06-17 17:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:32:34 --> No URI present. Default controller set.
DEBUG - 2022-06-17 17:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 17:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 17:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 17:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 17:39:26 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:00:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:03:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 18:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:31:40 --> 404 Page Not Found: Git/HEAD
DEBUG - 2022-06-17 18:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:34:37 --> 404 Page Not Found: Lessons/dropship-store-front-customization
DEBUG - 2022-06-17 18:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:46:22 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 18:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:48:42 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 18:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:50:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:50:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 18:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:56:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 18:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:56:48 --> No URI present. Default controller set.
DEBUG - 2022-06-17 18:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 18:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 18:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:56:49 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 18:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 18:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 18:56:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 19:04:11 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-17 19:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 19:12:49 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 19:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:24:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:29:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:32:28 --> Total execution time: 0.0989
DEBUG - 2022-06-17 19:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:32:30 --> Total execution time: 0.0656
DEBUG - 2022-06-17 19:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:32:30 --> Total execution time: 0.0843
DEBUG - 2022-06-17 19:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:33:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 19:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 19:33:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 19:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:34:17 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:41:07 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:41:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 19:41:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 19:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:41:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 19:41:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 19:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:41:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 19:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 19:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 19:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 19:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 19:50:14 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-17 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:01:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 20:01:47 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-17 20:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:07:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:11:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:13:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:14:25 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 20:19:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 20:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 20:21:54 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 20:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 20:23:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 20:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:06 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:19 --> Total execution time: 0.0514
DEBUG - 2022-06-17 20:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:24 --> Total execution time: 0.0460
DEBUG - 2022-06-17 20:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:24 --> Total execution time: 0.0892
DEBUG - 2022-06-17 20:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:10 --> Total execution time: 0.0568
DEBUG - 2022-06-17 20:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:12 --> Total execution time: 0.0977
DEBUG - 2022-06-17 20:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:12 --> Total execution time: 0.1605
DEBUG - 2022-06-17 20:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:22 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:27 --> Total execution time: 0.0389
DEBUG - 2022-06-17 20:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:33:53 --> Total execution time: 0.0462
DEBUG - 2022-06-17 20:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:33:53 --> Total execution time: 0.0686
DEBUG - 2022-06-17 20:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 20:40:28 --> 404 Page Not Found: Environments/environment.ts
DEBUG - 2022-06-17 20:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 20:45:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 20:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 20:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 20:57:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 20:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 20:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:09:26 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:10:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:13:01 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:15:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:27:47 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:29:09 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:32:32 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 21:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:33:03 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-17 21:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:34:36 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:35:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:35:24 --> 404 Page Not Found: Course/reselling-course
DEBUG - 2022-06-17 21:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:40:54 --> No URI present. Default controller set.
DEBUG - 2022-06-17 21:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:52:37 --> 404 Page Not Found: Wp-includes/SimplePie
DEBUG - 2022-06-17 21:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:52:47 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 21:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 21:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 21:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:55:07 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 21:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 21:57:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 21:57:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 22:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:00:57 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:03 --> Total execution time: 0.0442
DEBUG - 2022-06-17 22:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:04 --> Total execution time: 0.0801
DEBUG - 2022-06-17 22:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:04 --> Total execution time: 0.0984
DEBUG - 2022-06-17 22:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:22 --> Total execution time: 0.0392
DEBUG - 2022-06-17 22:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:03:06 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 22:19:08 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:23:45 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:40:01 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 22:40:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 22:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:41:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:41:38 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:45:52 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:45:59 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:46:10 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:46:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:46:41 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:45 --> Total execution time: 0.0424
DEBUG - 2022-06-17 22:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:03 --> Total execution time: 0.0379
DEBUG - 2022-06-17 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:05 --> Total execution time: 0.0439
DEBUG - 2022-06-17 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:05 --> Total execution time: 0.0747
DEBUG - 2022-06-17 22:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:55 --> No URI present. Default controller set.
DEBUG - 2022-06-17 22:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 22:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 22:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 22:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:04:47 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:31 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:43 --> Total execution time: 0.0417
DEBUG - 2022-06-17 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:45 --> Total execution time: 0.0468
DEBUG - 2022-06-17 23:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:45 --> Total execution time: 0.0603
DEBUG - 2022-06-17 23:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:49 --> Total execution time: 0.0469
DEBUG - 2022-06-17 23:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:20 --> Total execution time: 0.0391
DEBUG - 2022-06-17 23:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 23:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:22 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:09:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:18 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:36 --> Total execution time: 0.0434
DEBUG - 2022-06-17 23:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:16:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:00 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:22 --> Total execution time: 0.0401
DEBUG - 2022-06-17 23:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:23 --> Total execution time: 0.0506
DEBUG - 2022-06-17 23:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:23 --> Total execution time: 0.1103
DEBUG - 2022-06-17 23:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:30 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:39 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:45 --> Total execution time: 0.0392
DEBUG - 2022-06-17 23:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:49 --> Total execution time: 0.0469
DEBUG - 2022-06-17 23:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:49 --> Total execution time: 0.0731
DEBUG - 2022-06-17 23:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:52 --> Total execution time: 0.0340
DEBUG - 2022-06-17 23:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:53 --> Total execution time: 0.0453
DEBUG - 2022-06-17 23:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:19:53 --> Total execution time: 0.0857
DEBUG - 2022-06-17 23:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:02 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-17 23:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:21:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 23:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:14 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:23:24 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:23:50 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:24:28 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:25:53 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-17 23:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:25:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:25:53 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:25:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-17 23:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:26:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:26:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-17 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:27:49 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:28:59 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-17 23:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:31:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-17 23:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:36:35 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:40:40 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:47:17 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:53 --> Total execution time: 0.0328
DEBUG - 2022-06-17 23:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:56 --> Total execution time: 0.0579
DEBUG - 2022-06-17 23:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:50:56 --> Total execution time: 0.0736
DEBUG - 2022-06-17 23:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-17 23:53:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-17 23:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:55:03 --> No URI present. Default controller set.
DEBUG - 2022-06-17 23:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-17 23:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-17 23:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-17 23:57:06 --> Encryption: Auto-configured driver 'openssl'.
