<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-16 01:44:00 --> Total execution time: 1.0860
DEBUG - 2022-05-16 01:44:03 --> Total execution time: 0.0297
DEBUG - 2022-05-16 01:44:09 --> Total execution time: 0.1145
DEBUG - 2022-05-16 01:44:14 --> Total execution time: 0.0509
DEBUG - 2022-05-16 01:44:31 --> Total execution time: 0.1977
DEBUG - 2022-05-16 02:26:06 --> Total execution time: 1.0929
DEBUG - 2022-05-16 02:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 02:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 02:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 07:49:10 --> Total execution time: 1.2919
DEBUG - 2022-05-16 05:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 05:22:14 --> No URI present. Default controller set.
DEBUG - 2022-05-16 05:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 05:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 10:52:15 --> Total execution time: 1.1410
DEBUG - 2022-05-16 06:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 06:52:00 --> Total execution time: 1.2262
DEBUG - 2022-05-16 06:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 06:52:00 --> Total execution time: 0.0295
DEBUG - 2022-05-16 06:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 06:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:22:06 --> Total execution time: 0.2034
DEBUG - 2022-05-16 06:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:16 --> No URI present. Default controller set.
DEBUG - 2022-05-16 06:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:22:16 --> Total execution time: 0.0776
DEBUG - 2022-05-16 06:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:22:21 --> Total execution time: 0.0441
DEBUG - 2022-05-16 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:22:36 --> Total execution time: 2.4720
DEBUG - 2022-05-16 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:22:59 --> Total execution time: 0.0980
DEBUG - 2022-05-16 06:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:23:15 --> Total execution time: 0.0635
DEBUG - 2022-05-16 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:23:18 --> Total execution time: 0.6355
DEBUG - 2022-05-16 06:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:25:46 --> Total execution time: 1.0379
DEBUG - 2022-05-16 06:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:57:33 --> No URI present. Default controller set.
DEBUG - 2022-05-16 06:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:27:34 --> Total execution time: 0.0855
DEBUG - 2022-05-16 06:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 06:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 06:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:28:41 --> Total execution time: 0.7599
DEBUG - 2022-05-16 07:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:30:27 --> Total execution time: 0.8692
DEBUG - 2022-05-16 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:30:42 --> Total execution time: 0.0524
DEBUG - 2022-05-16 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:30:46 --> Total execution time: 0.6173
DEBUG - 2022-05-16 07:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:30:48 --> Total execution time: 0.0334
DEBUG - 2022-05-16 07:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:31:58 --> Total execution time: 0.0343
DEBUG - 2022-05-16 07:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:33:01 --> Total execution time: 1.1206
DEBUG - 2022-05-16 07:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 07:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:37:29 --> Total execution time: 0.0885
DEBUG - 2022-05-16 07:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:37:32 --> Total execution time: 0.0478
DEBUG - 2022-05-16 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:37:37 --> Total execution time: 0.7264
DEBUG - 2022-05-16 07:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 07:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 07:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 12:38:45 --> Total execution time: 1.4686
DEBUG - 2022-05-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 13:31:01 --> No URI present. Default controller set.
DEBUG - 2022-05-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 13:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 19:01:02 --> Total execution time: 1.4270
DEBUG - 2022-05-16 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 13:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 19:01:30 --> Total execution time: 0.0510
DEBUG - 2022-05-16 14:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:33:09 --> No URI present. Default controller set.
DEBUG - 2022-05-16 14:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:03:10 --> Total execution time: 0.9749
DEBUG - 2022-05-16 14:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:03:15 --> Total execution time: 0.0446
DEBUG - 2022-05-16 14:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 14:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:04:02 --> Total execution time: 0.0298
DEBUG - 2022-05-16 14:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:04:04 --> Total execution time: 0.0302
DEBUG - 2022-05-16 14:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 14:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:04:14 --> Total execution time: 0.0939
DEBUG - 2022-05-16 14:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:04:18 --> Total execution time: 0.0510
DEBUG - 2022-05-16 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:04:26 --> Total execution time: 0.0330
DEBUG - 2022-05-16 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:08:42 --> Total execution time: 0.8326
DEBUG - 2022-05-16 14:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:08:46 --> Total execution time: 0.2051
DEBUG - 2022-05-16 14:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 14:39:36 --> No URI present. Default controller set.
DEBUG - 2022-05-16 14:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 14:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-16 20:09:36 --> Total execution time: 0.0689
