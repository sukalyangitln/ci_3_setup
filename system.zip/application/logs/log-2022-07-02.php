<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-02 00:00:00 --> Total execution time: 0.0828
DEBUG - 2022-07-02 00:00:02 --> Total execution time: 0.0277
DEBUG - 2022-07-02 00:00:11 --> Total execution time: 0.0996
DEBUG - 2022-07-02 00:00:13 --> Total execution time: 0.0325
DEBUG - 2022-07-02 00:19:51 --> Total execution time: 0.0996
DEBUG - 2022-07-02 00:30:17 --> Total execution time: 0.8313
DEBUG - 2022-07-02 00:32:10 --> Total execution time: 0.0563
DEBUG - 2022-07-02 01:05:17 --> Total execution time: 0.0463
DEBUG - 2022-07-02 01:05:30 --> Total execution time: 0.0340
DEBUG - 2022-07-02 01:05:40 --> Total execution time: 0.0941
DEBUG - 2022-07-02 01:06:09 --> Total execution time: 0.0846
DEBUG - 2022-07-02 01:06:41 --> Total execution time: 0.0485
DEBUG - 2022-07-02 01:06:50 --> Total execution time: 0.0551
DEBUG - 2022-07-02 01:06:58 --> Total execution time: 0.0545
DEBUG - 2022-07-02 01:07:18 --> Total execution time: 0.0523
DEBUG - 2022-07-02 01:07:25 --> Total execution time: 0.0848
DEBUG - 2022-07-02 01:10:46 --> Total execution time: 0.0526
DEBUG - 2022-07-02 01:11:00 --> Total execution time: 0.1377
DEBUG - 2022-07-02 01:30:02 --> Total execution time: 0.2503
DEBUG - 2022-07-02 01:38:31 --> Total execution time: 0.1184
DEBUG - 2022-07-02 02:30:03 --> Total execution time: 0.2244
DEBUG - 2022-07-02 02:31:48 --> Total execution time: 0.0512
DEBUG - 2022-07-02 02:31:52 --> Total execution time: 0.0554
DEBUG - 2022-07-02 02:32:09 --> Total execution time: 0.0780
DEBUG - 2022-07-02 02:32:13 --> Total execution time: 0.0929
DEBUG - 2022-07-02 02:33:14 --> Total execution time: 0.0754
DEBUG - 2022-07-02 02:33:51 --> Total execution time: 0.0535
DEBUG - 2022-07-02 02:34:19 --> Total execution time: 1.5464
DEBUG - 2022-07-02 02:34:24 --> Total execution time: 1.4789
DEBUG - 2022-07-02 02:34:56 --> Total execution time: 0.0478
DEBUG - 2022-07-02 02:34:59 --> Total execution time: 0.0716
DEBUG - 2022-07-02 02:35:16 --> Total execution time: 0.0698
DEBUG - 2022-07-02 02:35:21 --> Total execution time: 0.0644
DEBUG - 2022-07-02 02:41:58 --> Total execution time: 0.1649
DEBUG - 2022-07-02 02:43:13 --> Total execution time: 0.0735
DEBUG - 2022-07-02 02:43:19 --> Total execution time: 1.5804
DEBUG - 2022-07-02 02:43:53 --> Total execution time: 1.5185
DEBUG - 2022-07-02 02:44:00 --> Total execution time: 0.0472
DEBUG - 2022-07-02 02:44:10 --> Total execution time: 0.0418
DEBUG - 2022-07-02 02:44:29 --> Total execution time: 0.1075
DEBUG - 2022-07-02 02:44:40 --> Total execution time: 0.0787
DEBUG - 2022-07-02 02:44:45 --> Total execution time: 0.0873
DEBUG - 2022-07-02 02:44:53 --> Total execution time: 0.1128
DEBUG - 2022-07-02 02:45:01 --> Total execution time: 0.0668
DEBUG - 2022-07-02 02:45:06 --> Total execution time: 0.0896
DEBUG - 2022-07-02 02:45:09 --> Total execution time: 0.0675
DEBUG - 2022-07-02 02:45:14 --> Total execution time: 0.1443
DEBUG - 2022-07-02 02:45:35 --> Total execution time: 1.3311
DEBUG - 2022-07-02 02:45:49 --> Total execution time: 0.1076
DEBUG - 2022-07-02 02:45:54 --> Total execution time: 0.5256
DEBUG - 2022-07-02 02:46:03 --> Total execution time: 0.0533
DEBUG - 2022-07-02 02:46:07 --> Total execution time: 0.0578
DEBUG - 2022-07-02 02:46:15 --> Total execution time: 0.0541
DEBUG - 2022-07-02 02:47:57 --> Total execution time: 1.0934
DEBUG - 2022-07-02 02:48:09 --> Total execution time: 0.0995
DEBUG - 2022-07-02 02:48:13 --> Total execution time: 0.0720
DEBUG - 2022-07-02 02:48:24 --> Total execution time: 0.0644
DEBUG - 2022-07-02 02:49:01 --> Total execution time: 0.0972
DEBUG - 2022-07-02 02:49:07 --> Total execution time: 0.0454
DEBUG - 2022-07-02 02:49:12 --> Total execution time: 0.0534
DEBUG - 2022-07-02 02:49:14 --> Total execution time: 0.0477
DEBUG - 2022-07-02 02:49:30 --> Total execution time: 0.0762
DEBUG - 2022-07-02 02:49:44 --> Total execution time: 0.0494
DEBUG - 2022-07-02 02:51:11 --> Total execution time: 0.0341
DEBUG - 2022-07-02 02:51:21 --> Total execution time: 0.0619
DEBUG - 2022-07-02 02:51:38 --> Total execution time: 0.0524
DEBUG - 2022-07-02 02:51:47 --> Total execution time: 0.0497
DEBUG - 2022-07-02 02:51:49 --> Total execution time: 0.0769
DEBUG - 2022-07-02 02:52:00 --> Total execution time: 0.0456
DEBUG - 2022-07-02 02:53:48 --> Total execution time: 0.0567
DEBUG - 2022-07-02 02:53:50 --> Total execution time: 0.0306
DEBUG - 2022-07-02 02:53:55 --> Total execution time: 0.0573
DEBUG - 2022-07-02 02:53:58 --> Total execution time: 0.0577
DEBUG - 2022-07-02 02:54:07 --> Total execution time: 0.0660
DEBUG - 2022-07-02 02:54:10 --> Total execution time: 0.0721
DEBUG - 2022-07-02 02:54:24 --> Total execution time: 0.0551
DEBUG - 2022-07-02 02:54:28 --> Total execution time: 0.0675
DEBUG - 2022-07-02 02:54:31 --> Total execution time: 0.0522
DEBUG - 2022-07-02 02:54:33 --> Total execution time: 0.0586
DEBUG - 2022-07-02 02:54:36 --> Total execution time: 0.0562
DEBUG - 2022-07-02 02:54:54 --> Total execution time: 0.0509
DEBUG - 2022-07-02 02:55:48 --> Total execution time: 0.0542
DEBUG - 2022-07-02 02:55:54 --> Total execution time: 0.0605
DEBUG - 2022-07-02 02:55:58 --> Total execution time: 0.0458
DEBUG - 2022-07-02 02:57:11 --> Total execution time: 0.0450
DEBUG - 2022-07-02 02:57:30 --> Total execution time: 0.0467
DEBUG - 2022-07-02 02:58:52 --> Total execution time: 0.0565
DEBUG - 2022-07-02 02:59:04 --> Total execution time: 0.0675
DEBUG - 2022-07-02 02:59:09 --> Total execution time: 0.0524
DEBUG - 2022-07-02 02:59:49 --> Total execution time: 0.0654
DEBUG - 2022-07-02 03:00:09 --> Total execution time: 0.0463
DEBUG - 2022-07-02 03:00:13 --> Total execution time: 0.0762
DEBUG - 2022-07-02 03:01:02 --> Total execution time: 0.1257
DEBUG - 2022-07-02 03:01:04 --> Total execution time: 0.0525
DEBUG - 2022-07-02 03:01:12 --> Total execution time: 0.0534
DEBUG - 2022-07-02 03:01:25 --> Total execution time: 0.0501
DEBUG - 2022-07-02 03:01:32 --> Total execution time: 1.4789
DEBUG - 2022-07-02 03:01:36 --> Total execution time: 0.0543
DEBUG - 2022-07-02 03:01:50 --> Total execution time: 0.0536
DEBUG - 2022-07-02 03:02:00 --> Total execution time: 0.0559
DEBUG - 2022-07-02 03:02:04 --> Total execution time: 0.0617
DEBUG - 2022-07-02 03:02:11 --> Total execution time: 0.0677
DEBUG - 2022-07-02 03:02:11 --> Total execution time: 0.0439
DEBUG - 2022-07-02 03:02:16 --> Total execution time: 0.0806
DEBUG - 2022-07-02 03:02:20 --> Total execution time: 0.0663
DEBUG - 2022-07-02 03:02:45 --> Total execution time: 0.0410
DEBUG - 2022-07-02 03:03:12 --> Total execution time: 0.0639
DEBUG - 2022-07-02 03:03:31 --> Total execution time: 0.1426
DEBUG - 2022-07-02 03:03:42 --> Total execution time: 0.0876
DEBUG - 2022-07-02 03:03:46 --> Total execution time: 0.0490
DEBUG - 2022-07-02 03:03:59 --> Total execution time: 0.1171
DEBUG - 2022-07-02 03:04:10 --> Total execution time: 0.0511
DEBUG - 2022-07-02 03:04:10 --> Total execution time: 0.0521
DEBUG - 2022-07-02 03:04:10 --> Total execution time: 0.0642
DEBUG - 2022-07-02 03:04:11 --> Total execution time: 0.0770
DEBUG - 2022-07-02 03:04:11 --> Total execution time: 0.0644
DEBUG - 2022-07-02 03:04:11 --> Total execution time: 0.0703
DEBUG - 2022-07-02 03:04:11 --> Total execution time: 0.0778
DEBUG - 2022-07-02 03:04:11 --> Total execution time: 0.0495
DEBUG - 2022-07-02 03:04:12 --> Total execution time: 0.0494
DEBUG - 2022-07-02 03:04:12 --> Total execution time: 0.0609
DEBUG - 2022-07-02 03:04:12 --> Total execution time: 0.0557
DEBUG - 2022-07-02 03:04:12 --> Total execution time: 0.0486
DEBUG - 2022-07-02 03:04:12 --> Total execution time: 0.0605
DEBUG - 2022-07-02 03:04:12 --> Total execution time: 0.0518
DEBUG - 2022-07-02 03:04:13 --> Total execution time: 0.0622
DEBUG - 2022-07-02 03:04:13 --> Total execution time: 0.0547
DEBUG - 2022-07-02 03:04:13 --> Total execution time: 0.0508
DEBUG - 2022-07-02 03:04:13 --> Total execution time: 0.0518
DEBUG - 2022-07-02 03:04:13 --> Total execution time: 0.0729
DEBUG - 2022-07-02 03:04:13 --> Total execution time: 0.0477
DEBUG - 2022-07-02 03:04:14 --> Total execution time: 0.0487
DEBUG - 2022-07-02 03:05:21 --> Total execution time: 1.4669
DEBUG - 2022-07-02 03:05:30 --> Total execution time: 0.0539
DEBUG - 2022-07-02 03:06:36 --> Total execution time: 0.0446
DEBUG - 2022-07-02 03:06:37 --> Total execution time: 0.0321
DEBUG - 2022-07-02 03:06:47 --> Total execution time: 0.0556
DEBUG - 2022-07-02 03:07:12 --> Total execution time: 0.0569
DEBUG - 2022-07-02 03:07:19 --> Total execution time: 0.0757
DEBUG - 2022-07-02 03:07:34 --> Total execution time: 0.0489
DEBUG - 2022-07-02 03:07:48 --> Total execution time: 0.0476
DEBUG - 2022-07-02 03:08:10 --> Total execution time: 0.0356
DEBUG - 2022-07-02 03:08:30 --> Total execution time: 0.0506
DEBUG - 2022-07-02 03:08:49 --> Total execution time: 0.0673
DEBUG - 2022-07-02 03:09:23 --> Total execution time: 0.0763
DEBUG - 2022-07-02 03:09:29 --> Total execution time: 0.0559
DEBUG - 2022-07-02 03:09:40 --> Total execution time: 0.0575
DEBUG - 2022-07-02 03:09:42 --> Total execution time: 0.0726
DEBUG - 2022-07-02 03:09:44 --> Total execution time: 0.0556
DEBUG - 2022-07-02 03:09:47 --> Total execution time: 0.0575
DEBUG - 2022-07-02 03:09:49 --> Total execution time: 0.0679
DEBUG - 2022-07-02 03:09:51 --> Total execution time: 0.0944
DEBUG - 2022-07-02 03:10:05 --> Total execution time: 0.0782
DEBUG - 2022-07-02 03:10:26 --> Total execution time: 0.0551
DEBUG - 2022-07-02 03:10:45 --> Total execution time: 0.0532
DEBUG - 2022-07-02 03:10:47 --> Total execution time: 0.0557
DEBUG - 2022-07-02 03:10:52 --> Total execution time: 0.1303
DEBUG - 2022-07-02 03:11:02 --> Total execution time: 0.0984
DEBUG - 2022-07-02 03:11:39 --> Total execution time: 0.0574
DEBUG - 2022-07-02 03:12:49 --> Total execution time: 0.0775
DEBUG - 2022-07-02 03:15:16 --> Total execution time: 0.1966
DEBUG - 2022-07-02 03:15:24 --> Total execution time: 0.0641
DEBUG - 2022-07-02 03:15:48 --> Total execution time: 0.1470
DEBUG - 2022-07-02 03:15:53 --> Total execution time: 0.0544
DEBUG - 2022-07-02 03:15:55 --> Total execution time: 0.0607
DEBUG - 2022-07-02 03:16:41 --> Total execution time: 0.0480
DEBUG - 2022-07-02 03:16:44 --> Total execution time: 0.0484
DEBUG - 2022-07-02 03:16:56 --> Total execution time: 0.0737
DEBUG - 2022-07-02 03:17:27 --> Total execution time: 0.0826
DEBUG - 2022-07-02 03:17:28 --> Total execution time: 0.1219
DEBUG - 2022-07-02 03:17:29 --> Total execution time: 0.1017
DEBUG - 2022-07-02 03:17:29 --> Total execution time: 0.0770
DEBUG - 2022-07-02 03:17:30 --> Total execution time: 0.0675
DEBUG - 2022-07-02 03:17:31 --> Total execution time: 0.0514
DEBUG - 2022-07-02 03:17:31 --> Total execution time: 0.0752
DEBUG - 2022-07-02 03:17:31 --> Total execution time: 0.0702
DEBUG - 2022-07-02 03:17:32 --> Total execution time: 0.0733
DEBUG - 2022-07-02 03:17:48 --> Total execution time: 0.0415
DEBUG - 2022-07-02 03:19:25 --> Total execution time: 0.0468
DEBUG - 2022-07-02 03:30:04 --> Total execution time: 0.1688
DEBUG - 2022-07-02 03:32:44 --> Total execution time: 0.0387
DEBUG - 2022-07-02 03:32:49 --> Total execution time: 0.0326
DEBUG - 2022-07-02 03:41:04 --> Total execution time: 0.1061
DEBUG - 2022-07-02 03:41:07 --> Total execution time: 0.0334
DEBUG - 2022-07-02 04:08:37 --> Total execution time: 0.1084
DEBUG - 2022-07-02 04:30:02 --> Total execution time: 0.1698
DEBUG - 2022-07-02 05:25:53 --> Total execution time: 0.1356
DEBUG - 2022-07-02 05:26:24 --> Total execution time: 0.0341
DEBUG - 2022-07-02 05:26:58 --> Total execution time: 0.0770
DEBUG - 2022-07-02 05:27:07 --> Total execution time: 0.0652
DEBUG - 2022-07-02 05:27:29 --> Total execution time: 0.0643
DEBUG - 2022-07-02 05:27:37 --> Total execution time: 0.0583
DEBUG - 2022-07-02 05:27:50 --> Total execution time: 0.0720
DEBUG - 2022-07-02 05:28:09 --> Total execution time: 0.0522
DEBUG - 2022-07-02 05:28:27 --> Total execution time: 0.0508
DEBUG - 2022-07-02 05:28:30 --> Total execution time: 0.0816
DEBUG - 2022-07-02 05:30:02 --> Total execution time: 0.0690
DEBUG - 2022-07-02 05:41:28 --> Total execution time: 0.2040
DEBUG - 2022-07-02 05:51:50 --> Total execution time: 0.1398
DEBUG - 2022-07-02 06:00:14 --> Total execution time: 0.1297
DEBUG - 2022-07-02 06:08:13 --> Total execution time: 0.2255
DEBUG - 2022-07-02 06:08:39 --> Total execution time: 0.0520
DEBUG - 2022-07-02 06:08:51 --> Total execution time: 0.0552
DEBUG - 2022-07-02 06:09:26 --> Total execution time: 0.0502
DEBUG - 2022-07-02 06:09:33 --> Total execution time: 0.0577
DEBUG - 2022-07-02 06:09:36 --> Total execution time: 0.0569
DEBUG - 2022-07-02 06:10:33 --> Total execution time: 0.0476
DEBUG - 2022-07-02 06:12:45 --> Total execution time: 0.0467
DEBUG - 2022-07-02 06:14:35 --> Total execution time: 0.1317
DEBUG - 2022-07-02 06:14:52 --> Total execution time: 0.0482
DEBUG - 2022-07-02 06:28:39 --> Total execution time: 0.1185
DEBUG - 2022-07-02 06:28:51 --> Total execution time: 0.0510
DEBUG - 2022-07-02 06:29:00 --> Total execution time: 0.0775
DEBUG - 2022-07-02 06:30:02 --> Total execution time: 0.0970
DEBUG - 2022-07-02 06:35:06 --> Total execution time: 0.0577
DEBUG - 2022-07-02 06:35:17 --> Total execution time: 0.0567
DEBUG - 2022-07-02 06:36:31 --> Total execution time: 0.0394
DEBUG - 2022-07-02 06:48:04 --> Total execution time: 0.0542
DEBUG - 2022-07-02 07:03:51 --> Total execution time: 0.0330
DEBUG - 2022-07-02 07:03:52 --> Total execution time: 0.0394
DEBUG - 2022-07-02 07:22:42 --> Total execution time: 0.1060
DEBUG - 2022-07-02 07:22:46 --> Total execution time: 0.0322
DEBUG - 2022-07-02 07:22:52 --> Total execution time: 0.0919
DEBUG - 2022-07-02 07:23:01 --> Total execution time: 0.1003
DEBUG - 2022-07-02 07:23:41 --> Total execution time: 0.0416
DEBUG - 2022-07-02 07:24:30 --> Total execution time: 0.0345
DEBUG - 2022-07-02 07:24:30 --> Total execution time: 0.0325
DEBUG - 2022-07-02 07:24:35 --> Total execution time: 0.0317
DEBUG - 2022-07-02 07:25:50 --> Total execution time: 0.0486
DEBUG - 2022-07-02 07:27:52 --> Total execution time: 0.0349
DEBUG - 2022-07-02 07:27:55 --> Total execution time: 0.0504
DEBUG - 2022-07-02 07:28:14 --> Total execution time: 0.0368
DEBUG - 2022-07-02 07:28:15 --> Total execution time: 0.0472
DEBUG - 2022-07-02 07:30:00 --> Total execution time: 0.0448
DEBUG - 2022-07-02 07:30:03 --> Total execution time: 0.0899
DEBUG - 2022-07-02 07:34:02 --> Total execution time: 0.1564
DEBUG - 2022-07-02 07:34:52 --> Total execution time: 0.0515
DEBUG - 2022-07-02 07:34:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:34:53 --> Total execution time: 0.0623
DEBUG - 2022-07-02 07:36:25 --> Total execution time: 0.0503
DEBUG - 2022-07-02 07:37:26 --> Total execution time: 0.1330
DEBUG - 2022-07-02 07:37:53 --> Total execution time: 0.0513
DEBUG - 2022-07-02 07:38:02 --> Total execution time: 0.0537
DEBUG - 2022-07-02 07:38:03 --> Total execution time: 0.0710
DEBUG - 2022-07-02 07:38:03 --> Total execution time: 0.0708
DEBUG - 2022-07-02 07:38:04 --> Total execution time: 0.0566
DEBUG - 2022-07-02 07:38:05 --> Total execution time: 0.0498
DEBUG - 2022-07-02 07:38:09 --> Total execution time: 0.0520
DEBUG - 2022-07-02 07:38:31 --> Total execution time: 0.0493
DEBUG - 2022-07-02 07:38:54 --> Total execution time: 0.0417
DEBUG - 2022-07-02 07:39:58 --> Total execution time: 0.0481
DEBUG - 2022-07-02 07:40:05 --> Total execution time: 0.0511
DEBUG - 2022-07-02 07:40:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:40:06 --> Total execution time: 0.0505
DEBUG - 2022-07-02 07:40:17 --> Total execution time: 0.0507
DEBUG - 2022-07-02 07:40:30 --> Total execution time: 0.0511
DEBUG - 2022-07-02 07:43:53 --> Total execution time: 0.0615
DEBUG - 2022-07-02 07:44:32 --> Total execution time: 0.0504
DEBUG - 2022-07-02 07:47:04 --> Total execution time: 0.0900
DEBUG - 2022-07-02 07:47:05 --> Total execution time: 0.0710
DEBUG - 2022-07-02 07:47:26 --> Total execution time: 0.0640
DEBUG - 2022-07-02 07:47:35 --> Total execution time: 0.0672
DEBUG - 2022-07-02 07:47:49 --> Total execution time: 0.0752
DEBUG - 2022-07-02 07:48:00 --> Total execution time: 0.0719
DEBUG - 2022-07-02 07:48:00 --> Total execution time: 0.0722
DEBUG - 2022-07-02 07:48:04 --> Total execution time: 0.0616
DEBUG - 2022-07-02 07:48:17 --> Total execution time: 0.0611
DEBUG - 2022-07-02 07:52:34 --> Total execution time: 0.0818
DEBUG - 2022-07-02 07:56:33 --> Total execution time: 0.0428
DEBUG - 2022-07-02 07:57:40 --> Total execution time: 0.0491
DEBUG - 2022-07-02 07:57:57 --> Total execution time: 0.0682
DEBUG - 2022-07-02 07:58:11 --> Total execution time: 0.0801
DEBUG - 2022-07-02 07:58:21 --> Total execution time: 0.0604
DEBUG - 2022-07-02 07:58:29 --> Total execution time: 0.1291
DEBUG - 2022-07-02 07:58:30 --> Total execution time: 0.1229
DEBUG - 2022-07-02 07:58:32 --> Total execution time: 0.0521
DEBUG - 2022-07-02 07:58:35 --> Total execution time: 0.0699
DEBUG - 2022-07-02 07:58:36 --> Total execution time: 0.0594
DEBUG - 2022-07-02 07:58:39 --> Total execution time: 0.0552
DEBUG - 2022-07-02 07:58:48 --> Total execution time: 0.0826
DEBUG - 2022-07-02 07:58:49 --> Total execution time: 0.1146
DEBUG - 2022-07-02 07:58:50 --> Total execution time: 0.0503
DEBUG - 2022-07-02 07:58:59 --> Total execution time: 0.0475
DEBUG - 2022-07-02 07:59:09 --> Total execution time: 0.0877
DEBUG - 2022-07-02 07:59:30 --> Total execution time: 0.0686
DEBUG - 2022-07-02 07:59:33 --> Total execution time: 0.0501
DEBUG - 2022-07-02 07:59:35 --> Total execution time: 0.0481
DEBUG - 2022-07-02 07:59:44 --> Total execution time: 0.0685
DEBUG - 2022-07-02 08:00:32 --> Total execution time: 0.0336
DEBUG - 2022-07-02 08:01:01 --> Total execution time: 0.0488
DEBUG - 2022-07-02 08:01:03 --> Total execution time: 0.0338
DEBUG - 2022-07-02 08:01:19 --> Total execution time: 0.0498
DEBUG - 2022-07-02 08:01:37 --> Total execution time: 0.0569
DEBUG - 2022-07-02 08:01:51 --> Total execution time: 0.0473
DEBUG - 2022-07-02 08:02:19 --> Total execution time: 0.0544
DEBUG - 2022-07-02 08:02:22 --> Total execution time: 0.0493
DEBUG - 2022-07-02 08:03:20 --> Total execution time: 0.0598
DEBUG - 2022-07-02 08:03:35 --> Total execution time: 0.0478
DEBUG - 2022-07-02 08:03:37 --> Total execution time: 0.0632
DEBUG - 2022-07-02 08:03:42 --> Total execution time: 0.1161
DEBUG - 2022-07-02 08:04:04 --> Total execution time: 0.0555
DEBUG - 2022-07-02 08:11:03 --> Total execution time: 0.2057
DEBUG - 2022-07-02 08:13:35 --> Total execution time: 0.1252
DEBUG - 2022-07-02 08:13:39 --> Total execution time: 0.0328
DEBUG - 2022-07-02 08:13:46 --> Total execution time: 0.0664
DEBUG - 2022-07-02 08:13:52 --> Total execution time: 0.0550
DEBUG - 2022-07-02 08:13:53 --> Total execution time: 0.0436
DEBUG - 2022-07-02 08:13:55 --> Total execution time: 0.0559
DEBUG - 2022-07-02 08:14:01 --> Total execution time: 0.0486
DEBUG - 2022-07-02 08:14:02 --> Total execution time: 0.0583
DEBUG - 2022-07-02 08:14:19 --> Total execution time: 0.0449
DEBUG - 2022-07-02 08:14:24 --> Total execution time: 0.0652
DEBUG - 2022-07-02 08:14:40 --> Total execution time: 0.0752
DEBUG - 2022-07-02 08:15:09 --> Total execution time: 0.0491
DEBUG - 2022-07-02 08:15:31 --> Total execution time: 0.0481
DEBUG - 2022-07-02 08:15:48 --> Total execution time: 0.0430
DEBUG - 2022-07-02 08:17:03 --> Total execution time: 0.0509
DEBUG - 2022-07-02 08:17:07 --> Total execution time: 0.0458
DEBUG - 2022-07-02 08:17:08 --> Total execution time: 0.0475
DEBUG - 2022-07-02 08:17:09 --> Total execution time: 0.0433
DEBUG - 2022-07-02 08:17:10 --> Total execution time: 0.0419
DEBUG - 2022-07-02 08:17:10 --> Total execution time: 0.0424
DEBUG - 2022-07-02 08:17:10 --> Total execution time: 0.0518
DEBUG - 2022-07-02 08:18:05 --> Total execution time: 0.0444
DEBUG - 2022-07-02 08:19:03 --> Total execution time: 0.0558
DEBUG - 2022-07-02 08:20:10 --> Total execution time: 0.0494
DEBUG - 2022-07-02 08:20:20 --> Total execution time: 0.0450
DEBUG - 2022-07-02 08:20:34 --> Total execution time: 0.0340
DEBUG - 2022-07-02 08:20:38 --> Total execution time: 0.1124
DEBUG - 2022-07-02 08:20:42 --> Total execution time: 0.0588
DEBUG - 2022-07-02 08:20:56 --> Total execution time: 0.0788
DEBUG - 2022-07-02 08:21:57 --> Total execution time: 0.0500
DEBUG - 2022-07-02 08:22:49 --> Total execution time: 0.0534
DEBUG - 2022-07-02 08:23:31 --> Total execution time: 0.0813
DEBUG - 2022-07-02 08:23:38 --> Total execution time: 0.0685
DEBUG - 2022-07-02 08:23:42 --> Total execution time: 0.0746
DEBUG - 2022-07-02 08:25:06 --> Total execution time: 0.0365
DEBUG - 2022-07-02 08:28:12 --> Total execution time: 0.1398
DEBUG - 2022-07-02 08:30:02 --> Total execution time: 0.0608
DEBUG - 2022-07-02 08:32:33 --> Total execution time: 0.1402
DEBUG - 2022-07-02 08:42:47 --> Total execution time: 0.1016
DEBUG - 2022-07-02 08:42:48 --> Total execution time: 0.0574
DEBUG - 2022-07-02 08:43:02 --> Total execution time: 0.0330
DEBUG - 2022-07-02 08:43:14 --> Total execution time: 0.0761
DEBUG - 2022-07-02 08:43:22 --> Total execution time: 0.0593
DEBUG - 2022-07-02 08:43:26 --> Total execution time: 0.0555
DEBUG - 2022-07-02 08:43:47 --> Total execution time: 0.0346
DEBUG - 2022-07-02 08:44:16 --> Total execution time: 0.1612
DEBUG - 2022-07-02 08:44:18 --> Total execution time: 0.0420
DEBUG - 2022-07-02 08:44:20 --> Total execution time: 0.0536
DEBUG - 2022-07-02 08:44:29 --> Total execution time: 0.0485
DEBUG - 2022-07-02 08:44:34 --> Total execution time: 0.0531
DEBUG - 2022-07-02 08:44:37 --> Total execution time: 0.0667
DEBUG - 2022-07-02 08:44:48 --> Total execution time: 0.0485
DEBUG - 2022-07-02 08:51:40 --> Total execution time: 0.0564
DEBUG - 2022-07-02 08:51:53 --> Total execution time: 0.0450
DEBUG - 2022-07-02 08:52:31 --> Total execution time: 0.0509
DEBUG - 2022-07-02 08:54:36 --> Total execution time: 0.2225
DEBUG - 2022-07-02 08:54:50 --> Total execution time: 0.0400
DEBUG - 2022-07-02 08:55:15 --> Total execution time: 0.0366
DEBUG - 2022-07-02 08:55:20 --> Total execution time: 0.0344
DEBUG - 2022-07-02 08:55:40 --> Total execution time: 0.0528
DEBUG - 2022-07-02 08:55:44 --> Total execution time: 0.0324
DEBUG - 2022-07-02 08:55:55 --> Total execution time: 0.0511
DEBUG - 2022-07-02 08:56:08 --> Total execution time: 0.0831
DEBUG - 2022-07-02 08:56:13 --> Total execution time: 0.0503
DEBUG - 2022-07-02 08:56:16 --> Total execution time: 0.0583
DEBUG - 2022-07-02 08:56:16 --> Total execution time: 0.0635
DEBUG - 2022-07-02 08:56:22 --> Total execution time: 0.0611
DEBUG - 2022-07-02 08:56:27 --> Total execution time: 0.0567
DEBUG - 2022-07-02 08:56:30 --> Total execution time: 0.0685
DEBUG - 2022-07-02 08:56:33 --> Total execution time: 0.0567
DEBUG - 2022-07-02 08:56:36 --> Total execution time: 0.0475
DEBUG - 2022-07-02 09:06:50 --> Total execution time: 0.1135
DEBUG - 2022-07-02 09:08:29 --> Total execution time: 0.0466
DEBUG - 2022-07-02 09:08:36 --> Total execution time: 0.0562
DEBUG - 2022-07-02 09:08:38 --> Total execution time: 0.0554
DEBUG - 2022-07-02 09:08:40 --> Total execution time: 0.0613
DEBUG - 2022-07-02 09:08:48 --> Total execution time: 0.0603
DEBUG - 2022-07-02 09:10:55 --> Total execution time: 0.1999
DEBUG - 2022-07-02 09:13:29 --> Total execution time: 0.1730
DEBUG - 2022-07-02 09:13:29 --> Total execution time: 0.0488
DEBUG - 2022-07-02 09:15:44 --> Total execution time: 0.0571
DEBUG - 2022-07-02 09:16:31 --> Total execution time: 0.1762
DEBUG - 2022-07-02 09:16:40 --> Total execution time: 0.0542
DEBUG - 2022-07-02 09:16:52 --> Total execution time: 0.0461
DEBUG - 2022-07-02 09:17:16 --> Total execution time: 0.0557
DEBUG - 2022-07-02 09:17:25 --> Total execution time: 0.0831
DEBUG - 2022-07-02 09:17:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 09:17:26 --> Total execution time: 0.0598
DEBUG - 2022-07-02 09:17:28 --> Total execution time: 0.0782
DEBUG - 2022-07-02 09:17:33 --> Total execution time: 0.0514
DEBUG - 2022-07-02 09:17:54 --> Total execution time: 0.0552
DEBUG - 2022-07-02 09:18:06 --> Total execution time: 0.0749
DEBUG - 2022-07-02 09:19:45 --> Total execution time: 0.0527
DEBUG - 2022-07-02 09:28:40 --> Total execution time: 0.2089
DEBUG - 2022-07-02 09:28:40 --> Total execution time: 0.0480
DEBUG - 2022-07-02 09:28:44 --> Total execution time: 0.0478
DEBUG - 2022-07-02 09:28:50 --> Total execution time: 0.0862
DEBUG - 2022-07-02 09:28:54 --> Total execution time: 0.0554
DEBUG - 2022-07-02 09:28:57 --> Total execution time: 0.0952
DEBUG - 2022-07-02 09:30:01 --> Total execution time: 0.0807
DEBUG - 2022-07-02 09:30:01 --> Total execution time: 0.0649
DEBUG - 2022-07-02 09:30:02 --> Total execution time: 0.1068
DEBUG - 2022-07-02 09:30:11 --> Total execution time: 0.0760
DEBUG - 2022-07-02 09:31:28 --> Total execution time: 0.0543
DEBUG - 2022-07-02 09:39:09 --> Total execution time: 0.1259
DEBUG - 2022-07-02 09:39:34 --> Total execution time: 0.0406
DEBUG - 2022-07-02 09:39:43 --> Total execution time: 0.1230
DEBUG - 2022-07-02 09:39:46 --> Total execution time: 0.0542
DEBUG - 2022-07-02 09:44:39 --> Total execution time: 0.0552
DEBUG - 2022-07-02 09:44:49 --> Total execution time: 0.0582
DEBUG - 2022-07-02 09:45:45 --> Total execution time: 0.0605
DEBUG - 2022-07-02 09:45:54 --> Total execution time: 0.0599
DEBUG - 2022-07-02 09:46:00 --> Total execution time: 0.0463
DEBUG - 2022-07-02 09:46:02 --> Total execution time: 0.0404
DEBUG - 2022-07-02 09:46:07 --> Total execution time: 0.0589
DEBUG - 2022-07-02 09:46:19 --> Total execution time: 0.0550
DEBUG - 2022-07-02 09:46:20 --> Total execution time: 0.0458
DEBUG - 2022-07-02 09:46:25 --> Total execution time: 0.0966
DEBUG - 2022-07-02 09:46:31 --> Total execution time: 0.0655
DEBUG - 2022-07-02 09:46:35 --> Total execution time: 0.0547
DEBUG - 2022-07-02 09:46:36 --> Total execution time: 0.0501
DEBUG - 2022-07-02 09:46:43 --> Total execution time: 0.0510
DEBUG - 2022-07-02 09:46:50 --> Total execution time: 0.0470
DEBUG - 2022-07-02 09:50:41 --> Total execution time: 0.0908
DEBUG - 2022-07-02 09:51:41 --> Total execution time: 0.1207
DEBUG - 2022-07-02 09:51:52 --> Total execution time: 0.0353
DEBUG - 2022-07-02 09:52:16 --> Total execution time: 0.0432
DEBUG - 2022-07-02 09:53:04 --> Total execution time: 0.0581
DEBUG - 2022-07-02 09:53:05 --> Total execution time: 0.0405
DEBUG - 2022-07-02 09:53:46 --> Total execution time: 0.0507
DEBUG - 2022-07-02 09:53:57 --> Total execution time: 0.1010
DEBUG - 2022-07-02 09:54:05 --> Total execution time: 0.0523
DEBUG - 2022-07-02 09:54:17 --> Total execution time: 0.0800
DEBUG - 2022-07-02 09:54:22 --> Total execution time: 0.0860
DEBUG - 2022-07-02 09:54:33 --> Total execution time: 0.0482
DEBUG - 2022-07-02 09:55:15 --> Total execution time: 0.0765
DEBUG - 2022-07-02 09:55:52 --> Total execution time: 0.0521
DEBUG - 2022-07-02 09:56:23 --> Total execution time: 0.0563
DEBUG - 2022-07-02 09:56:28 --> Total execution time: 0.0633
DEBUG - 2022-07-02 09:59:14 --> Total execution time: 0.1094
DEBUG - 2022-07-02 09:59:34 --> Total execution time: 0.0577
DEBUG - 2022-07-02 10:00:44 --> Total execution time: 0.0383
DEBUG - 2022-07-02 10:00:45 --> Total execution time: 0.0392
DEBUG - 2022-07-02 10:01:01 --> Total execution time: 0.0753
DEBUG - 2022-07-02 10:01:07 --> Total execution time: 0.0905
DEBUG - 2022-07-02 10:01:13 --> Total execution time: 0.0602
DEBUG - 2022-07-02 10:02:21 --> Total execution time: 0.0809
DEBUG - 2022-07-02 10:02:26 --> Total execution time: 0.0676
DEBUG - 2022-07-02 10:03:09 --> Total execution time: 0.0644
DEBUG - 2022-07-02 10:03:12 --> Total execution time: 0.1817
DEBUG - 2022-07-02 10:03:14 --> Total execution time: 0.0627
DEBUG - 2022-07-02 10:03:33 --> Total execution time: 0.0483
DEBUG - 2022-07-02 10:04:05 --> Total execution time: 0.0480
DEBUG - 2022-07-02 10:04:42 --> Total execution time: 0.0493
DEBUG - 2022-07-02 10:04:56 --> Total execution time: 0.0513
DEBUG - 2022-07-02 10:06:23 --> Total execution time: 0.1414
DEBUG - 2022-07-02 10:06:37 --> Total execution time: 0.0538
DEBUG - 2022-07-02 10:06:38 --> Total execution time: 0.0429
DEBUG - 2022-07-02 10:06:50 --> Total execution time: 0.0512
DEBUG - 2022-07-02 10:06:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 10:06:51 --> Total execution time: 0.0424
DEBUG - 2022-07-02 10:08:35 --> Total execution time: 0.0380
DEBUG - 2022-07-02 10:11:02 --> Total execution time: 0.0465
DEBUG - 2022-07-02 10:11:03 --> Total execution time: 0.0462
DEBUG - 2022-07-02 10:11:06 --> Total execution time: 0.0409
DEBUG - 2022-07-02 10:11:06 --> Total execution time: 0.0580
DEBUG - 2022-07-02 10:14:29 --> Total execution time: 0.0497
DEBUG - 2022-07-02 10:14:50 --> Total execution time: 0.1622
DEBUG - 2022-07-02 10:14:52 --> Total execution time: 0.0515
DEBUG - 2022-07-02 10:15:17 --> Total execution time: 0.0944
DEBUG - 2022-07-02 10:16:16 --> Total execution time: 0.0470
DEBUG - 2022-07-02 10:16:34 --> Total execution time: 0.0464
DEBUG - 2022-07-02 10:16:34 --> Total execution time: 0.0436
DEBUG - 2022-07-02 10:16:59 --> Total execution time: 0.0323
DEBUG - 2022-07-02 10:17:09 --> Total execution time: 0.1098
DEBUG - 2022-07-02 10:17:20 --> Total execution time: 0.0463
DEBUG - 2022-07-02 10:17:26 --> Total execution time: 0.0341
DEBUG - 2022-07-02 10:17:44 --> Total execution time: 0.1646
DEBUG - 2022-07-02 10:17:49 --> Total execution time: 0.0615
DEBUG - 2022-07-02 10:18:00 --> Total execution time: 0.0566
DEBUG - 2022-07-02 10:18:02 --> Total execution time: 0.1136
DEBUG - 2022-07-02 10:18:18 --> Total execution time: 1.5947
DEBUG - 2022-07-02 10:18:28 --> Total execution time: 0.0459
DEBUG - 2022-07-02 10:18:31 --> Total execution time: 0.0706
DEBUG - 2022-07-02 10:18:45 --> Total execution time: 0.0527
DEBUG - 2022-07-02 10:18:49 --> Total execution time: 0.0453
DEBUG - 2022-07-02 10:18:53 --> Total execution time: 0.0744
DEBUG - 2022-07-02 10:19:01 --> Total execution time: 0.0797
DEBUG - 2022-07-02 10:19:08 --> Total execution time: 0.0590
DEBUG - 2022-07-02 10:19:22 --> Total execution time: 0.0604
DEBUG - 2022-07-02 10:19:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 10:19:23 --> Total execution time: 0.0569
DEBUG - 2022-07-02 10:19:26 --> Total execution time: 0.0742
DEBUG - 2022-07-02 10:19:43 --> Total execution time: 0.0586
DEBUG - 2022-07-02 10:20:18 --> Total execution time: 0.0450
DEBUG - 2022-07-02 10:20:33 --> Total execution time: 0.0338
DEBUG - 2022-07-02 10:20:40 --> Total execution time: 0.0549
DEBUG - 2022-07-02 10:20:58 --> Total execution time: 0.0882
DEBUG - 2022-07-02 10:21:16 --> Total execution time: 0.0885
DEBUG - 2022-07-02 10:22:26 --> Total execution time: 0.0566
DEBUG - 2022-07-02 10:23:10 --> Total execution time: 0.1279
DEBUG - 2022-07-02 10:23:22 --> Total execution time: 0.0457
DEBUG - 2022-07-02 10:23:28 --> Total execution time: 0.0522
DEBUG - 2022-07-02 10:23:39 --> Total execution time: 0.0459
DEBUG - 2022-07-02 10:23:49 --> Total execution time: 0.0462
DEBUG - 2022-07-02 10:24:08 --> Total execution time: 0.0509
DEBUG - 2022-07-02 10:24:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 10:24:10 --> Total execution time: 0.0595
DEBUG - 2022-07-02 10:27:59 --> Total execution time: 0.1862
DEBUG - 2022-07-02 10:29:16 --> Total execution time: 0.0601
DEBUG - 2022-07-02 10:29:20 --> Total execution time: 0.0858
DEBUG - 2022-07-02 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:30:02 --> Total execution time: 0.0842
DEBUG - 2022-07-02 00:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:00:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:30:20 --> Total execution time: 0.0578
DEBUG - 2022-07-02 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:30:27 --> Total execution time: 0.0452
DEBUG - 2022-07-02 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:31:11 --> Total execution time: 0.0590
DEBUG - 2022-07-02 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:31:41 --> Total execution time: 0.0837
DEBUG - 2022-07-02 00:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:31:46 --> Total execution time: 0.0633
DEBUG - 2022-07-02 00:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:31:58 --> Total execution time: 0.0717
DEBUG - 2022-07-02 00:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:32:10 --> Total execution time: 0.0457
DEBUG - 2022-07-02 00:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:32:28 --> Total execution time: 0.0510
DEBUG - 2022-07-02 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:33:36 --> Total execution time: 0.1163
DEBUG - 2022-07-02 00:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:03:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:33:43 --> Total execution time: 0.0843
DEBUG - 2022-07-02 00:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:33:52 --> Total execution time: 0.0500
DEBUG - 2022-07-02 00:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:34:03 --> Total execution time: 0.0497
DEBUG - 2022-07-02 00:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:34:14 --> Total execution time: 0.0724
DEBUG - 2022-07-02 00:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:34:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 00:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:34:16 --> Total execution time: 0.0406
DEBUG - 2022-07-02 00:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:35:23 --> Total execution time: 0.0612
DEBUG - 2022-07-02 00:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 00:08:29 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:38:51 --> Total execution time: 0.0485
DEBUG - 2022-07-02 00:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:41:06 --> Total execution time: 0.1544
DEBUG - 2022-07-02 00:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:11:25 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:41:26 --> Total execution time: 0.1681
DEBUG - 2022-07-02 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:41:31 --> Total execution time: 0.0976
DEBUG - 2022-07-02 00:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:41:41 --> Total execution time: 0.0718
DEBUG - 2022-07-02 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:41:44 --> Total execution time: 0.0856
DEBUG - 2022-07-02 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:42:07 --> Total execution time: 0.0587
DEBUG - 2022-07-02 00:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:13:55 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:43:55 --> Total execution time: 0.0445
DEBUG - 2022-07-02 00:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:01 --> Total execution time: 0.1179
DEBUG - 2022-07-02 00:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:01 --> Total execution time: 0.0668
DEBUG - 2022-07-02 00:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:01 --> Total execution time: 0.0745
DEBUG - 2022-07-02 00:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:02 --> Total execution time: 0.0557
DEBUG - 2022-07-02 00:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:02 --> Total execution time: 0.0561
DEBUG - 2022-07-02 00:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:25 --> Total execution time: 0.1308
DEBUG - 2022-07-02 00:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:37 --> Total execution time: 0.0586
DEBUG - 2022-07-02 00:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:43 --> Total execution time: 0.0471
DEBUG - 2022-07-02 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:49 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:49 --> Total execution time: 0.0465
DEBUG - 2022-07-02 00:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:50 --> Total execution time: 0.0567
DEBUG - 2022-07-02 00:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:50 --> Total execution time: 0.0466
DEBUG - 2022-07-02 00:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:56 --> Total execution time: 0.0952
DEBUG - 2022-07-02 00:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 00:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:46:57 --> Total execution time: 0.0542
DEBUG - 2022-07-02 00:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:01 --> Total execution time: 0.0964
DEBUG - 2022-07-02 00:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:10 --> Total execution time: 0.0936
DEBUG - 2022-07-02 00:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:22 --> Total execution time: 0.0727
DEBUG - 2022-07-02 00:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:29 --> Total execution time: 0.0873
DEBUG - 2022-07-02 00:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:39 --> Total execution time: 0.0503
DEBUG - 2022-07-02 00:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:43 --> Total execution time: 0.1558
DEBUG - 2022-07-02 00:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:49 --> Total execution time: 0.0664
DEBUG - 2022-07-02 00:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:47:58 --> Total execution time: 0.0542
DEBUG - 2022-07-02 00:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:06 --> Total execution time: 0.0723
DEBUG - 2022-07-02 00:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:14 --> Total execution time: 0.0471
DEBUG - 2022-07-02 00:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:27 --> Total execution time: 0.0760
DEBUG - 2022-07-02 00:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:49:06 --> Total execution time: 0.0526
DEBUG - 2022-07-02 00:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:49:33 --> Total execution time: 0.0532
DEBUG - 2022-07-02 00:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:49:33 --> Total execution time: 0.0344
DEBUG - 2022-07-02 00:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:19:46 --> Total execution time: 0.0579
DEBUG - 2022-07-02 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:19:48 --> Total execution time: 0.0535
DEBUG - 2022-07-02 00:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:19:48 --> Total execution time: 0.1024
DEBUG - 2022-07-02 00:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:19:53 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:49:53 --> Total execution time: 0.0530
DEBUG - 2022-07-02 00:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:28:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:58:46 --> Total execution time: 0.1163
DEBUG - 2022-07-02 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:29:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:59:04 --> Total execution time: 0.0657
DEBUG - 2022-07-02 00:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:00:08 --> Total execution time: 0.1404
DEBUG - 2022-07-02 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:30:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:00:20 --> Total execution time: 0.0665
DEBUG - 2022-07-02 00:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:32:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:02:11 --> Total execution time: 0.1346
DEBUG - 2022-07-02 00:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:20:24 --> Total execution time: 0.3286
DEBUG - 2022-07-02 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:54:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:24:46 --> Total execution time: 0.0578
DEBUG - 2022-07-02 00:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:24:55 --> Total execution time: 0.0526
DEBUG - 2022-07-02 00:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:25:23 --> Total execution time: 0.0514
DEBUG - 2022-07-02 00:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 00:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:26:25 --> Total execution time: 0.0512
DEBUG - 2022-07-02 00:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:56:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:26:37 --> Total execution time: 0.0509
DEBUG - 2022-07-02 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:56:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:26:48 --> Total execution time: 0.0822
DEBUG - 2022-07-02 00:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:27:01 --> Total execution time: 0.0483
DEBUG - 2022-07-02 00:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 00:58:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 00:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 00:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:28:07 --> Total execution time: 0.0421
DEBUG - 2022-07-02 01:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:30:05 --> Total execution time: 0.0453
DEBUG - 2022-07-02 01:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:30:16 --> Total execution time: 0.1337
DEBUG - 2022-07-02 01:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:00:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:30:31 --> Total execution time: 0.0836
DEBUG - 2022-07-02 01:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:30:52 --> Total execution time: 0.0456
DEBUG - 2022-07-02 01:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:04 --> Total execution time: 0.0623
DEBUG - 2022-07-02 01:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:14 --> Total execution time: 0.0465
DEBUG - 2022-07-02 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:16 --> Total execution time: 0.0780
DEBUG - 2022-07-02 01:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:21 --> Total execution time: 0.0532
DEBUG - 2022-07-02 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:31 --> Total execution time: 0.1069
DEBUG - 2022-07-02 01:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:40 --> Total execution time: 0.1034
DEBUG - 2022-07-02 01:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:40 --> Total execution time: 0.0552
DEBUG - 2022-07-02 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:45 --> Total execution time: 0.0542
DEBUG - 2022-07-02 01:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:31:53 --> Total execution time: 0.0633
DEBUG - 2022-07-02 01:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:02:29 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 01:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:32:39 --> Total execution time: 0.0534
DEBUG - 2022-07-02 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:33:21 --> Total execution time: 0.0553
DEBUG - 2022-07-02 01:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:03:55 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:33:55 --> Total execution time: 0.0375
DEBUG - 2022-07-02 01:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:04:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:34:31 --> Total execution time: 0.0364
DEBUG - 2022-07-02 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:40:16 --> Total execution time: 0.1419
DEBUG - 2022-07-02 01:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:40:46 --> Total execution time: 0.0424
DEBUG - 2022-07-02 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:41:34 --> Total execution time: 0.1350
DEBUG - 2022-07-02 01:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:41:38 --> Total execution time: 0.0566
DEBUG - 2022-07-02 01:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:11:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:41:40 --> Total execution time: 0.0386
DEBUG - 2022-07-02 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:11:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:41:44 --> Total execution time: 0.0329
DEBUG - 2022-07-02 01:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:43:24 --> Total execution time: 0.0332
DEBUG - 2022-07-02 01:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:44:14 --> Total execution time: 0.0246
DEBUG - 2022-07-02 01:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:45:16 --> Total execution time: 0.0466
DEBUG - 2022-07-02 01:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:46:36 --> Total execution time: 0.0581
DEBUG - 2022-07-02 01:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:46:51 --> Total execution time: 0.1194
DEBUG - 2022-07-02 01:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:47:35 --> Total execution time: 0.1045
DEBUG - 2022-07-02 01:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:17:36 --> Total execution time: 0.0362
DEBUG - 2022-07-02 01:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:49:22 --> Total execution time: 0.0918
DEBUG - 2022-07-02 01:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:49:32 --> Total execution time: 0.0718
DEBUG - 2022-07-02 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:49:37 --> Total execution time: 0.1010
DEBUG - 2022-07-02 01:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:49:48 --> Total execution time: 0.0673
DEBUG - 2022-07-02 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:50:29 --> Total execution time: 0.0639
DEBUG - 2022-07-02 01:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:50:49 --> Total execution time: 0.0666
DEBUG - 2022-07-02 01:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:51:01 --> Total execution time: 0.0547
DEBUG - 2022-07-02 01:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:51:04 --> Total execution time: 0.0518
DEBUG - 2022-07-02 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:51:10 --> Total execution time: 0.0519
DEBUG - 2022-07-02 01:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:21:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:51:48 --> Total execution time: 0.0379
DEBUG - 2022-07-02 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:21:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 01:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:52:58 --> Total execution time: 0.0538
DEBUG - 2022-07-02 01:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:53:01 --> Total execution time: 0.0680
DEBUG - 2022-07-02 01:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:53:31 --> Total execution time: 0.1066
DEBUG - 2022-07-02 01:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:25:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:25:40 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:56:37 --> Total execution time: 0.1114
DEBUG - 2022-07-02 01:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:57:10 --> Total execution time: 0.1284
DEBUG - 2022-07-02 01:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:57:11 --> Total execution time: 0.0555
DEBUG - 2022-07-02 01:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:28:14 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 01:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:58:21 --> Total execution time: 0.0578
DEBUG - 2022-07-02 01:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:58:24 --> Total execution time: 0.0629
DEBUG - 2022-07-02 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:58:32 --> Total execution time: 0.0697
DEBUG - 2022-07-02 01:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:58:57 --> Total execution time: 0.0735
DEBUG - 2022-07-02 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:29:20 --> Total execution time: 0.0587
DEBUG - 2022-07-02 01:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:59:32 --> Total execution time: 0.0885
DEBUG - 2022-07-02 01:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:30:28 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 01:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:00:46 --> Total execution time: 0.0764
DEBUG - 2022-07-02 01:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:31:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:01:29 --> Total execution time: 0.0477
DEBUG - 2022-07-02 01:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:31:48 --> Total execution time: 0.0392
DEBUG - 2022-07-02 01:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:31:49 --> Total execution time: 0.0718
DEBUG - 2022-07-02 01:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:31:49 --> Total execution time: 0.1283
DEBUG - 2022-07-02 01:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:31:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:01:56 --> Total execution time: 0.0466
DEBUG - 2022-07-02 01:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:32:00 --> Total execution time: 0.0415
DEBUG - 2022-07-02 01:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:32:01 --> Total execution time: 0.0607
DEBUG - 2022-07-02 01:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:32:01 --> Total execution time: 0.0880
DEBUG - 2022-07-02 01:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:02:13 --> Total execution time: 0.0457
DEBUG - 2022-07-02 01:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:05:16 --> Total execution time: 0.0519
DEBUG - 2022-07-02 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:05:28 --> Total execution time: 0.0610
DEBUG - 2022-07-02 01:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:05:33 --> Total execution time: 0.0829
DEBUG - 2022-07-02 01:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:05:37 --> Total execution time: 0.0808
DEBUG - 2022-07-02 01:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:07:19 --> Total execution time: 0.0489
DEBUG - 2022-07-02 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:08:27 --> Total execution time: 0.1609
DEBUG - 2022-07-02 01:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:13:52 --> Total execution time: 0.2136
DEBUG - 2022-07-02 01:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:14:05 --> Total execution time: 0.1572
DEBUG - 2022-07-02 01:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:14:18 --> Total execution time: 0.0879
DEBUG - 2022-07-02 01:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:45:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:15:23 --> Total execution time: 0.0525
DEBUG - 2022-07-02 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:45:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:15:27 --> Total execution time: 0.0485
DEBUG - 2022-07-02 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:15:37 --> Total execution time: 0.0435
DEBUG - 2022-07-02 01:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:15:47 --> Total execution time: 0.0606
DEBUG - 2022-07-02 01:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:15:55 --> Total execution time: 0.0538
DEBUG - 2022-07-02 01:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:16:07 --> Total execution time: 0.0690
DEBUG - 2022-07-02 01:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:16:15 --> Total execution time: 0.1159
DEBUG - 2022-07-02 01:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:16:46 --> Total execution time: 0.0621
DEBUG - 2022-07-02 01:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:16:50 --> Total execution time: 0.0526
DEBUG - 2022-07-02 01:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:04 --> Total execution time: 0.0502
DEBUG - 2022-07-02 01:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:18 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:18 --> Total execution time: 0.0397
DEBUG - 2022-07-02 12:17:19 --> Total execution time: 1.5773
DEBUG - 2022-07-02 01:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:23 --> Total execution time: 0.0382
DEBUG - 2022-07-02 01:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:47:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 01:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:47:31 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-07-02 01:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:31 --> Total execution time: 0.0585
DEBUG - 2022-07-02 01:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:35 --> Total execution time: 0.0528
DEBUG - 2022-07-02 01:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:40 --> Total execution time: 0.0690
DEBUG - 2022-07-02 01:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:45 --> Total execution time: 0.0604
DEBUG - 2022-07-02 01:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:17:51 --> Total execution time: 0.0651
DEBUG - 2022-07-02 01:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:18:03 --> Total execution time: 0.1183
DEBUG - 2022-07-02 01:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:18:14 --> Total execution time: 1.5012
DEBUG - 2022-07-02 01:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:18:14 --> Total execution time: 0.0971
DEBUG - 2022-07-02 01:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:48:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:48:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 01:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:48:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 01:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:18:40 --> Total execution time: 0.0533
DEBUG - 2022-07-02 01:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:50:00 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 01:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:51:58 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-02 01:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:14 --> Total execution time: 0.3869
DEBUG - 2022-07-02 01:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:15 --> Total execution time: 0.1243
DEBUG - 2022-07-02 01:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:22 --> Total execution time: 0.0772
DEBUG - 2022-07-02 01:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:29 --> Total execution time: 0.0996
DEBUG - 2022-07-02 01:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:30 --> Total execution time: 0.1105
DEBUG - 2022-07-02 01:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:30 --> Total execution time: 0.1543
DEBUG - 2022-07-02 01:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:31 --> Total execution time: 0.1242
DEBUG - 2022-07-02 01:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:36 --> Total execution time: 0.0640
DEBUG - 2022-07-02 01:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:39 --> Total execution time: 0.0852
DEBUG - 2022-07-02 01:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 01:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:41 --> Total execution time: 0.0805
DEBUG - 2022-07-02 01:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 01:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:23:31 --> Total execution time: 0.1564
DEBUG - 2022-07-02 01:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 01:54:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 01:54:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:30:04 --> Total execution time: 0.2269
DEBUG - 2022-07-02 02:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:00:35 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:30:35 --> Total execution time: 0.0666
DEBUG - 2022-07-02 02:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:30:43 --> Total execution time: 0.0633
DEBUG - 2022-07-02 02:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:30:53 --> Total execution time: 0.0628
DEBUG - 2022-07-02 02:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:00 --> Total execution time: 0.0578
DEBUG - 2022-07-02 02:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:15 --> Total execution time: 0.0688
DEBUG - 2022-07-02 02:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:26 --> Total execution time: 0.1385
DEBUG - 2022-07-02 02:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:27 --> Total execution time: 0.0556
DEBUG - 2022-07-02 02:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:45 --> Total execution time: 0.0601
DEBUG - 2022-07-02 02:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:50 --> Total execution time: 0.1033
DEBUG - 2022-07-02 02:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:31:55 --> Total execution time: 0.0935
DEBUG - 2022-07-02 02:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:32:19 --> Total execution time: 0.0684
DEBUG - 2022-07-02 02:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:32:20 --> Total execution time: 0.0598
DEBUG - 2022-07-02 02:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:34:59 --> Total execution time: 0.1422
DEBUG - 2022-07-02 02:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:35:10 --> Total execution time: 0.0769
DEBUG - 2022-07-02 02:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:35:12 --> Total execution time: 0.0870
DEBUG - 2022-07-02 02:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:35:14 --> Total execution time: 0.0828
DEBUG - 2022-07-02 02:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:10:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:40:48 --> Total execution time: 0.1246
DEBUG - 2022-07-02 02:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:40:52 --> Total execution time: 0.0391
DEBUG - 2022-07-02 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:41:13 --> Total execution time: 0.0457
DEBUG - 2022-07-02 02:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:41:26 --> Total execution time: 0.0468
DEBUG - 2022-07-02 02:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:41:41 --> Total execution time: 0.0640
DEBUG - 2022-07-02 02:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:41:54 --> Total execution time: 0.0689
DEBUG - 2022-07-02 02:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:42:03 --> Total execution time: 0.0710
DEBUG - 2022-07-02 02:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:42:06 --> Total execution time: 0.0496
DEBUG - 2022-07-02 02:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:15:15 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:45:15 --> Total execution time: 0.0828
DEBUG - 2022-07-02 02:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:18:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:48:04 --> Total execution time: 0.1209
DEBUG - 2022-07-02 02:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:18:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:48:06 --> Total execution time: 0.0364
DEBUG - 2022-07-02 02:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:50:15 --> Total execution time: 0.0871
DEBUG - 2022-07-02 02:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:20:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:50:28 --> Total execution time: 0.0570
DEBUG - 2022-07-02 02:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:50:35 --> Total execution time: 0.0540
DEBUG - 2022-07-02 02:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:50:49 --> Total execution time: 0.0628
DEBUG - 2022-07-02 02:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:51:40 --> Total execution time: 0.0700
DEBUG - 2022-07-02 02:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:52:56 --> Total execution time: 0.1011
DEBUG - 2022-07-02 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:23:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:53:43 --> Total execution time: 0.0364
DEBUG - 2022-07-02 02:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:23:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:53:45 --> Total execution time: 0.0463
DEBUG - 2022-07-02 02:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:53:49 --> Total execution time: 0.0796
DEBUG - 2022-07-02 02:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:23:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 02:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:54:01 --> Total execution time: 0.1501
DEBUG - 2022-07-02 02:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:54:48 --> Total execution time: 0.0886
DEBUG - 2022-07-02 02:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:55:30 --> Total execution time: 0.1408
DEBUG - 2022-07-02 02:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:55:57 --> Total execution time: 0.0551
DEBUG - 2022-07-02 02:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:56:01 --> Total execution time: 0.0648
DEBUG - 2022-07-02 02:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:16 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:56:16 --> Total execution time: 0.0348
DEBUG - 2022-07-02 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:56:19 --> Total execution time: 0.0868
DEBUG - 2022-07-02 02:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:56:23 --> Total execution time: 0.0339
DEBUG - 2022-07-02 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:56:28 --> Total execution time: 0.0355
DEBUG - 2022-07-02 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:56:37 --> Total execution time: 0.0319
DEBUG - 2022-07-02 02:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:00 --> Total execution time: 0.0460
DEBUG - 2022-07-02 02:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:04 --> Total execution time: 0.0525
DEBUG - 2022-07-02 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:15 --> Total execution time: 0.0680
DEBUG - 2022-07-02 02:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:22 --> Total execution time: 0.0506
DEBUG - 2022-07-02 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:26 --> Total execution time: 0.0613
DEBUG - 2022-07-02 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:26 --> Total execution time: 0.0450
DEBUG - 2022-07-02 02:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:27 --> Total execution time: 0.0415
DEBUG - 2022-07-02 02:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:45 --> Total execution time: 0.0529
DEBUG - 2022-07-02 02:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:50 --> Total execution time: 0.0803
DEBUG - 2022-07-02 02:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:52 --> Total execution time: 0.0625
DEBUG - 2022-07-02 02:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:57:55 --> Total execution time: 0.0782
DEBUG - 2022-07-02 02:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:58:30 --> Total execution time: 0.2582
DEBUG - 2022-07-02 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:58:31 --> Total execution time: 0.0711
DEBUG - 2022-07-02 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:59:38 --> Total execution time: 0.0633
DEBUG - 2022-07-02 02:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:00:11 --> Total execution time: 0.0595
DEBUG - 2022-07-02 02:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:00:35 --> Total execution time: 0.0484
DEBUG - 2022-07-02 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:00:47 --> Total execution time: 0.0578
DEBUG - 2022-07-02 02:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:01:25 --> Total execution time: 0.0500
DEBUG - 2022-07-02 02:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:01:26 --> Total execution time: 0.0475
DEBUG - 2022-07-02 02:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:01:47 --> Total execution time: 0.0610
DEBUG - 2022-07-02 02:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:02:02 --> Total execution time: 0.0935
DEBUG - 2022-07-02 02:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:02:34 --> Total execution time: 0.0330
DEBUG - 2022-07-02 02:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:03:24 --> Total execution time: 0.1367
DEBUG - 2022-07-02 02:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:33:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:03:31 --> Total execution time: 0.1239
DEBUG - 2022-07-02 02:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:33:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:03:43 --> Total execution time: 0.0654
DEBUG - 2022-07-02 02:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:33:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:03:44 --> Total execution time: 0.0515
DEBUG - 2022-07-02 02:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:03 --> Total execution time: 0.0610
DEBUG - 2022-07-02 02:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:06 --> Total execution time: 0.0658
DEBUG - 2022-07-02 02:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:07 --> Total execution time: 0.1205
DEBUG - 2022-07-02 02:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:09 --> Total execution time: 0.0575
DEBUG - 2022-07-02 02:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:12 --> Total execution time: 0.0610
DEBUG - 2022-07-02 02:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:14 --> Total execution time: 0.0519
DEBUG - 2022-07-02 02:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:16 --> Total execution time: 0.0795
DEBUG - 2022-07-02 02:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:21 --> Total execution time: 0.0622
DEBUG - 2022-07-02 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:24 --> Total execution time: 0.0524
DEBUG - 2022-07-02 02:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:45 --> Total execution time: 0.0623
DEBUG - 2022-07-02 02:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:48 --> Total execution time: 0.0648
DEBUG - 2022-07-02 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:51 --> Total execution time: 0.0552
DEBUG - 2022-07-02 02:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:04:59 --> Total execution time: 0.0744
DEBUG - 2022-07-02 02:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:05:02 --> Total execution time: 0.1126
DEBUG - 2022-07-02 02:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:07:15 --> Total execution time: 0.0615
DEBUG - 2022-07-02 02:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:39:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:09:20 --> Total execution time: 0.1178
DEBUG - 2022-07-02 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:39:21 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:09:21 --> Total execution time: 0.0781
DEBUG - 2022-07-02 02:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:09:28 --> Total execution time: 0.0337
DEBUG - 2022-07-02 02:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:10:27 --> Total execution time: 0.0610
DEBUG - 2022-07-02 02:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:10:40 --> Total execution time: 0.0873
DEBUG - 2022-07-02 02:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:10:47 --> Total execution time: 0.0775
DEBUG - 2022-07-02 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:11:25 --> Total execution time: 0.0685
DEBUG - 2022-07-02 02:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:11:29 --> Total execution time: 0.0638
DEBUG - 2022-07-02 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:11:35 --> Total execution time: 0.0856
DEBUG - 2022-07-02 02:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:13:39 --> Total execution time: 0.1260
DEBUG - 2022-07-02 02:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:43:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:13:57 --> Total execution time: 0.0373
DEBUG - 2022-07-02 02:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:27 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-02 02:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:27 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-02 02:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:39 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:41 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-02 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:41 --> 404 Page Not Found: Well-known/gpc.json
DEBUG - 2022-07-02 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:41 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-02 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:41 --> 404 Page Not Found: Well-known/security.txt
DEBUG - 2022-07-02 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:41 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 02:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:42 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-07-02 02:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:44:42 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-07-02 02:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:45:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:15:36 --> Total execution time: 0.0679
DEBUG - 2022-07-02 02:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 02:46:42 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 02:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:46:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:16:43 --> Total execution time: 0.0529
DEBUG - 2022-07-02 02:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:50:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:02 --> Total execution time: 0.4397
DEBUG - 2022-07-02 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:23 --> Total execution time: 0.0610
DEBUG - 2022-07-02 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:36 --> Total execution time: 0.0697
DEBUG - 2022-07-02 02:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:42 --> Total execution time: 0.0899
DEBUG - 2022-07-02 02:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:53 --> Total execution time: 0.0984
DEBUG - 2022-07-02 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:03 --> Total execution time: 0.0367
DEBUG - 2022-07-02 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:03 --> Total execution time: 0.0399
DEBUG - 2022-07-02 02:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:08 --> Total execution time: 0.0317
DEBUG - 2022-07-02 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:16 --> Total execution time: 0.0487
DEBUG - 2022-07-02 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:20 --> Total execution time: 0.0582
DEBUG - 2022-07-02 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:23 --> Total execution time: 0.0791
DEBUG - 2022-07-02 02:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:34 --> Total execution time: 0.0517
DEBUG - 2022-07-02 02:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:37 --> Total execution time: 0.0512
DEBUG - 2022-07-02 02:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:51:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 02:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:21:46 --> Total execution time: 0.1193
DEBUG - 2022-07-02 02:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:22:03 --> Total execution time: 0.0484
DEBUG - 2022-07-02 02:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:24:19 --> Total execution time: 0.1047
DEBUG - 2022-07-02 02:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:24:22 --> Total execution time: 0.0530
DEBUG - 2022-07-02 02:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:24:45 --> Total execution time: 0.1129
DEBUG - 2022-07-02 02:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:24:51 --> Total execution time: 0.0553
DEBUG - 2022-07-02 02:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:24:55 --> Total execution time: 0.0536
DEBUG - 2022-07-02 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:25:03 --> Total execution time: 0.0562
DEBUG - 2022-07-02 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:25:03 --> Total execution time: 0.0452
DEBUG - 2022-07-02 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:27:14 --> Total execution time: 0.2094
DEBUG - 2022-07-02 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:27:41 --> Total execution time: 0.0620
DEBUG - 2022-07-02 02:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:27:48 --> Total execution time: 0.0550
DEBUG - 2022-07-02 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:27:52 --> Total execution time: 0.0560
DEBUG - 2022-07-02 02:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:27:53 --> Total execution time: 0.0798
DEBUG - 2022-07-02 02:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 02:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:28:01 --> Total execution time: 0.0775
DEBUG - 2022-07-02 02:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:28:07 --> Total execution time: 0.0664
DEBUG - 2022-07-02 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:28:10 --> Total execution time: 0.1020
DEBUG - 2022-07-02 02:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 02:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 02:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:28:26 --> Total execution time: 0.0556
DEBUG - 2022-07-02 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:30:03 --> Total execution time: 0.1025
DEBUG - 2022-07-02 03:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:33:41 --> Total execution time: 0.0524
DEBUG - 2022-07-02 03:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:34:13 --> Total execution time: 0.0741
DEBUG - 2022-07-02 03:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:34:22 --> Total execution time: 0.0611
DEBUG - 2022-07-02 03:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:34:25 --> Total execution time: 0.0554
DEBUG - 2022-07-02 03:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:36:28 --> Total execution time: 0.0948
DEBUG - 2022-07-02 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:36:44 --> Total execution time: 0.0469
DEBUG - 2022-07-02 03:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:07:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:37:07 --> Total execution time: 0.0399
DEBUG - 2022-07-02 03:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:37:57 --> Total execution time: 0.0524
DEBUG - 2022-07-02 03:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:04 --> Total execution time: 0.0518
DEBUG - 2022-07-02 03:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:29 --> Total execution time: 0.1435
DEBUG - 2022-07-02 03:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:35 --> Total execution time: 0.0607
DEBUG - 2022-07-02 03:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:37 --> Total execution time: 0.1410
DEBUG - 2022-07-02 03:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:39 --> Total execution time: 0.0606
DEBUG - 2022-07-02 03:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:39 --> Total execution time: 0.0581
DEBUG - 2022-07-02 03:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:42 --> Total execution time: 0.0588
DEBUG - 2022-07-02 03:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:43 --> Total execution time: 0.0603
DEBUG - 2022-07-02 03:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:39:57 --> Total execution time: 0.0385
DEBUG - 2022-07-02 03:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 03:10:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 03:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:40:51 --> Total execution time: 0.0646
DEBUG - 2022-07-02 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:40:52 --> Total execution time: 0.0616
DEBUG - 2022-07-02 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:40:53 --> Total execution time: 0.0586
DEBUG - 2022-07-02 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:40:53 --> Total execution time: 0.0492
DEBUG - 2022-07-02 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:10:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:40:54 --> Total execution time: 0.0387
DEBUG - 2022-07-02 03:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:12:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:42:31 --> Total execution time: 0.0743
DEBUG - 2022-07-02 03:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:12:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:42:33 --> Total execution time: 0.0584
DEBUG - 2022-07-02 03:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:42:41 --> Total execution time: 0.0350
DEBUG - 2022-07-02 03:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 03:13:15 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 03:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:43:26 --> Total execution time: 0.0667
DEBUG - 2022-07-02 03:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:43:31 --> Total execution time: 0.0688
DEBUG - 2022-07-02 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:43:45 --> Total execution time: 0.0473
DEBUG - 2022-07-02 03:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:13:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:43:46 --> Total execution time: 0.0547
DEBUG - 2022-07-02 03:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:15:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:45:06 --> Total execution time: 0.0849
DEBUG - 2022-07-02 03:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 03:15:32 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 03:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:15:32 --> Total execution time: 0.0375
DEBUG - 2022-07-02 03:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:15:42 --> Total execution time: 0.0479
DEBUG - 2022-07-02 03:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:15:42 --> Total execution time: 0.0880
DEBUG - 2022-07-02 03:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:16:45 --> Total execution time: 0.0560
DEBUG - 2022-07-02 03:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:16:47 --> Total execution time: 0.0611
DEBUG - 2022-07-02 03:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:16:47 --> Total execution time: 0.1254
DEBUG - 2022-07-02 03:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:17:10 --> Total execution time: 0.0516
DEBUG - 2022-07-02 03:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:17:12 --> Total execution time: 0.0431
DEBUG - 2022-07-02 03:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:17:12 --> Total execution time: 0.0947
DEBUG - 2022-07-02 03:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:47:16 --> Total execution time: 0.0394
DEBUG - 2022-07-02 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:47:37 --> Total execution time: 0.0404
DEBUG - 2022-07-02 03:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:47:58 --> Total execution time: 0.0416
DEBUG - 2022-07-02 03:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:48:08 --> Total execution time: 0.0769
DEBUG - 2022-07-02 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:48:16 --> Total execution time: 0.0475
DEBUG - 2022-07-02 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:48:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 03:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:48:17 --> Total execution time: 0.0469
DEBUG - 2022-07-02 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:49:14 --> Total execution time: 0.0572
DEBUG - 2022-07-02 03:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:49:20 --> Total execution time: 0.0480
DEBUG - 2022-07-02 03:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:49:43 --> Total execution time: 0.0534
DEBUG - 2022-07-02 03:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:19:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:49:58 --> Total execution time: 0.0500
DEBUG - 2022-07-02 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:20:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:50:34 --> Total execution time: 0.1475
DEBUG - 2022-07-02 03:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:20:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:50:58 --> Total execution time: 0.1121
DEBUG - 2022-07-02 03:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:21:10 --> Total execution time: 0.0571
DEBUG - 2022-07-02 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:21:11 --> Total execution time: 0.0560
DEBUG - 2022-07-02 03:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:21:11 --> Total execution time: 0.1120
DEBUG - 2022-07-02 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:51:34 --> Total execution time: 0.0539
DEBUG - 2022-07-02 03:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:51:50 --> Total execution time: 0.0340
DEBUG - 2022-07-02 03:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:51:55 --> Total execution time: 0.0498
DEBUG - 2022-07-02 03:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 03:22:18 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-07-02 03:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:52:18 --> Total execution time: 0.0504
DEBUG - 2022-07-02 03:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:52:28 --> Total execution time: 0.0553
DEBUG - 2022-07-02 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:52:31 --> Total execution time: 0.0843
DEBUG - 2022-07-02 03:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:23:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:53:03 --> Total execution time: 0.0557
DEBUG - 2022-07-02 03:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:54:09 --> Total execution time: 0.0551
DEBUG - 2022-07-02 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:24:14 --> Total execution time: 0.0559
DEBUG - 2022-07-02 03:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:24:16 --> Total execution time: 0.0586
DEBUG - 2022-07-02 03:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:24:16 --> Total execution time: 0.1236
DEBUG - 2022-07-02 03:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:24:18 --> Total execution time: 0.0401
DEBUG - 2022-07-02 03:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:24:20 --> Total execution time: 0.0432
DEBUG - 2022-07-02 03:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:24:24 --> Total execution time: 0.0537
DEBUG - 2022-07-02 03:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:24:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:54:38 --> Total execution time: 0.0337
DEBUG - 2022-07-02 03:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:25:00 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:55:00 --> Total execution time: 0.0371
DEBUG - 2022-07-02 03:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:25:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 03:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:55:34 --> Total execution time: 1.6025
DEBUG - 2022-07-02 03:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 03:25:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 03:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:55:47 --> Total execution time: 0.0313
DEBUG - 2022-07-02 03:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:56:44 --> Total execution time: 0.0323
DEBUG - 2022-07-02 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:57:20 --> Total execution time: 0.1335
DEBUG - 2022-07-02 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:58:27 --> Total execution time: 0.0523
DEBUG - 2022-07-02 03:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:28:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:58:37 --> Total execution time: 0.1224
DEBUG - 2022-07-02 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:59:09 --> Total execution time: 0.0533
DEBUG - 2022-07-02 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:33:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:03:20 --> Total execution time: 0.1236
DEBUG - 2022-07-02 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:33:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:03:20 --> Total execution time: 0.0352
DEBUG - 2022-07-02 03:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:33:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:03:22 --> Total execution time: 0.0384
DEBUG - 2022-07-02 03:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:03:43 --> Total execution time: 0.1193
DEBUG - 2022-07-02 03:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:03:51 --> Total execution time: 0.0622
DEBUG - 2022-07-02 03:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:04:13 --> Total execution time: 0.0953
DEBUG - 2022-07-02 03:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:04:16 --> Total execution time: 0.0619
DEBUG - 2022-07-02 03:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:04:30 --> Total execution time: 0.0493
DEBUG - 2022-07-02 03:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:37:30 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:07:30 --> Total execution time: 0.3976
DEBUG - 2022-07-02 03:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:07:38 --> Total execution time: 0.0391
DEBUG - 2022-07-02 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:07:44 --> Total execution time: 0.0574
DEBUG - 2022-07-02 03:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:08:20 --> Total execution time: 0.1384
DEBUG - 2022-07-02 03:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:08:23 --> Total execution time: 0.0799
DEBUG - 2022-07-02 03:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:08:46 --> Total execution time: 0.0687
DEBUG - 2022-07-02 03:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 03:41:09 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:12:43 --> Total execution time: 0.0484
DEBUG - 2022-07-02 03:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:13:21 --> Total execution time: 0.0692
DEBUG - 2022-07-02 03:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:18:52 --> Total execution time: 0.1941
DEBUG - 2022-07-02 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:19:00 --> Total execution time: 0.1355
DEBUG - 2022-07-02 03:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:19:04 --> Total execution time: 0.0523
DEBUG - 2022-07-02 03:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:24:23 --> Total execution time: 0.0919
DEBUG - 2022-07-02 03:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:26:36 --> Total execution time: 0.1713
DEBUG - 2022-07-02 03:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:56:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 03:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:26:46 --> Total execution time: 0.1255
DEBUG - 2022-07-02 03:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:26:52 --> Total execution time: 0.1100
DEBUG - 2022-07-02 03:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:27:09 --> Total execution time: 0.0508
DEBUG - 2022-07-02 03:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:27:51 --> Total execution time: 0.0622
DEBUG - 2022-07-02 03:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:27:55 --> Total execution time: 0.0865
DEBUG - 2022-07-02 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:28:07 --> Total execution time: 0.0599
DEBUG - 2022-07-02 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:28:16 --> Total execution time: 0.0673
DEBUG - 2022-07-02 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:28:23 --> Total execution time: 0.0717
DEBUG - 2022-07-02 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:28:33 --> Total execution time: 0.0832
DEBUG - 2022-07-02 03:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 03:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 03:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 03:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:28:47 --> Total execution time: 0.0582
DEBUG - 2022-07-02 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:30:02 --> Total execution time: 0.0602
DEBUG - 2022-07-02 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:02:47 --> Total execution time: 0.0569
DEBUG - 2022-07-02 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:02:49 --> Total execution time: 0.0695
DEBUG - 2022-07-02 04:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:02:49 --> Total execution time: 0.1550
DEBUG - 2022-07-02 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:03:02 --> Total execution time: 0.0724
DEBUG - 2022-07-02 04:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:03:06 --> Total execution time: 0.0490
DEBUG - 2022-07-02 04:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:03:09 --> Total execution time: 0.0499
DEBUG - 2022-07-02 04:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:03:13 --> Total execution time: 0.0477
DEBUG - 2022-07-02 04:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:03:16 --> Total execution time: 0.0464
DEBUG - 2022-07-02 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:03:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 04:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:33:45 --> Total execution time: 1.7499
DEBUG - 2022-07-02 04:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:03:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:00 --> Total execution time: 0.0528
DEBUG - 2022-07-02 04:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:09 --> Total execution time: 0.0822
DEBUG - 2022-07-02 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:19 --> Total execution time: 0.0840
DEBUG - 2022-07-02 04:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:35 --> Total execution time: 1.5648
DEBUG - 2022-07-02 04:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:40 --> Total execution time: 0.0772
DEBUG - 2022-07-02 04:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:42 --> Total execution time: 0.0769
DEBUG - 2022-07-02 04:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:44 --> Total execution time: 0.0507
DEBUG - 2022-07-02 04:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:49 --> Total execution time: 0.0633
DEBUG - 2022-07-02 04:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:34:54 --> Total execution time: 0.0581
DEBUG - 2022-07-02 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:35:11 --> Total execution time: 0.0635
DEBUG - 2022-07-02 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:35:43 --> Total execution time: 0.0702
DEBUG - 2022-07-02 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:05:48 --> Total execution time: 0.0459
DEBUG - 2022-07-02 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:35:54 --> Total execution time: 0.0544
DEBUG - 2022-07-02 04:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:35:58 --> Total execution time: 0.0817
DEBUG - 2022-07-02 04:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:35:59 --> Total execution time: 0.0566
DEBUG - 2022-07-02 04:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:36:00 --> Total execution time: 0.0749
DEBUG - 2022-07-02 04:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:36:04 --> Total execution time: 0.0690
DEBUG - 2022-07-02 04:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:36:13 --> Total execution time: 0.0560
DEBUG - 2022-07-02 04:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:07:08 --> Total execution time: 0.0608
DEBUG - 2022-07-02 04:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:07:22 --> Total execution time: 0.1009
DEBUG - 2022-07-02 04:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:37:48 --> Total execution time: 0.0910
DEBUG - 2022-07-02 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:37:54 --> Total execution time: 0.0907
DEBUG - 2022-07-02 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:38:05 --> Total execution time: 0.0854
DEBUG - 2022-07-02 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:08:08 --> Total execution time: 0.0449
DEBUG - 2022-07-02 04:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:08:13 --> Total execution time: 0.0439
DEBUG - 2022-07-02 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:08:20 --> Total execution time: 0.0420
DEBUG - 2022-07-02 04:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:11:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:41:03 --> Total execution time: 0.1150
DEBUG - 2022-07-02 04:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:11:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:41:10 --> Total execution time: 0.0354
DEBUG - 2022-07-02 04:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:11:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 04:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:43:13 --> Total execution time: 0.0467
DEBUG - 2022-07-02 04:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:43:23 --> Total execution time: 0.0582
DEBUG - 2022-07-02 04:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:43:23 --> Total execution time: 0.0456
DEBUG - 2022-07-02 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:47:31 --> Total execution time: 0.0493
DEBUG - 2022-07-02 04:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:48:11 --> Total execution time: 0.1787
DEBUG - 2022-07-02 04:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:48:13 --> Total execution time: 0.0682
DEBUG - 2022-07-02 04:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:48:21 --> Total execution time: 0.0499
DEBUG - 2022-07-02 04:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:48:23 --> Total execution time: 0.0565
DEBUG - 2022-07-02 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:48:30 --> Total execution time: 0.0484
DEBUG - 2022-07-02 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:49:14 --> Total execution time: 0.1197
DEBUG - 2022-07-02 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:19:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:49:46 --> Total execution time: 0.0385
DEBUG - 2022-07-02 04:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:19:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:49:47 --> Total execution time: 0.0335
DEBUG - 2022-07-02 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:20:17 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:50:17 --> Total execution time: 0.0718
DEBUG - 2022-07-02 04:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:20:45 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 04:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:53:22 --> Total execution time: 0.0665
DEBUG - 2022-07-02 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:26:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:56:26 --> Total execution time: 0.0895
DEBUG - 2022-07-02 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:57:07 --> Total execution time: 0.0609
DEBUG - 2022-07-02 04:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:57:20 --> Total execution time: 0.1482
DEBUG - 2022-07-02 04:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:57:25 --> Total execution time: 0.0551
DEBUG - 2022-07-02 04:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:57:27 --> Total execution time: 0.1100
DEBUG - 2022-07-02 04:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:27:28 --> Total execution time: 0.0499
DEBUG - 2022-07-02 04:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:57:29 --> Total execution time: 0.0315
DEBUG - 2022-07-02 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:27:30 --> Total execution time: 0.0495
DEBUG - 2022-07-02 04:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:27:30 --> Total execution time: 0.1737
DEBUG - 2022-07-02 04:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:57:45 --> Total execution time: 0.0835
DEBUG - 2022-07-02 04:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:00 --> Total execution time: 0.0478
DEBUG - 2022-07-02 04:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:14 --> Total execution time: 0.0893
DEBUG - 2022-07-02 04:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:16 --> Total execution time: 0.0814
DEBUG - 2022-07-02 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:19 --> Total execution time: 0.0768
DEBUG - 2022-07-02 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:20 --> Total execution time: 0.0610
DEBUG - 2022-07-02 04:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:23 --> Total execution time: 0.1320
DEBUG - 2022-07-02 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:32 --> Total execution time: 0.0975
DEBUG - 2022-07-02 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:34 --> Total execution time: 0.1092
DEBUG - 2022-07-02 04:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:48 --> Total execution time: 0.1050
DEBUG - 2022-07-02 04:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:48 --> Total execution time: 0.2071
DEBUG - 2022-07-02 04:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:58:52 --> Total execution time: 0.0713
DEBUG - 2022-07-02 04:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:05 --> Total execution time: 0.1447
DEBUG - 2022-07-02 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:08 --> Total execution time: 0.0926
DEBUG - 2022-07-02 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:12 --> Total execution time: 0.1101
DEBUG - 2022-07-02 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:15 --> Total execution time: 0.0778
DEBUG - 2022-07-02 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:18 --> Total execution time: 0.0747
DEBUG - 2022-07-02 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:18 --> Total execution time: 0.0444
DEBUG - 2022-07-02 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:29 --> Total execution time: 0.2086
DEBUG - 2022-07-02 04:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:35 --> Total execution time: 0.0840
DEBUG - 2022-07-02 04:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:51 --> Total execution time: 0.1202
DEBUG - 2022-07-02 04:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:59:56 --> Total execution time: 0.2476
DEBUG - 2022-07-02 04:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:30:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:00:09 --> Total execution time: 0.1198
DEBUG - 2022-07-02 04:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:30:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:00:40 --> Total execution time: 0.0994
DEBUG - 2022-07-02 04:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:01:17 --> Total execution time: 0.1718
DEBUG - 2022-07-02 04:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:31:31 --> Total execution time: 0.0864
DEBUG - 2022-07-02 04:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:01:35 --> Total execution time: 0.1122
DEBUG - 2022-07-02 04:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:03:04 --> Total execution time: 0.0676
DEBUG - 2022-07-02 04:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:04:49 --> Total execution time: 0.0472
DEBUG - 2022-07-02 04:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:05:58 --> Total execution time: 0.1549
DEBUG - 2022-07-02 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:08:42 --> Total execution time: 0.1193
DEBUG - 2022-07-02 04:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:43:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:13:28 --> Total execution time: 0.1836
DEBUG - 2022-07-02 04:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:13:41 --> Total execution time: 0.0464
DEBUG - 2022-07-02 04:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:13:54 --> Total execution time: 0.0520
DEBUG - 2022-07-02 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:48:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:18:38 --> Total execution time: 0.1059
DEBUG - 2022-07-02 04:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:49:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:19:09 --> Total execution time: 0.0530
DEBUG - 2022-07-02 04:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:52:16 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:22:17 --> Total execution time: 0.1128
DEBUG - 2022-07-02 04:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:52:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:22:19 --> Total execution time: 0.0337
DEBUG - 2022-07-02 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:52:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 04:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:52:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:22:43 --> Total execution time: 0.0361
DEBUG - 2022-07-02 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:53:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:23:43 --> Total execution time: 0.0548
DEBUG - 2022-07-02 04:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:53:53 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 04:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:54:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:24:07 --> Total execution time: 0.0527
DEBUG - 2022-07-02 04:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:24:16 --> Total execution time: 0.0314
DEBUG - 2022-07-02 04:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:54:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:24:56 --> Total execution time: 0.1393
DEBUG - 2022-07-02 04:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:55:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:25:10 --> Total execution time: 0.0582
DEBUG - 2022-07-02 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:55:44 --> Total execution time: 0.0399
DEBUG - 2022-07-02 04:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:55:58 --> Total execution time: 0.0494
DEBUG - 2022-07-02 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:00 --> Total execution time: 0.0799
DEBUG - 2022-07-02 04:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:00 --> Total execution time: 0.1289
DEBUG - 2022-07-02 04:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:02 --> Total execution time: 0.0358
DEBUG - 2022-07-02 04:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:13 --> Total execution time: 0.0401
DEBUG - 2022-07-02 04:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:26:19 --> Total execution time: 0.0550
DEBUG - 2022-07-02 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:29 --> Total execution time: 0.0636
DEBUG - 2022-07-02 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:29 --> Total execution time: 0.0546
DEBUG - 2022-07-02 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:31 --> Total execution time: 0.0610
DEBUG - 2022-07-02 04:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:31 --> Total execution time: 0.0854
DEBUG - 2022-07-02 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:56:31 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 04:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:26:45 --> Total execution time: 0.0477
DEBUG - 2022-07-02 04:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:56:49 --> Total execution time: 0.0332
DEBUG - 2022-07-02 04:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:56:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:26:52 --> Total execution time: 0.0660
DEBUG - 2022-07-02 04:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:57:07 --> Total execution time: 0.0546
DEBUG - 2022-07-02 04:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:57:07 --> Total execution time: 0.0627
DEBUG - 2022-07-02 04:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:57:59 --> Total execution time: 0.0470
DEBUG - 2022-07-02 04:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:58:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 04:58:13 --> Total execution time: 0.0483
DEBUG - 2022-07-02 04:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:28:13 --> Total execution time: 0.0844
DEBUG - 2022-07-02 04:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:58:21 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:28:21 --> Total execution time: 0.0517
DEBUG - 2022-07-02 04:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 04:58:44 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:58:55 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:28:55 --> Total execution time: 0.0679
DEBUG - 2022-07-02 04:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 04:59:59 --> No URI present. Default controller set.
DEBUG - 2022-07-02 04:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 04:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:29:59 --> Total execution time: 0.1794
DEBUG - 2022-07-02 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:30:03 --> Total execution time: 0.0854
DEBUG - 2022-07-02 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:30:10 --> Total execution time: 0.0830
DEBUG - 2022-07-02 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:00:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:30:28 --> Total execution time: 0.0742
DEBUG - 2022-07-02 05:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:00:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:30:34 --> Total execution time: 0.1443
DEBUG - 2022-07-02 05:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:07 --> Total execution time: 0.1478
DEBUG - 2022-07-02 05:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:09 --> Total execution time: 0.0649
DEBUG - 2022-07-02 05:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:33 --> Total execution time: 0.3282
DEBUG - 2022-07-02 05:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:37 --> Total execution time: 0.0813
DEBUG - 2022-07-02 05:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:40 --> Total execution time: 0.0946
DEBUG - 2022-07-02 05:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:43 --> Total execution time: 0.0871
DEBUG - 2022-07-02 05:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:50 --> Total execution time: 0.0647
DEBUG - 2022-07-02 05:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:53 --> Total execution time: 0.0509
DEBUG - 2022-07-02 05:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:31:55 --> Total execution time: 0.0731
DEBUG - 2022-07-02 05:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:02:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:32:22 --> Total execution time: 0.0479
DEBUG - 2022-07-02 05:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:12 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:33:12 --> Total execution time: 0.0494
DEBUG - 2022-07-02 05:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:33:18 --> Total execution time: 0.0523
DEBUG - 2022-07-02 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:33:34 --> Total execution time: 0.0505
DEBUG - 2022-07-02 05:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:33:46 --> Total execution time: 0.0493
DEBUG - 2022-07-02 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:03:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:33:48 --> Total execution time: 0.0479
DEBUG - 2022-07-02 05:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:04:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:34:23 --> Total execution time: 0.0513
DEBUG - 2022-07-02 05:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:07:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:37:09 --> Total execution time: 0.2145
DEBUG - 2022-07-02 05:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:39:14 --> Total execution time: 0.1554
DEBUG - 2022-07-02 05:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:41:57 --> Total execution time: 0.1272
DEBUG - 2022-07-02 05:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:44:37 --> Total execution time: 0.0651
DEBUG - 2022-07-02 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:44:42 --> Total execution time: 0.0590
DEBUG - 2022-07-02 05:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:44:44 --> Total execution time: 0.0543
DEBUG - 2022-07-02 05:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:44:49 --> Total execution time: 0.0553
DEBUG - 2022-07-02 05:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:45:00 --> Total execution time: 0.0555
DEBUG - 2022-07-02 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:49:43 --> Total execution time: 0.1267
DEBUG - 2022-07-02 05:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 05:23:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 05:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:27:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:57:28 --> Total execution time: 0.0908
DEBUG - 2022-07-02 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:30:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 05:30:15 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:30:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:00:23 --> Total execution time: 0.0958
DEBUG - 2022-07-02 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:00:26 --> Total execution time: 0.0474
DEBUG - 2022-07-02 05:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:01:00 --> Total execution time: 0.0593
DEBUG - 2022-07-02 05:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:01:21 --> Total execution time: 0.0688
DEBUG - 2022-07-02 05:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:01:28 --> Total execution time: 0.0552
DEBUG - 2022-07-02 05:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:01:31 --> Total execution time: 0.0779
DEBUG - 2022-07-02 05:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:01:45 --> Total execution time: 0.0454
DEBUG - 2022-07-02 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:02:46 --> Total execution time: 0.1351
DEBUG - 2022-07-02 05:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:02:49 --> Total execution time: 0.0547
DEBUG - 2022-07-02 05:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:02:56 --> Total execution time: 0.0469
DEBUG - 2022-07-02 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:38:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:08:27 --> Total execution time: 0.1401
DEBUG - 2022-07-02 05:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:13:25 --> Total execution time: 0.2254
DEBUG - 2022-07-02 05:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:14:06 --> Total execution time: 0.0387
DEBUG - 2022-07-02 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:46:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:16:29 --> Total execution time: 0.0527
DEBUG - 2022-07-02 05:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:17:01 --> Total execution time: 0.1622
DEBUG - 2022-07-02 05:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:17:14 --> Total execution time: 0.0585
DEBUG - 2022-07-02 05:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:47:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:17:47 --> Total execution time: 0.0333
DEBUG - 2022-07-02 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:48:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:18:32 --> Total execution time: 0.0531
DEBUG - 2022-07-02 05:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:48:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:18:36 --> Total execution time: 0.0371
DEBUG - 2022-07-02 05:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:48:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:18:37 --> Total execution time: 0.0350
DEBUG - 2022-07-02 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:48:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:18:58 --> Total execution time: 0.0534
DEBUG - 2022-07-02 05:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:49:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:19:35 --> Total execution time: 0.0382
DEBUG - 2022-07-02 05:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:13 --> Total execution time: 0.0571
DEBUG - 2022-07-02 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:16 --> Total execution time: 0.0351
DEBUG - 2022-07-02 05:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:22 --> Total execution time: 0.0539
DEBUG - 2022-07-02 05:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:31 --> Total execution time: 0.0478
DEBUG - 2022-07-02 05:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:35 --> Total execution time: 0.0756
DEBUG - 2022-07-02 05:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:41 --> Total execution time: 0.0563
DEBUG - 2022-07-02 05:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:20:48 --> Total execution time: 0.0913
DEBUG - 2022-07-02 05:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:51:21 --> Total execution time: 0.0393
DEBUG - 2022-07-02 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:51:22 --> Total execution time: 0.0681
DEBUG - 2022-07-02 05:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:51:22 --> Total execution time: 0.1113
DEBUG - 2022-07-02 05:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:21:39 --> Total execution time: 0.0524
DEBUG - 2022-07-02 05:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:51:41 --> Total execution time: 0.0605
DEBUG - 2022-07-02 05:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:51:43 --> Total execution time: 0.0546
DEBUG - 2022-07-02 05:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:51:43 --> Total execution time: 0.1080
DEBUG - 2022-07-02 05:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 05:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:21:44 --> Total execution time: 0.0470
DEBUG - 2022-07-02 05:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:22:00 --> Total execution time: 0.0552
DEBUG - 2022-07-02 05:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:22:02 --> Total execution time: 0.0545
DEBUG - 2022-07-02 05:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 05:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:22:11 --> Total execution time: 0.0493
DEBUG - 2022-07-02 05:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:22:50 --> Total execution time: 0.0446
DEBUG - 2022-07-02 05:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 05:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:28:11 --> Total execution time: 0.2262
DEBUG - 2022-07-02 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:30:03 --> Total execution time: 0.0775
DEBUG - 2022-07-02 06:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:30:52 --> Total execution time: 0.1400
DEBUG - 2022-07-02 06:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:31:14 --> Total execution time: 0.0800
DEBUG - 2022-07-02 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:31:23 --> Total execution time: 0.0698
DEBUG - 2022-07-02 06:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:31:33 --> Total execution time: 0.0634
DEBUG - 2022-07-02 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:08:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:38:09 --> Total execution time: 0.1618
DEBUG - 2022-07-02 06:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:08:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:38:09 --> Total execution time: 0.0484
DEBUG - 2022-07-02 06:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:08:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:38:09 --> Total execution time: 0.0493
DEBUG - 2022-07-02 06:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:10:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:40:52 --> Total execution time: 0.1104
DEBUG - 2022-07-02 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:21:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:51:59 --> Total execution time: 0.1537
DEBUG - 2022-07-02 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:57:20 --> Total execution time: 0.2528
DEBUG - 2022-07-02 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:28:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:58:23 --> Total execution time: 0.0554
DEBUG - 2022-07-02 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:59:38 --> Total execution time: 0.0492
DEBUG - 2022-07-02 06:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:59:52 --> Total execution time: 0.0513
DEBUG - 2022-07-02 06:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:59:58 --> Total execution time: 0.0995
DEBUG - 2022-07-02 06:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:00:14 --> Total execution time: 0.0630
DEBUG - 2022-07-02 06:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:00:16 --> Total execution time: 0.0558
DEBUG - 2022-07-02 06:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:03:47 --> Total execution time: 0.2304
DEBUG - 2022-07-02 17:03:47 --> Total execution time: 0.2309
DEBUG - 2022-07-02 17:03:47 --> Total execution time: 0.2350
DEBUG - 2022-07-02 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:03:47 --> Total execution time: 0.0936
DEBUG - 2022-07-02 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:03:47 --> Total execution time: 0.0627
DEBUG - 2022-07-02 06:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:37:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:07:09 --> Total execution time: 0.0430
DEBUG - 2022-07-02 06:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:07:52 --> Total execution time: 0.0347
DEBUG - 2022-07-02 06:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:08:36 --> Total execution time: 0.0477
DEBUG - 2022-07-02 06:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 06:41:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:43:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 06:43:43 --> 404 Page Not Found: Wp-admin/hbhbrdryld.php
DEBUG - 2022-07-02 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 06:44:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 06:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:45:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:15:50 --> Total execution time: 0.0949
DEBUG - 2022-07-02 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:45:51 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:15:51 --> Total execution time: 0.0410
DEBUG - 2022-07-02 06:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:45:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:15:52 --> Total execution time: 0.0501
DEBUG - 2022-07-02 06:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:45:55 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:15:55 --> Total execution time: 0.0592
DEBUG - 2022-07-02 06:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 06:46:35 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 06:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:16:52 --> Total execution time: 0.0395
DEBUG - 2022-07-02 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:16:54 --> Total execution time: 0.0408
DEBUG - 2022-07-02 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:16:55 --> Total execution time: 0.0305
DEBUG - 2022-07-02 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:16:56 --> Total execution time: 0.0323
DEBUG - 2022-07-02 06:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:22:17 --> Total execution time: 0.1271
DEBUG - 2022-07-02 06:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:22:39 --> Total execution time: 0.1021
DEBUG - 2022-07-02 06:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:22:44 --> Total execution time: 0.0771
DEBUG - 2022-07-02 06:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:22:50 --> Total execution time: 0.1146
DEBUG - 2022-07-02 06:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:23:01 --> Total execution time: 0.0841
DEBUG - 2022-07-02 06:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:23:11 --> Total execution time: 0.0586
DEBUG - 2022-07-02 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:23:20 --> Total execution time: 0.0509
DEBUG - 2022-07-02 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:23:33 --> Total execution time: 0.0596
DEBUG - 2022-07-02 06:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:23:59 --> Total execution time: 0.0544
DEBUG - 2022-07-02 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:24:08 --> Total execution time: 0.0672
DEBUG - 2022-07-02 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:24:11 --> Total execution time: 0.0492
DEBUG - 2022-07-02 06:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:24:15 --> Total execution time: 0.1205
DEBUG - 2022-07-02 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:24:31 --> Total execution time: 0.0504
DEBUG - 2022-07-02 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:54:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:24:48 --> Total execution time: 0.0471
DEBUG - 2022-07-02 06:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:18 --> No URI present. Default controller set.
DEBUG - 2022-07-02 06:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:26:18 --> Total execution time: 0.0644
DEBUG - 2022-07-02 06:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 06:56:20 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 06:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:26:21 --> Total execution time: 0.0415
DEBUG - 2022-07-02 06:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 06:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:26:28 --> Total execution time: 0.0623
DEBUG - 2022-07-02 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:26:32 --> Total execution time: 0.0501
DEBUG - 2022-07-02 06:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 06:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 06:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:26:41 --> Total execution time: 0.0580
DEBUG - 2022-07-02 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:30:05 --> Total execution time: 0.3185
DEBUG - 2022-07-02 07:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:10:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:40:22 --> Total execution time: 0.1155
DEBUG - 2022-07-02 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:40:41 --> Total execution time: 0.0525
DEBUG - 2022-07-02 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:11:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:11:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:11:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 07:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:42:11 --> Total execution time: 0.0892
DEBUG - 2022-07-02 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:12:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:42:48 --> Total execution time: 0.0549
DEBUG - 2022-07-02 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:42:49 --> Total execution time: 0.0425
DEBUG - 2022-07-02 07:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:15:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:45:29 --> Total execution time: 0.1160
DEBUG - 2022-07-02 07:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:15:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:45:44 --> Total execution time: 0.0749
DEBUG - 2022-07-02 07:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:12 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:46:12 --> Total execution time: 0.0513
DEBUG - 2022-07-02 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:46:23 --> Total execution time: 0.0402
DEBUG - 2022-07-02 07:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:46:29 --> Total execution time: 0.0540
DEBUG - 2022-07-02 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:46:32 --> Total execution time: 0.0518
DEBUG - 2022-07-02 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:46:55 --> Total execution time: 0.0560
DEBUG - 2022-07-02 07:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:46:58 --> Total execution time: 0.0603
DEBUG - 2022-07-02 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:47:12 --> Total execution time: 0.0600
DEBUG - 2022-07-02 07:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:47:23 --> Total execution time: 0.0508
DEBUG - 2022-07-02 07:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:47:55 --> Total execution time: 0.0492
DEBUG - 2022-07-02 07:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:47:59 --> Total execution time: 0.0476
DEBUG - 2022-07-02 07:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:48:12 --> Total execution time: 0.0522
DEBUG - 2022-07-02 07:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:48:23 --> Total execution time: 0.0869
DEBUG - 2022-07-02 07:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:48:32 --> Total execution time: 0.0841
DEBUG - 2022-07-02 07:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:00 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:49:00 --> Total execution time: 0.0470
DEBUG - 2022-07-02 07:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:49:03 --> Total execution time: 0.0398
DEBUG - 2022-07-02 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:19:13 --> Total execution time: 0.0731
DEBUG - 2022-07-02 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:19:16 --> Total execution time: 0.0609
DEBUG - 2022-07-02 07:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:19:16 --> Total execution time: 0.1159
DEBUG - 2022-07-02 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:49:50 --> Total execution time: 0.0692
DEBUG - 2022-07-02 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:49:54 --> Total execution time: 0.0511
DEBUG - 2022-07-02 07:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:50:02 --> Total execution time: 0.0710
DEBUG - 2022-07-02 07:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:50:07 --> Total execution time: 0.0579
DEBUG - 2022-07-02 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:20:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:50:52 --> Total execution time: 0.0354
DEBUG - 2022-07-02 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:21:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:51:55 --> Total execution time: 0.1220
DEBUG - 2022-07-02 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:52:00 --> Total execution time: 0.0611
DEBUG - 2022-07-02 07:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:52:04 --> Total execution time: 0.0560
DEBUG - 2022-07-02 07:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:52:08 --> Total execution time: 0.1124
DEBUG - 2022-07-02 07:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:52:17 --> Total execution time: 0.0484
DEBUG - 2022-07-02 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:53:02 --> Total execution time: 0.0531
DEBUG - 2022-07-02 07:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:53:05 --> Total execution time: 0.0649
DEBUG - 2022-07-02 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:23:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:53:50 --> Total execution time: 0.0337
DEBUG - 2022-07-02 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:53:57 --> Total execution time: 0.0525
DEBUG - 2022-07-02 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:07 --> Total execution time: 0.0602
DEBUG - 2022-07-02 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:12 --> Total execution time: 0.0562
DEBUG - 2022-07-02 07:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:21 --> Total execution time: 0.0529
DEBUG - 2022-07-02 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:40 --> Total execution time: 0.0529
DEBUG - 2022-07-02 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:44 --> Total execution time: 0.0697
DEBUG - 2022-07-02 07:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:48 --> Total execution time: 0.0590
DEBUG - 2022-07-02 07:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:50 --> Total execution time: 0.0595
DEBUG - 2022-07-02 07:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:24:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:54:50 --> Total execution time: 0.0578
DEBUG - 2022-07-02 07:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:55:59 --> Total execution time: 0.0472
DEBUG - 2022-07-02 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:26:08 --> 404 Page Not Found: Lp-profile/courses
DEBUG - 2022-07-02 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:26:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 07:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:17 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:17 --> Total execution time: 0.0348
DEBUG - 2022-07-02 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:28 --> Total execution time: 0.0468
DEBUG - 2022-07-02 07:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:41 --> Total execution time: 0.0611
DEBUG - 2022-07-02 07:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:48 --> Total execution time: 0.0533
DEBUG - 2022-07-02 07:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:49 --> Total execution time: 0.0722
DEBUG - 2022-07-02 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:56:56 --> Total execution time: 0.0519
DEBUG - 2022-07-02 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:02 --> Total execution time: 0.1896
DEBUG - 2022-07-02 07:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:11 --> Total execution time: 0.0594
DEBUG - 2022-07-02 07:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:15 --> Total execution time: 0.0735
DEBUG - 2022-07-02 07:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:30 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:30 --> Total execution time: 0.0692
DEBUG - 2022-07-02 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:43 --> Total execution time: 0.0642
DEBUG - 2022-07-02 07:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:50 --> Total execution time: 0.0587
DEBUG - 2022-07-02 07:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:52 --> Total execution time: 0.0709
DEBUG - 2022-07-02 07:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:56 --> Total execution time: 0.0504
DEBUG - 2022-07-02 07:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:57:58 --> Total execution time: 0.0451
DEBUG - 2022-07-02 07:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:18 --> Total execution time: 0.0587
DEBUG - 2022-07-02 07:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:25 --> Total execution time: 0.0520
DEBUG - 2022-07-02 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:26 --> Total execution time: 0.0759
DEBUG - 2022-07-02 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:50 --> Total execution time: 0.0567
DEBUG - 2022-07-02 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:58 --> Total execution time: 0.0579
DEBUG - 2022-07-02 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:58:59 --> Total execution time: 0.0473
DEBUG - 2022-07-02 07:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:29:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:59:40 --> Total execution time: 0.0360
DEBUG - 2022-07-02 07:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:59:56 --> Total execution time: 0.0364
DEBUG - 2022-07-02 07:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:04 --> Total execution time: 0.2176
DEBUG - 2022-07-02 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:06 --> Total execution time: 0.0797
DEBUG - 2022-07-02 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:09 --> Total execution time: 0.0513
DEBUG - 2022-07-02 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:24 --> Total execution time: 0.0590
DEBUG - 2022-07-02 07:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:44 --> Total execution time: 0.0546
DEBUG - 2022-07-02 07:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:46 --> Total execution time: 0.0479
DEBUG - 2022-07-02 07:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:00:54 --> Total execution time: 0.0730
DEBUG - 2022-07-02 07:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:01:02 --> Total execution time: 0.0672
DEBUG - 2022-07-02 07:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:01:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:01:03 --> Total execution time: 0.0810
DEBUG - 2022-07-02 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:01:29 --> Total execution time: 0.0326
DEBUG - 2022-07-02 07:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:01:56 --> Total execution time: 0.0544
DEBUG - 2022-07-02 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:02:05 --> Total execution time: 0.0888
DEBUG - 2022-07-02 07:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:02:09 --> Total execution time: 0.0587
DEBUG - 2022-07-02 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:02:15 --> Total execution time: 0.0962
DEBUG - 2022-07-02 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:02:31 --> Total execution time: 0.0635
DEBUG - 2022-07-02 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:02:35 --> Total execution time: 0.0853
DEBUG - 2022-07-02 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:04:13 --> Total execution time: 0.1141
DEBUG - 2022-07-02 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:04:35 --> Total execution time: 0.0509
DEBUG - 2022-07-02 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:12:52 --> Total execution time: 0.1083
DEBUG - 2022-07-02 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:12:58 --> Total execution time: 0.0463
DEBUG - 2022-07-02 07:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:13:05 --> Total execution time: 0.0625
DEBUG - 2022-07-02 07:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:13:26 --> Total execution time: 0.0559
DEBUG - 2022-07-02 07:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:43:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:13:34 --> Total execution time: 0.0524
DEBUG - 2022-07-02 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:13:44 --> Total execution time: 0.0533
DEBUG - 2022-07-02 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:14:24 --> Total execution time: 0.0380
DEBUG - 2022-07-02 07:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:46:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:16:48 --> Total execution time: 0.0456
DEBUG - 2022-07-02 07:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:46:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:16:50 --> Total execution time: 0.0354
DEBUG - 2022-07-02 07:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:47:12 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:17:12 --> Total execution time: 0.0376
DEBUG - 2022-07-02 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:47:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:17:13 --> Total execution time: 0.0365
DEBUG - 2022-07-02 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:17:18 --> Total execution time: 0.0475
DEBUG - 2022-07-02 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:47:18 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:17:18 --> Total execution time: 0.0852
DEBUG - 2022-07-02 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:17:31 --> Total execution time: 0.0649
DEBUG - 2022-07-02 07:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:48:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:18:29 --> Total execution time: 0.0362
DEBUG - 2022-07-02 07:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:18:37 --> Total execution time: 0.1143
DEBUG - 2022-07-02 07:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:48:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:18:38 --> Total execution time: 0.0616
DEBUG - 2022-07-02 07:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:50:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:20:23 --> Total execution time: 0.0536
DEBUG - 2022-07-02 07:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:51:02 --> Total execution time: 0.0708
DEBUG - 2022-07-02 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:51:13 --> Total execution time: 0.0584
DEBUG - 2022-07-02 07:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:51:13 --> Total execution time: 0.0764
DEBUG - 2022-07-02 07:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:52:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:22:55 --> Total execution time: 0.1192
DEBUG - 2022-07-02 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:53:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:23:42 --> Total execution time: 1.5786
DEBUG - 2022-07-02 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:53:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:23:57 --> Total execution time: 0.0483
DEBUG - 2022-07-02 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:53:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:23:58 --> Total execution time: 0.0368
DEBUG - 2022-07-02 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:24:06 --> Total execution time: 0.0311
DEBUG - 2022-07-02 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:24:12 --> Total execution time: 0.0666
DEBUG - 2022-07-02 07:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:24:21 --> Total execution time: 0.0934
DEBUG - 2022-07-02 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:25:09 --> Total execution time: 0.0562
DEBUG - 2022-07-02 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:25:18 --> Total execution time: 0.0754
DEBUG - 2022-07-02 07:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 07:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:25:38 --> Total execution time: 0.0492
DEBUG - 2022-07-02 07:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:55:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:25:48 --> Total execution time: 0.0508
DEBUG - 2022-07-02 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:25:53 --> Total execution time: 0.0636
DEBUG - 2022-07-02 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:26:02 --> Total execution time: 1.6848
DEBUG - 2022-07-02 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:56:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 07:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:56:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:26:22 --> Total execution time: 0.0600
DEBUG - 2022-07-02 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:26:30 --> Total execution time: 1.5061
DEBUG - 2022-07-02 07:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:27:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:27:14 --> Total execution time: 0.0596
DEBUG - 2022-07-02 07:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:27:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 18:27:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 18:27:19 --> Total execution time: 0.2569
DEBUG - 2022-07-02 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:58:16 --> No URI present. Default controller set.
DEBUG - 2022-07-02 07:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:28:16 --> Total execution time: 0.0450
DEBUG - 2022-07-02 07:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:58:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 07:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 07:58:28 --> 404 Page Not Found: Asset-manifestjson/index
DEBUG - 2022-07-02 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 07:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:29:48 --> Total execution time: 0.0451
DEBUG - 2022-07-02 08:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:30:02 --> Total execution time: 0.0648
DEBUG - 2022-07-02 08:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:00:20 --> Total execution time: 0.0339
DEBUG - 2022-07-02 08:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:00:28 --> Total execution time: 0.0647
DEBUG - 2022-07-02 08:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:00:28 --> Total execution time: 0.1165
DEBUG - 2022-07-02 08:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:30:40 --> Total execution time: 0.0488
DEBUG - 2022-07-02 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:30:41 --> Total execution time: 0.1139
DEBUG - 2022-07-02 08:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:30:46 --> Total execution time: 0.1362
DEBUG - 2022-07-02 08:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:30:47 --> Total execution time: 0.0422
DEBUG - 2022-07-02 08:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:01:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:31:02 --> Total execution time: 0.0365
DEBUG - 2022-07-02 08:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:01:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:31:19 --> Total execution time: 0.0584
DEBUG - 2022-07-02 08:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:31:45 --> Total execution time: 0.0518
DEBUG - 2022-07-02 08:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:32:27 --> Total execution time: 0.0482
DEBUG - 2022-07-02 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:32:46 --> Total execution time: 0.0793
DEBUG - 2022-07-02 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:33:05 --> Total execution time: 0.0501
DEBUG - 2022-07-02 08:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:33:14 --> Total execution time: 0.0780
DEBUG - 2022-07-02 08:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:34:06 --> Total execution time: 0.0717
DEBUG - 2022-07-02 08:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:35:02 --> Total execution time: 0.0889
DEBUG - 2022-07-02 08:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:37:55 --> Total execution time: 0.2067
DEBUG - 2022-07-02 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:08:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:38:39 --> Total execution time: 0.0379
DEBUG - 2022-07-02 08:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:08:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:38:44 --> Total execution time: 0.0511
DEBUG - 2022-07-02 08:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:38:47 --> Total execution time: 0.0470
DEBUG - 2022-07-02 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:39:02 --> Total execution time: 0.0460
DEBUG - 2022-07-02 08:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:39:26 --> Total execution time: 0.1857
DEBUG - 2022-07-02 08:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:12:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:12:35 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:42:35 --> Total execution time: 0.0792
DEBUG - 2022-07-02 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:42:39 --> Total execution time: 0.0411
DEBUG - 2022-07-02 08:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:42:44 --> Total execution time: 0.0497
DEBUG - 2022-07-02 08:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:42:57 --> Total execution time: 0.0750
DEBUG - 2022-07-02 08:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:13:12 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-02 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:13:14 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:43:14 --> Total execution time: 0.0359
DEBUG - 2022-07-02 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:43:34 --> Total execution time: 0.1012
DEBUG - 2022-07-02 08:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:14:04 --> Total execution time: 0.0396
DEBUG - 2022-07-02 08:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:14:05 --> Total execution time: 0.0470
DEBUG - 2022-07-02 08:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:14:05 --> Total execution time: 0.1141
DEBUG - 2022-07-02 08:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:44:21 --> Total execution time: 0.2724
DEBUG - 2022-07-02 08:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:16:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:46:10 --> Total execution time: 0.0387
DEBUG - 2022-07-02 08:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:16:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:46:38 --> Total execution time: 0.0383
DEBUG - 2022-07-02 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:16:54 --> Total execution time: 0.0350
DEBUG - 2022-07-02 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:16:55 --> Total execution time: 0.0486
DEBUG - 2022-07-02 08:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:16:55 --> Total execution time: 0.1043
DEBUG - 2022-07-02 08:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:17:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:47:11 --> Total execution time: 0.0488
DEBUG - 2022-07-02 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:47:48 --> Total execution time: 0.0499
DEBUG - 2022-07-02 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:48:00 --> Total execution time: 0.0515
DEBUG - 2022-07-02 08:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:48:10 --> Total execution time: 0.0630
DEBUG - 2022-07-02 08:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:48:35 --> Total execution time: 0.0497
DEBUG - 2022-07-02 08:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:19:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:49:06 --> Total execution time: 0.0387
DEBUG - 2022-07-02 08:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:49:07 --> Total execution time: 0.0482
DEBUG - 2022-07-02 08:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:49:18 --> Total execution time: 0.0464
DEBUG - 2022-07-02 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:19:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:49:44 --> Total execution time: 0.0564
DEBUG - 2022-07-02 08:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:20:02 --> Total execution time: 0.0530
DEBUG - 2022-07-02 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:04 --> Total execution time: 0.0575
DEBUG - 2022-07-02 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:20:04 --> Total execution time: 0.0687
DEBUG - 2022-07-02 08:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:50:27 --> Total execution time: 0.0411
DEBUG - 2022-07-02 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:50:32 --> Total execution time: 0.0339
DEBUG - 2022-07-02 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:50:32 --> Total execution time: 0.0401
DEBUG - 2022-07-02 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:50:32 --> Total execution time: 0.0340
DEBUG - 2022-07-02 08:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:20:38 --> Total execution time: 0.0473
DEBUG - 2022-07-02 08:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:20:39 --> Total execution time: 0.0479
DEBUG - 2022-07-02 08:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:20:39 --> Total execution time: 0.1204
DEBUG - 2022-07-02 08:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:51:31 --> Total execution time: 0.0572
DEBUG - 2022-07-02 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:00 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:53:00 --> Total execution time: 0.0490
DEBUG - 2022-07-02 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:23:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:53:05 --> Total execution time: 1.7015
DEBUG - 2022-07-02 08:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:23:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 08:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:53:44 --> Total execution time: 0.0590
DEBUG - 2022-07-02 08:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:53:46 --> Total execution time: 0.0388
DEBUG - 2022-07-02 08:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:53:59 --> Total execution time: 0.0512
DEBUG - 2022-07-02 08:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:54:04 --> Total execution time: 0.0676
DEBUG - 2022-07-02 08:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:54:12 --> Total execution time: 0.0577
DEBUG - 2022-07-02 08:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:54:18 --> Total execution time: 0.0538
DEBUG - 2022-07-02 08:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:24:36 --> Total execution time: 0.0593
DEBUG - 2022-07-02 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:24:38 --> Total execution time: 0.0684
DEBUG - 2022-07-02 08:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:24:38 --> Total execution time: 0.1004
DEBUG - 2022-07-02 08:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:54:39 --> Total execution time: 0.1169
DEBUG - 2022-07-02 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:54:53 --> Total execution time: 0.0635
DEBUG - 2022-07-02 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:55:14 --> Total execution time: 0.0541
DEBUG - 2022-07-02 08:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:25:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 08:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:55:23 --> Total execution time: 0.0540
DEBUG - 2022-07-02 08:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:55:28 --> Total execution time: 0.0854
DEBUG - 2022-07-02 08:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:28:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 08:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:28:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:58:21 --> Total execution time: 0.1838
DEBUG - 2022-07-02 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:28:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:58:22 --> Total execution time: 0.0601
DEBUG - 2022-07-02 08:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:58:41 --> Total execution time: 0.0547
DEBUG - 2022-07-02 08:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:58:58 --> Total execution time: 0.0648
DEBUG - 2022-07-02 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:05 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:59:05 --> Total execution time: 0.0385
DEBUG - 2022-07-02 08:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:59:08 --> Total execution time: 0.0556
DEBUG - 2022-07-02 08:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:59:17 --> Total execution time: 0.0586
DEBUG - 2022-07-02 08:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:59:21 --> Total execution time: 0.0594
DEBUG - 2022-07-02 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:29:41 --> Total execution time: 0.0465
DEBUG - 2022-07-02 08:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:29:42 --> Total execution time: 0.0592
DEBUG - 2022-07-02 08:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:29:42 --> Total execution time: 0.1173
DEBUG - 2022-07-02 08:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:59:47 --> Total execution time: 0.0612
DEBUG - 2022-07-02 08:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:59:52 --> Total execution time: 0.0538
DEBUG - 2022-07-02 08:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:30:16 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 08:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:30:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:00:27 --> Total execution time: 0.0346
DEBUG - 2022-07-02 08:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:31:38 --> Total execution time: 0.0400
DEBUG - 2022-07-02 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:31:39 --> Total execution time: 0.0467
DEBUG - 2022-07-02 08:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:31:39 --> Total execution time: 0.0939
DEBUG - 2022-07-02 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:05 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:05 --> Total execution time: 0.0505
DEBUG - 2022-07-02 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:32:08 --> Total execution time: 0.0450
DEBUG - 2022-07-02 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:08 --> Total execution time: 0.0480
DEBUG - 2022-07-02 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:32:09 --> Total execution time: 0.0665
DEBUG - 2022-07-02 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:09 --> Total execution time: 0.0542
DEBUG - 2022-07-02 08:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:36 --> Total execution time: 0.1164
DEBUG - 2022-07-02 08:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:44 --> Total execution time: 0.1490
DEBUG - 2022-07-02 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:49 --> Total execution time: 0.0519
DEBUG - 2022-07-02 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:03:21 --> Total execution time: 0.0551
DEBUG - 2022-07-02 08:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:03:39 --> Total execution time: 0.0523
DEBUG - 2022-07-02 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:03:59 --> Total execution time: 0.0506
DEBUG - 2022-07-02 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:04:18 --> Total execution time: 0.0641
DEBUG - 2022-07-02 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:04:29 --> Total execution time: 0.0598
DEBUG - 2022-07-02 08:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:04:42 --> Total execution time: 0.0584
DEBUG - 2022-07-02 08:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:04:47 --> Total execution time: 0.0517
DEBUG - 2022-07-02 08:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:05:16 --> Total execution time: 0.0688
DEBUG - 2022-07-02 08:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:05:24 --> Total execution time: 0.0530
DEBUG - 2022-07-02 08:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:05:37 --> Total execution time: 0.0539
DEBUG - 2022-07-02 08:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:05:51 --> Total execution time: 0.0792
DEBUG - 2022-07-02 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:06:13 --> Total execution time: 0.0505
DEBUG - 2022-07-02 08:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:36:14 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:06:14 --> Total execution time: 0.0351
DEBUG - 2022-07-02 08:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:06:16 --> Total execution time: 0.0509
DEBUG - 2022-07-02 08:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:06:28 --> Total execution time: 0.0408
DEBUG - 2022-07-02 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:08:17 --> Total execution time: 0.0547
DEBUG - 2022-07-02 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:08:25 --> Total execution time: 0.0572
DEBUG - 2022-07-02 08:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:08:43 --> Total execution time: 0.0666
DEBUG - 2022-07-02 08:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:08:53 --> Total execution time: 0.0759
DEBUG - 2022-07-02 08:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:10:21 --> Total execution time: 0.0543
DEBUG - 2022-07-02 08:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:10:30 --> Total execution time: 0.0680
DEBUG - 2022-07-02 08:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:40:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:10:39 --> Total execution time: 0.0469
DEBUG - 2022-07-02 08:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:40:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:10:39 --> Total execution time: 0.0615
DEBUG - 2022-07-02 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:11:19 --> Total execution time: 0.0606
DEBUG - 2022-07-02 08:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:12:15 --> Total execution time: 0.0642
DEBUG - 2022-07-02 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:12:16 --> Total execution time: 0.0459
DEBUG - 2022-07-02 08:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:12:24 --> Total execution time: 0.0627
DEBUG - 2022-07-02 08:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:12:36 --> Total execution time: 0.0310
DEBUG - 2022-07-02 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:12:38 --> Total execution time: 0.0853
DEBUG - 2022-07-02 08:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:12:42 --> Total execution time: 0.0266
DEBUG - 2022-07-02 08:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:02 --> Total execution time: 0.0809
DEBUG - 2022-07-02 08:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:10 --> Total execution time: 0.0553
DEBUG - 2022-07-02 08:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:20 --> Total execution time: 0.1370
DEBUG - 2022-07-02 08:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:24 --> Total execution time: 0.0449
DEBUG - 2022-07-02 08:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:25 --> Total execution time: 0.0674
DEBUG - 2022-07-02 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:40 --> Total execution time: 0.0582
DEBUG - 2022-07-02 08:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:52 --> Total execution time: 0.0482
DEBUG - 2022-07-02 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:58 --> Total execution time: 0.0494
DEBUG - 2022-07-02 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:45:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:15:52 --> Total execution time: 0.0348
DEBUG - 2022-07-02 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:45:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:15:52 --> Total execution time: 0.0383
DEBUG - 2022-07-02 08:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:46:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:16:10 --> Total execution time: 0.0409
DEBUG - 2022-07-02 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:46:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:16:19 --> Total execution time: 0.0338
DEBUG - 2022-07-02 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:47:11 --> Total execution time: 0.0551
DEBUG - 2022-07-02 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:47:13 --> Total execution time: 0.0542
DEBUG - 2022-07-02 08:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:47:13 --> Total execution time: 0.0927
DEBUG - 2022-07-02 08:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:48:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:48:33 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 08:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:48:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:18:50 --> Total execution time: 0.0495
DEBUG - 2022-07-02 08:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:19:20 --> Total execution time: 0.1225
DEBUG - 2022-07-02 08:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:19:27 --> Total execution time: 0.0544
DEBUG - 2022-07-02 08:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:19:49 --> Total execution time: 0.0482
DEBUG - 2022-07-02 08:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:20:19 --> Total execution time: 0.0472
DEBUG - 2022-07-02 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:20:27 --> Total execution time: 0.0660
DEBUG - 2022-07-02 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:20:57 --> Total execution time: 0.1699
DEBUG - 2022-07-02 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:21:04 --> Total execution time: 0.0502
DEBUG - 2022-07-02 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:21:20 --> Total execution time: 0.0887
DEBUG - 2022-07-02 08:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:21:45 --> Total execution time: 0.0461
DEBUG - 2022-07-02 08:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:21:49 --> Total execution time: 0.0489
DEBUG - 2022-07-02 08:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:21:51 --> Total execution time: 0.0460
DEBUG - 2022-07-02 08:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 08:55:21 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:06 --> Total execution time: 0.1119
DEBUG - 2022-07-02 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:08 --> Total execution time: 0.0509
DEBUG - 2022-07-02 08:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:24 --> Total execution time: 0.0533
DEBUG - 2022-07-02 08:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:25 --> Total execution time: 0.0481
DEBUG - 2022-07-02 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:32 --> Total execution time: 0.0480
DEBUG - 2022-07-02 08:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:41 --> Total execution time: 0.0660
DEBUG - 2022-07-02 08:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:42 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:42 --> Total execution time: 0.0282
DEBUG - 2022-07-02 08:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:28:45 --> Total execution time: 0.0641
DEBUG - 2022-07-02 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:29:09 --> Total execution time: 0.0767
DEBUG - 2022-07-02 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:59:43 --> Total execution time: 0.1190
DEBUG - 2022-07-02 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:59:44 --> Total execution time: 0.0403
DEBUG - 2022-07-02 08:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 08:59:44 --> Total execution time: 0.0916
DEBUG - 2022-07-02 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 08:59:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 08:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 08:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:29:47 --> Total execution time: 0.1236
DEBUG - 2022-07-02 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:02 --> Total execution time: 0.0498
DEBUG - 2022-07-02 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:03 --> Total execution time: 0.0585
DEBUG - 2022-07-02 09:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:07 --> Total execution time: 0.0398
DEBUG - 2022-07-02 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:15 --> Total execution time: 0.0511
DEBUG - 2022-07-02 09:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:18 --> Total execution time: 0.0479
DEBUG - 2022-07-02 09:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:35 --> Total execution time: 0.0544
DEBUG - 2022-07-02 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:30:39 --> Total execution time: 0.0830
DEBUG - 2022-07-02 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:31:40 --> Total execution time: 0.1211
DEBUG - 2022-07-02 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:01:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:31:48 --> Total execution time: 0.0347
DEBUG - 2022-07-02 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:01:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:31:48 --> Total execution time: 0.0335
DEBUG - 2022-07-02 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:31:49 --> Total execution time: 0.0793
DEBUG - 2022-07-02 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:31:59 --> Total execution time: 0.0543
DEBUG - 2022-07-02 09:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:32:09 --> Total execution time: 0.0616
DEBUG - 2022-07-02 09:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:32:17 --> Total execution time: 0.0417
DEBUG - 2022-07-02 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:02:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:32:22 --> Total execution time: 0.0287
DEBUG - 2022-07-02 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:03:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:33:11 --> Total execution time: 0.0347
DEBUG - 2022-07-02 09:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:04:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:34:03 --> Total execution time: 0.0944
DEBUG - 2022-07-02 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:05:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:35:11 --> Total execution time: 0.1409
DEBUG - 2022-07-02 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:05:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:35:28 --> Total execution time: 0.0519
DEBUG - 2022-07-02 09:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:36:50 --> Total execution time: 0.1385
DEBUG - 2022-07-02 09:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:36:56 --> Total execution time: 0.0530
DEBUG - 2022-07-02 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:37:07 --> Total execution time: 0.0472
DEBUG - 2022-07-02 09:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:07:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:37:44 --> Total execution time: 0.0623
DEBUG - 2022-07-02 09:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:08:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:48 --> Total execution time: 0.0335
DEBUG - 2022-07-02 09:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:39:24 --> Total execution time: 0.0846
DEBUG - 2022-07-02 09:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:09:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:39:29 --> Total execution time: 0.1325
DEBUG - 2022-07-02 09:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:39:38 --> Total execution time: 0.0489
DEBUG - 2022-07-02 09:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:39:44 --> Total execution time: 0.0704
DEBUG - 2022-07-02 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:03 --> Total execution time: 0.0522
DEBUG - 2022-07-02 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:04 --> Total execution time: 0.0517
DEBUG - 2022-07-02 09:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:05 --> Total execution time: 0.0718
DEBUG - 2022-07-02 09:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:11 --> Total execution time: 0.0886
DEBUG - 2022-07-02 09:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:13 --> Total execution time: 0.0266
DEBUG - 2022-07-02 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:28 --> Total execution time: 0.0501
DEBUG - 2022-07-02 09:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:36 --> Total execution time: 0.0563
DEBUG - 2022-07-02 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:40:39 --> Total execution time: 0.0470
DEBUG - 2022-07-02 09:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:11:25 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:41:25 --> Total execution time: 0.0613
DEBUG - 2022-07-02 09:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:11:35 --> Total execution time: 0.0456
DEBUG - 2022-07-02 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:11:36 --> Total execution time: 0.0574
DEBUG - 2022-07-02 09:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:11:36 --> Total execution time: 0.0762
DEBUG - 2022-07-02 09:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:42:42 --> Total execution time: 0.0466
DEBUG - 2022-07-02 09:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:43:00 --> Total execution time: 0.0535
DEBUG - 2022-07-02 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:43:21 --> Total execution time: 0.0488
DEBUG - 2022-07-02 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:43:21 --> Total execution time: 0.0516
DEBUG - 2022-07-02 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:43:38 --> Total execution time: 0.0495
DEBUG - 2022-07-02 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:14:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:44:24 --> Total execution time: 1.6708
DEBUG - 2022-07-02 09:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:14:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:15:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:45:11 --> Total execution time: 0.0478
DEBUG - 2022-07-02 09:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:45:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 09:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:45:55 --> Total execution time: 0.0517
DEBUG - 2022-07-02 09:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:45:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 19:45:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 19:45:56 --> Total execution time: 0.1960
DEBUG - 2022-07-02 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:46:23 --> Total execution time: 0.0622
DEBUG - 2022-07-02 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:16:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:46:38 --> Total execution time: 0.1111
DEBUG - 2022-07-02 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:46:51 --> Total execution time: 0.0453
DEBUG - 2022-07-02 09:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:46:51 --> Total execution time: 0.0454
DEBUG - 2022-07-02 09:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:46:57 --> Total execution time: 0.0842
DEBUG - 2022-07-02 09:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:47:02 --> Total execution time: 0.0532
DEBUG - 2022-07-02 09:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:47:09 --> Total execution time: 0.0444
DEBUG - 2022-07-02 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:17:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:47:22 --> Total execution time: 0.0469
DEBUG - 2022-07-02 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:47:22 --> Total execution time: 0.0459
DEBUG - 2022-07-02 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:18:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:48:26 --> Total execution time: 0.0487
DEBUG - 2022-07-02 09:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:51:30 --> Total execution time: 0.0495
DEBUG - 2022-07-02 09:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:25:55 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:55:55 --> Total execution time: 0.0846
DEBUG - 2022-07-02 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:26:14 --> Total execution time: 0.0508
DEBUG - 2022-07-02 09:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:56:20 --> Total execution time: 0.0581
DEBUG - 2022-07-02 09:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:56:28 --> Total execution time: 0.0764
DEBUG - 2022-07-02 09:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:56:30 --> Total execution time: 0.0729
DEBUG - 2022-07-02 09:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:56:40 --> Total execution time: 0.0704
DEBUG - 2022-07-02 09:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:56:44 --> Total execution time: 0.1599
DEBUG - 2022-07-02 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:27:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:57:57 --> Total execution time: 0.0405
DEBUG - 2022-07-02 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:58:06 --> Total execution time: 0.1169
DEBUG - 2022-07-02 09:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:58:40 --> Total execution time: 0.0327
DEBUG - 2022-07-02 09:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:58:56 --> Total execution time: 0.0504
DEBUG - 2022-07-02 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:59:21 --> Total execution time: 0.0514
DEBUG - 2022-07-02 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:59:47 --> Total execution time: 0.0492
DEBUG - 2022-07-02 09:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:03:16 --> Total execution time: 0.0403
DEBUG - 2022-07-02 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:33:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:03:50 --> Total execution time: 0.0551
DEBUG - 2022-07-02 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:34:34 --> Total execution time: 0.0397
DEBUG - 2022-07-02 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:34:36 --> Total execution time: 0.0562
DEBUG - 2022-07-02 09:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:34:36 --> Total execution time: 0.0732
DEBUG - 2022-07-02 09:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:04:52 --> Total execution time: 0.1442
DEBUG - 2022-07-02 09:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:04:53 --> Total execution time: 0.0751
DEBUG - 2022-07-02 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:04:57 --> Total execution time: 0.1019
DEBUG - 2022-07-02 09:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:05:01 --> Total execution time: 0.1666
DEBUG - 2022-07-02 09:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:35:52 --> Total execution time: 0.0410
DEBUG - 2022-07-02 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:35:53 --> Total execution time: 0.0538
DEBUG - 2022-07-02 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:35:53 --> Total execution time: 0.0793
DEBUG - 2022-07-02 09:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:21 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:39:21 --> Total execution time: 0.1043
DEBUG - 2022-07-02 09:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:09:21 --> Total execution time: 0.1799
DEBUG - 2022-07-02 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:39:23 --> Total execution time: 0.0672
DEBUG - 2022-07-02 09:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:39:23 --> Total execution time: 0.1374
DEBUG - 2022-07-02 09:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:09:32 --> Total execution time: 0.0495
DEBUG - 2022-07-02 09:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:09:36 --> Total execution time: 0.1185
DEBUG - 2022-07-02 09:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:09:40 --> Total execution time: 0.0604
DEBUG - 2022-07-02 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:09:56 --> Total execution time: 0.0654
DEBUG - 2022-07-02 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:10:00 --> Total execution time: 0.0818
DEBUG - 2022-07-02 09:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:10:11 --> Total execution time: 0.0749
DEBUG - 2022-07-02 09:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:43:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:13:08 --> Total execution time: 0.1761
DEBUG - 2022-07-02 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:15:36 --> Total execution time: 0.1431
DEBUG - 2022-07-02 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:15:37 --> Total execution time: 0.0532
DEBUG - 2022-07-02 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:15:37 --> Total execution time: 0.0517
DEBUG - 2022-07-02 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:15:37 --> Total execution time: 0.0633
DEBUG - 2022-07-02 09:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:15:42 --> Total execution time: 0.0586
DEBUG - 2022-07-02 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:16:27 --> Total execution time: 0.0530
DEBUG - 2022-07-02 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:16:28 --> Total execution time: 0.0525
DEBUG - 2022-07-02 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:16:29 --> Total execution time: 0.0528
DEBUG - 2022-07-02 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:16:30 --> Total execution time: 0.0657
DEBUG - 2022-07-02 09:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:46:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:16:31 --> Total execution time: 0.1459
DEBUG - 2022-07-02 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:19:15 --> Total execution time: 0.0915
DEBUG - 2022-07-02 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:50:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:20:50 --> Total execution time: 0.0371
DEBUG - 2022-07-02 09:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:51:11 --> Total execution time: 0.0473
DEBUG - 2022-07-02 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:51:15 --> Total execution time: 0.0444
DEBUG - 2022-07-02 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:24:21 --> Total execution time: 0.0574
DEBUG - 2022-07-02 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:24:30 --> Total execution time: 0.0599
DEBUG - 2022-07-02 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:24:31 --> Total execution time: 0.0517
DEBUG - 2022-07-02 09:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:24:36 --> Total execution time: 0.4903
DEBUG - 2022-07-02 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:24:48 --> Total execution time: 0.0516
DEBUG - 2022-07-02 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:24:51 --> Total execution time: 0.0521
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-02 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 09:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-02 09:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:59:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:29:23 --> Total execution time: 0.1102
DEBUG - 2022-07-02 09:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:59:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 09:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:29:34 --> Total execution time: 0.0413
DEBUG - 2022-07-02 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 09:59:54 --> Total execution time: 0.0940
DEBUG - 2022-07-02 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:02 --> Total execution time: 0.0501
DEBUG - 2022-07-02 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:04 --> Total execution time: 0.0581
DEBUG - 2022-07-02 10:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:05 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:05 --> Total execution time: 0.1738
DEBUG - 2022-07-02 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:07 --> Total execution time: 0.0912
DEBUG - 2022-07-02 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:45 --> Total execution time: 0.0561
DEBUG - 2022-07-02 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:46 --> Total execution time: 0.0468
DEBUG - 2022-07-02 10:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:51 --> Total execution time: 0.0362
DEBUG - 2022-07-02 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:31:06 --> Total execution time: 0.0473
DEBUG - 2022-07-02 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:31:13 --> Total execution time: 0.0544
DEBUG - 2022-07-02 10:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:31:17 --> Total execution time: 0.0474
DEBUG - 2022-07-02 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:31:20 --> Total execution time: 0.0511
DEBUG - 2022-07-02 10:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:31:34 --> Total execution time: 0.0509
DEBUG - 2022-07-02 10:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:38 --> Total execution time: 0.0566
DEBUG - 2022-07-02 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:40 --> Total execution time: 0.0475
DEBUG - 2022-07-02 10:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:42 --> Total execution time: 0.0556
DEBUG - 2022-07-02 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:47 --> Total execution time: 0.0525
DEBUG - 2022-07-02 10:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:48 --> Total execution time: 0.0725
DEBUG - 2022-07-02 10:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:49 --> Total execution time: 0.0453
DEBUG - 2022-07-02 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:51 --> Total execution time: 0.0576
DEBUG - 2022-07-02 10:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:01:51 --> Total execution time: 0.0947
DEBUG - 2022-07-02 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:02:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:32:34 --> Total execution time: 1.6750
DEBUG - 2022-07-02 10:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:02:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 10:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:03:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:03:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:07:49 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:37:49 --> Total execution time: 0.1224
DEBUG - 2022-07-02 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:01 --> Total execution time: 0.0570
DEBUG - 2022-07-02 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:07 --> Total execution time: 0.0492
DEBUG - 2022-07-02 10:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:20 --> Total execution time: 0.0477
DEBUG - 2022-07-02 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:30 --> Total execution time: 0.0509
DEBUG - 2022-07-02 10:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:30 --> Total execution time: 0.0993
DEBUG - 2022-07-02 10:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:33 --> Total execution time: 0.0683
DEBUG - 2022-07-02 10:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:34 --> Total execution time: 0.0507
DEBUG - 2022-07-02 10:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:34 --> Total execution time: 0.1196
DEBUG - 2022-07-02 10:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:35 --> Total execution time: 0.0500
DEBUG - 2022-07-02 10:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:36 --> Total execution time: 0.0466
DEBUG - 2022-07-02 10:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:08:57 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 10:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:39:09 --> Total execution time: 0.0775
DEBUG - 2022-07-02 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:10:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:40:39 --> Total execution time: 0.0382
DEBUG - 2022-07-02 10:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:11:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:41:09 --> Total execution time: 0.0682
DEBUG - 2022-07-02 10:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:11:39 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 10:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:13:12 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:43:12 --> Total execution time: 0.0369
DEBUG - 2022-07-02 10:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:13:53 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 10:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:14:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:44:13 --> Total execution time: 0.0378
DEBUG - 2022-07-02 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:16:53 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:46:53 --> Total execution time: 0.0936
DEBUG - 2022-07-02 10:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:46:56 --> Total execution time: 0.0565
DEBUG - 2022-07-02 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:17:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:23 --> Total execution time: 0.0475
DEBUG - 2022-07-02 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:23 --> Total execution time: 0.0455
DEBUG - 2022-07-02 10:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:32 --> Total execution time: 0.0598
DEBUG - 2022-07-02 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:37 --> Total execution time: 0.0744
DEBUG - 2022-07-02 10:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:43 --> Total execution time: 0.0836
DEBUG - 2022-07-02 10:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:18:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:11 --> Total execution time: 0.0413
DEBUG - 2022-07-02 10:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:21:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:26 --> Total execution time: 0.0922
DEBUG - 2022-07-02 10:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:28 --> Total execution time: 0.0394
DEBUG - 2022-07-02 10:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:27 --> Total execution time: 0.0552
DEBUG - 2022-07-02 10:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:31 --> Total execution time: 0.0497
DEBUG - 2022-07-02 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:45 --> Total execution time: 0.0764
DEBUG - 2022-07-02 10:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:22:51 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:51 --> Total execution time: 0.1198
DEBUG - 2022-07-02 10:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:59 --> Total execution time: 0.0566
DEBUG - 2022-07-02 10:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:10 --> Total execution time: 0.0314
DEBUG - 2022-07-02 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:12 --> Total execution time: 0.0833
DEBUG - 2022-07-02 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:23:25 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:28 --> Total execution time: 0.0345
DEBUG - 2022-07-02 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:23:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:23:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:50 --> Total execution time: 0.0457
DEBUG - 2022-07-02 10:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:01 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:17 --> Total execution time: 0.0521
DEBUG - 2022-07-02 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:25 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:27 --> Total execution time: 0.0446
DEBUG - 2022-07-02 10:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:36 --> Total execution time: 0.0464
DEBUG - 2022-07-02 10:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:24:48 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:25:06 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:25:29 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:32 --> Total execution time: 0.0523
DEBUG - 2022-07-02 10:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:25:37 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:43 --> Total execution time: 0.0538
DEBUG - 2022-07-02 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:25:44 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:25:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:25:49 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 10:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:10 --> Total execution time: 0.0529
DEBUG - 2022-07-02 10:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:15 --> Total execution time: 0.0571
DEBUG - 2022-07-02 10:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:17 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:17 --> Total execution time: 0.0344
DEBUG - 2022-07-02 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:28 --> Total execution time: 0.0490
DEBUG - 2022-07-02 10:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:34 --> Total execution time: 0.0561
DEBUG - 2022-07-02 10:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:39 --> Total execution time: 0.0473
DEBUG - 2022-07-02 10:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:45 --> Total execution time: 0.0685
DEBUG - 2022-07-02 10:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:50 --> Total execution time: 0.0716
DEBUG - 2022-07-02 10:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:53 --> Total execution time: 0.0605
DEBUG - 2022-07-02 10:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:57:20 --> Total execution time: 0.1166
DEBUG - 2022-07-02 10:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:27:40 --> 404 Page Not Found: Cart/index
DEBUG - 2022-07-02 10:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:27:41 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:57:41 --> Total execution time: 0.0360
DEBUG - 2022-07-02 10:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:34:34 --> 404 Page Not Found: Lessons/how-to-execute-reselling-business-2
DEBUG - 2022-07-02 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:36:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:36:34 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-02 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:06:34 --> Total execution time: 0.0845
DEBUG - 2022-07-02 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:36:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:06:36 --> Total execution time: 0.0418
DEBUG - 2022-07-02 10:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:38:26 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:38:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:40 --> Total execution time: 0.0512
DEBUG - 2022-07-02 10:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:04 --> Total execution time: 0.0463
DEBUG - 2022-07-02 10:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:17 --> Total execution time: 0.0795
DEBUG - 2022-07-02 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:28 --> Total execution time: 0.0490
DEBUG - 2022-07-02 10:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:19 --> Total execution time: 0.0554
DEBUG - 2022-07-02 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:35 --> Total execution time: 0.1589
DEBUG - 2022-07-02 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:49 --> Total execution time: 0.0513
DEBUG - 2022-07-02 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:50 --> Total execution time: 0.0518
DEBUG - 2022-07-02 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:01 --> Total execution time: 0.0549
DEBUG - 2022-07-02 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:04 --> Total execution time: 0.0456
DEBUG - 2022-07-02 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:49 --> Total execution time: 0.0596
DEBUG - 2022-07-02 10:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:50 --> Total execution time: 0.0532
DEBUG - 2022-07-02 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:56 --> Total execution time: 0.0630
DEBUG - 2022-07-02 10:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:59 --> Total execution time: 0.0521
DEBUG - 2022-07-02 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:11 --> Total execution time: 0.0504
DEBUG - 2022-07-02 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:18 --> Total execution time: 0.0785
DEBUG - 2022-07-02 10:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:23 --> Total execution time: 0.0527
DEBUG - 2022-07-02 10:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:26 --> Total execution time: 0.0507
DEBUG - 2022-07-02 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:29 --> Total execution time: 0.0771
DEBUG - 2022-07-02 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:31 --> Total execution time: 0.0497
DEBUG - 2022-07-02 10:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 10:46:47 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 10:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:21 --> Total execution time: 0.1802
DEBUG - 2022-07-02 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:23 --> Total execution time: 0.0493
DEBUG - 2022-07-02 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:23 --> Total execution time: 0.1070
DEBUG - 2022-07-02 10:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:37 --> Total execution time: 0.0752
DEBUG - 2022-07-02 10:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:54 --> Total execution time: 0.0482
DEBUG - 2022-07-02 10:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:57 --> Total execution time: 0.0525
DEBUG - 2022-07-02 10:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:48:57 --> Total execution time: 0.0611
DEBUG - 2022-07-02 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:49:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:19:08 --> Total execution time: 0.0603
DEBUG - 2022-07-02 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:20:50 --> Total execution time: 0.1479
DEBUG - 2022-07-02 10:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:20:51 --> Total execution time: 0.0815
DEBUG - 2022-07-02 10:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:20:59 --> Total execution time: 0.0821
DEBUG - 2022-07-02 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:21:59 --> Total execution time: 0.0333
DEBUG - 2022-07-02 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:22:11 --> Total execution time: 0.0764
DEBUG - 2022-07-02 10:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:22:33 --> Total execution time: 0.0645
DEBUG - 2022-07-02 10:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:22:36 --> Total execution time: 0.0621
DEBUG - 2022-07-02 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:22:50 --> Total execution time: 0.0462
DEBUG - 2022-07-02 10:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:23:07 --> Total execution time: 0.0463
DEBUG - 2022-07-02 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:23:11 --> Total execution time: 0.0732
DEBUG - 2022-07-02 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:55:00 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:25:00 --> Total execution time: 0.1273
DEBUG - 2022-07-02 10:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:25:05 --> Total execution time: 0.0690
DEBUG - 2022-07-02 10:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:25:37 --> Total execution time: 0.0878
DEBUG - 2022-07-02 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:26:43 --> Total execution time: 0.1228
DEBUG - 2022-07-02 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:56:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:26:48 --> Total execution time: 0.1234
DEBUG - 2022-07-02 10:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:26:53 --> Total execution time: 0.1326
DEBUG - 2022-07-02 10:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:08 --> Total execution time: 0.0501
DEBUG - 2022-07-02 10:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:11 --> Total execution time: 0.0499
DEBUG - 2022-07-02 10:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:15 --> Total execution time: 0.0549
DEBUG - 2022-07-02 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:20 --> Total execution time: 0.0316
DEBUG - 2022-07-02 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:28 --> Total execution time: 0.0595
DEBUG - 2022-07-02 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:30 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:31 --> Total execution time: 0.0440
DEBUG - 2022-07-02 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:28:31 --> Total execution time: 0.0913
DEBUG - 2022-07-02 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:31 --> Total execution time: 0.0624
DEBUG - 2022-07-02 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:31 --> Total execution time: 0.0446
DEBUG - 2022-07-02 10:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:41 --> Total execution time: 0.0548
DEBUG - 2022-07-02 10:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:41 --> Total execution time: 0.0491
DEBUG - 2022-07-02 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:44 --> Total execution time: 0.0424
DEBUG - 2022-07-02 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:45 --> Total execution time: 0.1056
DEBUG - 2022-07-02 10:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:48 --> Total execution time: 0.0633
DEBUG - 2022-07-02 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:52 --> Total execution time: 0.0563
DEBUG - 2022-07-02 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:28:57 --> Total execution time: 0.0513
DEBUG - 2022-07-02 10:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:01 --> Total execution time: 0.0624
DEBUG - 2022-07-02 10:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:05 --> Total execution time: 0.0468
DEBUG - 2022-07-02 10:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:07 --> Total execution time: 0.0488
DEBUG - 2022-07-02 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:13 --> Total execution time: 0.0511
DEBUG - 2022-07-02 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:14 --> Total execution time: 0.0652
DEBUG - 2022-07-02 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 10:59:15 --> Total execution time: 0.0459
DEBUG - 2022-07-02 10:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:16 --> Total execution time: 0.0498
DEBUG - 2022-07-02 10:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:18 --> Total execution time: 0.0598
DEBUG - 2022-07-02 10:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:19 --> Total execution time: 0.0509
DEBUG - 2022-07-02 10:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:23 --> Total execution time: 0.0710
DEBUG - 2022-07-02 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:33 --> Total execution time: 0.0457
DEBUG - 2022-07-02 10:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:46 --> Total execution time: 0.0421
DEBUG - 2022-07-02 10:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 10:59:48 --> No URI present. Default controller set.
DEBUG - 2022-07-02 10:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 10:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:29:48 --> Total execution time: 0.0337
DEBUG - 2022-07-02 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:02 --> Total execution time: 0.0624
DEBUG - 2022-07-02 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:02 --> Total execution time: 0.0541
DEBUG - 2022-07-02 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:02 --> Total execution time: 0.0710
DEBUG - 2022-07-02 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:06 --> Total execution time: 0.0963
DEBUG - 2022-07-02 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:19 --> Total execution time: 0.0517
DEBUG - 2022-07-02 11:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:48 --> Total execution time: 0.0496
DEBUG - 2022-07-02 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:55 --> Total execution time: 0.0519
DEBUG - 2022-07-02 11:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:30:57 --> Total execution time: 0.0578
DEBUG - 2022-07-02 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:07 --> Total execution time: 0.1268
DEBUG - 2022-07-02 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:18 --> Total execution time: 0.0814
DEBUG - 2022-07-02 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:27 --> Total execution time: 0.0533
DEBUG - 2022-07-02 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:31 --> Total execution time: 0.0467
DEBUG - 2022-07-02 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:34 --> Total execution time: 0.0715
DEBUG - 2022-07-02 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:41 --> Total execution time: 0.0605
DEBUG - 2022-07-02 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:41 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:41 --> Total execution time: 0.1354
DEBUG - 2022-07-02 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:43 --> Total execution time: 0.0816
DEBUG - 2022-07-02 11:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:47 --> Total execution time: 0.0485
DEBUG - 2022-07-02 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:48 --> Total execution time: 0.0914
DEBUG - 2022-07-02 11:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:52 --> Total execution time: 0.0759
DEBUG - 2022-07-02 11:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:31:55 --> Total execution time: 0.0832
DEBUG - 2022-07-02 21:31:56 --> Total execution time: 1.4965
DEBUG - 2022-07-02 11:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:02:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:03 --> Total execution time: 0.0863
DEBUG - 2022-07-02 11:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:07 --> Total execution time: 0.0759
DEBUG - 2022-07-02 11:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:09 --> Total execution time: 0.0534
DEBUG - 2022-07-02 11:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:13 --> Total execution time: 0.0759
DEBUG - 2022-07-02 11:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:19 --> Total execution time: 0.0891
DEBUG - 2022-07-02 11:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:27 --> Total execution time: 0.0554
DEBUG - 2022-07-02 11:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:33 --> Total execution time: 0.0512
DEBUG - 2022-07-02 11:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:37 --> Total execution time: 0.0835
DEBUG - 2022-07-02 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:39 --> Total execution time: 0.0583
DEBUG - 2022-07-02 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:39 --> Total execution time: 0.0600
DEBUG - 2022-07-02 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:46 --> Total execution time: 0.0503
DEBUG - 2022-07-02 21:32:47 --> Total execution time: 1.5110
DEBUG - 2022-07-02 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:02:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:32:57 --> Total execution time: 0.0562
DEBUG - 2022-07-02 11:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:33:04 --> Total execution time: 0.0505
DEBUG - 2022-07-02 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:33:14 --> Total execution time: 0.0716
DEBUG - 2022-07-02 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:33:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:33:20 --> Total execution time: 0.0835
DEBUG - 2022-07-02 11:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:33:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:00 --> Total execution time: 0.0608
DEBUG - 2022-07-02 11:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 21:34:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 21:34:02 --> Total execution time: 0.2639
DEBUG - 2022-07-02 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:07 --> Total execution time: 0.1855
DEBUG - 2022-07-02 11:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:20 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:20 --> Total execution time: 0.0492
DEBUG - 2022-07-02 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:25 --> Total execution time: 0.0706
DEBUG - 2022-07-02 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:32 --> Total execution time: 0.0481
DEBUG - 2022-07-02 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:34 --> Total execution time: 0.0473
DEBUG - 2022-07-02 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:38 --> Total execution time: 0.1341
DEBUG - 2022-07-02 11:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:34:48 --> Total execution time: 1.4557
DEBUG - 2022-07-02 11:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:50 --> Total execution time: 1.8391
DEBUG - 2022-07-02 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:04:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:34:58 --> Total execution time: 0.0504
DEBUG - 2022-07-02 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:35:06 --> Total execution time: 0.0460
DEBUG - 2022-07-02 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:35:21 --> Total execution time: 0.1310
DEBUG - 2022-07-02 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:35:57 --> Total execution time: 0.0460
DEBUG - 2022-07-02 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:36:23 --> Total execution time: 0.0505
DEBUG - 2022-07-02 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:36:32 --> Total execution time: 0.0522
DEBUG - 2022-07-02 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:06:41 --> Total execution time: 0.0469
DEBUG - 2022-07-02 11:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:06:42 --> Total execution time: 0.0641
DEBUG - 2022-07-02 11:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:06:42 --> Total execution time: 0.0867
DEBUG - 2022-07-02 11:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:07:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 11:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:37:31 --> Total execution time: 0.1633
DEBUG - 2022-07-02 21:37:32 --> Total execution time: 1.5363
DEBUG - 2022-07-02 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:37:35 --> Total execution time: 0.0805
DEBUG - 2022-07-02 11:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:37:38 --> Total execution time: 0.0649
DEBUG - 2022-07-02 11:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:37:45 --> Total execution time: 0.0846
DEBUG - 2022-07-02 11:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:37:51 --> Total execution time: 0.0615
DEBUG - 2022-07-02 11:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:38:47 --> Total execution time: 0.0864
DEBUG - 2022-07-02 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:38:48 --> Total execution time: 0.0491
DEBUG - 2022-07-02 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:38:54 --> Total execution time: 0.1109
DEBUG - 2022-07-02 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:39:04 --> Total execution time: 0.0491
DEBUG - 2022-07-02 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:39:10 --> Total execution time: 0.0516
DEBUG - 2022-07-02 11:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:39:14 --> Total execution time: 0.0488
DEBUG - 2022-07-02 11:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:39:29 --> Total execution time: 0.0528
DEBUG - 2022-07-02 11:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:39:33 --> Total execution time: 0.0573
DEBUG - 2022-07-02 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:40:35 --> Total execution time: 0.0948
DEBUG - 2022-07-02 11:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:40:38 --> Total execution time: 0.0450
DEBUG - 2022-07-02 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:40:46 --> Total execution time: 0.0430
DEBUG - 2022-07-02 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:40:46 --> Total execution time: 0.0482
DEBUG - 2022-07-02 11:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:41:02 --> Total execution time: 0.0546
DEBUG - 2022-07-02 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:41:17 --> Total execution time: 0.0704
DEBUG - 2022-07-02 11:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:41:28 --> Total execution time: 0.0509
DEBUG - 2022-07-02 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:41:52 --> Total execution time: 0.0634
DEBUG - 2022-07-02 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:41:55 --> Total execution time: 0.0765
DEBUG - 2022-07-02 11:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:02 --> Total execution time: 0.1081
DEBUG - 2022-07-02 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:07 --> Total execution time: 0.0509
DEBUG - 2022-07-02 11:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:15 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:15 --> Total execution time: 0.0375
DEBUG - 2022-07-02 11:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:33 --> Total execution time: 0.1439
DEBUG - 2022-07-02 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:37 --> Total execution time: 0.0814
DEBUG - 2022-07-02 11:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:40 --> Total execution time: 0.0504
DEBUG - 2022-07-02 11:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:42 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:42 --> Total execution time: 0.0605
DEBUG - 2022-07-02 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:47 --> Total execution time: 0.0456
DEBUG - 2022-07-02 11:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:42:50 --> Total execution time: 0.0473
DEBUG - 2022-07-02 11:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:43:11 --> Total execution time: 0.0489
DEBUG - 2022-07-02 11:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:43:19 --> Total execution time: 0.0872
DEBUG - 2022-07-02 11:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:13:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:43:38 --> Total execution time: 0.0583
DEBUG - 2022-07-02 11:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:43:53 --> Total execution time: 1.6501
DEBUG - 2022-07-02 11:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:44:54 --> Total execution time: 0.0475
DEBUG - 2022-07-02 11:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:25 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:45:25 --> Total execution time: 0.0362
DEBUG - 2022-07-02 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:45:33 --> Total execution time: 0.0541
DEBUG - 2022-07-02 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:45:38 --> Total execution time: 0.0583
DEBUG - 2022-07-02 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:45:40 --> Total execution time: 0.0511
DEBUG - 2022-07-02 11:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:45:51 --> Total execution time: 0.0608
DEBUG - 2022-07-02 11:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:45:55 --> Total execution time: 0.0475
DEBUG - 2022-07-02 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:46:06 --> Total execution time: 0.0623
DEBUG - 2022-07-02 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:46:27 --> Total execution time: 0.0520
DEBUG - 2022-07-02 11:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:46:28 --> Total execution time: 0.0468
DEBUG - 2022-07-02 11:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:46:34 --> Total execution time: 0.0519
DEBUG - 2022-07-02 11:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:46:39 --> Total execution time: 0.0506
DEBUG - 2022-07-02 11:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:46:47 --> Total execution time: 0.0520
DEBUG - 2022-07-02 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:47:05 --> Total execution time: 0.0520
DEBUG - 2022-07-02 11:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:47:19 --> Total execution time: 0.0458
DEBUG - 2022-07-02 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:47:58 --> Total execution time: 0.0457
DEBUG - 2022-07-02 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:48:09 --> Total execution time: 0.1236
DEBUG - 2022-07-02 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:19:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:49:23 --> Total execution time: 0.0372
DEBUG - 2022-07-02 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:19:30 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:19:58 --> Total execution time: 0.0495
DEBUG - 2022-07-02 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:20:02 --> Total execution time: 0.0798
DEBUG - 2022-07-02 11:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:50:39 --> Total execution time: 0.0736
DEBUG - 2022-07-02 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:32 --> Total execution time: 0.0766
DEBUG - 2022-07-02 11:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:38 --> Total execution time: 0.0722
DEBUG - 2022-07-02 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:44 --> Total execution time: 0.0522
DEBUG - 2022-07-02 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:50 --> Total execution time: 0.0606
DEBUG - 2022-07-02 11:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:54 --> Total execution time: 0.1268
DEBUG - 2022-07-02 11:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:57 --> Total execution time: 0.0461
DEBUG - 2022-07-02 11:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:22:06 --> Total execution time: 0.0345
DEBUG - 2022-07-02 11:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:22:12 --> Total execution time: 0.0618
DEBUG - 2022-07-02 11:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:22:12 --> Total execution time: 0.1026
DEBUG - 2022-07-02 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:52:20 --> Total execution time: 0.0676
DEBUG - 2022-07-02 11:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:52:32 --> Total execution time: 0.0704
DEBUG - 2022-07-02 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:52:59 --> Total execution time: 0.0882
DEBUG - 2022-07-02 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:53:10 --> Total execution time: 0.1223
DEBUG - 2022-07-02 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:54:27 --> Total execution time: 0.0532
DEBUG - 2022-07-02 11:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:24:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:54:40 --> Total execution time: 0.0346
DEBUG - 2022-07-02 11:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:24:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:54:40 --> Total execution time: 0.0394
DEBUG - 2022-07-02 11:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:25:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:55:04 --> Total execution time: 0.0585
DEBUG - 2022-07-02 11:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:55:15 --> Total execution time: 0.0397
DEBUG - 2022-07-02 11:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:55:33 --> Total execution time: 0.0764
DEBUG - 2022-07-02 11:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:55:37 --> Total execution time: 0.0534
DEBUG - 2022-07-02 11:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:55:51 --> Total execution time: 0.0454
DEBUG - 2022-07-02 11:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:56:02 --> Total execution time: 0.0489
DEBUG - 2022-07-02 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:56:17 --> Total execution time: 0.0895
DEBUG - 2022-07-02 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:56:38 --> Total execution time: 0.0775
DEBUG - 2022-07-02 11:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:57:03 --> Total execution time: 0.0938
DEBUG - 2022-07-02 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:27:21 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:57:21 --> Total execution time: 0.0434
DEBUG - 2022-07-02 11:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:58:15 --> Total execution time: 0.0813
DEBUG - 2022-07-02 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:59:01 --> Total execution time: 0.0457
DEBUG - 2022-07-02 11:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:59:56 --> Total execution time: 0.0479
DEBUG - 2022-07-02 11:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:30:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:00:01 --> Total execution time: 0.0451
DEBUG - 2022-07-02 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:30:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:00:10 --> Total execution time: 0.0333
DEBUG - 2022-07-02 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:30:11 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-02 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:30:35 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:00:35 --> Total execution time: 0.0465
DEBUG - 2022-07-02 11:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:01:19 --> Total execution time: 0.0481
DEBUG - 2022-07-02 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:01:23 --> Total execution time: 0.0464
DEBUG - 2022-07-02 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:01:26 --> Total execution time: 0.0373
DEBUG - 2022-07-02 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:31:27 --> 404 Page Not Found: Wp-admin/admin.php
DEBUG - 2022-07-02 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:31:27 --> 404 Page Not Found: Wp-admin/admin.php
DEBUG - 2022-07-02 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:31:27 --> 404 Page Not Found: Wp-admin/options.php
DEBUG - 2022-07-02 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:01:54 --> Total execution time: 0.0568
DEBUG - 2022-07-02 11:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:03:38 --> Total execution time: 0.0468
DEBUG - 2022-07-02 11:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:05:37 --> Total execution time: 0.0520
DEBUG - 2022-07-02 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:06:36 --> Total execution time: 0.1176
DEBUG - 2022-07-02 11:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:08:35 --> Total execution time: 0.0479
DEBUG - 2022-07-02 11:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:39:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:09:32 --> Total execution time: 0.0352
DEBUG - 2022-07-02 11:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:09:33 --> Total execution time: 0.0676
DEBUG - 2022-07-02 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:39:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:09:45 --> Total execution time: 0.0408
DEBUG - 2022-07-02 11:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:39:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:09:47 --> Total execution time: 0.0449
DEBUG - 2022-07-02 11:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:39:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:09:47 --> Total execution time: 0.0473
DEBUG - 2022-07-02 11:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:10:01 --> Total execution time: 0.0613
DEBUG - 2022-07-02 11:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:12:38 --> Total execution time: 0.0628
DEBUG - 2022-07-02 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:12:52 --> Total execution time: 0.0462
DEBUG - 2022-07-02 11:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:12:57 --> Total execution time: 0.0582
DEBUG - 2022-07-02 11:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:07 --> Total execution time: 0.0863
DEBUG - 2022-07-02 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:14 --> Total execution time: 0.0387
DEBUG - 2022-07-02 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:22 --> Total execution time: 0.0377
DEBUG - 2022-07-02 11:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:23 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:23 --> Total execution time: 0.0445
DEBUG - 2022-07-02 11:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:38 --> Total execution time: 0.0330
DEBUG - 2022-07-02 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:58 --> Total execution time: 0.0511
DEBUG - 2022-07-02 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:44:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:14:02 --> Total execution time: 0.0494
DEBUG - 2022-07-02 11:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:14:30 --> Total execution time: 0.1173
DEBUG - 2022-07-02 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:45:42 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:17:51 --> Total execution time: 0.0613
DEBUG - 2022-07-02 11:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:18:02 --> Total execution time: 0.0995
DEBUG - 2022-07-02 11:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:18:10 --> Total execution time: 0.0622
DEBUG - 2022-07-02 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:18:21 --> Total execution time: 0.0508
DEBUG - 2022-07-02 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:18:36 --> Total execution time: 0.0638
DEBUG - 2022-07-02 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:18:55 --> Total execution time: 0.0511
DEBUG - 2022-07-02 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:19:12 --> Total execution time: 0.0826
DEBUG - 2022-07-02 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:19:15 --> Total execution time: 0.0555
DEBUG - 2022-07-02 11:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:19:20 --> Total execution time: 0.0467
DEBUG - 2022-07-02 11:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:32 --> Total execution time: 0.1380
DEBUG - 2022-07-02 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:34 --> Total execution time: 0.0577
DEBUG - 2022-07-02 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:41 --> Total execution time: 0.0487
DEBUG - 2022-07-02 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:51 --> Total execution time: 0.0563
DEBUG - 2022-07-02 11:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:54 --> Total execution time: 0.0577
DEBUG - 2022-07-02 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:22:04 --> Total execution time: 0.1244
DEBUG - 2022-07-02 11:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:52:47 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:23:59 --> Total execution time: 0.0541
DEBUG - 2022-07-02 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:55:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:55:33 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:26:26 --> Total execution time: 0.0521
DEBUG - 2022-07-02 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:26:31 --> Total execution time: 0.0535
DEBUG - 2022-07-02 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:26:33 --> Total execution time: 0.0893
DEBUG - 2022-07-02 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:26:42 --> Total execution time: 0.0514
DEBUG - 2022-07-02 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 11:57:57 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 11:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:28:37 --> Total execution time: 0.0395
DEBUG - 2022-07-02 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:03 --> Total execution time: 0.0466
DEBUG - 2022-07-02 11:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:10 --> Total execution time: 0.0561
DEBUG - 2022-07-02 11:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:23 --> Total execution time: 0.0458
DEBUG - 2022-07-02 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:35 --> Total execution time: 0.0471
DEBUG - 2022-07-02 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:40 --> Total execution time: 0.0452
DEBUG - 2022-07-02 11:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:43 --> Total execution time: 0.0460
DEBUG - 2022-07-02 11:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 11:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 11:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 11:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:29:50 --> Total execution time: 0.0514
DEBUG - 2022-07-02 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:02 --> Total execution time: 0.0626
DEBUG - 2022-07-02 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:03 --> Total execution time: 0.1147
DEBUG - 2022-07-02 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:15 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:15 --> Total execution time: 0.0581
DEBUG - 2022-07-02 12:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:18 --> Total execution time: 0.0856
DEBUG - 2022-07-02 12:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:24 --> Total execution time: 0.0837
DEBUG - 2022-07-02 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:27 --> Total execution time: 0.0578
DEBUG - 2022-07-02 12:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:31 --> Total execution time: 0.0604
DEBUG - 2022-07-02 12:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:33 --> Total execution time: 0.0494
DEBUG - 2022-07-02 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:35 --> Total execution time: 0.0514
DEBUG - 2022-07-02 12:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:39 --> Total execution time: 0.0518
DEBUG - 2022-07-02 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:42 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:42 --> Total execution time: 0.0325
DEBUG - 2022-07-02 12:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:46 --> Total execution time: 0.0524
DEBUG - 2022-07-02 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:30:50 --> Total execution time: 0.0668
DEBUG - 2022-07-02 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:21 --> Total execution time: 0.0509
DEBUG - 2022-07-02 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:33:47 --> Total execution time: 0.0617
DEBUG - 2022-07-02 12:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:33:54 --> Total execution time: 0.0463
DEBUG - 2022-07-02 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:33:56 --> Total execution time: 0.0586
DEBUG - 2022-07-02 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:34:03 --> Total execution time: 0.0491
DEBUG - 2022-07-02 12:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:44 --> Total execution time: 0.0814
DEBUG - 2022-07-02 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:11 --> Total execution time: 0.2276
DEBUG - 2022-07-02 12:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:13 --> Total execution time: 0.0546
DEBUG - 2022-07-02 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:16 --> Total execution time: 0.0639
DEBUG - 2022-07-02 12:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:09:27 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:40:26 --> Total execution time: 0.1417
DEBUG - 2022-07-02 12:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:40:45 --> Total execution time: 0.0869
DEBUG - 2022-07-02 12:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:40:46 --> Total execution time: 0.0790
DEBUG - 2022-07-02 12:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:41:18 --> Total execution time: 0.0688
DEBUG - 2022-07-02 12:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:41:31 --> Total execution time: 0.0773
DEBUG - 2022-07-02 12:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:09 --> Total execution time: 0.0389
DEBUG - 2022-07-02 12:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:11 --> Total execution time: 0.0592
DEBUG - 2022-07-02 12:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:14 --> Total execution time: 0.0336
DEBUG - 2022-07-02 12:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:14 --> Total execution time: 0.0304
DEBUG - 2022-07-02 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:16 --> Total execution time: 0.1083
DEBUG - 2022-07-02 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:18 --> Total execution time: 0.0500
DEBUG - 2022-07-02 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:21 --> Total execution time: 0.0525
DEBUG - 2022-07-02 12:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:24 --> Total execution time: 0.0803
DEBUG - 2022-07-02 12:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:36 --> Total execution time: 0.0706
DEBUG - 2022-07-02 12:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:25 --> Total execution time: 0.0582
DEBUG - 2022-07-02 12:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:44:24 --> Total execution time: 0.0562
DEBUG - 2022-07-02 12:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:44:36 --> Total execution time: 0.0471
DEBUG - 2022-07-02 12:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:36 --> Total execution time: 0.1445
DEBUG - 2022-07-02 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:10 --> Total execution time: 0.0537
DEBUG - 2022-07-02 12:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:29 --> Total execution time: 0.0718
DEBUG - 2022-07-02 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:16:58 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:59 --> Total execution time: 0.0531
DEBUG - 2022-07-02 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:17:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:17:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:17:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:17:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:17:51 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:09 --> Total execution time: 0.0539
DEBUG - 2022-07-02 12:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:18:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:18:41 --> Total execution time: 0.0466
DEBUG - 2022-07-02 12:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:18:41 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:45 --> Total execution time: 0.0456
DEBUG - 2022-07-02 12:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:51 --> Total execution time: 0.0843
DEBUG - 2022-07-02 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:52 --> Total execution time: 0.0709
DEBUG - 2022-07-02 12:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:56 --> Total execution time: 0.1310
DEBUG - 2022-07-02 12:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:58 --> Total execution time: 0.1274
DEBUG - 2022-07-02 12:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:59 --> Total execution time: 0.1505
DEBUG - 2022-07-02 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:00 --> Total execution time: 0.1381
DEBUG - 2022-07-02 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:00 --> Total execution time: 0.0667
DEBUG - 2022-07-02 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:19:05 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:08 --> Total execution time: 0.1320
DEBUG - 2022-07-02 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:09 --> Total execution time: 0.1305
DEBUG - 2022-07-02 12:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:09 --> Total execution time: 0.2904
DEBUG - 2022-07-02 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:19:11 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:13 --> Total execution time: 0.0763
DEBUG - 2022-07-02 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:19:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:18 --> Total execution time: 0.1079
DEBUG - 2022-07-02 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:19:33 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:49:38 --> Total execution time: 0.0578
DEBUG - 2022-07-02 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:19:41 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:19:48 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:20:01 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:02 --> Total execution time: 0.0835
DEBUG - 2022-07-02 12:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:02 --> Total execution time: 0.1685
DEBUG - 2022-07-02 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:03 --> Total execution time: 0.0727
DEBUG - 2022-07-02 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:06 --> Total execution time: 0.0747
DEBUG - 2022-07-02 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:06 --> Total execution time: 0.0447
DEBUG - 2022-07-02 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:07 --> Total execution time: 0.0673
DEBUG - 2022-07-02 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:20:12 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:19 --> Total execution time: 0.0941
DEBUG - 2022-07-02 12:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:19 --> Total execution time: 0.0795
DEBUG - 2022-07-02 12:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:20 --> Total execution time: 0.0798
DEBUG - 2022-07-02 12:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:20 --> Total execution time: 0.0716
DEBUG - 2022-07-02 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:21 --> Total execution time: 0.0716
DEBUG - 2022-07-02 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:22 --> Total execution time: 0.0921
DEBUG - 2022-07-02 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:20:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:33 --> Total execution time: 0.1036
DEBUG - 2022-07-02 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:20:35 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:41 --> Total execution time: 0.0477
DEBUG - 2022-07-02 12:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:20:51 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:20:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:05 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:20 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:24 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:24 --> Total execution time: 0.1305
DEBUG - 2022-07-02 12:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:29 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:31 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:34 --> Total execution time: 0.0555
DEBUG - 2022-07-02 12:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:35 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:21:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:52 --> Total execution time: 0.0517
DEBUG - 2022-07-02 12:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:00 --> Total execution time: 0.0498
DEBUG - 2022-07-02 12:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:08 --> Total execution time: 0.0500
DEBUG - 2022-07-02 12:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:17 --> Total execution time: 0.0658
DEBUG - 2022-07-02 12:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:18 --> Total execution time: 0.0504
DEBUG - 2022-07-02 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:20 --> Total execution time: 0.0449
DEBUG - 2022-07-02 12:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:22 --> Total execution time: 0.0500
DEBUG - 2022-07-02 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:25 --> Total execution time: 0.0480
DEBUG - 2022-07-02 12:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:25 --> Total execution time: 0.0430
DEBUG - 2022-07-02 12:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:26 --> Total execution time: 0.0667
DEBUG - 2022-07-02 12:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:22:26 --> Total execution time: 0.0903
DEBUG - 2022-07-02 12:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-07-02 22:52:26 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-07-02 22:52:26 --> Total execution time: 0.0543
DEBUG - 2022-07-02 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:28 --> Total execution time: 0.0507
DEBUG - 2022-07-02 12:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:32 --> Total execution time: 0.0334
DEBUG - 2022-07-02 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:42 --> Total execution time: 0.0556
DEBUG - 2022-07-02 12:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:22:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:56 --> Total execution time: 0.0344
DEBUG - 2022-07-02 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:23:04 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:53:28 --> Total execution time: 0.0459
DEBUG - 2022-07-02 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:23:34 --> Total execution time: 0.0477
DEBUG - 2022-07-02 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:23:36 --> Total execution time: 0.0751
DEBUG - 2022-07-02 12:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:23:36 --> Total execution time: 0.1036
DEBUG - 2022-07-02 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:53:51 --> Total execution time: 0.0455
DEBUG - 2022-07-02 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:53:59 --> Total execution time: 0.0544
DEBUG - 2022-07-02 12:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:03 --> Total execution time: 0.0674
DEBUG - 2022-07-02 12:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:16 --> Total execution time: 0.0659
DEBUG - 2022-07-02 12:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:18 --> Total execution time: 0.0663
DEBUG - 2022-07-02 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:27 --> Total execution time: 0.0727
DEBUG - 2022-07-02 12:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:34 --> Total execution time: 0.0517
DEBUG - 2022-07-02 12:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:40 --> Total execution time: 0.0462
DEBUG - 2022-07-02 12:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:42 --> Total execution time: 0.0772
DEBUG - 2022-07-02 12:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:52 --> Total execution time: 0.0498
DEBUG - 2022-07-02 12:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:55 --> Total execution time: 0.0696
DEBUG - 2022-07-02 12:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:01 --> Total execution time: 0.0996
DEBUG - 2022-07-02 12:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:05 --> Total execution time: 0.0655
DEBUG - 2022-07-02 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:12 --> Total execution time: 0.0492
DEBUG - 2022-07-02 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:21 --> Total execution time: 0.0507
DEBUG - 2022-07-02 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:26 --> Total execution time: 0.0562
DEBUG - 2022-07-02 12:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:29 --> Total execution time: 0.0479
DEBUG - 2022-07-02 12:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:37 --> Total execution time: 0.0652
DEBUG - 2022-07-02 12:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:41 --> Total execution time: 0.0658
DEBUG - 2022-07-02 12:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:50 --> Total execution time: 0.0549
DEBUG - 2022-07-02 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:52 --> Total execution time: 0.0522
DEBUG - 2022-07-02 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:52 --> Total execution time: 0.0561
DEBUG - 2022-07-02 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:52 --> Total execution time: 0.0548
DEBUG - 2022-07-02 12:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:53 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:53 --> Total execution time: 0.0328
DEBUG - 2022-07-02 12:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:55:53 --> Total execution time: 0.0577
DEBUG - 2022-07-02 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:56:15 --> Total execution time: 0.0570
DEBUG - 2022-07-02 12:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:56:31 --> Total execution time: 0.0464
DEBUG - 2022-07-02 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:56:35 --> Total execution time: 0.0485
DEBUG - 2022-07-02 12:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:59:10 --> Total execution time: 0.0494
DEBUG - 2022-07-02 12:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:34:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:04:03 --> Total execution time: 0.1340
DEBUG - 2022-07-02 12:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:05:11 --> Total execution time: 0.0554
DEBUG - 2022-07-02 12:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:10:36 --> Total execution time: 0.1184
DEBUG - 2022-07-02 12:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:12:15 --> Total execution time: 0.1304
DEBUG - 2022-07-02 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:43:02 --> Total execution time: 0.1344
DEBUG - 2022-07-02 12:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:43:04 --> Total execution time: 0.0682
DEBUG - 2022-07-02 12:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:43:04 --> Total execution time: 0.0543
DEBUG - 2022-07-02 12:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:44:45 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 12:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:45:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:15:05 --> Total execution time: 1.5008
DEBUG - 2022-07-02 12:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:45:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 12:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:16:47 --> Total execution time: 0.0350
DEBUG - 2022-07-02 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:17:35 --> Total execution time: 0.1522
DEBUG - 2022-07-02 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:05 --> Total execution time: 0.0565
DEBUG - 2022-07-02 12:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 23:18:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 23:18:07 --> Total execution time: 0.1814
DEBUG - 2022-07-02 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:12 --> Total execution time: 0.0494
DEBUG - 2022-07-02 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:15 --> Total execution time: 0.0719
DEBUG - 2022-07-02 12:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:33 --> Total execution time: 0.1171
DEBUG - 2022-07-02 12:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 12:48:58 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-02 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:20:26 --> Total execution time: 0.2435
DEBUG - 2022-07-02 12:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:50:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:20:40 --> Total execution time: 0.0516
DEBUG - 2022-07-02 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:20:49 --> Total execution time: 0.0314
DEBUG - 2022-07-02 12:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:20:54 --> Total execution time: 0.0492
DEBUG - 2022-07-02 12:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:20:56 --> Total execution time: 0.0703
DEBUG - 2022-07-02 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:21:28 --> Total execution time: 0.1417
DEBUG - 2022-07-02 12:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:21:36 --> Total execution time: 0.0725
DEBUG - 2022-07-02 12:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:21:39 --> Total execution time: 0.0960
DEBUG - 2022-07-02 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:21:50 --> Total execution time: 0.0637
DEBUG - 2022-07-02 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:52:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:02 --> Total execution time: 0.0646
DEBUG - 2022-07-02 12:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 12:56:14 --> No URI present. Default controller set.
DEBUG - 2022-07-02 12:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 12:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:26:14 --> Total execution time: 0.1106
DEBUG - 2022-07-02 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:03 --> Total execution time: 0.0993
DEBUG - 2022-07-02 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:05:05 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:35:05 --> Total execution time: 0.0971
DEBUG - 2022-07-02 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:35:09 --> Total execution time: 0.0338
DEBUG - 2022-07-02 13:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:35:18 --> Total execution time: 0.0561
DEBUG - 2022-07-02 13:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:35:22 --> Total execution time: 0.0990
DEBUG - 2022-07-02 13:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:35:23 --> Total execution time: 0.0825
DEBUG - 2022-07-02 13:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:10:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:40:13 --> Total execution time: 0.0878
DEBUG - 2022-07-02 13:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:10:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:40:56 --> Total execution time: 0.0745
DEBUG - 2022-07-02 13:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:41:05 --> Total execution time: 0.0340
DEBUG - 2022-07-02 13:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:42:02 --> Total execution time: 0.0467
DEBUG - 2022-07-02 13:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:42:59 --> Total execution time: 0.0563
DEBUG - 2022-07-02 13:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:43:11 --> Total execution time: 0.0506
DEBUG - 2022-07-02 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:44:13 --> Total execution time: 0.0623
DEBUG - 2022-07-02 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:15:34 --> Total execution time: 0.0538
DEBUG - 2022-07-02 13:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:45:45 --> Total execution time: 0.0462
DEBUG - 2022-07-02 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:17:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:47:26 --> Total execution time: 0.0370
DEBUG - 2022-07-02 13:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:17:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:47:27 --> Total execution time: 0.0498
DEBUG - 2022-07-02 13:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:48:13 --> Total execution time: 0.0358
DEBUG - 2022-07-02 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:19 --> Total execution time: 0.1462
DEBUG - 2022-07-02 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:50:34 --> Total execution time: 0.0845
DEBUG - 2022-07-02 13:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:50:43 --> Total execution time: 0.0535
DEBUG - 2022-07-02 13:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:50:51 --> Total execution time: 0.0530
DEBUG - 2022-07-02 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:50:55 --> Total execution time: 0.0496
DEBUG - 2022-07-02 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:51:03 --> Total execution time: 0.0479
DEBUG - 2022-07-02 13:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:51:35 --> Total execution time: 0.0542
DEBUG - 2022-07-02 13:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:51:39 --> Total execution time: 0.0500
DEBUG - 2022-07-02 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:51:46 --> Total execution time: 0.0928
DEBUG - 2022-07-02 13:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:52:54 --> Total execution time: 0.1279
DEBUG - 2022-07-02 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:20 --> Total execution time: 0.0573
DEBUG - 2022-07-02 13:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:30:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:32:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:36:39 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 13:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:39:23 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 13:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:39:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:41:34 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 13:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:41:41 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:45:00 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-02 13:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:45:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:45:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 13:45:13 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-02 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:46:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:53:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:57:12 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 13:58:59 --> No URI present. Default controller set.
DEBUG - 2022-07-02 13:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 13:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 14:06:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:13:30 --> No URI present. Default controller set.
DEBUG - 2022-07-02 14:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:25:28 --> No URI present. Default controller set.
DEBUG - 2022-07-02 14:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:25:49 --> No URI present. Default controller set.
DEBUG - 2022-07-02 14:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 14:26:05 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:26:08 --> No URI present. Default controller set.
DEBUG - 2022-07-02 14:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:26:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 14:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:28:09 --> No URI present. Default controller set.
DEBUG - 2022-07-02 14:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 14:54:51 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 14:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 14:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 14:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 14:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 15:22:22 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 15:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 15:25:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 15:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 15:27:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 15:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:30:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 15:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 15:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 15:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 15:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 15:52:57 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 16:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 16:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 16:08:38 --> 404 Page Not Found: Hbhbrdryldphp/index
DEBUG - 2022-07-02 16:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 16:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 16:33:06 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 16:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 16:46:16 --> No URI present. Default controller set.
DEBUG - 2022-07-02 16:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 16:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:03:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 17:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:03:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 17:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 17:07:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 17:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:09:16 --> No URI present. Default controller set.
DEBUG - 2022-07-02 17:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:09:18 --> No URI present. Default controller set.
DEBUG - 2022-07-02 17:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 17:09:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 17:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 17:10:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 17:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:11:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 17:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 17:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 17:12:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 17:37:51 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 17:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 17:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 17:52:00 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-07-02 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 18:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 18:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 18:18:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 18:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:18:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 18:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 18:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:18:29 --> No URI present. Default controller set.
DEBUG - 2022-07-02 18:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 18:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 18:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 18:18:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 18:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:51:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 18:51:20 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 18:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 18:53:54 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 18:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 18:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 18:56:02 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 19:08:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 19:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 19:08:54 --> 404 Page Not Found: Teacher/demyan-rostislav
DEBUG - 2022-07-02 19:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:13:25 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:13:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:13:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:20:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 19:20:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 19:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:22:52 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:23:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 19:34:16 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-02 19:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:35:47 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:37:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:43 --> Total execution time: 0.0394
DEBUG - 2022-07-02 19:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:44 --> Total execution time: 0.0507
DEBUG - 2022-07-02 19:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:44 --> Total execution time: 0.1113
DEBUG - 2022-07-02 19:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:38:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:44:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 19:44:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 19:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:44:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 19:44:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 19:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:44:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 19:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 19:52:16 --> No URI present. Default controller set.
DEBUG - 2022-07-02 19:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 19:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 20:09:24 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 20:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:21:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:26:49 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:29:56 --> Total execution time: 0.0819
DEBUG - 2022-07-02 20:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:29:58 --> Total execution time: 0.0765
DEBUG - 2022-07-02 20:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:29:58 --> Total execution time: 0.1199
DEBUG - 2022-07-02 20:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:30:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:30:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:32:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:32:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 20:32:15 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 20:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 20:34:49 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 20:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:36:12 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:36:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 20:36:57 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 20:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:39:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:43 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:51 --> Total execution time: 0.0482
DEBUG - 2022-07-02 20:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:52 --> Total execution time: 0.0522
DEBUG - 2022-07-02 20:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:50:52 --> Total execution time: 0.0517
DEBUG - 2022-07-02 20:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:50:53 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:06 --> Total execution time: 0.0330
DEBUG - 2022-07-02 20:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:07 --> Total execution time: 0.0494
DEBUG - 2022-07-02 20:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:07 --> Total execution time: 0.0915
DEBUG - 2022-07-02 20:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:04 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 20:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 20:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 20:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 20:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:00:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-02 21:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:00:23 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-02 21:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:00:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:00:37 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 21:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:08:51 --> Total execution time: 0.0444
DEBUG - 2022-07-02 21:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:09 --> Total execution time: 0.0637
DEBUG - 2022-07-02 21:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:22 --> Total execution time: 0.0478
DEBUG - 2022-07-02 21:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:30 --> Total execution time: 0.0592
DEBUG - 2022-07-02 21:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:33 --> Total execution time: 0.0664
DEBUG - 2022-07-02 21:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:52 --> Total execution time: 0.0489
DEBUG - 2022-07-02 21:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:57 --> Total execution time: 0.0659
DEBUG - 2022-07-02 21:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:09:57 --> Total execution time: 0.1454
DEBUG - 2022-07-02 21:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:38 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:12:10 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:13:54 --> 404 Page Not Found: Shell4php/index
DEBUG - 2022-07-02 21:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:13:55 --> 404 Page Not Found: Upsphp/index
DEBUG - 2022-07-02 21:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:13:56 --> 404 Page Not Found: Ruphp/index
DEBUG - 2022-07-02 21:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:13:57 --> 404 Page Not Found: Ifphp/index
DEBUG - 2022-07-02 21:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:13:58 --> 404 Page Not Found: Vulnphp/index
DEBUG - 2022-07-02 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:13:59 --> 404 Page Not Found: Fwphp/index
DEBUG - 2022-07-02 21:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:00 --> 404 Page Not Found: Skipperphp/index
DEBUG - 2022-07-02 21:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:01 --> 404 Page Not Found: Skippershellphp/index
DEBUG - 2022-07-02 21:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:02 --> 404 Page Not Found: Ttttphp/index
DEBUG - 2022-07-02 21:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:03 --> 404 Page Not Found: Tshopphp/index
DEBUG - 2022-07-02 21:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:04 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-07-02 21:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:05 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-07-02 21:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:06 --> 404 Page Not Found: Inje3ctorphp/index
DEBUG - 2022-07-02 21:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:07 --> 404 Page Not Found: Saudiphp/index
DEBUG - 2022-07-02 21:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:08 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-07-02 21:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:09 --> 404 Page Not Found: Alfashellphp/index
DEBUG - 2022-07-02 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:10 --> 404 Page Not Found: My_alfaphp/index
DEBUG - 2022-07-02 21:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:11 --> 404 Page Not Found: Uploaderphp/index
DEBUG - 2022-07-02 21:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:12 --> 404 Page Not Found: Upphp/index
DEBUG - 2022-07-02 21:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:13 --> 404 Page Not Found: Hackedphp/index
DEBUG - 2022-07-02 21:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:15 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-07-02 21:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:16 --> 404 Page Not Found: Navirphp/index
DEBUG - 2022-07-02 21:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:17 --> 404 Page Not Found: Cmd13php/index
DEBUG - 2022-07-02 21:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:18 --> 404 Page Not Found: Inc20k1php/index
DEBUG - 2022-07-02 21:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:19 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-07-02 21:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:20 --> 404 Page Not Found: 404php/index
DEBUG - 2022-07-02 21:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:21 --> 404 Page Not Found: Swmphp/index
DEBUG - 2022-07-02 21:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:22 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-07-02 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:23 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-07-02 21:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:24 --> 404 Page Not Found: Shxphp/index
DEBUG - 2022-07-02 21:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:25 --> 404 Page Not Found: Wsphp/index
DEBUG - 2022-07-02 21:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:26 --> 404 Page Not Found: Mphp/index
DEBUG - 2022-07-02 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:27 --> 404 Page Not Found: Edit-formphp/index
DEBUG - 2022-07-02 21:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:28 --> 404 Page Not Found: LEAFphp/index
DEBUG - 2022-07-02 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:29 --> 404 Page Not Found: Leafmailerphp/index
DEBUG - 2022-07-02 21:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:30 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-07-02 21:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:31 --> 404 Page Not Found: Leafmailer28php/index
DEBUG - 2022-07-02 21:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:31 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-07-02 21:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:33 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-07-02 21:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:34 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-07-02 21:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:35 --> 404 Page Not Found: Srxphp/index
DEBUG - 2022-07-02 21:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:36 --> 404 Page Not Found: 1337php/index
DEBUG - 2022-07-02 21:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:37 --> 404 Page Not Found: Xxphp/index
DEBUG - 2022-07-02 21:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:38 --> 404 Page Not Found: XxXphp/index
DEBUG - 2022-07-02 21:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:39 --> 404 Page Not Found: Lfphp/index
DEBUG - 2022-07-02 21:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:40 --> 404 Page Not Found: Alexphp/index
DEBUG - 2022-07-02 21:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:41 --> 404 Page Not Found: Newphp/index
DEBUG - 2022-07-02 21:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:42 --> 404 Page Not Found: Marijuanaphp/index
DEBUG - 2022-07-02 21:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:43 --> 404 Page Not Found: Gazaphp/index
DEBUG - 2022-07-02 21:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:44 --> 404 Page Not Found: Wp-adminphp/index
DEBUG - 2022-07-02 21:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:45 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-07-02 21:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:46 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-07-02 21:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:47 --> 404 Page Not Found: Wso1php/index
DEBUG - 2022-07-02 21:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:48 --> 404 Page Not Found: Bbphp/index
DEBUG - 2022-07-02 21:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:48 --> 404 Page Not Found: Luxphp/index
DEBUG - 2022-07-02 21:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:50 --> 404 Page Not Found: Haxorphp/index
DEBUG - 2022-07-02 21:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:51 --> 404 Page Not Found: Aphp/index
DEBUG - 2022-07-02 21:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:52 --> 404 Page Not Found: Zphp/index
DEBUG - 2022-07-02 21:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:53 --> 404 Page Not Found: Ephp/index
DEBUG - 2022-07-02 21:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:54 --> 404 Page Not Found: Rphp/index
DEBUG - 2022-07-02 21:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:55 --> 404 Page Not Found: Tphp/index
DEBUG - 2022-07-02 21:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:56 --> 404 Page Not Found: Yphp/index
DEBUG - 2022-07-02 21:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:57 --> 404 Page Not Found: Uphp/index
DEBUG - 2022-07-02 21:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:58 --> 404 Page Not Found: Iphp/index
DEBUG - 2022-07-02 21:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:14:59 --> 404 Page Not Found: Ophp/index
DEBUG - 2022-07-02 21:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:00 --> 404 Page Not Found: Pphp/index
DEBUG - 2022-07-02 21:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:01 --> 404 Page Not Found: Qphp/index
DEBUG - 2022-07-02 21:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:02 --> 404 Page Not Found: Sphp/index
DEBUG - 2022-07-02 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:03 --> 404 Page Not Found: Dphp/index
DEBUG - 2022-07-02 21:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:04 --> 404 Page Not Found: Fphp/index
DEBUG - 2022-07-02 21:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:05 --> 404 Page Not Found: Gphp/index
DEBUG - 2022-07-02 21:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:06 --> 404 Page Not Found: Hphp/index
DEBUG - 2022-07-02 21:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:07 --> 404 Page Not Found: Jphp/index
DEBUG - 2022-07-02 21:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:08 --> 404 Page Not Found: Kphp/index
DEBUG - 2022-07-02 21:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:09 --> 404 Page Not Found: Lphp/index
DEBUG - 2022-07-02 21:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:10 --> 404 Page Not Found: Mphp/index
DEBUG - 2022-07-02 21:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:11 --> 404 Page Not Found: Wphp/index
DEBUG - 2022-07-02 21:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:12 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-07-02 21:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:13 --> 404 Page Not Found: Cphp/index
DEBUG - 2022-07-02 21:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:14 --> 404 Page Not Found: Vphp/index
DEBUG - 2022-07-02 21:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:15 --> 404 Page Not Found: Bphp/index
DEBUG - 2022-07-02 21:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:16 --> 404 Page Not Found: Nphp/index
DEBUG - 2022-07-02 21:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:17 --> 404 Page Not Found: New-indexphp/index
DEBUG - 2022-07-02 21:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:18 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-07-02 21:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:19 --> 404 Page Not Found: Sendemailphp/index
DEBUG - 2022-07-02 21:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:20 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-07-02 21:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:21 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-07-02 21:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:22 --> 404 Page Not Found: 2indexphp/index
DEBUG - 2022-07-02 21:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:23 --> 404 Page Not Found: Kindexphp/index
DEBUG - 2022-07-02 21:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:24 --> 404 Page Not Found: Cpanelphp/index
DEBUG - 2022-07-02 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:25 --> 404 Page Not Found: Cpphp/index
DEBUG - 2022-07-02 21:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:26 --> 404 Page Not Found: Cpanelphp/index
DEBUG - 2022-07-02 21:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:27 --> 404 Page Not Found: Marphp/index
DEBUG - 2022-07-02 21:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:28 --> 404 Page Not Found: Sym403php/index
DEBUG - 2022-07-02 21:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:28 --> 404 Page Not Found: Contentphp/index
DEBUG - 2022-07-02 21:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:29 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-07-02 21:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:30 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-07-02 21:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:31 --> 404 Page Not Found: FoxWSOv1php/index
DEBUG - 2022-07-02 21:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:32 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-07-02 21:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:33 --> 404 Page Not Found: Alfphp/index
DEBUG - 2022-07-02 21:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:34 --> 404 Page Not Found: Wsphp/index
DEBUG - 2022-07-02 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:35 --> 404 Page Not Found: 1php/index
DEBUG - 2022-07-02 21:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:36 --> 404 Page Not Found: 2php/index
DEBUG - 2022-07-02 21:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:37 --> 404 Page Not Found: 3php/index
DEBUG - 2022-07-02 21:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:38 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-07-02 21:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:39 --> 404 Page Not Found: Bbphp/index
DEBUG - 2022-07-02 21:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:40 --> 404 Page Not Found: Leafmailer28php/index
DEBUG - 2022-07-02 21:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:41 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-07-02 21:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:42 --> 404 Page Not Found: 1php/index
DEBUG - 2022-07-02 21:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:43 --> 404 Page Not Found: Kphp/index
DEBUG - 2022-07-02 21:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:44 --> 404 Page Not Found: Alexphp/index
DEBUG - 2022-07-02 21:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:45 --> 404 Page Not Found: Lfphp/index
DEBUG - 2022-07-02 21:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:46 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-07-02 21:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:47 --> 404 Page Not Found: Alfphp/index
DEBUG - 2022-07-02 21:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:48 --> 404 Page Not Found: 2php/index
DEBUG - 2022-07-02 21:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:49 --> 404 Page Not Found: Xoxphp/index
DEBUG - 2022-07-02 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:50 --> 404 Page Not Found: Xophp/index
DEBUG - 2022-07-02 21:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:51 --> 404 Page Not Found: Miphp/index
DEBUG - 2022-07-02 21:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:52 --> 404 Page Not Found: Sphp/index
DEBUG - 2022-07-02 21:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:54 --> 404 Page Not Found: Alexusmailer%2020php/index
DEBUG - 2022-07-02 21:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:55 --> 404 Page Not Found: Rssphp/index
DEBUG - 2022-07-02 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:56 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-07-02 21:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:57 --> 404 Page Not Found: WSOphp/index
DEBUG - 2022-07-02 21:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:58 --> 404 Page Not Found: Alwsophp/index
DEBUG - 2022-07-02 21:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:15:59 --> 404 Page Not Found: Wp-content/includes
DEBUG - 2022-07-02 21:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 21:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:01 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-02 21:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:02 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:03 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:04 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:04 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:05 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:06 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:07 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:08 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:09 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:10 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-07-02 21:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:11 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-02 21:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:12 --> 404 Page Not Found: Wp-includes/sys.php
DEBUG - 2022-07-02 21:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:13 --> 404 Page Not Found: Xxxphp/index
DEBUG - 2022-07-02 21:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:14 --> 404 Page Not Found: 11indexphp/index
DEBUG - 2022-07-02 21:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:15 --> 404 Page Not Found: Hellophp/index
DEBUG - 2022-07-02 21:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:16 --> 404 Page Not Found: Faphp/index
DEBUG - 2022-07-02 21:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:17 --> 404 Page Not Found: 3php/index
DEBUG - 2022-07-02 21:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:18 --> 404 Page Not Found: Alexus-mailerphp/index
DEBUG - 2022-07-02 21:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:19 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-07-02 21:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:20 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-07-02 21:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:21 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-07-02 21:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:22 --> 404 Page Not Found: Miniphp/index
DEBUG - 2022-07-02 21:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:23 --> 404 Page Not Found: Wp-adphp/index
DEBUG - 2022-07-02 21:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:24 --> 404 Page Not Found: Wp-filephp/index
DEBUG - 2022-07-02 21:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:25 --> 404 Page Not Found: Okphp/index
DEBUG - 2022-07-02 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:26 --> 404 Page Not Found: Wso2php/index
DEBUG - 2022-07-02 21:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:27 --> 404 Page Not Found: Wso1php/index
DEBUG - 2022-07-02 21:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:27 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:28 --> 404 Page Not Found: Ifphp/index
DEBUG - 2022-07-02 21:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:29 --> 404 Page Not Found: Kkphp/index
DEBUG - 2022-07-02 21:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:30 --> 404 Page Not Found: Aphp/index
DEBUG - 2022-07-02 21:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:31 --> 404 Page Not Found: Zphp/index
DEBUG - 2022-07-02 21:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:32 --> 404 Page Not Found: Ephp/index
DEBUG - 2022-07-02 21:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:33 --> 404 Page Not Found: Rphp/index
DEBUG - 2022-07-02 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:34 --> 404 Page Not Found: Tphp/index
DEBUG - 2022-07-02 21:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:35 --> 404 Page Not Found: Yphp/index
DEBUG - 2022-07-02 21:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:36 --> 404 Page Not Found: Uphp/index
DEBUG - 2022-07-02 21:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:37 --> 404 Page Not Found: Iphp/index
DEBUG - 2022-07-02 21:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:38 --> 404 Page Not Found: Ophp/index
DEBUG - 2022-07-02 21:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:39 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-07-02 21:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:40 --> 404 Page Not Found: Anonephp/index
DEBUG - 2022-07-02 21:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:41 --> 404 Page Not Found: Wp-configerphp/index
DEBUG - 2022-07-02 21:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:42 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-07-02 21:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:42 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:43 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-07-02 21:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:44 --> 404 Page Not Found: Cphp/index
DEBUG - 2022-07-02 21:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:44 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:45 --> 404 Page Not Found: 1php/index
DEBUG - 2022-07-02 21:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:46 --> 404 Page Not Found: Sendphp/index
DEBUG - 2022-07-02 21:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:47 --> 404 Page Not Found: 3php/index
DEBUG - 2022-07-02 21:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:48 --> 404 Page Not Found: Wp-rssphp/index
DEBUG - 2022-07-02 21:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:48 --> 404 Page Not Found: Wp-cachephp/index
DEBUG - 2022-07-02 21:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:49 --> 404 Page Not Found: Sendmailphp/index
DEBUG - 2022-07-02 21:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:50 --> 404 Page Not Found: Wp/rahma.php
DEBUG - 2022-07-02 21:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:51 --> 404 Page Not Found: Rahmaphp/index
DEBUG - 2022-07-02 21:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:52 --> 404 Page Not Found: Nasgorphp/index
DEBUG - 2022-07-02 21:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:53 --> 404 Page Not Found: 404php/index
DEBUG - 2022-07-02 21:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:54 --> 404 Page Not Found: Wp-admin/admin.php
DEBUG - 2022-07-02 21:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:54 --> 404 Page Not Found: Symphp/index
DEBUG - 2022-07-02 21:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:55 --> 404 Page Not Found: Wp-confirmphp/index
DEBUG - 2022-07-02 21:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:56 --> 404 Page Not Found: Alfa123php/index
DEBUG - 2022-07-02 21:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:57 --> 404 Page Not Found: Drphp/index
DEBUG - 2022-07-02 21:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:58 --> 404 Page Not Found: Wp-admin/admin.php
DEBUG - 2022-07-02 21:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:58 --> 404 Page Not Found: Bypassphp/index
DEBUG - 2022-07-02 21:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:16:59 --> 404 Page Not Found: Wp-blogphp/index
DEBUG - 2022-07-02 21:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:00 --> 404 Page Not Found: Sym403php/index
DEBUG - 2022-07-02 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:01 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-07-02 21:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:02 --> 404 Page Not Found: Dataphp/index
DEBUG - 2022-07-02 21:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:03 --> 404 Page Not Found: Wp-onephp/index
DEBUG - 2022-07-02 21:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:04 --> 404 Page Not Found: Alexusphp/index
DEBUG - 2022-07-02 21:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:05 --> 404 Page Not Found: Edit-formphp/index
DEBUG - 2022-07-02 21:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:06 --> 404 Page Not Found: Wso1337php/index
DEBUG - 2022-07-02 21:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:07 --> 404 Page Not Found: Wwwphp/index
DEBUG - 2022-07-02 21:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:08 --> 404 Page Not Found: Uploads/contexmini.php
DEBUG - 2022-07-02 21:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:09 --> 404 Page Not Found: Blogphp/index
DEBUG - 2022-07-02 21:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:10 --> 404 Page Not Found: Itphp/index
DEBUG - 2022-07-02 21:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:11 --> 404 Page Not Found: Kissphp/index
DEBUG - 2022-07-02 21:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:12 --> 404 Page Not Found: Wp-admin/options.php
DEBUG - 2022-07-02 21:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:12 --> 404 Page Not Found: 0php/index
DEBUG - 2022-07-02 21:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:13 --> 404 Page Not Found: Wp2php/index
DEBUG - 2022-07-02 21:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:14 --> 404 Page Not Found: Owlphp/index
DEBUG - 2022-07-02 21:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:15 --> 404 Page Not Found: Symlinkphp/index
DEBUG - 2022-07-02 21:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:16 --> 404 Page Not Found: Ohayophp/index
DEBUG - 2022-07-02 21:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:17 --> 404 Page Not Found: 100php/index
DEBUG - 2022-07-02 21:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:18 --> 404 Page Not Found: 777php/index
DEBUG - 2022-07-02 21:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:19 --> 404 Page Not Found: Wp-content/wp-logins.php
DEBUG - 2022-07-02 21:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:20 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-07-02 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:21 --> 404 Page Not Found: 2indexphp/index
DEBUG - 2022-07-02 21:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:22 --> 404 Page Not Found: Wp-content/wp-admin.php
DEBUG - 2022-07-02 21:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:23 --> 404 Page Not Found: Wp-adminphp/index
DEBUG - 2022-07-02 21:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:24 --> 404 Page Not Found: Miniphp/index
DEBUG - 2022-07-02 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:25 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-07-02 21:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:26 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-07-02 21:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:27 --> 404 Page Not Found: Shxphp/index
DEBUG - 2022-07-02 21:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:28 --> 404 Page Not Found: FoxWSOphp/index
DEBUG - 2022-07-02 21:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:29 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-07-02 21:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:30 --> 404 Page Not Found: Cmsphp/index
DEBUG - 2022-07-02 21:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:31 --> 404 Page Not Found: Stindexphp/index
DEBUG - 2022-07-02 21:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:32 --> 404 Page Not Found: Wp-uploadsphp/index
DEBUG - 2022-07-02 21:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:33 --> 404 Page Not Found: Autoload_classmapphp/index
DEBUG - 2022-07-02 21:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:34 --> 404 Page Not Found: Gelphp/index
DEBUG - 2022-07-02 21:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:35 --> 404 Page Not Found: Defau1tphp/index
DEBUG - 2022-07-02 21:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:36 --> 404 Page Not Found: 0bytephp/index
DEBUG - 2022-07-02 21:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:37 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-07-02 21:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:38 --> 404 Page Not Found: 41php/index
DEBUG - 2022-07-02 21:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:39 --> 404 Page Not Found: 4pricephp/index
DEBUG - 2022-07-02 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:40 --> 404 Page Not Found: MARIJUANAphp/index
DEBUG - 2022-07-02 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:41 --> 404 Page Not Found: Fphp/index
DEBUG - 2022-07-02 21:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:42 --> 404 Page Not Found: Fkphp/index
DEBUG - 2022-07-02 21:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:43 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-07-02 21:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:44 --> 404 Page Not Found: Xoxphp/index
DEBUG - 2022-07-02 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:45 --> 404 Page Not Found: Newphp/index
DEBUG - 2022-07-02 21:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:46 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-07-02 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:47 --> 404 Page Not Found: Sindexphp/index
DEBUG - 2022-07-02 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:48 --> 404 Page Not Found: Baindexphp/index
DEBUG - 2022-07-02 21:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:49 --> 404 Page Not Found: New-indexphp/index
DEBUG - 2022-07-02 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:50 --> 404 Page Not Found: Wiphp/index
DEBUG - 2022-07-02 21:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:51 --> 404 Page Not Found: XxXphp/index
DEBUG - 2022-07-02 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:17:52 --> 404 Page Not Found: Marphp/index
DEBUG - 2022-07-02 21:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:18:41 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:19:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 21:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:19:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:41:35 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:52:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 21:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 21:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 21:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 21:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 21:55:30 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-07-02 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 22:08:05 --> 404 Page Not Found: Cart/index
DEBUG - 2022-07-02 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 22:10:39 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 22:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:11:58 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:12:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 22:13:12 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 22:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:15:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 22:15:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 22:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:15:50 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:16:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:19:11 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:19:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:21:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:22:34 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:22:36 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:52 --> Total execution time: 0.0580
DEBUG - 2022-07-02 22:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:53 --> Total execution time: 0.0469
DEBUG - 2022-07-02 22:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:54 --> Total execution time: 0.0795
DEBUG - 2022-07-02 22:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:54 --> Total execution time: 0.0992
DEBUG - 2022-07-02 22:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:55 --> Total execution time: 0.0511
DEBUG - 2022-07-02 22:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:55 --> Total execution time: 0.1052
DEBUG - 2022-07-02 22:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:32:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:44 --> Total execution time: 0.0569
DEBUG - 2022-07-02 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:36:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:37:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:38:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 22:38:50 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-02 22:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:41:37 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:45 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:09 --> Total execution time: 0.0498
DEBUG - 2022-07-02 22:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:17 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:45:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:45:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:45:33 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:00 --> Total execution time: 0.0483
DEBUG - 2022-07-02 22:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:05 --> Total execution time: 0.0883
DEBUG - 2022-07-02 22:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:05 --> Total execution time: 0.1602
DEBUG - 2022-07-02 22:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:46:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 22:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 22:47:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 22:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:52:02 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:52:03 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:58:31 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 22:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 22:58:32 --> No URI present. Default controller set.
DEBUG - 2022-07-02 22:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 22:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:26 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:02:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:13:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 23:13:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 23:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:13:56 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:15:55 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:19 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:31 --> Total execution time: 0.0354
DEBUG - 2022-07-02 23:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:41 --> Total execution time: 0.0614
DEBUG - 2022-07-02 23:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:41 --> Total execution time: 0.0997
DEBUG - 2022-07-02 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:13 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:25 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:40 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:54 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:01 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:43:57 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:46:24 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 23:49:35 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-02 23:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:52:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 23:52:06 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-02 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 23:54:08 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-02 23:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:55:46 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:56:07 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:56:22 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:56:39 --> No URI present. Default controller set.
DEBUG - 2022-07-02 23:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:15 --> Total execution time: 0.0598
DEBUG - 2022-07-02 23:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:17 --> Total execution time: 0.0556
DEBUG - 2022-07-02 23:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:17 --> Total execution time: 0.0971
DEBUG - 2022-07-02 23:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:26 --> Total execution time: 0.0457
DEBUG - 2022-07-02 23:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:38 --> Total execution time: 0.0548
DEBUG - 2022-07-02 23:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:58:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-02 23:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-02 23:58:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-02 23:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-02 23:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-02 23:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-02 23:59:50 --> Encryption: Auto-configured driver 'openssl'.
