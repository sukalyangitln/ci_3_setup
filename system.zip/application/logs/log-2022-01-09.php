<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-09 17:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-09 17:17:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-01-09 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-09 17:17:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-01-09 17:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 17:17:19 --> Total execution time: 0.0801
DEBUG - 2022-01-09 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 17:17:19 --> Total execution time: 0.0545
DEBUG - 2022-01-09 17:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 17:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:26 --> Total execution time: 0.1097
DEBUG - 2022-01-09 17:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:29 --> Total execution time: 0.1027
DEBUG - 2022-01-09 17:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:40 --> Total execution time: 0.0677
DEBUG - 2022-01-09 17:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:42 --> Total execution time: 0.0750
DEBUG - 2022-01-09 17:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:43 --> Total execution time: 0.0534
DEBUG - 2022-01-09 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:44 --> Total execution time: 0.0637
DEBUG - 2022-01-09 17:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:47:45 --> Total execution time: 0.0747
DEBUG - 2022-01-09 17:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:52:21 --> Total execution time: 0.0670
DEBUG - 2022-01-09 17:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:57:46 --> Total execution time: 0.0795
DEBUG - 2022-01-09 17:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:58:18 --> Total execution time: 0.0615
DEBUG - 2022-01-09 17:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:58:35 --> Total execution time: 0.0588
DEBUG - 2022-01-09 17:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:58:52 --> Total execution time: 0.0641
DEBUG - 2022-01-09 17:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:59:03 --> Total execution time: 0.0682
DEBUG - 2022-01-09 17:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:59:26 --> Total execution time: 0.0778
DEBUG - 2022-01-09 17:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:59:34 --> Total execution time: 0.0751
DEBUG - 2022-01-09 17:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 21:59:45 --> Total execution time: 0.0655
DEBUG - 2022-01-09 17:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:00:14 --> Total execution time: 0.0719
DEBUG - 2022-01-09 17:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:00:16 --> Total execution time: 0.0743
DEBUG - 2022-01-09 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:01:02 --> Total execution time: 0.0528
DEBUG - 2022-01-09 17:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:01:23 --> Total execution time: 0.0621
DEBUG - 2022-01-09 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:01:43 --> Total execution time: 0.0569
DEBUG - 2022-01-09 17:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:01:54 --> Total execution time: 0.0832
DEBUG - 2022-01-09 17:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:02:13 --> Total execution time: 0.0944
DEBUG - 2022-01-09 17:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:02:26 --> Total execution time: 0.0964
DEBUG - 2022-01-09 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:04:09 --> Total execution time: 0.0779
DEBUG - 2022-01-09 17:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:04:58 --> Total execution time: 0.0723
DEBUG - 2022-01-09 17:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:09:05 --> Total execution time: 0.0507
DEBUG - 2022-01-09 17:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:09:11 --> Total execution time: 0.0516
DEBUG - 2022-01-09 17:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:10:04 --> Total execution time: 0.0511
DEBUG - 2022-01-09 17:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:10:23 --> Total execution time: 0.0509
DEBUG - 2022-01-09 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:11:11 --> Total execution time: 0.0722
DEBUG - 2022-01-09 17:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 17:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 17:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-09 22:11:30 --> Total execution time: 0.0606
