<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-23 00:00:37 --> Total execution time: 0.1386
DEBUG - 2022-06-23 00:01:19 --> Total execution time: 0.1291
DEBUG - 2022-06-23 00:01:27 --> Total execution time: 0.0575
DEBUG - 2022-06-23 00:01:27 --> Total execution time: 0.0442
DEBUG - 2022-06-23 00:06:23 --> Total execution time: 0.0459
DEBUG - 2022-06-23 00:06:49 --> Total execution time: 0.0353
DEBUG - 2022-06-23 00:07:14 --> Total execution time: 0.1070
DEBUG - 2022-06-23 00:08:20 --> Total execution time: 0.0395
DEBUG - 2022-06-23 00:08:21 --> Total execution time: 0.0479
DEBUG - 2022-06-23 00:08:22 --> Total execution time: 0.0440
DEBUG - 2022-06-23 00:08:24 --> Total execution time: 0.0518
DEBUG - 2022-06-23 00:08:25 --> Total execution time: 0.0419
DEBUG - 2022-06-23 00:10:14 --> Total execution time: 0.0308
DEBUG - 2022-06-23 00:10:33 --> Total execution time: 0.0495
DEBUG - 2022-06-23 00:10:36 --> Total execution time: 0.0460
DEBUG - 2022-06-23 00:10:39 --> Total execution time: 0.0560
DEBUG - 2022-06-23 00:10:47 --> Total execution time: 0.0763
DEBUG - 2022-06-23 00:14:18 --> Total execution time: 0.0591
DEBUG - 2022-06-23 00:17:26 --> Total execution time: 0.0887
DEBUG - 2022-06-23 00:17:27 --> Total execution time: 0.0574
DEBUG - 2022-06-23 00:17:29 --> Total execution time: 0.0512
DEBUG - 2022-06-23 00:21:31 --> Total execution time: 0.0810
DEBUG - 2022-06-23 00:21:37 --> Total execution time: 0.0524
DEBUG - 2022-06-23 00:21:44 --> Total execution time: 0.0515
DEBUG - 2022-06-23 00:21:47 --> Total execution time: 0.0517
DEBUG - 2022-06-23 00:21:51 --> Total execution time: 0.0410
DEBUG - 2022-06-23 00:21:54 --> Total execution time: 0.0422
DEBUG - 2022-06-23 00:23:03 --> Total execution time: 0.1425
DEBUG - 2022-06-23 00:23:07 --> Total execution time: 0.0968
DEBUG - 2022-06-23 00:23:14 --> Total execution time: 0.0804
DEBUG - 2022-06-23 00:23:22 --> Total execution time: 0.0632
DEBUG - 2022-06-23 00:23:36 --> Total execution time: 0.0559
DEBUG - 2022-06-23 00:23:44 --> Total execution time: 0.0475
DEBUG - 2022-06-23 00:30:03 --> Total execution time: 0.5169
DEBUG - 2022-06-23 00:30:06 --> Total execution time: 0.0445
DEBUG - 2022-06-23 00:30:45 --> Total execution time: 0.0703
DEBUG - 2022-06-23 00:30:55 --> Total execution time: 0.0523
DEBUG - 2022-06-23 00:30:59 --> Total execution time: 0.0628
DEBUG - 2022-06-23 00:31:11 --> Total execution time: 0.0424
DEBUG - 2022-06-23 00:31:49 --> Total execution time: 0.0368
DEBUG - 2022-06-23 00:33:09 --> Total execution time: 0.0320
DEBUG - 2022-06-23 00:33:12 --> Total execution time: 0.0424
DEBUG - 2022-06-23 00:34:40 --> Total execution time: 0.0337
DEBUG - 2022-06-23 00:34:43 --> Total execution time: 0.1210
DEBUG - 2022-06-23 00:34:54 --> Total execution time: 0.0424
DEBUG - 2022-06-23 00:35:16 --> Total execution time: 0.0599
DEBUG - 2022-06-23 00:35:20 --> Total execution time: 0.0639
DEBUG - 2022-06-23 00:42:13 --> Total execution time: 0.1810
DEBUG - 2022-06-23 00:42:16 --> Total execution time: 0.0475
DEBUG - 2022-06-23 00:44:54 --> Total execution time: 0.1517
DEBUG - 2022-06-23 00:46:23 --> Total execution time: 0.0451
DEBUG - 2022-06-23 00:46:38 --> Total execution time: 0.0365
DEBUG - 2022-06-23 00:46:54 --> Total execution time: 0.0351
DEBUG - 2022-06-23 00:47:03 --> Total execution time: 0.0496
DEBUG - 2022-06-23 00:47:08 --> Total execution time: 0.0605
DEBUG - 2022-06-23 00:47:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 00:47:09 --> Total execution time: 0.0421
DEBUG - 2022-06-23 00:47:51 --> Total execution time: 0.0407
DEBUG - 2022-06-23 00:47:53 --> Total execution time: 0.0474
DEBUG - 2022-06-23 00:48:03 --> Total execution time: 0.0649
DEBUG - 2022-06-23 00:48:16 --> Total execution time: 0.0756
DEBUG - 2022-06-23 00:48:32 --> Total execution time: 0.0739
DEBUG - 2022-06-23 00:48:38 --> Total execution time: 0.0525
DEBUG - 2022-06-23 00:48:40 --> Total execution time: 0.0522
DEBUG - 2022-06-23 00:48:48 --> Total execution time: 0.0422
DEBUG - 2022-06-23 00:59:27 --> Total execution time: 0.1534
DEBUG - 2022-06-23 00:59:28 --> Total execution time: 0.0417
DEBUG - 2022-06-23 00:59:30 --> Total execution time: 0.0423
DEBUG - 2022-06-23 01:05:56 --> Total execution time: 0.1460
DEBUG - 2022-06-23 01:30:03 --> Total execution time: 0.1264
DEBUG - 2022-06-23 01:44:53 --> Total execution time: 0.1238
DEBUG - 2022-06-23 02:21:53 --> Total execution time: 0.1475
DEBUG - 2022-06-23 02:21:58 --> Total execution time: 0.0318
DEBUG - 2022-06-23 02:22:14 --> Total execution time: 0.0708
DEBUG - 2022-06-23 02:22:17 --> Total execution time: 0.0847
DEBUG - 2022-06-23 02:30:02 --> Total execution time: 0.1981
DEBUG - 2022-06-23 02:34:47 --> Total execution time: 0.0955
DEBUG - 2022-06-23 02:34:47 --> Total execution time: 0.0526
DEBUG - 2022-06-23 02:34:47 --> Total execution time: 0.0495
DEBUG - 2022-06-23 02:34:47 --> Total execution time: 0.0572
DEBUG - 2022-06-23 02:42:02 --> Total execution time: 0.0997
DEBUG - 2022-06-23 02:50:47 --> Total execution time: 0.0849
DEBUG - 2022-06-23 02:50:49 --> Total execution time: 0.0450
DEBUG - 2022-06-23 02:51:01 --> Total execution time: 0.0604
DEBUG - 2022-06-23 02:51:07 --> Total execution time: 0.0518
DEBUG - 2022-06-23 02:51:14 --> Total execution time: 0.0763
DEBUG - 2022-06-23 02:51:36 --> Total execution time: 0.0813
DEBUG - 2022-06-23 02:51:45 --> Total execution time: 0.0525
DEBUG - 2022-06-23 02:52:02 --> Total execution time: 0.0883
DEBUG - 2022-06-23 02:52:04 --> Total execution time: 0.1049
DEBUG - 2022-06-23 02:52:08 --> Total execution time: 0.0966
DEBUG - 2022-06-23 02:52:46 --> Total execution time: 0.0896
DEBUG - 2022-06-23 02:52:55 --> Total execution time: 0.0450
DEBUG - 2022-06-23 02:53:04 --> Total execution time: 0.0441
DEBUG - 2022-06-23 02:53:12 --> Total execution time: 0.0504
DEBUG - 2022-06-23 02:53:13 --> Total execution time: 0.0463
DEBUG - 2022-06-23 02:53:50 --> Total execution time: 0.0371
DEBUG - 2022-06-23 02:53:52 --> Total execution time: 0.0497
DEBUG - 2022-06-23 02:53:54 --> Total execution time: 0.0613
DEBUG - 2022-06-23 02:56:39 --> Total execution time: 0.1363
DEBUG - 2022-06-23 02:56:45 --> Total execution time: 0.0400
DEBUG - 2022-06-23 02:56:48 --> Total execution time: 0.0273
DEBUG - 2022-06-23 03:08:29 --> Total execution time: 0.0928
DEBUG - 2022-06-23 03:08:30 --> Total execution time: 0.0250
DEBUG - 2022-06-23 03:10:24 --> Total execution time: 1.9416
DEBUG - 2022-06-23 03:10:43 --> Total execution time: 1.4611
DEBUG - 2022-06-23 03:10:45 --> Total execution time: 0.0603
DEBUG - 2022-06-23 03:10:46 --> Total execution time: 0.0516
DEBUG - 2022-06-23 03:10:50 --> Total execution time: 0.0516
DEBUG - 2022-06-23 03:10:57 --> Total execution time: 0.0553
DEBUG - 2022-06-23 03:11:09 --> Total execution time: 0.0541
DEBUG - 2022-06-23 03:11:22 --> Total execution time: 0.1034
DEBUG - 2022-06-23 03:11:35 --> Total execution time: 0.0649
DEBUG - 2022-06-23 03:30:03 --> Total execution time: 0.0954
DEBUG - 2022-06-23 04:24:07 --> Total execution time: 0.1377
DEBUG - 2022-06-23 04:30:02 --> Total execution time: 0.1292
DEBUG - 2022-06-23 04:49:58 --> Total execution time: 0.0466
DEBUG - 2022-06-23 04:50:03 --> Total execution time: 0.0793
DEBUG - 2022-06-23 04:50:12 --> Total execution time: 0.0926
DEBUG - 2022-06-23 05:00:53 --> Total execution time: 0.0919
DEBUG - 2022-06-23 05:06:47 --> Total execution time: 0.0713
DEBUG - 2022-06-23 05:29:20 --> Total execution time: 0.1243
DEBUG - 2022-06-23 05:30:02 --> Total execution time: 0.0517
DEBUG - 2022-06-23 05:37:03 --> Total execution time: 0.0737
DEBUG - 2022-06-23 05:37:04 --> Total execution time: 0.0420
DEBUG - 2022-06-23 05:37:06 --> Total execution time: 0.0401
DEBUG - 2022-06-23 05:50:30 --> Total execution time: 0.1026
DEBUG - 2022-06-23 05:50:34 --> Total execution time: 0.0428
DEBUG - 2022-06-23 05:50:58 --> Total execution time: 0.0508
DEBUG - 2022-06-23 05:51:07 --> Total execution time: 0.0686
DEBUG - 2022-06-23 05:53:58 --> Total execution time: 0.0810
DEBUG - 2022-06-23 05:55:07 --> Total execution time: 0.0347
DEBUG - 2022-06-23 05:55:13 --> Total execution time: 0.0272
DEBUG - 2022-06-23 05:55:32 --> Total execution time: 0.0323
DEBUG - 2022-06-23 06:07:01 --> Total execution time: 0.1128
DEBUG - 2022-06-23 06:07:05 --> Total execution time: 0.0584
DEBUG - 2022-06-23 06:07:20 --> Total execution time: 0.0572
DEBUG - 2022-06-23 06:07:34 --> Total execution time: 0.0873
DEBUG - 2022-06-23 06:07:54 --> Total execution time: 0.0764
DEBUG - 2022-06-23 06:08:20 --> Total execution time: 0.0482
DEBUG - 2022-06-23 06:08:31 --> Total execution time: 0.0653
DEBUG - 2022-06-23 06:08:55 --> Total execution time: 0.0464
DEBUG - 2022-06-23 06:08:55 --> Total execution time: 0.0451
DEBUG - 2022-06-23 06:09:05 --> Total execution time: 0.0735
DEBUG - 2022-06-23 06:09:16 --> Total execution time: 0.0681
DEBUG - 2022-06-23 06:09:27 --> Total execution time: 0.0332
DEBUG - 2022-06-23 06:09:28 --> Total execution time: 0.0325
DEBUG - 2022-06-23 06:13:16 --> Total execution time: 0.0478
DEBUG - 2022-06-23 06:18:36 --> Total execution time: 0.0999
DEBUG - 2022-06-23 06:30:03 --> Total execution time: 0.1733
DEBUG - 2022-06-23 06:37:14 --> Total execution time: 0.0519
DEBUG - 2022-06-23 06:38:16 --> Total execution time: 0.0530
DEBUG - 2022-06-23 06:38:26 --> Total execution time: 0.0516
DEBUG - 2022-06-23 06:38:35 --> Total execution time: 0.0606
DEBUG - 2022-06-23 06:38:48 --> Total execution time: 0.0478
DEBUG - 2022-06-23 06:39:08 --> Total execution time: 0.0505
DEBUG - 2022-06-23 06:41:12 --> Total execution time: 0.0931
DEBUG - 2022-06-23 06:41:23 --> Total execution time: 0.0535
DEBUG - 2022-06-23 06:46:30 --> Total execution time: 0.1399
DEBUG - 2022-06-23 06:47:23 --> Total execution time: 0.0435
DEBUG - 2022-06-23 06:48:00 --> Total execution time: 0.0401
DEBUG - 2022-06-23 06:48:01 --> Total execution time: 0.0402
DEBUG - 2022-06-23 06:48:07 --> Total execution time: 0.0419
DEBUG - 2022-06-23 06:48:22 --> Total execution time: 0.0594
DEBUG - 2022-06-23 06:48:34 --> Total execution time: 0.1142
DEBUG - 2022-06-23 06:48:41 --> Total execution time: 0.0462
DEBUG - 2022-06-23 06:48:44 --> Total execution time: 0.0803
DEBUG - 2022-06-23 06:50:20 --> Total execution time: 0.0487
DEBUG - 2022-06-23 06:51:25 --> Total execution time: 0.0312
DEBUG - 2022-06-23 06:51:37 --> Total execution time: 0.0289
DEBUG - 2022-06-23 06:51:54 --> Total execution time: 0.0417
DEBUG - 2022-06-23 06:51:58 --> Total execution time: 0.0475
DEBUG - 2022-06-23 06:52:06 --> Total execution time: 0.0546
DEBUG - 2022-06-23 06:52:10 --> Total execution time: 0.0541
DEBUG - 2022-06-23 06:52:15 --> Total execution time: 0.0446
DEBUG - 2022-06-23 06:52:30 --> Total execution time: 0.0431
DEBUG - 2022-06-23 06:53:23 --> Total execution time: 0.0455
DEBUG - 2022-06-23 07:02:44 --> Total execution time: 0.0495
DEBUG - 2022-06-23 07:02:51 --> Total execution time: 0.0578
DEBUG - 2022-06-23 07:03:00 --> Total execution time: 0.0555
DEBUG - 2022-06-23 07:03:08 --> Total execution time: 0.0770
DEBUG - 2022-06-23 07:03:12 --> Total execution time: 0.0529
DEBUG - 2022-06-23 07:03:15 --> Total execution time: 0.0519
DEBUG - 2022-06-23 07:05:19 --> Total execution time: 0.0472
DEBUG - 2022-06-23 07:07:28 --> Total execution time: 0.0794
DEBUG - 2022-06-23 07:07:36 --> Total execution time: 0.0858
DEBUG - 2022-06-23 07:07:55 --> Total execution time: 0.0858
DEBUG - 2022-06-23 07:08:41 --> Total execution time: 0.0340
DEBUG - 2022-06-23 07:08:42 --> Total execution time: 0.0411
DEBUG - 2022-06-23 07:08:44 --> Total execution time: 0.0409
DEBUG - 2022-06-23 07:17:41 --> Total execution time: 0.0688
DEBUG - 2022-06-23 07:17:49 --> Total execution time: 0.0669
DEBUG - 2022-06-23 07:18:03 --> Total execution time: 0.0844
DEBUG - 2022-06-23 07:18:06 --> Total execution time: 0.0686
DEBUG - 2022-06-23 07:18:10 --> Total execution time: 0.0521
DEBUG - 2022-06-23 07:18:20 --> Total execution time: 0.0426
DEBUG - 2022-06-23 07:30:03 --> Total execution time: 0.1828
DEBUG - 2022-06-23 07:30:07 --> Total execution time: 0.0858
DEBUG - 2022-06-23 07:30:13 --> Total execution time: 0.0396
DEBUG - 2022-06-23 07:30:41 --> Total execution time: 0.0570
DEBUG - 2022-06-23 07:30:59 --> Total execution time: 0.0517
DEBUG - 2022-06-23 07:31:12 --> Total execution time: 0.0705
DEBUG - 2022-06-23 07:31:23 --> Total execution time: 0.0399
DEBUG - 2022-06-23 07:31:24 --> Total execution time: 0.0480
DEBUG - 2022-06-23 07:31:31 --> Total execution time: 0.0588
DEBUG - 2022-06-23 07:33:33 --> Total execution time: 1.8832
DEBUG - 2022-06-23 07:34:12 --> Total execution time: 1.4796
DEBUG - 2022-06-23 07:34:16 --> Total execution time: 0.0637
DEBUG - 2022-06-23 07:34:19 --> Total execution time: 0.0326
DEBUG - 2022-06-23 07:34:20 --> Total execution time: 1.5296
DEBUG - 2022-06-23 07:34:27 --> Total execution time: 0.0404
DEBUG - 2022-06-23 07:34:35 --> Total execution time: 1.4850
DEBUG - 2022-06-23 07:34:41 --> Total execution time: 0.0443
DEBUG - 2022-06-23 07:34:43 --> Total execution time: 0.0488
DEBUG - 2022-06-23 07:34:47 --> Total execution time: 0.0479
DEBUG - 2022-06-23 07:35:07 --> Total execution time: 0.0497
DEBUG - 2022-06-23 07:35:20 --> Total execution time: 0.0530
DEBUG - 2022-06-23 07:35:30 --> Total execution time: 0.0518
DEBUG - 2022-06-23 07:35:52 --> Total execution time: 0.0513
DEBUG - 2022-06-23 07:36:01 --> Total execution time: 0.0594
DEBUG - 2022-06-23 07:36:12 --> Total execution time: 0.0321
DEBUG - 2022-06-23 07:36:13 --> Total execution time: 0.0517
DEBUG - 2022-06-23 07:36:18 --> Total execution time: 0.0704
DEBUG - 2022-06-23 07:36:24 --> Total execution time: 0.0457
DEBUG - 2022-06-23 07:36:32 --> Total execution time: 0.0544
DEBUG - 2022-06-23 07:36:36 --> Total execution time: 0.0389
DEBUG - 2022-06-23 07:36:37 --> Total execution time: 0.0395
DEBUG - 2022-06-23 07:36:54 --> Total execution time: 0.0460
DEBUG - 2022-06-23 07:37:12 --> Total execution time: 0.0976
DEBUG - 2022-06-23 07:38:53 --> Total execution time: 0.0556
DEBUG - 2022-06-23 07:39:07 --> Total execution time: 0.0508
DEBUG - 2022-06-23 07:39:11 --> Total execution time: 0.0450
DEBUG - 2022-06-23 07:41:17 --> Total execution time: 0.1656
DEBUG - 2022-06-23 07:41:21 --> Total execution time: 0.0606
DEBUG - 2022-06-23 07:41:27 --> Total execution time: 0.0428
DEBUG - 2022-06-23 07:41:51 --> Total execution time: 0.0449
DEBUG - 2022-06-23 07:43:30 --> Total execution time: 0.1205
DEBUG - 2022-06-23 07:44:06 --> Total execution time: 0.0411
DEBUG - 2022-06-23 07:44:18 --> Total execution time: 0.0556
DEBUG - 2022-06-23 07:44:47 --> Total execution time: 0.0492
DEBUG - 2022-06-23 07:45:05 --> Total execution time: 0.0467
DEBUG - 2022-06-23 07:45:14 --> Total execution time: 0.0469
DEBUG - 2022-06-23 07:45:22 --> Total execution time: 0.0499
DEBUG - 2022-06-23 07:45:22 --> Total execution time: 0.0653
DEBUG - 2022-06-23 07:45:57 --> Total execution time: 0.0765
DEBUG - 2022-06-23 07:49:32 --> Total execution time: 0.0795
DEBUG - 2022-06-23 07:52:13 --> Total execution time: 0.0933
DEBUG - 2022-06-23 07:52:28 --> Total execution time: 0.0452
DEBUG - 2022-06-23 07:53:31 --> Total execution time: 0.0471
DEBUG - 2022-06-23 07:53:44 --> Total execution time: 0.0492
DEBUG - 2022-06-23 07:54:22 --> Total execution time: 0.1008
DEBUG - 2022-06-23 07:54:29 --> Total execution time: 0.0434
DEBUG - 2022-06-23 07:54:29 --> Total execution time: 0.0525
DEBUG - 2022-06-23 07:55:09 --> Total execution time: 0.0458
DEBUG - 2022-06-23 07:55:23 --> Total execution time: 0.0618
DEBUG - 2022-06-23 07:55:31 --> Total execution time: 0.0604
DEBUG - 2022-06-23 07:55:59 --> Total execution time: 0.0504
DEBUG - 2022-06-23 08:00:28 --> Total execution time: 0.1066
DEBUG - 2022-06-23 08:00:32 --> Total execution time: 0.0422
DEBUG - 2022-06-23 08:01:02 --> Total execution time: 0.0699
DEBUG - 2022-06-23 08:01:22 --> Total execution time: 0.0507
DEBUG - 2022-06-23 08:01:30 --> Total execution time: 0.0340
DEBUG - 2022-06-23 08:01:30 --> Total execution time: 0.0312
DEBUG - 2022-06-23 08:01:31 --> Total execution time: 0.0490
DEBUG - 2022-06-23 08:02:00 --> Total execution time: 0.0486
DEBUG - 2022-06-23 08:02:15 --> Total execution time: 0.0457
DEBUG - 2022-06-23 08:03:00 --> Total execution time: 0.1228
DEBUG - 2022-06-23 08:05:23 --> Total execution time: 0.0383
DEBUG - 2022-06-23 08:07:51 --> Total execution time: 0.0436
DEBUG - 2022-06-23 08:13:48 --> Total execution time: 0.0964
DEBUG - 2022-06-23 08:15:22 --> Total execution time: 0.0459
DEBUG - 2022-06-23 08:15:24 --> Total execution time: 0.0438
DEBUG - 2022-06-23 08:15:25 --> Total execution time: 0.0762
DEBUG - 2022-06-23 08:15:32 --> Total execution time: 0.1331
DEBUG - 2022-06-23 08:15:44 --> Total execution time: 0.0568
DEBUG - 2022-06-23 08:15:59 --> Total execution time: 0.0264
DEBUG - 2022-06-23 08:16:01 --> Total execution time: 0.0526
DEBUG - 2022-06-23 08:16:06 --> Total execution time: 0.0509
DEBUG - 2022-06-23 08:16:17 --> Total execution time: 0.0409
DEBUG - 2022-06-23 08:16:41 --> Total execution time: 0.1005
DEBUG - 2022-06-23 08:16:47 --> Total execution time: 0.0496
DEBUG - 2022-06-23 08:16:58 --> Total execution time: 0.0640
DEBUG - 2022-06-23 08:17:06 --> Total execution time: 0.0506
DEBUG - 2022-06-23 08:17:09 --> Total execution time: 0.0469
DEBUG - 2022-06-23 08:17:10 --> Total execution time: 0.0881
DEBUG - 2022-06-23 08:17:13 --> Total execution time: 0.0638
DEBUG - 2022-06-23 08:17:20 --> Total execution time: 0.0460
DEBUG - 2022-06-23 08:17:23 --> Total execution time: 0.0439
DEBUG - 2022-06-23 08:17:23 --> Total execution time: 0.0432
DEBUG - 2022-06-23 08:17:24 --> Total execution time: 0.0700
DEBUG - 2022-06-23 08:17:26 --> Total execution time: 0.0539
DEBUG - 2022-06-23 08:18:16 --> Total execution time: 0.0370
DEBUG - 2022-06-23 08:18:20 --> Total execution time: 0.0311
DEBUG - 2022-06-23 08:18:35 --> Total execution time: 0.0502
DEBUG - 2022-06-23 08:18:38 --> Total execution time: 0.0719
DEBUG - 2022-06-23 08:18:38 --> Total execution time: 0.0851
DEBUG - 2022-06-23 08:18:58 --> Total execution time: 0.0473
DEBUG - 2022-06-23 08:19:05 --> Total execution time: 0.0903
DEBUG - 2022-06-23 08:19:38 --> Total execution time: 0.0486
DEBUG - 2022-06-23 08:19:45 --> Total execution time: 0.0450
DEBUG - 2022-06-23 08:19:49 --> Total execution time: 0.0498
DEBUG - 2022-06-23 08:25:42 --> Total execution time: 0.0462
DEBUG - 2022-06-23 08:26:42 --> Total execution time: 0.0469
DEBUG - 2022-06-23 08:26:46 --> Total execution time: 0.0458
DEBUG - 2022-06-23 08:26:55 --> Total execution time: 0.0683
DEBUG - 2022-06-23 08:27:02 --> Total execution time: 0.0546
DEBUG - 2022-06-23 08:27:13 --> Total execution time: 0.0575
DEBUG - 2022-06-23 08:27:27 --> Total execution time: 0.0581
DEBUG - 2022-06-23 08:27:38 --> Total execution time: 0.0421
DEBUG - 2022-06-23 08:27:39 --> Total execution time: 0.0451
DEBUG - 2022-06-23 08:27:42 --> Total execution time: 0.0533
DEBUG - 2022-06-23 08:27:44 --> Total execution time: 0.0493
DEBUG - 2022-06-23 08:28:03 --> Total execution time: 0.0957
DEBUG - 2022-06-23 08:28:21 --> Total execution time: 0.0706
DEBUG - 2022-06-23 08:28:25 --> Total execution time: 0.0471
DEBUG - 2022-06-23 08:28:29 --> Total execution time: 0.0479
DEBUG - 2022-06-23 08:28:33 --> Total execution time: 0.0631
DEBUG - 2022-06-23 08:28:59 --> Total execution time: 0.0623
DEBUG - 2022-06-23 08:30:02 --> Total execution time: 0.0576
DEBUG - 2022-06-23 08:30:15 --> Total execution time: 0.0325
DEBUG - 2022-06-23 08:30:16 --> Total execution time: 0.0368
DEBUG - 2022-06-23 08:30:22 --> Total execution time: 0.0326
DEBUG - 2022-06-23 08:30:32 --> Total execution time: 0.0494
DEBUG - 2022-06-23 08:30:37 --> Total execution time: 0.0730
DEBUG - 2022-06-23 08:31:50 --> Total execution time: 0.0741
DEBUG - 2022-06-23 08:32:02 --> Total execution time: 0.0731
DEBUG - 2022-06-23 08:32:10 --> Total execution time: 0.0745
DEBUG - 2022-06-23 08:32:20 --> Total execution time: 0.0484
DEBUG - 2022-06-23 08:32:30 --> Total execution time: 0.0496
DEBUG - 2022-06-23 08:32:44 --> Total execution time: 0.0906
DEBUG - 2022-06-23 08:33:04 --> Total execution time: 0.0629
DEBUG - 2022-06-23 08:34:23 --> Total execution time: 0.0372
DEBUG - 2022-06-23 08:34:23 --> Total execution time: 0.0919
DEBUG - 2022-06-23 08:34:28 --> Total execution time: 0.0535
DEBUG - 2022-06-23 08:34:49 --> Total execution time: 0.0489
DEBUG - 2022-06-23 08:34:50 --> Total execution time: 0.0773
DEBUG - 2022-06-23 08:39:01 --> Total execution time: 0.2569
DEBUG - 2022-06-23 08:39:38 --> Total execution time: 0.1274
DEBUG - 2022-06-23 08:44:21 --> Total execution time: 0.0901
DEBUG - 2022-06-23 08:45:24 --> Total execution time: 0.0412
DEBUG - 2022-06-23 08:45:47 --> Total execution time: 0.0464
DEBUG - 2022-06-23 08:45:53 --> Total execution time: 0.0643
DEBUG - 2022-06-23 08:49:50 --> Total execution time: 0.0858
DEBUG - 2022-06-23 08:51:08 --> Total execution time: 0.0544
DEBUG - 2022-06-23 08:51:22 --> Total execution time: 0.0468
DEBUG - 2022-06-23 08:52:14 --> Total execution time: 0.0568
DEBUG - 2022-06-23 08:52:20 --> Total execution time: 0.0522
DEBUG - 2022-06-23 08:52:46 --> Total execution time: 0.0426
DEBUG - 2022-06-23 08:53:19 --> Total execution time: 0.0551
DEBUG - 2022-06-23 08:53:23 --> Total execution time: 0.0540
DEBUG - 2022-06-23 08:53:28 --> Total execution time: 0.0689
DEBUG - 2022-06-23 08:53:37 --> Total execution time: 0.0586
DEBUG - 2022-06-23 08:53:39 --> Total execution time: 0.0324
DEBUG - 2022-06-23 08:55:03 --> Total execution time: 0.0309
DEBUG - 2022-06-23 08:55:04 --> Total execution time: 0.0330
DEBUG - 2022-06-23 08:55:07 --> Total execution time: 0.0961
DEBUG - 2022-06-23 08:55:12 --> Total execution time: 0.0472
DEBUG - 2022-06-23 08:55:20 --> Total execution time: 0.0544
DEBUG - 2022-06-23 08:55:24 --> Total execution time: 0.0720
DEBUG - 2022-06-23 08:55:32 --> Total execution time: 0.0674
DEBUG - 2022-06-23 08:55:41 --> Total execution time: 0.0581
DEBUG - 2022-06-23 08:57:45 --> Total execution time: 0.0816
DEBUG - 2022-06-23 08:57:53 --> Total execution time: 0.0471
DEBUG - 2022-06-23 08:57:57 --> Total execution time: 0.0293
DEBUG - 2022-06-23 08:58:05 --> Total execution time: 0.0287
DEBUG - 2022-06-23 08:58:07 --> Total execution time: 0.0442
DEBUG - 2022-06-23 08:58:12 --> Total execution time: 0.0525
DEBUG - 2022-06-23 08:58:19 --> Total execution time: 0.0521
DEBUG - 2022-06-23 08:58:36 --> Total execution time: 0.0425
DEBUG - 2022-06-23 08:58:51 --> Total execution time: 0.0482
DEBUG - 2022-06-23 08:59:02 --> Total execution time: 0.0686
DEBUG - 2022-06-23 08:59:08 --> Total execution time: 0.0487
DEBUG - 2022-06-23 08:59:13 --> Total execution time: 0.0447
DEBUG - 2022-06-23 08:59:50 --> Total execution time: 0.0301
DEBUG - 2022-06-23 08:59:54 --> Total execution time: 0.0407
DEBUG - 2022-06-23 08:59:55 --> Total execution time: 0.0422
DEBUG - 2022-06-23 09:01:47 --> Total execution time: 0.0716
DEBUG - 2022-06-23 09:01:55 --> Total execution time: 0.0471
DEBUG - 2022-06-23 09:04:35 --> Total execution time: 0.0956
DEBUG - 2022-06-23 09:04:42 --> Total execution time: 0.0497
DEBUG - 2022-06-23 09:05:39 --> Total execution time: 0.0663
DEBUG - 2022-06-23 09:06:19 --> Total execution time: 0.0856
DEBUG - 2022-06-23 09:06:33 --> Total execution time: 0.0512
DEBUG - 2022-06-23 09:07:20 --> Total execution time: 0.1048
DEBUG - 2022-06-23 09:07:56 --> Total execution time: 0.0378
DEBUG - 2022-06-23 09:08:02 --> Total execution time: 0.0345
DEBUG - 2022-06-23 09:08:14 --> Total execution time: 0.0463
DEBUG - 2022-06-23 09:10:08 --> Total execution time: 0.0600
DEBUG - 2022-06-23 09:10:16 --> Total execution time: 0.0482
DEBUG - 2022-06-23 09:10:51 --> Total execution time: 0.0743
DEBUG - 2022-06-23 09:11:39 --> Total execution time: 0.0540
DEBUG - 2022-06-23 09:11:40 --> Total execution time: 0.0573
DEBUG - 2022-06-23 09:11:42 --> Total execution time: 0.0367
DEBUG - 2022-06-23 09:11:44 --> Total execution time: 0.0386
DEBUG - 2022-06-23 09:11:45 --> Total execution time: 0.0308
DEBUG - 2022-06-23 09:12:19 --> Total execution time: 0.1083
DEBUG - 2022-06-23 09:15:13 --> Total execution time: 0.1092
DEBUG - 2022-06-23 09:15:22 --> Total execution time: 0.0439
DEBUG - 2022-06-23 09:15:52 --> Total execution time: 0.0395
DEBUG - 2022-06-23 09:18:03 --> Total execution time: 0.1767
DEBUG - 2022-06-23 09:19:46 --> Total execution time: 0.0590
DEBUG - 2022-06-23 09:22:01 --> Total execution time: 0.0591
DEBUG - 2022-06-23 09:22:31 --> Total execution time: 0.1376
DEBUG - 2022-06-23 09:23:26 --> Total execution time: 0.0566
DEBUG - 2022-06-23 09:23:34 --> Total execution time: 0.0455
DEBUG - 2022-06-23 09:23:44 --> Total execution time: 0.0437
DEBUG - 2022-06-23 09:25:48 --> Total execution time: 0.1576
DEBUG - 2022-06-23 09:30:02 --> Total execution time: 0.1276
DEBUG - 2022-06-23 09:31:46 --> Total execution time: 0.1346
DEBUG - 2022-06-23 09:31:51 --> Total execution time: 0.0618
DEBUG - 2022-06-23 09:31:54 --> Total execution time: 0.1180
DEBUG - 2022-06-23 09:31:54 --> Total execution time: 0.0493
DEBUG - 2022-06-23 09:41:47 --> Total execution time: 0.1105
DEBUG - 2022-06-23 09:41:53 --> Total execution time: 0.0538
DEBUG - 2022-06-23 09:42:00 --> Total execution time: 0.0681
DEBUG - 2022-06-23 09:42:17 --> Total execution time: 0.0607
DEBUG - 2022-06-23 09:42:20 --> Total execution time: 0.0575
DEBUG - 2022-06-23 09:42:35 --> Total execution time: 0.0438
DEBUG - 2022-06-23 09:53:25 --> Total execution time: 0.2996
DEBUG - 2022-06-23 09:53:39 --> Total execution time: 0.0715
DEBUG - 2022-06-23 09:54:22 --> Total execution time: 0.0419
DEBUG - 2022-06-23 09:54:38 --> Total execution time: 0.0663
DEBUG - 2022-06-23 09:55:34 --> Total execution time: 0.0433
DEBUG - 2022-06-23 09:55:35 --> Total execution time: 0.0462
DEBUG - 2022-06-23 09:56:21 --> Total execution time: 0.1312
DEBUG - 2022-06-23 09:56:24 --> Total execution time: 0.0775
DEBUG - 2022-06-23 09:56:27 --> Total execution time: 0.0513
DEBUG - 2022-06-23 09:56:31 --> Total execution time: 0.0658
DEBUG - 2022-06-23 10:01:46 --> Total execution time: 0.0854
DEBUG - 2022-06-23 10:01:49 --> Total execution time: 0.0314
DEBUG - 2022-06-23 10:01:58 --> Total execution time: 0.0668
DEBUG - 2022-06-23 10:02:02 --> Total execution time: 0.1057
DEBUG - 2022-06-23 10:02:28 --> Total execution time: 0.0451
DEBUG - 2022-06-23 10:02:31 --> Total execution time: 0.0519
DEBUG - 2022-06-23 10:02:31 --> Total execution time: 0.0427
DEBUG - 2022-06-23 10:02:37 --> Total execution time: 0.0513
DEBUG - 2022-06-23 10:02:39 --> Total execution time: 0.1293
DEBUG - 2022-06-23 10:02:43 --> Total execution time: 0.0591
DEBUG - 2022-06-23 10:02:49 --> Total execution time: 0.0358
DEBUG - 2022-06-23 10:04:18 --> Total execution time: 0.0488
DEBUG - 2022-06-23 10:08:40 --> Total execution time: 0.1635
DEBUG - 2022-06-23 10:11:08 --> Total execution time: 0.0941
DEBUG - 2022-06-23 10:11:14 --> Total execution time: 0.0454
DEBUG - 2022-06-23 10:11:23 --> Total execution time: 0.0523
DEBUG - 2022-06-23 10:11:32 --> Total execution time: 0.0554
DEBUG - 2022-06-23 10:11:35 --> Total execution time: 0.0614
DEBUG - 2022-06-23 10:12:58 --> Total execution time: 0.0485
DEBUG - 2022-06-23 10:13:15 --> Total execution time: 0.0576
DEBUG - 2022-06-23 10:13:17 --> Total execution time: 0.0635
DEBUG - 2022-06-23 10:13:20 --> Total execution time: 0.0439
DEBUG - 2022-06-23 10:13:22 --> Total execution time: 0.0536
DEBUG - 2022-06-23 10:13:26 --> Total execution time: 0.0406
DEBUG - 2022-06-23 10:14:52 --> Total execution time: 0.0567
DEBUG - 2022-06-23 10:15:00 --> Total execution time: 0.1115
DEBUG - 2022-06-23 10:15:16 --> Total execution time: 0.0586
DEBUG - 2022-06-23 10:16:15 --> Total execution time: 0.0326
DEBUG - 2022-06-23 10:16:22 --> Total execution time: 0.0604
DEBUG - 2022-06-23 10:16:27 --> Total execution time: 0.1276
DEBUG - 2022-06-23 10:16:43 --> Total execution time: 0.0537
DEBUG - 2022-06-23 10:16:50 --> Total execution time: 0.1474
DEBUG - 2022-06-23 10:17:11 --> Total execution time: 0.0483
DEBUG - 2022-06-23 10:18:38 --> Total execution time: 0.1705
DEBUG - 2022-06-23 10:18:38 --> Total execution time: 0.0511
DEBUG - 2022-06-23 10:18:43 --> Total execution time: 0.0706
DEBUG - 2022-06-23 10:18:53 --> Total execution time: 0.0726
DEBUG - 2022-06-23 10:19:35 --> Total execution time: 0.0428
DEBUG - 2022-06-23 10:19:40 --> Total execution time: 0.0418
DEBUG - 2022-06-23 10:21:50 --> Total execution time: 0.1504
DEBUG - 2022-06-23 10:21:53 --> Total execution time: 0.1147
DEBUG - 2022-06-23 10:21:55 --> Total execution time: 0.0582
DEBUG - 2022-06-23 10:22:14 --> Total execution time: 0.0505
DEBUG - 2022-06-23 10:22:43 --> Total execution time: 0.0759
DEBUG - 2022-06-23 10:23:26 --> Total execution time: 0.0643
DEBUG - 2022-06-23 10:24:23 --> Total execution time: 0.0546
DEBUG - 2022-06-23 10:24:35 --> Total execution time: 0.0554
DEBUG - 2022-06-23 10:24:44 --> Total execution time: 0.0503
DEBUG - 2022-06-23 10:24:49 --> Total execution time: 0.0450
DEBUG - 2022-06-23 10:25:00 --> Total execution time: 0.0767
DEBUG - 2022-06-23 10:25:24 --> Total execution time: 0.0475
DEBUG - 2022-06-23 10:25:27 --> Total execution time: 0.0552
DEBUG - 2022-06-23 10:25:35 --> Total execution time: 0.0801
DEBUG - 2022-06-23 10:25:43 --> Total execution time: 0.0717
DEBUG - 2022-06-23 10:25:45 --> Total execution time: 0.0492
DEBUG - 2022-06-23 10:25:50 --> Total execution time: 0.0414
DEBUG - 2022-06-23 10:26:05 --> Total execution time: 0.0538
DEBUG - 2022-06-23 10:26:09 --> Total execution time: 0.0512
DEBUG - 2022-06-23 10:26:21 --> Total execution time: 0.0430
DEBUG - 2022-06-23 10:26:29 --> Total execution time: 0.0571
DEBUG - 2022-06-23 10:26:46 --> Total execution time: 0.0835
DEBUG - 2022-06-23 10:26:58 --> Total execution time: 0.1178
DEBUG - 2022-06-23 10:27:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:27:45 --> Total execution time: 0.0561
DEBUG - 2022-06-23 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:30:03 --> Total execution time: 0.1126
DEBUG - 2022-06-23 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 00:00:15 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 00:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:00:52 --> Total execution time: 0.0514
DEBUG - 2022-06-23 00:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:00:57 --> Total execution time: 0.1045
DEBUG - 2022-06-23 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:31:41 --> Total execution time: 0.1371
DEBUG - 2022-06-23 00:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:31:53 --> Total execution time: 0.0821
DEBUG - 2022-06-23 00:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:32:23 --> Total execution time: 0.0772
DEBUG - 2022-06-23 00:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:34:04 --> Total execution time: 0.1032
DEBUG - 2022-06-23 00:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:34:13 --> Total execution time: 0.0599
DEBUG - 2022-06-23 00:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:34:47 --> Total execution time: 0.0647
DEBUG - 2022-06-23 00:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:34:54 --> Total execution time: 0.0720
DEBUG - 2022-06-23 00:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:35:12 --> Total execution time: 0.0537
DEBUG - 2022-06-23 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:35:20 --> Total execution time: 0.0577
DEBUG - 2022-06-23 00:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:35:52 --> Total execution time: 0.0422
DEBUG - 2022-06-23 00:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:07:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:37:59 --> Total execution time: 0.1227
DEBUG - 2022-06-23 00:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:02 --> Total execution time: 0.0581
DEBUG - 2022-06-23 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:11 --> Total execution time: 0.0550
DEBUG - 2022-06-23 00:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:12 --> Total execution time: 0.0525
DEBUG - 2022-06-23 00:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:28 --> Total execution time: 0.0687
DEBUG - 2022-06-23 00:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:08:37 --> Total execution time: 0.0481
DEBUG - 2022-06-23 00:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:08:38 --> Total execution time: 0.0435
DEBUG - 2022-06-23 00:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:08:38 --> Total execution time: 0.1631
DEBUG - 2022-06-23 00:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:39:30 --> Total execution time: 0.1452
DEBUG - 2022-06-23 00:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:39:44 --> Total execution time: 0.0642
DEBUG - 2022-06-23 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:03 --> Total execution time: 0.0561
DEBUG - 2022-06-23 00:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:36 --> Total execution time: 0.0532
DEBUG - 2022-06-23 00:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:40 --> Total execution time: 0.0540
DEBUG - 2022-06-23 00:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:42 --> Total execution time: 0.0528
DEBUG - 2022-06-23 00:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:42 --> Total execution time: 0.0720
DEBUG - 2022-06-23 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:44 --> Total execution time: 0.0423
DEBUG - 2022-06-23 00:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:48 --> Total execution time: 0.0390
DEBUG - 2022-06-23 00:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:10:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:52 --> Total execution time: 0.0505
DEBUG - 2022-06-23 00:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:11:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:04 --> Total execution time: 0.0335
DEBUG - 2022-06-23 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:09 --> Total execution time: 0.0413
DEBUG - 2022-06-23 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:30 --> Total execution time: 0.0554
DEBUG - 2022-06-23 00:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:53 --> Total execution time: 0.0498
DEBUG - 2022-06-23 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:42:04 --> Total execution time: 0.0532
DEBUG - 2022-06-23 00:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:10 --> Total execution time: 0.0578
DEBUG - 2022-06-23 00:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:11 --> Total execution time: 0.0460
DEBUG - 2022-06-23 00:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:11 --> Total execution time: 0.0421
DEBUG - 2022-06-23 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:17 --> Total execution time: 0.0713
DEBUG - 2022-06-23 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:18 --> Total execution time: 0.0465
DEBUG - 2022-06-23 00:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:18 --> Total execution time: 0.0731
DEBUG - 2022-06-23 00:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:43 --> Total execution time: 0.0425
DEBUG - 2022-06-23 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:44 --> Total execution time: 0.0768
DEBUG - 2022-06-23 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:44 --> Total execution time: 0.0421
DEBUG - 2022-06-23 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:42:48 --> Total execution time: 0.0472
DEBUG - 2022-06-23 00:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:06 --> Total execution time: 0.1057
DEBUG - 2022-06-23 00:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:42 --> Total execution time: 0.0431
DEBUG - 2022-06-23 00:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:08 --> Total execution time: 0.0411
DEBUG - 2022-06-23 00:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:12 --> Total execution time: 0.0321
DEBUG - 2022-06-23 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:19 --> Total execution time: 0.0631
DEBUG - 2022-06-23 00:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:23 --> Total execution time: 0.0494
DEBUG - 2022-06-23 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:29 --> Total execution time: 0.0416
DEBUG - 2022-06-23 00:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:42 --> Total execution time: 0.0707
DEBUG - 2022-06-23 00:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:45 --> Total execution time: 0.0779
DEBUG - 2022-06-23 00:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:54 --> Total execution time: 0.0522
DEBUG - 2022-06-23 00:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:58 --> Total execution time: 0.0502
DEBUG - 2022-06-23 00:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:06 --> Total execution time: 0.0723
DEBUG - 2022-06-23 00:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:07 --> Total execution time: 0.0934
DEBUG - 2022-06-23 00:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:15 --> Total execution time: 0.0370
DEBUG - 2022-06-23 00:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:17 --> Total execution time: 0.0700
DEBUG - 2022-06-23 00:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:29 --> Total execution time: 0.0296
DEBUG - 2022-06-23 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:35 --> Total execution time: 0.0499
DEBUG - 2022-06-23 00:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:38 --> Total execution time: 0.0536
DEBUG - 2022-06-23 00:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 00:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:39 --> Total execution time: 0.0587
DEBUG - 2022-06-23 00:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:41 --> Total execution time: 0.0607
DEBUG - 2022-06-23 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:44 --> Total execution time: 0.0541
DEBUG - 2022-06-23 00:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:15:45 --> Total execution time: 0.0330
DEBUG - 2022-06-23 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:45 --> Total execution time: 0.0430
DEBUG - 2022-06-23 00:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:51 --> Total execution time: 0.0738
DEBUG - 2022-06-23 00:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:52 --> Total execution time: 0.0422
DEBUG - 2022-06-23 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:53 --> Total execution time: 0.0366
DEBUG - 2022-06-23 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 00:15:53 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-23 00:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:54 --> Total execution time: 0.0721
DEBUG - 2022-06-23 00:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:58 --> Total execution time: 0.0739
DEBUG - 2022-06-23 00:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:06 --> Total execution time: 0.0685
DEBUG - 2022-06-23 00:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:07 --> Total execution time: 0.0518
DEBUG - 2022-06-23 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:07 --> Total execution time: 0.0522
DEBUG - 2022-06-23 00:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:10 --> Total execution time: 0.0753
DEBUG - 2022-06-23 00:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:11 --> Total execution time: 0.0539
DEBUG - 2022-06-23 00:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:15 --> Total execution time: 0.0444
DEBUG - 2022-06-23 00:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:15 --> Total execution time: 0.0478
DEBUG - 2022-06-23 00:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:18 --> Total execution time: 0.0482
DEBUG - 2022-06-23 00:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:19 --> Total execution time: 0.0554
DEBUG - 2022-06-23 00:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:24 --> Total execution time: 0.0422
DEBUG - 2022-06-23 00:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:26 --> Total execution time: 0.0522
DEBUG - 2022-06-23 00:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:31 --> Total execution time: 0.0649
DEBUG - 2022-06-23 00:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:32 --> Total execution time: 0.0516
DEBUG - 2022-06-23 00:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:32 --> Total execution time: 0.0507
DEBUG - 2022-06-23 00:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:33 --> Total execution time: 0.0495
DEBUG - 2022-06-23 00:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:34 --> Total execution time: 0.0463
DEBUG - 2022-06-23 00:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:38 --> Total execution time: 0.0489
DEBUG - 2022-06-23 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:49 --> Total execution time: 0.0617
DEBUG - 2022-06-23 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:51 --> Total execution time: 0.0682
DEBUG - 2022-06-23 00:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:54 --> Total execution time: 0.0563
DEBUG - 2022-06-23 00:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:05 --> Total execution time: 0.0451
DEBUG - 2022-06-23 00:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:17 --> Total execution time: 0.0790
DEBUG - 2022-06-23 00:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:22 --> Total execution time: 0.0618
DEBUG - 2022-06-23 00:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:22 --> Total execution time: 0.0684
DEBUG - 2022-06-23 00:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:38 --> Total execution time: 0.0629
DEBUG - 2022-06-23 00:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:24 --> Total execution time: 0.0496
DEBUG - 2022-06-23 00:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:32 --> Total execution time: 0.0446
DEBUG - 2022-06-23 00:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:07 --> Total execution time: 0.1054
DEBUG - 2022-06-23 00:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:19:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:37 --> Total execution time: 0.0486
DEBUG - 2022-06-23 00:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:51:22 --> Total execution time: 0.0504
DEBUG - 2022-06-23 00:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:51:24 --> Total execution time: 0.0669
DEBUG - 2022-06-23 00:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:51:50 --> Total execution time: 0.0556
DEBUG - 2022-06-23 00:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:51:55 --> Total execution time: 0.1119
DEBUG - 2022-06-23 00:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:52:00 --> Total execution time: 0.0571
DEBUG - 2022-06-23 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:52:04 --> Total execution time: 0.0449
DEBUG - 2022-06-23 00:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:53:21 --> Total execution time: 0.0507
DEBUG - 2022-06-23 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:53:59 --> Total execution time: 0.0462
DEBUG - 2022-06-23 00:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:54:02 --> Total execution time: 0.0721
DEBUG - 2022-06-23 00:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:54:18 --> Total execution time: 0.0513
DEBUG - 2022-06-23 00:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:54:25 --> Total execution time: 0.1480
DEBUG - 2022-06-23 00:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:54:28 --> Total execution time: 0.0732
DEBUG - 2022-06-23 00:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:54:29 --> Total execution time: 0.0442
DEBUG - 2022-06-23 00:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:54:31 --> Total execution time: 0.0441
DEBUG - 2022-06-23 00:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:25:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:55:02 --> Total execution time: 0.0608
DEBUG - 2022-06-23 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:55:07 --> Total execution time: 0.0602
DEBUG - 2022-06-23 00:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:56:53 --> Total execution time: 0.0666
DEBUG - 2022-06-23 00:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:57:39 --> Total execution time: 0.0739
DEBUG - 2022-06-23 00:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:27:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:57:41 --> Total execution time: 0.1335
DEBUG - 2022-06-23 00:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:57:45 --> Total execution time: 0.0571
DEBUG - 2022-06-23 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:57:53 --> Total execution time: 0.0669
DEBUG - 2022-06-23 00:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:58:28 --> Total execution time: 0.1002
DEBUG - 2022-06-23 00:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:58:46 --> Total execution time: 0.0540
DEBUG - 2022-06-23 00:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:58:53 --> Total execution time: 0.0623
DEBUG - 2022-06-23 00:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:59:04 --> Total execution time: 0.0516
DEBUG - 2022-06-23 00:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:59:15 --> Total execution time: 0.1660
DEBUG - 2022-06-23 00:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:59:24 --> Total execution time: 0.0468
DEBUG - 2022-06-23 00:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:00:17 --> Total execution time: 0.0640
DEBUG - 2022-06-23 00:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:01:36 --> Total execution time: 0.0595
DEBUG - 2022-06-23 00:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:02:04 --> Total execution time: 0.0633
DEBUG - 2022-06-23 00:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:03:54 --> Total execution time: 0.1121
DEBUG - 2022-06-23 00:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:03:59 --> Total execution time: 0.0524
DEBUG - 2022-06-23 00:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:05:17 --> Total execution time: 0.1077
DEBUG - 2022-06-23 00:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:06:18 --> Total execution time: 0.0748
DEBUG - 2022-06-23 00:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:06:34 --> Total execution time: 0.0497
DEBUG - 2022-06-23 00:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:05 --> Total execution time: 0.0571
DEBUG - 2022-06-23 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:30 --> Total execution time: 0.0691
DEBUG - 2022-06-23 00:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:37:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:45 --> Total execution time: 0.1106
DEBUG - 2022-06-23 00:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:49 --> Total execution time: 0.0643
DEBUG - 2022-06-23 00:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:50 --> Total execution time: 0.0430
DEBUG - 2022-06-23 00:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:07 --> Total execution time: 0.0574
DEBUG - 2022-06-23 00:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:13 --> Total execution time: 0.0545
DEBUG - 2022-06-23 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:20 --> Total execution time: 0.0500
DEBUG - 2022-06-23 00:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:28 --> Total execution time: 0.0540
DEBUG - 2022-06-23 00:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:32 --> Total execution time: 0.0691
DEBUG - 2022-06-23 00:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:32 --> Total execution time: 0.0644
DEBUG - 2022-06-23 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:08:42 --> Total execution time: 0.0431
DEBUG - 2022-06-23 00:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:09:55 --> Total execution time: 0.0625
DEBUG - 2022-06-23 00:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:09:55 --> Total execution time: 0.0711
DEBUG - 2022-06-23 00:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:10:08 --> Total execution time: 0.0491
DEBUG - 2022-06-23 00:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:10:09 --> Total execution time: 0.0696
DEBUG - 2022-06-23 00:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:10:17 --> Total execution time: 0.0687
DEBUG - 2022-06-23 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:10:18 --> Total execution time: 0.1273
DEBUG - 2022-06-23 00:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:10:36 --> Total execution time: 0.0550
DEBUG - 2022-06-23 00:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:11:29 --> Total execution time: 0.0842
DEBUG - 2022-06-23 00:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:11:45 --> Total execution time: 0.0486
DEBUG - 2022-06-23 00:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:11:56 --> Total execution time: 0.0631
DEBUG - 2022-06-23 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:12:09 --> Total execution time: 0.0626
DEBUG - 2022-06-23 00:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:12:45 --> Total execution time: 0.3117
DEBUG - 2022-06-23 00:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:14:23 --> Total execution time: 0.1091
DEBUG - 2022-06-23 00:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:14:34 --> Total execution time: 0.0861
DEBUG - 2022-06-23 00:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:14:58 --> Total execution time: 0.0520
DEBUG - 2022-06-23 00:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:02 --> Total execution time: 0.0684
DEBUG - 2022-06-23 00:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:07 --> Total execution time: 0.0477
DEBUG - 2022-06-23 00:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:11 --> Total execution time: 0.1130
DEBUG - 2022-06-23 00:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:36 --> Total execution time: 0.1683
DEBUG - 2022-06-23 00:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:37 --> Total execution time: 0.2871
DEBUG - 2022-06-23 00:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:53 --> Total execution time: 0.1612
DEBUG - 2022-06-23 00:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:15:59 --> Total execution time: 0.0953
DEBUG - 2022-06-23 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:16:15 --> Total execution time: 0.0887
DEBUG - 2022-06-23 00:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:16:28 --> Total execution time: 0.0553
DEBUG - 2022-06-23 00:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:16:30 --> Total execution time: 0.0661
DEBUG - 2022-06-23 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:07 --> Total execution time: 0.1523
DEBUG - 2022-06-23 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:19 --> Total execution time: 0.2181
DEBUG - 2022-06-23 00:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:28 --> Total execution time: 0.0923
DEBUG - 2022-06-23 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:34 --> Total execution time: 0.0962
DEBUG - 2022-06-23 00:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:38 --> Total execution time: 0.2281
DEBUG - 2022-06-23 00:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:57 --> Total execution time: 0.1386
DEBUG - 2022-06-23 00:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:16 --> Total execution time: 0.0757
DEBUG - 2022-06-23 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:27 --> Total execution time: 0.0485
DEBUG - 2022-06-23 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:39 --> Total execution time: 0.0889
DEBUG - 2022-06-23 00:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:44 --> Total execution time: 0.0872
DEBUG - 2022-06-23 00:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:10 --> Total execution time: 0.0611
DEBUG - 2022-06-23 00:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:21 --> Total execution time: 0.0665
DEBUG - 2022-06-23 00:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:23 --> Total execution time: 0.0620
DEBUG - 2022-06-23 00:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:25 --> Total execution time: 0.0516
DEBUG - 2022-06-23 00:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:27 --> Total execution time: 0.0640
DEBUG - 2022-06-23 00:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:32 --> Total execution time: 0.0397
DEBUG - 2022-06-23 00:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:44 --> Total execution time: 0.0355
DEBUG - 2022-06-23 00:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:49:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:47 --> Total execution time: 0.0404
DEBUG - 2022-06-23 00:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:09 --> Total execution time: 0.0680
DEBUG - 2022-06-23 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:31 --> Total execution time: 0.0508
DEBUG - 2022-06-23 00:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:31 --> Total execution time: 0.0479
DEBUG - 2022-06-23 00:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 00:51:32 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-23 00:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 00:51:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 00:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:57 --> Total execution time: 0.0451
DEBUG - 2022-06-23 00:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:20 --> Total execution time: 0.0542
DEBUG - 2022-06-23 00:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:23 --> Total execution time: 0.0469
DEBUG - 2022-06-23 00:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:25 --> Total execution time: 0.1179
DEBUG - 2022-06-23 00:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:31 --> Total execution time: 0.0593
DEBUG - 2022-06-23 00:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:41 --> Total execution time: 0.1058
DEBUG - 2022-06-23 00:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:43 --> Total execution time: 0.0402
DEBUG - 2022-06-23 00:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:52:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:59 --> Total execution time: 0.1263
DEBUG - 2022-06-23 00:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:00 --> Total execution time: 0.0617
DEBUG - 2022-06-23 00:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:02 --> Total execution time: 0.0648
DEBUG - 2022-06-23 00:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:02 --> Total execution time: 0.0462
DEBUG - 2022-06-23 00:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:07 --> Total execution time: 0.0679
DEBUG - 2022-06-23 00:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:13 --> Total execution time: 0.0582
DEBUG - 2022-06-23 00:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:16 --> Total execution time: 0.0593
DEBUG - 2022-06-23 00:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:24 --> Total execution time: 0.0504
DEBUG - 2022-06-23 00:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:29 --> Total execution time: 0.1233
DEBUG - 2022-06-23 00:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:31 --> Total execution time: 0.0504
DEBUG - 2022-06-23 00:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:34 --> Total execution time: 0.0686
DEBUG - 2022-06-23 00:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:37 --> Total execution time: 0.0817
DEBUG - 2022-06-23 00:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:38 --> Total execution time: 0.0776
DEBUG - 2022-06-23 00:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:43 --> Total execution time: 0.0424
DEBUG - 2022-06-23 00:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:49 --> Total execution time: 0.0350
DEBUG - 2022-06-23 00:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:54 --> Total execution time: 0.0458
DEBUG - 2022-06-23 00:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:59 --> Total execution time: 0.0538
DEBUG - 2022-06-23 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:08 --> Total execution time: 0.0521
DEBUG - 2022-06-23 00:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:17 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:17 --> Total execution time: 0.0494
DEBUG - 2022-06-23 00:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:54:27 --> Total execution time: 0.0510
DEBUG - 2022-06-23 00:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:54:33 --> Total execution time: 0.0537
DEBUG - 2022-06-23 00:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 00:54:33 --> Total execution time: 0.1017
DEBUG - 2022-06-23 00:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:40 --> Total execution time: 0.0606
DEBUG - 2022-06-23 00:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:43 --> Total execution time: 0.0512
DEBUG - 2022-06-23 00:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:45 --> Total execution time: 0.0492
DEBUG - 2022-06-23 00:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:55 --> Total execution time: 0.0487
DEBUG - 2022-06-23 00:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:25:15 --> Total execution time: 0.1375
DEBUG - 2022-06-23 00:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:25:50 --> Total execution time: 0.0486
DEBUG - 2022-06-23 00:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:08 --> Total execution time: 0.1276
DEBUG - 2022-06-23 00:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:20 --> Total execution time: 0.0612
DEBUG - 2022-06-23 00:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:29 --> Total execution time: 0.0493
DEBUG - 2022-06-23 00:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:32 --> Total execution time: 0.0487
DEBUG - 2022-06-23 00:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:40 --> Total execution time: 0.0571
DEBUG - 2022-06-23 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:49 --> Total execution time: 1.9158
DEBUG - 2022-06-23 00:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 00:56:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 00:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:11 --> Total execution time: 0.0472
DEBUG - 2022-06-23 00:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:12 --> Total execution time: 0.1103
DEBUG - 2022-06-23 00:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:16 --> Total execution time: 1.4789
DEBUG - 2022-06-23 00:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 00:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:30 --> Total execution time: 0.0517
DEBUG - 2022-06-23 00:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:31 --> Total execution time: 0.0556
DEBUG - 2022-06-23 00:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:35 --> Total execution time: 0.0729
DEBUG - 2022-06-23 00:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:44 --> Total execution time: 0.1328
DEBUG - 2022-06-23 00:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:54 --> Total execution time: 0.0662
DEBUG - 2022-06-23 00:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:27:55 --> Total execution time: 0.0514
DEBUG - 2022-06-23 00:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:28:01 --> Total execution time: 0.0816
DEBUG - 2022-06-23 00:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:28:06 --> Total execution time: 0.0534
DEBUG - 2022-06-23 00:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 00:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 00:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:28:11 --> Total execution time: 0.0830
DEBUG - 2022-06-23 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:30:02 --> Total execution time: 0.2059
DEBUG - 2022-06-23 01:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:14 --> Total execution time: 0.0381
DEBUG - 2022-06-23 01:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:14 --> Total execution time: 0.0393
DEBUG - 2022-06-23 01:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:14 --> Total execution time: 0.0487
DEBUG - 2022-06-23 01:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:19 --> Total execution time: 0.0569
DEBUG - 2022-06-23 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:24 --> Total execution time: 0.0319
DEBUG - 2022-06-23 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:24 --> Total execution time: 0.0691
DEBUG - 2022-06-23 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:27 --> Total execution time: 0.0595
DEBUG - 2022-06-23 01:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:40 --> Total execution time: 0.0468
DEBUG - 2022-06-23 01:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:53 --> Total execution time: 0.0518
DEBUG - 2022-06-23 01:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:58 --> Total execution time: 0.0541
DEBUG - 2022-06-23 01:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:32:04 --> Total execution time: 0.0473
DEBUG - 2022-06-23 01:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:03:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:32 --> Total execution time: 0.0344
DEBUG - 2022-06-23 01:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:34:24 --> Total execution time: 0.0619
DEBUG - 2022-06-23 01:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:34:47 --> Total execution time: 0.1231
DEBUG - 2022-06-23 01:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:05:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:35:26 --> Total execution time: 0.0365
DEBUG - 2022-06-23 01:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:36:04 --> Total execution time: 0.0492
DEBUG - 2022-06-23 01:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:36:38 --> Total execution time: 0.0494
DEBUG - 2022-06-23 01:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:07:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:37:28 --> Total execution time: 0.1041
DEBUG - 2022-06-23 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:07:40 --> Total execution time: 0.0537
DEBUG - 2022-06-23 01:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:07:42 --> Total execution time: 0.0711
DEBUG - 2022-06-23 01:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:07:42 --> Total execution time: 0.0783
DEBUG - 2022-06-23 01:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:38:19 --> Total execution time: 0.1033
DEBUG - 2022-06-23 01:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:08:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 01:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:38:46 --> Total execution time: 1.4783
DEBUG - 2022-06-23 01:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:08:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:08:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 01:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:05 --> Total execution time: 0.1867
DEBUG - 2022-06-23 01:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:05 --> Total execution time: 0.0607
DEBUG - 2022-06-23 01:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:06 --> Total execution time: 0.0893
DEBUG - 2022-06-23 01:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:06 --> Total execution time: 0.0565
DEBUG - 2022-06-23 01:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:13 --> Total execution time: 0.0557
DEBUG - 2022-06-23 01:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:56 --> Total execution time: 0.1040
DEBUG - 2022-06-23 01:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:39:59 --> Total execution time: 0.0571
DEBUG - 2022-06-23 01:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:04 --> Total execution time: 0.0706
DEBUG - 2022-06-23 01:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:07 --> Total execution time: 0.0533
DEBUG - 2022-06-23 01:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:11 --> Total execution time: 0.0507
DEBUG - 2022-06-23 01:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:13 --> Total execution time: 0.0798
DEBUG - 2022-06-23 01:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:15 --> Total execution time: 0.0569
DEBUG - 2022-06-23 01:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:31 --> Total execution time: 0.0738
DEBUG - 2022-06-23 01:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:10:44 --> 404 Page Not Found: %20ye%20asli%20hai%20ya%20nahi/index
DEBUG - 2022-06-23 01:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:10:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 01:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:10:57 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 01:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:08 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:08 --> Total execution time: 0.0995
DEBUG - 2022-06-23 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:25 --> Total execution time: 0.0491
DEBUG - 2022-06-23 01:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:27 --> Total execution time: 0.0520
DEBUG - 2022-06-23 01:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:32 --> Total execution time: 0.0651
DEBUG - 2022-06-23 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:44 --> Total execution time: 0.0513
DEBUG - 2022-06-23 01:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:49 --> Total execution time: 0.0524
DEBUG - 2022-06-23 01:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:50 --> Total execution time: 0.0368
DEBUG - 2022-06-23 01:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:59 --> Total execution time: 0.0492
DEBUG - 2022-06-23 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:08 --> Total execution time: 0.0478
DEBUG - 2022-06-23 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:08 --> Total execution time: 0.0585
DEBUG - 2022-06-23 01:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:12 --> Total execution time: 0.0839
DEBUG - 2022-06-23 01:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:24 --> Total execution time: 0.0684
DEBUG - 2022-06-23 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:35 --> Total execution time: 0.0481
DEBUG - 2022-06-23 01:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:37 --> Total execution time: 0.0559
DEBUG - 2022-06-23 01:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:41 --> Total execution time: 0.0599
DEBUG - 2022-06-23 01:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:45 --> Total execution time: 0.1014
DEBUG - 2022-06-23 01:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:42:49 --> Total execution time: 0.0564
DEBUG - 2022-06-23 01:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:43:15 --> Total execution time: 0.1208
DEBUG - 2022-06-23 01:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:13:27 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 01:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:43:28 --> Total execution time: 0.0879
DEBUG - 2022-06-23 01:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:43:33 --> Total execution time: 0.0463
DEBUG - 2022-06-23 01:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:01 --> Total execution time: 0.0773
DEBUG - 2022-06-23 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:14:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:45 --> Total execution time: 0.0381
DEBUG - 2022-06-23 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:14:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:14:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:46 --> Total execution time: 0.0411
DEBUG - 2022-06-23 11:44:46 --> Total execution time: 0.0434
DEBUG - 2022-06-23 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:46 --> Total execution time: 0.0411
DEBUG - 2022-06-23 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:46 --> Total execution time: 0.0341
DEBUG - 2022-06-23 11:44:46 --> Total execution time: 0.0340
DEBUG - 2022-06-23 01:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:47 --> Total execution time: 0.0310
DEBUG - 2022-06-23 01:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:47 --> Total execution time: 0.0448
DEBUG - 2022-06-23 01:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:14:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:44:51 --> Total execution time: 0.0434
DEBUG - 2022-06-23 01:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:15:46 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 01:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:47:47 --> Total execution time: 0.0713
DEBUG - 2022-06-23 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:48:34 --> Total execution time: 0.0588
DEBUG - 2022-06-23 01:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:48:42 --> Total execution time: 0.0783
DEBUG - 2022-06-23 01:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:48:47 --> Total execution time: 0.0702
DEBUG - 2022-06-23 01:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:14 --> Total execution time: 0.0299
DEBUG - 2022-06-23 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:24 --> Total execution time: 0.0457
DEBUG - 2022-06-23 01:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:31 --> Total execution time: 0.0848
DEBUG - 2022-06-23 01:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:38 --> Total execution time: 0.0524
DEBUG - 2022-06-23 01:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:40 --> Total execution time: 0.0487
DEBUG - 2022-06-23 01:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:40 --> Total execution time: 0.0307
DEBUG - 2022-06-23 01:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:43 --> Total execution time: 0.0361
DEBUG - 2022-06-23 01:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:47 --> Total execution time: 0.0775
DEBUG - 2022-06-23 01:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:47 --> Total execution time: 0.0741
DEBUG - 2022-06-23 01:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:54 --> Total execution time: 0.0370
DEBUG - 2022-06-23 01:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:19:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:49:59 --> Total execution time: 0.0440
DEBUG - 2022-06-23 01:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:20:07 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:50:07 --> Total execution time: 0.0350
DEBUG - 2022-06-23 01:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:20:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:50:26 --> Total execution time: 0.0483
DEBUG - 2022-06-23 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:50:39 --> Total execution time: 0.0522
DEBUG - 2022-06-23 01:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:20:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:50:42 --> Total execution time: 0.0506
DEBUG - 2022-06-23 01:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:20:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:50:43 --> Total execution time: 0.0313
DEBUG - 2022-06-23 01:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:50:58 --> Total execution time: 0.0317
DEBUG - 2022-06-23 01:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:51:05 --> Total execution time: 0.0529
DEBUG - 2022-06-23 01:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:51:15 --> Total execution time: 0.0331
DEBUG - 2022-06-23 01:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:51:24 --> Total execution time: 0.0515
DEBUG - 2022-06-23 01:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:51:40 --> Total execution time: 0.1018
DEBUG - 2022-06-23 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:51:53 --> Total execution time: 0.0546
DEBUG - 2022-06-23 01:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:51:55 --> Total execution time: 0.0560
DEBUG - 2022-06-23 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:52:00 --> Total execution time: 0.0442
DEBUG - 2022-06-23 01:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:52:14 --> Total execution time: 0.0708
DEBUG - 2022-06-23 01:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:22:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:52:46 --> Total execution time: 0.0399
DEBUG - 2022-06-23 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:52:50 --> Total execution time: 0.0475
DEBUG - 2022-06-23 01:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:53:10 --> Total execution time: 0.0483
DEBUG - 2022-06-23 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:53:13 --> Total execution time: 0.0651
DEBUG - 2022-06-23 01:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:53:16 --> Total execution time: 0.2964
DEBUG - 2022-06-23 01:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:56:19 --> Total execution time: 0.1099
DEBUG - 2022-06-23 01:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:27:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:57:56 --> Total execution time: 0.0369
DEBUG - 2022-06-23 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:59:10 --> Total execution time: 0.0439
DEBUG - 2022-06-23 01:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:02:25 --> Total execution time: 0.0989
DEBUG - 2022-06-23 01:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:05:07 --> Total execution time: 0.0449
DEBUG - 2022-06-23 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:36:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:06:42 --> Total execution time: 0.1118
DEBUG - 2022-06-23 01:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:38:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:39:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:09:54 --> Total execution time: 0.0714
DEBUG - 2022-06-23 01:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:39:57 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:09:57 --> Total execution time: 0.0362
DEBUG - 2022-06-23 01:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:40:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:10:31 --> Total execution time: 0.0399
DEBUG - 2022-06-23 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:43:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:13:56 --> Total execution time: 0.1022
DEBUG - 2022-06-23 01:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:07 --> Total execution time: 0.0522
DEBUG - 2022-06-23 01:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:11 --> Total execution time: 0.1591
DEBUG - 2022-06-23 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:19 --> Total execution time: 0.0435
DEBUG - 2022-06-23 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:20 --> Total execution time: 0.0541
DEBUG - 2022-06-23 01:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:21 --> Total execution time: 0.0657
DEBUG - 2022-06-23 01:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:35 --> Total execution time: 0.0411
DEBUG - 2022-06-23 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:35 --> Total execution time: 0.0496
DEBUG - 2022-06-23 01:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:14:41 --> Total execution time: 0.0938
DEBUG - 2022-06-23 01:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:15:23 --> Total execution time: 0.0575
DEBUG - 2022-06-23 01:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:15:25 --> Total execution time: 0.0641
DEBUG - 2022-06-23 01:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:15:25 --> Total execution time: 0.0481
DEBUG - 2022-06-23 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:15:27 --> Total execution time: 0.0612
DEBUG - 2022-06-23 01:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:45:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:15:29 --> Total execution time: 0.0445
DEBUG - 2022-06-23 01:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:46:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:16:39 --> Total execution time: 0.2601
DEBUG - 2022-06-23 01:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:46:55 --> Total execution time: 0.1095
DEBUG - 2022-06-23 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:46:56 --> Total execution time: 0.0925
DEBUG - 2022-06-23 01:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:46:56 --> Total execution time: 0.2009
DEBUG - 2022-06-23 01:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:46:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:16:59 --> Total execution time: 0.1132
DEBUG - 2022-06-23 01:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:01 --> Total execution time: 0.0775
DEBUG - 2022-06-23 01:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:06 --> Total execution time: 0.0520
DEBUG - 2022-06-23 01:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:10 --> Total execution time: 0.1399
DEBUG - 2022-06-23 01:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:17 --> Total execution time: 0.1021
DEBUG - 2022-06-23 01:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 01:47:22 --> 404 Page Not Found: Affiliate-lost-password/esalestrix.in
DEBUG - 2022-06-23 01:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:26 --> Total execution time: 0.0582
DEBUG - 2022-06-23 01:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:38 --> Total execution time: 0.0660
DEBUG - 2022-06-23 01:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:46 --> Total execution time: 0.0896
DEBUG - 2022-06-23 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:53 --> Total execution time: 0.0615
DEBUG - 2022-06-23 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:54 --> Total execution time: 0.1181
DEBUG - 2022-06-23 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:54 --> Total execution time: 0.1061
DEBUG - 2022-06-23 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:54 --> Total execution time: 0.0560
DEBUG - 2022-06-23 01:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:56 --> Total execution time: 0.0449
DEBUG - 2022-06-23 01:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:17:59 --> Total execution time: 0.0882
DEBUG - 2022-06-23 01:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:48:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:18:01 --> Total execution time: 0.1576
DEBUG - 2022-06-23 01:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:49:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:19:40 --> Total execution time: 0.3098
DEBUG - 2022-06-23 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:20:41 --> Total execution time: 0.0514
DEBUG - 2022-06-23 01:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:20:47 --> Total execution time: 0.1579
DEBUG - 2022-06-23 01:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:21:30 --> Total execution time: 0.0934
DEBUG - 2022-06-23 01:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:21:35 --> Total execution time: 0.2904
DEBUG - 2022-06-23 01:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:51:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:21:56 --> Total execution time: 0.1484
DEBUG - 2022-06-23 01:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:23:12 --> Total execution time: 0.1454
DEBUG - 2022-06-23 01:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:23:16 --> Total execution time: 0.0929
DEBUG - 2022-06-23 01:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:23:25 --> Total execution time: 0.0749
DEBUG - 2022-06-23 01:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:56:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:26:42 --> Total execution time: 0.0892
DEBUG - 2022-06-23 01:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:56:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 01:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:26:42 --> Total execution time: 0.0346
DEBUG - 2022-06-23 01:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:26:46 --> Total execution time: 0.0446
DEBUG - 2022-06-23 01:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:26:52 --> Total execution time: 0.0726
DEBUG - 2022-06-23 01:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:27:03 --> Total execution time: 0.0562
DEBUG - 2022-06-23 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:27:11 --> Total execution time: 0.0472
DEBUG - 2022-06-23 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:27:13 --> Total execution time: 0.0725
DEBUG - 2022-06-23 01:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:57:33 --> Total execution time: 0.0666
DEBUG - 2022-06-23 01:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:57:41 --> Total execution time: 0.0616
DEBUG - 2022-06-23 01:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 01:57:44 --> Total execution time: 0.0411
DEBUG - 2022-06-23 01:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:27:46 --> Total execution time: 0.0845
DEBUG - 2022-06-23 01:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:27:55 --> Total execution time: 0.0575
DEBUG - 2022-06-23 01:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:28:06 --> Total execution time: 0.0561
DEBUG - 2022-06-23 01:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:28:47 --> Total execution time: 0.1009
DEBUG - 2022-06-23 01:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:29:34 --> Total execution time: 0.0629
DEBUG - 2022-06-23 01:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:29:44 --> Total execution time: 0.0983
DEBUG - 2022-06-23 01:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 01:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 01:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:29:53 --> Total execution time: 0.0623
DEBUG - 2022-06-23 02:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:30:25 --> Total execution time: 0.1102
DEBUG - 2022-06-23 02:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:30:26 --> Total execution time: 0.1706
DEBUG - 2022-06-23 02:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:03:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:33:50 --> Total execution time: 0.1431
DEBUG - 2022-06-23 02:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:33:56 --> Total execution time: 0.0712
DEBUG - 2022-06-23 02:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:08 --> Total execution time: 0.0567
DEBUG - 2022-06-23 02:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:20 --> Total execution time: 0.0567
DEBUG - 2022-06-23 02:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:25 --> Total execution time: 0.0524
DEBUG - 2022-06-23 02:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:43 --> Total execution time: 0.1163
DEBUG - 2022-06-23 02:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:54 --> Total execution time: 0.0499
DEBUG - 2022-06-23 02:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:15 --> Total execution time: 0.0578
DEBUG - 2022-06-23 02:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:16 --> Total execution time: 0.0668
DEBUG - 2022-06-23 02:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:38 --> Total execution time: 0.0615
DEBUG - 2022-06-23 02:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:49 --> Total execution time: 0.0481
DEBUG - 2022-06-23 02:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:52 --> Total execution time: 0.0517
DEBUG - 2022-06-23 02:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:56 --> Total execution time: 0.0492
DEBUG - 2022-06-23 02:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:58 --> Total execution time: 0.0656
DEBUG - 2022-06-23 02:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:03 --> Total execution time: 0.0777
DEBUG - 2022-06-23 02:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:03 --> Total execution time: 0.0507
DEBUG - 2022-06-23 02:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:06 --> Total execution time: 0.0624
DEBUG - 2022-06-23 02:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:09 --> Total execution time: 0.1275
DEBUG - 2022-06-23 02:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:20 --> Total execution time: 0.0532
DEBUG - 2022-06-23 02:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:25 --> Total execution time: 0.0527
DEBUG - 2022-06-23 02:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:37:53 --> Total execution time: 0.0628
DEBUG - 2022-06-23 02:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:38:19 --> Total execution time: 0.0461
DEBUG - 2022-06-23 02:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:38:27 --> Total execution time: 0.0591
DEBUG - 2022-06-23 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:38:41 --> Total execution time: 0.0498
DEBUG - 2022-06-23 02:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:39:02 --> Total execution time: 0.0621
DEBUG - 2022-06-23 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:39:24 --> Total execution time: 0.0586
DEBUG - 2022-06-23 02:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:39:34 --> Total execution time: 0.0537
DEBUG - 2022-06-23 02:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:39:37 --> Total execution time: 0.0607
DEBUG - 2022-06-23 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:40:36 --> Total execution time: 0.0498
DEBUG - 2022-06-23 02:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:11:10 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:41:10 --> Total execution time: 0.0405
DEBUG - 2022-06-23 02:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:11:10 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:41:10 --> Total execution time: 0.0496
DEBUG - 2022-06-23 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:11:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:41:12 --> Total execution time: 0.0347
DEBUG - 2022-06-23 02:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:11:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:41:15 --> Total execution time: 0.0369
DEBUG - 2022-06-23 02:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:11:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:41:56 --> Total execution time: 0.0430
DEBUG - 2022-06-23 02:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:42:06 --> Total execution time: 0.0760
DEBUG - 2022-06-23 02:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:12:07 --> Total execution time: 0.0564
DEBUG - 2022-06-23 02:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:12:10 --> Total execution time: 0.0579
DEBUG - 2022-06-23 02:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:12:10 --> Total execution time: 0.1168
DEBUG - 2022-06-23 02:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:42:11 --> Total execution time: 0.0497
DEBUG - 2022-06-23 02:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:42:37 --> Total execution time: 0.0550
DEBUG - 2022-06-23 02:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:42:48 --> Total execution time: 0.0470
DEBUG - 2022-06-23 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:14:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 02:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:44:02 --> Total execution time: 1.8525
DEBUG - 2022-06-23 02:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 02:14:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 02:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:44:14 --> Total execution time: 0.1174
DEBUG - 2022-06-23 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:44:27 --> Total execution time: 0.0426
DEBUG - 2022-06-23 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:45:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:45:17 --> Total execution time: 0.0521
DEBUG - 2022-06-23 02:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:45:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:45:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:45:19 --> Total execution time: 0.2922
DEBUG - 2022-06-23 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:16:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:46:13 --> Total execution time: 0.0389
DEBUG - 2022-06-23 02:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:16:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:46:46 --> Total execution time: 0.0459
DEBUG - 2022-06-23 02:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:47:45 --> Total execution time: 0.0495
DEBUG - 2022-06-23 02:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:58:17 --> Total execution time: 0.3634
DEBUG - 2022-06-23 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:58:25 --> Total execution time: 0.0582
DEBUG - 2022-06-23 02:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:58:27 --> Total execution time: 0.0619
DEBUG - 2022-06-23 02:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:58:32 --> Total execution time: 0.0487
DEBUG - 2022-06-23 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:10 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:10 --> Total execution time: 0.0467
DEBUG - 2022-06-23 02:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:13 --> Total execution time: 0.0491
DEBUG - 2022-06-23 02:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:16 --> Total execution time: 0.0915
DEBUG - 2022-06-23 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:23 --> Total execution time: 0.0471
DEBUG - 2022-06-23 02:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:41 --> Total execution time: 0.0489
DEBUG - 2022-06-23 02:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:47 --> Total execution time: 0.0563
DEBUG - 2022-06-23 02:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:59:56 --> Total execution time: 0.0537
DEBUG - 2022-06-23 02:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:01 --> Total execution time: 0.1594
DEBUG - 2022-06-23 02:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:04 --> Total execution time: 0.0402
DEBUG - 2022-06-23 02:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:10 --> Total execution time: 0.0433
DEBUG - 2022-06-23 02:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:22 --> Total execution time: 0.0599
DEBUG - 2022-06-23 02:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:37 --> Total execution time: 0.0538
DEBUG - 2022-06-23 02:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:50 --> Total execution time: 0.0707
DEBUG - 2022-06-23 02:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:00:59 --> Total execution time: 0.0685
DEBUG - 2022-06-23 02:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:01:16 --> Total execution time: 0.0689
DEBUG - 2022-06-23 02:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:32:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:37 --> Total execution time: 0.0384
DEBUG - 2022-06-23 02:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:46 --> Total execution time: 0.0520
DEBUG - 2022-06-23 02:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:03:03 --> Total execution time: 0.0490
DEBUG - 2022-06-23 02:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:03:36 --> Total execution time: 0.0883
DEBUG - 2022-06-23 02:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:07:31 --> Total execution time: 0.1266
DEBUG - 2022-06-23 02:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:15 --> Total execution time: 0.0436
DEBUG - 2022-06-23 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:22 --> Total execution time: 0.0535
DEBUG - 2022-06-23 02:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:26 --> Total execution time: 0.0495
DEBUG - 2022-06-23 02:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:33 --> Total execution time: 0.0705
DEBUG - 2022-06-23 02:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:35 --> Total execution time: 0.0426
DEBUG - 2022-06-23 02:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:42 --> Total execution time: 0.0471
DEBUG - 2022-06-23 02:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:10:17 --> Total execution time: 0.0437
DEBUG - 2022-06-23 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:11:35 --> Total execution time: 0.0469
DEBUG - 2022-06-23 02:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:42:03 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:12:03 --> Total execution time: 0.0627
DEBUG - 2022-06-23 02:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:43:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:13:26 --> Total execution time: 0.0407
DEBUG - 2022-06-23 02:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:13:44 --> Total execution time: 0.0303
DEBUG - 2022-06-23 02:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:14:13 --> Total execution time: 0.0564
DEBUG - 2022-06-23 02:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:14:39 --> Total execution time: 0.0519
DEBUG - 2022-06-23 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:14:49 --> Total execution time: 0.0622
DEBUG - 2022-06-23 02:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:14:59 --> Total execution time: 0.0434
DEBUG - 2022-06-23 02:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:16:14 --> Total execution time: 0.0602
DEBUG - 2022-06-23 02:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:16:58 --> Total execution time: 0.0500
DEBUG - 2022-06-23 02:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:47:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:17:06 --> Total execution time: 0.0368
DEBUG - 2022-06-23 02:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:47:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:17:18 --> Total execution time: 0.0334
DEBUG - 2022-06-23 02:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:17:18 --> Total execution time: 0.1371
DEBUG - 2022-06-23 02:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:18:28 --> Total execution time: 0.0682
DEBUG - 2022-06-23 02:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:18:44 --> Total execution time: 0.0499
DEBUG - 2022-06-23 02:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:49:21 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:19:21 --> Total execution time: 0.0447
DEBUG - 2022-06-23 02:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 02:49:30 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 02:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:52:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 02:52:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:23:20 --> Total execution time: 0.1632
DEBUG - 2022-06-23 02:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 02:54:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:25:10 --> Total execution time: 0.0438
DEBUG - 2022-06-23 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:25:22 --> Total execution time: 0.0556
DEBUG - 2022-06-23 02:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:25:25 --> Total execution time: 0.0514
DEBUG - 2022-06-23 02:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:25:27 --> Total execution time: 0.0548
DEBUG - 2022-06-23 02:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:25:36 --> Total execution time: 0.0454
DEBUG - 2022-06-23 02:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:26:00 --> Total execution time: 0.0414
DEBUG - 2022-06-23 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:26:49 --> Total execution time: 0.0463
DEBUG - 2022-06-23 02:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:27:44 --> Total execution time: 0.0442
DEBUG - 2022-06-23 02:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 02:59:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 02:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 02:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:29:39 --> Total execution time: 0.0433
DEBUG - 2022-06-23 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:30:02 --> Total execution time: 0.0480
DEBUG - 2022-06-23 03:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:00:50 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:30:50 --> Total execution time: 0.0502
DEBUG - 2022-06-23 03:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:31:03 --> Total execution time: 0.0447
DEBUG - 2022-06-23 03:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:01:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:31:12 --> Total execution time: 0.0899
DEBUG - 2022-06-23 03:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:31:29 --> Total execution time: 0.1197
DEBUG - 2022-06-23 03:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:32:34 --> Total execution time: 0.1134
DEBUG - 2022-06-23 03:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:03:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:33:34 --> Total execution time: 0.1039
DEBUG - 2022-06-23 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:04:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:34:34 --> Total execution time: 0.2568
DEBUG - 2022-06-23 03:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:34:36 --> Total execution time: 0.0726
DEBUG - 2022-06-23 03:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:34:37 --> Total execution time: 0.0949
DEBUG - 2022-06-23 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:34:41 --> Total execution time: 0.0869
DEBUG - 2022-06-23 03:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:08:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:38:55 --> Total execution time: 0.1063
DEBUG - 2022-06-23 03:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:11:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:47 --> Total execution time: 0.1695
DEBUG - 2022-06-23 03:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:12 --> Total execution time: 0.0343
DEBUG - 2022-06-23 03:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:14 --> Total execution time: 0.0475
DEBUG - 2022-06-23 03:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:14 --> Total execution time: 0.0912
DEBUG - 2022-06-23 03:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:27 --> Total execution time: 0.0497
DEBUG - 2022-06-23 03:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:33 --> Total execution time: 0.0445
DEBUG - 2022-06-23 03:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:35 --> Total execution time: 0.0535
DEBUG - 2022-06-23 03:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:36 --> Total execution time: 0.0396
DEBUG - 2022-06-23 03:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:36 --> Total execution time: 0.0795
DEBUG - 2022-06-23 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:45 --> Total execution time: 0.0419
DEBUG - 2022-06-23 03:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:54 --> Total execution time: 0.0790
DEBUG - 2022-06-23 03:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:07 --> Total execution time: 0.0652
DEBUG - 2022-06-23 03:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:23 --> Total execution time: 0.0653
DEBUG - 2022-06-23 03:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:13:33 --> Total execution time: 0.0564
DEBUG - 2022-06-23 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:13:35 --> Total execution time: 0.0469
DEBUG - 2022-06-23 03:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:13:35 --> Total execution time: 0.0949
DEBUG - 2022-06-23 03:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:35 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:35 --> Total execution time: 0.0309
DEBUG - 2022-06-23 03:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:41 --> Total execution time: 0.0483
DEBUG - 2022-06-23 03:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:43 --> Total execution time: 0.0575
DEBUG - 2022-06-23 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:47 --> Total execution time: 0.0494
DEBUG - 2022-06-23 03:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:51 --> Total execution time: 0.0411
DEBUG - 2022-06-23 03:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:43:59 --> Total execution time: 0.0724
DEBUG - 2022-06-23 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:44:54 --> Total execution time: 0.0495
DEBUG - 2022-06-23 03:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:45:00 --> Total execution time: 0.0768
DEBUG - 2022-06-23 03:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:45:03 --> Total execution time: 0.0740
DEBUG - 2022-06-23 03:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:15:10 --> Total execution time: 0.0603
DEBUG - 2022-06-23 03:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:15:10 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:45:11 --> Total execution time: 0.0450
DEBUG - 2022-06-23 03:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:45:28 --> Total execution time: 0.0678
DEBUG - 2022-06-23 03:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 03:17:31 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 03:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:17:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:47:53 --> Total execution time: 0.0811
DEBUG - 2022-06-23 03:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:50:50 --> Total execution time: 0.0440
DEBUG - 2022-06-23 03:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:50:52 --> Total execution time: 0.0444
DEBUG - 2022-06-23 03:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:20:54 --> Total execution time: 0.0437
DEBUG - 2022-06-23 03:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:20:55 --> Total execution time: 0.0541
DEBUG - 2022-06-23 03:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:20:56 --> Total execution time: 0.0575
DEBUG - 2022-06-23 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:51:21 --> Total execution time: 0.0442
DEBUG - 2022-06-23 03:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:21:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:51:23 --> Total execution time: 0.0456
DEBUG - 2022-06-23 03:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:52:04 --> Total execution time: 0.0569
DEBUG - 2022-06-23 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:09 --> Total execution time: 0.0649
DEBUG - 2022-06-23 03:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:10 --> Total execution time: 0.0504
DEBUG - 2022-06-23 03:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:10 --> Total execution time: 0.0606
DEBUG - 2022-06-23 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:17 --> Total execution time: 0.0457
DEBUG - 2022-06-23 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:52:30 --> Total execution time: 0.0994
DEBUG - 2022-06-23 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:31 --> Total execution time: 0.0472
DEBUG - 2022-06-23 03:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:38 --> Total execution time: 0.0537
DEBUG - 2022-06-23 03:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:39 --> Total execution time: 0.0557
DEBUG - 2022-06-23 03:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:39 --> Total execution time: 0.0940
DEBUG - 2022-06-23 03:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:52:43 --> Total execution time: 0.0656
DEBUG - 2022-06-23 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:52:47 --> Total execution time: 0.0714
DEBUG - 2022-06-23 03:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:52:52 --> Total execution time: 0.0675
DEBUG - 2022-06-23 03:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:52:56 --> Total execution time: 0.0735
DEBUG - 2022-06-23 03:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:23 --> Total execution time: 0.0521
DEBUG - 2022-06-23 03:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:24 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:24 --> Total execution time: 0.1214
DEBUG - 2022-06-23 13:53:24 --> Total execution time: 0.2995
DEBUG - 2022-06-23 03:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:26 --> Total execution time: 0.0606
DEBUG - 2022-06-23 03:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:27 --> Total execution time: 0.0327
DEBUG - 2022-06-23 03:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:30 --> Total execution time: 0.0399
DEBUG - 2022-06-23 03:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:32 --> Total execution time: 0.0616
DEBUG - 2022-06-23 03:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:53:56 --> Total execution time: 0.0593
DEBUG - 2022-06-23 03:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:24:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:54:05 --> Total execution time: 0.0452
DEBUG - 2022-06-23 03:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:57:47 --> Total execution time: 0.1679
DEBUG - 2022-06-23 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:58:11 --> Total execution time: 0.0509
DEBUG - 2022-06-23 03:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:58:20 --> Total execution time: 0.0695
DEBUG - 2022-06-23 03:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:11 --> Total execution time: 0.0586
DEBUG - 2022-06-23 03:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:31 --> Total execution time: 0.0585
DEBUG - 2022-06-23 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:29:36 --> Total execution time: 0.0512
DEBUG - 2022-06-23 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:45 --> Total execution time: 0.0506
DEBUG - 2022-06-23 03:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:47 --> Total execution time: 0.0655
DEBUG - 2022-06-23 03:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:00:17 --> Total execution time: 0.0737
DEBUG - 2022-06-23 03:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:00:37 --> Total execution time: 0.1482
DEBUG - 2022-06-23 03:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:18 --> Total execution time: 0.0811
DEBUG - 2022-06-23 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:25 --> Total execution time: 0.0805
DEBUG - 2022-06-23 03:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:29 --> Total execution time: 0.0474
DEBUG - 2022-06-23 03:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:34 --> Total execution time: 0.0443
DEBUG - 2022-06-23 03:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:38 --> Total execution time: 0.0377
DEBUG - 2022-06-23 03:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:48 --> Total execution time: 0.0515
DEBUG - 2022-06-23 03:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:00 --> Total execution time: 0.0526
DEBUG - 2022-06-23 03:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:01 --> Total execution time: 0.0399
DEBUG - 2022-06-23 03:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:30 --> Total execution time: 0.0460
DEBUG - 2022-06-23 03:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:31 --> Total execution time: 0.0527
DEBUG - 2022-06-23 03:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:43 --> Total execution time: 0.0461
DEBUG - 2022-06-23 03:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:47 --> Total execution time: 0.0429
DEBUG - 2022-06-23 03:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:04:05 --> Total execution time: 0.0515
DEBUG - 2022-06-23 03:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:04:24 --> Total execution time: 0.0618
DEBUG - 2022-06-23 03:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:07:02 --> Total execution time: 0.1020
DEBUG - 2022-06-23 03:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:03 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:07:03 --> Total execution time: 0.0526
DEBUG - 2022-06-23 03:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:37:46 --> Total execution time: 0.0342
DEBUG - 2022-06-23 03:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:37:47 --> Total execution time: 0.0455
DEBUG - 2022-06-23 03:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:37:47 --> Total execution time: 0.0928
DEBUG - 2022-06-23 03:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:37:55 --> Total execution time: 0.0596
DEBUG - 2022-06-23 03:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:37:59 --> Total execution time: 0.0425
DEBUG - 2022-06-23 03:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:38:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 03:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:08:40 --> Total execution time: 2.0132
DEBUG - 2022-06-23 03:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 03:38:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 03:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:09:56 --> Total execution time: 0.0702
DEBUG - 2022-06-23 03:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:10:15 --> Total execution time: 0.0538
DEBUG - 2022-06-23 03:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:10:26 --> Total execution time: 0.0544
DEBUG - 2022-06-23 03:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:11:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 03:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:11:08 --> Total execution time: 0.0670
DEBUG - 2022-06-23 03:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:43:29 --> Total execution time: 0.1373
DEBUG - 2022-06-23 03:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:43:37 --> Total execution time: 0.0783
DEBUG - 2022-06-23 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:14:30 --> Total execution time: 0.1138
DEBUG - 2022-06-23 03:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:14:39 --> Total execution time: 0.0893
DEBUG - 2022-06-23 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:14:45 --> Total execution time: 0.0888
DEBUG - 2022-06-23 03:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:02 --> Total execution time: 0.0899
DEBUG - 2022-06-23 03:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:02 --> Total execution time: 0.0735
DEBUG - 2022-06-23 03:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:12 --> Total execution time: 0.0599
DEBUG - 2022-06-23 03:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:17 --> Total execution time: 0.0503
DEBUG - 2022-06-23 03:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:21 --> Total execution time: 0.0510
DEBUG - 2022-06-23 03:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:22 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:22 --> Total execution time: 0.0362
DEBUG - 2022-06-23 03:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:25 --> Total execution time: 0.0441
DEBUG - 2022-06-23 03:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:28 --> Total execution time: 0.0806
DEBUG - 2022-06-23 03:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:45 --> Total execution time: 0.0598
DEBUG - 2022-06-23 03:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:15:59 --> Total execution time: 1.4521
DEBUG - 2022-06-23 03:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:07 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:07 --> Total execution time: 0.0512
DEBUG - 2022-06-23 03:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:13 --> Total execution time: 0.0485
DEBUG - 2022-06-23 03:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:15 --> Total execution time: 0.0471
DEBUG - 2022-06-23 03:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:19 --> Total execution time: 0.0685
DEBUG - 2022-06-23 03:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:22 --> Total execution time: 0.0583
DEBUG - 2022-06-23 03:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:24 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:24 --> Total execution time: 0.1185
DEBUG - 2022-06-23 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:49 --> Total execution time: 0.1258
DEBUG - 2022-06-23 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:49 --> Total execution time: 0.0786
DEBUG - 2022-06-23 03:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:51 --> Total execution time: 0.0894
DEBUG - 2022-06-23 03:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:46:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:16:53 --> Total execution time: 0.0841
DEBUG - 2022-06-23 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:47:14 --> Total execution time: 0.0474
DEBUG - 2022-06-23 03:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:47:15 --> Total execution time: 0.0600
DEBUG - 2022-06-23 03:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:47:15 --> Total execution time: 0.0630
DEBUG - 2022-06-23 03:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:47:33 --> Total execution time: 0.0538
DEBUG - 2022-06-23 03:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:48:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 03:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:18:21 --> Total execution time: 1.4763
DEBUG - 2022-06-23 03:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 03:48:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 03:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:18:33 --> Total execution time: 0.0385
DEBUG - 2022-06-23 03:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:18:59 --> Total execution time: 1.5678
DEBUG - 2022-06-23 03:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:49:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:19:48 --> Total execution time: 0.0557
DEBUG - 2022-06-23 03:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:20:06 --> Total execution time: 0.1429
DEBUG - 2022-06-23 03:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:20:06 --> Total execution time: 0.0540
DEBUG - 2022-06-23 03:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:20:13 --> Total execution time: 1.4419
DEBUG - 2022-06-23 03:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:20:20 --> Total execution time: 0.0317
DEBUG - 2022-06-23 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:20:28 --> Total execution time: 0.0343
DEBUG - 2022-06-23 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:20:59 --> Total execution time: 0.0531
DEBUG - 2022-06-23 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:21:02 --> Total execution time: 0.0433
DEBUG - 2022-06-23 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:21:06 --> Total execution time: 0.0708
DEBUG - 2022-06-23 03:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:52:07 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:22:07 --> Total execution time: 0.1017
DEBUG - 2022-06-23 03:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:22:26 --> Total execution time: 1.5472
DEBUG - 2022-06-23 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:52:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 03:52:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 03:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:52:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:22:38 --> Total execution time: 0.0510
DEBUG - 2022-06-23 03:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:23:04 --> Total execution time: 0.1091
DEBUG - 2022-06-23 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:23:12 --> Total execution time: 0.0518
DEBUG - 2022-06-23 03:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:23:28 --> Total execution time: 0.0526
DEBUG - 2022-06-23 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:23:33 --> Total execution time: 0.0540
DEBUG - 2022-06-23 03:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:23:43 --> Total execution time: 0.0706
DEBUG - 2022-06-23 03:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:23:57 --> Total execution time: 0.0794
DEBUG - 2022-06-23 03:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:24:15 --> Total execution time: 0.0524
DEBUG - 2022-06-23 03:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:24:19 --> Total execution time: 0.0770
DEBUG - 2022-06-23 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:24:54 --> Total execution time: 0.1240
DEBUG - 2022-06-23 03:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:03 --> No URI present. Default controller set.
DEBUG - 2022-06-23 03:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:26:03 --> Total execution time: 0.0483
DEBUG - 2022-06-23 03:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:26:12 --> Total execution time: 0.0483
DEBUG - 2022-06-23 03:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:26:33 --> Total execution time: 0.0586
DEBUG - 2022-06-23 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:26:39 --> Total execution time: 0.0635
DEBUG - 2022-06-23 03:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:26:50 --> Total execution time: 0.0529
DEBUG - 2022-06-23 03:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:26:51 --> Total execution time: 0.0425
DEBUG - 2022-06-23 03:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:27:04 --> Total execution time: 0.0648
DEBUG - 2022-06-23 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:27:33 --> Total execution time: 0.0611
DEBUG - 2022-06-23 03:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:27:43 --> Total execution time: 0.0954
DEBUG - 2022-06-23 03:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:28:25 --> Total execution time: 0.0683
DEBUG - 2022-06-23 03:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 03:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 03:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:28:45 --> Total execution time: 0.0622
DEBUG - 2022-06-23 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:30:02 --> Total execution time: 0.0871
DEBUG - 2022-06-23 04:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:30:06 --> Total execution time: 0.2948
DEBUG - 2022-06-23 04:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:30:22 --> Total execution time: 0.0340
DEBUG - 2022-06-23 04:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:30:41 --> Total execution time: 0.0554
DEBUG - 2022-06-23 04:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:30:48 --> Total execution time: 0.0534
DEBUG - 2022-06-23 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:30:56 --> Total execution time: 0.1796
DEBUG - 2022-06-23 04:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 04:01:13 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-23 04:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:31:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 04:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:31:18 --> Total execution time: 0.0700
DEBUG - 2022-06-23 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:31:24 --> Total execution time: 0.0795
DEBUG - 2022-06-23 04:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:32:25 --> Total execution time: 0.0490
DEBUG - 2022-06-23 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:45:53 --> Total execution time: 0.4800
DEBUG - 2022-06-23 04:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:20:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:50:01 --> Total execution time: 0.1804
DEBUG - 2022-06-23 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:50:14 --> Total execution time: 0.0626
DEBUG - 2022-06-23 04:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:21:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:51:39 --> Total execution time: 0.0389
DEBUG - 2022-06-23 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:51:40 --> Total execution time: 0.1012
DEBUG - 2022-06-23 04:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:51:46 --> Total execution time: 0.0486
DEBUG - 2022-06-23 04:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:51:51 --> Total execution time: 0.0539
DEBUG - 2022-06-23 04:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:51:59 --> Total execution time: 0.0683
DEBUG - 2022-06-23 04:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:52:08 --> Total execution time: 0.0581
DEBUG - 2022-06-23 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:55:32 --> Total execution time: 0.0527
DEBUG - 2022-06-23 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:25:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:55:37 --> Total execution time: 0.0366
DEBUG - 2022-06-23 04:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:26:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:56:01 --> Total execution time: 0.0454
DEBUG - 2022-06-23 04:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 04:28:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 04:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:59:56 --> Total execution time: 0.1819
DEBUG - 2022-06-23 04:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 04:31:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 04:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:32:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:02:04 --> Total execution time: 0.0659
DEBUG - 2022-06-23 04:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:02:07 --> Total execution time: 0.0314
DEBUG - 2022-06-23 04:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:02:14 --> Total execution time: 0.0565
DEBUG - 2022-06-23 04:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:02:20 --> Total execution time: 0.1003
DEBUG - 2022-06-23 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:03:05 --> Total execution time: 0.0509
DEBUG - 2022-06-23 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 04:33:11 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 04:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:33:35 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:03:35 --> Total execution time: 0.1095
DEBUG - 2022-06-23 04:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:06:17 --> Total execution time: 0.0998
DEBUG - 2022-06-23 04:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:07:47 --> Total execution time: 0.1168
DEBUG - 2022-06-23 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:40:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:10:04 --> Total execution time: 0.0793
DEBUG - 2022-06-23 04:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:10:07 --> Total execution time: 0.0443
DEBUG - 2022-06-23 04:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:10:14 --> Total execution time: 0.0669
DEBUG - 2022-06-23 04:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:10:17 --> Total execution time: 0.0465
DEBUG - 2022-06-23 04:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:10:24 --> Total execution time: 0.0528
DEBUG - 2022-06-23 04:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:12 --> Total execution time: 0.0938
DEBUG - 2022-06-23 04:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:13 --> Total execution time: 0.0363
DEBUG - 2022-06-23 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:37 --> Total execution time: 0.0433
DEBUG - 2022-06-23 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:37 --> Total execution time: 0.1702
DEBUG - 2022-06-23 04:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:39 --> Total execution time: 0.0473
DEBUG - 2022-06-23 04:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:43 --> Total execution time: 0.0481
DEBUG - 2022-06-23 04:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:45 --> Total execution time: 0.0771
DEBUG - 2022-06-23 04:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:47 --> Total execution time: 0.1147
DEBUG - 2022-06-23 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:51 --> Total execution time: 0.0681
DEBUG - 2022-06-23 04:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:00 --> Total execution time: 0.1121
DEBUG - 2022-06-23 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:06 --> Total execution time: 0.0524
DEBUG - 2022-06-23 04:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:31 --> Total execution time: 0.1076
DEBUG - 2022-06-23 04:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:34 --> Total execution time: 0.0482
DEBUG - 2022-06-23 04:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:40 --> Total execution time: 0.0663
DEBUG - 2022-06-23 04:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:44 --> Total execution time: 0.0508
DEBUG - 2022-06-23 04:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:44:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:14:48 --> Total execution time: 0.0339
DEBUG - 2022-06-23 04:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:15:08 --> Total execution time: 0.0298
DEBUG - 2022-06-23 04:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:09 --> Total execution time: 0.0484
DEBUG - 2022-06-23 04:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:11 --> Total execution time: 0.0546
DEBUG - 2022-06-23 04:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:11 --> Total execution time: 0.0784
DEBUG - 2022-06-23 04:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:15:12 --> Total execution time: 0.0532
DEBUG - 2022-06-23 04:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:16 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:15:16 --> Total execution time: 0.0472
DEBUG - 2022-06-23 04:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:15:35 --> Total execution time: 0.0666
DEBUG - 2022-06-23 04:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:38 --> Total execution time: 0.0707
DEBUG - 2022-06-23 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:45:39 --> Total execution time: 0.0545
DEBUG - 2022-06-23 04:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:45:39 --> Total execution time: 0.0599
DEBUG - 2022-06-23 04:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:07 --> Total execution time: 0.0666
DEBUG - 2022-06-23 04:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:46:08 --> Total execution time: 0.0371
DEBUG - 2022-06-23 04:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 04:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:20 --> Total execution time: 0.0320
DEBUG - 2022-06-23 04:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:22 --> Total execution time: 0.0721
DEBUG - 2022-06-23 04:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:29 --> Total execution time: 0.0541
DEBUG - 2022-06-23 04:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:46:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 04:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:16:37 --> Total execution time: 2.1531
DEBUG - 2022-06-23 04:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:46:38 --> Total execution time: 0.0435
DEBUG - 2022-06-23 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:38 --> Total execution time: 0.0642
DEBUG - 2022-06-23 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:46:38 --> Total execution time: 0.0632
DEBUG - 2022-06-23 04:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:41 --> Total execution time: 0.0527
DEBUG - 2022-06-23 04:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:16:53 --> Total execution time: 0.0656
DEBUG - 2022-06-23 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:17:23 --> Total execution time: 0.0470
DEBUG - 2022-06-23 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:17:54 --> Total execution time: 0.0653
DEBUG - 2022-06-23 04:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:18:15 --> Total execution time: 0.0778
DEBUG - 2022-06-23 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:18:27 --> Total execution time: 0.0610
DEBUG - 2022-06-23 04:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:19:01 --> Total execution time: 0.0755
DEBUG - 2022-06-23 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:19:21 --> Total execution time: 0.0692
DEBUG - 2022-06-23 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:19:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:19:43 --> Total execution time: 0.0517
DEBUG - 2022-06-23 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:51:13 --> Total execution time: 0.0513
DEBUG - 2022-06-23 04:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:21:36 --> Total execution time: 0.1163
DEBUG - 2022-06-23 04:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:21:49 --> Total execution time: 0.1429
DEBUG - 2022-06-23 04:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:22:19 --> Total execution time: 0.1343
DEBUG - 2022-06-23 04:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:53:02 --> Total execution time: 0.0516
DEBUG - 2022-06-23 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:53:12 --> Total execution time: 0.1034
DEBUG - 2022-06-23 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:23:42 --> Total execution time: 0.0784
DEBUG - 2022-06-23 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:23:52 --> Total execution time: 0.0992
DEBUG - 2022-06-23 04:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:24:03 --> Total execution time: 0.0545
DEBUG - 2022-06-23 04:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:24:11 --> Total execution time: 0.0929
DEBUG - 2022-06-23 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:24:12 --> Total execution time: 0.0725
DEBUG - 2022-06-23 04:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:24:15 --> Total execution time: 0.0739
DEBUG - 2022-06-23 04:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:24:18 --> Total execution time: 0.0487
DEBUG - 2022-06-23 04:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:25:22 --> Total execution time: 0.0797
DEBUG - 2022-06-23 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:25:51 --> Total execution time: 0.0671
DEBUG - 2022-06-23 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:25:51 --> Total execution time: 0.1189
DEBUG - 2022-06-23 04:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:26:24 --> Total execution time: 0.0516
DEBUG - 2022-06-23 04:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 04:56:32 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 04:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:26:34 --> Total execution time: 0.1964
DEBUG - 2022-06-23 04:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:59:17 --> Total execution time: 0.1176
DEBUG - 2022-06-23 04:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 04:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 04:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 04:59:35 --> Total execution time: 0.0706
DEBUG - 2022-06-23 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:30:02 --> Total execution time: 0.1269
DEBUG - 2022-06-23 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:00:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:30:13 --> Total execution time: 0.0425
DEBUG - 2022-06-23 05:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:00:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:30:20 --> Total execution time: 0.0339
DEBUG - 2022-06-23 05:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:31:48 --> Total execution time: 0.1399
DEBUG - 2022-06-23 05:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:32:10 --> Total execution time: 0.0892
DEBUG - 2022-06-23 05:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:32:31 --> Total execution time: 0.1633
DEBUG - 2022-06-23 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:03:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:33:18 --> Total execution time: 0.1170
DEBUG - 2022-06-23 05:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:36:11 --> Total execution time: 0.1087
DEBUG - 2022-06-23 05:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:36:31 --> Total execution time: 0.1828
DEBUG - 2022-06-23 05:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:36:33 --> Total execution time: 0.1125
DEBUG - 2022-06-23 05:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:36:52 --> Total execution time: 0.0650
DEBUG - 2022-06-23 05:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:06:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:36:53 --> Total execution time: 0.0374
DEBUG - 2022-06-23 05:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:37:00 --> Total execution time: 0.0353
DEBUG - 2022-06-23 05:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:37:33 --> Total execution time: 0.1018
DEBUG - 2022-06-23 05:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:37:42 --> Total execution time: 0.0676
DEBUG - 2022-06-23 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:37:48 --> Total execution time: 0.1275
DEBUG - 2022-06-23 05:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:37:53 --> Total execution time: 0.0550
DEBUG - 2022-06-23 05:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:37:59 --> Total execution time: 0.0892
DEBUG - 2022-06-23 05:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:00 --> Total execution time: 0.0523
DEBUG - 2022-06-23 05:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:06 --> Total execution time: 0.0349
DEBUG - 2022-06-23 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:16 --> Total execution time: 0.0524
DEBUG - 2022-06-23 05:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:44 --> Total execution time: 0.0657
DEBUG - 2022-06-23 05:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:50 --> Total execution time: 0.0814
DEBUG - 2022-06-23 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:38:56 --> Total execution time: 0.0896
DEBUG - 2022-06-23 05:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:39:15 --> Total execution time: 0.1322
DEBUG - 2022-06-23 05:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:39:32 --> Total execution time: 0.1191
DEBUG - 2022-06-23 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:39:47 --> Total execution time: 0.0972
DEBUG - 2022-06-23 05:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:39:56 --> Total execution time: 0.1363
DEBUG - 2022-06-23 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:08 --> Total execution time: 0.0949
DEBUG - 2022-06-23 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:14 --> Total execution time: 0.0962
DEBUG - 2022-06-23 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:16 --> Total execution time: 0.1065
DEBUG - 2022-06-23 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:21 --> Total execution time: 0.2278
DEBUG - 2022-06-23 05:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:26 --> Total execution time: 0.1129
DEBUG - 2022-06-23 05:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:27 --> Total execution time: 0.0877
DEBUG - 2022-06-23 05:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:28 --> Total execution time: 0.1108
DEBUG - 2022-06-23 05:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:29 --> Total execution time: 0.0993
DEBUG - 2022-06-23 05:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:32 --> Total execution time: 0.0858
DEBUG - 2022-06-23 05:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:37 --> Total execution time: 0.0861
DEBUG - 2022-06-23 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:38 --> Total execution time: 0.1014
DEBUG - 2022-06-23 05:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:40 --> Total execution time: 0.0497
DEBUG - 2022-06-23 05:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:41 --> Total execution time: 0.0565
DEBUG - 2022-06-23 05:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:42 --> Total execution time: 0.0573
DEBUG - 2022-06-23 05:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:51 --> Total execution time: 0.0731
DEBUG - 2022-06-23 05:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:40:52 --> Total execution time: 0.2108
DEBUG - 2022-06-23 05:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:08 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:41:09 --> Total execution time: 0.1262
DEBUG - 2022-06-23 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:41:21 --> Total execution time: 0.0301
DEBUG - 2022-06-23 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:41:25 --> Total execution time: 0.0528
DEBUG - 2022-06-23 05:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:41:35 --> Total execution time: 0.0500
DEBUG - 2022-06-23 05:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:11:35 --> Total execution time: 0.0470
DEBUG - 2022-06-23 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:12:21 --> Total execution time: 0.0457
DEBUG - 2022-06-23 05:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:13:11 --> Total execution time: 0.0678
DEBUG - 2022-06-23 05:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:13:15 --> Total execution time: 0.0646
DEBUG - 2022-06-23 05:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:13:20 --> Total execution time: 0.0477
DEBUG - 2022-06-23 05:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:13:25 --> Total execution time: 0.0728
DEBUG - 2022-06-23 05:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:43:40 --> Total execution time: 0.0457
DEBUG - 2022-06-23 05:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:14:24 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:44:24 --> Total execution time: 0.1252
DEBUG - 2022-06-23 05:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:15:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:45:15 --> Total execution time: 0.1050
DEBUG - 2022-06-23 05:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:47:05 --> Total execution time: 0.1654
DEBUG - 2022-06-23 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:47:36 --> Total execution time: 0.0485
DEBUG - 2022-06-23 05:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:48:44 --> Total execution time: 0.0697
DEBUG - 2022-06-23 05:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:49:30 --> Total execution time: 0.1394
DEBUG - 2022-06-23 05:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:49:44 --> Total execution time: 0.0588
DEBUG - 2022-06-23 05:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:49:49 --> Total execution time: 0.0521
DEBUG - 2022-06-23 05:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:19:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:49:52 --> Total execution time: 0.0429
DEBUG - 2022-06-23 05:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:20:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:50:02 --> Total execution time: 0.1076
DEBUG - 2022-06-23 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:50:22 --> Total execution time: 0.0580
DEBUG - 2022-06-23 05:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:50:37 --> Total execution time: 0.0613
DEBUG - 2022-06-23 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:50:41 --> Total execution time: 0.0522
DEBUG - 2022-06-23 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:50:54 --> Total execution time: 0.0558
DEBUG - 2022-06-23 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:06 --> Total execution time: 0.0723
DEBUG - 2022-06-23 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:14 --> Total execution time: 0.0499
DEBUG - 2022-06-23 05:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:24 --> Total execution time: 0.0865
DEBUG - 2022-06-23 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:28 --> Total execution time: 0.0944
DEBUG - 2022-06-23 05:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:30 --> Total execution time: 0.1160
DEBUG - 2022-06-23 05:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:34 --> Total execution time: 0.1058
DEBUG - 2022-06-23 05:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:40 --> Total execution time: 0.1186
DEBUG - 2022-06-23 05:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:21:48 --> Total execution time: 0.1316
DEBUG - 2022-06-23 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:51:58 --> Total execution time: 0.1040
DEBUG - 2022-06-23 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:52:03 --> Total execution time: 0.1162
DEBUG - 2022-06-23 05:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:52:12 --> Total execution time: 0.1854
DEBUG - 2022-06-23 05:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:52:14 --> Total execution time: 0.2642
DEBUG - 2022-06-23 05:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:52:32 --> Total execution time: 0.0832
DEBUG - 2022-06-23 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:52:40 --> Total execution time: 0.0828
DEBUG - 2022-06-23 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:22:50 --> Total execution time: 0.0522
DEBUG - 2022-06-23 05:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:22:52 --> Total execution time: 0.0968
DEBUG - 2022-06-23 05:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:22:52 --> Total execution time: 0.2402
DEBUG - 2022-06-23 05:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:22:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:52:59 --> Total execution time: 0.0788
DEBUG - 2022-06-23 05:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:53:08 --> Total execution time: 0.0810
DEBUG - 2022-06-23 05:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:53:17 --> Total execution time: 0.1153
DEBUG - 2022-06-23 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:53:27 --> Total execution time: 0.1225
DEBUG - 2022-06-23 05:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:53:41 --> Total execution time: 0.1629
DEBUG - 2022-06-23 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:53:47 --> Total execution time: 0.1881
DEBUG - 2022-06-23 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:54:22 --> Total execution time: 0.0590
DEBUG - 2022-06-23 05:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:55:43 --> Total execution time: 0.0631
DEBUG - 2022-06-23 05:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:57:45 --> Total execution time: 0.0922
DEBUG - 2022-06-23 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:58:12 --> Total execution time: 0.1269
DEBUG - 2022-06-23 05:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:58:15 --> Total execution time: 0.0894
DEBUG - 2022-06-23 05:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:59:11 --> Total execution time: 0.1562
DEBUG - 2022-06-23 05:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:59:22 --> Total execution time: 0.0710
DEBUG - 2022-06-23 05:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:00 --> Total execution time: 0.0980
DEBUG - 2022-06-23 05:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:04 --> Total execution time: 0.0793
DEBUG - 2022-06-23 05:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:10 --> Total execution time: 0.0728
DEBUG - 2022-06-23 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:11 --> Total execution time: 0.1002
DEBUG - 2022-06-23 05:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:19 --> Total execution time: 0.0489
DEBUG - 2022-06-23 05:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:19 --> Total execution time: 0.1037
DEBUG - 2022-06-23 05:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:31 --> Total execution time: 0.0546
DEBUG - 2022-06-23 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:34 --> Total execution time: 0.0604
DEBUG - 2022-06-23 05:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:38 --> Total execution time: 0.0708
DEBUG - 2022-06-23 05:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:43 --> Total execution time: 0.0546
DEBUG - 2022-06-23 05:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:49 --> Total execution time: 0.1015
DEBUG - 2022-06-23 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:31:04 --> Total execution time: 0.0461
DEBUG - 2022-06-23 05:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:01:29 --> Total execution time: 0.0517
DEBUG - 2022-06-23 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:01:39 --> Total execution time: 0.0530
DEBUG - 2022-06-23 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:01:51 --> Total execution time: 0.0485
DEBUG - 2022-06-23 05:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:02:10 --> Total execution time: 0.1394
DEBUG - 2022-06-23 05:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:32:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:02:53 --> Total execution time: 0.0345
DEBUG - 2022-06-23 05:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:14:35 --> Total execution time: 0.0623
DEBUG - 2022-06-23 05:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:33 --> Total execution time: 0.0454
DEBUG - 2022-06-23 05:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:34 --> Total execution time: 0.0546
DEBUG - 2022-06-23 05:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:35 --> Total execution time: 0.0433
DEBUG - 2022-06-23 05:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:37 --> Total execution time: 0.0569
DEBUG - 2022-06-23 05:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:38 --> Total execution time: 0.0550
DEBUG - 2022-06-23 05:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:39 --> Total execution time: 0.0588
DEBUG - 2022-06-23 05:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:16:41 --> Total execution time: 0.0591
DEBUG - 2022-06-23 05:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:17:19 --> Total execution time: 0.0468
DEBUG - 2022-06-23 05:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:17:22 --> Total execution time: 0.0361
DEBUG - 2022-06-23 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:17:23 --> Total execution time: 0.0366
DEBUG - 2022-06-23 05:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:17:24 --> Total execution time: 0.0369
DEBUG - 2022-06-23 05:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:09 --> Total execution time: 0.0693
DEBUG - 2022-06-23 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:10 --> Total execution time: 0.0738
DEBUG - 2022-06-23 05:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:11 --> Total execution time: 0.0507
DEBUG - 2022-06-23 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:13 --> Total execution time: 0.0417
DEBUG - 2022-06-23 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:14 --> Total execution time: 0.0457
DEBUG - 2022-06-23 05:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:15 --> Total execution time: 0.0445
DEBUG - 2022-06-23 05:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:26 --> Total execution time: 0.0432
DEBUG - 2022-06-23 05:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:18:28 --> Total execution time: 0.0578
DEBUG - 2022-06-23 05:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:51:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:21:34 --> Total execution time: 0.0765
DEBUG - 2022-06-23 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:05 --> Total execution time: 0.0367
DEBUG - 2022-06-23 05:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:07 --> Total execution time: 0.0597
DEBUG - 2022-06-23 05:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:08 --> Total execution time: 0.0491
DEBUG - 2022-06-23 05:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:13 --> Total execution time: 0.0323
DEBUG - 2022-06-23 05:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:17 --> Total execution time: 0.0596
DEBUG - 2022-06-23 05:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:20 --> Total execution time: 0.0478
DEBUG - 2022-06-23 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:24 --> Total execution time: 0.1048
DEBUG - 2022-06-23 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:38 --> Total execution time: 0.0403
DEBUG - 2022-06-23 16:22:38 --> Total execution time: 0.3748
DEBUG - 2022-06-23 05:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:39 --> Total execution time: 0.0977
DEBUG - 2022-06-23 05:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:41 --> Total execution time: 0.1328
DEBUG - 2022-06-23 05:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 05:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:46 --> Total execution time: 0.0551
DEBUG - 2022-06-23 05:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:48 --> Total execution time: 0.0462
DEBUG - 2022-06-23 05:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:22:50 --> Total execution time: 0.0537
DEBUG - 2022-06-23 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 05:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:23:55 --> Total execution time: 0.0370
DEBUG - 2022-06-23 05:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:28:02 --> Total execution time: 0.2500
DEBUG - 2022-06-23 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:30:03 --> Total execution time: 0.2708
DEBUG - 2022-06-23 06:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:31:16 --> Total execution time: 0.0672
DEBUG - 2022-06-23 06:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:33:29 --> Total execution time: 0.3687
DEBUG - 2022-06-23 06:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:37:08 --> Total execution time: 0.0928
DEBUG - 2022-06-23 06:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 06:07:27 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:09:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:39:37 --> Total execution time: 0.1178
DEBUG - 2022-06-23 06:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:09:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:39:38 --> Total execution time: 0.0954
DEBUG - 2022-06-23 06:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:39:54 --> Total execution time: 0.0500
DEBUG - 2022-06-23 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 06:09:58 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:40:03 --> Total execution time: 0.0641
DEBUG - 2022-06-23 06:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:40:41 --> Total execution time: 0.0691
DEBUG - 2022-06-23 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:40:46 --> Total execution time: 0.0946
DEBUG - 2022-06-23 06:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:41:05 --> Total execution time: 0.0587
DEBUG - 2022-06-23 06:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:41:12 --> Total execution time: 0.0546
DEBUG - 2022-06-23 06:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 06:12:07 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 06:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:13:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:43:38 --> Total execution time: 0.0336
DEBUG - 2022-06-23 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:16:21 --> Total execution time: 0.0429
DEBUG - 2022-06-23 06:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:46:27 --> Total execution time: 0.0647
DEBUG - 2022-06-23 06:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:46:31 --> Total execution time: 0.1459
DEBUG - 2022-06-23 06:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:46:33 --> Total execution time: 0.0738
DEBUG - 2022-06-23 06:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:46:37 --> Total execution time: 0.0643
DEBUG - 2022-06-23 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:46:41 --> Total execution time: 0.1954
DEBUG - 2022-06-23 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:47:18 --> Total execution time: 0.0700
DEBUG - 2022-06-23 06:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:47:19 --> Total execution time: 0.0345
DEBUG - 2022-06-23 06:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:47:21 --> Total execution time: 0.0501
DEBUG - 2022-06-23 06:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:47:26 --> Total execution time: 0.0538
DEBUG - 2022-06-23 06:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:47:31 --> Total execution time: 0.0647
DEBUG - 2022-06-23 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:47:36 --> Total execution time: 0.0666
DEBUG - 2022-06-23 06:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:24:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:54:12 --> Total execution time: 0.1096
DEBUG - 2022-06-23 06:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:55:16 --> Total execution time: 0.0455
DEBUG - 2022-06-23 06:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:55:24 --> Total execution time: 0.0539
DEBUG - 2022-06-23 06:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:56:00 --> Total execution time: 0.0636
DEBUG - 2022-06-23 06:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:56:00 --> Total execution time: 0.0341
DEBUG - 2022-06-23 06:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 06:26:00 --> 404 Page Not Found: Category/sports
DEBUG - 2022-06-23 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:56:04 --> Total execution time: 0.0231
DEBUG - 2022-06-23 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:56:11 --> Total execution time: 0.0638
DEBUG - 2022-06-23 06:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:56:17 --> Total execution time: 0.0741
DEBUG - 2022-06-23 06:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:03:11 --> Total execution time: 0.1549
DEBUG - 2022-06-23 06:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:03:12 --> Total execution time: 0.1454
DEBUG - 2022-06-23 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:04:49 --> Total execution time: 0.0476
DEBUG - 2022-06-23 06:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:05:00 --> Total execution time: 0.0506
DEBUG - 2022-06-23 06:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:05:02 --> Total execution time: 0.0538
DEBUG - 2022-06-23 06:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:05:06 --> Total execution time: 0.0597
DEBUG - 2022-06-23 06:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:05:15 --> Total execution time: 0.0450
DEBUG - 2022-06-23 06:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 06:35:41 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 06:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:09:08 --> Total execution time: 0.1675
DEBUG - 2022-06-23 06:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:11:02 --> Total execution time: 0.0483
DEBUG - 2022-06-23 06:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 06:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:11:09 --> Total execution time: 0.0559
DEBUG - 2022-06-23 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:11:18 --> Total execution time: 0.0377
DEBUG - 2022-06-23 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:11:39 --> Total execution time: 0.0594
DEBUG - 2022-06-23 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:11:56 --> Total execution time: 0.1301
DEBUG - 2022-06-23 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:12:45 --> Total execution time: 0.2383
DEBUG - 2022-06-23 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:45:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:15:00 --> Total execution time: 0.0749
DEBUG - 2022-06-23 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:16:54 --> Total execution time: 0.0525
DEBUG - 2022-06-23 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:26:45 --> Total execution time: 0.2026
DEBUG - 2022-06-23 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:26:48 --> Total execution time: 0.0576
DEBUG - 2022-06-23 06:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:26:56 --> Total execution time: 0.0457
DEBUG - 2022-06-23 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:30:04 --> Total execution time: 0.2405
DEBUG - 2022-06-23 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:06:50 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:36:51 --> Total execution time: 0.1824
DEBUG - 2022-06-23 07:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:07:57 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:37:57 --> Total execution time: 0.0343
DEBUG - 2022-06-23 07:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:38:34 --> Total execution time: 0.1152
DEBUG - 2022-06-23 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:08:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:38:52 --> Total execution time: 0.0458
DEBUG - 2022-06-23 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:40:44 --> Total execution time: 0.0442
DEBUG - 2022-06-23 07:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:40:56 --> Total execution time: 0.0577
DEBUG - 2022-06-23 07:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:42:11 --> Total execution time: 0.0694
DEBUG - 2022-06-23 07:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:45:28 --> Total execution time: 0.1633
DEBUG - 2022-06-23 07:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:45:36 --> Total execution time: 0.0469
DEBUG - 2022-06-23 07:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:18:48 --> Total execution time: 0.0457
DEBUG - 2022-06-23 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 07:21:12 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-06-23 07:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:26:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:56:26 --> Total execution time: 0.1240
DEBUG - 2022-06-23 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:57:40 --> Total execution time: 0.0488
DEBUG - 2022-06-23 07:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:59:10 --> Total execution time: 0.0703
DEBUG - 2022-06-23 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:59:19 --> Total execution time: 0.1068
DEBUG - 2022-06-23 07:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:59:21 --> Total execution time: 0.0804
DEBUG - 2022-06-23 07:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:59:46 --> Total execution time: 0.0460
DEBUG - 2022-06-23 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:00:02 --> Total execution time: 0.0582
DEBUG - 2022-06-23 07:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:30:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:00:11 --> Total execution time: 0.0428
DEBUG - 2022-06-23 07:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:30:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:00:11 --> Total execution time: 0.0599
DEBUG - 2022-06-23 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:35:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:05:03 --> Total execution time: 0.1162
DEBUG - 2022-06-23 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:05:06 --> Total execution time: 0.0406
DEBUG - 2022-06-23 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:05:13 --> Total execution time: 0.0655
DEBUG - 2022-06-23 07:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:05:21 --> Total execution time: 0.0807
DEBUG - 2022-06-23 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:05:35 --> Total execution time: 0.0797
DEBUG - 2022-06-23 07:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:06:06 --> Total execution time: 0.0629
DEBUG - 2022-06-23 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:06:54 --> Total execution time: 0.0506
DEBUG - 2022-06-23 07:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:07:05 --> Total execution time: 0.0466
DEBUG - 2022-06-23 07:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:07:22 --> Total execution time: 0.0933
DEBUG - 2022-06-23 07:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:07:37 --> Total execution time: 0.0476
DEBUG - 2022-06-23 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:07:48 --> Total execution time: 0.1402
DEBUG - 2022-06-23 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:07:50 --> Total execution time: 0.0516
DEBUG - 2022-06-23 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:07:52 --> Total execution time: 0.0488
DEBUG - 2022-06-23 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:18 --> Total execution time: 0.0444
DEBUG - 2022-06-23 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:20 --> Total execution time: 0.0576
DEBUG - 2022-06-23 07:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:32 --> Total execution time: 0.0454
DEBUG - 2022-06-23 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:34 --> Total execution time: 0.0570
DEBUG - 2022-06-23 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:35 --> Total execution time: 0.0410
DEBUG - 2022-06-23 07:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:36 --> Total execution time: 0.0433
DEBUG - 2022-06-23 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:08:40 --> Total execution time: 0.0643
DEBUG - 2022-06-23 07:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:03 --> Total execution time: 0.0513
DEBUG - 2022-06-23 07:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:20 --> Total execution time: 0.0908
DEBUG - 2022-06-23 07:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:23 --> Total execution time: 0.0670
DEBUG - 2022-06-23 07:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:28 --> Total execution time: 0.0394
DEBUG - 2022-06-23 07:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:31 --> Total execution time: 0.0328
DEBUG - 2022-06-23 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:34 --> Total execution time: 0.0495
DEBUG - 2022-06-23 07:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:09:39 --> Total execution time: 0.0606
DEBUG - 2022-06-23 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:10:17 --> Total execution time: 0.0511
DEBUG - 2022-06-23 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:10:27 --> Total execution time: 0.0620
DEBUG - 2022-06-23 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:10:39 --> Total execution time: 0.0610
DEBUG - 2022-06-23 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:10:42 --> Total execution time: 0.0792
DEBUG - 2022-06-23 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:10:51 --> Total execution time: 0.0571
DEBUG - 2022-06-23 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:01 --> Total execution time: 0.0541
DEBUG - 2022-06-23 07:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:06 --> Total execution time: 0.0459
DEBUG - 2022-06-23 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:09 --> Total execution time: 0.0658
DEBUG - 2022-06-23 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:13 --> Total execution time: 0.0528
DEBUG - 2022-06-23 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:22 --> Total execution time: 0.0448
DEBUG - 2022-06-23 07:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:24 --> Total execution time: 0.0417
DEBUG - 2022-06-23 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:39 --> Total execution time: 0.0629
DEBUG - 2022-06-23 07:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:46 --> Total execution time: 0.0719
DEBUG - 2022-06-23 07:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:11:57 --> Total execution time: 0.0808
DEBUG - 2022-06-23 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:42:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:12:01 --> Total execution time: 0.0973
DEBUG - 2022-06-23 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:12:32 --> Total execution time: 0.0949
DEBUG - 2022-06-23 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:00 --> Total execution time: 0.2695
DEBUG - 2022-06-23 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:04 --> Total execution time: 0.0876
DEBUG - 2022-06-23 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:08 --> Total execution time: 0.0656
DEBUG - 2022-06-23 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:21 --> Total execution time: 0.0489
DEBUG - 2022-06-23 07:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:28 --> Total execution time: 0.0444
DEBUG - 2022-06-23 07:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:33 --> Total execution time: 0.0708
DEBUG - 2022-06-23 07:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:34 --> Total execution time: 0.1111
DEBUG - 2022-06-23 07:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:34 --> Total execution time: 0.0566
DEBUG - 2022-06-23 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:42 --> Total execution time: 0.0527
DEBUG - 2022-06-23 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:42 --> Total execution time: 0.0721
DEBUG - 2022-06-23 07:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:54 --> Total execution time: 0.0630
DEBUG - 2022-06-23 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:55 --> Total execution time: 0.0317
DEBUG - 2022-06-23 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:56 --> Total execution time: 0.0676
DEBUG - 2022-06-23 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:43:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:13:58 --> Total execution time: 0.0609
DEBUG - 2022-06-23 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:05 --> Total execution time: 0.0473
DEBUG - 2022-06-23 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:09 --> Total execution time: 0.0648
DEBUG - 2022-06-23 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:14 --> Total execution time: 0.0674
DEBUG - 2022-06-23 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:17 --> Total execution time: 0.0647
DEBUG - 2022-06-23 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:18 --> Total execution time: 0.0635
DEBUG - 2022-06-23 07:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:18 --> Total execution time: 0.1278
DEBUG - 2022-06-23 07:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:33 --> Total execution time: 0.0467
DEBUG - 2022-06-23 07:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:33 --> Total execution time: 0.1222
DEBUG - 2022-06-23 07:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:37 --> Total execution time: 0.1804
DEBUG - 2022-06-23 07:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:43 --> Total execution time: 0.0734
DEBUG - 2022-06-23 07:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:44 --> Total execution time: 0.0709
DEBUG - 2022-06-23 07:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:48 --> Total execution time: 0.0774
DEBUG - 2022-06-23 07:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:51 --> Total execution time: 0.0773
DEBUG - 2022-06-23 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:54 --> Total execution time: 0.0613
DEBUG - 2022-06-23 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:55 --> Total execution time: 0.0425
DEBUG - 2022-06-23 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:56 --> Total execution time: 0.0461
DEBUG - 2022-06-23 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:57 --> Total execution time: 0.0439
DEBUG - 2022-06-23 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:14:58 --> Total execution time: 0.0999
DEBUG - 2022-06-23 07:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:00 --> Total execution time: 0.0482
DEBUG - 2022-06-23 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:03 --> Total execution time: 0.0493
DEBUG - 2022-06-23 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:04 --> Total execution time: 0.0860
DEBUG - 2022-06-23 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:04 --> Total execution time: 0.0835
DEBUG - 2022-06-23 07:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:05 --> Total execution time: 0.0983
DEBUG - 2022-06-23 07:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:07 --> Total execution time: 0.0480
DEBUG - 2022-06-23 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:21 --> Total execution time: 0.0499
DEBUG - 2022-06-23 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:30 --> Total execution time: 0.1307
DEBUG - 2022-06-23 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:37 --> Total execution time: 0.0537
DEBUG - 2022-06-23 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:48 --> Total execution time: 0.0519
DEBUG - 2022-06-23 07:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:45:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:15:54 --> Total execution time: 1.9073
DEBUG - 2022-06-23 07:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:16:02 --> Total execution time: 0.1060
DEBUG - 2022-06-23 07:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:17:06 --> Total execution time: 0.0818
DEBUG - 2022-06-23 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:17:18 --> Total execution time: 0.1038
DEBUG - 2022-06-23 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:17:22 --> Total execution time: 0.0505
DEBUG - 2022-06-23 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:47:43 --> Total execution time: 0.0491
DEBUG - 2022-06-23 07:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:17:51 --> Total execution time: 0.0862
DEBUG - 2022-06-23 07:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 07:48:00 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 07:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:18:32 --> Total execution time: 0.0456
DEBUG - 2022-06-23 07:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:18:35 --> Total execution time: 0.0465
DEBUG - 2022-06-23 07:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:18:37 --> Total execution time: 0.0457
DEBUG - 2022-06-23 07:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:18:41 --> Total execution time: 0.0468
DEBUG - 2022-06-23 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:18:45 --> Total execution time: 0.0456
DEBUG - 2022-06-23 07:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:48:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:18:53 --> Total execution time: 0.0978
DEBUG - 2022-06-23 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:19:28 --> Total execution time: 0.0963
DEBUG - 2022-06-23 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:19:31 --> Total execution time: 0.0446
DEBUG - 2022-06-23 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:19:36 --> Total execution time: 0.0424
DEBUG - 2022-06-23 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:19:37 --> Total execution time: 0.0293
DEBUG - 2022-06-23 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:19:38 --> Total execution time: 0.0431
DEBUG - 2022-06-23 07:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:20:07 --> Total execution time: 0.0415
DEBUG - 2022-06-23 07:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:20:16 --> Total execution time: 0.0577
DEBUG - 2022-06-23 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 07:50:34 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:21:29 --> Total execution time: 0.0525
DEBUG - 2022-06-23 07:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 07:52:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:53:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:23:19 --> Total execution time: 0.0524
DEBUG - 2022-06-23 07:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:55:08 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:25:08 --> Total execution time: 0.1130
DEBUG - 2022-06-23 07:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:25:25 --> Total execution time: 0.1020
DEBUG - 2022-06-23 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:25:43 --> Total execution time: 0.0588
DEBUG - 2022-06-23 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:25:52 --> Total execution time: 0.0621
DEBUG - 2022-06-23 07:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:26:34 --> Total execution time: 0.1394
DEBUG - 2022-06-23 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:26:35 --> Total execution time: 0.0820
DEBUG - 2022-06-23 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:56:57 --> No URI present. Default controller set.
DEBUG - 2022-06-23 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:26:57 --> Total execution time: 0.0458
DEBUG - 2022-06-23 07:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:02 --> Total execution time: 0.0510
DEBUG - 2022-06-23 07:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:03 --> Total execution time: 0.0461
DEBUG - 2022-06-23 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:04 --> Total execution time: 0.0486
DEBUG - 2022-06-23 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:04 --> Total execution time: 0.0691
DEBUG - 2022-06-23 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:04 --> Total execution time: 0.0547
DEBUG - 2022-06-23 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:04 --> Total execution time: 0.0465
DEBUG - 2022-06-23 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:05 --> Total execution time: 0.0502
DEBUG - 2022-06-23 07:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:10 --> Total execution time: 0.0706
DEBUG - 2022-06-23 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:14 --> Total execution time: 0.0466
DEBUG - 2022-06-23 07:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 07:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:17 --> Total execution time: 0.0426
DEBUG - 2022-06-23 07:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 18:27:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 18:27:18 --> Total execution time: 0.1907
DEBUG - 2022-06-23 07:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:28:41 --> Total execution time: 0.0467
DEBUG - 2022-06-23 07:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 07:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:28:46 --> Total execution time: 0.0956
DEBUG - 2022-06-23 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 07:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 07:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:28:58 --> Total execution time: 0.0695
DEBUG - 2022-06-23 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:00:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:30:00 --> Total execution time: 0.0652
DEBUG - 2022-06-23 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:30:02 --> Total execution time: 0.1049
DEBUG - 2022-06-23 08:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:00:24 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:30:24 --> Total execution time: 0.0929
DEBUG - 2022-06-23 08:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:30:33 --> Total execution time: 0.0559
DEBUG - 2022-06-23 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:30:48 --> Total execution time: 0.0534
DEBUG - 2022-06-23 08:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:32:56 --> Total execution time: 0.1044
DEBUG - 2022-06-23 08:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:06:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:36:29 --> Total execution time: 0.0971
DEBUG - 2022-06-23 08:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:40:28 --> Total execution time: 0.0466
DEBUG - 2022-06-23 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:05 --> Total execution time: 0.0913
DEBUG - 2022-06-23 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:06 --> Total execution time: 0.0530
DEBUG - 2022-06-23 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:15 --> Total execution time: 0.0621
DEBUG - 2022-06-23 08:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:20 --> Total execution time: 0.0495
DEBUG - 2022-06-23 08:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:31 --> Total execution time: 0.0430
DEBUG - 2022-06-23 08:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:33 --> Total execution time: 0.0407
DEBUG - 2022-06-23 08:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:42 --> Total execution time: 0.0424
DEBUG - 2022-06-23 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:43 --> Total execution time: 0.0451
DEBUG - 2022-06-23 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:44 --> Total execution time: 0.0444
DEBUG - 2022-06-23 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:13:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:43:48 --> Total execution time: 0.0623
DEBUG - 2022-06-23 08:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:14:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:44:31 --> Total execution time: 0.1251
DEBUG - 2022-06-23 08:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:14:57 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:44:57 --> Total execution time: 0.0325
DEBUG - 2022-06-23 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:04 --> Total execution time: 0.0402
DEBUG - 2022-06-23 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:15 --> Total execution time: 0.0557
DEBUG - 2022-06-23 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:24 --> Total execution time: 0.0408
DEBUG - 2022-06-23 08:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:27 --> Total execution time: 0.0418
DEBUG - 2022-06-23 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:42 --> Total execution time: 0.0698
DEBUG - 2022-06-23 08:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:44 --> Total execution time: 0.0522
DEBUG - 2022-06-23 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:45:59 --> Total execution time: 0.0941
DEBUG - 2022-06-23 08:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:46:06 --> Total execution time: 0.0923
DEBUG - 2022-06-23 08:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 08:16:12 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 08:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:16:33 --> Total execution time: 0.0368
DEBUG - 2022-06-23 08:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:16:35 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:46:35 --> Total execution time: 0.0408
DEBUG - 2022-06-23 08:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:46:51 --> Total execution time: 0.0462
DEBUG - 2022-06-23 08:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:03 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:47:03 --> Total execution time: 0.1031
DEBUG - 2022-06-23 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:47:17 --> Total execution time: 0.0472
DEBUG - 2022-06-23 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:47:34 --> Total execution time: 0.0442
DEBUG - 2022-06-23 08:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:47:52 --> Total execution time: 0.0473
DEBUG - 2022-06-23 08:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:47:55 --> Total execution time: 0.0424
DEBUG - 2022-06-23 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:18:16 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:48:16 --> Total execution time: 0.0437
DEBUG - 2022-06-23 08:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:18:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:48:32 --> Total execution time: 0.0441
DEBUG - 2022-06-23 08:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:18:55 --> Total execution time: 0.0437
DEBUG - 2022-06-23 08:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:18:57 --> Total execution time: 0.0699
DEBUG - 2022-06-23 08:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:18:57 --> Total execution time: 0.1217
DEBUG - 2022-06-23 08:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:49:03 --> Total execution time: 0.0450
DEBUG - 2022-06-23 08:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:50:09 --> Total execution time: 0.1030
DEBUG - 2022-06-23 08:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:20:11 --> Total execution time: 0.0420
DEBUG - 2022-06-23 08:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:20:13 --> Total execution time: 0.0528
DEBUG - 2022-06-23 08:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:20:13 --> Total execution time: 0.0774
DEBUG - 2022-06-23 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:50:28 --> Total execution time: 0.0620
DEBUG - 2022-06-23 08:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:50:31 --> Total execution time: 0.0454
DEBUG - 2022-06-23 08:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:50:54 --> Total execution time: 0.1234
DEBUG - 2022-06-23 08:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:50:55 --> Total execution time: 0.0508
DEBUG - 2022-06-23 08:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:51:01 --> Total execution time: 0.0488
DEBUG - 2022-06-23 08:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:51:22 --> Total execution time: 0.0445
DEBUG - 2022-06-23 08:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:51:38 --> Total execution time: 0.0532
DEBUG - 2022-06-23 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:52:26 --> Total execution time: 0.0442
DEBUG - 2022-06-23 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:52:34 --> Total execution time: 0.0419
DEBUG - 2022-06-23 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:22:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:52:51 --> Total execution time: 0.1021
DEBUG - 2022-06-23 08:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:53:17 --> Total execution time: 0.0503
DEBUG - 2022-06-23 08:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 08:23:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:21 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:53:21 --> Total execution time: 0.0471
DEBUG - 2022-06-23 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:23:30 --> Total execution time: 0.0533
DEBUG - 2022-06-23 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:23:31 --> Total execution time: 0.0625
DEBUG - 2022-06-23 08:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:23:31 --> Total execution time: 0.0901
DEBUG - 2022-06-23 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:36 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:53:36 --> Total execution time: 0.0434
DEBUG - 2022-06-23 08:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:41 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:53:41 --> Total execution time: 0.0638
DEBUG - 2022-06-23 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:53:52 --> Total execution time: 0.0459
DEBUG - 2022-06-23 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:54:20 --> Total execution time: 0.0423
DEBUG - 2022-06-23 08:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:25:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:55:49 --> Total execution time: 0.0406
DEBUG - 2022-06-23 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:25:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:55:55 --> Total execution time: 0.0316
DEBUG - 2022-06-23 08:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:26:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:56:35 --> Total execution time: 0.0464
DEBUG - 2022-06-23 08:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:57:41 --> Total execution time: 0.1042
DEBUG - 2022-06-23 08:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:57:49 --> Total execution time: 0.0600
DEBUG - 2022-06-23 08:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:57:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 08:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:57:50 --> Total execution time: 0.0485
DEBUG - 2022-06-23 08:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:59:03 --> Total execution time: 0.0442
DEBUG - 2022-06-23 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:59:10 --> Total execution time: 0.0421
DEBUG - 2022-06-23 08:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:59:20 --> Total execution time: 0.0727
DEBUG - 2022-06-23 08:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:59:36 --> Total execution time: 0.0439
DEBUG - 2022-06-23 08:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:59:37 --> Total execution time: 0.0693
DEBUG - 2022-06-23 08:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:30:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:00:00 --> Total execution time: 0.0315
DEBUG - 2022-06-23 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:00:06 --> Total execution time: 0.0760
DEBUG - 2022-06-23 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:00:06 --> Total execution time: 0.0837
DEBUG - 2022-06-23 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:00:06 --> Total execution time: 0.0858
DEBUG - 2022-06-23 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:01:45 --> Total execution time: 0.0762
DEBUG - 2022-06-23 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:31:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:01:45 --> Total execution time: 0.1034
DEBUG - 2022-06-23 08:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:01:55 --> Total execution time: 1.9530
DEBUG - 2022-06-23 08:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:32:11 --> Total execution time: 0.0343
DEBUG - 2022-06-23 08:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 08:32:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 08:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:32:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:02:20 --> Total execution time: 0.0548
DEBUG - 2022-06-23 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:32:30 --> Total execution time: 0.0477
DEBUG - 2022-06-23 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:32:30 --> Total execution time: 0.0626
DEBUG - 2022-06-23 08:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:32:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:02:43 --> Total execution time: 0.0475
DEBUG - 2022-06-23 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:03:02 --> Total execution time: 0.0341
DEBUG - 2022-06-23 08:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:03:17 --> Total execution time: 0.0291
DEBUG - 2022-06-23 08:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:03:34 --> Total execution time: 0.0539
DEBUG - 2022-06-23 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:03:34 --> Total execution time: 0.1206
DEBUG - 2022-06-23 08:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:03:39 --> Total execution time: 0.0593
DEBUG - 2022-06-23 08:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:03:48 --> Total execution time: 0.0655
DEBUG - 2022-06-23 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:04:00 --> Total execution time: 0.0926
DEBUG - 2022-06-23 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:04:29 --> Total execution time: 0.0697
DEBUG - 2022-06-23 08:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:04:33 --> Total execution time: 0.0486
DEBUG - 2022-06-23 08:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:04:36 --> Total execution time: 0.0574
DEBUG - 2022-06-23 08:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:04:41 --> Total execution time: 0.1135
DEBUG - 2022-06-23 08:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:04:53 --> Total execution time: 0.0636
DEBUG - 2022-06-23 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:05:01 --> Total execution time: 0.0606
DEBUG - 2022-06-23 08:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:05:24 --> Total execution time: 0.0527
DEBUG - 2022-06-23 08:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:05:27 --> Total execution time: 0.0470
DEBUG - 2022-06-23 08:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:36:32 --> Total execution time: 0.0544
DEBUG - 2022-06-23 08:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:36:38 --> Total execution time: 0.0643
DEBUG - 2022-06-23 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:37:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:07:54 --> Total execution time: 0.0359
DEBUG - 2022-06-23 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:07:56 --> Total execution time: 0.0438
DEBUG - 2022-06-23 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:21 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:21 --> Total execution time: 0.0493
DEBUG - 2022-06-23 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:27 --> Total execution time: 0.0311
DEBUG - 2022-06-23 08:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:30 --> Total execution time: 0.0784
DEBUG - 2022-06-23 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:39 --> Total execution time: 0.0460
DEBUG - 2022-06-23 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:44 --> Total execution time: 0.0555
DEBUG - 2022-06-23 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:44 --> Total execution time: 0.0477
DEBUG - 2022-06-23 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:46 --> Total execution time: 0.1126
DEBUG - 2022-06-23 08:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:49 --> Total execution time: 0.0425
DEBUG - 2022-06-23 08:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:58 --> Total execution time: 0.0816
DEBUG - 2022-06-23 08:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:09:04 --> Total execution time: 0.0568
DEBUG - 2022-06-23 08:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:09:09 --> Total execution time: 0.0547
DEBUG - 2022-06-23 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:09:14 --> Total execution time: 0.0505
DEBUG - 2022-06-23 08:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:39:14 --> Total execution time: 0.0622
DEBUG - 2022-06-23 08:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:39:14 --> Total execution time: 0.0425
DEBUG - 2022-06-23 08:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:09:20 --> Total execution time: 0.0671
DEBUG - 2022-06-23 08:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:39:23 --> Total execution time: 0.0437
DEBUG - 2022-06-23 08:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:39:23 --> Total execution time: 0.1174
DEBUG - 2022-06-23 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 08:40:04 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-23 08:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:40:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:10:57 --> Total execution time: 1.5121
DEBUG - 2022-06-23 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:11:27 --> Total execution time: 0.0507
DEBUG - 2022-06-23 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:11:40 --> Total execution time: 0.0516
DEBUG - 2022-06-23 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:12:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:12:12 --> Total execution time: 0.0525
DEBUG - 2022-06-23 08:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:12:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 19:12:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 19:12:15 --> Total execution time: 0.1854
DEBUG - 2022-06-23 08:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:12:50 --> Total execution time: 0.0464
DEBUG - 2022-06-23 08:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:13:17 --> Total execution time: 0.0764
DEBUG - 2022-06-23 08:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:13:18 --> Total execution time: 0.0544
DEBUG - 2022-06-23 08:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:13:22 --> Total execution time: 0.0653
DEBUG - 2022-06-23 08:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 08:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:27 --> Total execution time: 0.0415
DEBUG - 2022-06-23 08:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:39 --> Total execution time: 0.0537
DEBUG - 2022-06-23 08:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:42 --> Total execution time: 0.0500
DEBUG - 2022-06-23 08:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:44 --> Total execution time: 0.0540
DEBUG - 2022-06-23 08:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:47 --> Total execution time: 0.0670
DEBUG - 2022-06-23 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:14:52 --> Total execution time: 0.0646
DEBUG - 2022-06-23 08:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:45:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:15:14 --> Total execution time: 0.0398
DEBUG - 2022-06-23 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:16:05 --> Total execution time: 0.1489
DEBUG - 2022-06-23 08:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:16:06 --> Total execution time: 0.0832
DEBUG - 2022-06-23 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:16:20 --> Total execution time: 1.5531
DEBUG - 2022-06-23 08:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:16:37 --> Total execution time: 0.0794
DEBUG - 2022-06-23 08:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 19:16:43 --> Total execution time: 0.0777
DEBUG - 2022-06-23 08:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:16:44 --> Total execution time: 0.0460
DEBUG - 2022-06-23 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:16:50 --> Total execution time: 0.0910
DEBUG - 2022-06-23 08:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:17:17 --> Total execution time: 0.0774
DEBUG - 2022-06-23 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:17:33 --> Total execution time: 0.1311
DEBUG - 2022-06-23 08:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:48:25 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:18:25 --> Total execution time: 0.0515
DEBUG - 2022-06-23 08:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:18:32 --> Total execution time: 0.0861
DEBUG - 2022-06-23 08:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:18:44 --> Total execution time: 2.1466
DEBUG - 2022-06-23 08:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:18:55 --> Total execution time: 0.0639
DEBUG - 2022-06-23 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:19:02 --> Total execution time: 0.1111
DEBUG - 2022-06-23 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:19:08 --> Total execution time: 0.0527
DEBUG - 2022-06-23 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:19:11 --> Total execution time: 0.0995
DEBUG - 2022-06-23 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:19:15 --> Total execution time: 0.0568
DEBUG - 2022-06-23 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:19:43 --> Total execution time: 0.1718
DEBUG - 2022-06-23 08:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:19:50 --> Total execution time: 0.0860
DEBUG - 2022-06-23 08:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:20:03 --> Total execution time: 0.1474
DEBUG - 2022-06-23 08:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:20:50 --> Total execution time: 0.0666
DEBUG - 2022-06-23 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:20:53 --> Total execution time: 0.0470
DEBUG - 2022-06-23 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:21:02 --> Total execution time: 0.0690
DEBUG - 2022-06-23 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:52:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 08:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:22:59 --> Total execution time: 0.0532
DEBUG - 2022-06-23 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:27 --> Total execution time: 0.0806
DEBUG - 2022-06-23 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:27 --> Total execution time: 0.1679
DEBUG - 2022-06-23 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 19:23:28 --> Total execution time: 0.4207
DEBUG - 2022-06-23 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:28 --> Total execution time: 0.5427
DEBUG - 2022-06-23 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:28 --> Total execution time: 0.5999
DEBUG - 2022-06-23 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:28 --> Total execution time: 0.4280
DEBUG - 2022-06-23 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:43 --> Total execution time: 0.1442
DEBUG - 2022-06-23 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:43 --> Total execution time: 0.0781
DEBUG - 2022-06-23 08:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:44 --> Total execution time: 0.1549
DEBUG - 2022-06-23 08:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:44 --> Total execution time: 0.0819
DEBUG - 2022-06-23 08:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:45 --> Total execution time: 0.0751
DEBUG - 2022-06-23 08:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:48 --> Total execution time: 0.0534
DEBUG - 2022-06-23 08:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:23:49 --> Total execution time: 0.1248
DEBUG - 2022-06-23 08:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:24:24 --> Total execution time: 0.0338
DEBUG - 2022-06-23 08:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:24:38 --> Total execution time: 0.0725
DEBUG - 2022-06-23 08:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:24:42 --> Total execution time: 0.2426
DEBUG - 2022-06-23 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:24:59 --> Total execution time: 0.2508
DEBUG - 2022-06-23 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:04 --> Total execution time: 0.1377
DEBUG - 2022-06-23 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:19 --> Total execution time: 0.0845
DEBUG - 2022-06-23 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:26 --> Total execution time: 0.1577
DEBUG - 2022-06-23 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:26 --> Total execution time: 0.1124
DEBUG - 2022-06-23 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:27 --> Total execution time: 0.0766
DEBUG - 2022-06-23 08:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:31 --> Total execution time: 0.1811
DEBUG - 2022-06-23 08:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:32 --> Total execution time: 0.0753
DEBUG - 2022-06-23 08:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:33 --> Total execution time: 0.1006
DEBUG - 2022-06-23 08:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:33 --> Total execution time: 0.0572
DEBUG - 2022-06-23 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:35 --> Total execution time: 0.0653
DEBUG - 2022-06-23 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:35 --> Total execution time: 0.0845
DEBUG - 2022-06-23 08:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:36 --> Total execution time: 0.0715
DEBUG - 2022-06-23 08:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:45 --> Total execution time: 0.0956
DEBUG - 2022-06-23 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:46 --> Total execution time: 0.0619
DEBUG - 2022-06-23 08:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 08:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:25:57 --> Total execution time: 0.1094
DEBUG - 2022-06-23 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:26:08 --> Total execution time: 0.1218
DEBUG - 2022-06-23 08:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:26:21 --> Total execution time: 0.0892
DEBUG - 2022-06-23 08:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:27:40 --> Total execution time: 0.0617
DEBUG - 2022-06-23 08:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:27:41 --> Total execution time: 0.0675
DEBUG - 2022-06-23 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:30:03 --> Total execution time: 0.2471
DEBUG - 2022-06-23 09:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:01:22 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:31:22 --> Total execution time: 0.1068
DEBUG - 2022-06-23 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:01:28 --> Total execution time: 0.0622
DEBUG - 2022-06-23 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:01:31 --> Total execution time: 0.0946
DEBUG - 2022-06-23 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:01:31 --> Total execution time: 0.1114
DEBUG - 2022-06-23 09:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:31:35 --> Total execution time: 0.1425
DEBUG - 2022-06-23 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:31:38 --> Total execution time: 0.1200
DEBUG - 2022-06-23 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:02:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:32:59 --> Total execution time: 1.8919
DEBUG - 2022-06-23 09:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:03:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:33:44 --> Total execution time: 0.0641
DEBUG - 2022-06-23 09:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:33:45 --> Total execution time: 0.0836
DEBUG - 2022-06-23 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:04 --> Total execution time: 0.0639
DEBUG - 2022-06-23 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:05 --> Total execution time: 0.0644
DEBUG - 2022-06-23 09:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:13 --> Total execution time: 0.0464
DEBUG - 2022-06-23 09:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:14 --> Total execution time: 0.0621
DEBUG - 2022-06-23 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 09:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:16 --> Total execution time: 0.0464
DEBUG - 2022-06-23 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 19:34:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 19:34:17 --> Total execution time: 0.1839
DEBUG - 2022-06-23 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:34:18 --> Total execution time: 0.0682
DEBUG - 2022-06-23 09:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:35:47 --> Total execution time: 0.0682
DEBUG - 2022-06-23 09:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:10:47 --> 404 Page Not Found: Wp-loadphp/index
DEBUG - 2022-06-23 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:11:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:41:19 --> Total execution time: 0.0821
DEBUG - 2022-06-23 09:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:41:21 --> Total execution time: 0.0317
DEBUG - 2022-06-23 09:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:41:27 --> Total execution time: 0.0509
DEBUG - 2022-06-23 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:41:32 --> Total execution time: 0.0658
DEBUG - 2022-06-23 09:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:42:10 --> Total execution time: 0.0455
DEBUG - 2022-06-23 09:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:13:11 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-23 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:14:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:44:12 --> Total execution time: 0.0429
DEBUG - 2022-06-23 09:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:14:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:44:15 --> Total execution time: 0.0477
DEBUG - 2022-06-23 09:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:18:36 --> 404 Page Not Found: Radiophp/index
DEBUG - 2022-06-23 09:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:20:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:50:52 --> Total execution time: 0.1110
DEBUG - 2022-06-23 09:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:51:13 --> Total execution time: 0.0482
DEBUG - 2022-06-23 09:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:51:35 --> Total execution time: 0.0506
DEBUG - 2022-06-23 09:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:51:44 --> Total execution time: 0.2229
DEBUG - 2022-06-23 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:51:51 --> Total execution time: 0.0658
DEBUG - 2022-06-23 09:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:22:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:52:02 --> Total execution time: 0.0283
DEBUG - 2022-06-23 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:52:19 --> Total execution time: 0.0557
DEBUG - 2022-06-23 09:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:52:22 --> Total execution time: 0.0519
DEBUG - 2022-06-23 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:22:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:52:52 --> Total execution time: 0.0336
DEBUG - 2022-06-23 09:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:52:59 --> Total execution time: 0.0255
DEBUG - 2022-06-23 09:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:23:01 --> Total execution time: 0.0443
DEBUG - 2022-06-23 09:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:23:04 --> Total execution time: 0.0694
DEBUG - 2022-06-23 09:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:23:04 --> Total execution time: 0.1089
DEBUG - 2022-06-23 09:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:53:14 --> Total execution time: 0.0505
DEBUG - 2022-06-23 09:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:23:22 --> Total execution time: 0.0436
DEBUG - 2022-06-23 09:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:53:58 --> Total execution time: 0.0440
DEBUG - 2022-06-23 09:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:05 --> Total execution time: 0.0487
DEBUG - 2022-06-23 09:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:23 --> Total execution time: 0.0512
DEBUG - 2022-06-23 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:35 --> Total execution time: 0.0423
DEBUG - 2022-06-23 09:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:36 --> Total execution time: 0.0504
DEBUG - 2022-06-23 09:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:39 --> Total execution time: 0.0529
DEBUG - 2022-06-23 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:43 --> Total execution time: 0.0470
DEBUG - 2022-06-23 09:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:56 --> Total execution time: 0.0658
DEBUG - 2022-06-23 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:58 --> Total execution time: 0.0426
DEBUG - 2022-06-23 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:54:58 --> Total execution time: 0.0379
DEBUG - 2022-06-23 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:00 --> Total execution time: 0.0445
DEBUG - 2022-06-23 09:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:06 --> Total execution time: 0.0469
DEBUG - 2022-06-23 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:07 --> Total execution time: 0.0463
DEBUG - 2022-06-23 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:09 --> Total execution time: 0.0425
DEBUG - 2022-06-23 09:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:18 --> Total execution time: 0.0433
DEBUG - 2022-06-23 09:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:21 --> Total execution time: 0.0417
DEBUG - 2022-06-23 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:22 --> Total execution time: 0.0565
DEBUG - 2022-06-23 09:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:40 --> Total execution time: 0.0500
DEBUG - 2022-06-23 09:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:55:55 --> Total execution time: 0.0563
DEBUG - 2022-06-23 09:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:56:03 --> Total execution time: 0.0622
DEBUG - 2022-06-23 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:56:07 --> Total execution time: 0.0415
DEBUG - 2022-06-23 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:56:14 --> Total execution time: 0.0436
DEBUG - 2022-06-23 09:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:56:45 --> Total execution time: 0.0551
DEBUG - 2022-06-23 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:56:48 --> Total execution time: 0.0433
DEBUG - 2022-06-23 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:26:58 --> Total execution time: 0.0486
DEBUG - 2022-06-23 09:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:26:59 --> Total execution time: 0.0546
DEBUG - 2022-06-23 09:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:26:59 --> Total execution time: 0.0568
DEBUG - 2022-06-23 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:27:11 --> Total execution time: 0.1003
DEBUG - 2022-06-23 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:57:20 --> Total execution time: 0.0360
DEBUG - 2022-06-23 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:57:39 --> Total execution time: 0.0423
DEBUG - 2022-06-23 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:58:14 --> Total execution time: 0.0993
DEBUG - 2022-06-23 09:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:28:31 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:58:37 --> Total execution time: 0.0449
DEBUG - 2022-06-23 09:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:41 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:58:41 --> Total execution time: 0.0493
DEBUG - 2022-06-23 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:28:48 --> Total execution time: 0.0543
DEBUG - 2022-06-23 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:28:49 --> Total execution time: 0.0719
DEBUG - 2022-06-23 09:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:28:49 --> Total execution time: 0.0959
DEBUG - 2022-06-23 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:58:51 --> Total execution time: 0.0463
DEBUG - 2022-06-23 09:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:58:55 --> Total execution time: 0.0501
DEBUG - 2022-06-23 09:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:58:56 --> Total execution time: 0.0438
DEBUG - 2022-06-23 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:59:09 --> Total execution time: 0.0674
DEBUG - 2022-06-23 09:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:59:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 09:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:59:10 --> Total execution time: 0.0551
DEBUG - 2022-06-23 09:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:15 --> Total execution time: 0.0319
DEBUG - 2022-06-23 09:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:22 --> Total execution time: 0.0434
DEBUG - 2022-06-23 09:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:36 --> Total execution time: 0.0509
DEBUG - 2022-06-23 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:38 --> Total execution time: 0.0504
DEBUG - 2022-06-23 09:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:49 --> Total execution time: 0.1006
DEBUG - 2022-06-23 09:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:56 --> Total execution time: 0.0459
DEBUG - 2022-06-23 09:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 09:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:00:57 --> Total execution time: 0.0413
DEBUG - 2022-06-23 09:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:31:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 09:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:01:21 --> Total execution time: 0.0472
DEBUG - 2022-06-23 09:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:01:24 --> Total execution time: 0.0911
DEBUG - 2022-06-23 09:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:31:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 09:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:33:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 09:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:03:23 --> Total execution time: 0.0621
DEBUG - 2022-06-23 09:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:06:28 --> Total execution time: 0.0853
DEBUG - 2022-06-23 09:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:36:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:06:47 --> Total execution time: 0.0341
DEBUG - 2022-06-23 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:07:01 --> Total execution time: 0.0828
DEBUG - 2022-06-23 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:07:07 --> Total execution time: 0.0321
DEBUG - 2022-06-23 09:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:07:29 --> Total execution time: 0.0428
DEBUG - 2022-06-23 09:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:07:46 --> Total execution time: 0.0617
DEBUG - 2022-06-23 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:07:54 --> Total execution time: 0.0682
DEBUG - 2022-06-23 09:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:08:00 --> Total execution time: 0.0683
DEBUG - 2022-06-23 09:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:08:03 --> Total execution time: 0.0740
DEBUG - 2022-06-23 09:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:08:10 --> Total execution time: 0.0447
DEBUG - 2022-06-23 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:08:13 --> Total execution time: 0.0444
DEBUG - 2022-06-23 09:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:12:35 --> Total execution time: 0.0770
DEBUG - 2022-06-23 09:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:12:44 --> Total execution time: 0.0521
DEBUG - 2022-06-23 09:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:43:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:13:12 --> Total execution time: 0.0782
DEBUG - 2022-06-23 09:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:43:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:13:23 --> Total execution time: 0.0956
DEBUG - 2022-06-23 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:13:52 --> Total execution time: 0.0501
DEBUG - 2022-06-23 09:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:14:43 --> Total execution time: 0.0501
DEBUG - 2022-06-23 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:14:47 --> Total execution time: 0.0433
DEBUG - 2022-06-23 09:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:44:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:14:56 --> Total execution time: 0.0446
DEBUG - 2022-06-23 09:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:15:00 --> Total execution time: 0.0476
DEBUG - 2022-06-23 09:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:15:07 --> Total execution time: 0.0500
DEBUG - 2022-06-23 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:15:17 --> Total execution time: 0.0498
DEBUG - 2022-06-23 09:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:15:27 --> Total execution time: 0.0539
DEBUG - 2022-06-23 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:16:56 --> Total execution time: 0.0464
DEBUG - 2022-06-23 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:17:21 --> Total execution time: 0.0485
DEBUG - 2022-06-23 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:17:26 --> Total execution time: 0.1048
DEBUG - 2022-06-23 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:17:43 --> Total execution time: 0.1090
DEBUG - 2022-06-23 09:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:15 --> Total execution time: 0.0681
DEBUG - 2022-06-23 09:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:20 --> Total execution time: 0.0513
DEBUG - 2022-06-23 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:23 --> Total execution time: 0.1308
DEBUG - 2022-06-23 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:28 --> Total execution time: 0.0432
DEBUG - 2022-06-23 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:29 --> Total execution time: 0.1454
DEBUG - 2022-06-23 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:38 --> Total execution time: 0.0448
DEBUG - 2022-06-23 09:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:48 --> Total execution time: 0.0450
DEBUG - 2022-06-23 09:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:18:55 --> Total execution time: 0.0731
DEBUG - 2022-06-23 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:00 --> Total execution time: 0.0474
DEBUG - 2022-06-23 09:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:09 --> Total execution time: 0.0333
DEBUG - 2022-06-23 09:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:20 --> Total execution time: 0.0428
DEBUG - 2022-06-23 09:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:25 --> Total execution time: 0.0496
DEBUG - 2022-06-23 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:26 --> Total execution time: 0.0473
DEBUG - 2022-06-23 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:29 --> Total execution time: 0.0506
DEBUG - 2022-06-23 09:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:30 --> Total execution time: 0.0489
DEBUG - 2022-06-23 09:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:33 --> Total execution time: 0.0527
DEBUG - 2022-06-23 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:35 --> Total execution time: 0.0462
DEBUG - 2022-06-23 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:36 --> Total execution time: 0.0537
DEBUG - 2022-06-23 09:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:38 --> Total execution time: 0.0557
DEBUG - 2022-06-23 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:40 --> Total execution time: 0.0659
DEBUG - 2022-06-23 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:43 --> Total execution time: 0.0588
DEBUG - 2022-06-23 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:44 --> Total execution time: 0.0544
DEBUG - 2022-06-23 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:51 --> Total execution time: 0.0693
DEBUG - 2022-06-23 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:51 --> Total execution time: 0.0445
DEBUG - 2022-06-23 09:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:19:59 --> Total execution time: 0.0452
DEBUG - 2022-06-23 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:01 --> Total execution time: 0.0511
DEBUG - 2022-06-23 09:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:03 --> Total execution time: 0.1027
DEBUG - 2022-06-23 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:04 --> Total execution time: 0.0484
DEBUG - 2022-06-23 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:04 --> Total execution time: 0.0658
DEBUG - 2022-06-23 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:04 --> Total execution time: 0.0494
DEBUG - 2022-06-23 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:05 --> Total execution time: 0.0991
DEBUG - 2022-06-23 09:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:27 --> Total execution time: 0.0293
DEBUG - 2022-06-23 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:35 --> Total execution time: 0.0507
DEBUG - 2022-06-23 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:42 --> Total execution time: 0.0491
DEBUG - 2022-06-23 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:20:46 --> Total execution time: 0.0471
DEBUG - 2022-06-23 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:52:27 --> Total execution time: 0.0463
DEBUG - 2022-06-23 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:52:28 --> Total execution time: 0.0426
DEBUG - 2022-06-23 09:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:52:28 --> Total execution time: 0.0811
DEBUG - 2022-06-23 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:52:36 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:22:36 --> Total execution time: 0.0474
DEBUG - 2022-06-23 09:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:22:41 --> Total execution time: 0.0584
DEBUG - 2022-06-23 09:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:23:35 --> Total execution time: 0.0426
DEBUG - 2022-06-23 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:24:05 --> Total execution time: 0.0445
DEBUG - 2022-06-23 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:24:15 --> Total execution time: 0.1308
DEBUG - 2022-06-23 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:24:42 --> Total execution time: 0.0458
DEBUG - 2022-06-23 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:24:47 --> Total execution time: 0.0596
DEBUG - 2022-06-23 09:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:25:14 --> Total execution time: 0.0479
DEBUG - 2022-06-23 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:25:30 --> Total execution time: 0.0889
DEBUG - 2022-06-23 09:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:55:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:25:47 --> Total execution time: 0.1209
DEBUG - 2022-06-23 09:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:26:00 --> Total execution time: 0.0487
DEBUG - 2022-06-23 09:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:26:12 --> Total execution time: 0.0425
DEBUG - 2022-06-23 09:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:23 --> Total execution time: 0.0480
DEBUG - 2022-06-23 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:26:34 --> Total execution time: 0.1071
DEBUG - 2022-06-23 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:36 --> Total execution time: 0.0427
DEBUG - 2022-06-23 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:41 --> Total execution time: 0.0450
DEBUG - 2022-06-23 09:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:56:42 --> Total execution time: 0.0499
DEBUG - 2022-06-23 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 09:56:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:26:53 --> Total execution time: 0.0562
DEBUG - 2022-06-23 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:26:55 --> Total execution time: 0.0363
DEBUG - 2022-06-23 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:27:02 --> Total execution time: 0.0555
DEBUG - 2022-06-23 09:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:57:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:27:05 --> Total execution time: 0.0654
DEBUG - 2022-06-23 09:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:27:13 --> Total execution time: 0.0408
DEBUG - 2022-06-23 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:27:17 --> Total execution time: 0.0419
DEBUG - 2022-06-23 09:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:57:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:27:19 --> Total execution time: 0.0459
DEBUG - 2022-06-23 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:57:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:27:30 --> Total execution time: 0.0445
DEBUG - 2022-06-23 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:58:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:28:09 --> Total execution time: 0.1765
DEBUG - 2022-06-23 09:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:28:10 --> Total execution time: 0.1055
DEBUG - 2022-06-23 09:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:58:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:28:11 --> Total execution time: 0.0484
DEBUG - 2022-06-23 09:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:58:25 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:28:25 --> Total execution time: 0.1233
DEBUG - 2022-06-23 09:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:59:18 --> Total execution time: 0.1193
DEBUG - 2022-06-23 09:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:59:42 --> Total execution time: 0.0474
DEBUG - 2022-06-23 09:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:59:42 --> Total execution time: 0.0737
DEBUG - 2022-06-23 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:29:44 --> Total execution time: 0.0726
DEBUG - 2022-06-23 09:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:29:49 --> Total execution time: 0.0709
DEBUG - 2022-06-23 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:29:55 --> Total execution time: 0.0808
DEBUG - 2022-06-23 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:03 --> Total execution time: 0.1213
DEBUG - 2022-06-23 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:09 --> Total execution time: 0.2581
DEBUG - 2022-06-23 10:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:20 --> Total execution time: 0.1008
DEBUG - 2022-06-23 10:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:32 --> Total execution time: 0.0893
DEBUG - 2022-06-23 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:33 --> Total execution time: 0.0662
DEBUG - 2022-06-23 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:34 --> Total execution time: 0.0869
DEBUG - 2022-06-23 10:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:34 --> Total execution time: 0.1668
DEBUG - 2022-06-23 10:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:36 --> Total execution time: 0.1646
DEBUG - 2022-06-23 10:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:36 --> Total execution time: 0.0809
DEBUG - 2022-06-23 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:38 --> Total execution time: 0.0832
DEBUG - 2022-06-23 10:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:00:38 --> Total execution time: 0.1657
DEBUG - 2022-06-23 10:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:39 --> Total execution time: 0.0972
DEBUG - 2022-06-23 10:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:42 --> Total execution time: 0.0938
DEBUG - 2022-06-23 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:45 --> Total execution time: 0.0794
DEBUG - 2022-06-23 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:47 --> Total execution time: 0.1622
DEBUG - 2022-06-23 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:52 --> Total execution time: 0.1720
DEBUG - 2022-06-23 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:02 --> Total execution time: 0.0785
DEBUG - 2022-06-23 10:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:24 --> Total execution time: 0.1294
DEBUG - 2022-06-23 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:28 --> Total execution time: 0.0744
DEBUG - 2022-06-23 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:53 --> Total execution time: 0.1260
DEBUG - 2022-06-23 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:00 --> Total execution time: 0.3600
DEBUG - 2022-06-23 10:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:07 --> Total execution time: 0.0592
DEBUG - 2022-06-23 10:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:08 --> Total execution time: 0.1305
DEBUG - 2022-06-23 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:21 --> Total execution time: 0.0935
DEBUG - 2022-06-23 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:23 --> Total execution time: 0.0940
DEBUG - 2022-06-23 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:33 --> Total execution time: 0.0785
DEBUG - 2022-06-23 10:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:33 --> Total execution time: 0.1188
DEBUG - 2022-06-23 10:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:42 --> Total execution time: 0.0936
DEBUG - 2022-06-23 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:51 --> Total execution time: 0.2005
DEBUG - 2022-06-23 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:32:55 --> Total execution time: 0.0785
DEBUG - 2022-06-23 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:04 --> Total execution time: 0.1649
DEBUG - 2022-06-23 10:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:12 --> Total execution time: 0.1709
DEBUG - 2022-06-23 10:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:25 --> Total execution time: 0.2270
DEBUG - 2022-06-23 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:26 --> Total execution time: 0.0671
DEBUG - 2022-06-23 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:38 --> Total execution time: 0.1454
DEBUG - 2022-06-23 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:43 --> Total execution time: 0.0548
DEBUG - 2022-06-23 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:53 --> Total execution time: 0.0999
DEBUG - 2022-06-23 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:59 --> Total execution time: 0.1595
DEBUG - 2022-06-23 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:03:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:33:59 --> Total execution time: 0.1400
DEBUG - 2022-06-23 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:01 --> Total execution time: 0.2026
DEBUG - 2022-06-23 10:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:05 --> Total execution time: 0.0804
DEBUG - 2022-06-23 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:12 --> Total execution time: 0.0516
DEBUG - 2022-06-23 10:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:17 --> Total execution time: 0.0749
DEBUG - 2022-06-23 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:21 --> Total execution time: 0.1494
DEBUG - 2022-06-23 10:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:28 --> Total execution time: 0.0542
DEBUG - 2022-06-23 10:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:04:33 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 10:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:38 --> Total execution time: 0.0481
DEBUG - 2022-06-23 10:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:34:57 --> Total execution time: 0.0562
DEBUG - 2022-06-23 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:35:11 --> Total execution time: 0.1066
DEBUG - 2022-06-23 10:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:35:25 --> Total execution time: 0.0796
DEBUG - 2022-06-23 10:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:35:52 --> Total execution time: 0.0595
DEBUG - 2022-06-23 10:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:35:57 --> Total execution time: 0.1634
DEBUG - 2022-06-23 10:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:09 --> Total execution time: 0.0991
DEBUG - 2022-06-23 10:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:22 --> Total execution time: 0.0490
DEBUG - 2022-06-23 10:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:27 --> Total execution time: 0.0870
DEBUG - 2022-06-23 10:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:31 --> Total execution time: 0.0474
DEBUG - 2022-06-23 10:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:42 --> Total execution time: 0.1297
DEBUG - 2022-06-23 10:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:44 --> Total execution time: 0.1976
DEBUG - 2022-06-23 10:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:36:51 --> Total execution time: 0.0493
DEBUG - 2022-06-23 10:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:38:55 --> Total execution time: 0.0998
DEBUG - 2022-06-23 10:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:39:06 --> Total execution time: 0.0980
DEBUG - 2022-06-23 10:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:39:11 --> Total execution time: 0.1025
DEBUG - 2022-06-23 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:39:13 --> Total execution time: 0.0544
DEBUG - 2022-06-23 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:39:30 --> Total execution time: 0.1006
DEBUG - 2022-06-23 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:43:49 --> Total execution time: 0.0961
DEBUG - 2022-06-23 10:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:13 --> Total execution time: 0.0359
DEBUG - 2022-06-23 10:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:18 --> Total execution time: 0.1149
DEBUG - 2022-06-23 10:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:20 --> Total execution time: 0.0467
DEBUG - 2022-06-23 10:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:26 --> Total execution time: 0.0439
DEBUG - 2022-06-23 10:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:31 --> Total execution time: 0.0767
DEBUG - 2022-06-23 10:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:32 --> Total execution time: 0.0486
DEBUG - 2022-06-23 10:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:36 --> Total execution time: 0.0488
DEBUG - 2022-06-23 10:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:53 --> Total execution time: 0.0828
DEBUG - 2022-06-23 10:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:15:55 --> Total execution time: 0.0344
DEBUG - 2022-06-23 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:15:57 --> Total execution time: 0.0484
DEBUG - 2022-06-23 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:15:57 --> Total execution time: 0.0752
DEBUG - 2022-06-23 10:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:16:02 --> Total execution time: 0.0655
DEBUG - 2022-06-23 10:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:16:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:46:13 --> Total execution time: 0.0499
DEBUG - 2022-06-23 10:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:16:30 --> Total execution time: 0.0681
DEBUG - 2022-06-23 10:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:16:30 --> Total execution time: 0.1351
DEBUG - 2022-06-23 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:17:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:47:20 --> Total execution time: 1.9701
DEBUG - 2022-06-23 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:17:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:47:38 --> Total execution time: 1.4667
DEBUG - 2022-06-23 10:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:17:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:47:42 --> Total execution time: 0.0331
DEBUG - 2022-06-23 10:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:18:48 --> Total execution time: 0.0440
DEBUG - 2022-06-23 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:18:52 --> Total execution time: 0.0434
DEBUG - 2022-06-23 10:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:18:52 --> Total execution time: 0.1001
DEBUG - 2022-06-23 10:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:19:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:49:06 --> Total execution time: 0.0586
DEBUG - 2022-06-23 10:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:51:13 --> Total execution time: 0.1148
DEBUG - 2022-06-23 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:51:47 --> Total execution time: 0.1018
DEBUG - 2022-06-23 10:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:52:12 --> Total execution time: 0.0565
DEBUG - 2022-06-23 10:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:22:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:52:30 --> Total execution time: 0.1017
DEBUG - 2022-06-23 10:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:52:35 --> Total execution time: 0.0432
DEBUG - 2022-06-23 10:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:52:53 --> Total execution time: 0.0520
DEBUG - 2022-06-23 10:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:53:00 --> Total execution time: 0.0472
DEBUG - 2022-06-23 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:08 --> Total execution time: 0.0712
DEBUG - 2022-06-23 10:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:10 --> Total execution time: 0.0499
DEBUG - 2022-06-23 10:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:10 --> Total execution time: 0.0919
DEBUG - 2022-06-23 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:19 --> Total execution time: 0.0760
DEBUG - 2022-06-23 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:53:49 --> Total execution time: 0.0662
DEBUG - 2022-06-23 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:55 --> Total execution time: 0.0530
DEBUG - 2022-06-23 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:57 --> Total execution time: 0.0492
DEBUG - 2022-06-23 10:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:23:57 --> Total execution time: 0.0847
DEBUG - 2022-06-23 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:24:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:54:06 --> Total execution time: 0.0346
DEBUG - 2022-06-23 10:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:54:32 --> Total execution time: 0.1196
DEBUG - 2022-06-23 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:54:50 --> Total execution time: 0.0565
DEBUG - 2022-06-23 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:24:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:54:51 --> Total execution time: 0.0512
DEBUG - 2022-06-23 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:24:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:54:55 --> Total execution time: 0.0632
DEBUG - 2022-06-23 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:55:01 --> Total execution time: 1.5402
DEBUG - 2022-06-23 10:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:25:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 10:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:55:34 --> Total execution time: 0.1055
DEBUG - 2022-06-23 10:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:25:43 --> Total execution time: 0.0946
DEBUG - 2022-06-23 10:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:25:48 --> Total execution time: 0.0430
DEBUG - 2022-06-23 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:25:57 --> Total execution time: 0.0459
DEBUG - 2022-06-23 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:25:57 --> Total execution time: 0.0483
DEBUG - 2022-06-23 10:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:25:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:55:58 --> Total execution time: 0.0398
DEBUG - 2022-06-23 10:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:28:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:58:38 --> Total execution time: 0.0864
DEBUG - 2022-06-23 10:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:28:45 --> Total execution time: 0.0445
DEBUG - 2022-06-23 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:28:48 --> Total execution time: 0.0493
DEBUG - 2022-06-23 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:28:48 --> Total execution time: 0.0834
DEBUG - 2022-06-23 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:29:23 --> Total execution time: 0.0973
DEBUG - 2022-06-23 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:29:25 --> Total execution time: 0.0471
DEBUG - 2022-06-23 10:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:29:25 --> Total execution time: 0.0929
DEBUG - 2022-06-23 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:59:56 --> Total execution time: 0.0691
DEBUG - 2022-06-23 10:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:02 --> Total execution time: 0.0673
DEBUG - 2022-06-23 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:09 --> Total execution time: 0.1232
DEBUG - 2022-06-23 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:16 --> Total execution time: 0.1170
DEBUG - 2022-06-23 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:18 --> Total execution time: 1.7485
DEBUG - 2022-06-23 10:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:21 --> Total execution time: 0.0711
DEBUG - 2022-06-23 10:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:33 --> Total execution time: 0.0469
DEBUG - 2022-06-23 10:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:40 --> Total execution time: 1.4307
DEBUG - 2022-06-23 10:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:30:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 10:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:04 --> Total execution time: 0.0527
DEBUG - 2022-06-23 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:11 --> Total execution time: 0.0457
DEBUG - 2022-06-23 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:16 --> Total execution time: 0.0686
DEBUG - 2022-06-23 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:20 --> Total execution time: 0.0731
DEBUG - 2022-06-23 10:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:25 --> Total execution time: 0.0453
DEBUG - 2022-06-23 10:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:27 --> Total execution time: 0.0620
DEBUG - 2022-06-23 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:29 --> Total execution time: 0.0467
DEBUG - 2022-06-23 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:31 --> Total execution time: 0.0571
DEBUG - 2022-06-23 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:35 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:35 --> Total execution time: 0.0532
DEBUG - 2022-06-23 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:36 --> Total execution time: 0.0764
DEBUG - 2022-06-23 10:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:46 --> Total execution time: 0.0486
DEBUG - 2022-06-23 10:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:49 --> Total execution time: 0.0728
DEBUG - 2022-06-23 10:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:31:50 --> Total execution time: 0.0590
DEBUG - 2022-06-23 10:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:57 --> Total execution time: 0.0744
DEBUG - 2022-06-23 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:32:02 --> Total execution time: 0.0505
DEBUG - 2022-06-23 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:32:02 --> Total execution time: 0.0899
DEBUG - 2022-06-23 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:02:06 --> Total execution time: 0.0517
DEBUG - 2022-06-23 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:02:28 --> Total execution time: 0.0442
DEBUG - 2022-06-23 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:02:37 --> Total execution time: 0.0673
DEBUG - 2022-06-23 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:02:44 --> Total execution time: 0.0717
DEBUG - 2022-06-23 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:02:46 --> Total execution time: 0.0451
DEBUG - 2022-06-23 10:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:02:49 --> Total execution time: 0.1173
DEBUG - 2022-06-23 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:03:25 --> Total execution time: 0.0629
DEBUG - 2022-06-23 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:34:35 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:04:36 --> Total execution time: 0.0329
DEBUG - 2022-06-23 10:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:34:55 --> Total execution time: 0.0707
DEBUG - 2022-06-23 10:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:35:06 --> Total execution time: 0.0646
DEBUG - 2022-06-23 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:05:16 --> Total execution time: 0.0511
DEBUG - 2022-06-23 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:05:35 --> Total execution time: 0.0724
DEBUG - 2022-06-23 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:06:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:06:34 --> Total execution time: 0.0534
DEBUG - 2022-06-23 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:36:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:06:39 --> Total execution time: 0.0322
DEBUG - 2022-06-23 10:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:36:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:06:58 --> Total execution time: 0.0976
DEBUG - 2022-06-23 10:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:07:06 --> Total execution time: 0.0973
DEBUG - 2022-06-23 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:07:10 --> Total execution time: 0.0290
DEBUG - 2022-06-23 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:07:37 --> Total execution time: 0.0437
DEBUG - 2022-06-23 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:08:13 --> Total execution time: 0.0351
DEBUG - 2022-06-23 10:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:08:18 --> Total execution time: 0.0485
DEBUG - 2022-06-23 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:08:19 --> Total execution time: 0.0499
DEBUG - 2022-06-23 10:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:08:46 --> Total execution time: 0.0410
DEBUG - 2022-06-23 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:50 --> Total execution time: 0.0534
DEBUG - 2022-06-23 10:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:08:56 --> Total execution time: 0.0556
DEBUG - 2022-06-23 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:38:59 --> Total execution time: 0.0569
DEBUG - 2022-06-23 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:01 --> Total execution time: 0.0289
DEBUG - 2022-06-23 10:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:08 --> Total execution time: 0.0433
DEBUG - 2022-06-23 10:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:39:19 --> Total execution time: 0.0722
DEBUG - 2022-06-23 10:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:39:21 --> Total execution time: 0.0439
DEBUG - 2022-06-23 10:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:39:21 --> Total execution time: 0.1010
DEBUG - 2022-06-23 10:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:29 --> Total execution time: 0.0456
DEBUG - 2022-06-23 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:37 --> Total execution time: 0.0482
DEBUG - 2022-06-23 10:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:45 --> Total execution time: 0.0488
DEBUG - 2022-06-23 10:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:46 --> Total execution time: 0.0446
DEBUG - 2022-06-23 10:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:50 --> Total execution time: 0.0642
DEBUG - 2022-06-23 10:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:09:51 --> Total execution time: 0.0452
DEBUG - 2022-06-23 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:10:15 --> Total execution time: 0.0415
DEBUG - 2022-06-23 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:10:40 --> Total execution time: 0.0574
DEBUG - 2022-06-23 10:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:10:48 --> Total execution time: 0.0435
DEBUG - 2022-06-23 10:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:10 --> Total execution time: 0.0536
DEBUG - 2022-06-23 10:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:31 --> Total execution time: 0.1037
DEBUG - 2022-06-23 10:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:36 --> Total execution time: 0.0651
DEBUG - 2022-06-23 10:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:37 --> Total execution time: 0.0518
DEBUG - 2022-06-23 10:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:37 --> Total execution time: 0.0916
DEBUG - 2022-06-23 10:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:39 --> Total execution time: 0.0526
DEBUG - 2022-06-23 10:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:44 --> Total execution time: 0.0729
DEBUG - 2022-06-23 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:51 --> Total execution time: 0.0390
DEBUG - 2022-06-23 10:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:58 --> Total execution time: 0.0376
DEBUG - 2022-06-23 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:06 --> Total execution time: 0.0521
DEBUG - 2022-06-23 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:11 --> Total execution time: 0.0554
DEBUG - 2022-06-23 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:19 --> Total execution time: 0.0511
DEBUG - 2022-06-23 10:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:40 --> Total execution time: 0.0501
DEBUG - 2022-06-23 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:47 --> Total execution time: 0.1043
DEBUG - 2022-06-23 10:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:48 --> Total execution time: 0.0436
DEBUG - 2022-06-23 10:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:42:58 --> Total execution time: 0.0466
DEBUG - 2022-06-23 10:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:12:59 --> Total execution time: 0.0525
DEBUG - 2022-06-23 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:03 --> Total execution time: 0.0481
DEBUG - 2022-06-23 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:03 --> Total execution time: 0.0663
DEBUG - 2022-06-23 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:09 --> Total execution time: 0.1019
DEBUG - 2022-06-23 10:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:10 --> Total execution time: 0.0459
DEBUG - 2022-06-23 10:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:17 --> Total execution time: 0.0625
DEBUG - 2022-06-23 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:18 --> Total execution time: 0.0546
DEBUG - 2022-06-23 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:18 --> Total execution time: 0.0861
DEBUG - 2022-06-23 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:20 --> Total execution time: 0.0759
DEBUG - 2022-06-23 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:20 --> Total execution time: 0.0629
DEBUG - 2022-06-23 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:23 --> Total execution time: 0.0604
DEBUG - 2022-06-23 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:28 --> Total execution time: 0.0432
DEBUG - 2022-06-23 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:36 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:36 --> Total execution time: 0.0993
DEBUG - 2022-06-23 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:42 --> Total execution time: 0.0407
DEBUG - 2022-06-23 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:47 --> Total execution time: 0.0448
DEBUG - 2022-06-23 10:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:48 --> Total execution time: 0.0454
DEBUG - 2022-06-23 10:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:43:49 --> Total execution time: 0.0922
DEBUG - 2022-06-23 10:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:13:51 --> Total execution time: 0.0372
DEBUG - 2022-06-23 10:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:00 --> Total execution time: 0.0427
DEBUG - 2022-06-23 10:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:14:24 --> Total execution time: 0.0452
DEBUG - 2022-06-23 10:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:14:26 --> Total execution time: 0.0414
DEBUG - 2022-06-23 10:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:14:30 --> Total execution time: 0.0506
DEBUG - 2022-06-23 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:03 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:15:03 --> Total execution time: 0.0465
DEBUG - 2022-06-23 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:15:16 --> Total execution time: 0.0534
DEBUG - 2022-06-23 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:15:24 --> Total execution time: 0.0519
DEBUG - 2022-06-23 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:15:35 --> Total execution time: 0.0464
DEBUG - 2022-06-23 10:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:15:55 --> Total execution time: 0.0561
DEBUG - 2022-06-23 10:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:15:59 --> Total execution time: 0.0437
DEBUG - 2022-06-23 10:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:05 --> Total execution time: 0.0413
DEBUG - 2022-06-23 10:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:12 --> Total execution time: 0.0362
DEBUG - 2022-06-23 10:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:23 --> Total execution time: 0.0446
DEBUG - 2022-06-23 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:29 --> Total execution time: 0.1030
DEBUG - 2022-06-23 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:29 --> Total execution time: 0.0420
DEBUG - 2022-06-23 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:31 --> Total execution time: 0.0457
DEBUG - 2022-06-23 10:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:31 --> Total execution time: 0.1204
DEBUG - 2022-06-23 10:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:35 --> Total execution time: 1.9370
DEBUG - 2022-06-23 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:46:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 10:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:44 --> Total execution time: 0.0427
DEBUG - 2022-06-23 10:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:16:45 --> Total execution time: 0.0447
DEBUG - 2022-06-23 10:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:47 --> Total execution time: 0.0446
DEBUG - 2022-06-23 10:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:49 --> Total execution time: 0.0650
DEBUG - 2022-06-23 10:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:49 --> Total execution time: 0.1017
DEBUG - 2022-06-23 10:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:46:58 --> Total execution time: 0.0429
DEBUG - 2022-06-23 10:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:08 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:08 --> Total execution time: 0.1027
DEBUG - 2022-06-23 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:13 --> Total execution time: 0.0427
DEBUG - 2022-06-23 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:13 --> Total execution time: 0.0425
DEBUG - 2022-06-23 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:14 --> Total execution time: 0.0418
DEBUG - 2022-06-23 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:14 --> Total execution time: 0.1010
DEBUG - 2022-06-23 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:23 --> Total execution time: 0.0447
DEBUG - 2022-06-23 10:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:31 --> Total execution time: 0.0414
DEBUG - 2022-06-23 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:37 --> Total execution time: 0.0445
DEBUG - 2022-06-23 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:37 --> Total execution time: 0.0569
DEBUG - 2022-06-23 10:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:44 --> Total execution time: 0.0499
DEBUG - 2022-06-23 10:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:45 --> Total execution time: 0.0442
DEBUG - 2022-06-23 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:49 --> Total execution time: 0.0473
DEBUG - 2022-06-23 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:51 --> Total execution time: 0.0522
DEBUG - 2022-06-23 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:47:51 --> Total execution time: 0.1007
DEBUG - 2022-06-23 10:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:47:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:17:58 --> Total execution time: 0.0601
DEBUG - 2022-06-23 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:02 --> Total execution time: 0.0502
DEBUG - 2022-06-23 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:02 --> Total execution time: 0.0506
DEBUG - 2022-06-23 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:16 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:16 --> Total execution time: 0.0451
DEBUG - 2022-06-23 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:16 --> Total execution time: 0.0540
DEBUG - 2022-06-23 10:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:19 --> Total execution time: 0.0479
DEBUG - 2022-06-23 10:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:19 --> Total execution time: 0.0971
DEBUG - 2022-06-23 10:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:19 --> Total execution time: 0.0442
DEBUG - 2022-06-23 10:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:25 --> Total execution time: 0.0634
DEBUG - 2022-06-23 10:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:26 --> Total execution time: 0.1114
DEBUG - 2022-06-23 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:27 --> Total execution time: 0.0546
DEBUG - 2022-06-23 10:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:27 --> Total execution time: 0.0463
DEBUG - 2022-06-23 10:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:48:27 --> Total execution time: 0.1371
DEBUG - 2022-06-23 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:38 --> Total execution time: 0.1102
DEBUG - 2022-06-23 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:48:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:18:44 --> Total execution time: 0.0527
DEBUG - 2022-06-23 10:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:04 --> Total execution time: 0.2078
DEBUG - 2022-06-23 10:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:06 --> Total execution time: 0.0542
DEBUG - 2022-06-23 10:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:09 --> Total execution time: 0.0487
DEBUG - 2022-06-23 10:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:10 --> Total execution time: 0.0453
DEBUG - 2022-06-23 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:12 --> Total execution time: 0.0514
DEBUG - 2022-06-23 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:12 --> Total execution time: 0.0501
DEBUG - 2022-06-23 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:13 --> Total execution time: 0.0485
DEBUG - 2022-06-23 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:13 --> Total execution time: 0.0823
DEBUG - 2022-06-23 21:19:14 --> Total execution time: 1.5184
DEBUG - 2022-06-23 10:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:49:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:20 --> Total execution time: 0.0419
DEBUG - 2022-06-23 10:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:21 --> Total execution time: 0.0561
DEBUG - 2022-06-23 10:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:21 --> Total execution time: 0.1163
DEBUG - 2022-06-23 10:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:39 --> Total execution time: 0.0559
DEBUG - 2022-06-23 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:46 --> Total execution time: 0.0483
DEBUG - 2022-06-23 10:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:49:51 --> Total execution time: 0.0432
DEBUG - 2022-06-23 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:52 --> Total execution time: 0.0598
DEBUG - 2022-06-23 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:54 --> Total execution time: 0.0431
DEBUG - 2022-06-23 10:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:49:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:19:55 --> Total execution time: 0.0514
DEBUG - 2022-06-23 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:00 --> Total execution time: 0.0487
DEBUG - 2022-06-23 10:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:04 --> Total execution time: 0.0703
DEBUG - 2022-06-23 10:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:05 --> Total execution time: 0.0483
DEBUG - 2022-06-23 10:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:05 --> Total execution time: 0.0493
DEBUG - 2022-06-23 10:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:05 --> Total execution time: 0.0825
DEBUG - 2022-06-23 10:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:08 --> Total execution time: 0.0462
DEBUG - 2022-06-23 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:10 --> Total execution time: 0.0450
DEBUG - 2022-06-23 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:12 --> Total execution time: 0.0495
DEBUG - 2022-06-23 10:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:15 --> Total execution time: 0.0480
DEBUG - 2022-06-23 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:24 --> Total execution time: 0.0431
DEBUG - 2022-06-23 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:28 --> Total execution time: 0.0511
DEBUG - 2022-06-23 10:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:30 --> Total execution time: 0.0482
DEBUG - 2022-06-23 10:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:42 --> Total execution time: 0.1078
DEBUG - 2022-06-23 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:59 --> Total execution time: 0.0549
DEBUG - 2022-06-23 10:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:21:39 --> Total execution time: 0.0413
DEBUG - 2022-06-23 10:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:22:18 --> Total execution time: 0.0737
DEBUG - 2022-06-23 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:22:22 --> Total execution time: 0.0476
DEBUG - 2022-06-23 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:22:47 --> Total execution time: 0.1258
DEBUG - 2022-06-23 10:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:22:54 --> Total execution time: 0.0480
DEBUG - 2022-06-23 10:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:22:57 --> Total execution time: 0.0677
DEBUG - 2022-06-23 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:09 --> Total execution time: 0.0510
DEBUG - 2022-06-23 10:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:10 --> Total execution time: 0.0882
DEBUG - 2022-06-23 10:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:19 --> Total execution time: 0.0453
DEBUG - 2022-06-23 10:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:22 --> Total execution time: 0.0589
DEBUG - 2022-06-23 10:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:29 --> Total execution time: 0.0563
DEBUG - 2022-06-23 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:34 --> Total execution time: 0.0625
DEBUG - 2022-06-23 10:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:23:36 --> Total execution time: 0.0483
DEBUG - 2022-06-23 10:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:24:56 --> Total execution time: 0.0573
DEBUG - 2022-06-23 10:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:24:56 --> Total execution time: 0.0835
DEBUG - 2022-06-23 10:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:55:02 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:25:02 --> Total execution time: 0.1311
DEBUG - 2022-06-23 10:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:55:41 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:25:41 --> Total execution time: 0.1061
DEBUG - 2022-06-23 10:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:56:16 --> Total execution time: 0.0517
DEBUG - 2022-06-23 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:56:19 --> Total execution time: 0.0502
DEBUG - 2022-06-23 10:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:56:20 --> Total execution time: 0.0890
DEBUG - 2022-06-23 10:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:56:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 10:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 10:56:53 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 10:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:01 --> Total execution time: 0.0480
DEBUG - 2022-06-23 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:09 --> Total execution time: 0.0582
DEBUG - 2022-06-23 10:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:12 --> No URI present. Default controller set.
DEBUG - 2022-06-23 10:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:12 --> Total execution time: 0.0440
DEBUG - 2022-06-23 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:23 --> Total execution time: 0.0413
DEBUG - 2022-06-23 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:46 --> Total execution time: 0.0532
DEBUG - 2022-06-23 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:46 --> Total execution time: 0.0374
DEBUG - 2022-06-23 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:52 --> Total execution time: 0.0510
DEBUG - 2022-06-23 10:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:08 --> Total execution time: 0.0598
DEBUG - 2022-06-23 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:28 --> Total execution time: 0.0487
DEBUG - 2022-06-23 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:28 --> Total execution time: 0.0479
DEBUG - 2022-06-23 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:29 --> Total execution time: 0.0437
DEBUG - 2022-06-23 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:28:40 --> Total execution time: 0.0596
DEBUG - 2022-06-23 10:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:29:08 --> Total execution time: 0.0456
DEBUG - 2022-06-23 10:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 10:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:29:12 --> Total execution time: 0.0488
DEBUG - 2022-06-23 10:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:29:45 --> Total execution time: 0.0532
DEBUG - 2022-06-23 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:01 --> Total execution time: 0.1006
DEBUG - 2022-06-23 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:02 --> Total execution time: 0.0967
DEBUG - 2022-06-23 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:21 --> Total execution time: 0.0749
DEBUG - 2022-06-23 11:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:32 --> Total execution time: 0.0504
DEBUG - 2022-06-23 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:54 --> Total execution time: 0.1119
DEBUG - 2022-06-23 11:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:57 --> Total execution time: 0.0483
DEBUG - 2022-06-23 11:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:57 --> Total execution time: 0.0477
DEBUG - 2022-06-23 11:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:31:09 --> Total execution time: 0.0647
DEBUG - 2022-06-23 11:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:31:26 --> Total execution time: 0.1336
DEBUG - 2022-06-23 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:31:48 --> Total execution time: 0.0520
DEBUG - 2022-06-23 11:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:31:51 --> Total execution time: 0.0487
DEBUG - 2022-06-23 11:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:31:58 --> Total execution time: 0.0487
DEBUG - 2022-06-23 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:32:47 --> Total execution time: 0.1212
DEBUG - 2022-06-23 11:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:04:01 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:34:01 --> Total execution time: 0.0727
DEBUG - 2022-06-23 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:04:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:34:15 --> Total execution time: 0.1080
DEBUG - 2022-06-23 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:34:23 --> Total execution time: 0.0451
DEBUG - 2022-06-23 11:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:34:57 --> Total execution time: 0.0596
DEBUG - 2022-06-23 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:07 --> Total execution time: 0.1273
DEBUG - 2022-06-23 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:19 --> Total execution time: 0.0639
DEBUG - 2022-06-23 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:23 --> Total execution time: 0.0740
DEBUG - 2022-06-23 11:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:27 --> Total execution time: 0.0470
DEBUG - 2022-06-23 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:31 --> Total execution time: 0.1114
DEBUG - 2022-06-23 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:32 --> Total execution time: 0.0558
DEBUG - 2022-06-23 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:06:41 --> Total execution time: 0.0551
DEBUG - 2022-06-23 11:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:13 --> Total execution time: 0.0413
DEBUG - 2022-06-23 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:16 --> Total execution time: 0.0432
DEBUG - 2022-06-23 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:17 --> Total execution time: 0.0484
DEBUG - 2022-06-23 11:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:25 --> Total execution time: 0.0707
DEBUG - 2022-06-23 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:28 --> Total execution time: 0.0687
DEBUG - 2022-06-23 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:32 --> Total execution time: 0.0791
DEBUG - 2022-06-23 11:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:42 --> Total execution time: 0.0520
DEBUG - 2022-06-23 11:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:43 --> Total execution time: 0.0453
DEBUG - 2022-06-23 11:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:51 --> Total execution time: 0.0505
DEBUG - 2022-06-23 11:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:02 --> Total execution time: 0.0503
DEBUG - 2022-06-23 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:03 --> Total execution time: 0.0625
DEBUG - 2022-06-23 11:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:48 --> Total execution time: 0.0460
DEBUG - 2022-06-23 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 11:08:56 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:08 --> Total execution time: 0.0451
DEBUG - 2022-06-23 11:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:13 --> Total execution time: 0.0512
DEBUG - 2022-06-23 11:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:15 --> Total execution time: 0.0534
DEBUG - 2022-06-23 11:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:10:03 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:40:04 --> Total execution time: 0.1253
DEBUG - 2022-06-23 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:40:06 --> Total execution time: 0.0872
DEBUG - 2022-06-23 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:40:06 --> Total execution time: 0.0631
DEBUG - 2022-06-23 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:10:22 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:40:22 --> Total execution time: 0.0509
DEBUG - 2022-06-23 11:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:40:27 --> Total execution time: 0.0580
DEBUG - 2022-06-23 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:06 --> Total execution time: 1.9636
DEBUG - 2022-06-23 11:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:10 --> Total execution time: 0.0534
DEBUG - 2022-06-23 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 11:11:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 11:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 11:11:29 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 11:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:46 --> Total execution time: 0.1538
DEBUG - 2022-06-23 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:57 --> Total execution time: 0.0478
DEBUG - 2022-06-23 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:59 --> Total execution time: 0.0560
DEBUG - 2022-06-23 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:42:17 --> Total execution time: 1.6410
DEBUG - 2022-06-23 11:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:12:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:42:33 --> Total execution time: 0.1184
DEBUG - 2022-06-23 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:42:37 --> Total execution time: 0.0450
DEBUG - 2022-06-23 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:42:47 --> Total execution time: 0.0424
DEBUG - 2022-06-23 11:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:42:48 --> Total execution time: 0.0393
DEBUG - 2022-06-23 11:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:12:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:42:58 --> Total execution time: 0.0695
DEBUG - 2022-06-23 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:43:00 --> Total execution time: 0.0341
DEBUG - 2022-06-23 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:43:18 --> Total execution time: 0.0512
DEBUG - 2022-06-23 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:43:21 --> Total execution time: 0.0981
DEBUG - 2022-06-23 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:43:28 --> Total execution time: 1.4969
DEBUG - 2022-06-23 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:43:33 --> Total execution time: 0.1126
DEBUG - 2022-06-23 11:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 11:13:37 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:44:07 --> Total execution time: 0.0654
DEBUG - 2022-06-23 11:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:44:33 --> Total execution time: 0.0488
DEBUG - 2022-06-23 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:45:50 --> Total execution time: 0.1099
DEBUG - 2022-06-23 11:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:45:59 --> Total execution time: 0.0421
DEBUG - 2022-06-23 11:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:16:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:46:39 --> Total execution time: 0.0497
DEBUG - 2022-06-23 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:23 --> Total execution time: 0.0597
DEBUG - 2022-06-23 11:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:31 --> Total execution time: 0.0508
DEBUG - 2022-06-23 11:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:33 --> Total execution time: 0.1044
DEBUG - 2022-06-23 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:35 --> Total execution time: 0.0475
DEBUG - 2022-06-23 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:38 --> Total execution time: 0.0991
DEBUG - 2022-06-23 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:40 --> Total execution time: 0.0664
DEBUG - 2022-06-23 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:45 --> Total execution time: 0.0528
DEBUG - 2022-06-23 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:46 --> Total execution time: 0.1038
DEBUG - 2022-06-23 11:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:51 --> Total execution time: 0.0485
DEBUG - 2022-06-23 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:56 --> Total execution time: 0.0439
DEBUG - 2022-06-23 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:57 --> Total execution time: 0.0417
DEBUG - 2022-06-23 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:47:58 --> Total execution time: 0.0487
DEBUG - 2022-06-23 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:12 --> Total execution time: 0.0382
DEBUG - 2022-06-23 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:16 --> Total execution time: 0.0383
DEBUG - 2022-06-23 11:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:20 --> Total execution time: 0.0487
DEBUG - 2022-06-23 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:48:31 --> Total execution time: 0.0361
DEBUG - 2022-06-23 11:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:48:50 --> Total execution time: 0.0440
DEBUG - 2022-06-23 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:48:54 --> Total execution time: 0.0431
DEBUG - 2022-06-23 11:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:18:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:48:58 --> Total execution time: 0.0652
DEBUG - 2022-06-23 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:19:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:49:09 --> Total execution time: 0.0445
DEBUG - 2022-06-23 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:26 --> Total execution time: 0.0377
DEBUG - 2022-06-23 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:28 --> Total execution time: 0.0681
DEBUG - 2022-06-23 11:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:19:28 --> Total execution time: 0.0844
DEBUG - 2022-06-23 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:19:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:49:51 --> Total execution time: 0.0444
DEBUG - 2022-06-23 11:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:49:56 --> Total execution time: 0.0727
DEBUG - 2022-06-23 11:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:50:11 --> Total execution time: 0.0437
DEBUG - 2022-06-23 11:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:23 --> Total execution time: 0.0460
DEBUG - 2022-06-23 11:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:23 --> Total execution time: 0.0454
DEBUG - 2022-06-23 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:26 --> Total execution time: 0.0424
DEBUG - 2022-06-23 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:27 --> Total execution time: 0.0601
DEBUG - 2022-06-23 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:27 --> Total execution time: 0.0590
DEBUG - 2022-06-23 11:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:40 --> Total execution time: 0.0573
DEBUG - 2022-06-23 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:42 --> Total execution time: 0.0538
DEBUG - 2022-06-23 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:21:42 --> Total execution time: 0.0527
DEBUG - 2022-06-23 11:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:21:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:51:51 --> Total execution time: 0.0515
DEBUG - 2022-06-23 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:11 --> Total execution time: 0.0467
DEBUG - 2022-06-23 11:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:13 --> Total execution time: 0.1300
DEBUG - 2022-06-23 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:18 --> Total execution time: 0.0672
DEBUG - 2022-06-23 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:19 --> Total execution time: 0.0808
DEBUG - 2022-06-23 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:39 --> Total execution time: 0.1048
DEBUG - 2022-06-23 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:42 --> Total execution time: 0.0535
DEBUG - 2022-06-23 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:44 --> Total execution time: 0.0711
DEBUG - 2022-06-23 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:44 --> Total execution time: 0.1049
DEBUG - 2022-06-23 11:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:46 --> Total execution time: 0.0522
DEBUG - 2022-06-23 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:49 --> Total execution time: 0.0425
DEBUG - 2022-06-23 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:50 --> Total execution time: 0.0475
DEBUG - 2022-06-23 11:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:22:51 --> Total execution time: 0.1056
DEBUG - 2022-06-23 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:52:55 --> Total execution time: 0.0533
DEBUG - 2022-06-23 11:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:07 --> Total execution time: 0.0491
DEBUG - 2022-06-23 11:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:20 --> Total execution time: 0.0439
DEBUG - 2022-06-23 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:21 --> Total execution time: 0.0529
DEBUG - 2022-06-23 11:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:22 --> Total execution time: 0.0490
DEBUG - 2022-06-23 11:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:22 --> Total execution time: 0.0516
DEBUG - 2022-06-23 11:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:33 --> Total execution time: 0.0459
DEBUG - 2022-06-23 11:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:38 --> Total execution time: 0.0494
DEBUG - 2022-06-23 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:41 --> Total execution time: 0.0459
DEBUG - 2022-06-23 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:41 --> Total execution time: 0.0923
DEBUG - 2022-06-23 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:42 --> Total execution time: 0.0810
DEBUG - 2022-06-23 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:42 --> Total execution time: 0.0577
DEBUG - 2022-06-23 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:43 --> Total execution time: 0.0497
DEBUG - 2022-06-23 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:43 --> Total execution time: 0.0691
DEBUG - 2022-06-23 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:43 --> Total execution time: 0.0591
DEBUG - 2022-06-23 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:43 --> Total execution time: 0.0625
DEBUG - 2022-06-23 11:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:44 --> Total execution time: 0.0533
DEBUG - 2022-06-23 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:45 --> Total execution time: 0.0605
DEBUG - 2022-06-23 11:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:47 --> Total execution time: 0.1129
DEBUG - 2022-06-23 11:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:47 --> Total execution time: 0.1115
DEBUG - 2022-06-23 11:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:55 --> Total execution time: 0.0567
DEBUG - 2022-06-23 11:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:55 --> Total execution time: 0.1082
DEBUG - 2022-06-23 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:56 --> Total execution time: 0.0454
DEBUG - 2022-06-23 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:56 --> Total execution time: 0.0435
DEBUG - 2022-06-23 11:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:53:58 --> Total execution time: 0.0486
DEBUG - 2022-06-23 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:02 --> Total execution time: 0.0669
DEBUG - 2022-06-23 11:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:03 --> Total execution time: 0.0495
DEBUG - 2022-06-23 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:11 --> Total execution time: 0.0540
DEBUG - 2022-06-23 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:16 --> Total execution time: 0.0458
DEBUG - 2022-06-23 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:19 --> Total execution time: 0.0473
DEBUG - 2022-06-23 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:24 --> Total execution time: 0.0783
DEBUG - 2022-06-23 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:26 --> Total execution time: 0.0537
DEBUG - 2022-06-23 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:54:36 --> Total execution time: 0.0510
DEBUG - 2022-06-23 11:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:25:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:55:23 --> Total execution time: 0.1337
DEBUG - 2022-06-23 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:08 --> Total execution time: 0.0498
DEBUG - 2022-06-23 11:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:13 --> Total execution time: 0.0696
DEBUG - 2022-06-23 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:20 --> Total execution time: 0.0488
DEBUG - 2022-06-23 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:32 --> Total execution time: 0.0463
DEBUG - 2022-06-23 11:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:36 --> Total execution time: 0.0623
DEBUG - 2022-06-23 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:39 --> Total execution time: 0.0672
DEBUG - 2022-06-23 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:41 --> Total execution time: 0.0539
DEBUG - 2022-06-23 11:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:50 --> Total execution time: 0.0466
DEBUG - 2022-06-23 11:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:00 --> Total execution time: 0.0512
DEBUG - 2022-06-23 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:10 --> Total execution time: 0.0421
DEBUG - 2022-06-23 11:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:22 --> Total execution time: 0.0419
DEBUG - 2022-06-23 11:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:27:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:34 --> Total execution time: 0.0473
DEBUG - 2022-06-23 11:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:27:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:35 --> Total execution time: 0.0495
DEBUG - 2022-06-23 11:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:27:37 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:37 --> Total execution time: 0.0581
DEBUG - 2022-06-23 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:29 --> Total execution time: 0.0581
DEBUG - 2022-06-23 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:42 --> Total execution time: 0.0828
DEBUG - 2022-06-23 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:54 --> Total execution time: 0.0624
DEBUG - 2022-06-23 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:35 --> Total execution time: 0.0491
DEBUG - 2022-06-23 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:29:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:48 --> Total execution time: 0.1075
DEBUG - 2022-06-23 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:13 --> Total execution time: 0.0469
DEBUG - 2022-06-23 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:36 --> Total execution time: 0.0499
DEBUG - 2022-06-23 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:41 --> Total execution time: 0.0520
DEBUG - 2022-06-23 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:30:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:47 --> Total execution time: 0.0374
DEBUG - 2022-06-23 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:51 --> Total execution time: 0.0496
DEBUG - 2022-06-23 11:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:01:06 --> Total execution time: 0.0487
DEBUG - 2022-06-23 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:01:12 --> Total execution time: 0.0486
DEBUG - 2022-06-23 11:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:01:19 --> Total execution time: 0.0467
DEBUG - 2022-06-23 11:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:01:52 --> Total execution time: 0.0544
DEBUG - 2022-06-23 11:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:01:59 --> Total execution time: 0.0472
DEBUG - 2022-06-23 11:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:02 --> Total execution time: 0.0532
DEBUG - 2022-06-23 11:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:08 --> Total execution time: 0.0534
DEBUG - 2022-06-23 11:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:12 --> Total execution time: 0.0546
DEBUG - 2022-06-23 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:23 --> Total execution time: 0.0675
DEBUG - 2022-06-23 11:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:26 --> Total execution time: 0.0490
DEBUG - 2022-06-23 11:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:34 --> Total execution time: 0.0449
DEBUG - 2022-06-23 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:49 --> Total execution time: 0.0537
DEBUG - 2022-06-23 11:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:51 --> Total execution time: 0.0461
DEBUG - 2022-06-23 11:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:54 --> Total execution time: 0.0471
DEBUG - 2022-06-23 11:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:56 --> Total execution time: 0.0516
DEBUG - 2022-06-23 11:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:57 --> Total execution time: 0.0534
DEBUG - 2022-06-23 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:02:58 --> Total execution time: 0.0460
DEBUG - 2022-06-23 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:03:07 --> Total execution time: 0.0516
DEBUG - 2022-06-23 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:03:10 --> Total execution time: 0.0457
DEBUG - 2022-06-23 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:03:13 --> Total execution time: 0.0497
DEBUG - 2022-06-23 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:22 --> Total execution time: 0.0418
DEBUG - 2022-06-23 11:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:28 --> Total execution time: 0.0403
DEBUG - 2022-06-23 11:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:37 --> Total execution time: 0.0410
DEBUG - 2022-06-23 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:43 --> Total execution time: 0.0411
DEBUG - 2022-06-23 11:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:03:53 --> Total execution time: 0.0497
DEBUG - 2022-06-23 11:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:04:16 --> Total execution time: 0.0493
DEBUG - 2022-06-23 11:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:04:31 --> Total execution time: 0.0429
DEBUG - 2022-06-23 11:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:04:35 --> Total execution time: 0.0471
DEBUG - 2022-06-23 11:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:04:39 --> Total execution time: 0.0478
DEBUG - 2022-06-23 11:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:04:53 --> Total execution time: 0.0504
DEBUG - 2022-06-23 11:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:05:00 --> Total execution time: 0.0630
DEBUG - 2022-06-23 11:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:05:01 --> Total execution time: 0.0501
DEBUG - 2022-06-23 11:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:37:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 11:37:01 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:40:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:10:06 --> Total execution time: 0.1562
DEBUG - 2022-06-23 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:10:13 --> Total execution time: 0.0320
DEBUG - 2022-06-23 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:10:39 --> Total execution time: 0.0463
DEBUG - 2022-06-23 11:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:11:01 --> Total execution time: 0.0992
DEBUG - 2022-06-23 11:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:11:10 --> Total execution time: 0.0588
DEBUG - 2022-06-23 11:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:11:14 --> Total execution time: 0.0682
DEBUG - 2022-06-23 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:11:21 --> Total execution time: 0.0761
DEBUG - 2022-06-23 11:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:11:54 --> Total execution time: 0.0488
DEBUG - 2022-06-23 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:12:12 --> Total execution time: 0.0571
DEBUG - 2022-06-23 11:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:12:23 --> Total execution time: 0.0658
DEBUG - 2022-06-23 11:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:23:27 --> Total execution time: 0.0848
DEBUG - 2022-06-23 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:07 --> Total execution time: 0.0611
DEBUG - 2022-06-23 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:28 --> Total execution time: 0.0498
DEBUG - 2022-06-23 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:32 --> Total execution time: 0.0708
DEBUG - 2022-06-23 11:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:40 --> Total execution time: 0.0660
DEBUG - 2022-06-23 11:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 11:57:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 11:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:27:52 --> Total execution time: 0.1551
DEBUG - 2022-06-23 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:30:04 --> Total execution time: 0.1388
DEBUG - 2022-06-23 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:01:07 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:31:08 --> Total execution time: 0.0656
DEBUG - 2022-06-23 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:32:44 --> Total execution time: 0.0407
DEBUG - 2022-06-23 12:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:33:50 --> Total execution time: 0.0327
DEBUG - 2022-06-23 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:33:57 --> Total execution time: 0.0624
DEBUG - 2022-06-23 12:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:30 --> Total execution time: 0.0539
DEBUG - 2022-06-23 12:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:03 --> Total execution time: 0.0424
DEBUG - 2022-06-23 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:19 --> Total execution time: 0.0345
DEBUG - 2022-06-23 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:22 --> Total execution time: 0.0435
DEBUG - 2022-06-23 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:38 --> Total execution time: 0.0592
DEBUG - 2022-06-23 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:40 --> Total execution time: 0.0529
DEBUG - 2022-06-23 12:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:44 --> Total execution time: 0.0597
DEBUG - 2022-06-23 12:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:54 --> Total execution time: 0.0505
DEBUG - 2022-06-23 12:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:17:50 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:47:51 --> Total execution time: 0.4444
DEBUG - 2022-06-23 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:49:07 --> Total execution time: 0.1631
DEBUG - 2022-06-23 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:49:07 --> Total execution time: 0.0499
DEBUG - 2022-06-23 12:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:49:20 --> Total execution time: 0.0725
DEBUG - 2022-06-23 12:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:49:25 --> Total execution time: 0.1168
DEBUG - 2022-06-23 12:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:49:28 --> Total execution time: 0.0835
DEBUG - 2022-06-23 12:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:49:52 --> Total execution time: 0.1048
DEBUG - 2022-06-23 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:08 --> Total execution time: 0.0795
DEBUG - 2022-06-23 12:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:14 --> Total execution time: 0.0859
DEBUG - 2022-06-23 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:22 --> Total execution time: 0.0624
DEBUG - 2022-06-23 12:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:52:33 --> Total execution time: 0.2832
DEBUG - 2022-06-23 12:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:23:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:53:30 --> Total execution time: 0.0643
DEBUG - 2022-06-23 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:53:45 --> Total execution time: 0.0513
DEBUG - 2022-06-23 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:53:55 --> Total execution time: 0.1835
DEBUG - 2022-06-23 12:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:54:02 --> Total execution time: 0.0587
DEBUG - 2022-06-23 12:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:54:04 --> Total execution time: 0.0624
DEBUG - 2022-06-23 12:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:54:06 --> Total execution time: 0.0929
DEBUG - 2022-06-23 12:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:54:12 --> Total execution time: 0.0525
DEBUG - 2022-06-23 12:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:54:15 --> Total execution time: 0.0901
DEBUG - 2022-06-23 12:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:54:17 --> Total execution time: 0.0532
DEBUG - 2022-06-23 12:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:26:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:56:32 --> Total execution time: 0.1217
DEBUG - 2022-06-23 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:56:59 --> Total execution time: 0.1138
DEBUG - 2022-06-23 12:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:08 --> Total execution time: 0.0326
DEBUG - 2022-06-23 12:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:21 --> Total execution time: 0.0420
DEBUG - 2022-06-23 12:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:31 --> Total execution time: 0.0748
DEBUG - 2022-06-23 12:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:34 --> Total execution time: 0.0519
DEBUG - 2022-06-23 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:39 --> Total execution time: 0.0516
DEBUG - 2022-06-23 12:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:42 --> Total execution time: 0.0531
DEBUG - 2022-06-23 12:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:49 --> Total execution time: 0.0533
DEBUG - 2022-06-23 12:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:58:04 --> Total execution time: 0.0503
DEBUG - 2022-06-23 12:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:33:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:03:32 --> Total execution time: 0.0832
DEBUG - 2022-06-23 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:27 --> Total execution time: 0.0571
DEBUG - 2022-06-23 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:35 --> Total execution time: 0.0457
DEBUG - 2022-06-23 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:34:35 --> Total execution time: 0.0425
DEBUG - 2022-06-23 12:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:00 --> Total execution time: 0.0571
DEBUG - 2022-06-23 12:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:02 --> Total execution time: 0.0438
DEBUG - 2022-06-23 12:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:24 --> Total execution time: 0.1245
DEBUG - 2022-06-23 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:25 --> Total execution time: 0.0455
DEBUG - 2022-06-23 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:28 --> Total execution time: 0.0520
DEBUG - 2022-06-23 12:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:34 --> Total execution time: 0.0477
DEBUG - 2022-06-23 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:38 --> Total execution time: 0.0481
DEBUG - 2022-06-23 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:35:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:42 --> Total execution time: 1.9009
DEBUG - 2022-06-23 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 12:35:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:47 --> Total execution time: 0.0431
DEBUG - 2022-06-23 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:12 --> Total execution time: 0.0596
DEBUG - 2022-06-23 12:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:25 --> Total execution time: 1.6059
DEBUG - 2022-06-23 12:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:38 --> Total execution time: 0.0472
DEBUG - 2022-06-23 12:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:40 --> Total execution time: 0.0479
DEBUG - 2022-06-23 12:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:50 --> Total execution time: 0.0423
DEBUG - 2022-06-23 12:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:18 --> Total execution time: 1.4916
DEBUG - 2022-06-23 12:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:37:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 12:37:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 12:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:37:33 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:33 --> Total execution time: 0.0437
DEBUG - 2022-06-23 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:37:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:48 --> Total execution time: 0.0443
DEBUG - 2022-06-23 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:08:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:08:04 --> Total execution time: 0.0552
DEBUG - 2022-06-23 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:44:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:14:11 --> Total execution time: 0.0978
DEBUG - 2022-06-23 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:14:20 --> Total execution time: 0.0424
DEBUG - 2022-06-23 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:14:43 --> Total execution time: 0.0350
DEBUG - 2022-06-23 12:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:10 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:10 --> Total execution time: 0.0347
DEBUG - 2022-06-23 12:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:19 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:19 --> Total execution time: 0.0443
DEBUG - 2022-06-23 12:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:45:24 --> Total execution time: 0.0656
DEBUG - 2022-06-23 12:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:24 --> Total execution time: 0.0477
DEBUG - 2022-06-23 12:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:29 --> Total execution time: 0.0513
DEBUG - 2022-06-23 12:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:44 --> Total execution time: 0.0531
DEBUG - 2022-06-23 12:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:47 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:47 --> Total execution time: 0.0466
DEBUG - 2022-06-23 12:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:53 --> Total execution time: 0.0321
DEBUG - 2022-06-23 12:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:45:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:15:58 --> Total execution time: 0.0479
DEBUG - 2022-06-23 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:11 --> Total execution time: 0.0470
DEBUG - 2022-06-23 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:21 --> Total execution time: 0.0423
DEBUG - 2022-06-23 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:29 --> Total execution time: 0.0733
DEBUG - 2022-06-23 12:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:31 --> Total execution time: 0.0462
DEBUG - 2022-06-23 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:32 --> Total execution time: 0.0425
DEBUG - 2022-06-23 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:36 --> Total execution time: 0.0569
DEBUG - 2022-06-23 12:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:40 --> Total execution time: 0.0477
DEBUG - 2022-06-23 12:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:51 --> Total execution time: 0.0729
DEBUG - 2022-06-23 12:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:47:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:17:46 --> Total execution time: 0.0504
DEBUG - 2022-06-23 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 12:48:55 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:20:43 --> Total execution time: 0.0441
DEBUG - 2022-06-23 12:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:20:59 --> Total execution time: 0.0415
DEBUG - 2022-06-23 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:02 --> Total execution time: 0.0931
DEBUG - 2022-06-23 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 12:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:04 --> Total execution time: 0.0328
DEBUG - 2022-06-23 12:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:05 --> Total execution time: 0.0581
DEBUG - 2022-06-23 12:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:06 --> Total execution time: 0.0419
DEBUG - 2022-06-23 12:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:13 --> Total execution time: 0.0469
DEBUG - 2022-06-23 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:14 --> Total execution time: 0.0640
DEBUG - 2022-06-23 12:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:16 --> Total execution time: 0.0477
DEBUG - 2022-06-23 12:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 12:51:26 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:58 --> Total execution time: 0.0621
DEBUG - 2022-06-23 12:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:24 --> Total execution time: 0.0318
DEBUG - 2022-06-23 12:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 12:53:33 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:30:03 --> Total execution time: 0.1567
DEBUG - 2022-06-23 13:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:32:45 --> Total execution time: 0.0415
DEBUG - 2022-06-23 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:52 --> Total execution time: 0.0409
DEBUG - 2022-06-23 13:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:53 --> Total execution time: 0.0569
DEBUG - 2022-06-23 13:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:02:53 --> Total execution time: 0.0815
DEBUG - 2022-06-23 13:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:03:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:33:13 --> Total execution time: 0.0358
DEBUG - 2022-06-23 13:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:44 --> Total execution time: 0.0849
DEBUG - 2022-06-23 13:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:09 --> Total execution time: 0.0451
DEBUG - 2022-06-23 13:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:33 --> Total execution time: 0.0428
DEBUG - 2022-06-23 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:05 --> Total execution time: 0.0611
DEBUG - 2022-06-23 13:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:15 --> Total execution time: 0.1415
DEBUG - 2022-06-23 13:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:30 --> Total execution time: 0.0567
DEBUG - 2022-06-23 13:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:38 --> Total execution time: 0.0861
DEBUG - 2022-06-23 13:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:46 --> Total execution time: 0.1013
DEBUG - 2022-06-23 13:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:40:00 --> Total execution time: 0.0786
DEBUG - 2022-06-23 13:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:40:11 --> Total execution time: 0.0816
DEBUG - 2022-06-23 13:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:40:27 --> Total execution time: 0.0791
DEBUG - 2022-06-23 13:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:40:31 --> Total execution time: 0.0636
DEBUG - 2022-06-23 13:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:25 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:42:25 --> Total execution time: 0.0381
DEBUG - 2022-06-23 13:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:42:32 --> Total execution time: 0.0467
DEBUG - 2022-06-23 13:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:42:41 --> Total execution time: 0.0473
DEBUG - 2022-06-23 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:42:51 --> Total execution time: 0.0629
DEBUG - 2022-06-23 13:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:42:56 --> Total execution time: 0.0541
DEBUG - 2022-06-23 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:42:59 --> Total execution time: 0.0577
DEBUG - 2022-06-23 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 13:16:37 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 13:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:47:16 --> Total execution time: 0.1482
DEBUG - 2022-06-23 13:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:49:11 --> Total execution time: 0.0341
DEBUG - 2022-06-23 13:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:49:14 --> Total execution time: 0.0449
DEBUG - 2022-06-23 13:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:49:22 --> Total execution time: 0.0506
DEBUG - 2022-06-23 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:29 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:49:29 --> Total execution time: 0.0472
DEBUG - 2022-06-23 13:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:49:34 --> Total execution time: 0.0783
DEBUG - 2022-06-23 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:19:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:49:48 --> Total execution time: 0.0521
DEBUG - 2022-06-23 13:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:20:17 --> Total execution time: 0.0558
DEBUG - 2022-06-23 13:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:20:18 --> Total execution time: 0.0484
DEBUG - 2022-06-23 13:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:20:18 --> Total execution time: 0.0794
DEBUG - 2022-06-23 13:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:50:27 --> Total execution time: 0.0591
DEBUG - 2022-06-23 13:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:50:32 --> Total execution time: 0.0476
DEBUG - 2022-06-23 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:50:34 --> Total execution time: 0.0500
DEBUG - 2022-06-23 13:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:50:41 --> Total execution time: 0.0487
DEBUG - 2022-06-23 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:50:46 --> Total execution time: 0.0460
DEBUG - 2022-06-23 13:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:20:57 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:50:57 --> Total execution time: 0.0331
DEBUG - 2022-06-23 13:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:21:24 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:51:25 --> Total execution time: 0.0547
DEBUG - 2022-06-23 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:53:22 --> Total execution time: 0.0558
DEBUG - 2022-06-23 13:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:23:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:53:32 --> Total execution time: 0.0553
DEBUG - 2022-06-23 13:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:53:43 --> Total execution time: 0.0411
DEBUG - 2022-06-23 13:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:54:43 --> Total execution time: 0.0436
DEBUG - 2022-06-23 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:24:52 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:54:52 --> Total execution time: 0.0445
DEBUG - 2022-06-23 13:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:55:03 --> Total execution time: 0.0414
DEBUG - 2022-06-23 13:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:55:11 --> Total execution time: 0.0537
DEBUG - 2022-06-23 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:26:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:56:26 --> Total execution time: 0.1032
DEBUG - 2022-06-23 13:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:57:04 --> Total execution time: 0.1417
DEBUG - 2022-06-23 13:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:57:37 --> Total execution time: 0.0918
DEBUG - 2022-06-23 13:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:58:52 --> Total execution time: 0.0493
DEBUG - 2022-06-23 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:00 --> Total execution time: 0.0586
DEBUG - 2022-06-23 13:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:08 --> Total execution time: 0.0486
DEBUG - 2022-06-23 13:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:18 --> Total execution time: 0.0738
DEBUG - 2022-06-23 13:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:25 --> Total execution time: 0.0885
DEBUG - 2022-06-23 13:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:50 --> Total execution time: 0.0470
DEBUG - 2022-06-23 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:30:51 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:31:25 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:39:46 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:09 --> Total execution time: 0.0461
DEBUG - 2022-06-23 13:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:14 --> Total execution time: 0.0366
DEBUG - 2022-06-23 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:34 --> Total execution time: 0.0394
DEBUG - 2022-06-23 13:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:37 --> Total execution time: 0.0422
DEBUG - 2022-06-23 13:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 13:45:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 13:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:45:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 13:45:55 --> 404 Page Not Found: Lessons/add-products-to-store-3
DEBUG - 2022-06-23 13:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:58:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:15 --> Total execution time: 0.0611
DEBUG - 2022-06-23 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:16 --> Total execution time: 0.0482
DEBUG - 2022-06-23 13:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:16 --> Total execution time: 0.0777
DEBUG - 2022-06-23 13:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 13:59:43 --> Total execution time: 0.0442
DEBUG - 2022-06-23 13:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 13:59:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 13:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 13:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:00:39 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:01:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:01:25 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:52 --> Total execution time: 0.0438
DEBUG - 2022-06-23 14:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:53 --> Total execution time: 0.0542
DEBUG - 2022-06-23 14:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:02:53 --> Total execution time: 0.0907
DEBUG - 2022-06-23 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:03:38 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:09:13 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:21:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:21:37 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-23 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:27:20 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 14:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:29:47 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:31:51 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 14:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:41:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:43:18 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 14:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:43:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:43:18 --> No URI present. Default controller set.
DEBUG - 2022-06-23 14:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:43:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 14:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:43:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 14:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:54:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 14:54:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 14:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:34:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 15:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:34:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 15:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:35:55 --> Total execution time: 0.0437
DEBUG - 2022-06-23 15:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:35:57 --> Total execution time: 0.0775
DEBUG - 2022-06-23 15:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 15:35:57 --> Total execution time: 0.1360
DEBUG - 2022-06-23 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 15:35:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 15:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 15:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 16:04:41 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 16:07:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 16:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 16:09:19 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 16:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 16:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 16:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 16:32:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 16:32:12 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 17:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 17:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:13:14 --> Total execution time: 0.0426
DEBUG - 2022-06-23 17:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 17:25:54 --> 404 Page Not Found: Lessons/create-first-campaign
DEBUG - 2022-06-23 17:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 17:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:42:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 17:42:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 17:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 17:44:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 17:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:46:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 17:46:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 17:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:59:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 17:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 17:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:59:20 --> No URI present. Default controller set.
DEBUG - 2022-06-23 17:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 17:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 17:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 17:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 17:59:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:01:59 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-06-23 18:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:04:32 --> No URI present. Default controller set.
DEBUG - 2022-06-23 18:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 18:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:10:13 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 18:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:11:11 --> 404 Page Not Found: Category/health
DEBUG - 2022-06-23 18:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:13:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:13:20 --> 404 Page Not Found: Category/culture
DEBUG - 2022-06-23 18:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:24:08 --> No URI present. Default controller set.
DEBUG - 2022-06-23 18:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 18:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:27:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 18:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 18:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:29:12 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-06-23 18:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:32:56 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 18:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 18:34:18 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-23 18:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 18:51:50 --> No URI present. Default controller set.
DEBUG - 2022-06-23 18:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 18:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 19:08:33 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-06-23 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:14:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 19:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 19:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 19:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 19:20:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 19:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 19:23:03 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 19:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 19:25:08 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 19:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 19:47:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 19:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 19:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 19:59:55 --> 404 Page Not Found: Membership-account/your-profile
DEBUG - 2022-06-23 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:12:13 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-06-23 20:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:30:00 --> No URI present. Default controller set.
DEBUG - 2022-06-23 20:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:31:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 20:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:38:15 --> No URI present. Default controller set.
DEBUG - 2022-06-23 20:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:42:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:42:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 20:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:42:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:42:36 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-23 20:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:42:42 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-23 20:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 20:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:26 --> No URI present. Default controller set.
DEBUG - 2022-06-23 20:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:36 --> Total execution time: 0.0574
DEBUG - 2022-06-23 20:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:37 --> Total execution time: 0.0435
DEBUG - 2022-06-23 20:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:37 --> Total execution time: 0.0764
DEBUG - 2022-06-23 20:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:49:55 --> Total execution time: 0.0489
DEBUG - 2022-06-23 20:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:50:25 --> Total execution time: 0.0881
DEBUG - 2022-06-23 20:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:55:55 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 20:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:58:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 20:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:58:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 20:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 20:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 20:58:52 --> 404 Page Not Found: Category/world
DEBUG - 2022-06-23 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:00:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:00:16 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 21:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:00:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 21:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:08:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:08:02 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 21:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:08:21 --> No URI present. Default controller set.
DEBUG - 2022-06-23 21:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:11:49 --> 404 Page Not Found: Event/lesley-2030-help-shape-our-future
DEBUG - 2022-06-23 21:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:12:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 21:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:20:03 --> 404 Page Not Found: Category/news
DEBUG - 2022-06-23 21:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:22:18 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 21:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:23:21 --> 404 Page Not Found: News/feed
DEBUG - 2022-06-23 21:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:30:12 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-06-23 21:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:36:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 21:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 21:38:36 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-06-23 21:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:56:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 21:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:56:56 --> No URI present. Default controller set.
DEBUG - 2022-06-23 21:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:59:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 21:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 21:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 21:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 21:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:06:31 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:07:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:12:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:25 --> Total execution time: 0.0442
DEBUG - 2022-06-23 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:45 --> Total execution time: 0.0452
DEBUG - 2022-06-23 22:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:13:45 --> Total execution time: 0.0662
DEBUG - 2022-06-23 22:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:14:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 22:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:14:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:14:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 22:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:14:50 --> Total execution time: 0.0346
DEBUG - 2022-06-23 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:16:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:16:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:17:40 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:18:25 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-06-23 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:19:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:20:06 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:01 --> Total execution time: 0.1247
DEBUG - 2022-06-23 22:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:09 --> Total execution time: 0.0570
DEBUG - 2022-06-23 22:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:09 --> Total execution time: 0.0909
DEBUG - 2022-06-23 22:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:21:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-23 22:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:24:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:24:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:25:25 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-06-23 22:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:26:01 --> Total execution time: 0.0569
DEBUG - 2022-06-23 22:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:26:15 --> Total execution time: 0.0537
DEBUG - 2022-06-23 22:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:26:15 --> Total execution time: 0.0686
DEBUG - 2022-06-23 22:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:28:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 22:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:28:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-23 22:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:29:56 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-23 22:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:32:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 22:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:33:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:34:07 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:34:16 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-23 22:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:34:42 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:35:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-23 22:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:35:08 --> 404 Page Not Found: Category/technology
DEBUG - 2022-06-23 22:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:23 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:45 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:35:54 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:36:05 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:27 --> Total execution time: 0.0431
DEBUG - 2022-06-23 22:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:28 --> Total execution time: 0.0405
DEBUG - 2022-06-23 22:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:36:28 --> Total execution time: 0.0728
DEBUG - 2022-06-23 22:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:37:22 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:28 --> Total execution time: 0.0968
DEBUG - 2022-06-23 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:37 --> Total execution time: 0.0722
DEBUG - 2022-06-23 22:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:37:37 --> Total execution time: 0.1399
DEBUG - 2022-06-23 22:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:41:55 --> Total execution time: 0.0482
DEBUG - 2022-06-23 22:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:41:56 --> Total execution time: 0.0744
DEBUG - 2022-06-23 22:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:41:56 --> Total execution time: 0.1009
DEBUG - 2022-06-23 22:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:42:09 --> Total execution time: 0.0552
DEBUG - 2022-06-23 22:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:42:10 --> Total execution time: 0.0554
DEBUG - 2022-06-23 22:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:42:10 --> Total execution time: 0.0996
DEBUG - 2022-06-23 22:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:44:42 --> Total execution time: 0.1197
DEBUG - 2022-06-23 22:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:44:51 --> Total execution time: 0.0907
DEBUG - 2022-06-23 22:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:46:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:30 --> Total execution time: 0.0473
DEBUG - 2022-06-23 22:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:51:34 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:52:57 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 22:56:08 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-23 22:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:57:43 --> No URI present. Default controller set.
DEBUG - 2022-06-23 22:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:57:55 --> Total execution time: 0.0457
DEBUG - 2022-06-23 22:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 22:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 22:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:58:00 --> Total execution time: 0.0660
DEBUG - 2022-06-23 22:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 22:58:00 --> Total execution time: 0.0914
DEBUG - 2022-06-23 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:03:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:04:55 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:11:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:11:49 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:12:32 --> Total execution time: 0.0446
DEBUG - 2022-06-23 23:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:12:34 --> Total execution time: 0.0498
DEBUG - 2022-06-23 23:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:12:34 --> Total execution time: 0.1002
DEBUG - 2022-06-23 23:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:13:28 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:16:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:20:11 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:22:27 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:44 --> Total execution time: 0.1061
DEBUG - 2022-06-23 23:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:55 --> Total execution time: 0.0633
DEBUG - 2022-06-23 23:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:55 --> Total execution time: 0.0913
DEBUG - 2022-06-23 23:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:25:59 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:03 --> Total execution time: 0.0446
DEBUG - 2022-06-23 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:05 --> Total execution time: 0.0447
DEBUG - 2022-06-23 23:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:05 --> Total execution time: 0.1031
DEBUG - 2022-06-23 23:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:24 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:27:58 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:28:14 --> 404 Page Not Found: Category/features
DEBUG - 2022-06-23 23:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:26 --> Total execution time: 0.0671
DEBUG - 2022-06-23 23:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:38 --> Total execution time: 0.0663
DEBUG - 2022-06-23 23:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:38 --> Total execution time: 0.1111
DEBUG - 2022-06-23 23:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:34:59 --> Total execution time: 0.0425
DEBUG - 2022-06-23 23:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:40 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:41 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:42 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:44 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:45 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2022-06-23 23:35:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:48 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:48 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:49 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:49 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:35:50 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-23 23:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:09 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:37:24 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:37:24 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-23 23:37:25 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-23 23:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:55 --> Total execution time: 0.0414
DEBUG - 2022-06-23 23:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:37:57 --> Total execution time: 0.0460
DEBUG - 2022-06-23 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:04 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:12 --> Total execution time: 0.0455
DEBUG - 2022-06-23 23:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:17 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:24 --> Total execution time: 0.0437
DEBUG - 2022-06-23 23:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:52 --> Total execution time: 0.0481
DEBUG - 2022-06-23 23:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:38:56 --> Total execution time: 0.0519
DEBUG - 2022-06-23 23:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:04 --> Total execution time: 0.0558
DEBUG - 2022-06-23 23:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:12 --> Total execution time: 0.0503
DEBUG - 2022-06-23 23:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:15 --> Total execution time: 0.0627
DEBUG - 2022-06-23 23:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:28 --> Total execution time: 0.1108
DEBUG - 2022-06-23 23:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:30 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:30 --> Total execution time: 0.0721
DEBUG - 2022-06-23 23:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:30 --> Total execution time: 0.1204
DEBUG - 2022-06-23 23:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:39:53 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:55:48 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:14 --> No URI present. Default controller set.
DEBUG - 2022-06-23 23:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:25 --> Total execution time: 0.0358
DEBUG - 2022-06-23 23:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:27 --> Total execution time: 0.0606
DEBUG - 2022-06-23 23:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:27 --> Total execution time: 0.1093
DEBUG - 2022-06-23 23:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-23 23:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 23:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 23:59:59 --> Encryption: Auto-configured driver 'openssl'.
