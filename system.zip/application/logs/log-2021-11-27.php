<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-27 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 13:25:15 --> Total execution time: 0.0835
DEBUG - 2021-11-27 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 13:25:15 --> Total execution time: 0.0475
DEBUG - 2021-11-27 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 17:55:20 --> Total execution time: 0.0500
DEBUG - 2021-11-27 13:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 17:55:24 --> Total execution time: 0.0800
DEBUG - 2021-11-27 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 17:55:27 --> Total execution time: 0.0642
DEBUG - 2021-11-27 13:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:05:12 --> Total execution time: 1.7936
DEBUG - 2021-11-27 13:41:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:11:19 --> Total execution time: 0.0549
DEBUG - 2021-11-27 13:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:11:28 --> Total execution time: 0.1024
DEBUG - 2021-11-27 13:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 13:41:33 --> 404 Page Not Found: Admin-today-attendance/index
DEBUG - 2021-11-27 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 13:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 13:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:14:37 --> Total execution time: 0.0682
DEBUG - 2021-11-27 14:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:49:50 --> Total execution time: 0.0482
DEBUG - 2021-11-27 14:24:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:54:49 --> Total execution time: 0.0505
DEBUG - 2021-11-27 14:24:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 18:54:59 --> Total execution time: 0.0568
DEBUG - 2021-11-27 14:29:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 14:32:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:02:41 --> Total execution time: 0.0774
DEBUG - 2021-11-27 14:33:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:03:24 --> Total execution time: 0.0713
DEBUG - 2021-11-27 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:11:39 --> Total execution time: 0.0668
DEBUG - 2021-11-27 14:42:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:42:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 19:12:54 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 38
DEBUG - 2021-11-27 14:43:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:13:01 --> Total execution time: 0.0504
DEBUG - 2021-11-27 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:22:41 --> Total execution time: 0.0541
DEBUG - 2021-11-27 14:53:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:23:14 --> Total execution time: 0.0489
DEBUG - 2021-11-27 14:54:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:24:38 --> Total execution time: 0.0580
DEBUG - 2021-11-27 14:55:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:25:19 --> Total execution time: 0.0486
DEBUG - 2021-11-27 14:55:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:25:44 --> Total execution time: 0.0535
DEBUG - 2021-11-27 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:26:07 --> Total execution time: 0.0481
DEBUG - 2021-11-27 14:56:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:26:19 --> Total execution time: 0.0656
DEBUG - 2021-11-27 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:27:29 --> Total execution time: 0.0512
DEBUG - 2021-11-27 14:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:27:48 --> Total execution time: 0.0516
DEBUG - 2021-11-27 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:28:24 --> Total execution time: 0.0526
DEBUG - 2021-11-27 14:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:29:52 --> Total execution time: 0.0530
DEBUG - 2021-11-27 14:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 14:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 14:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:29:58 --> Total execution time: 0.0551
DEBUG - 2021-11-27 15:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:31:44 --> Total execution time: 0.0670
DEBUG - 2021-11-27 15:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:31:50 --> Total execution time: 0.0870
DEBUG - 2021-11-27 15:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:32:02 --> Total execution time: 0.0507
DEBUG - 2021-11-27 15:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:03:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
ERROR - 2021-11-27 19:33:11 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 70
DEBUG - 2021-11-27 19:33:11 --> Total execution time: 0.1707
DEBUG - 2021-11-27 15:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:04:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:08 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
DEBUG - 2021-11-27 19:34:08 --> Total execution time: 0.1335
DEBUG - 2021-11-27 15:04:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:04:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
ERROR - 2021-11-27 19:34:10 --> Severity: Notice --> Undefined property: stdClass::$atndc_day C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 71
DEBUG - 2021-11-27 19:34:10 --> Total execution time: 0.1412
DEBUG - 2021-11-27 15:05:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:35:03 --> Total execution time: 0.1016
DEBUG - 2021-11-27 15:05:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:35:27 --> Total execution time: 0.0544
DEBUG - 2021-11-27 15:06:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:36:00 --> Total execution time: 0.0555
DEBUG - 2021-11-27 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:36:16 --> Total execution time: 0.1139
DEBUG - 2021-11-27 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:37:57 --> Total execution time: 0.0496
DEBUG - 2021-11-27 15:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:38:20 --> Total execution time: 0.0732
DEBUG - 2021-11-27 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:39:02 --> Total execution time: 0.0718
DEBUG - 2021-11-27 15:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:39:10 --> Total execution time: 0.0512
DEBUG - 2021-11-27 15:09:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:39:54 --> Total execution time: 0.0688
DEBUG - 2021-11-27 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:39:56 --> Total execution time: 0.0626
DEBUG - 2021-11-27 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:41:23 --> Total execution time: 0.0532
DEBUG - 2021-11-27 15:12:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:42:17 --> Total execution time: 0.0509
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:42:35 --> Total execution time: 0.0566
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:14:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:44:12 --> Total execution time: 0.0540
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:14:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:46:13 --> Total execution time: 0.0511
DEBUG - 2021-11-27 15:17:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:47:04 --> Total execution time: 0.0826
DEBUG - 2021-11-27 15:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:47:40 --> Total execution time: 0.0518
DEBUG - 2021-11-27 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:47:41 --> Total execution time: 0.0506
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 15:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:17:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:17:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:48:19 --> Total execution time: 0.0576
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:18:19 --> UTF-8 Support Enabled
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 15:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:48:21 --> Total execution time: 0.0724
DEBUG - 2021-11-27 15:18:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:48:28 --> Total execution time: 0.0977
DEBUG - 2021-11-27 15:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:48:40 --> Total execution time: 0.0710
DEBUG - 2021-11-27 15:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:48:53 --> Total execution time: 0.0878
DEBUG - 2021-11-27 15:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:49:00 --> Total execution time: 0.0462
DEBUG - 2021-11-27 15:19:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:49:02 --> Total execution time: 0.0491
DEBUG - 2021-11-27 15:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:49:16 --> Total execution time: 0.0674
DEBUG - 2021-11-27 15:19:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:49:17 --> Total execution time: 0.0565
DEBUG - 2021-11-27 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:49:21 --> Total execution time: 0.0503
DEBUG - 2021-11-27 15:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:49:24 --> Total execution time: 0.0583
DEBUG - 2021-11-27 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:56:18 --> Total execution time: 0.0705
DEBUG - 2021-11-27 15:27:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:57:51 --> Total execution time: 0.0460
DEBUG - 2021-11-27 15:29:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 19:59:44 --> Total execution time: 0.0730
DEBUG - 2021-11-27 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:03:02 --> Total execution time: 0.0506
DEBUG - 2021-11-27 15:33:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 15:33:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:03:07 --> Total execution time: 0.0497
DEBUG - 2021-11-27 15:33:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:03:26 --> Total execution time: 0.0761
DEBUG - 2021-11-27 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:03:35 --> Total execution time: 0.0532
DEBUG - 2021-11-27 15:33:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:03:57 --> Total execution time: 0.0669
DEBUG - 2021-11-27 15:34:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:04:27 --> Total execution time: 0.0624
DEBUG - 2021-11-27 15:34:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:04:54 --> Total execution time: 0.1001
DEBUG - 2021-11-27 15:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:05:00 --> Total execution time: 0.0719
DEBUG - 2021-11-27 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:05:23 --> Total execution time: 0.0802
DEBUG - 2021-11-27 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:05:28 --> Total execution time: 0.0749
DEBUG - 2021-11-27 15:35:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:05:54 --> Total execution time: 0.0530
DEBUG - 2021-11-27 15:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:05:58 --> Total execution time: 0.0824
DEBUG - 2021-11-27 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:06:16 --> Total execution time: 0.0467
DEBUG - 2021-11-27 15:36:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:06:30 --> Total execution time: 0.1090
DEBUG - 2021-11-27 15:36:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:06:35 --> Total execution time: 0.0740
DEBUG - 2021-11-27 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 15:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 15:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:06:38 --> Total execution time: 0.0882
DEBUG - 2021-11-27 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:37:32 --> Total execution time: 0.0522
DEBUG - 2021-11-27 16:07:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:37:35 --> Total execution time: 0.0480
DEBUG - 2021-11-27 16:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:38:01 --> Total execution time: 0.0770
DEBUG - 2021-11-27 16:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:38:06 --> Total execution time: 0.0511
DEBUG - 2021-11-27 16:11:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:41:17 --> Total execution time: 0.0712
DEBUG - 2021-11-27 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:43:00 --> Total execution time: 0.0742
DEBUG - 2021-11-27 16:13:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:43:32 --> Total execution time: 0.0887
DEBUG - 2021-11-27 16:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:45:06 --> Total execution time: 0.0635
DEBUG - 2021-11-27 16:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:48:55 --> Total execution time: 0.0675
DEBUG - 2021-11-27 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:49:37 --> Total execution time: 0.0651
DEBUG - 2021-11-27 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:49:58 --> Total execution time: 0.0582
DEBUG - 2021-11-27 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:51:03 --> Total execution time: 0.0517
DEBUG - 2021-11-27 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:51:09 --> Total execution time: 0.0541
DEBUG - 2021-11-27 16:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 20:51:41 --> Total execution time: 0.0738
DEBUG - 2021-11-27 16:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:22:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 20:52:12 --> Severity: Notice --> Undefined variable: from_d C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 146
ERROR - 2021-11-27 20:52:12 --> Severity: Notice --> Undefined variable: from_d C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-today-attendance.php 146
DEBUG - 2021-11-27 20:52:12 --> Total execution time: 0.0702
DEBUG - 2021-11-27 16:39:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:09:29 --> Total execution time: 0.0758
DEBUG - 2021-11-27 16:43:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:13:11 --> Total execution time: 0.0500
DEBUG - 2021-11-27 16:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:43:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 21:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserAttendance.php 34
DEBUG - 2021-11-27 16:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:13:34 --> Total execution time: 0.0481
DEBUG - 2021-11-27 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:15:34 --> Total execution time: 0.0735
DEBUG - 2021-11-27 16:45:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:15:38 --> Total execution time: 0.0460
DEBUG - 2021-11-27 16:48:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:18:38 --> Total execution time: 0.0618
DEBUG - 2021-11-27 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:19:47 --> Total execution time: 0.0590
DEBUG - 2021-11-27 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:22:30 --> Total execution time: 0.0584
DEBUG - 2021-11-27 16:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:22:39 --> Total execution time: 0.0557
DEBUG - 2021-11-27 16:53:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:23:54 --> Total execution time: 0.0489
DEBUG - 2021-11-27 16:56:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:26:23 --> Total execution time: 0.0776
DEBUG - 2021-11-27 16:58:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:28:12 --> Total execution time: 0.0599
DEBUG - 2021-11-27 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 16:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 16:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:29:29 --> Total execution time: 0.0610
DEBUG - 2021-11-27 17:00:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:30:50 --> Total execution time: 0.0506
DEBUG - 2021-11-27 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:31:48 --> Total execution time: 0.0506
DEBUG - 2021-11-27 17:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:32:49 --> Total execution time: 0.0490
DEBUG - 2021-11-27 17:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:32:54 --> Total execution time: 0.0557
DEBUG - 2021-11-27 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:33:36 --> Total execution time: 0.0768
DEBUG - 2021-11-27 17:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:34:35 --> Total execution time: 0.0615
DEBUG - 2021-11-27 17:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:35:46 --> Total execution time: 0.0878
DEBUG - 2021-11-27 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:36:17 --> Total execution time: 0.0483
DEBUG - 2021-11-27 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:36:19 --> Total execution time: 0.0618
DEBUG - 2021-11-27 17:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:36:57 --> Total execution time: 0.0824
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:37:37 --> Total execution time: 0.0820
DEBUG - 2021-11-27 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:37 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:38 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:07:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:07:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:38:18 --> Total execution time: 0.0525
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:18 --> UTF-8 Support Enabled
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:38:29 --> Total execution time: 0.0959
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:38:48 --> Total execution time: 0.0910
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:38:59 --> Total execution time: 0.0724
DEBUG - 2021-11-27 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:59 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:08:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:08:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:09:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:00 --> UTF-8 Support Enabled
ERROR - 2021-11-27 17:09:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:39:19 --> Total execution time: 0.0538
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:39:27 --> Total execution time: 0.0826
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:39:42 --> Total execution time: 0.0757
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:40:06 --> Total execution time: 0.0474
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:40:15 --> Total execution time: 0.0518
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:15 --> UTF-8 Support Enabled
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:10:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-27 17:10:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:40:33 --> Total execution time: 0.0492
DEBUG - 2021-11-27 17:10:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:40:37 --> Total execution time: 0.0542
DEBUG - 2021-11-27 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:40:40 --> Total execution time: 0.0464
DEBUG - 2021-11-27 17:11:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:41:44 --> Total execution time: 0.0587
DEBUG - 2021-11-27 17:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-27 17:19:16 --> Severity: error --> Exception: syntax error, unexpected '$year' (T_VARIABLE), expecting ']' C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserAttendance.php 81
DEBUG - 2021-11-27 17:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:19:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 21:49:22 --> Severity: Notice --> Undefined variable: number C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserAttendance.php 81
DEBUG - 2021-11-27 21:49:22 --> Total execution time: 0.0664
DEBUG - 2021-11-27 17:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:19:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-27 21:49:37 --> Severity: Notice --> Undefined variable: number C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserAttendance.php 81
DEBUG - 2021-11-27 17:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 17:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:49:50 --> Total execution time: 0.0856
DEBUG - 2021-11-27 17:21:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:51:05 --> Total execution time: 0.0814
DEBUG - 2021-11-27 17:21:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:51:15 --> Total execution time: 0.0498
DEBUG - 2021-11-27 17:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:51:33 --> Total execution time: 0.0526
DEBUG - 2021-11-27 17:21:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:51:50 --> Total execution time: 0.0616
DEBUG - 2021-11-27 17:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:52:00 --> Total execution time: 0.0484
DEBUG - 2021-11-27 17:22:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:52:02 --> Total execution time: 0.0497
DEBUG - 2021-11-27 17:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:52:06 --> Total execution time: 0.0751
DEBUG - 2021-11-27 17:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:52:11 --> Total execution time: 0.0628
DEBUG - 2021-11-27 17:22:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:52:21 --> Total execution time: 0.0489
DEBUG - 2021-11-27 17:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:53:21 --> Total execution time: 0.0612
DEBUG - 2021-11-27 17:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:53:22 --> Total execution time: 0.0614
DEBUG - 2021-11-27 17:23:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:53:25 --> Total execution time: 0.0721
DEBUG - 2021-11-27 17:24:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:54:11 --> Total execution time: 0.0650
DEBUG - 2021-11-27 17:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 21:55:22 --> Total execution time: 0.0537
DEBUG - 2021-11-27 17:35:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 22:05:09 --> Total execution time: 0.0784
DEBUG - 2021-11-27 17:35:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 22:05:11 --> Total execution time: 0.0727
DEBUG - 2021-11-27 17:35:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 22:05:17 --> Total execution time: 0.0541
DEBUG - 2021-11-27 17:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-27 17:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-27 17:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-27 22:07:38 --> Total execution time: 0.0921
