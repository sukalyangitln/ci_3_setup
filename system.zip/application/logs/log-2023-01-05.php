<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-05 12:34:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:34:53 --> No URI present. Default controller set.
DEBUG - 2023-01-05 12:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:04:54 --> Total execution time: 0.2320
DEBUG - 2023-01-05 12:34:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:34:54 --> No URI present. Default controller set.
DEBUG - 2023-01-05 12:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:04:54 --> Total execution time: 0.0920
DEBUG - 2023-01-05 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:05:06 --> Total execution time: 0.0604
DEBUG - 2023-01-05 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:05:57 --> Total execution time: 0.0527
DEBUG - 2023-01-05 12:36:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:06:40 --> Total execution time: 0.0586
DEBUG - 2023-01-05 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:06:49 --> Total execution time: 0.0633
DEBUG - 2023-01-05 12:37:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:07:38 --> Total execution time: 0.0542
DEBUG - 2023-01-05 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:37:44 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:37:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:37:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:37:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:38:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:08:00 --> Total execution time: 0.0658
DEBUG - 2023-01-05 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:08:16 --> Total execution time: 0.0682
DEBUG - 2023-01-05 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:09:32 --> Total execution time: 0.0484
DEBUG - 2023-01-05 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:40:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:40:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:40:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:40:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:11:53 --> Total execution time: 0.0591
DEBUG - 2023-01-05 12:41:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:41:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:41:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:41:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:41:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:41:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:41:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:41:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:41:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:41:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:41:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:13:55 --> Total execution time: 0.0590
DEBUG - 2023-01-05 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:43:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:43:55 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:43:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:43:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:45:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:15:10 --> Total execution time: 0.0519
DEBUG - 2023-01-05 12:45:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:45:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:45:11 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:45:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:45:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:15:27 --> Total execution time: 0.0525
DEBUG - 2023-01-05 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:45:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:45:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:45:28 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:45:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:45:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:45:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:16:21 --> Total execution time: 0.0789
DEBUG - 2023-01-05 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:46:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:46:21 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:46:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:46:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:16:49 --> Total execution time: 0.0581
DEBUG - 2023-01-05 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:46:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:46:49 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-05 12:46:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-05 12:46:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-05 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:18:26 --> Total execution time: 0.0592
DEBUG - 2023-01-05 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:18:40 --> Total execution time: 0.0608
DEBUG - 2023-01-05 12:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:18:50 --> Total execution time: 0.0570
DEBUG - 2023-01-05 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 12:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 12:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 12:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:20:45 --> Total execution time: 0.0606
DEBUG - 2023-01-05 13:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:31:03 --> Total execution time: 0.0517
DEBUG - 2023-01-05 13:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:34:27 --> Total execution time: 0.0676
DEBUG - 2023-01-05 13:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:34:30 --> Total execution time: 0.0499
DEBUG - 2023-01-05 13:05:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:35:21 --> Total execution time: 0.0527
DEBUG - 2023-01-05 13:11:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:41:46 --> Total execution time: 0.0642
DEBUG - 2023-01-05 13:19:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:49:03 --> Total execution time: 0.0618
DEBUG - 2023-01-05 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:25:41 --> No URI present. Default controller set.
DEBUG - 2023-01-05 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:55:42 --> Total execution time: 1.4675
DEBUG - 2023-01-05 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:25:42 --> No URI present. Default controller set.
DEBUG - 2023-01-05 13:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:55:42 --> Total execution time: 0.1025
DEBUG - 2023-01-05 13:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 17:56:10 --> Total execution time: 0.0534
DEBUG - 2023-01-05 13:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:01:09 --> Total execution time: 0.0582
DEBUG - 2023-01-05 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:01:26 --> Total execution time: 0.0515
DEBUG - 2023-01-05 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:01:37 --> Total execution time: 0.0790
DEBUG - 2023-01-05 13:34:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:04:52 --> Total execution time: 0.0520
DEBUG - 2023-01-05 13:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:05:08 --> Total execution time: 0.0560
DEBUG - 2023-01-05 13:35:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:05:25 --> Total execution time: 0.0594
DEBUG - 2023-01-05 13:36:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:06:37 --> Total execution time: 0.0512
DEBUG - 2023-01-05 13:36:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:06:41 --> Total execution time: 0.0488
DEBUG - 2023-01-05 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:06:47 --> Total execution time: 0.0487
DEBUG - 2023-01-05 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:08:47 --> Total execution time: 0.0704
DEBUG - 2023-01-05 13:39:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:09:14 --> Total execution time: 0.0509
DEBUG - 2023-01-05 13:55:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 13:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 13:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 13:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:25:55 --> Total execution time: 0.0688
DEBUG - 2023-01-05 14:22:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-05 14:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-05 14:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-05 14:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-05 18:52:19 --> Total execution time: 0.0559
