<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-09 05:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 05:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 05:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 05:18:57 --> Total execution time: 1.0001
DEBUG - 2022-05-09 05:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 05:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 05:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 05:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 05:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 05:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 10:49:00 --> Total execution time: 0.0816
DEBUG - 2022-05-09 05:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 05:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 05:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 10:49:19 --> Total execution time: 0.0782
DEBUG - 2022-05-09 05:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 05:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 05:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 10:49:24 --> Total execution time: 0.1822
DEBUG - 2022-05-09 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 05:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 10:49:26 --> Total execution time: 0.1320
DEBUG - 2022-05-09 06:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:14:05 --> No URI present. Default controller set.
DEBUG - 2022-05-09 06:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:44:06 --> Total execution time: 1.4010
DEBUG - 2022-05-09 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:15:24 --> No URI present. Default controller set.
DEBUG - 2022-05-09 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:45:24 --> Total execution time: 0.8317
DEBUG - 2022-05-09 06:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 06:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:47:25 --> Total execution time: 0.0437
DEBUG - 2022-05-09 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 06:17:33 --> Total execution time: 0.0411
DEBUG - 2022-05-09 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:47:40 --> Total execution time: 0.0422
DEBUG - 2022-05-09 06:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:53:32 --> Total execution time: 0.8948
DEBUG - 2022-05-09 06:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:53:34 --> Total execution time: 0.0282
DEBUG - 2022-05-09 06:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 06:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:53:53 --> Total execution time: 0.0962
DEBUG - 2022-05-09 06:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:54:03 --> Total execution time: 0.0490
DEBUG - 2022-05-09 06:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 11:54:07 --> Total execution time: 0.0383
DEBUG - 2022-05-09 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 06:32:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 06:32:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:02:08 --> Total execution time: 0.8017
DEBUG - 2022-05-09 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:32:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:09:52 --> Total execution time: 0.8866
DEBUG - 2022-05-09 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:39:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 06:39:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:10:28 --> Total execution time: 0.0312
DEBUG - 2022-05-09 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:40:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 06:40:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:13:05 --> Total execution time: 0.9596
DEBUG - 2022-05-09 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:43:07 --> UTF-8 Support Enabled
ERROR - 2022-05-09 06:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:13:36 --> Total execution time: 0.0324
DEBUG - 2022-05-09 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:43:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:15:35 --> Total execution time: 0.0328
DEBUG - 2022-05-09 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:16:01 --> Total execution time: 0.0401
DEBUG - 2022-05-09 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:46:07 --> UTF-8 Support Enabled
ERROR - 2022-05-09 06:46:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:46:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:20:10 --> Total execution time: 0.8276
DEBUG - 2022-05-09 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:20:23 --> Total execution time: 0.0316
DEBUG - 2022-05-09 06:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:51:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:21:55 --> Total execution time: 0.8286
DEBUG - 2022-05-09 06:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:22:16 --> Total execution time: 0.0328
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:52:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:26:52 --> Total execution time: 0.8315
DEBUG - 2022-05-09 06:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:27:01 --> Total execution time: 0.0340
DEBUG - 2022-05-09 06:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:27:21 --> Total execution time: 0.0338
DEBUG - 2022-05-09 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:57:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:57:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:28:48 --> Total execution time: 0.0319
DEBUG - 2022-05-09 06:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:29:19 --> Total execution time: 0.0325
DEBUG - 2022-05-09 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 06:59:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:59:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 06:59:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 06:59:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:02:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:34:52 --> Total execution time: 0.8697
DEBUG - 2022-05-09 07:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:35:22 --> Total execution time: 0.0307
DEBUG - 2022-05-09 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:05:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:05:23 --> UTF-8 Support Enabled
ERROR - 2022-05-09 07:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:05:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:05:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:05:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:36:43 --> Total execution time: 0.0323
DEBUG - 2022-05-09 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:37:50 --> Total execution time: 0.0316
DEBUG - 2022-05-09 07:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:37:53 --> Total execution time: 0.0317
DEBUG - 2022-05-09 07:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:38:05 --> Total execution time: 0.0322
DEBUG - 2022-05-09 07:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:38:27 --> Total execution time: 0.0318
DEBUG - 2022-05-09 07:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:38:55 --> Total execution time: 0.0338
DEBUG - 2022-05-09 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:39:10 --> Total execution time: 0.0536
DEBUG - 2022-05-09 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:40:09 --> Total execution time: 0.0342
DEBUG - 2022-05-09 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:10:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:10:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:41:16 --> Total execution time: 0.0316
DEBUG - 2022-05-09 07:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:11:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:11:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:42:47 --> Total execution time: 0.0321
DEBUG - 2022-05-09 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:12:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:43:07 --> Total execution time: 0.0332
DEBUG - 2022-05-09 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:13:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:44:13 --> Total execution time: 0.0319
DEBUG - 2022-05-09 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:14:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:45:06 --> Total execution time: 0.0336
DEBUG - 2022-05-09 07:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:45:50 --> Total execution time: 0.0355
DEBUG - 2022-05-09 07:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:46:35 --> Total execution time: 0.0310
DEBUG - 2022-05-09 07:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:46:49 --> Total execution time: 0.0314
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:17:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:48:46 --> Total execution time: 0.6104
DEBUG - 2022-05-09 07:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:50:25 --> Total execution time: 0.0388
DEBUG - 2022-05-09 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:51:15 --> Total execution time: 0.1612
DEBUG - 2022-05-09 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:51:50 --> Total execution time: 0.0317
DEBUG - 2022-05-09 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:21:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:52:49 --> Total execution time: 0.1597
DEBUG - 2022-05-09 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:51 --> UTF-8 Support Enabled
ERROR - 2022-05-09 07:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:52:51 --> Total execution time: 0.0474
DEBUG - 2022-05-09 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:22:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:53:58 --> Total execution time: 0.0301
DEBUG - 2022-05-09 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:23:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:23:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:23:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:24:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:24:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:24:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:24:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:24:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:55:03 --> Total execution time: 0.3418
DEBUG - 2022-05-09 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:25:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:25:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:56:54 --> Total execution time: 0.0327
DEBUG - 2022-05-09 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 12:58:22 --> Total execution time: 0.0309
DEBUG - 2022-05-09 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:00:09 --> Total execution time: 0.8266
DEBUG - 2022-05-09 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:00:58 --> Total execution time: 0.0344
DEBUG - 2022-05-09 07:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:02:03 --> Total execution time: 0.0345
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:02:30 --> Total execution time: 3.7814
DEBUG - 2022-05-09 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:33 --> UTF-8 Support Enabled
ERROR - 2022-05-09 07:32:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:02:50 --> Total execution time: 0.0322
DEBUG - 2022-05-09 07:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:32:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:03:14 --> Total execution time: 0.0353
DEBUG - 2022-05-09 07:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:33:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:33:57 --> No URI present. Default controller set.
DEBUG - 2022-05-09 07:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:03:57 --> Total execution time: 0.0654
DEBUG - 2022-05-09 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:04:05 --> Total execution time: 0.0386
DEBUG - 2022-05-09 07:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 07:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:04:11 --> Total execution time: 0.0424
DEBUG - 2022-05-09 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:04:17 --> Total execution time: 0.0359
DEBUG - 2022-05-09 07:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:04:20 --> Total execution time: 0.0317
DEBUG - 2022-05-09 07:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:05:48 --> Total execution time: 0.9365
DEBUG - 2022-05-09 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:35:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:38:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:38:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:38:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:38:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:38:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:38:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:38:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:38:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:09:09 --> Total execution time: 0.7605
DEBUG - 2022-05-09 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:09:42 --> Total execution time: 0.0996
DEBUG - 2022-05-09 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:43:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-09 13:13:49 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/gvprods/public_html/v1/gvv3/application/views/User/my-courses-view.php 35
DEBUG - 2022-05-09 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:14:09 --> Total execution time: 0.0651
DEBUG - 2022-05-09 07:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:44:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:15:59 --> Total execution time: 0.7822
DEBUG - 2022-05-09 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:16:13 --> Total execution time: 0.0315
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:46:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:18:03 --> Total execution time: 0.8626
DEBUG - 2022-05-09 07:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:48:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:20:04 --> Total execution time: 1.2307
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:50:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:21:59 --> Total execution time: 0.9644
DEBUG - 2022-05-09 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:23:34 --> Total execution time: 0.8819
DEBUG - 2022-05-09 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:53:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:53:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:53:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:53:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:53:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:53:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:53:36 --> UTF-8 Support Enabled
ERROR - 2022-05-09 07:53:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:53:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:24:25 --> Total execution time: 0.8314
DEBUG - 2022-05-09 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 07:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 07:54:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:26:37 --> Total execution time: 0.0449
DEBUG - 2022-05-09 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 07:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 07:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:26:44 --> Total execution time: 0.0356
DEBUG - 2022-05-09 08:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:31:35 --> Total execution time: 1.0619
DEBUG - 2022-05-09 08:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:01:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-09 13:31:38 --> Severity: Notice --> Trying to get property 'sp_heading' of non-object /home/gvprods/public_html/v1/gvv3/application/controllers/User/Courses_Controller.php 40
ERROR - 2022-05-09 13:31:38 --> Severity: Notice --> Trying to get property 'sp_data' of non-object /home/gvprods/public_html/v1/gvv3/application/controllers/User/Courses_Controller.php 41
DEBUG - 2022-05-09 13:31:38 --> Total execution time: 0.0499
DEBUG - 2022-05-09 08:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:31:51 --> Total execution time: 0.8116
DEBUG - 2022-05-09 08:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:31:55 --> Total execution time: 0.0328
DEBUG - 2022-05-09 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:32:09 --> Total execution time: 0.8052
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:34:58 --> Total execution time: 0.9997
DEBUG - 2022-05-09 08:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:04:59 --> UTF-8 Support Enabled
ERROR - 2022-05-09 08:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:05:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:05:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:35:53 --> Total execution time: 0.0345
DEBUG - 2022-05-09 08:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:36:08 --> Total execution time: 0.0344
DEBUG - 2022-05-09 08:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:36:16 --> Total execution time: 0.0355
DEBUG - 2022-05-09 08:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:37:12 --> Total execution time: 0.8306
DEBUG - 2022-05-09 08:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:37:16 --> Total execution time: 0.0288
DEBUG - 2022-05-09 08:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:37:24 --> Total execution time: 0.0328
DEBUG - 2022-05-09 08:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:37:28 --> Total execution time: 0.0306
DEBUG - 2022-05-09 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:08:01 --> 404 Page Not Found: User/index
DEBUG - 2022-05-09 08:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:38:03 --> Total execution time: 0.0824
DEBUG - 2022-05-09 08:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:38:05 --> Total execution time: 0.0374
DEBUG - 2022-05-09 08:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:38:48 --> Total execution time: 0.8346
DEBUG - 2022-05-09 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 08:10:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 08:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:40:53 --> Total execution time: 0.0368
DEBUG - 2022-05-09 08:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:41:07 --> Total execution time: 0.0480
DEBUG - 2022-05-09 08:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:11:10 --> No URI present. Default controller set.
DEBUG - 2022-05-09 08:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:41:10 --> Total execution time: 0.0680
DEBUG - 2022-05-09 08:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:41:10 --> Total execution time: 0.0337
DEBUG - 2022-05-09 08:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:41:25 --> Total execution time: 0.0294
DEBUG - 2022-05-09 08:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:41:42 --> Total execution time: 0.0294
DEBUG - 2022-05-09 08:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:41:54 --> Total execution time: 0.0346
DEBUG - 2022-05-09 08:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:42:02 --> Total execution time: 0.0321
DEBUG - 2022-05-09 08:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:42:23 --> Total execution time: 0.0426
DEBUG - 2022-05-09 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:01 --> Total execution time: 0.0325
DEBUG - 2022-05-09 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:17 --> Total execution time: 0.0478
DEBUG - 2022-05-09 08:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:26 --> Total execution time: 0.0346
DEBUG - 2022-05-09 08:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:40 --> Total execution time: 0.0298
DEBUG - 2022-05-09 08:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:45 --> Total execution time: 0.0297
DEBUG - 2022-05-09 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:51 --> Total execution time: 0.0354
DEBUG - 2022-05-09 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:43:57 --> Total execution time: 0.0316
DEBUG - 2022-05-09 08:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:14:01 --> No URI present. Default controller set.
DEBUG - 2022-05-09 08:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:44:02 --> Total execution time: 0.0486
DEBUG - 2022-05-09 08:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:14:04 --> Total execution time: 0.1310
DEBUG - 2022-05-09 08:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:44:06 --> Total execution time: 0.0498
DEBUG - 2022-05-09 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:44:13 --> Total execution time: 0.0331
DEBUG - 2022-05-09 08:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:14:49 --> Total execution time: 0.0286
DEBUG - 2022-05-09 08:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:01 --> Total execution time: 0.0854
DEBUG - 2022-05-09 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:24 --> Total execution time: 0.0334
DEBUG - 2022-05-09 08:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:25 --> Total execution time: 0.0314
DEBUG - 2022-05-09 08:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:29 --> Total execution time: 0.0338
DEBUG - 2022-05-09 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:31 --> Total execution time: 0.0612
DEBUG - 2022-05-09 08:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:35 --> Total execution time: 0.0299
DEBUG - 2022-05-09 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:48 --> Total execution time: 0.0820
DEBUG - 2022-05-09 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:45:48 --> Total execution time: 0.0322
DEBUG - 2022-05-09 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:48:13 --> Total execution time: 0.1769
DEBUG - 2022-05-09 08:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:50:55 --> Total execution time: 0.6508
DEBUG - 2022-05-09 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:09 --> Total execution time: 0.0880
DEBUG - 2022-05-09 08:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:11 --> Total execution time: 0.0696
DEBUG - 2022-05-09 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:21 --> Total execution time: 0.0317
DEBUG - 2022-05-09 08:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:26 --> Total execution time: 0.0329
DEBUG - 2022-05-09 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:29 --> Total execution time: 0.0285
DEBUG - 2022-05-09 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:32 --> Total execution time: 0.0327
DEBUG - 2022-05-09 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:34 --> Total execution time: 0.0344
DEBUG - 2022-05-09 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:37 --> Total execution time: 0.0340
DEBUG - 2022-05-09 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:38 --> Total execution time: 0.0290
DEBUG - 2022-05-09 08:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:43 --> Total execution time: 0.0360
DEBUG - 2022-05-09 08:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:44 --> Total execution time: 0.0312
DEBUG - 2022-05-09 08:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:45 --> Total execution time: 0.0320
DEBUG - 2022-05-09 08:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:53:56 --> Total execution time: 0.3291
DEBUG - 2022-05-09 08:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:01 --> Total execution time: 0.0340
DEBUG - 2022-05-09 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:18 --> Total execution time: 0.0312
DEBUG - 2022-05-09 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:30 --> Total execution time: 0.0354
DEBUG - 2022-05-09 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:30 --> Total execution time: 0.0293
DEBUG - 2022-05-09 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:32 --> Total execution time: 0.0346
DEBUG - 2022-05-09 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:35 --> Total execution time: 0.0312
DEBUG - 2022-05-09 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:40 --> Total execution time: 0.0331
DEBUG - 2022-05-09 08:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:42 --> Total execution time: 0.0282
DEBUG - 2022-05-09 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:46 --> Total execution time: 0.0357
DEBUG - 2022-05-09 08:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:54:58 --> Total execution time: 0.0310
DEBUG - 2022-05-09 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:55:02 --> Total execution time: 0.2255
DEBUG - 2022-05-09 08:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:55:23 --> Total execution time: 0.0297
DEBUG - 2022-05-09 08:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:00:45 --> Total execution time: 0.8387
DEBUG - 2022-05-09 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:47:24 --> Total execution time: 1.1601
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:17:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:49:56 --> Total execution time: 0.8612
DEBUG - 2022-05-09 09:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-09 09:19:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:19:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:52:05 --> Total execution time: 0.8517
DEBUG - 2022-05-09 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:22:07 --> UTF-8 Support Enabled
ERROR - 2022-05-09 09:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:52:50 --> Total execution time: 0.8638
DEBUG - 2022-05-09 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 09:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:52:58 --> Total execution time: 0.0917
DEBUG - 2022-05-09 09:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:22:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:22:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:23:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:23:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:23:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:23:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 09:23:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-09 09:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:53:38 --> Total execution time: 0.5787
DEBUG - 2022-05-09 09:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 09:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:53:45 --> Total execution time: 0.0308
DEBUG - 2022-05-09 09:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 09:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 09:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 14:55:39 --> Total execution time: 0.6018
DEBUG - 2022-05-09 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 13:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 13:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 13:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 13:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 13:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-09 19:14:59 --> Total execution time: 0.1262
