<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-04 00:02:47 --> Total execution time: 0.0929
DEBUG - 2022-07-04 00:02:49 --> Total execution time: 0.0483
DEBUG - 2022-07-04 00:02:54 --> Total execution time: 0.0751
DEBUG - 2022-07-04 00:02:56 --> Total execution time: 0.0872
DEBUG - 2022-07-04 00:02:58 --> Total execution time: 0.0380
DEBUG - 2022-07-04 00:03:07 --> Total execution time: 0.0613
DEBUG - 2022-07-04 00:03:12 --> Total execution time: 0.0583
DEBUG - 2022-07-04 00:12:17 --> Total execution time: 0.1301
DEBUG - 2022-07-04 00:13:26 --> Total execution time: 0.0480
DEBUG - 2022-07-04 00:14:11 --> Total execution time: 0.0515
DEBUG - 2022-07-04 00:19:43 --> Total execution time: 0.0799
DEBUG - 2022-07-04 00:22:06 --> Total execution time: 0.0882
DEBUG - 2022-07-04 00:22:06 --> Total execution time: 0.0349
DEBUG - 2022-07-04 00:26:25 --> Total execution time: 0.0920
DEBUG - 2022-07-04 00:27:44 --> Total execution time: 0.1580
DEBUG - 2022-07-04 00:30:03 --> Total execution time: 0.4423
DEBUG - 2022-07-04 00:37:27 --> Total execution time: 0.2024
DEBUG - 2022-07-04 00:39:23 --> Total execution time: 0.0364
DEBUG - 2022-07-04 00:40:17 --> Total execution time: 0.0402
DEBUG - 2022-07-04 00:40:17 --> Total execution time: 0.0352
DEBUG - 2022-07-04 00:44:17 --> Total execution time: 0.0516
DEBUG - 2022-07-04 00:44:45 --> Total execution time: 0.0515
DEBUG - 2022-07-04 00:44:52 --> Total execution time: 0.0613
DEBUG - 2022-07-04 00:45:20 --> Total execution time: 0.0721
DEBUG - 2022-07-04 00:45:32 --> Total execution time: 0.0697
DEBUG - 2022-07-04 00:45:36 --> Total execution time: 0.0603
DEBUG - 2022-07-04 00:45:46 --> Total execution time: 0.0477
DEBUG - 2022-07-04 00:45:54 --> Total execution time: 0.0469
DEBUG - 2022-07-04 01:23:19 --> Total execution time: 0.2116
DEBUG - 2022-07-04 01:29:24 --> Total execution time: 0.0510
DEBUG - 2022-07-04 01:30:02 --> Total execution time: 0.0895
DEBUG - 2022-07-04 01:36:32 --> Total execution time: 0.0852
DEBUG - 2022-07-04 01:36:33 --> Total execution time: 0.0490
DEBUG - 2022-07-04 01:46:28 --> Total execution time: 0.1030
DEBUG - 2022-07-04 01:48:39 --> Total execution time: 0.0678
DEBUG - 2022-07-04 01:48:51 --> Total execution time: 0.0780
DEBUG - 2022-07-04 01:49:05 --> Total execution time: 0.0740
DEBUG - 2022-07-04 01:49:14 --> Total execution time: 0.0820
DEBUG - 2022-07-04 01:49:46 --> Total execution time: 0.0550
DEBUG - 2022-07-04 01:54:25 --> Total execution time: 0.0905
DEBUG - 2022-07-04 01:54:27 --> Total execution time: 0.0526
DEBUG - 2022-07-04 01:56:18 --> Total execution time: 0.1606
DEBUG - 2022-07-04 02:01:31 --> Total execution time: 0.1708
DEBUG - 2022-07-04 02:03:55 --> Total execution time: 0.0882
DEBUG - 2022-07-04 02:03:56 --> Total execution time: 0.0352
DEBUG - 2022-07-04 02:05:27 --> Total execution time: 0.0404
DEBUG - 2022-07-04 02:05:27 --> Total execution time: 0.0709
DEBUG - 2022-07-04 02:05:40 --> Total execution time: 0.0351
DEBUG - 2022-07-04 02:07:25 --> Total execution time: 0.0357
DEBUG - 2022-07-04 02:28:33 --> Total execution time: 0.1183
DEBUG - 2022-07-04 02:30:02 --> Total execution time: 0.0526
DEBUG - 2022-07-04 03:06:07 --> Total execution time: 0.0553
DEBUG - 2022-07-04 03:06:07 --> Total execution time: 0.0471
DEBUG - 2022-07-04 03:27:37 --> Total execution time: 0.2080
DEBUG - 2022-07-04 03:30:03 --> Total execution time: 0.1057
DEBUG - 2022-07-04 03:31:02 --> Total execution time: 0.0516
DEBUG - 2022-07-04 03:31:38 --> Total execution time: 0.0789
DEBUG - 2022-07-04 03:31:50 --> Total execution time: 0.0670
DEBUG - 2022-07-04 03:31:56 --> Total execution time: 0.0825
DEBUG - 2022-07-04 03:32:15 --> Total execution time: 0.0527
DEBUG - 2022-07-04 03:32:22 --> Total execution time: 0.1105
DEBUG - 2022-07-04 03:32:37 --> Total execution time: 0.0581
DEBUG - 2022-07-04 03:32:42 --> Total execution time: 0.0522
DEBUG - 2022-07-04 03:32:57 --> Total execution time: 0.0378
DEBUG - 2022-07-04 03:33:01 --> Total execution time: 0.0374
DEBUG - 2022-07-04 03:40:50 --> Total execution time: 0.0901
DEBUG - 2022-07-04 03:40:54 --> Total execution time: 0.0347
DEBUG - 2022-07-04 03:45:24 --> Total execution time: 0.1086
DEBUG - 2022-07-04 03:45:25 --> Total execution time: 0.0331
DEBUG - 2022-07-04 04:02:00 --> Total execution time: 0.0894
DEBUG - 2022-07-04 04:07:22 --> Total execution time: 0.0812
DEBUG - 2022-07-04 04:07:23 --> Total execution time: 0.0419
DEBUG - 2022-07-04 04:30:03 --> Total execution time: 0.1212
DEBUG - 2022-07-04 04:35:48 --> Total execution time: 0.0503
DEBUG - 2022-07-04 04:40:00 --> Total execution time: 0.1137
DEBUG - 2022-07-04 04:46:34 --> Total execution time: 0.1662
DEBUG - 2022-07-04 04:51:40 --> Total execution time: 0.1026
DEBUG - 2022-07-04 05:08:27 --> Total execution time: 0.1071
DEBUG - 2022-07-04 05:09:00 --> Total execution time: 0.0362
DEBUG - 2022-07-04 05:19:02 --> Total execution time: 0.1756
DEBUG - 2022-07-04 05:19:24 --> Total execution time: 0.0495
DEBUG - 2022-07-04 05:19:57 --> Total execution time: 0.0898
DEBUG - 2022-07-04 05:20:09 --> Total execution time: 0.0761
DEBUG - 2022-07-04 05:20:13 --> Total execution time: 0.0587
DEBUG - 2022-07-04 05:20:49 --> Total execution time: 0.0485
DEBUG - 2022-07-04 05:23:53 --> Total execution time: 0.0417
DEBUG - 2022-07-04 05:30:03 --> Total execution time: 0.0908
DEBUG - 2022-07-04 05:52:40 --> Total execution time: 0.0938
DEBUG - 2022-07-04 06:00:52 --> Total execution time: 0.1060
DEBUG - 2022-07-04 06:01:06 --> Total execution time: 0.0644
DEBUG - 2022-07-04 06:01:13 --> Total execution time: 0.0643
DEBUG - 2022-07-04 06:01:17 --> Total execution time: 0.0599
DEBUG - 2022-07-04 06:08:53 --> Total execution time: 0.0906
DEBUG - 2022-07-04 06:08:57 --> Total execution time: 0.0565
DEBUG - 2022-07-04 06:09:03 --> Total execution time: 0.0637
DEBUG - 2022-07-04 06:09:18 --> Total execution time: 0.0568
DEBUG - 2022-07-04 06:10:01 --> Total execution time: 0.0478
DEBUG - 2022-07-04 06:20:00 --> Total execution time: 0.1197
DEBUG - 2022-07-04 06:22:53 --> Total execution time: 0.1258
DEBUG - 2022-07-04 06:23:31 --> Total execution time: 0.0372
DEBUG - 2022-07-04 06:23:32 --> Total execution time: 0.0476
DEBUG - 2022-07-04 06:25:45 --> Total execution time: 0.0480
DEBUG - 2022-07-04 06:30:02 --> Total execution time: 0.1150
DEBUG - 2022-07-04 06:33:30 --> Total execution time: 0.0861
DEBUG - 2022-07-04 06:36:25 --> Total execution time: 0.0464
DEBUG - 2022-07-04 06:36:27 --> Total execution time: 0.0315
DEBUG - 2022-07-04 06:36:29 --> Total execution time: 0.0507
DEBUG - 2022-07-04 06:37:40 --> Total execution time: 0.0333
DEBUG - 2022-07-04 06:42:26 --> Total execution time: 0.2005
DEBUG - 2022-07-04 06:42:36 --> Total execution time: 0.0596
DEBUG - 2022-07-04 06:43:36 --> Total execution time: 0.0355
DEBUG - 2022-07-04 06:45:25 --> Total execution time: 0.0598
DEBUG - 2022-07-04 06:50:04 --> Total execution time: 0.0853
DEBUG - 2022-07-04 06:50:05 --> Total execution time: 0.0514
DEBUG - 2022-07-04 06:50:12 --> Total execution time: 0.0323
DEBUG - 2022-07-04 06:50:20 --> Total execution time: 0.0620
DEBUG - 2022-07-04 06:50:28 --> Total execution time: 0.0713
DEBUG - 2022-07-04 06:50:33 --> Total execution time: 0.0778
DEBUG - 2022-07-04 06:50:39 --> Total execution time: 0.0597
DEBUG - 2022-07-04 06:50:43 --> Total execution time: 0.0507
DEBUG - 2022-07-04 06:50:47 --> Total execution time: 0.0494
DEBUG - 2022-07-04 06:50:49 --> Total execution time: 0.0657
DEBUG - 2022-07-04 06:55:03 --> Total execution time: 0.0819
DEBUG - 2022-07-04 06:55:27 --> Total execution time: 0.0363
DEBUG - 2022-07-04 06:55:49 --> Total execution time: 0.0329
DEBUG - 2022-07-04 06:55:59 --> Total execution time: 0.0543
DEBUG - 2022-07-04 06:56:05 --> Total execution time: 0.0474
DEBUG - 2022-07-04 06:56:34 --> Total execution time: 0.0464
DEBUG - 2022-07-04 06:56:39 --> Total execution time: 0.0550
DEBUG - 2022-07-04 06:56:42 --> Total execution time: 0.0566
DEBUG - 2022-07-04 06:56:49 --> Total execution time: 0.0398
DEBUG - 2022-07-04 07:01:17 --> Total execution time: 0.0881
DEBUG - 2022-07-04 07:07:54 --> Total execution time: 0.0931
DEBUG - 2022-07-04 07:22:09 --> Total execution time: 0.1480
DEBUG - 2022-07-04 07:30:03 --> Total execution time: 0.1408
DEBUG - 2022-07-04 07:37:47 --> Total execution time: 0.1062
DEBUG - 2022-07-04 07:37:49 --> Total execution time: 0.0560
DEBUG - 2022-07-04 07:38:05 --> Total execution time: 0.0624
DEBUG - 2022-07-04 07:43:23 --> Total execution time: 0.0970
DEBUG - 2022-07-04 07:43:31 --> Total execution time: 0.0833
DEBUG - 2022-07-04 07:43:32 --> Total execution time: 0.0372
DEBUG - 2022-07-04 07:43:36 --> Total execution time: 0.0687
DEBUG - 2022-07-04 07:43:40 --> Total execution time: 0.0676
DEBUG - 2022-07-04 07:43:50 --> Total execution time: 0.0474
DEBUG - 2022-07-04 07:46:38 --> Total execution time: 0.0466
DEBUG - 2022-07-04 07:47:02 --> Total execution time: 0.0574
DEBUG - 2022-07-04 07:47:14 --> Total execution time: 0.1243
DEBUG - 2022-07-04 07:47:40 --> Total execution time: 0.0531
DEBUG - 2022-07-04 07:47:50 --> Total execution time: 0.0597
DEBUG - 2022-07-04 07:47:57 --> Total execution time: 0.0724
DEBUG - 2022-07-04 07:48:16 --> Total execution time: 0.0672
DEBUG - 2022-07-04 07:48:55 --> Total execution time: 0.0655
DEBUG - 2022-07-04 07:55:02 --> Total execution time: 0.1333
DEBUG - 2022-07-04 08:10:45 --> Total execution time: 0.1238
DEBUG - 2022-07-04 08:16:17 --> Total execution time: 0.0563
DEBUG - 2022-07-04 08:21:25 --> Total execution time: 0.1027
DEBUG - 2022-07-04 08:21:30 --> Total execution time: 0.0342
DEBUG - 2022-07-04 08:21:32 --> Total execution time: 0.0500
DEBUG - 2022-07-04 08:21:34 --> Total execution time: 0.0518
DEBUG - 2022-07-04 08:21:37 --> Total execution time: 0.0464
DEBUG - 2022-07-04 08:21:39 --> Total execution time: 0.0713
DEBUG - 2022-07-04 08:21:41 --> Total execution time: 0.0472
DEBUG - 2022-07-04 08:21:51 --> Total execution time: 0.0537
DEBUG - 2022-07-04 08:21:58 --> Total execution time: 0.0641
DEBUG - 2022-07-04 08:22:04 --> Total execution time: 0.0597
DEBUG - 2022-07-04 08:22:19 --> Total execution time: 0.0310
DEBUG - 2022-07-04 08:22:22 --> Total execution time: 0.0460
DEBUG - 2022-07-04 08:22:24 --> Total execution time: 0.0451
DEBUG - 2022-07-04 08:22:26 --> Total execution time: 0.0465
DEBUG - 2022-07-04 08:22:43 --> Total execution time: 0.0682
DEBUG - 2022-07-04 08:22:49 --> Total execution time: 0.0522
DEBUG - 2022-07-04 08:22:53 --> Total execution time: 0.0752
DEBUG - 2022-07-04 08:22:56 --> Total execution time: 0.0460
DEBUG - 2022-07-04 08:22:59 --> Total execution time: 0.0483
DEBUG - 2022-07-04 08:23:16 --> Total execution time: 0.0573
DEBUG - 2022-07-04 08:23:20 --> Total execution time: 0.0484
DEBUG - 2022-07-04 08:23:43 --> Total execution time: 0.0574
DEBUG - 2022-07-04 08:24:18 --> Total execution time: 0.0774
DEBUG - 2022-07-04 08:24:29 --> Total execution time: 0.0643
DEBUG - 2022-07-04 08:24:42 --> Total execution time: 0.0560
DEBUG - 2022-07-04 08:24:52 --> Total execution time: 0.0705
DEBUG - 2022-07-04 08:24:54 --> Total execution time: 0.0512
DEBUG - 2022-07-04 08:24:57 --> Total execution time: 0.0573
DEBUG - 2022-07-04 08:24:57 --> Total execution time: 0.0560
DEBUG - 2022-07-04 08:25:02 --> Total execution time: 0.0481
DEBUG - 2022-07-04 08:25:08 --> Total execution time: 0.0507
DEBUG - 2022-07-04 08:26:52 --> Total execution time: 0.0602
DEBUG - 2022-07-04 08:26:56 --> Total execution time: 0.0616
DEBUG - 2022-07-04 08:27:16 --> Total execution time: 0.0625
DEBUG - 2022-07-04 08:27:17 --> Total execution time: 0.0730
DEBUG - 2022-07-04 08:27:26 --> Total execution time: 0.1795
DEBUG - 2022-07-04 08:27:53 --> Total execution time: 0.0694
DEBUG - 2022-07-04 08:27:53 --> Total execution time: 0.1043
DEBUG - 2022-07-04 08:28:06 --> Total execution time: 0.0578
DEBUG - 2022-07-04 08:28:10 --> Total execution time: 0.0526
DEBUG - 2022-07-04 08:28:14 --> Total execution time: 0.0932
DEBUG - 2022-07-04 08:28:19 --> Total execution time: 0.0673
DEBUG - 2022-07-04 08:29:52 --> Total execution time: 0.0412
DEBUG - 2022-07-04 08:29:59 --> Total execution time: 0.0352
DEBUG - 2022-07-04 08:30:02 --> Total execution time: 0.0944
DEBUG - 2022-07-04 08:30:04 --> Total execution time: 0.0513
DEBUG - 2022-07-04 08:30:07 --> Total execution time: 0.0443
DEBUG - 2022-07-04 08:30:39 --> Total execution time: 0.0371
DEBUG - 2022-07-04 08:31:05 --> Total execution time: 0.0459
DEBUG - 2022-07-04 08:31:26 --> Total execution time: 0.0497
DEBUG - 2022-07-04 08:31:41 --> Total execution time: 0.0475
DEBUG - 2022-07-04 08:31:45 --> Total execution time: 0.0584
DEBUG - 2022-07-04 08:33:18 --> Total execution time: 0.0481
DEBUG - 2022-07-04 08:33:26 --> Total execution time: 0.0510
DEBUG - 2022-07-04 08:33:31 --> Total execution time: 0.0499
DEBUG - 2022-07-04 08:33:42 --> Total execution time: 0.0518
DEBUG - 2022-07-04 08:33:55 --> Total execution time: 0.0542
DEBUG - 2022-07-04 08:34:01 --> Total execution time: 0.0629
DEBUG - 2022-07-04 08:34:10 --> Total execution time: 0.0469
DEBUG - 2022-07-04 08:34:28 --> Total execution time: 0.0576
DEBUG - 2022-07-04 08:34:35 --> Total execution time: 0.0643
DEBUG - 2022-07-04 08:35:13 --> Total execution time: 0.1288
DEBUG - 2022-07-04 08:36:24 --> Total execution time: 0.1230
DEBUG - 2022-07-04 08:37:03 --> Total execution time: 0.0774
DEBUG - 2022-07-04 08:37:04 --> Total execution time: 0.0299
DEBUG - 2022-07-04 08:37:22 --> Total execution time: 0.0331
DEBUG - 2022-07-04 08:37:44 --> Total execution time: 0.0549
DEBUG - 2022-07-04 08:37:56 --> Total execution time: 0.0624
DEBUG - 2022-07-04 08:37:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:37:57 --> Total execution time: 0.0516
DEBUG - 2022-07-04 08:38:16 --> Total execution time: 0.0316
DEBUG - 2022-07-04 08:38:17 --> Total execution time: 0.0461
DEBUG - 2022-07-04 08:38:29 --> Total execution time: 0.0467
DEBUG - 2022-07-04 08:40:00 --> Total execution time: 0.0471
DEBUG - 2022-07-04 08:40:15 --> Total execution time: 0.0577
DEBUG - 2022-07-04 08:40:25 --> Total execution time: 0.0655
DEBUG - 2022-07-04 08:40:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:40:31 --> Total execution time: 0.0460
DEBUG - 2022-07-04 08:41:02 --> Total execution time: 0.0361
DEBUG - 2022-07-04 08:41:08 --> Total execution time: 0.0311
DEBUG - 2022-07-04 08:41:31 --> Total execution time: 0.0545
DEBUG - 2022-07-04 08:41:32 --> Total execution time: 0.0514
DEBUG - 2022-07-04 08:41:42 --> Total execution time: 0.0612
DEBUG - 2022-07-04 08:41:45 --> Total execution time: 0.0523
DEBUG - 2022-07-04 08:41:55 --> Total execution time: 0.0470
DEBUG - 2022-07-04 08:43:34 --> Total execution time: 0.0468
DEBUG - 2022-07-04 08:45:41 --> Total execution time: 0.0538
DEBUG - 2022-07-04 08:46:27 --> Total execution time: 0.1140
DEBUG - 2022-07-04 08:47:55 --> Total execution time: 0.1141
DEBUG - 2022-07-04 08:48:00 --> Total execution time: 0.0503
DEBUG - 2022-07-04 08:48:04 --> Total execution time: 0.0460
DEBUG - 2022-07-04 08:48:46 --> Total execution time: 0.0459
DEBUG - 2022-07-04 08:49:22 --> Total execution time: 0.0500
DEBUG - 2022-07-04 08:51:02 --> Total execution time: 0.0769
DEBUG - 2022-07-04 08:51:07 --> Total execution time: 0.0476
DEBUG - 2022-07-04 08:51:13 --> Total execution time: 0.0376
DEBUG - 2022-07-04 08:54:07 --> Total execution time: 0.1352
DEBUG - 2022-07-04 08:54:31 --> Total execution time: 0.0606
DEBUG - 2022-07-04 08:54:40 --> Total execution time: 0.0743
DEBUG - 2022-07-04 08:54:59 --> Total execution time: 0.0486
DEBUG - 2022-07-04 08:55:14 --> Total execution time: 0.0707
DEBUG - 2022-07-04 08:55:18 --> Total execution time: 0.0640
DEBUG - 2022-07-04 08:55:18 --> Total execution time: 0.0531
DEBUG - 2022-07-04 08:55:23 --> Total execution time: 0.0555
DEBUG - 2022-07-04 08:55:25 --> Total execution time: 0.0837
DEBUG - 2022-07-04 08:55:46 --> Total execution time: 0.0479
DEBUG - 2022-07-04 08:56:25 --> Total execution time: 0.0609
DEBUG - 2022-07-04 08:56:55 --> Total execution time: 0.0336
DEBUG - 2022-07-04 08:57:04 --> Total execution time: 0.0542
DEBUG - 2022-07-04 08:57:11 --> Total execution time: 0.0533
DEBUG - 2022-07-04 08:57:14 --> Total execution time: 0.0496
DEBUG - 2022-07-04 08:57:16 --> Total execution time: 0.0614
DEBUG - 2022-07-04 08:57:21 --> Total execution time: 0.0712
DEBUG - 2022-07-04 08:57:32 --> Total execution time: 0.0520
DEBUG - 2022-07-04 08:57:36 --> Total execution time: 0.0559
DEBUG - 2022-07-04 08:57:43 --> Total execution time: 0.1494
DEBUG - 2022-07-04 08:57:51 --> Total execution time: 0.0562
DEBUG - 2022-07-04 08:58:08 --> Total execution time: 0.0686
DEBUG - 2022-07-04 08:58:08 --> Total execution time: 0.0503
DEBUG - 2022-07-04 08:58:24 --> Total execution time: 0.0687
DEBUG - 2022-07-04 08:58:31 --> Total execution time: 0.0476
DEBUG - 2022-07-04 08:58:52 --> Total execution time: 0.0613
DEBUG - 2022-07-04 08:58:54 --> Total execution time: 0.0404
DEBUG - 2022-07-04 08:59:07 --> Total execution time: 0.0468
DEBUG - 2022-07-04 08:59:11 --> Total execution time: 0.1271
DEBUG - 2022-07-04 08:59:50 --> Total execution time: 0.0345
DEBUG - 2022-07-04 09:00:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 09:00:35 --> Total execution time: 0.0810
DEBUG - 2022-07-04 09:06:08 --> Total execution time: 0.0395
DEBUG - 2022-07-04 09:06:11 --> Total execution time: 0.0476
DEBUG - 2022-07-04 09:06:13 --> Total execution time: 0.0490
DEBUG - 2022-07-04 09:06:22 --> Total execution time: 0.0615
DEBUG - 2022-07-04 09:06:27 --> Total execution time: 0.0608
DEBUG - 2022-07-04 09:06:30 --> Total execution time: 0.1294
DEBUG - 2022-07-04 09:06:32 --> Total execution time: 0.0790
DEBUG - 2022-07-04 09:07:12 --> Total execution time: 0.0492
DEBUG - 2022-07-04 09:07:18 --> Total execution time: 0.0557
DEBUG - 2022-07-04 09:07:39 --> Total execution time: 0.0590
DEBUG - 2022-07-04 09:07:40 --> Total execution time: 0.0532
DEBUG - 2022-07-04 09:07:42 --> Total execution time: 0.0537
DEBUG - 2022-07-04 09:08:13 --> Total execution time: 0.0456
DEBUG - 2022-07-04 09:08:42 --> Total execution time: 0.0333
DEBUG - 2022-07-04 09:10:43 --> Total execution time: 0.0658
DEBUG - 2022-07-04 09:10:58 --> Total execution time: 0.0603
DEBUG - 2022-07-04 09:10:59 --> Total execution time: 0.0771
DEBUG - 2022-07-04 09:11:04 --> Total execution time: 0.0616
DEBUG - 2022-07-04 09:11:14 --> Total execution time: 1.7489
DEBUG - 2022-07-04 09:11:48 --> Total execution time: 1.5503
DEBUG - 2022-07-04 09:11:50 --> Total execution time: 0.0609
DEBUG - 2022-07-04 09:11:54 --> Total execution time: 0.0810
DEBUG - 2022-07-04 09:13:15 --> Total execution time: 0.0647
DEBUG - 2022-07-04 09:13:28 --> Total execution time: 0.0829
DEBUG - 2022-07-04 09:14:09 --> Total execution time: 0.1456
DEBUG - 2022-07-04 09:14:10 --> Total execution time: 0.0603
DEBUG - 2022-07-04 09:14:12 --> Total execution time: 0.0931
DEBUG - 2022-07-04 09:14:21 --> Total execution time: 0.0590
DEBUG - 2022-07-04 09:14:21 --> Total execution time: 0.0645
DEBUG - 2022-07-04 09:14:22 --> Total execution time: 0.0343
DEBUG - 2022-07-04 09:14:41 --> Total execution time: 0.0658
DEBUG - 2022-07-04 09:18:01 --> Total execution time: 0.2217
DEBUG - 2022-07-04 09:19:56 --> Total execution time: 0.0829
DEBUG - 2022-07-04 09:20:36 --> Total execution time: 0.0403
DEBUG - 2022-07-04 09:21:38 --> Total execution time: 0.0493
DEBUG - 2022-07-04 09:21:42 --> Total execution time: 0.0353
DEBUG - 2022-07-04 09:21:46 --> Total execution time: 0.0625
DEBUG - 2022-07-04 09:21:48 --> Total execution time: 0.0429
DEBUG - 2022-07-04 09:21:49 --> Total execution time: 0.0540
DEBUG - 2022-07-04 09:21:50 --> Total execution time: 0.0399
DEBUG - 2022-07-04 09:21:51 --> Total execution time: 0.0422
DEBUG - 2022-07-04 09:21:51 --> Total execution time: 0.0669
DEBUG - 2022-07-04 09:21:51 --> Total execution time: 0.0316
DEBUG - 2022-07-04 09:21:51 --> Total execution time: 0.0701
DEBUG - 2022-07-04 09:21:52 --> Total execution time: 0.0420
DEBUG - 2022-07-04 09:21:52 --> Total execution time: 0.0407
DEBUG - 2022-07-04 09:21:52 --> Total execution time: 0.0545
DEBUG - 2022-07-04 09:21:53 --> Total execution time: 0.0446
DEBUG - 2022-07-04 09:21:53 --> Total execution time: 0.0623
DEBUG - 2022-07-04 09:22:29 --> Total execution time: 0.0612
DEBUG - 2022-07-04 09:23:04 --> Total execution time: 0.0443
DEBUG - 2022-07-04 09:23:05 --> Total execution time: 0.0593
DEBUG - 2022-07-04 09:23:05 --> Total execution time: 0.0326
DEBUG - 2022-07-04 09:24:16 --> Total execution time: 0.0584
DEBUG - 2022-07-04 09:25:01 --> Total execution time: 0.0594
DEBUG - 2022-07-04 09:25:15 --> Total execution time: 0.0670
DEBUG - 2022-07-04 09:26:08 --> Total execution time: 0.0360
DEBUG - 2022-07-04 09:26:08 --> Total execution time: 0.0596
DEBUG - 2022-07-04 09:26:26 --> Total execution time: 0.1287
DEBUG - 2022-07-04 09:26:41 --> Total execution time: 0.0885
DEBUG - 2022-07-04 09:26:51 --> Total execution time: 0.0694
DEBUG - 2022-07-04 09:26:53 --> Total execution time: 0.0899
DEBUG - 2022-07-04 09:27:04 --> Total execution time: 0.0693
DEBUG - 2022-07-04 09:27:41 --> Total execution time: 0.0503
DEBUG - 2022-07-04 09:27:44 --> Total execution time: 0.0577
DEBUG - 2022-07-04 09:28:01 --> Total execution time: 0.0520
DEBUG - 2022-07-04 09:28:04 --> Total execution time: 0.0727
DEBUG - 2022-07-04 09:28:18 --> Total execution time: 0.0855
DEBUG - 2022-07-04 09:29:37 --> Total execution time: 0.1076
DEBUG - 2022-07-04 09:29:45 --> Total execution time: 0.0666
DEBUG - 2022-07-04 09:29:59 --> Total execution time: 0.0330
DEBUG - 2022-07-04 09:30:01 --> Total execution time: 0.0977
DEBUG - 2022-07-04 09:30:02 --> Total execution time: 0.1101
DEBUG - 2022-07-04 09:30:02 --> Total execution time: 0.1438
DEBUG - 2022-07-04 09:30:04 --> Total execution time: 0.1043
DEBUG - 2022-07-04 09:30:06 --> Total execution time: 0.1031
DEBUG - 2022-07-04 09:30:09 --> Total execution time: 0.1660
DEBUG - 2022-07-04 09:30:11 --> Total execution time: 0.1197
DEBUG - 2022-07-04 09:30:11 --> Total execution time: 0.1078
DEBUG - 2022-07-04 09:30:11 --> Total execution time: 0.1089
DEBUG - 2022-07-04 09:30:12 --> Total execution time: 0.1171
DEBUG - 2022-07-04 09:30:12 --> Total execution time: 0.0848
DEBUG - 2022-07-04 09:30:14 --> Total execution time: 0.0808
DEBUG - 2022-07-04 09:30:15 --> Total execution time: 0.0810
DEBUG - 2022-07-04 09:30:17 --> Total execution time: 0.0670
DEBUG - 2022-07-04 09:30:19 --> Total execution time: 0.0737
DEBUG - 2022-07-04 09:30:20 --> Total execution time: 0.0860
DEBUG - 2022-07-04 09:30:20 --> Total execution time: 0.1174
DEBUG - 2022-07-04 09:30:21 --> Total execution time: 0.0568
DEBUG - 2022-07-04 09:30:22 --> Total execution time: 0.0537
DEBUG - 2022-07-04 09:30:22 --> Total execution time: 0.0591
DEBUG - 2022-07-04 09:30:23 --> Total execution time: 0.0511
DEBUG - 2022-07-04 09:30:30 --> Total execution time: 0.0480
DEBUG - 2022-07-04 09:30:38 --> Total execution time: 0.0456
DEBUG - 2022-07-04 09:30:44 --> Total execution time: 0.0558
DEBUG - 2022-07-04 09:30:46 --> Total execution time: 0.0659
DEBUG - 2022-07-04 09:30:47 --> Total execution time: 0.0513
DEBUG - 2022-07-04 09:30:47 --> Total execution time: 0.0486
DEBUG - 2022-07-04 09:30:53 --> Total execution time: 0.0550
DEBUG - 2022-07-04 09:30:59 --> Total execution time: 0.0616
DEBUG - 2022-07-04 09:42:12 --> Total execution time: 0.3928
DEBUG - 2022-07-04 09:48:45 --> Total execution time: 0.1700
DEBUG - 2022-07-04 09:48:54 --> Total execution time: 0.0535
DEBUG - 2022-07-04 09:49:15 --> Total execution time: 0.0583
DEBUG - 2022-07-04 09:49:26 --> Total execution time: 0.0618
DEBUG - 2022-07-04 09:49:50 --> Total execution time: 0.0552
DEBUG - 2022-07-04 09:49:52 --> Total execution time: 0.0577
DEBUG - 2022-07-04 09:50:07 --> Total execution time: 0.0739
DEBUG - 2022-07-04 09:51:05 --> Total execution time: 0.1046
DEBUG - 2022-07-04 09:52:33 --> Total execution time: 0.0499
DEBUG - 2022-07-04 09:53:18 --> Total execution time: 0.0573
DEBUG - 2022-07-04 09:53:31 --> Total execution time: 0.0354
DEBUG - 2022-07-04 09:53:54 --> Total execution time: 0.0553
DEBUG - 2022-07-04 09:55:01 --> Total execution time: 0.0369
DEBUG - 2022-07-04 09:57:06 --> Total execution time: 0.0755
DEBUG - 2022-07-04 09:57:14 --> Total execution time: 0.0577
DEBUG - 2022-07-04 09:57:18 --> Total execution time: 0.0977
DEBUG - 2022-07-04 09:57:20 --> Total execution time: 0.0533
DEBUG - 2022-07-04 09:57:22 --> Total execution time: 0.0458
DEBUG - 2022-07-04 09:57:24 --> Total execution time: 0.0450
DEBUG - 2022-07-04 09:57:26 --> Total execution time: 0.0570
DEBUG - 2022-07-04 09:57:28 --> Total execution time: 0.0827
DEBUG - 2022-07-04 09:57:32 --> Total execution time: 0.0600
DEBUG - 2022-07-04 09:57:34 --> Total execution time: 0.0438
DEBUG - 2022-07-04 09:57:54 --> Total execution time: 0.0858
DEBUG - 2022-07-04 09:58:11 --> Total execution time: 0.0661
DEBUG - 2022-07-04 09:59:17 --> Total execution time: 0.0355
DEBUG - 2022-07-04 09:59:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 09:59:20 --> Total execution time: 0.0683
DEBUG - 2022-07-04 09:59:24 --> Total execution time: 0.0413
DEBUG - 2022-07-04 09:59:27 --> Total execution time: 0.0518
DEBUG - 2022-07-04 09:59:48 --> Total execution time: 0.0454
DEBUG - 2022-07-04 09:59:53 --> Total execution time: 0.0515
DEBUG - 2022-07-04 10:00:00 --> Total execution time: 0.0591
DEBUG - 2022-07-04 10:00:09 --> Total execution time: 0.0481
DEBUG - 2022-07-04 10:00:16 --> Total execution time: 0.0476
DEBUG - 2022-07-04 10:00:29 --> Total execution time: 0.0540
DEBUG - 2022-07-04 10:00:31 --> Total execution time: 0.0558
DEBUG - 2022-07-04 10:00:35 --> Total execution time: 0.0908
DEBUG - 2022-07-04 10:00:39 --> Total execution time: 0.0499
DEBUG - 2022-07-04 10:01:03 --> Total execution time: 0.0702
DEBUG - 2022-07-04 10:01:16 --> Total execution time: 0.0375
DEBUG - 2022-07-04 10:01:17 --> Total execution time: 0.0323
DEBUG - 2022-07-04 10:01:23 --> Total execution time: 0.0555
DEBUG - 2022-07-04 10:01:28 --> Total execution time: 0.0664
DEBUG - 2022-07-04 10:01:29 --> Total execution time: 0.0666
DEBUG - 2022-07-04 10:01:32 --> Total execution time: 0.0648
DEBUG - 2022-07-04 10:01:34 --> Total execution time: 0.0544
DEBUG - 2022-07-04 10:01:42 --> Total execution time: 0.0638
DEBUG - 2022-07-04 10:01:48 --> Total execution time: 0.0511
DEBUG - 2022-07-04 10:01:51 --> Total execution time: 0.0374
DEBUG - 2022-07-04 10:02:45 --> Total execution time: 0.0529
DEBUG - 2022-07-04 10:02:48 --> Total execution time: 0.0497
DEBUG - 2022-07-04 10:02:49 --> Total execution time: 0.1145
DEBUG - 2022-07-04 10:02:53 --> Total execution time: 0.0442
DEBUG - 2022-07-04 10:03:16 --> Total execution time: 0.0566
DEBUG - 2022-07-04 10:03:34 --> Total execution time: 0.0745
DEBUG - 2022-07-04 10:03:43 --> Total execution time: 0.0595
DEBUG - 2022-07-04 10:04:01 --> Total execution time: 0.0499
DEBUG - 2022-07-04 10:06:31 --> Total execution time: 0.0441
DEBUG - 2022-07-04 10:06:36 --> Total execution time: 0.0531
DEBUG - 2022-07-04 10:06:43 --> Total execution time: 0.0559
DEBUG - 2022-07-04 10:06:46 --> Total execution time: 0.0588
DEBUG - 2022-07-04 10:11:31 --> Total execution time: 0.0629
DEBUG - 2022-07-04 10:11:36 --> Total execution time: 0.0454
DEBUG - 2022-07-04 10:11:50 --> Total execution time: 0.0486
DEBUG - 2022-07-04 10:12:43 --> Total execution time: 0.0447
DEBUG - 2022-07-04 10:13:03 --> Total execution time: 0.0548
DEBUG - 2022-07-04 10:13:10 --> Total execution time: 0.0563
DEBUG - 2022-07-04 10:13:17 --> Total execution time: 0.0646
DEBUG - 2022-07-04 10:15:13 --> Total execution time: 0.0479
DEBUG - 2022-07-04 10:15:53 --> Total execution time: 0.0586
DEBUG - 2022-07-04 10:16:04 --> Total execution time: 0.0671
DEBUG - 2022-07-04 10:16:11 --> Total execution time: 0.0609
DEBUG - 2022-07-04 10:17:12 --> Total execution time: 0.0560
DEBUG - 2022-07-04 10:17:59 --> Total execution time: 0.1282
DEBUG - 2022-07-04 10:18:04 --> Total execution time: 0.0902
DEBUG - 2022-07-04 10:18:37 --> Total execution time: 0.0581
DEBUG - 2022-07-04 10:18:48 --> Total execution time: 0.0562
DEBUG - 2022-07-04 10:19:08 --> Total execution time: 0.0469
DEBUG - 2022-07-04 10:19:33 --> Total execution time: 0.1185
DEBUG - 2022-07-04 10:19:34 --> Total execution time: 0.0688
DEBUG - 2022-07-04 10:19:55 --> Total execution time: 0.0639
DEBUG - 2022-07-04 10:20:42 --> Total execution time: 0.0589
DEBUG - 2022-07-04 10:21:22 --> Total execution time: 0.0514
DEBUG - 2022-07-04 10:21:32 --> Total execution time: 0.0635
DEBUG - 2022-07-04 10:21:53 --> Total execution time: 0.0612
DEBUG - 2022-07-04 10:22:03 --> Total execution time: 0.0763
DEBUG - 2022-07-04 10:22:08 --> Total execution time: 0.0752
DEBUG - 2022-07-04 10:22:20 --> Total execution time: 0.0519
DEBUG - 2022-07-04 10:22:24 --> Total execution time: 0.0565
DEBUG - 2022-07-04 10:22:35 --> Total execution time: 0.0723
DEBUG - 2022-07-04 10:22:43 --> Total execution time: 0.0511
DEBUG - 2022-07-04 10:25:25 --> Total execution time: 0.1303
DEBUG - 2022-07-04 10:25:29 --> Total execution time: 0.0420
DEBUG - 2022-07-04 10:25:46 --> Total execution time: 0.0541
DEBUG - 2022-07-04 10:25:58 --> Total execution time: 0.0780
DEBUG - 2022-07-04 10:26:03 --> Total execution time: 0.0818
DEBUG - 2022-07-04 10:26:21 --> Total execution time: 0.0603
DEBUG - 2022-07-04 10:26:38 --> Total execution time: 1.5511
DEBUG - 2022-07-04 10:27:01 --> Total execution time: 0.0782
DEBUG - 2022-07-04 10:27:07 --> Total execution time: 0.0739
DEBUG - 2022-07-04 10:27:10 --> Total execution time: 0.0919
DEBUG - 2022-07-04 10:27:20 --> Total execution time: 0.0593
DEBUG - 2022-07-04 10:27:29 --> Total execution time: 0.0491
DEBUG - 2022-07-04 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:30:02 --> Total execution time: 0.4094
DEBUG - 2022-07-04 00:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:01:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 00:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:31:42 --> Total execution time: 1.5580
DEBUG - 2022-07-04 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:31:59 --> Total execution time: 0.0684
DEBUG - 2022-07-04 00:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:03:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:33:08 --> Total execution time: 0.1281
DEBUG - 2022-07-04 00:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:33:19 --> Total execution time: 0.0759
DEBUG - 2022-07-04 00:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:33:26 --> Total execution time: 0.0626
DEBUG - 2022-07-04 00:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:03 --> Total execution time: 0.0889
DEBUG - 2022-07-04 00:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:12 --> Total execution time: 0.0743
DEBUG - 2022-07-04 00:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:18 --> Total execution time: 0.0633
DEBUG - 2022-07-04 00:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:04:23 --> Total execution time: 0.0981
DEBUG - 2022-07-04 00:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:24 --> Total execution time: 0.0855
DEBUG - 2022-07-04 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:04:27 --> Total execution time: 0.1074
DEBUG - 2022-07-04 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:28 --> Total execution time: 0.0568
DEBUG - 2022-07-04 00:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:37 --> Total execution time: 0.0645
DEBUG - 2022-07-04 00:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:43 --> Total execution time: 0.0641
DEBUG - 2022-07-04 00:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:51 --> Total execution time: 0.0673
DEBUG - 2022-07-04 00:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:34:59 --> Total execution time: 0.0605
DEBUG - 2022-07-04 00:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:03 --> Total execution time: 0.0691
DEBUG - 2022-07-04 00:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:12 --> Total execution time: 0.0631
DEBUG - 2022-07-04 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:13 --> Total execution time: 0.0428
DEBUG - 2022-07-04 00:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:37 --> Total execution time: 0.0571
DEBUG - 2022-07-04 00:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:41 --> Total execution time: 0.0551
DEBUG - 2022-07-04 00:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:41 --> Total execution time: 0.0899
DEBUG - 2022-07-04 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:48 --> Total execution time: 0.0709
DEBUG - 2022-07-04 00:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:49 --> Total execution time: 0.0804
DEBUG - 2022-07-04 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:35:54 --> Total execution time: 0.0603
DEBUG - 2022-07-04 00:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:00 --> Total execution time: 0.0549
DEBUG - 2022-07-04 00:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:03 --> Total execution time: 0.0563
DEBUG - 2022-07-04 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:07 --> Total execution time: 0.0656
DEBUG - 2022-07-04 00:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:16 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:16 --> Total execution time: 0.0363
DEBUG - 2022-07-04 00:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:39 --> Total execution time: 0.1386
DEBUG - 2022-07-04 00:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:40 --> Total execution time: 0.0974
DEBUG - 2022-07-04 00:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:45 --> Total execution time: 0.0541
DEBUG - 2022-07-04 00:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:47 --> Total execution time: 0.0506
DEBUG - 2022-07-04 00:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:53 --> Total execution time: 0.0583
DEBUG - 2022-07-04 00:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:03 --> Total execution time: 0.0581
DEBUG - 2022-07-04 00:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:08 --> Total execution time: 0.0918
DEBUG - 2022-07-04 00:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:19 --> Total execution time: 0.0592
DEBUG - 2022-07-04 00:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:22 --> Total execution time: 0.0591
DEBUG - 2022-07-04 00:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:33 --> Total execution time: 0.0625
DEBUG - 2022-07-04 00:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:34 --> Total execution time: 0.0623
DEBUG - 2022-07-04 00:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:46 --> Total execution time: 0.0673
DEBUG - 2022-07-04 00:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:59 --> Total execution time: 0.0474
DEBUG - 2022-07-04 00:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:31 --> Total execution time: 0.0777
DEBUG - 2022-07-04 00:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:41 --> Total execution time: 0.0852
DEBUG - 2022-07-04 00:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:46 --> Total execution time: 0.1803
DEBUG - 2022-07-04 00:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:02 --> Total execution time: 0.0704
DEBUG - 2022-07-04 00:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:07 --> Total execution time: 0.0640
DEBUG - 2022-07-04 00:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:10 --> Total execution time: 0.0524
DEBUG - 2022-07-04 00:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:11 --> Total execution time: 0.1571
DEBUG - 2022-07-04 00:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:14 --> Total execution time: 0.0489
DEBUG - 2022-07-04 00:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:19 --> Total execution time: 0.0679
DEBUG - 2022-07-04 00:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:22 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:22 --> Total execution time: 0.1506
DEBUG - 2022-07-04 00:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:23 --> Total execution time: 0.0729
DEBUG - 2022-07-04 00:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:30 --> Total execution time: 0.0699
DEBUG - 2022-07-04 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:39 --> Total execution time: 0.0616
DEBUG - 2022-07-04 00:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:40 --> Total execution time: 0.0378
DEBUG - 2022-07-04 00:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:45 --> Total execution time: 0.0452
DEBUG - 2022-07-04 00:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:47 --> Total execution time: 0.0638
DEBUG - 2022-07-04 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:50 --> Total execution time: 0.0566
DEBUG - 2022-07-04 00:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:52 --> Total execution time: 0.0804
DEBUG - 2022-07-04 00:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:54 --> Total execution time: 0.0826
DEBUG - 2022-07-04 00:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:00 --> Total execution time: 1.5360
DEBUG - 2022-07-04 00:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:12 --> Total execution time: 0.1033
DEBUG - 2022-07-04 00:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:17 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:17 --> Total execution time: 0.0726
DEBUG - 2022-07-04 00:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:20 --> Total execution time: 0.0486
DEBUG - 2022-07-04 00:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:26 --> Total execution time: 0.0488
DEBUG - 2022-07-04 00:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:28 --> Total execution time: 0.0646
DEBUG - 2022-07-04 00:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:33 --> Total execution time: 0.0535
DEBUG - 2022-07-04 00:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:35 --> Total execution time: 0.0509
DEBUG - 2022-07-04 00:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:40 --> Total execution time: 0.0732
DEBUG - 2022-07-04 00:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:43 --> Total execution time: 0.0614
DEBUG - 2022-07-04 00:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:45 --> Total execution time: 0.0566
DEBUG - 2022-07-04 00:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:49 --> Total execution time: 0.0697
DEBUG - 2022-07-04 00:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:41:28 --> Total execution time: 0.0642
DEBUG - 2022-07-04 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:41:45 --> Total execution time: 0.0708
DEBUG - 2022-07-04 00:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:41:54 --> Total execution time: 0.0566
DEBUG - 2022-07-04 00:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:41:55 --> Total execution time: 0.0473
DEBUG - 2022-07-04 00:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:41:56 --> Total execution time: 0.0577
DEBUG - 2022-07-04 00:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:12:03 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-04 00:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:12:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 00:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:12:09 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-07-04 00:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:42:43 --> Total execution time: 0.0796
DEBUG - 2022-07-04 00:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:42:45 --> Total execution time: 0.0459
DEBUG - 2022-07-04 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:12:47 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-04 00:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:42:49 --> Total execution time: 0.0397
DEBUG - 2022-07-04 00:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:12:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:42:50 --> Total execution time: 0.0364
DEBUG - 2022-07-04 00:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:13:01 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-04 00:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:43:32 --> Total execution time: 0.0320
DEBUG - 2022-07-04 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:14:09 --> Total execution time: 0.0540
DEBUG - 2022-07-04 00:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:13 --> Total execution time: 0.0647
DEBUG - 2022-07-04 00:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:28 --> Total execution time: 0.0829
DEBUG - 2022-07-04 00:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:31 --> Total execution time: 0.0621
DEBUG - 2022-07-04 00:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:45 --> Total execution time: 1.5813
DEBUG - 2022-07-04 00:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:14:46 --> Total execution time: 0.1192
DEBUG - 2022-07-04 00:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:50 --> Total execution time: 0.1346
DEBUG - 2022-07-04 00:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:14:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 00:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:01 --> Total execution time: 0.0424
DEBUG - 2022-07-04 00:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:07 --> Total execution time: 0.1202
DEBUG - 2022-07-04 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:19 --> Total execution time: 0.1023
DEBUG - 2022-07-04 00:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:27 --> Total execution time: 0.1116
DEBUG - 2022-07-04 00:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 00:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:50 --> Total execution time: 0.1145
DEBUG - 2022-07-04 00:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:46:05 --> Total execution time: 3.6350
DEBUG - 2022-07-04 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:16:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 00:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:46:23 --> Total execution time: 0.0560
DEBUG - 2022-07-04 00:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:46:27 --> Total execution time: 0.0710
DEBUG - 2022-07-04 10:46:28 --> Total execution time: 1.5339
DEBUG - 2022-07-04 00:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:46:38 --> Total execution time: 1.5912
DEBUG - 2022-07-04 00:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:16:48 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-04 00:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:16:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 00:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:01 --> Total execution time: 0.0802
DEBUG - 2022-07-04 00:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:14 --> Total execution time: 0.0538
DEBUG - 2022-07-04 00:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:26 --> Total execution time: 0.0540
DEBUG - 2022-07-04 00:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:34 --> Total execution time: 0.0571
DEBUG - 2022-07-04 00:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:52 --> Total execution time: 0.0729
DEBUG - 2022-07-04 00:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:48:00 --> Total execution time: 0.0551
DEBUG - 2022-07-04 00:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:48:17 --> Total execution time: 1.5183
DEBUG - 2022-07-04 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:48:18 --> Total execution time: 0.0563
DEBUG - 2022-07-04 00:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:48:52 --> Total execution time: 0.0525
DEBUG - 2022-07-04 00:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:49:25 --> Total execution time: 0.1249
DEBUG - 2022-07-04 00:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:49:28 --> Total execution time: 0.0584
DEBUG - 2022-07-04 00:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:49:35 --> Total execution time: 0.0721
DEBUG - 2022-07-04 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:49:45 --> Total execution time: 0.0591
DEBUG - 2022-07-04 00:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:50:10 --> Total execution time: 1.6533
DEBUG - 2022-07-04 00:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:20:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 00:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:50:12 --> Total execution time: 0.0523
DEBUG - 2022-07-04 00:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:50:25 --> Total execution time: 0.0583
DEBUG - 2022-07-04 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:50:38 --> Total execution time: 0.0670
DEBUG - 2022-07-04 00:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:50:51 --> Total execution time: 0.0606
DEBUG - 2022-07-04 00:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:50:55 --> Total execution time: 0.0771
DEBUG - 2022-07-04 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:21:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:51:33 --> Total execution time: 0.0378
DEBUG - 2022-07-04 00:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:52:22 --> Total execution time: 0.0404
DEBUG - 2022-07-04 00:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:52:39 --> Total execution time: 0.1370
DEBUG - 2022-07-04 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:52:42 --> Total execution time: 0.0564
DEBUG - 2022-07-04 00:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:52:52 --> Total execution time: 0.0326
DEBUG - 2022-07-04 00:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:52:54 --> Total execution time: 0.0599
DEBUG - 2022-07-04 00:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:53:03 --> Total execution time: 0.0346
DEBUG - 2022-07-04 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:54:51 --> Total execution time: 0.0465
DEBUG - 2022-07-04 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:54:59 --> Total execution time: 0.0766
DEBUG - 2022-07-04 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:55:09 --> Total execution time: 0.0552
DEBUG - 2022-07-04 00:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:55:16 --> Total execution time: 0.0513
DEBUG - 2022-07-04 00:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:55:27 --> Total execution time: 0.0686
DEBUG - 2022-07-04 00:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:55:52 --> Total execution time: 0.0552
DEBUG - 2022-07-04 00:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:56:13 --> Total execution time: 0.0577
DEBUG - 2022-07-04 00:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:59:17 --> Total execution time: 0.1342
DEBUG - 2022-07-04 00:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:59:31 --> Total execution time: 0.0618
DEBUG - 2022-07-04 00:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:59:36 --> Total execution time: 0.0695
DEBUG - 2022-07-04 00:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:00:15 --> Total execution time: 0.1376
DEBUG - 2022-07-04 00:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:00:17 --> Total execution time: 0.0595
DEBUG - 2022-07-04 00:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:00:24 --> Total execution time: 0.1602
DEBUG - 2022-07-04 00:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:30:46 --> Total execution time: 0.0862
DEBUG - 2022-07-04 00:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:30:54 --> Total execution time: 0.0659
DEBUG - 2022-07-04 00:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:02:42 --> Total execution time: 0.0791
DEBUG - 2022-07-04 00:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:03:00 --> Total execution time: 0.0742
DEBUG - 2022-07-04 00:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:03:29 --> Total execution time: 0.0587
DEBUG - 2022-07-04 00:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:34:38 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 00:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:37:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:37:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 00:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:08:53 --> Total execution time: 0.2277
DEBUG - 2022-07-04 00:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:39:22 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:12:17 --> Total execution time: 0.0563
DEBUG - 2022-07-04 00:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:45:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:15:00 --> Total execution time: 0.1315
DEBUG - 2022-07-04 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:45:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:15:33 --> Total execution time: 0.0358
DEBUG - 2022-07-04 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:16:48 --> Total execution time: 0.1373
DEBUG - 2022-07-04 00:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:01 --> Total execution time: 0.0769
DEBUG - 2022-07-04 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:21 --> Total execution time: 0.1563
DEBUG - 2022-07-04 00:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:29 --> Total execution time: 0.0766
DEBUG - 2022-07-04 00:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:46 --> Total execution time: 0.0596
DEBUG - 2022-07-04 00:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:46 --> Total execution time: 0.0618
DEBUG - 2022-07-04 00:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:50 --> Total execution time: 0.0610
DEBUG - 2022-07-04 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:17:59 --> Total execution time: 0.0487
DEBUG - 2022-07-04 00:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:18:20 --> Total execution time: 0.0595
DEBUG - 2022-07-04 00:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:18:33 --> Total execution time: 0.0595
DEBUG - 2022-07-04 00:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:18:56 --> Total execution time: 0.0499
DEBUG - 2022-07-04 00:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:19:01 --> Total execution time: 0.0513
DEBUG - 2022-07-04 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:19:04 --> Total execution time: 0.0860
DEBUG - 2022-07-04 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:19:12 --> Total execution time: 0.0515
DEBUG - 2022-07-04 00:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:19:15 --> Total execution time: 0.0570
DEBUG - 2022-07-04 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:19:18 --> Total execution time: 0.0822
DEBUG - 2022-07-04 00:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:49:22 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:19:22 --> Total execution time: 0.1566
DEBUG - 2022-07-04 00:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:22:00 --> Total execution time: 0.2094
DEBUG - 2022-07-04 00:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:15 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:22:15 --> Total execution time: 0.0435
DEBUG - 2022-07-04 00:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:22:20 --> Total execution time: 0.0654
DEBUG - 2022-07-04 00:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:22:28 --> Total execution time: 0.0504
DEBUG - 2022-07-04 00:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:22:34 --> Total execution time: 0.0468
DEBUG - 2022-07-04 00:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:23:45 --> Total execution time: 0.0506
DEBUG - 2022-07-04 00:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:24:08 --> Total execution time: 0.0570
DEBUG - 2022-07-04 00:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:24:15 --> Total execution time: 0.0563
DEBUG - 2022-07-04 00:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:24:24 --> Total execution time: 0.0536
DEBUG - 2022-07-04 00:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:24:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 00:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:24:25 --> Total execution time: 0.0493
DEBUG - 2022-07-04 00:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:54:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:24:55 --> Total execution time: 0.1183
DEBUG - 2022-07-04 00:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:55:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-04 00:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:25:13 --> Total execution time: 0.1267
DEBUG - 2022-07-04 00:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:55:14 --> Total execution time: 0.0513
DEBUG - 2022-07-04 00:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:55:15 --> Total execution time: 0.0521
DEBUG - 2022-07-04 00:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 00:55:15 --> Total execution time: 0.1061
DEBUG - 2022-07-04 00:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:25:23 --> Total execution time: 0.0758
DEBUG - 2022-07-04 00:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:25:56 --> Total execution time: 0.0531
DEBUG - 2022-07-04 00:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:25:57 --> Total execution time: 0.0623
DEBUG - 2022-07-04 00:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:56:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:26:01 --> Total execution time: 0.0594
DEBUG - 2022-07-04 00:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:56:55 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-04 00:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:56:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 00:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:56:58 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-04 00:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:57:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:27:25 --> Total execution time: 0.1185
DEBUG - 2022-07-04 00:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:57:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:27:25 --> Total execution time: 0.0650
DEBUG - 2022-07-04 00:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:27:36 --> Total execution time: 0.1144
DEBUG - 2022-07-04 00:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:57:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 00:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:27:42 --> Total execution time: 0.0489
DEBUG - 2022-07-04 00:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 00:58:28 --> 404 Page Not Found: Category/world
DEBUG - 2022-07-04 00:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 00:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 00:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:29:04 --> Total execution time: 0.0476
DEBUG - 2022-07-04 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:30:02 --> Total execution time: 0.1025
DEBUG - 2022-07-04 01:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:31:15 --> Total execution time: 0.0704
DEBUG - 2022-07-04 01:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:31:22 --> Total execution time: 0.0476
DEBUG - 2022-07-04 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:31:29 --> Total execution time: 0.0619
DEBUG - 2022-07-04 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:31:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:31:30 --> Total execution time: 0.0595
DEBUG - 2022-07-04 01:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:03:05 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 01:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:03:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:33:18 --> Total execution time: 0.1330
DEBUG - 2022-07-04 01:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:33:52 --> Total execution time: 0.0490
DEBUG - 2022-07-04 01:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:35:34 --> Total execution time: 0.0489
DEBUG - 2022-07-04 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:35:39 --> Total execution time: 0.0512
DEBUG - 2022-07-04 01:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:36:02 --> Total execution time: 0.0651
DEBUG - 2022-07-04 01:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:36:09 --> Total execution time: 0.0487
DEBUG - 2022-07-04 01:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:07:34 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 01:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:38:29 --> Total execution time: 0.1415
DEBUG - 2022-07-04 01:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:11:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:11:46 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 01:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:49:07 --> Total execution time: 0.2457
DEBUG - 2022-07-04 01:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:19:22 --> 404 Page Not Found: Category/news
DEBUG - 2022-07-04 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:49:37 --> Total execution time: 0.0569
DEBUG - 2022-07-04 01:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:19:57 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:49:57 --> Total execution time: 0.0726
DEBUG - 2022-07-04 01:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:50:05 --> Total execution time: 0.0556
DEBUG - 2022-07-04 01:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:50:09 --> Total execution time: 0.0529
DEBUG - 2022-07-04 01:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:50:16 --> Total execution time: 0.0799
DEBUG - 2022-07-04 01:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:50:27 --> Total execution time: 0.0594
DEBUG - 2022-07-04 01:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:50:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 01:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:50:28 --> Total execution time: 0.0477
DEBUG - 2022-07-04 01:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:22:41 --> 404 Page Not Found: News/feed
DEBUG - 2022-07-04 01:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:23:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:53:24 --> Total execution time: 0.1575
DEBUG - 2022-07-04 01:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:23:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:53:42 --> Total execution time: 0.0391
DEBUG - 2022-07-04 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:54:05 --> Total execution time: 0.0510
DEBUG - 2022-07-04 01:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:54:11 --> Total execution time: 0.0973
DEBUG - 2022-07-04 01:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:54:16 --> Total execution time: 0.1009
DEBUG - 2022-07-04 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:56:37 --> Total execution time: 0.1993
DEBUG - 2022-07-04 01:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:57:50 --> Total execution time: 0.0621
DEBUG - 2022-07-04 01:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:59:08 --> Total execution time: 0.0571
DEBUG - 2022-07-04 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:29:20 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-07-04 01:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:00:13 --> Total execution time: 0.0554
DEBUG - 2022-07-04 01:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:00:34 --> Total execution time: 0.0590
DEBUG - 2022-07-04 01:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:02:34 --> Total execution time: 0.0657
DEBUG - 2022-07-04 01:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:04:15 --> Total execution time: 0.0588
DEBUG - 2022-07-04 01:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:04:27 --> Total execution time: 0.0600
DEBUG - 2022-07-04 01:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:04:43 --> Total execution time: 0.2017
DEBUG - 2022-07-04 01:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:04:58 --> Total execution time: 0.0516
DEBUG - 2022-07-04 01:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:05:00 --> Total execution time: 0.0609
DEBUG - 2022-07-04 01:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:05:24 --> Total execution time: 0.0555
DEBUG - 2022-07-04 01:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:05:42 --> Total execution time: 0.0793
DEBUG - 2022-07-04 01:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:06:17 --> Total execution time: 0.0869
DEBUG - 2022-07-04 01:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:06:53 --> Total execution time: 0.1810
DEBUG - 2022-07-04 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:00 --> Total execution time: 0.0537
DEBUG - 2022-07-04 01:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:06 --> Total execution time: 0.0538
DEBUG - 2022-07-04 01:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:10 --> Total execution time: 0.0976
DEBUG - 2022-07-04 01:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:14 --> Total execution time: 0.0569
DEBUG - 2022-07-04 01:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:17 --> Total execution time: 0.1414
DEBUG - 2022-07-04 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:23 --> Total execution time: 0.0869
DEBUG - 2022-07-04 01:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:27 --> Total execution time: 0.0857
DEBUG - 2022-07-04 01:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:31 --> Total execution time: 0.1078
DEBUG - 2022-07-04 01:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:07:43 --> Total execution time: 0.1276
DEBUG - 2022-07-04 01:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 01:37:53 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-07-04 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:08:27 --> Total execution time: 0.0491
DEBUG - 2022-07-04 01:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:08:32 --> Total execution time: 0.0582
DEBUG - 2022-07-04 01:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:08:32 --> Total execution time: 0.0969
DEBUG - 2022-07-04 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:08:33 --> Total execution time: 0.0991
DEBUG - 2022-07-04 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:08:41 --> Total execution time: 0.0704
DEBUG - 2022-07-04 01:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:08:58 --> Total execution time: 0.1021
DEBUG - 2022-07-04 01:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:00 --> Total execution time: 0.0509
DEBUG - 2022-07-04 01:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:06 --> Total execution time: 0.0754
DEBUG - 2022-07-04 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:08 --> Total execution time: 0.0543
DEBUG - 2022-07-04 01:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:27 --> Total execution time: 0.0790
DEBUG - 2022-07-04 01:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:29 --> Total execution time: 0.0925
DEBUG - 2022-07-04 01:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:15:12 --> Total execution time: 0.1623
DEBUG - 2022-07-04 01:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:18:20 --> Total execution time: 0.1357
DEBUG - 2022-07-04 01:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:50:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:20:13 --> Total execution time: 0.0711
DEBUG - 2022-07-04 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:20:28 --> Total execution time: 0.0555
DEBUG - 2022-07-04 01:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:21:09 --> Total execution time: 0.1720
DEBUG - 2022-07-04 01:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:17 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:17 --> Total execution time: 0.1139
DEBUG - 2022-07-04 01:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:23 --> Total execution time: 0.0396
DEBUG - 2022-07-04 01:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:30 --> Total execution time: 0.0544
DEBUG - 2022-07-04 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:39 --> Total execution time: 0.0478
DEBUG - 2022-07-04 01:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:45 --> Total execution time: 0.0667
DEBUG - 2022-07-04 01:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:54 --> Total execution time: 0.0535
DEBUG - 2022-07-04 01:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 01:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:54 --> Total execution time: 0.0568
DEBUG - 2022-07-04 01:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:14 --> Total execution time: 0.0616
DEBUG - 2022-07-04 01:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:26 --> Total execution time: 0.0482
DEBUG - 2022-07-04 01:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:32 --> Total execution time: 0.0790
DEBUG - 2022-07-04 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:40 --> Total execution time: 0.0837
DEBUG - 2022-07-04 01:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 01:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:41 --> Total execution time: 0.0603
DEBUG - 2022-07-04 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 01:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:08 --> Total execution time: 0.0621
DEBUG - 2022-07-04 01:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:10 --> Total execution time: 0.0493
DEBUG - 2022-07-04 01:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:16 --> Total execution time: 0.0485
DEBUG - 2022-07-04 01:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:43 --> Total execution time: 0.0523
DEBUG - 2022-07-04 01:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:46 --> Total execution time: 0.0464
DEBUG - 2022-07-04 01:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:48 --> Total execution time: 0.0512
DEBUG - 2022-07-04 01:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:50 --> Total execution time: 0.0499
DEBUG - 2022-07-04 01:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:53 --> Total execution time: 0.0526
DEBUG - 2022-07-04 01:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:54 --> Total execution time: 0.0514
DEBUG - 2022-07-04 01:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:56 --> Total execution time: 0.0497
DEBUG - 2022-07-04 01:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:58 --> Total execution time: 0.0542
DEBUG - 2022-07-04 01:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 01:57:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 01:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 01:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:27:00 --> Total execution time: 0.0554
DEBUG - 2022-07-04 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:30:04 --> Total execution time: 0.2252
DEBUG - 2022-07-04 02:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:27 --> Total execution time: 0.0924
DEBUG - 2022-07-04 02:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:41 --> Total execution time: 0.0719
DEBUG - 2022-07-04 02:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:53 --> Total execution time: 0.0606
DEBUG - 2022-07-04 02:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:33:01 --> Total execution time: 0.0512
DEBUG - 2022-07-04 02:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:33:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 02:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:33:02 --> Total execution time: 0.0553
DEBUG - 2022-07-04 02:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:34:05 --> Total execution time: 0.0627
DEBUG - 2022-07-04 02:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:34:14 --> Total execution time: 0.0607
DEBUG - 2022-07-04 02:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:34:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 02:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:34:15 --> Total execution time: 0.0472
DEBUG - 2022-07-04 02:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:34:29 --> Total execution time: 0.0646
DEBUG - 2022-07-04 02:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:03 --> Total execution time: 0.0870
DEBUG - 2022-07-04 02:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:10 --> Total execution time: 0.1083
DEBUG - 2022-07-04 02:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:20 --> Total execution time: 0.1632
DEBUG - 2022-07-04 02:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:36 --> Total execution time: 0.0705
DEBUG - 2022-07-04 02:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:05:44 --> Total execution time: 0.0685
DEBUG - 2022-07-04 02:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:05:46 --> Total execution time: 0.0575
DEBUG - 2022-07-04 02:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:05:46 --> Total execution time: 0.1399
DEBUG - 2022-07-04 02:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:53 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:53 --> Total execution time: 0.0511
DEBUG - 2022-07-04 02:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:05:56 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:56 --> Total execution time: 0.0449
DEBUG - 2022-07-04 02:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:09:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:39:52 --> Total execution time: 0.2285
DEBUG - 2022-07-04 02:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:39:55 --> Total execution time: 0.0496
DEBUG - 2022-07-04 02:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:39:58 --> Total execution time: 0.0516
DEBUG - 2022-07-04 02:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:40:04 --> Total execution time: 0.0763
DEBUG - 2022-07-04 02:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:40:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 02:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:40:05 --> Total execution time: 0.0640
DEBUG - 2022-07-04 02:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:11:27 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:41:27 --> Total execution time: 0.0416
DEBUG - 2022-07-04 02:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:13:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:43:20 --> Total execution time: 0.0471
DEBUG - 2022-07-04 02:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:15:04 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:45:04 --> Total execution time: 0.1396
DEBUG - 2022-07-04 02:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:45:31 --> Total execution time: 0.2028
DEBUG - 2022-07-04 02:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:16:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 02:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:17:46 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-07-04 02:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:19:07 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:21:19 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 02:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:23:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:53:36 --> Total execution time: 0.2419
DEBUG - 2022-07-04 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:53:44 --> Total execution time: 0.0798
DEBUG - 2022-07-04 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:53:48 --> Total execution time: 0.0751
DEBUG - 2022-07-04 02:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:54:01 --> Total execution time: 0.0529
DEBUG - 2022-07-04 02:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:54:02 --> Total execution time: 0.0712
DEBUG - 2022-07-04 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:54:13 --> Total execution time: 0.0909
DEBUG - 2022-07-04 02:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:54:22 --> Total execution time: 0.0930
DEBUG - 2022-07-04 02:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:24:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:24:45 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-07-04 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:55:19 --> Total execution time: 0.0991
DEBUG - 2022-07-04 02:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:55:45 --> Total execution time: 0.1009
DEBUG - 2022-07-04 02:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:56:15 --> Total execution time: 0.1088
DEBUG - 2022-07-04 02:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:56:16 --> Total execution time: 0.0830
DEBUG - 2022-07-04 02:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:56:22 --> Total execution time: 0.0747
DEBUG - 2022-07-04 02:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:56:45 --> Total execution time: 0.0672
DEBUG - 2022-07-04 02:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:56:57 --> Total execution time: 0.0573
DEBUG - 2022-07-04 02:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:57:00 --> Total execution time: 0.0650
DEBUG - 2022-07-04 02:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:57:11 --> Total execution time: 0.0617
DEBUG - 2022-07-04 02:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:28:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:58:36 --> Total execution time: 0.0507
DEBUG - 2022-07-04 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:58:40 --> Total execution time: 0.0357
DEBUG - 2022-07-04 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:59:04 --> Total execution time: 0.0722
DEBUG - 2022-07-04 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:59:10 --> Total execution time: 0.0638
DEBUG - 2022-07-04 02:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:59:15 --> Total execution time: 0.0666
DEBUG - 2022-07-04 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:59:23 --> Total execution time: 0.0516
DEBUG - 2022-07-04 02:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:59:29 --> Total execution time: 0.0603
DEBUG - 2022-07-04 02:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:34:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 02:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:34:26 --> 404 Page Not Found: Category/technology
DEBUG - 2022-07-04 02:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:05:24 --> Total execution time: 0.1884
DEBUG - 2022-07-04 02:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:05:27 --> Total execution time: 0.0568
DEBUG - 2022-07-04 02:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:05:31 --> Total execution time: 0.0497
DEBUG - 2022-07-04 02:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:38:16 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:08:16 --> Total execution time: 0.1866
DEBUG - 2022-07-04 02:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:38:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:08:34 --> Total execution time: 0.0509
DEBUG - 2022-07-04 02:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:18 --> Total execution time: 0.0828
DEBUG - 2022-07-04 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:21 --> Total execution time: 0.0602
DEBUG - 2022-07-04 02:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:26 --> Total execution time: 0.0507
DEBUG - 2022-07-04 02:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:26 --> Total execution time: 0.0573
DEBUG - 2022-07-04 02:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 02:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:27 --> Total execution time: 0.0658
DEBUG - 2022-07-04 02:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:27 --> Total execution time: 0.0499
DEBUG - 2022-07-04 02:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:11:59 --> Total execution time: 0.1290
DEBUG - 2022-07-04 02:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:12:03 --> Total execution time: 0.0456
DEBUG - 2022-07-04 02:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:12:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 02:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:12:04 --> Total execution time: 0.0437
DEBUG - 2022-07-04 02:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:43:48 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:13:48 --> Total execution time: 0.0504
DEBUG - 2022-07-04 02:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:43:58 --> Total execution time: 0.0571
DEBUG - 2022-07-04 02:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:44:01 --> Total execution time: 0.0604
DEBUG - 2022-07-04 02:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:44:01 --> Total execution time: 0.1207
DEBUG - 2022-07-04 02:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:46:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 02:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:46:15 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 13:16:16 --> Total execution time: 1.8676
DEBUG - 2022-07-04 02:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 02:46:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 02:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:48:56 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:18:56 --> Total execution time: 0.1122
DEBUG - 2022-07-04 02:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:00 --> Total execution time: 0.0490
DEBUG - 2022-07-04 02:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:09 --> Total execution time: 0.0791
DEBUG - 2022-07-04 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:16 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:16 --> Total execution time: 0.0390
DEBUG - 2022-07-04 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:16 --> Total execution time: 0.0688
DEBUG - 2022-07-04 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:26 --> Total execution time: 0.0613
DEBUG - 2022-07-04 02:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:27 --> Total execution time: 0.0347
DEBUG - 2022-07-04 02:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:33 --> Total execution time: 0.0627
DEBUG - 2022-07-04 02:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:19:57 --> Total execution time: 0.0453
DEBUG - 2022-07-04 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:20:04 --> Total execution time: 0.0840
DEBUG - 2022-07-04 02:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:23:18 --> Total execution time: 0.1915
DEBUG - 2022-07-04 02:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:53:53 --> No URI present. Default controller set.
DEBUG - 2022-07-04 02:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:23:53 --> Total execution time: 0.0727
DEBUG - 2022-07-04 02:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:23:57 --> Total execution time: 0.0609
DEBUG - 2022-07-04 02:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:24:28 --> Total execution time: 0.0602
DEBUG - 2022-07-04 02:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:24:31 --> Total execution time: 0.0494
DEBUG - 2022-07-04 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:24:38 --> Total execution time: 0.0551
DEBUG - 2022-07-04 02:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:24:42 --> Total execution time: 0.0786
DEBUG - 2022-07-04 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:24:58 --> Total execution time: 0.0502
DEBUG - 2022-07-04 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:25:10 --> Total execution time: 0.1206
DEBUG - 2022-07-04 02:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:55:10 --> Total execution time: 0.0614
DEBUG - 2022-07-04 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:25:13 --> Total execution time: 0.0464
DEBUG - 2022-07-04 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:25:22 --> Total execution time: 0.0540
DEBUG - 2022-07-04 02:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:25:41 --> Total execution time: 0.0658
DEBUG - 2022-07-04 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:25:45 --> Total execution time: 0.0510
DEBUG - 2022-07-04 02:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:26:34 --> Total execution time: 0.0582
DEBUG - 2022-07-04 02:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:27:04 --> Total execution time: 0.0517
DEBUG - 2022-07-04 02:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:27:19 --> Total execution time: 0.0507
DEBUG - 2022-07-04 02:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:27:22 --> Total execution time: 0.0484
DEBUG - 2022-07-04 02:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:27:22 --> Total execution time: 0.0550
DEBUG - 2022-07-04 02:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:27:23 --> Total execution time: 0.0567
DEBUG - 2022-07-04 02:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:27:23 --> Total execution time: 0.0971
DEBUG - 2022-07-04 02:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:28:26 --> Total execution time: 0.0724
DEBUG - 2022-07-04 02:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:29:24 --> Total execution time: 0.0701
DEBUG - 2022-07-04 02:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:29:53 --> Total execution time: 0.0916
DEBUG - 2022-07-04 02:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 02:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 02:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:29:54 --> Total execution time: 0.0794
DEBUG - 2022-07-04 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:03 --> Total execution time: 0.0783
DEBUG - 2022-07-04 03:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:22 --> Total execution time: 0.1809
DEBUG - 2022-07-04 03:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:34 --> Total execution time: 0.0625
DEBUG - 2022-07-04 03:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:35 --> Total execution time: 0.0617
DEBUG - 2022-07-04 03:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:35 --> Total execution time: 0.0442
DEBUG - 2022-07-04 03:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:00:40 --> Total execution time: 0.0669
DEBUG - 2022-07-04 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:00:42 --> Total execution time: 0.0556
DEBUG - 2022-07-04 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:00:42 --> Total execution time: 0.0923
DEBUG - 2022-07-04 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:42 --> Total execution time: 0.0605
DEBUG - 2022-07-04 03:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:46 --> Total execution time: 0.0504
DEBUG - 2022-07-04 03:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 13:30:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 13:30:47 --> Total execution time: 0.2442
DEBUG - 2022-07-04 03:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:49 --> Total execution time: 0.0607
DEBUG - 2022-07-04 03:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:30:51 --> Total execution time: 0.0563
DEBUG - 2022-07-04 03:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:07 --> Total execution time: 0.0586
DEBUG - 2022-07-04 03:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:16 --> Total execution time: 0.0853
DEBUG - 2022-07-04 03:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:24 --> Total execution time: 0.1569
DEBUG - 2022-07-04 03:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:26 --> Total execution time: 0.0859
DEBUG - 2022-07-04 03:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:27 --> Total execution time: 0.1341
DEBUG - 2022-07-04 03:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:29 --> Total execution time: 0.0761
DEBUG - 2022-07-04 03:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:32 --> Total execution time: 0.0633
DEBUG - 2022-07-04 03:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:36 --> Total execution time: 0.0711
DEBUG - 2022-07-04 03:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:36 --> Total execution time: 0.0787
DEBUG - 2022-07-04 03:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:37 --> Total execution time: 0.0682
DEBUG - 2022-07-04 03:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:45 --> Total execution time: 0.0599
DEBUG - 2022-07-04 03:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:31:58 --> Total execution time: 0.0575
DEBUG - 2022-07-04 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:32:01 --> Total execution time: 0.0497
DEBUG - 2022-07-04 03:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:32:09 --> Total execution time: 0.0706
DEBUG - 2022-07-04 03:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:02:20 --> Total execution time: 0.0631
DEBUG - 2022-07-04 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:02:24 --> Total execution time: 0.1113
DEBUG - 2022-07-04 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:32:25 --> Total execution time: 0.0729
DEBUG - 2022-07-04 03:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 03:02:57 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-07-04 03:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:02:57 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:32:57 --> Total execution time: 0.0360
DEBUG - 2022-07-04 03:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:33:07 --> Total execution time: 0.0498
DEBUG - 2022-07-04 03:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:33:16 --> Total execution time: 0.0503
DEBUG - 2022-07-04 03:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:33:53 --> Total execution time: 0.0776
DEBUG - 2022-07-04 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:33:57 --> Total execution time: 0.0792
DEBUG - 2022-07-04 03:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:34:06 --> Total execution time: 0.0833
DEBUG - 2022-07-04 03:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:34:13 --> Total execution time: 0.0700
DEBUG - 2022-07-04 03:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:34:16 --> Total execution time: 0.0532
DEBUG - 2022-07-04 03:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:34:18 --> Total execution time: 0.0540
DEBUG - 2022-07-04 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:35:42 --> Total execution time: 0.0369
DEBUG - 2022-07-04 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:36:37 --> Total execution time: 0.0522
DEBUG - 2022-07-04 03:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:36:53 --> Total execution time: 0.0508
DEBUG - 2022-07-04 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:00 --> Total execution time: 0.2851
DEBUG - 2022-07-04 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:04 --> Total execution time: 0.1333
DEBUG - 2022-07-04 03:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:12 --> Total execution time: 0.1183
DEBUG - 2022-07-04 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:23 --> Total execution time: 0.0516
DEBUG - 2022-07-04 03:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:40 --> Total execution time: 0.0416
DEBUG - 2022-07-04 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:44 --> Total execution time: 0.0482
DEBUG - 2022-07-04 03:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:47 --> Total execution time: 0.0461
DEBUG - 2022-07-04 03:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:49 --> Total execution time: 0.0502
DEBUG - 2022-07-04 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:55 --> Total execution time: 0.0540
DEBUG - 2022-07-04 03:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:44:55 --> Total execution time: 0.0612
DEBUG - 2022-07-04 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:45:18 --> Total execution time: 0.0749
DEBUG - 2022-07-04 03:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:45:20 --> Total execution time: 0.0472
DEBUG - 2022-07-04 03:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:15:22 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:45:22 --> Total execution time: 0.0525
DEBUG - 2022-07-04 03:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:16:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:46:14 --> Total execution time: 0.0546
DEBUG - 2022-07-04 03:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:46:17 --> Total execution time: 0.0597
DEBUG - 2022-07-04 03:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:46:31 --> Total execution time: 0.0948
DEBUG - 2022-07-04 03:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:46:38 --> Total execution time: 0.0937
DEBUG - 2022-07-04 03:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:46:45 --> Total execution time: 0.0686
DEBUG - 2022-07-04 03:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:48:25 --> Total execution time: 0.0694
DEBUG - 2022-07-04 03:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:48:33 --> Total execution time: 0.0563
DEBUG - 2022-07-04 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:18:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:48:42 --> Total execution time: 0.0349
DEBUG - 2022-07-04 03:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:48:51 --> Total execution time: 0.0359
DEBUG - 2022-07-04 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:48:58 --> Total execution time: 0.0424
DEBUG - 2022-07-04 03:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:49:30 --> Total execution time: 0.0578
DEBUG - 2022-07-04 03:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:49:32 --> Total execution time: 0.0579
DEBUG - 2022-07-04 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:49:38 --> Total execution time: 0.0514
DEBUG - 2022-07-04 03:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:51:38 --> Total execution time: 0.1284
DEBUG - 2022-07-04 03:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:51:42 --> Total execution time: 0.0751
DEBUG - 2022-07-04 03:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:51:51 --> Total execution time: 0.0623
DEBUG - 2022-07-04 03:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:51:57 --> Total execution time: 0.1265
DEBUG - 2022-07-04 03:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:00 --> Total execution time: 0.0488
DEBUG - 2022-07-04 03:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:16 --> Total execution time: 0.0600
DEBUG - 2022-07-04 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:20 --> Total execution time: 0.0378
DEBUG - 2022-07-04 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:20 --> Total execution time: 0.0572
DEBUG - 2022-07-04 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:20 --> Total execution time: 0.0771
DEBUG - 2022-07-04 03:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:22:25 --> Total execution time: 0.0525
DEBUG - 2022-07-04 03:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:25 --> Total execution time: 0.0701
DEBUG - 2022-07-04 03:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:27 --> Total execution time: 0.0466
DEBUG - 2022-07-04 03:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:28 --> Total execution time: 0.0620
DEBUG - 2022-07-04 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:31 --> Total execution time: 0.0744
DEBUG - 2022-07-04 03:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:36 --> Total execution time: 0.0554
DEBUG - 2022-07-04 03:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:40 --> Total execution time: 0.0594
DEBUG - 2022-07-04 03:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:42 --> Total execution time: 0.0602
DEBUG - 2022-07-04 03:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:53 --> Total execution time: 0.0512
DEBUG - 2022-07-04 03:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:58 --> Total execution time: 0.0557
DEBUG - 2022-07-04 03:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:52:59 --> Total execution time: 0.0497
DEBUG - 2022-07-04 03:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:02 --> Total execution time: 0.2076
DEBUG - 2022-07-04 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:07 --> Total execution time: 0.0464
DEBUG - 2022-07-04 03:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:25 --> Total execution time: 0.0357
DEBUG - 2022-07-04 03:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:31 --> Total execution time: 0.0327
DEBUG - 2022-07-04 03:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:34 --> Total execution time: 0.0366
DEBUG - 2022-07-04 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:42 --> Total execution time: 0.0329
DEBUG - 2022-07-04 03:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:55:51 --> Total execution time: 0.0457
DEBUG - 2022-07-04 03:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:01 --> Total execution time: 0.0615
DEBUG - 2022-07-04 03:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:04 --> Total execution time: 0.0669
DEBUG - 2022-07-04 03:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:07 --> Total execution time: 0.0559
DEBUG - 2022-07-04 03:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:16 --> Total execution time: 0.0507
DEBUG - 2022-07-04 03:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:34 --> Total execution time: 0.0486
DEBUG - 2022-07-04 03:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:46 --> Total execution time: 0.0508
DEBUG - 2022-07-04 03:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:50 --> Total execution time: 0.0449
DEBUG - 2022-07-04 03:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:57:28 --> Total execution time: 0.0540
DEBUG - 2022-07-04 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:57:36 --> Total execution time: 0.0645
DEBUG - 2022-07-04 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:58:10 --> Total execution time: 0.0529
DEBUG - 2022-07-04 03:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:19 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:58:19 --> Total execution time: 0.0743
DEBUG - 2022-07-04 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:21 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:58:21 --> Total execution time: 0.0374
DEBUG - 2022-07-04 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 03:28:31 --> 404 Page Not Found: Category/features
DEBUG - 2022-07-04 03:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:58:47 --> Total execution time: 0.0369
DEBUG - 2022-07-04 03:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:58:47 --> Total execution time: 0.0345
DEBUG - 2022-07-04 03:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 03:28:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 03:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:00:16 --> Total execution time: 0.1196
DEBUG - 2022-07-04 03:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:00:31 --> Total execution time: 0.0539
DEBUG - 2022-07-04 03:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:02:27 --> Total execution time: 0.2698
DEBUG - 2022-07-04 03:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:02:40 --> Total execution time: 0.0591
DEBUG - 2022-07-04 03:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:02:43 --> Total execution time: 0.0567
DEBUG - 2022-07-04 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:02:53 --> Total execution time: 0.0516
DEBUG - 2022-07-04 03:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:11 --> Total execution time: 0.0525
DEBUG - 2022-07-04 03:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:33 --> Total execution time: 0.0493
DEBUG - 2022-07-04 03:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:36 --> Total execution time: 0.1246
DEBUG - 2022-07-04 03:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:39 --> Total execution time: 0.0482
DEBUG - 2022-07-04 03:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:50 --> Total execution time: 0.0489
DEBUG - 2022-07-04 03:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:55 --> Total execution time: 0.0741
DEBUG - 2022-07-04 03:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:56 --> Total execution time: 0.0517
DEBUG - 2022-07-04 03:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:57 --> Total execution time: 0.0529
DEBUG - 2022-07-04 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:03:58 --> Total execution time: 0.0496
DEBUG - 2022-07-04 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:05:21 --> Total execution time: 0.0503
DEBUG - 2022-07-04 03:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:05:28 --> Total execution time: 0.0579
DEBUG - 2022-07-04 03:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:05:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:05:29 --> Total execution time: 0.0496
DEBUG - 2022-07-04 03:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:06:03 --> Total execution time: 0.0485
DEBUG - 2022-07-04 03:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:06:13 --> Total execution time: 0.0659
DEBUG - 2022-07-04 03:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:09:09 --> Total execution time: 0.2264
DEBUG - 2022-07-04 03:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:04 --> Total execution time: 0.1791
DEBUG - 2022-07-04 03:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:06 --> Total execution time: 0.0619
DEBUG - 2022-07-04 03:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:11 --> Total execution time: 0.0517
DEBUG - 2022-07-04 03:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:14 --> Total execution time: 0.0858
DEBUG - 2022-07-04 03:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:15 --> Total execution time: 0.0817
DEBUG - 2022-07-04 03:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:28 --> Total execution time: 0.1124
DEBUG - 2022-07-04 03:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:45 --> Total execution time: 0.0552
DEBUG - 2022-07-04 03:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:51 --> Total execution time: 0.0563
DEBUG - 2022-07-04 03:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:52 --> Total execution time: 0.0498
DEBUG - 2022-07-04 03:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:55 --> Total execution time: 0.0519
DEBUG - 2022-07-04 03:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:58 --> Total execution time: 0.0521
DEBUG - 2022-07-04 03:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:01 --> Total execution time: 0.0519
DEBUG - 2022-07-04 03:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 14:11:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 14:11:02 --> Total execution time: 0.2289
DEBUG - 2022-07-04 03:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:30 --> Total execution time: 0.1545
DEBUG - 2022-07-04 03:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:29 --> Total execution time: 0.0653
DEBUG - 2022-07-04 03:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:42:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:34 --> Total execution time: 0.0681
DEBUG - 2022-07-04 03:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:39 --> Total execution time: 0.0831
DEBUG - 2022-07-04 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:43 --> Total execution time: 0.0389
DEBUG - 2022-07-04 03:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:42:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:49 --> Total execution time: 0.0352
DEBUG - 2022-07-04 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:13:17 --> Total execution time: 0.0598
DEBUG - 2022-07-04 03:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:13:42 --> Total execution time: 0.0533
DEBUG - 2022-07-04 03:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:13:54 --> Total execution time: 0.0612
DEBUG - 2022-07-04 03:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:14:13 --> Total execution time: 0.0530
DEBUG - 2022-07-04 03:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:14:15 --> Total execution time: 0.0521
DEBUG - 2022-07-04 03:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:14:15 --> Total execution time: 0.0748
DEBUG - 2022-07-04 03:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:14:25 --> Total execution time: 0.0478
DEBUG - 2022-07-04 03:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:28 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:14:28 --> Total execution time: 0.0395
DEBUG - 2022-07-04 03:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:14:31 --> Total execution time: 0.0333
DEBUG - 2022-07-04 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:04 --> Total execution time: 0.0527
DEBUG - 2022-07-04 03:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:12 --> Total execution time: 0.0566
DEBUG - 2022-07-04 03:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:14 --> Total execution time: 0.1017
DEBUG - 2022-07-04 03:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:22 --> Total execution time: 0.0526
DEBUG - 2022-07-04 03:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:41 --> Total execution time: 0.0572
DEBUG - 2022-07-04 03:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:44 --> Total execution time: 0.0527
DEBUG - 2022-07-04 03:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:15:52 --> Total execution time: 0.1082
DEBUG - 2022-07-04 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:46:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:16:44 --> Total execution time: 0.1199
DEBUG - 2022-07-04 03:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:22:00 --> Total execution time: 0.1935
DEBUG - 2022-07-04 03:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:27:27 --> Total execution time: 0.0524
DEBUG - 2022-07-04 03:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:27:47 --> Total execution time: 0.0504
DEBUG - 2022-07-04 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:27:48 --> Total execution time: 0.0816
DEBUG - 2022-07-04 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:27:53 --> Total execution time: 0.0902
DEBUG - 2022-07-04 03:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:27:57 --> Total execution time: 0.0808
DEBUG - 2022-07-04 03:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:58:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 03:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:28:06 --> Total execution time: 0.0435
DEBUG - 2022-07-04 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:29:26 --> Total execution time: 0.1263
DEBUG - 2022-07-04 03:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:29:28 --> Total execution time: 0.0504
DEBUG - 2022-07-04 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:29:29 --> Total execution time: 0.0657
DEBUG - 2022-07-04 03:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 03:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:29:53 --> Total execution time: 0.0535
DEBUG - 2022-07-04 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:30:02 --> Total execution time: 0.0675
DEBUG - 2022-07-04 04:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:30:20 --> Total execution time: 0.0561
DEBUG - 2022-07-04 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:30:30 --> Total execution time: 0.0730
DEBUG - 2022-07-04 04:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:01:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 04:01:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 04:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:03:09 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:33:09 --> Total execution time: 0.0400
DEBUG - 2022-07-04 04:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:33:13 --> Total execution time: 0.0328
DEBUG - 2022-07-04 04:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:33:27 --> Total execution time: 0.0585
DEBUG - 2022-07-04 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:33:30 --> Total execution time: 0.0725
DEBUG - 2022-07-04 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:33:33 --> Total execution time: 0.3984
DEBUG - 2022-07-04 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 04:04:19 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 04:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:05:51 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:35:51 --> Total execution time: 0.0527
DEBUG - 2022-07-04 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:36:05 --> Total execution time: 0.0570
DEBUG - 2022-07-04 04:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:06:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 04:06:37 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 04:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:10:51 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:40:51 --> Total execution time: 0.1962
DEBUG - 2022-07-04 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:40:55 --> Total execution time: 0.0686
DEBUG - 2022-07-04 04:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:40:59 --> Total execution time: 0.0634
DEBUG - 2022-07-04 04:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:41:03 --> Total execution time: 0.0600
DEBUG - 2022-07-04 04:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:41:14 --> Total execution time: 0.0497
DEBUG - 2022-07-04 04:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:11 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:11 --> Total execution time: 0.0344
DEBUG - 2022-07-04 04:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:13 --> Total execution time: 0.0284
DEBUG - 2022-07-04 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:16 --> Total execution time: 0.0454
DEBUG - 2022-07-04 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:24 --> Total execution time: 0.0450
DEBUG - 2022-07-04 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:12:30 --> Total execution time: 0.0533
DEBUG - 2022-07-04 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:12:33 --> Total execution time: 0.0630
DEBUG - 2022-07-04 04:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:12:33 --> Total execution time: 0.1032
DEBUG - 2022-07-04 04:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:36 --> Total execution time: 0.0725
DEBUG - 2022-07-04 04:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:42 --> Total execution time: 0.0785
DEBUG - 2022-07-04 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:13:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 04:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:43:34 --> Total execution time: 1.5775
DEBUG - 2022-07-04 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:13:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 04:13:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 04:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:06 --> Total execution time: 0.1333
DEBUG - 2022-07-04 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:24 --> Total execution time: 0.0588
DEBUG - 2022-07-04 04:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:34 --> Total execution time: 0.0554
DEBUG - 2022-07-04 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:44 --> Total execution time: 0.0566
DEBUG - 2022-07-04 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:54 --> Total execution time: 0.0548
DEBUG - 2022-07-04 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:45:27 --> Total execution time: 0.0705
DEBUG - 2022-07-04 04:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:45:43 --> Total execution time: 0.0528
DEBUG - 2022-07-04 04:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:45:57 --> Total execution time: 0.0543
DEBUG - 2022-07-04 04:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:46:57 --> Total execution time: 0.0604
DEBUG - 2022-07-04 04:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:17:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:47:25 --> Total execution time: 0.0485
DEBUG - 2022-07-04 04:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:27:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:57:55 --> Total execution time: 0.1183
DEBUG - 2022-07-04 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:58:07 --> Total execution time: 0.0610
DEBUG - 2022-07-04 04:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:58:45 --> Total execution time: 0.0816
DEBUG - 2022-07-04 04:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:28:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:58:59 --> Total execution time: 0.0472
DEBUG - 2022-07-04 04:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:59:00 --> Total execution time: 0.0867
DEBUG - 2022-07-04 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:59:17 --> Total execution time: 0.0612
DEBUG - 2022-07-04 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:59:22 --> Total execution time: 0.0594
DEBUG - 2022-07-04 04:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:31:11 --> Total execution time: 0.0638
DEBUG - 2022-07-04 04:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:31:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 04:31:32 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 04:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:31:45 --> Total execution time: 0.1188
DEBUG - 2022-07-04 04:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:31:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:01:47 --> Total execution time: 0.1404
DEBUG - 2022-07-04 04:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:01:55 --> Total execution time: 0.0518
DEBUG - 2022-07-04 04:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:02:00 --> Total execution time: 0.0616
DEBUG - 2022-07-04 04:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:02:06 --> Total execution time: 0.1173
DEBUG - 2022-07-04 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:29 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:02:29 --> Total execution time: 0.0405
DEBUG - 2022-07-04 04:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:32:30 --> Total execution time: 0.0584
DEBUG - 2022-07-04 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:32:32 --> Total execution time: 0.0586
DEBUG - 2022-07-04 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:32:32 --> Total execution time: 0.0685
DEBUG - 2022-07-04 04:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:02:38 --> Total execution time: 0.0850
DEBUG - 2022-07-04 04:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:02:45 --> Total execution time: 0.0928
DEBUG - 2022-07-04 04:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:02:55 --> Total execution time: 0.0853
DEBUG - 2022-07-04 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:02 --> Total execution time: 0.0740
DEBUG - 2022-07-04 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:02 --> Total execution time: 0.0908
DEBUG - 2022-07-04 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:05 --> Total execution time: 0.0777
DEBUG - 2022-07-04 04:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:09 --> Total execution time: 0.0636
DEBUG - 2022-07-04 04:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:09 --> Total execution time: 0.0591
DEBUG - 2022-07-04 04:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:15 --> Total execution time: 0.0527
DEBUG - 2022-07-04 04:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:19 --> Total execution time: 0.0669
DEBUG - 2022-07-04 04:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:24 --> Total execution time: 0.0731
DEBUG - 2022-07-04 04:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:03:27 --> Total execution time: 0.0645
DEBUG - 2022-07-04 04:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:34:00 --> Total execution time: 0.0431
DEBUG - 2022-07-04 04:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:34:01 --> Total execution time: 0.0608
DEBUG - 2022-07-04 04:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:34:01 --> Total execution time: 0.0933
DEBUG - 2022-07-04 04:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:34:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:04:24 --> Total execution time: 0.0632
DEBUG - 2022-07-04 04:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:04:37 --> Total execution time: 0.0573
DEBUG - 2022-07-04 04:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:05:03 --> Total execution time: 0.0652
DEBUG - 2022-07-04 04:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:05:15 --> Total execution time: 0.0587
DEBUG - 2022-07-04 04:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:05:26 --> Total execution time: 0.0478
DEBUG - 2022-07-04 04:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:35:37 --> Total execution time: 0.0617
DEBUG - 2022-07-04 04:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:35:39 --> Total execution time: 0.0690
DEBUG - 2022-07-04 04:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:35:39 --> Total execution time: 0.1195
DEBUG - 2022-07-04 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:35:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:05:50 --> Total execution time: 0.0517
DEBUG - 2022-07-04 04:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:06:04 --> Total execution time: 0.0839
DEBUG - 2022-07-04 04:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:36:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:06:13 --> Total execution time: 0.0519
DEBUG - 2022-07-04 04:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:06:22 --> Total execution time: 0.0539
DEBUG - 2022-07-04 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:36:25 --> Total execution time: 0.0492
DEBUG - 2022-07-04 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:06:34 --> Total execution time: 0.0759
DEBUG - 2022-07-04 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:00 --> Total execution time: 0.0562
DEBUG - 2022-07-04 04:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:37:00 --> Total execution time: 0.0755
DEBUG - 2022-07-04 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:04 --> Total execution time: 0.0640
DEBUG - 2022-07-04 04:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:06 --> Total execution time: 0.1229
DEBUG - 2022-07-04 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:09 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:09 --> Total execution time: 0.0495
DEBUG - 2022-07-04 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:10 --> Total execution time: 0.0775
DEBUG - 2022-07-04 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:14 --> Total execution time: 0.0562
DEBUG - 2022-07-04 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:37:15 --> Total execution time: 0.0604
DEBUG - 2022-07-04 04:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:19 --> Total execution time: 0.0861
DEBUG - 2022-07-04 04:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:29 --> Total execution time: 0.1002
DEBUG - 2022-07-04 04:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:35 --> Total execution time: 0.1205
DEBUG - 2022-07-04 04:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:43 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:43 --> Total execution time: 0.0543
DEBUG - 2022-07-04 04:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:46 --> Total execution time: 0.0600
DEBUG - 2022-07-04 04:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:07:58 --> Total execution time: 0.1375
DEBUG - 2022-07-04 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:01 --> Total execution time: 0.0924
DEBUG - 2022-07-04 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:07 --> Total execution time: 0.0346
DEBUG - 2022-07-04 04:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:09 --> Total execution time: 0.0599
DEBUG - 2022-07-04 04:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:14 --> Total execution time: 0.0523
DEBUG - 2022-07-04 04:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:16 --> Total execution time: 0.0369
DEBUG - 2022-07-04 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:24 --> Total execution time: 0.0636
DEBUG - 2022-07-04 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:25 --> Total execution time: 0.0480
DEBUG - 2022-07-04 04:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:34 --> Total execution time: 0.0588
DEBUG - 2022-07-04 04:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:34 --> Total execution time: 0.0519
DEBUG - 2022-07-04 04:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:35 --> Total execution time: 0.0439
DEBUG - 2022-07-04 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:36 --> Total execution time: 0.0504
DEBUG - 2022-07-04 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:38:36 --> Total execution time: 0.0466
DEBUG - 2022-07-04 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:36 --> Total execution time: 0.0467
DEBUG - 2022-07-04 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:36 --> Total execution time: 0.0563
DEBUG - 2022-07-04 04:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:37 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:37 --> Total execution time: 0.0459
DEBUG - 2022-07-04 04:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:38 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:38 --> Total execution time: 0.0535
DEBUG - 2022-07-04 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:38:39 --> Total execution time: 0.0594
DEBUG - 2022-07-04 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:39 --> Total execution time: 0.0560
DEBUG - 2022-07-04 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:40 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:40 --> Total execution time: 0.0498
DEBUG - 2022-07-04 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:38:41 --> Total execution time: 0.0570
DEBUG - 2022-07-04 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:41 --> Total execution time: 0.0543
DEBUG - 2022-07-04 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:42 --> Total execution time: 0.0763
DEBUG - 2022-07-04 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:43 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:43 --> Total execution time: 0.0655
DEBUG - 2022-07-04 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:47 --> Total execution time: 0.0573
DEBUG - 2022-07-04 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:50 --> Total execution time: 0.0529
DEBUG - 2022-07-04 04:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:08:56 --> Total execution time: 0.0768
DEBUG - 2022-07-04 04:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:09:01 --> Total execution time: 0.0711
DEBUG - 2022-07-04 04:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:09:18 --> Total execution time: 0.0675
DEBUG - 2022-07-04 04:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:09:21 --> Total execution time: 0.0545
DEBUG - 2022-07-04 04:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:09:52 --> Total execution time: 0.0351
DEBUG - 2022-07-04 04:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:09:56 --> Total execution time: 0.0678
DEBUG - 2022-07-04 04:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:39:59 --> Total execution time: 0.0601
DEBUG - 2022-07-04 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:40:00 --> Total execution time: 0.0567
DEBUG - 2022-07-04 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:40:00 --> Total execution time: 0.1157
DEBUG - 2022-07-04 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:07 --> Total execution time: 0.0529
DEBUG - 2022-07-04 04:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:08 --> Total execution time: 0.0560
DEBUG - 2022-07-04 04:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:10 --> Total execution time: 0.0540
DEBUG - 2022-07-04 04:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:24 --> Total execution time: 0.0808
DEBUG - 2022-07-04 04:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:35 --> Total execution time: 0.0549
DEBUG - 2022-07-04 04:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:36 --> Total execution time: 0.0524
DEBUG - 2022-07-04 04:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:44 --> Total execution time: 0.0564
DEBUG - 2022-07-04 04:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 04:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:50 --> Total execution time: 0.0771
DEBUG - 2022-07-04 04:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:10:53 --> Total execution time: 0.0786
DEBUG - 2022-07-04 04:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:15 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:15 --> Total execution time: 0.0348
DEBUG - 2022-07-04 04:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:28 --> Total execution time: 0.0652
DEBUG - 2022-07-04 04:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:34 --> Total execution time: 0.0565
DEBUG - 2022-07-04 04:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:38 --> Total execution time: 0.0752
DEBUG - 2022-07-04 04:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:41 --> Total execution time: 0.0822
DEBUG - 2022-07-04 04:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:50 --> Total execution time: 0.0552
DEBUG - 2022-07-04 04:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:54 --> Total execution time: 0.1292
DEBUG - 2022-07-04 04:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:11:57 --> Total execution time: 0.0564
DEBUG - 2022-07-04 04:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:12:06 --> Total execution time: 0.0514
DEBUG - 2022-07-04 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:12:49 --> Total execution time: 0.1373
DEBUG - 2022-07-04 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:42:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 04:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:12:49 --> Total execution time: 0.0654
DEBUG - 2022-07-04 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:13:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:13:02 --> Total execution time: 0.0906
DEBUG - 2022-07-04 04:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:13:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 04:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:13:57 --> Total execution time: 0.0830
DEBUG - 2022-07-04 04:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:03 --> Total execution time: 0.0909
DEBUG - 2022-07-04 04:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:05 --> Total execution time: 0.0808
DEBUG - 2022-07-04 04:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:07 --> Total execution time: 0.0607
DEBUG - 2022-07-04 04:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:12 --> Total execution time: 0.0880
DEBUG - 2022-07-04 04:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:16 --> Total execution time: 0.0802
DEBUG - 2022-07-04 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:19 --> Total execution time: 0.0806
DEBUG - 2022-07-04 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 04:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:38 --> Total execution time: 0.0822
DEBUG - 2022-07-04 04:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:41 --> Total execution time: 0.0764
DEBUG - 2022-07-04 04:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:42 --> Total execution time: 0.0843
DEBUG - 2022-07-04 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:44 --> Total execution time: 0.0536
DEBUG - 2022-07-04 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:44 --> Total execution time: 0.1176
DEBUG - 2022-07-04 04:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:47 --> Total execution time: 0.0540
DEBUG - 2022-07-04 04:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:14:52 --> Total execution time: 0.0811
DEBUG - 2022-07-04 04:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:16:12 --> Total execution time: 0.0532
DEBUG - 2022-07-04 04:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:16:29 --> Total execution time: 0.1340
DEBUG - 2022-07-04 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:16:38 --> Total execution time: 0.0637
DEBUG - 2022-07-04 04:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:16:48 --> Total execution time: 0.0471
DEBUG - 2022-07-04 04:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:17:01 --> Total execution time: 0.1315
DEBUG - 2022-07-04 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:22:44 --> Total execution time: 0.1004
DEBUG - 2022-07-04 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 04:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:22:45 --> Total execution time: 0.0502
DEBUG - 2022-07-04 04:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:26:05 --> Total execution time: 0.1306
DEBUG - 2022-07-04 04:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 04:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 04:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:27:38 --> Total execution time: 0.1776
DEBUG - 2022-07-04 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:30:03 --> Total execution time: 0.1120
DEBUG - 2022-07-04 05:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:00:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:30:31 --> Total execution time: 0.0558
DEBUG - 2022-07-04 05:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:30:57 --> Total execution time: 0.0561
DEBUG - 2022-07-04 05:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:31:42 --> Total execution time: 0.1595
DEBUG - 2022-07-04 05:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:31:46 --> Total execution time: 0.1563
DEBUG - 2022-07-04 05:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:01:48 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:31:48 --> Total execution time: 0.0593
DEBUG - 2022-07-04 05:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:31:53 --> Total execution time: 0.0644
DEBUG - 2022-07-04 05:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:04 --> Total execution time: 0.0614
DEBUG - 2022-07-04 05:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:11 --> Total execution time: 0.0499
DEBUG - 2022-07-04 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:13 --> Total execution time: 0.0547
DEBUG - 2022-07-04 05:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:30 --> Total execution time: 0.0726
DEBUG - 2022-07-04 05:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:31 --> Total execution time: 0.0861
DEBUG - 2022-07-04 05:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:37 --> Total execution time: 0.0707
DEBUG - 2022-07-04 05:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:41 --> Total execution time: 0.1860
DEBUG - 2022-07-04 05:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:46 --> Total execution time: 0.0552
DEBUG - 2022-07-04 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:32:57 --> Total execution time: 0.0543
DEBUG - 2022-07-04 05:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:33:02 --> Total execution time: 0.0534
DEBUG - 2022-07-04 05:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:33:29 --> Total execution time: 0.0531
DEBUG - 2022-07-04 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:33:51 --> Total execution time: 0.0531
DEBUG - 2022-07-04 05:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:35:08 --> Total execution time: 0.0329
DEBUG - 2022-07-04 05:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:06:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:36:10 --> Total execution time: 0.0419
DEBUG - 2022-07-04 05:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:06:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 05:06:22 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 05:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:37:08 --> Total execution time: 0.0493
DEBUG - 2022-07-04 05:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:37:50 --> Total execution time: 0.0637
DEBUG - 2022-07-04 05:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:08:51 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:38:51 --> Total execution time: 0.0390
DEBUG - 2022-07-04 05:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:39:07 --> Total execution time: 0.0358
DEBUG - 2022-07-04 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:39:36 --> Total execution time: 0.0581
DEBUG - 2022-07-04 05:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:39:45 --> Total execution time: 0.0578
DEBUG - 2022-07-04 05:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:09 --> Total execution time: 0.0885
DEBUG - 2022-07-04 05:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:22 --> Total execution time: 0.0598
DEBUG - 2022-07-04 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:30 --> Total execution time: 0.0730
DEBUG - 2022-07-04 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:31 --> Total execution time: 0.0526
DEBUG - 2022-07-04 05:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:34 --> Total execution time: 0.0803
DEBUG - 2022-07-04 05:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:42 --> Total execution time: 0.0530
DEBUG - 2022-07-04 05:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:46 --> Total execution time: 0.0746
DEBUG - 2022-07-04 05:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:40:51 --> Total execution time: 0.0633
DEBUG - 2022-07-04 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:41:20 --> Total execution time: 0.1191
DEBUG - 2022-07-04 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:41:21 --> Total execution time: 0.0658
DEBUG - 2022-07-04 05:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:41:25 --> Total execution time: 0.0699
DEBUG - 2022-07-04 05:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:41:29 --> Total execution time: 0.0610
DEBUG - 2022-07-04 05:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:42:05 --> Total execution time: 0.0490
DEBUG - 2022-07-04 05:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:42:33 --> Total execution time: 0.1476
DEBUG - 2022-07-04 05:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:42:42 --> Total execution time: 0.0586
DEBUG - 2022-07-04 05:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:12:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:42:42 --> Total execution time: 0.0434
DEBUG - 2022-07-04 05:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:42:48 --> Total execution time: 0.0695
DEBUG - 2022-07-04 05:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:43:06 --> Total execution time: 0.0508
DEBUG - 2022-07-04 05:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:44:09 --> Total execution time: 0.0609
DEBUG - 2022-07-04 05:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:44:14 --> Total execution time: 0.0590
DEBUG - 2022-07-04 05:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:44:20 --> Total execution time: 0.0712
DEBUG - 2022-07-04 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:44:42 --> Total execution time: 0.0563
DEBUG - 2022-07-04 05:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:45:26 --> Total execution time: 0.1361
DEBUG - 2022-07-04 05:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:45:27 --> Total execution time: 0.1708
DEBUG - 2022-07-04 05:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:45:27 --> Total execution time: 0.1057
DEBUG - 2022-07-04 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:45:29 --> Total execution time: 0.1138
DEBUG - 2022-07-04 05:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:45:57 --> Total execution time: 0.1456
DEBUG - 2022-07-04 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:45:59 --> Total execution time: 0.0605
DEBUG - 2022-07-04 05:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:01 --> Total execution time: 0.1360
DEBUG - 2022-07-04 05:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:16:21 --> Total execution time: 0.0594
DEBUG - 2022-07-04 05:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:47:19 --> Total execution time: 0.0599
DEBUG - 2022-07-04 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:18:53 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:48:53 --> Total execution time: 0.0983
DEBUG - 2022-07-04 05:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:53:18 --> Total execution time: 0.3242
DEBUG - 2022-07-04 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:53:24 --> Total execution time: 0.0546
DEBUG - 2022-07-04 05:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:27:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:57:13 --> Total execution time: 0.1624
DEBUG - 2022-07-04 05:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:58:46 --> Total execution time: 0.1914
DEBUG - 2022-07-04 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:58:47 --> Total execution time: 0.0687
DEBUG - 2022-07-04 05:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:30:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:00:45 --> Total execution time: 0.0390
DEBUG - 2022-07-04 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:00:53 --> Total execution time: 0.0497
DEBUG - 2022-07-04 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:01:15 --> Total execution time: 0.0838
DEBUG - 2022-07-04 05:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:01:53 --> Total execution time: 0.0649
DEBUG - 2022-07-04 05:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:02:03 --> Total execution time: 0.1247
DEBUG - 2022-07-04 05:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:21 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:02:21 --> Total execution time: 0.0382
DEBUG - 2022-07-04 05:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:02:31 --> Total execution time: 0.0677
DEBUG - 2022-07-04 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:02:50 --> Total execution time: 0.0552
DEBUG - 2022-07-04 05:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:02:58 --> Total execution time: 0.1281
DEBUG - 2022-07-04 05:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 05:32:58 --> 404 Page Not Found: Wp_wrong_datlibphp/index
DEBUG - 2022-07-04 05:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:00 --> Total execution time: 0.0367
DEBUG - 2022-07-04 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:02 --> Total execution time: 0.0745
DEBUG - 2022-07-04 05:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:03 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:03 --> Total execution time: 0.0668
DEBUG - 2022-07-04 05:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:08 --> Total execution time: 0.0682
DEBUG - 2022-07-04 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:11 --> Total execution time: 0.0709
DEBUG - 2022-07-04 05:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:16 --> Total execution time: 0.0712
DEBUG - 2022-07-04 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:17 --> Total execution time: 0.0935
DEBUG - 2022-07-04 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:27 --> Total execution time: 0.0596
DEBUG - 2022-07-04 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:31 --> Total execution time: 0.0592
DEBUG - 2022-07-04 05:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:35 --> Total execution time: 0.1769
DEBUG - 2022-07-04 05:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:38 --> Total execution time: 0.0845
DEBUG - 2022-07-04 05:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:03:55 --> Total execution time: 0.0643
DEBUG - 2022-07-04 05:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 05:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:01 --> Total execution time: 0.1220
DEBUG - 2022-07-04 05:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:06 --> Total execution time: 0.0932
DEBUG - 2022-07-04 05:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:12 --> Total execution time: 0.0963
DEBUG - 2022-07-04 05:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:18 --> Total execution time: 0.0884
DEBUG - 2022-07-04 05:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:21 --> Total execution time: 0.1195
DEBUG - 2022-07-04 05:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:28 --> Total execution time: 0.1481
DEBUG - 2022-07-04 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:04:36 --> Total execution time: 0.1425
DEBUG - 2022-07-04 05:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:04 --> Total execution time: 0.1462
DEBUG - 2022-07-04 05:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:17 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:17 --> Total execution time: 0.0448
DEBUG - 2022-07-04 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:23 --> Total execution time: 0.1299
DEBUG - 2022-07-04 05:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:24 --> Total execution time: 0.0392
DEBUG - 2022-07-04 05:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:28 --> Total execution time: 0.0952
DEBUG - 2022-07-04 05:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:42 --> Total execution time: 0.0537
DEBUG - 2022-07-04 05:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 05:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:46 --> Total execution time: 0.1161
DEBUG - 2022-07-04 05:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:46 --> Total execution time: 0.0967
DEBUG - 2022-07-04 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:49 --> Total execution time: 0.1039
DEBUG - 2022-07-04 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:05:50 --> Total execution time: 0.1088
DEBUG - 2022-07-04 05:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:00 --> Total execution time: 0.1266
DEBUG - 2022-07-04 05:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:04 --> Total execution time: 0.0608
DEBUG - 2022-07-04 05:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:05 --> Total execution time: 0.0538
DEBUG - 2022-07-04 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:13 --> Total execution time: 0.0646
DEBUG - 2022-07-04 05:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:21 --> Total execution time: 0.0579
DEBUG - 2022-07-04 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:30 --> Total execution time: 0.1151
DEBUG - 2022-07-04 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:31 --> Total execution time: 0.0959
DEBUG - 2022-07-04 05:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:42 --> Total execution time: 0.0476
DEBUG - 2022-07-04 05:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:45 --> Total execution time: 0.0475
DEBUG - 2022-07-04 05:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:11:04 --> Total execution time: 0.0532
DEBUG - 2022-07-04 05:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:13:25 --> Total execution time: 0.0935
DEBUG - 2022-07-04 05:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:13:30 --> Total execution time: 0.0480
DEBUG - 2022-07-04 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:13:31 --> Total execution time: 0.0562
DEBUG - 2022-07-04 05:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:43:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:13:34 --> Total execution time: 0.0590
DEBUG - 2022-07-04 05:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:44:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:14:24 --> Total execution time: 0.1594
DEBUG - 2022-07-04 05:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:15:29 --> Total execution time: 0.0480
DEBUG - 2022-07-04 05:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:18:01 --> Total execution time: 0.1152
DEBUG - 2022-07-04 05:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:18:09 --> Total execution time: 0.1456
DEBUG - 2022-07-04 05:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:18:21 --> Total execution time: 0.0576
DEBUG - 2022-07-04 05:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:18:28 --> Total execution time: 0.0887
DEBUG - 2022-07-04 05:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:48:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 05:48:37 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 05:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:06 --> Total execution time: 0.0742
DEBUG - 2022-07-04 05:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:11 --> Total execution time: 0.0641
DEBUG - 2022-07-04 05:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:14 --> Total execution time: 0.0621
DEBUG - 2022-07-04 05:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:20 --> Total execution time: 0.0521
DEBUG - 2022-07-04 05:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:23 --> Total execution time: 0.0568
DEBUG - 2022-07-04 05:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:36 --> Total execution time: 0.0609
DEBUG - 2022-07-04 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:19:47 --> Total execution time: 0.0636
DEBUG - 2022-07-04 05:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:49:49 --> Total execution time: 0.0605
DEBUG - 2022-07-04 05:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:49:50 --> Total execution time: 0.0606
DEBUG - 2022-07-04 05:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:49:50 --> Total execution time: 0.1326
DEBUG - 2022-07-04 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:50:03 --> Total execution time: 0.0522
DEBUG - 2022-07-04 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:50:08 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:20:08 --> Total execution time: 0.0660
DEBUG - 2022-07-04 05:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:20:09 --> Total execution time: 0.0488
DEBUG - 2022-07-04 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:20:25 --> Total execution time: 0.0515
DEBUG - 2022-07-04 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 05:51:29 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:53:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:23:42 --> Total execution time: 0.1897
DEBUG - 2022-07-04 05:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:53:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 05:53:49 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 05:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:23:52 --> Total execution time: 1.5835
DEBUG - 2022-07-04 05:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 05:53:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 05:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:54:03 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:24:04 --> Total execution time: 0.0576
DEBUG - 2022-07-04 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:54:08 --> No URI present. Default controller set.
DEBUG - 2022-07-04 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:24:09 --> Total execution time: 0.1705
DEBUG - 2022-07-04 05:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:24:09 --> Total execution time: 0.0814
DEBUG - 2022-07-04 05:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:24:52 --> Total execution time: 0.0554
DEBUG - 2022-07-04 05:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:24:59 --> Total execution time: 0.0615
DEBUG - 2022-07-04 05:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:25:02 --> Total execution time: 0.0829
DEBUG - 2022-07-04 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:28:13 --> Total execution time: 0.0608
DEBUG - 2022-07-04 05:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 05:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 05:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 05:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:29:36 --> Total execution time: 0.0708
DEBUG - 2022-07-04 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:30:02 --> Total execution time: 0.0628
DEBUG - 2022-07-04 06:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:31:42 --> Total execution time: 0.0333
DEBUG - 2022-07-04 06:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:03:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:45 --> Total execution time: 0.1080
DEBUG - 2022-07-04 06:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:03:46 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:46 --> Total execution time: 0.0407
DEBUG - 2022-07-04 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:55 --> Total execution time: 0.0403
DEBUG - 2022-07-04 06:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:34:04 --> Total execution time: 0.0835
DEBUG - 2022-07-04 06:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:34:19 --> Total execution time: 0.0721
DEBUG - 2022-07-04 06:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:34:33 --> Total execution time: 0.0801
DEBUG - 2022-07-04 06:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:34:33 --> Total execution time: 0.0511
DEBUG - 2022-07-04 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:04:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:34:35 --> Total execution time: 0.0519
DEBUG - 2022-07-04 06:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:06:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:36:26 --> Total execution time: 0.0372
DEBUG - 2022-07-04 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:10:53 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:40:53 --> Total execution time: 0.1189
DEBUG - 2022-07-04 06:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:40:58 --> Total execution time: 0.0341
DEBUG - 2022-07-04 06:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:41:15 --> Total execution time: 0.0517
DEBUG - 2022-07-04 06:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:11:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:41:23 --> Total execution time: 0.0566
DEBUG - 2022-07-04 06:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:41:33 --> Total execution time: 0.0331
DEBUG - 2022-07-04 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:42:06 --> Total execution time: 0.0516
DEBUG - 2022-07-04 06:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:42:16 --> Total execution time: 0.0708
DEBUG - 2022-07-04 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:42:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:42:17 --> Total execution time: 0.0491
DEBUG - 2022-07-04 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:42:26 --> Total execution time: 0.0455
DEBUG - 2022-07-04 06:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:43:23 --> Total execution time: 0.0516
DEBUG - 2022-07-04 06:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:43:45 --> Total execution time: 0.0505
DEBUG - 2022-07-04 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:43:57 --> Total execution time: 0.0505
DEBUG - 2022-07-04 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:44:01 --> Total execution time: 0.0559
DEBUG - 2022-07-04 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:14:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:44:07 --> Total execution time: 0.0498
DEBUG - 2022-07-04 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:44:25 --> Total execution time: 0.0485
DEBUG - 2022-07-04 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:44:25 --> Total execution time: 0.0490
DEBUG - 2022-07-04 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:14:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:44:25 --> Total execution time: 0.0536
DEBUG - 2022-07-04 06:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:45:17 --> Total execution time: 0.0526
DEBUG - 2022-07-04 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:45:24 --> Total execution time: 0.0605
DEBUG - 2022-07-04 06:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:45:28 --> Total execution time: 0.0549
DEBUG - 2022-07-04 06:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:45:33 --> Total execution time: 0.0573
DEBUG - 2022-07-04 06:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:45:37 --> Total execution time: 0.0522
DEBUG - 2022-07-04 06:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:15:38 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:45:38 --> Total execution time: 0.0422
DEBUG - 2022-07-04 06:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:16:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:46:10 --> Total execution time: 0.0639
DEBUG - 2022-07-04 06:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:46:14 --> Total execution time: 0.0562
DEBUG - 2022-07-04 06:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:16:16 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:46:16 --> Total execution time: 0.1374
DEBUG - 2022-07-04 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:46:20 --> Total execution time: 0.0469
DEBUG - 2022-07-04 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:04 --> Total execution time: 0.0617
DEBUG - 2022-07-04 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:06 --> Total execution time: 0.0784
DEBUG - 2022-07-04 06:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:13 --> Total execution time: 0.0538
DEBUG - 2022-07-04 06:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:21 --> Total execution time: 0.0864
DEBUG - 2022-07-04 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:40 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:40 --> Total execution time: 0.0453
DEBUG - 2022-07-04 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:40 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:40 --> Total execution time: 0.0468
DEBUG - 2022-07-04 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:44 --> Total execution time: 0.0326
DEBUG - 2022-07-04 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:47:48 --> Total execution time: 0.0564
DEBUG - 2022-07-04 06:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:08 --> Total execution time: 0.0481
DEBUG - 2022-07-04 06:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:12 --> Total execution time: 0.0534
DEBUG - 2022-07-04 06:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:18 --> Total execution time: 0.0606
DEBUG - 2022-07-04 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:28 --> Total execution time: 0.0693
DEBUG - 2022-07-04 06:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:35 --> Total execution time: 0.0539
DEBUG - 2022-07-04 06:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:54 --> Total execution time: 0.0778
DEBUG - 2022-07-04 06:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:49:01 --> Total execution time: 0.0705
DEBUG - 2022-07-04 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:49:31 --> Total execution time: 0.0608
DEBUG - 2022-07-04 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 06:19:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:50:06 --> Total execution time: 0.0663
DEBUG - 2022-07-04 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:50:22 --> Total execution time: 0.0529
DEBUG - 2022-07-04 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:20:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:50:55 --> Total execution time: 0.0512
DEBUG - 2022-07-04 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:50:59 --> Total execution time: 0.0516
DEBUG - 2022-07-04 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:00 --> Total execution time: 0.0733
DEBUG - 2022-07-04 06:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:18 --> Total execution time: 0.0470
DEBUG - 2022-07-04 06:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:23 --> Total execution time: 0.0491
DEBUG - 2022-07-04 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:30 --> Total execution time: 0.0494
DEBUG - 2022-07-04 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:32 --> Total execution time: 0.0487
DEBUG - 2022-07-04 06:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:32 --> Total execution time: 0.1009
DEBUG - 2022-07-04 06:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:38 --> Total execution time: 0.0490
DEBUG - 2022-07-04 06:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:39 --> Total execution time: 0.0592
DEBUG - 2022-07-04 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:56 --> Total execution time: 0.0631
DEBUG - 2022-07-04 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:51:57 --> Total execution time: 0.0526
DEBUG - 2022-07-04 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:22:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:52:13 --> Total execution time: 0.1302
DEBUG - 2022-07-04 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:52:17 --> Total execution time: 0.1172
DEBUG - 2022-07-04 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:22:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:52:26 --> Total execution time: 0.0366
DEBUG - 2022-07-04 06:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:52:42 --> Total execution time: 0.0536
DEBUG - 2022-07-04 06:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:52:46 --> Total execution time: 0.0593
DEBUG - 2022-07-04 06:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:14 --> Total execution time: 0.0641
DEBUG - 2022-07-04 06:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:17 --> Total execution time: 0.0711
DEBUG - 2022-07-04 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:17 --> Total execution time: 0.0591
DEBUG - 2022-07-04 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:18 --> Total execution time: 0.0486
DEBUG - 2022-07-04 06:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:22 --> Total execution time: 0.0642
DEBUG - 2022-07-04 06:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:32 --> Total execution time: 0.0603
DEBUG - 2022-07-04 06:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:37 --> Total execution time: 0.0731
DEBUG - 2022-07-04 06:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:52 --> Total execution time: 0.0338
DEBUG - 2022-07-04 06:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:53:56 --> Total execution time: 0.0486
DEBUG - 2022-07-04 06:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:24:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:54:25 --> Total execution time: 0.0349
DEBUG - 2022-07-04 06:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:24:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:54:25 --> Total execution time: 0.0515
DEBUG - 2022-07-04 06:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 06:24:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 06:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:24:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:54:35 --> Total execution time: 0.0512
DEBUG - 2022-07-04 06:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 06:24:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 06:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:25:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:55:42 --> Total execution time: 0.0561
DEBUG - 2022-07-04 06:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:56:30 --> Total execution time: 0.0354
DEBUG - 2022-07-04 06:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:56:57 --> Total execution time: 0.0608
DEBUG - 2022-07-04 06:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:57:22 --> Total execution time: 0.0477
DEBUG - 2022-07-04 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:57:35 --> Total execution time: 0.0514
DEBUG - 2022-07-04 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:57:39 --> Total execution time: 0.0583
DEBUG - 2022-07-04 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:58:07 --> Total execution time: 0.0585
DEBUG - 2022-07-04 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:58:19 --> Total execution time: 0.0862
DEBUG - 2022-07-04 06:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:58:35 --> Total execution time: 0.0884
DEBUG - 2022-07-04 06:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:58:43 --> Total execution time: 0.0875
DEBUG - 2022-07-04 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:29:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:59:55 --> Total execution time: 0.0403
DEBUG - 2022-07-04 06:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:30:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:00:00 --> Total execution time: 0.0420
DEBUG - 2022-07-04 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:31:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:01:20 --> Total execution time: 0.0418
DEBUG - 2022-07-04 06:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:01:25 --> Total execution time: 0.0270
DEBUG - 2022-07-04 06:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:02:32 --> Total execution time: 0.0582
DEBUG - 2022-07-04 06:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:02:52 --> Total execution time: 0.0728
DEBUG - 2022-07-04 06:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:33:15 --> Total execution time: 0.0606
DEBUG - 2022-07-04 06:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:33:30 --> Total execution time: 0.0553
DEBUG - 2022-07-04 06:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:33:35 --> Total execution time: 0.0534
DEBUG - 2022-07-04 06:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:03:35 --> Total execution time: 0.0552
DEBUG - 2022-07-04 06:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:04:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 06:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:04:01 --> Total execution time: 0.0848
DEBUG - 2022-07-04 06:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:04:12 --> Total execution time: 0.1044
DEBUG - 2022-07-04 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:04:32 --> Total execution time: 0.0840
DEBUG - 2022-07-04 06:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:05:07 --> Total execution time: 0.0653
DEBUG - 2022-07-04 06:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:05:15 --> Total execution time: 0.0557
DEBUG - 2022-07-04 06:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:06:01 --> Total execution time: 0.1015
DEBUG - 2022-07-04 06:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:06:12 --> Total execution time: 0.0621
DEBUG - 2022-07-04 06:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:36:22 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:06:22 --> Total execution time: 0.0451
DEBUG - 2022-07-04 06:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:06:29 --> Total execution time: 0.1830
DEBUG - 2022-07-04 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:07:51 --> Total execution time: 0.0601
DEBUG - 2022-07-04 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:08:08 --> Total execution time: 0.1030
DEBUG - 2022-07-04 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:08:12 --> Total execution time: 0.0681
DEBUG - 2022-07-04 06:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:08:13 --> Total execution time: 0.1184
DEBUG - 2022-07-04 06:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:08:17 --> Total execution time: 0.0561
DEBUG - 2022-07-04 06:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:08:26 --> Total execution time: 0.0735
DEBUG - 2022-07-04 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:38:34 --> Total execution time: 0.0567
DEBUG - 2022-07-04 06:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:39:01 --> Total execution time: 0.0635
DEBUG - 2022-07-04 06:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:39:04 --> Total execution time: 0.0670
DEBUG - 2022-07-04 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:09:33 --> Total execution time: 0.1479
DEBUG - 2022-07-04 06:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:39:55 --> Total execution time: 0.0470
DEBUG - 2022-07-04 06:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:09:59 --> Total execution time: 0.0364
DEBUG - 2022-07-04 06:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:39:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:09:59 --> Total execution time: 0.0577
DEBUG - 2022-07-04 06:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:10:06 --> Total execution time: 0.0720
DEBUG - 2022-07-04 06:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:09 --> Total execution time: 0.0572
DEBUG - 2022-07-04 06:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:21 --> Total execution time: 0.0517
DEBUG - 2022-07-04 06:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:25 --> Total execution time: 0.0542
DEBUG - 2022-07-04 06:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:27 --> Total execution time: 0.0495
DEBUG - 2022-07-04 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:29 --> Total execution time: 0.0570
DEBUG - 2022-07-04 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:10:29 --> Total execution time: 0.0841
DEBUG - 2022-07-04 06:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:10:34 --> Total execution time: 0.0590
DEBUG - 2022-07-04 06:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:10:39 --> Total execution time: 0.0510
DEBUG - 2022-07-04 06:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:10:43 --> Total execution time: 0.0831
DEBUG - 2022-07-04 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:11:17 --> Total execution time: 0.0961
DEBUG - 2022-07-04 06:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:11:33 --> Total execution time: 0.1282
DEBUG - 2022-07-04 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:11:40 --> Total execution time: 0.0773
DEBUG - 2022-07-04 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:11:40 --> Total execution time: 0.0517
DEBUG - 2022-07-04 06:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:11:58 --> Total execution time: 0.0592
DEBUG - 2022-07-04 06:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:07 --> Total execution time: 0.1257
DEBUG - 2022-07-04 06:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:07 --> Total execution time: 0.0653
DEBUG - 2022-07-04 06:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:15 --> Total execution time: 0.0558
DEBUG - 2022-07-04 06:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:20 --> Total execution time: 0.0511
DEBUG - 2022-07-04 06:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:24 --> Total execution time: 0.0759
DEBUG - 2022-07-04 06:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:41 --> Total execution time: 0.0563
DEBUG - 2022-07-04 06:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:44 --> Total execution time: 0.0506
DEBUG - 2022-07-04 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:42:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:12:45 --> Total execution time: 0.0528
DEBUG - 2022-07-04 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:20 --> Total execution time: 0.0452
DEBUG - 2022-07-04 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:24 --> Total execution time: 0.0603
DEBUG - 2022-07-04 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:24 --> Total execution time: 0.1255
DEBUG - 2022-07-04 06:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:27 --> Total execution time: 0.0589
DEBUG - 2022-07-04 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 06:43:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:41 --> Total execution time: 0.0718
DEBUG - 2022-07-04 06:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:48 --> Total execution time: 0.0589
DEBUG - 2022-07-04 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:50 --> Total execution time: 0.0706
DEBUG - 2022-07-04 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:43:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:13:50 --> Total execution time: 0.0624
DEBUG - 2022-07-04 06:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:14:17 --> Total execution time: 0.0746
DEBUG - 2022-07-04 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:14:22 --> Total execution time: 0.0627
DEBUG - 2022-07-04 06:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:14:26 --> Total execution time: 0.0550
DEBUG - 2022-07-04 06:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:14:34 --> Total execution time: 0.0783
DEBUG - 2022-07-04 06:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:17:13 --> Total execution time: 0.2246
DEBUG - 2022-07-04 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:17:22 --> Total execution time: 0.0698
DEBUG - 2022-07-04 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:17:26 --> Total execution time: 0.0663
DEBUG - 2022-07-04 06:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:17:29 --> Total execution time: 0.0538
DEBUG - 2022-07-04 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:17:38 --> Total execution time: 0.0951
DEBUG - 2022-07-04 06:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:18:13 --> Total execution time: 0.0622
DEBUG - 2022-07-04 06:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:18:18 --> Total execution time: 0.0759
DEBUG - 2022-07-04 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:25 --> Total execution time: 0.0488
DEBUG - 2022-07-04 06:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:34 --> Total execution time: 0.0500
DEBUG - 2022-07-04 06:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:38 --> Total execution time: 0.0474
DEBUG - 2022-07-04 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:48:58 --> Total execution time: 0.0552
DEBUG - 2022-07-04 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:19:41 --> Total execution time: 0.0460
DEBUG - 2022-07-04 06:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:19:53 --> Total execution time: 0.0520
DEBUG - 2022-07-04 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:49:56 --> Total execution time: 0.0525
DEBUG - 2022-07-04 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:49:59 --> Total execution time: 0.0542
DEBUG - 2022-07-04 17:19:59 --> Total execution time: 0.1681
DEBUG - 2022-07-04 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:50:02 --> Total execution time: 0.0794
DEBUG - 2022-07-04 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:50:04 --> Total execution time: 0.0565
DEBUG - 2022-07-04 06:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:50:07 --> Total execution time: 0.0732
DEBUG - 2022-07-04 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:20:09 --> Total execution time: 0.0858
DEBUG - 2022-07-04 06:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:20:24 --> Total execution time: 0.0534
DEBUG - 2022-07-04 06:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:20:25 --> Total execution time: 0.0502
DEBUG - 2022-07-04 06:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:20:28 --> Total execution time: 0.0632
DEBUG - 2022-07-04 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:20:59 --> Total execution time: 0.3996
DEBUG - 2022-07-04 06:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:21:13 --> Total execution time: 0.0733
DEBUG - 2022-07-04 06:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:21:16 --> Total execution time: 0.0970
DEBUG - 2022-07-04 06:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:21:22 --> Total execution time: 0.0676
DEBUG - 2022-07-04 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:22:48 --> Total execution time: 0.1682
DEBUG - 2022-07-04 06:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:52:51 --> Total execution time: 0.0741
DEBUG - 2022-07-04 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:52:59 --> Total execution time: 0.1157
DEBUG - 2022-07-04 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:23:51 --> Total execution time: 0.0784
DEBUG - 2022-07-04 06:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:54:21 --> Total execution time: 0.0726
DEBUG - 2022-07-04 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:54:31 --> Total execution time: 0.0675
DEBUG - 2022-07-04 06:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:54:56 --> Total execution time: 0.0526
DEBUG - 2022-07-04 06:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:55:00 --> Total execution time: 0.0488
DEBUG - 2022-07-04 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 06:55:01 --> Total execution time: 0.0617
DEBUG - 2022-07-04 06:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:25:03 --> Total execution time: 0.0672
DEBUG - 2022-07-04 06:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:25:12 --> Total execution time: 0.0782
DEBUG - 2022-07-04 06:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:25:15 --> Total execution time: 0.0732
DEBUG - 2022-07-04 06:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:25:45 --> Total execution time: 0.0566
DEBUG - 2022-07-04 06:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:56:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 06:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:26:10 --> Total execution time: 0.1316
DEBUG - 2022-07-04 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:27:46 --> Total execution time: 0.0687
DEBUG - 2022-07-04 06:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:27:56 --> Total execution time: 0.0572
DEBUG - 2022-07-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 06:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 06:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:29:42 --> Total execution time: 0.1493
DEBUG - 2022-07-04 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:30:03 --> Total execution time: 0.0916
DEBUG - 2022-07-04 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:00:05 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:30:05 --> Total execution time: 0.1298
DEBUG - 2022-07-04 07:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:00:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:30:31 --> Total execution time: 0.0982
DEBUG - 2022-07-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:30:41 --> Total execution time: 1.9116
DEBUG - 2022-07-04 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 07:00:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:31:19 --> Total execution time: 0.0595
DEBUG - 2022-07-04 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:01:27 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:31:27 --> Total execution time: 0.0505
DEBUG - 2022-07-04 07:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:31:39 --> Total execution time: 1.4458
DEBUG - 2022-07-04 07:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:01:43 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:31:43 --> Total execution time: 0.0540
DEBUG - 2022-07-04 07:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:33:04 --> Total execution time: 0.0663
DEBUG - 2022-07-04 07:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:33:13 --> Total execution time: 0.0536
DEBUG - 2022-07-04 07:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:33:13 --> Total execution time: 0.0556
DEBUG - 2022-07-04 07:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:33:29 --> Total execution time: 0.1526
DEBUG - 2022-07-04 07:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:33:42 --> Total execution time: 0.0803
DEBUG - 2022-07-04 07:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:33:57 --> Total execution time: 0.0653
DEBUG - 2022-07-04 07:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:34:07 --> Total execution time: 0.0826
DEBUG - 2022-07-04 07:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:34:14 --> Total execution time: 0.0768
DEBUG - 2022-07-04 07:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:35:08 --> Total execution time: 0.0794
DEBUG - 2022-07-04 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:35:20 --> Total execution time: 0.0324
DEBUG - 2022-07-04 07:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:35:22 --> Total execution time: 0.0717
DEBUG - 2022-07-04 07:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:07:15 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:37:16 --> Total execution time: 0.1602
DEBUG - 2022-07-04 07:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:37:19 --> Total execution time: 0.1471
DEBUG - 2022-07-04 07:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:37:37 --> Total execution time: 0.0846
DEBUG - 2022-07-04 07:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:02 --> Total execution time: 0.0539
DEBUG - 2022-07-04 07:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:08 --> Total execution time: 0.0691
DEBUG - 2022-07-04 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:16 --> Total execution time: 0.0670
DEBUG - 2022-07-04 07:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:18 --> Total execution time: 0.0472
DEBUG - 2022-07-04 07:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:19 --> Total execution time: 0.0528
DEBUG - 2022-07-04 07:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:26 --> Total execution time: 0.0583
DEBUG - 2022-07-04 07:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:57 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:38:57 --> Total execution time: 0.0430
DEBUG - 2022-07-04 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:39:00 --> Total execution time: 0.0479
DEBUG - 2022-07-04 07:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:39:03 --> Total execution time: 0.0501
DEBUG - 2022-07-04 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:39:10 --> Total execution time: 0.1487
DEBUG - 2022-07-04 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:39:10 --> Total execution time: 0.0582
DEBUG - 2022-07-04 07:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:39:16 --> Total execution time: 1.5554
DEBUG - 2022-07-04 07:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:17 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:39:17 --> Total execution time: 0.0764
DEBUG - 2022-07-04 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 07:09:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 07:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:21 --> Total execution time: 0.1040
DEBUG - 2022-07-04 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:23 --> Total execution time: 0.0506
DEBUG - 2022-07-04 07:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:23 --> Total execution time: 0.1240
DEBUG - 2022-07-04 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:41 --> Total execution time: 0.0659
DEBUG - 2022-07-04 07:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:46 --> Total execution time: 0.0577
DEBUG - 2022-07-04 07:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:09:55 --> Total execution time: 0.0631
DEBUG - 2022-07-04 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:10:05 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:40:05 --> Total execution time: 0.0667
DEBUG - 2022-07-04 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:40:08 --> Total execution time: 0.0579
DEBUG - 2022-07-04 07:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:41:06 --> Total execution time: 0.1309
DEBUG - 2022-07-04 07:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:11:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:41:23 --> Total execution time: 0.0408
DEBUG - 2022-07-04 07:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:11:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:41:24 --> Total execution time: 0.0408
DEBUG - 2022-07-04 07:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:41:27 --> Total execution time: 0.0881
DEBUG - 2022-07-04 07:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:11:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:41:35 --> Total execution time: 0.0474
DEBUG - 2022-07-04 07:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:42:29 --> Total execution time: 0.1267
DEBUG - 2022-07-04 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:12:52 --> Total execution time: 0.0605
DEBUG - 2022-07-04 07:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:13:13 --> Total execution time: 0.0774
DEBUG - 2022-07-04 07:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:13:19 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:43:19 --> Total execution time: 0.0586
DEBUG - 2022-07-04 07:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:13:38 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:43:38 --> Total execution time: 0.0602
DEBUG - 2022-07-04 07:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:43:45 --> Total execution time: 0.0529
DEBUG - 2022-07-04 07:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:44:34 --> Total execution time: 0.0855
DEBUG - 2022-07-04 07:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:45:28 --> Total execution time: 0.1490
DEBUG - 2022-07-04 07:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:15:43 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:45:43 --> Total execution time: 0.0559
DEBUG - 2022-07-04 07:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:45:56 --> Total execution time: 1.5121
DEBUG - 2022-07-04 07:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:46:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 07:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:46:45 --> Total execution time: 0.0740
DEBUG - 2022-07-04 07:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:46:57 --> Total execution time: 0.0783
DEBUG - 2022-07-04 07:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:47:05 --> Total execution time: 0.0619
DEBUG - 2022-07-04 07:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:47:08 --> Total execution time: 0.1325
DEBUG - 2022-07-04 07:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:47:11 --> Total execution time: 0.0473
DEBUG - 2022-07-04 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:47:16 --> Total execution time: 0.0584
DEBUG - 2022-07-04 07:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:47:20 --> Total execution time: 0.0773
DEBUG - 2022-07-04 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:47:41 --> Total execution time: 0.0720
DEBUG - 2022-07-04 07:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:18:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:48:25 --> Total execution time: 0.0383
DEBUG - 2022-07-04 07:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:18:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:48:45 --> Total execution time: 0.0792
DEBUG - 2022-07-04 07:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:18:46 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:48:46 --> Total execution time: 0.1077
DEBUG - 2022-07-04 07:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:19:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:49:23 --> Total execution time: 0.0706
DEBUG - 2022-07-04 07:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:49:59 --> Total execution time: 0.0545
DEBUG - 2022-07-04 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:50:12 --> Total execution time: 0.0987
DEBUG - 2022-07-04 07:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:50:16 --> Total execution time: 0.0714
DEBUG - 2022-07-04 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:50:21 --> Total execution time: 0.1325
DEBUG - 2022-07-04 07:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:20:40 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:50:40 --> Total execution time: 0.1421
DEBUG - 2022-07-04 07:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:50:49 --> Total execution time: 1.5649
DEBUG - 2022-07-04 07:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:56:29 --> Total execution time: 0.1915
DEBUG - 2022-07-04 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:56:32 --> Total execution time: 0.1201
DEBUG - 2022-07-04 17:56:32 --> Total execution time: 0.1842
DEBUG - 2022-07-04 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:56:39 --> Total execution time: 0.0467
DEBUG - 2022-07-04 07:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:56:44 --> Total execution time: 0.0566
DEBUG - 2022-07-04 07:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:57:07 --> Total execution time: 0.0576
DEBUG - 2022-07-04 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:57:08 --> Total execution time: 0.0508
DEBUG - 2022-07-04 07:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:57:17 --> Total execution time: 0.0754
DEBUG - 2022-07-04 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:57:23 --> Total execution time: 1.5602
DEBUG - 2022-07-04 07:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:57:36 --> Total execution time: 0.0827
DEBUG - 2022-07-04 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:57:56 --> Total execution time: 1.5019
DEBUG - 2022-07-04 07:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:05 --> Total execution time: 0.0786
DEBUG - 2022-07-04 07:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:12 --> Total execution time: 0.0680
DEBUG - 2022-07-04 07:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:17 --> Total execution time: 0.0579
DEBUG - 2022-07-04 07:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:20 --> Total execution time: 0.0590
DEBUG - 2022-07-04 07:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:38 --> Total execution time: 0.0481
DEBUG - 2022-07-04 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:51 --> Total execution time: 0.0523
DEBUG - 2022-07-04 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:58:58 --> Total execution time: 0.0813
DEBUG - 2022-07-04 07:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:59:08 --> Total execution time: 0.0766
DEBUG - 2022-07-04 07:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:59:34 --> Total execution time: 0.0937
DEBUG - 2022-07-04 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:03:48 --> Total execution time: 0.2005
DEBUG - 2022-07-04 07:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:03:48 --> Total execution time: 0.0625
DEBUG - 2022-07-04 07:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:04:04 --> Total execution time: 0.0518
DEBUG - 2022-07-04 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:34:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:04:59 --> Total execution time: 0.0426
DEBUG - 2022-07-04 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:00 --> Total execution time: 0.1406
DEBUG - 2022-07-04 07:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:00 --> Total execution time: 0.0585
DEBUG - 2022-07-04 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:05 --> Total execution time: 0.0626
DEBUG - 2022-07-04 07:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:19 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:19 --> Total execution time: 0.0558
DEBUG - 2022-07-04 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:35:24 --> Total execution time: 0.0510
DEBUG - 2022-07-04 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:35:25 --> Total execution time: 0.0664
DEBUG - 2022-07-04 07:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:35:25 --> Total execution time: 0.1233
DEBUG - 2022-07-04 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:35 --> Total execution time: 0.0523
DEBUG - 2022-07-04 07:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:39 --> Total execution time: 0.0668
DEBUG - 2022-07-04 07:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:05:52 --> Total execution time: 0.0676
DEBUG - 2022-07-04 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:06:27 --> Total execution time: 0.0499
DEBUG - 2022-07-04 07:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:06:41 --> Total execution time: 0.0626
DEBUG - 2022-07-04 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:36:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:06:44 --> Total execution time: 0.0824
DEBUG - 2022-07-04 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:06:49 --> Total execution time: 0.0498
DEBUG - 2022-07-04 07:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:07:22 --> Total execution time: 0.0583
DEBUG - 2022-07-04 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 07:37:23 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 07:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:37:33 --> Total execution time: 0.0566
DEBUG - 2022-07-04 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:08:11 --> Total execution time: 0.0634
DEBUG - 2022-07-04 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:08:14 --> Total execution time: 0.0515
DEBUG - 2022-07-04 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:08:30 --> Total execution time: 0.0502
DEBUG - 2022-07-04 07:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:08:37 --> Total execution time: 0.0561
DEBUG - 2022-07-04 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:08:49 --> Total execution time: 0.1349
DEBUG - 2022-07-04 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:08:56 --> Total execution time: 0.0573
DEBUG - 2022-07-04 07:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:09:21 --> Total execution time: 0.0594
DEBUG - 2022-07-04 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:08 --> Total execution time: 0.0476
DEBUG - 2022-07-04 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:12 --> Total execution time: 0.0670
DEBUG - 2022-07-04 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 07:40:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:28 --> Total execution time: 0.0482
DEBUG - 2022-07-04 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:29 --> Total execution time: 0.0546
DEBUG - 2022-07-04 07:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:34 --> Total execution time: 0.1399
DEBUG - 2022-07-04 07:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:40 --> Total execution time: 0.0523
DEBUG - 2022-07-04 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:52 --> Total execution time: 0.0584
DEBUG - 2022-07-04 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:11:09 --> Total execution time: 0.0516
DEBUG - 2022-07-04 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:11:15 --> Total execution time: 0.0526
DEBUG - 2022-07-04 07:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:11:26 --> Total execution time: 0.0534
DEBUG - 2022-07-04 07:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:41:34 --> Total execution time: 0.0500
DEBUG - 2022-07-04 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:41:35 --> Total execution time: 0.0682
DEBUG - 2022-07-04 07:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:41:35 --> Total execution time: 0.1192
DEBUG - 2022-07-04 07:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:42:25 --> Total execution time: 0.0497
DEBUG - 2022-07-04 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:42:26 --> Total execution time: 0.0541
DEBUG - 2022-07-04 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:42:26 --> Total execution time: 0.1003
DEBUG - 2022-07-04 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 07:42:40 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 07:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:43:08 --> Total execution time: 0.0481
DEBUG - 2022-07-04 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:43:09 --> Total execution time: 0.0590
DEBUG - 2022-07-04 07:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:43:09 --> Total execution time: 0.0794
DEBUG - 2022-07-04 07:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:44:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:14:00 --> Total execution time: 0.0404
DEBUG - 2022-07-04 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:14:39 --> Total execution time: 0.0574
DEBUG - 2022-07-04 07:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:44:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:14:49 --> Total execution time: 0.1232
DEBUG - 2022-07-04 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:44:56 --> Total execution time: 0.0483
DEBUG - 2022-07-04 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:44:57 --> Total execution time: 0.0480
DEBUG - 2022-07-04 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:44:59 --> Total execution time: 0.0518
DEBUG - 2022-07-04 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:05 --> Total execution time: 0.0483
DEBUG - 2022-07-04 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:08 --> Total execution time: 0.0511
DEBUG - 2022-07-04 07:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:09 --> Total execution time: 0.0472
DEBUG - 2022-07-04 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:16:13 --> Total execution time: 0.0486
DEBUG - 2022-07-04 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:23 --> Total execution time: 0.1298
DEBUG - 2022-07-04 07:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:54 --> Total execution time: 0.0822
DEBUG - 2022-07-04 07:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:55 --> Total execution time: 0.0540
DEBUG - 2022-07-04 07:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:46:55 --> Total execution time: 0.0877
DEBUG - 2022-07-04 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:17:22 --> Total execution time: 0.0475
DEBUG - 2022-07-04 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:17:26 --> Total execution time: 0.0657
DEBUG - 2022-07-04 07:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:17:40 --> Total execution time: 0.0513
DEBUG - 2022-07-04 07:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:18:00 --> Total execution time: 0.0718
DEBUG - 2022-07-04 07:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:18:07 --> Total execution time: 0.0644
DEBUG - 2022-07-04 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:18:22 --> Total execution time: 0.0706
DEBUG - 2022-07-04 07:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:18:39 --> Total execution time: 0.0582
DEBUG - 2022-07-04 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:18:43 --> Total execution time: 0.0592
DEBUG - 2022-07-04 07:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:18:57 --> Total execution time: 0.0618
DEBUG - 2022-07-04 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:08 --> Total execution time: 0.0570
DEBUG - 2022-07-04 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:10 --> Total execution time: 0.0563
DEBUG - 2022-07-04 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:14 --> Total execution time: 0.0509
DEBUG - 2022-07-04 07:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:14 --> Total execution time: 0.0731
DEBUG - 2022-07-04 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:15 --> Total execution time: 0.0625
DEBUG - 2022-07-04 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:17 --> Total execution time: 0.0677
DEBUG - 2022-07-04 07:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:23 --> Total execution time: 0.0560
DEBUG - 2022-07-04 07:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:27 --> Total execution time: 0.0600
DEBUG - 2022-07-04 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:19:28 --> Total execution time: 0.0676
DEBUG - 2022-07-04 07:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:51:43 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:21:43 --> Total execution time: 0.1057
DEBUG - 2022-07-04 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:21:54 --> Total execution time: 0.0576
DEBUG - 2022-07-04 07:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:13 --> Total execution time: 0.0646
DEBUG - 2022-07-04 07:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:16 --> Total execution time: 0.0662
DEBUG - 2022-07-04 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:32 --> Total execution time: 0.0670
DEBUG - 2022-07-04 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:35 --> Total execution time: 0.1381
DEBUG - 2022-07-04 07:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:40 --> Total execution time: 0.0608
DEBUG - 2022-07-04 07:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:45 --> Total execution time: 0.0565
DEBUG - 2022-07-04 07:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:47 --> Total execution time: 0.0695
DEBUG - 2022-07-04 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:52:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:22:50 --> Total execution time: 0.0582
DEBUG - 2022-07-04 07:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:53:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:23:23 --> Total execution time: 0.0862
DEBUG - 2022-07-04 07:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:53:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:23:49 --> Total execution time: 0.0548
DEBUG - 2022-07-04 07:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 07:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:24:02 --> Total execution time: 0.0812
DEBUG - 2022-07-04 07:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:24:10 --> Total execution time: 0.1203
DEBUG - 2022-07-04 07:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:24:19 --> Total execution time: 0.1050
DEBUG - 2022-07-04 07:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:24:24 --> Total execution time: 0.2018
DEBUG - 2022-07-04 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:24:28 --> Total execution time: 0.1348
DEBUG - 2022-07-04 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:24:38 --> Total execution time: 0.0590
DEBUG - 2022-07-04 07:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:25:04 --> Total execution time: 0.0525
DEBUG - 2022-07-04 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:25:26 --> Total execution time: 0.0562
DEBUG - 2022-07-04 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:25:32 --> Total execution time: 0.0553
DEBUG - 2022-07-04 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:25:35 --> Total execution time: 0.0643
DEBUG - 2022-07-04 07:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:26:04 --> Total execution time: 0.0528
DEBUG - 2022-07-04 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:57:04 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:27:04 --> Total execution time: 0.1210
DEBUG - 2022-07-04 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 07:58:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 07:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:29:08 --> Total execution time: 0.1369
DEBUG - 2022-07-04 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:29:14 --> Total execution time: 0.0526
DEBUG - 2022-07-04 07:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:29:25 --> Total execution time: 0.0957
DEBUG - 2022-07-04 07:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 07:59:57 --> No URI present. Default controller set.
DEBUG - 2022-07-04 07:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 07:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:29:57 --> Total execution time: 0.0794
DEBUG - 2022-07-04 08:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:01 --> Total execution time: 0.0597
DEBUG - 2022-07-04 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:02 --> Total execution time: 0.0716
DEBUG - 2022-07-04 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:09 --> Total execution time: 0.0600
DEBUG - 2022-07-04 08:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:14 --> Total execution time: 0.0736
DEBUG - 2022-07-04 08:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:22 --> Total execution time: 0.0621
DEBUG - 2022-07-04 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:35 --> Total execution time: 0.0655
DEBUG - 2022-07-04 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:41 --> Total execution time: 0.0767
DEBUG - 2022-07-04 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:30:43 --> Total execution time: 0.0840
DEBUG - 2022-07-04 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:31:01 --> Total execution time: 0.0604
DEBUG - 2022-07-04 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:31:16 --> Total execution time: 0.0557
DEBUG - 2022-07-04 08:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:31:30 --> Total execution time: 0.0594
DEBUG - 2022-07-04 08:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:03:39 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:33:39 --> Total execution time: 0.1997
DEBUG - 2022-07-04 08:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:03:44 --> Total execution time: 0.0517
DEBUG - 2022-07-04 08:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:03:46 --> Total execution time: 0.0546
DEBUG - 2022-07-04 08:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:03:46 --> Total execution time: 0.0993
DEBUG - 2022-07-04 08:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:34:30 --> Total execution time: 0.0544
DEBUG - 2022-07-04 08:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:04:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:34:52 --> Total execution time: 0.1627
DEBUG - 2022-07-04 08:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:04:54 --> Total execution time: 0.0561
DEBUG - 2022-07-04 08:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:04:56 --> Total execution time: 0.0508
DEBUG - 2022-07-04 08:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:04:56 --> Total execution time: 0.1052
DEBUG - 2022-07-04 08:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:05:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:35:38 --> Total execution time: 1.5608
DEBUG - 2022-07-04 08:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:05:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 08:05:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:36:11 --> Total execution time: 0.0563
DEBUG - 2022-07-04 08:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:06:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:36:14 --> Total execution time: 0.0536
DEBUG - 2022-07-04 08:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:37:46 --> Total execution time: 0.0495
DEBUG - 2022-07-04 08:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 08:08:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:40:35 --> Total execution time: 0.0485
DEBUG - 2022-07-04 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:40:42 --> Total execution time: 0.0484
DEBUG - 2022-07-04 08:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:40:53 --> Total execution time: 0.0552
DEBUG - 2022-07-04 08:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:40:58 --> Total execution time: 0.0455
DEBUG - 2022-07-04 08:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:41:01 --> Total execution time: 0.0447
DEBUG - 2022-07-04 08:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:41:19 --> Total execution time: 0.0677
DEBUG - 2022-07-04 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:41:30 --> Total execution time: 0.1272
DEBUG - 2022-07-04 08:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:41:31 --> Total execution time: 0.0531
DEBUG - 2022-07-04 08:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:45:12 --> Total execution time: 0.1743
DEBUG - 2022-07-04 08:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:45:20 --> Total execution time: 0.0597
DEBUG - 2022-07-04 08:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:15:39 --> Total execution time: 0.0528
DEBUG - 2022-07-04 08:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:45:41 --> Total execution time: 0.0420
DEBUG - 2022-07-04 08:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:47 --> Total execution time: 0.0598
DEBUG - 2022-07-04 08:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:15:47 --> Total execution time: 0.0822
DEBUG - 2022-07-04 08:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:45:54 --> Total execution time: 0.0506
DEBUG - 2022-07-04 08:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:46:09 --> Total execution time: 0.0788
DEBUG - 2022-07-04 08:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:46:26 --> Total execution time: 0.0609
DEBUG - 2022-07-04 08:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:46:38 --> Total execution time: 0.1054
DEBUG - 2022-07-04 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:46:50 --> Total execution time: 0.0840
DEBUG - 2022-07-04 08:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:47:13 --> Total execution time: 0.0561
DEBUG - 2022-07-04 08:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:48:30 --> Total execution time: 0.0542
DEBUG - 2022-07-04 08:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:49:29 --> Total execution time: 0.0583
DEBUG - 2022-07-04 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:50:06 --> Total execution time: 0.0565
DEBUG - 2022-07-04 08:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:50:15 --> Total execution time: 0.1381
DEBUG - 2022-07-04 08:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:51:00 --> Total execution time: 0.0464
DEBUG - 2022-07-04 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:51:04 --> Total execution time: 0.0612
DEBUG - 2022-07-04 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:51:07 --> Total execution time: 0.0423
DEBUG - 2022-07-04 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:51:08 --> Total execution time: 0.0534
DEBUG - 2022-07-04 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:51:36 --> Total execution time: 0.1364
DEBUG - 2022-07-04 08:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:56:54 --> Total execution time: 0.0618
DEBUG - 2022-07-04 08:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:56:59 --> Total execution time: 0.0509
DEBUG - 2022-07-04 08:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:57:05 --> Total execution time: 0.0581
DEBUG - 2022-07-04 08:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:57:13 --> Total execution time: 0.0583
DEBUG - 2022-07-04 08:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:57:40 --> Total execution time: 0.0548
DEBUG - 2022-07-04 08:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:01 --> Total execution time: 0.0409
DEBUG - 2022-07-04 08:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:10 --> Total execution time: 0.0374
DEBUG - 2022-07-04 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:23 --> Total execution time: 0.0475
DEBUG - 2022-07-04 08:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:37 --> Total execution time: 0.0576
DEBUG - 2022-07-04 08:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:45 --> Total execution time: 0.0702
DEBUG - 2022-07-04 08:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:58:47 --> Total execution time: 0.0844
DEBUG - 2022-07-04 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:59:55 --> Total execution time: 0.0633
DEBUG - 2022-07-04 08:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:00:21 --> Total execution time: 0.0567
DEBUG - 2022-07-04 08:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:00:23 --> Total execution time: 0.0668
DEBUG - 2022-07-04 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:01:36 --> Total execution time: 0.0484
DEBUG - 2022-07-04 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:31:38 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:01:38 --> Total execution time: 0.0347
DEBUG - 2022-07-04 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:31:39 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:01:39 --> Total execution time: 0.0525
DEBUG - 2022-07-04 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:31:39 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:01:39 --> Total execution time: 0.0339
DEBUG - 2022-07-04 08:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:01:50 --> Total execution time: 0.0470
DEBUG - 2022-07-04 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:02:04 --> Total execution time: 0.0612
DEBUG - 2022-07-04 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:02:09 --> Total execution time: 0.0469
DEBUG - 2022-07-04 08:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:02:14 --> Total execution time: 0.0600
DEBUG - 2022-07-04 08:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:02:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:02:15 --> Total execution time: 0.0418
DEBUG - 2022-07-04 08:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:32:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:02:42 --> Total execution time: 0.0356
DEBUG - 2022-07-04 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:03:13 --> Total execution time: 0.0566
DEBUG - 2022-07-04 08:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:04:08 --> Total execution time: 0.0378
DEBUG - 2022-07-04 08:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:06:22 --> Total execution time: 0.2180
DEBUG - 2022-07-04 08:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:06:33 --> Total execution time: 0.0521
DEBUG - 2022-07-04 08:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:07:46 --> Total execution time: 0.1502
DEBUG - 2022-07-04 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:08:26 --> Total execution time: 0.0721
DEBUG - 2022-07-04 08:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:08:37 --> Total execution time: 0.1231
DEBUG - 2022-07-04 08:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:09:09 --> Total execution time: 0.1368
DEBUG - 2022-07-04 08:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:09:10 --> Total execution time: 0.0545
DEBUG - 2022-07-04 08:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:09:12 --> Total execution time: 0.1252
DEBUG - 2022-07-04 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:09:19 --> Total execution time: 0.0643
DEBUG - 2022-07-04 08:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:09:25 --> Total execution time: 0.0512
DEBUG - 2022-07-04 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:09:29 --> Total execution time: 0.0901
DEBUG - 2022-07-04 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:40:41 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:10:41 --> Total execution time: 0.0482
DEBUG - 2022-07-04 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:40:41 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:10:41 --> Total execution time: 0.0536
DEBUG - 2022-07-04 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:10:45 --> Total execution time: 0.0421
DEBUG - 2022-07-04 08:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:11:02 --> Total execution time: 0.1303
DEBUG - 2022-07-04 08:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:11:05 --> Total execution time: 0.0526
DEBUG - 2022-07-04 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:11:10 --> Total execution time: 0.0676
DEBUG - 2022-07-04 08:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:11:13 --> Total execution time: 0.0503
DEBUG - 2022-07-04 08:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:11:17 --> Total execution time: 0.0774
DEBUG - 2022-07-04 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:41:30 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:11:30 --> Total execution time: 0.0491
DEBUG - 2022-07-04 08:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:11 --> Total execution time: 0.0358
DEBUG - 2022-07-04 08:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:27 --> Total execution time: 0.0792
DEBUG - 2022-07-04 08:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:42 --> Total execution time: 0.0429
DEBUG - 2022-07-04 08:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:43 --> Total execution time: 0.1433
DEBUG - 2022-07-04 08:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:46 --> Total execution time: 0.0515
DEBUG - 2022-07-04 08:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:46 --> Total execution time: 0.0556
DEBUG - 2022-07-04 08:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:49 --> Total execution time: 0.0466
DEBUG - 2022-07-04 08:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:50 --> Total execution time: 0.0425
DEBUG - 2022-07-04 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:12:51 --> Total execution time: 0.0551
DEBUG - 2022-07-04 08:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:43:17 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:13:17 --> Total execution time: 0.0643
DEBUG - 2022-07-04 08:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:13:37 --> Total execution time: 0.1445
DEBUG - 2022-07-04 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:43:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:13:55 --> Total execution time: 0.0618
DEBUG - 2022-07-04 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:13:58 --> Total execution time: 0.0494
DEBUG - 2022-07-04 08:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:14:04 --> Total execution time: 0.0598
DEBUG - 2022-07-04 08:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:14:07 --> Total execution time: 0.0570
DEBUG - 2022-07-04 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:14:18 --> Total execution time: 0.0612
DEBUG - 2022-07-04 08:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:14:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:14:19 --> Total execution time: 0.0770
DEBUG - 2022-07-04 08:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:14:57 --> Total execution time: 0.1367
DEBUG - 2022-07-04 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:15:27 --> Total execution time: 0.0569
DEBUG - 2022-07-04 08:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:45:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:15:31 --> Total execution time: 0.0508
DEBUG - 2022-07-04 08:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:15:37 --> Total execution time: 0.0581
DEBUG - 2022-07-04 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:16:15 --> Total execution time: 0.0490
DEBUG - 2022-07-04 08:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:16:30 --> Total execution time: 0.0510
DEBUG - 2022-07-04 08:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:16:37 --> Total execution time: 0.0565
DEBUG - 2022-07-04 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:16:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:16:38 --> Total execution time: 0.0474
DEBUG - 2022-07-04 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:47:34 --> Total execution time: 0.0490
DEBUG - 2022-07-04 08:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:47:35 --> Total execution time: 0.0591
DEBUG - 2022-07-04 08:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:47:35 --> Total execution time: 0.1087
DEBUG - 2022-07-04 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:37 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:17:37 --> Total execution time: 0.0352
DEBUG - 2022-07-04 08:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:17:41 --> Total execution time: 0.0540
DEBUG - 2022-07-04 08:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:17:50 --> Total execution time: 0.0559
DEBUG - 2022-07-04 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:17:54 --> Total execution time: 0.0505
DEBUG - 2022-07-04 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:17:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:17:55 --> Total execution time: 0.0652
DEBUG - 2022-07-04 08:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:18:02 --> Total execution time: 0.0563
DEBUG - 2022-07-04 08:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:18:05 --> Total execution time: 0.0656
DEBUG - 2022-07-04 08:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:18:18 --> Total execution time: 0.0481
DEBUG - 2022-07-04 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:48:23 --> Total execution time: 0.0524
DEBUG - 2022-07-04 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:48:24 --> Total execution time: 0.0541
DEBUG - 2022-07-04 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 08:48:24 --> Total execution time: 0.1133
DEBUG - 2022-07-04 08:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:18:34 --> Total execution time: 0.0561
DEBUG - 2022-07-04 08:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:19:30 --> Total execution time: 0.0499
DEBUG - 2022-07-04 08:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:19:36 --> Total execution time: 0.0519
DEBUG - 2022-07-04 08:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:19:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:19:38 --> Total execution time: 0.0519
DEBUG - 2022-07-04 08:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:18 --> Total execution time: 0.0638
DEBUG - 2022-07-04 08:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:22 --> Total execution time: 0.0511
DEBUG - 2022-07-04 08:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:24 --> Total execution time: 0.0484
DEBUG - 2022-07-04 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:27 --> Total execution time: 0.0483
DEBUG - 2022-07-04 08:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:29 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:29 --> Total execution time: 0.0578
DEBUG - 2022-07-04 08:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:31 --> Total execution time: 0.0494
DEBUG - 2022-07-04 08:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:34 --> Total execution time: 0.0541
DEBUG - 2022-07-04 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:38 --> Total execution time: 0.0479
DEBUG - 2022-07-04 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:46 --> Total execution time: 0.0505
DEBUG - 2022-07-04 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:58 --> Total execution time: 0.0744
DEBUG - 2022-07-04 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:58 --> Total execution time: 0.0518
DEBUG - 2022-07-04 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:20:59 --> Total execution time: 0.0555
DEBUG - 2022-07-04 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:21:04 --> Total execution time: 0.0793
DEBUG - 2022-07-04 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:21:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:21:05 --> Total execution time: 0.0470
DEBUG - 2022-07-04 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:52:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 08:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:22:00 --> Total execution time: 0.0951
DEBUG - 2022-07-04 08:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:22:13 --> Total execution time: 0.0537
DEBUG - 2022-07-04 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:22:17 --> Total execution time: 0.0599
DEBUG - 2022-07-04 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:24:44 --> Total execution time: 0.1290
DEBUG - 2022-07-04 08:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:24:57 --> Total execution time: 0.0488
DEBUG - 2022-07-04 08:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:25:07 --> Total execution time: 0.0634
DEBUG - 2022-07-04 08:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:25:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 08:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 08:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 08:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:25:08 --> Total execution time: 0.0460
DEBUG - 2022-07-04 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:30:03 --> Total execution time: 0.1998
DEBUG - 2022-07-04 09:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:32:46 --> Total execution time: 0.0847
DEBUG - 2022-07-04 09:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:03:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:33:13 --> Total execution time: 0.0583
DEBUG - 2022-07-04 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:03:53 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:33:54 --> Total execution time: 0.0391
DEBUG - 2022-07-04 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:33:59 --> Total execution time: 0.0668
DEBUG - 2022-07-04 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:34:06 --> Total execution time: 0.0796
DEBUG - 2022-07-04 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:34:16 --> Total execution time: 0.0962
DEBUG - 2022-07-04 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:35:26 --> Total execution time: 0.0514
DEBUG - 2022-07-04 09:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:35:34 --> Total execution time: 0.0538
DEBUG - 2022-07-04 09:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:38:19 --> Total execution time: 0.1022
DEBUG - 2022-07-04 09:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:09:56 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:39:57 --> Total execution time: 0.0648
DEBUG - 2022-07-04 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:47:23 --> Total execution time: 0.1133
DEBUG - 2022-07-04 09:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:47:26 --> Total execution time: 0.0598
DEBUG - 2022-07-04 09:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:18:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:48:18 --> Total execution time: 0.1290
DEBUG - 2022-07-04 09:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:49:13 --> Total execution time: 0.0494
DEBUG - 2022-07-04 09:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:49:30 --> Total execution time: 0.0684
DEBUG - 2022-07-04 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:49:44 --> Total execution time: 0.0865
DEBUG - 2022-07-04 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:48 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:49:48 --> Total execution time: 0.0373
DEBUG - 2022-07-04 09:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:50:14 --> Total execution time: 0.0391
DEBUG - 2022-07-04 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:50:15 --> Total execution time: 0.0536
DEBUG - 2022-07-04 09:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:50:23 --> Total execution time: 0.0524
DEBUG - 2022-07-04 09:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:50:29 --> Total execution time: 0.0626
DEBUG - 2022-07-04 09:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:50:37 --> Total execution time: 0.0852
DEBUG - 2022-07-04 09:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:51:08 --> Total execution time: 0.0675
DEBUG - 2022-07-04 09:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:51:38 --> Total execution time: 0.0730
DEBUG - 2022-07-04 09:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:24:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 09:24:11 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 09:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:25:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:55:31 --> Total execution time: 0.0901
DEBUG - 2022-07-04 09:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:55:41 --> Total execution time: 0.1311
DEBUG - 2022-07-04 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:25:51 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:55:51 --> Total execution time: 0.0387
DEBUG - 2022-07-04 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:10 --> Total execution time: 0.0465
DEBUG - 2022-07-04 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:50 --> Total execution time: 0.0603
DEBUG - 2022-07-04 09:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 09:26:53 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:07 --> Total execution time: 0.0640
DEBUG - 2022-07-04 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:29 --> Total execution time: 0.0597
DEBUG - 2022-07-04 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:47 --> Total execution time: 0.0661
DEBUG - 2022-07-04 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:48 --> Total execution time: 0.0740
DEBUG - 2022-07-04 09:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 09:29:04 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:00:03 --> Total execution time: 0.0522
DEBUG - 2022-07-04 09:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:00:27 --> Total execution time: 0.0602
DEBUG - 2022-07-04 09:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:00:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 09:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:00:29 --> Total execution time: 0.0475
DEBUG - 2022-07-04 09:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:01:17 --> Total execution time: 0.1812
DEBUG - 2022-07-04 09:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:01:21 --> Total execution time: 0.0431
DEBUG - 2022-07-04 09:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:01:40 --> Total execution time: 0.0414
DEBUG - 2022-07-04 09:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:01:54 --> Total execution time: 0.0488
DEBUG - 2022-07-04 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:02:01 --> Total execution time: 0.1044
DEBUG - 2022-07-04 09:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:02:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 09:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:02:02 --> Total execution time: 0.0803
DEBUG - 2022-07-04 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:02:51 --> Total execution time: 0.0689
DEBUG - 2022-07-04 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:32:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:02:59 --> Total execution time: 0.0502
DEBUG - 2022-07-04 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:03:17 --> Total execution time: 0.0319
DEBUG - 2022-07-04 09:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:03:30 --> Total execution time: 0.0503
DEBUG - 2022-07-04 09:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:13 --> Total execution time: 0.0345
DEBUG - 2022-07-04 09:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:24 --> Total execution time: 0.0523
DEBUG - 2022-07-04 09:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:33 --> Total execution time: 0.0556
DEBUG - 2022-07-04 09:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:40 --> Total execution time: 0.0606
DEBUG - 2022-07-04 09:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:44 --> Total execution time: 0.0627
DEBUG - 2022-07-04 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:54 --> Total execution time: 0.0507
DEBUG - 2022-07-04 09:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:05:57 --> Total execution time: 0.0770
DEBUG - 2022-07-04 09:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:14 --> Total execution time: 0.0594
DEBUG - 2022-07-04 09:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:29 --> Total execution time: 0.0471
DEBUG - 2022-07-04 09:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:32 --> Total execution time: 0.0610
DEBUG - 2022-07-04 09:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:38 --> Total execution time: 0.0561
DEBUG - 2022-07-04 09:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:37:43 --> Total execution time: 0.0493
DEBUG - 2022-07-04 09:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:46 --> Total execution time: 0.0669
DEBUG - 2022-07-04 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:49 --> Total execution time: 0.0549
DEBUG - 2022-07-04 09:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:07:56 --> Total execution time: 0.0503
DEBUG - 2022-07-04 09:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:08:03 --> Total execution time: 0.0696
DEBUG - 2022-07-04 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:08:12 --> Total execution time: 0.0822
DEBUG - 2022-07-04 09:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:08:33 --> Total execution time: 0.0733
DEBUG - 2022-07-04 09:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:08:47 --> Total execution time: 0.0524
DEBUG - 2022-07-04 09:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:08:52 --> Total execution time: 0.0699
DEBUG - 2022-07-04 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:04 --> Total execution time: 0.0920
DEBUG - 2022-07-04 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:04 --> Total execution time: 0.0745
DEBUG - 2022-07-04 09:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:06 --> Total execution time: 0.0373
DEBUG - 2022-07-04 09:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:06 --> Total execution time: 0.0430
DEBUG - 2022-07-04 09:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:07 --> Total execution time: 0.0352
DEBUG - 2022-07-04 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:12 --> Total execution time: 0.0588
DEBUG - 2022-07-04 09:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:15 --> Total execution time: 0.0912
DEBUG - 2022-07-04 20:09:15 --> Total execution time: 0.0969
DEBUG - 2022-07-04 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:19 --> Total execution time: 0.0536
DEBUG - 2022-07-04 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:23 --> Total execution time: 0.0658
DEBUG - 2022-07-04 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:30 --> Total execution time: 0.0964
DEBUG - 2022-07-04 09:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:09:53 --> Total execution time: 0.0834
DEBUG - 2022-07-04 09:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:10:02 --> Total execution time: 0.1050
DEBUG - 2022-07-04 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:10:51 --> Total execution time: 0.1520
DEBUG - 2022-07-04 09:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:38 --> Total execution time: 0.0791
DEBUG - 2022-07-04 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:43 --> Total execution time: 0.0524
DEBUG - 2022-07-04 09:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:44 --> Total execution time: 0.0397
DEBUG - 2022-07-04 09:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:46 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:46 --> Total execution time: 0.0344
DEBUG - 2022-07-04 09:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:50 --> Total execution time: 0.0643
DEBUG - 2022-07-04 09:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:54 --> Total execution time: 0.0570
DEBUG - 2022-07-04 09:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:54 --> Total execution time: 0.0329
DEBUG - 2022-07-04 09:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:11:58 --> Total execution time: 0.0574
DEBUG - 2022-07-04 09:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:12:01 --> Total execution time: 0.0613
DEBUG - 2022-07-04 09:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:12:02 --> Total execution time: 0.0704
DEBUG - 2022-07-04 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:12:10 --> Total execution time: 0.0705
DEBUG - 2022-07-04 09:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:12:11 --> Total execution time: 0.0684
DEBUG - 2022-07-04 09:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:12:51 --> Total execution time: 0.0528
DEBUG - 2022-07-04 09:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:13:10 --> Total execution time: 0.0885
DEBUG - 2022-07-04 09:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:13:17 --> Total execution time: 0.0744
DEBUG - 2022-07-04 09:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:43:37 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:13:37 --> Total execution time: 0.0455
DEBUG - 2022-07-04 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:13:40 --> Total execution time: 0.0423
DEBUG - 2022-07-04 09:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:13:53 --> Total execution time: 0.0501
DEBUG - 2022-07-04 09:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:44:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:14:12 --> Total execution time: 0.0358
DEBUG - 2022-07-04 09:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:14:33 --> Total execution time: 0.0485
DEBUG - 2022-07-04 09:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:15:56 --> Total execution time: 0.0516
DEBUG - 2022-07-04 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:16:20 --> Total execution time: 0.0527
DEBUG - 2022-07-04 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:16:41 --> Total execution time: 0.1018
DEBUG - 2022-07-04 09:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:47:48 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:17:48 --> Total execution time: 0.0342
DEBUG - 2022-07-04 09:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:17:50 --> Total execution time: 0.0515
DEBUG - 2022-07-04 09:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:51:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:21:47 --> Total execution time: 0.1173
DEBUG - 2022-07-04 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 09:53:29 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 09:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:53:30 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:23:30 --> Total execution time: 0.0386
DEBUG - 2022-07-04 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:23:40 --> Total execution time: 0.0395
DEBUG - 2022-07-04 09:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:23:51 --> Total execution time: 0.0586
DEBUG - 2022-07-04 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:23:54 --> Total execution time: 0.0748
DEBUG - 2022-07-04 09:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:24:05 --> Total execution time: 0.0515
DEBUG - 2022-07-04 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:09 --> Total execution time: 0.0548
DEBUG - 2022-07-04 09:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:12 --> Total execution time: 0.0472
DEBUG - 2022-07-04 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:16 --> Total execution time: 0.0506
DEBUG - 2022-07-04 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:19 --> Total execution time: 0.0642
DEBUG - 2022-07-04 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:21 --> Total execution time: 0.0485
DEBUG - 2022-07-04 09:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:54:23 --> Total execution time: 0.0571
DEBUG - 2022-07-04 09:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:54:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:24:45 --> Total execution time: 0.0523
DEBUG - 2022-07-04 09:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 09:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:25:06 --> Total execution time: 0.0524
DEBUG - 2022-07-04 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:25:13 --> Total execution time: 0.0494
DEBUG - 2022-07-04 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:25:27 --> Total execution time: 0.0428
DEBUG - 2022-07-04 09:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:25:35 --> Total execution time: 0.0692
DEBUG - 2022-07-04 09:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:25:40 --> Total execution time: 0.0528
DEBUG - 2022-07-04 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:25:45 --> Total execution time: 0.0543
DEBUG - 2022-07-04 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:30:02 --> Total execution time: 0.1806
DEBUG - 2022-07-04 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:01:05 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:31:05 --> Total execution time: 0.0936
DEBUG - 2022-07-04 10:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:31:11 --> Total execution time: 0.0958
DEBUG - 2022-07-04 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:01:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:31:59 --> Total execution time: 0.0823
DEBUG - 2022-07-04 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:31:59 --> Total execution time: 0.0389
DEBUG - 2022-07-04 10:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:00 --> Total execution time: 0.0727
DEBUG - 2022-07-04 10:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:00 --> Total execution time: 0.0563
DEBUG - 2022-07-04 10:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:00 --> Total execution time: 0.0470
DEBUG - 2022-07-04 10:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:01 --> Total execution time: 0.0489
DEBUG - 2022-07-04 10:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:01 --> Total execution time: 0.0920
DEBUG - 2022-07-04 10:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:04 --> Total execution time: 0.0454
DEBUG - 2022-07-04 10:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:04 --> Total execution time: 0.0269
DEBUG - 2022-07-04 10:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:02:05 --> Total execution time: 0.0458
DEBUG - 2022-07-04 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:10 --> Total execution time: 0.1290
DEBUG - 2022-07-04 10:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:32:43 --> Total execution time: 0.0963
DEBUG - 2022-07-04 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:33:31 --> Total execution time: 0.1297
DEBUG - 2022-07-04 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:33:37 --> Total execution time: 0.1696
DEBUG - 2022-07-04 10:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:33:44 --> Total execution time: 0.1401
DEBUG - 2022-07-04 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:33:49 --> Total execution time: 0.0763
DEBUG - 2022-07-04 10:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:34:02 --> Total execution time: 0.1435
DEBUG - 2022-07-04 10:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:34:18 --> Total execution time: 0.0891
DEBUG - 2022-07-04 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:34:21 --> Total execution time: 0.0544
DEBUG - 2022-07-04 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:34:24 --> Total execution time: 0.0605
DEBUG - 2022-07-04 10:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:35:06 --> Total execution time: 0.0537
DEBUG - 2022-07-04 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:35:13 --> Total execution time: 0.0526
DEBUG - 2022-07-04 10:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:35:26 --> Total execution time: 0.0884
DEBUG - 2022-07-04 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:35:31 --> Total execution time: 0.1214
DEBUG - 2022-07-04 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:05:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:35:49 --> Total execution time: 0.0368
DEBUG - 2022-07-04 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:06:13 --> Total execution time: 0.0340
DEBUG - 2022-07-04 10:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:06:35 --> Total execution time: 0.0641
DEBUG - 2022-07-04 10:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:06:36 --> Total execution time: 0.1203
DEBUG - 2022-07-04 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:08:03 --> Total execution time: 0.0518
DEBUG - 2022-07-04 10:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:39:24 --> Total execution time: 0.1234
DEBUG - 2022-07-04 10:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:39:32 --> Total execution time: 0.0468
DEBUG - 2022-07-04 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:39:46 --> Total execution time: 0.0590
DEBUG - 2022-07-04 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:39:53 --> Total execution time: 0.0598
DEBUG - 2022-07-04 10:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:39:56 --> Total execution time: 0.0539
DEBUG - 2022-07-04 10:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:39:58 --> Total execution time: 0.0600
DEBUG - 2022-07-04 10:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:40:01 --> Total execution time: 0.0602
DEBUG - 2022-07-04 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:40:05 --> Total execution time: 0.0600
DEBUG - 2022-07-04 10:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:41:47 --> Total execution time: 0.0535
DEBUG - 2022-07-04 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:41:51 --> Total execution time: 0.0539
DEBUG - 2022-07-04 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:41:53 --> Total execution time: 0.0576
DEBUG - 2022-07-04 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:41:58 --> Total execution time: 0.1242
DEBUG - 2022-07-04 10:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 10:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:10 --> Total execution time: 0.0749
DEBUG - 2022-07-04 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:18 --> Total execution time: 0.0938
DEBUG - 2022-07-04 10:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:22 --> Total execution time: 0.0895
DEBUG - 2022-07-04 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:25 --> Total execution time: 0.0800
DEBUG - 2022-07-04 10:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:26 --> Total execution time: 0.0527
DEBUG - 2022-07-04 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:29 --> Total execution time: 0.0645
DEBUG - 2022-07-04 10:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:32 --> Total execution time: 0.0501
DEBUG - 2022-07-04 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:33 --> Total execution time: 0.0556
DEBUG - 2022-07-04 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:42:46 --> Total execution time: 0.1131
DEBUG - 2022-07-04 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:44:32 --> Total execution time: 0.0505
DEBUG - 2022-07-04 10:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:16:34 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-04 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:20:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:50:33 --> Total execution time: 0.1115
DEBUG - 2022-07-04 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:20:41 --> Total execution time: 0.0648
DEBUG - 2022-07-04 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:20:42 --> Total execution time: 0.0532
DEBUG - 2022-07-04 10:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:20:42 --> Total execution time: 0.0759
DEBUG - 2022-07-04 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:39 --> Total execution time: 0.0504
DEBUG - 2022-07-04 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:40 --> Total execution time: 0.0644
DEBUG - 2022-07-04 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:40 --> Total execution time: 0.1314
DEBUG - 2022-07-04 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:58 --> Total execution time: 0.0516
DEBUG - 2022-07-04 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:58 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:51:58 --> Total execution time: 0.0615
DEBUG - 2022-07-04 10:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:59 --> Total execution time: 0.0650
DEBUG - 2022-07-04 10:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:21:59 --> Total execution time: 0.0898
DEBUG - 2022-07-04 10:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:07 --> Total execution time: 0.0473
DEBUG - 2022-07-04 10:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:08 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:08 --> Total execution time: 0.0332
DEBUG - 2022-07-04 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:25 --> Total execution time: 0.0343
DEBUG - 2022-07-04 10:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:34 --> Total execution time: 0.0761
DEBUG - 2022-07-04 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:40 --> Total execution time: 0.0671
DEBUG - 2022-07-04 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:44 --> Total execution time: 0.0757
DEBUG - 2022-07-04 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:52:55 --> Total execution time: 0.0555
DEBUG - 2022-07-04 10:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:24:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:54:47 --> Total execution time: 0.0386
DEBUG - 2022-07-04 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:24:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:54:49 --> Total execution time: 0.0385
DEBUG - 2022-07-04 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:24:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:54:49 --> Total execution time: 0.0477
DEBUG - 2022-07-04 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:54:51 --> Total execution time: 0.0491
DEBUG - 2022-07-04 10:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:55:01 --> Total execution time: 0.1059
DEBUG - 2022-07-04 10:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:55:09 --> Total execution time: 0.0592
DEBUG - 2022-07-04 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:55:20 --> Total execution time: 0.0493
DEBUG - 2022-07-04 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:55:47 --> Total execution time: 0.0479
DEBUG - 2022-07-04 10:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:55:54 --> Total execution time: 0.0654
DEBUG - 2022-07-04 10:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:56:00 --> Total execution time: 0.0760
DEBUG - 2022-07-04 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:29:30 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:59:31 --> Total execution time: 0.1710
DEBUG - 2022-07-04 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:00 --> Total execution time: 0.1235
DEBUG - 2022-07-04 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:05 --> Total execution time: 0.0395
DEBUG - 2022-07-04 10:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:16 --> Total execution time: 0.0546
DEBUG - 2022-07-04 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:19 --> Total execution time: 0.0908
DEBUG - 2022-07-04 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:28 --> Total execution time: 0.0843
DEBUG - 2022-07-04 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:30 --> Total execution time: 0.0531
DEBUG - 2022-07-04 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:47 --> Total execution time: 0.0431
DEBUG - 2022-07-04 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:30:53 --> Total execution time: 0.0506
DEBUG - 2022-07-04 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:30:55 --> Total execution time: 0.0556
DEBUG - 2022-07-04 10:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:30:55 --> Total execution time: 0.1082
DEBUG - 2022-07-04 10:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:04 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:04 --> Total execution time: 0.0572
DEBUG - 2022-07-04 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:15 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:15 --> Total execution time: 0.0680
DEBUG - 2022-07-04 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:23 --> Total execution time: 1.5406
DEBUG - 2022-07-04 10:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:31:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:55 --> Total execution time: 0.0509
DEBUG - 2022-07-04 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 21:01:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 21:01:56 --> Total execution time: 0.1821
DEBUG - 2022-07-04 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:59 --> Total execution time: 0.0563
DEBUG - 2022-07-04 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:02:04 --> Total execution time: 0.0798
DEBUG - 2022-07-04 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:02:07 --> Total execution time: 0.0511
DEBUG - 2022-07-04 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:02:09 --> Total execution time: 0.0500
DEBUG - 2022-07-04 10:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:04:00 --> Total execution time: 0.0360
DEBUG - 2022-07-04 10:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:04:30 --> Total execution time: 0.0440
DEBUG - 2022-07-04 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:05:34 --> Total execution time: 0.0486
DEBUG - 2022-07-04 10:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:06:24 --> Total execution time: 0.1552
DEBUG - 2022-07-04 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:06:45 --> Total execution time: 0.0636
DEBUG - 2022-07-04 10:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:06:48 --> Total execution time: 0.0577
DEBUG - 2022-07-04 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:06:56 --> Total execution time: 0.0580
DEBUG - 2022-07-04 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:07:03 --> Total execution time: 0.0540
DEBUG - 2022-07-04 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:07:45 --> Total execution time: 0.1366
DEBUG - 2022-07-04 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:07:56 --> Total execution time: 0.0500
DEBUG - 2022-07-04 10:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:07:59 --> Total execution time: 0.0525
DEBUG - 2022-07-04 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:08:13 --> Total execution time: 0.0766
DEBUG - 2022-07-04 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:08:23 --> Total execution time: 0.0487
DEBUG - 2022-07-04 10:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:08:29 --> Total execution time: 0.0481
DEBUG - 2022-07-04 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:08:32 --> Total execution time: 0.0654
DEBUG - 2022-07-04 10:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:08:37 --> Total execution time: 0.0496
DEBUG - 2022-07-04 10:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:08:57 --> Total execution time: 0.0526
DEBUG - 2022-07-04 10:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:09:27 --> Total execution time: 0.0463
DEBUG - 2022-07-04 10:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:37 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:09:37 --> Total execution time: 0.1350
DEBUG - 2022-07-04 10:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:09:49 --> Total execution time: 0.0504
DEBUG - 2022-07-04 10:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:09:49 --> Total execution time: 0.0466
DEBUG - 2022-07-04 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:10:00 --> Total execution time: 0.0461
DEBUG - 2022-07-04 10:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:40:10 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-04 10:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:40:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 10:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:10:12 --> Total execution time: 0.0469
DEBUG - 2022-07-04 10:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:40:27 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-04 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:40:31 --> 404 Page Not Found: Course-category/development
DEBUG - 2022-07-04 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:10:33 --> Total execution time: 0.0485
DEBUG - 2022-07-04 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:10:40 --> Total execution time: 0.0491
DEBUG - 2022-07-04 10:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:11:24 --> Total execution time: 0.0507
DEBUG - 2022-07-04 10:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:11:42 --> Total execution time: 0.0540
DEBUG - 2022-07-04 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:11:43 --> Total execution time: 0.0617
DEBUG - 2022-07-04 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:12:25 --> Total execution time: 0.0461
DEBUG - 2022-07-04 10:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:42:31 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 10:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:12:39 --> Total execution time: 0.0578
DEBUG - 2022-07-04 10:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:12:51 --> Total execution time: 0.0491
DEBUG - 2022-07-04 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:13:11 --> Total execution time: 0.0333
DEBUG - 2022-07-04 10:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:28 --> Total execution time: 0.0485
DEBUG - 2022-07-04 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:31 --> Total execution time: 0.0584
DEBUG - 2022-07-04 10:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:44:31 --> Total execution time: 0.1217
DEBUG - 2022-07-04 10:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:41 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-04 10:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:41 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-04 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:14:42 --> Total execution time: 0.1244
DEBUG - 2022-07-04 10:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Well-known/gpc.json
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Well-known/security.txt
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-07-04 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:44:50 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-07-04 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:09 --> Total execution time: 0.0435
DEBUG - 2022-07-04 10:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:15:12 --> Total execution time: 0.0448
DEBUG - 2022-07-04 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:13 --> Total execution time: 0.0464
DEBUG - 2022-07-04 10:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:13 --> Total execution time: 0.0902
DEBUG - 2022-07-04 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:45:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 10:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:32 --> Total execution time: 0.0486
DEBUG - 2022-07-04 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:33 --> Total execution time: 0.0825
DEBUG - 2022-07-04 10:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:45:33 --> Total execution time: 0.1177
DEBUG - 2022-07-04 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:15:42 --> Total execution time: 0.0348
DEBUG - 2022-07-04 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:20 --> Total execution time: 0.0491
DEBUG - 2022-07-04 10:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:42 --> Total execution time: 0.0481
DEBUG - 2022-07-04 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:20 --> Total execution time: 0.1264
DEBUG - 2022-07-04 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:23 --> Total execution time: 0.0448
DEBUG - 2022-07-04 10:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:26 --> Total execution time: 0.0462
DEBUG - 2022-07-04 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:38 --> Total execution time: 0.0575
DEBUG - 2022-07-04 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:57 --> Total execution time: 0.0541
DEBUG - 2022-07-04 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:48:40 --> Total execution time: 0.0346
DEBUG - 2022-07-04 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:47 --> Total execution time: 0.0611
DEBUG - 2022-07-04 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:51:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:21:26 --> Total execution time: 0.0535
DEBUG - 2022-07-04 10:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:21:29 --> Total execution time: 0.0626
DEBUG - 2022-07-04 10:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:22:03 --> Total execution time: 0.0567
DEBUG - 2022-07-04 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:52:21 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:22:21 --> Total execution time: 0.1513
DEBUG - 2022-07-04 10:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:22:24 --> Total execution time: 0.0521
DEBUG - 2022-07-04 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:23:09 --> Total execution time: 0.0474
DEBUG - 2022-07-04 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:53:27 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:53:27 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:23:27 --> Total execution time: 0.1010
DEBUG - 2022-07-04 10:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:23:27 --> Total execution time: 0.1205
DEBUG - 2022-07-04 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 10:56:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:56:03 --> No URI present. Default controller set.
DEBUG - 2022-07-04 10:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:26:03 --> Total execution time: 0.1114
DEBUG - 2022-07-04 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:27:13 --> Total execution time: 0.0524
DEBUG - 2022-07-04 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:27:26 --> Total execution time: 0.0519
DEBUG - 2022-07-04 10:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:17 --> Total execution time: 0.1321
DEBUG - 2022-07-04 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:22 --> Total execution time: 0.0636
DEBUG - 2022-07-04 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 10:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 10:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:30 --> Total execution time: 0.0572
DEBUG - 2022-07-04 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:30:02 --> Total execution time: 0.0598
DEBUG - 2022-07-04 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:00:03 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:30:03 --> Total execution time: 0.0397
DEBUG - 2022-07-04 11:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:00:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:30:48 --> Total execution time: 0.0367
DEBUG - 2022-07-04 11:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:30:57 --> Total execution time: 0.0318
DEBUG - 2022-07-04 11:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:01:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:31:23 --> Total execution time: 0.0407
DEBUG - 2022-07-04 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:31:33 --> Total execution time: 0.0650
DEBUG - 2022-07-04 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:31:55 --> Total execution time: 0.0518
DEBUG - 2022-07-04 11:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:31:58 --> Total execution time: 0.0913
DEBUG - 2022-07-04 11:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:14 --> Total execution time: 0.0538
DEBUG - 2022-07-04 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:34 --> Total execution time: 0.1579
DEBUG - 2022-07-04 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:25 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:25 --> Total execution time: 0.0462
DEBUG - 2022-07-04 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:03:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:03:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:03:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:26 --> Total execution time: 0.0289
DEBUG - 2022-07-04 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:26 --> Total execution time: 0.0467
DEBUG - 2022-07-04 11:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:26 --> Total execution time: 0.0319
DEBUG - 2022-07-04 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:27 --> Total execution time: 0.0454
DEBUG - 2022-07-04 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:27 --> Total execution time: 0.0827
DEBUG - 2022-07-04 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:27 --> Total execution time: 0.0511
DEBUG - 2022-07-04 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:27 --> Total execution time: 0.0460
DEBUG - 2022-07-04 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:27 --> Total execution time: 0.0429
DEBUG - 2022-07-04 11:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:31 --> Total execution time: 0.0494
DEBUG - 2022-07-04 11:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:40 --> Total execution time: 0.0497
DEBUG - 2022-07-04 11:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:50 --> Total execution time: 0.0706
DEBUG - 2022-07-04 11:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:50 --> Total execution time: 0.0436
DEBUG - 2022-07-04 11:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:01 --> Total execution time: 0.0504
DEBUG - 2022-07-04 11:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:35:11 --> Total execution time: 0.0503
DEBUG - 2022-07-04 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:05:21 --> Total execution time: 0.0638
DEBUG - 2022-07-04 11:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:05:23 --> Total execution time: 0.0463
DEBUG - 2022-07-04 11:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:35:25 --> Total execution time: 0.0475
DEBUG - 2022-07-04 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:35:29 --> Total execution time: 0.0442
DEBUG - 2022-07-04 11:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:35:34 --> Total execution time: 0.0431
DEBUG - 2022-07-04 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:35:48 --> Total execution time: 0.0318
DEBUG - 2022-07-04 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:35:52 --> Total execution time: 0.0683
DEBUG - 2022-07-04 11:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:36:04 --> Total execution time: 0.0893
DEBUG - 2022-07-04 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:06:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 11:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:00 --> Total execution time: 0.0626
DEBUG - 2022-07-04 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:08:18 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:41 --> Total execution time: 0.0522
DEBUG - 2022-07-04 11:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:08:57 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:39:08 --> Total execution time: 0.0612
DEBUG - 2022-07-04 11:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:39:31 --> Total execution time: 0.0545
DEBUG - 2022-07-04 11:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:39:49 --> Total execution time: 0.0541
DEBUG - 2022-07-04 11:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:39:52 --> Total execution time: 0.0534
DEBUG - 2022-07-04 11:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:39:59 --> Total execution time: 0.0690
DEBUG - 2022-07-04 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:03 --> Total execution time: 0.1003
DEBUG - 2022-07-04 11:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:10:17 --> Total execution time: 0.0642
DEBUG - 2022-07-04 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:20 --> Total execution time: 0.0704
DEBUG - 2022-07-04 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:10:23 --> Total execution time: 0.0742
DEBUG - 2022-07-04 11:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:29 --> Total execution time: 0.0621
DEBUG - 2022-07-04 11:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:51 --> Total execution time: 0.0550
DEBUG - 2022-07-04 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:52 --> Total execution time: 0.1711
DEBUG - 2022-07-04 11:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:40:57 --> Total execution time: 0.0630
DEBUG - 2022-07-04 11:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:11:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:17 --> Total execution time: 0.0742
DEBUG - 2022-07-04 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:32 --> Total execution time: 0.0534
DEBUG - 2022-07-04 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:11:33 --> Total execution time: 0.0546
DEBUG - 2022-07-04 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:36 --> Total execution time: 0.0559
DEBUG - 2022-07-04 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:11:40 --> Total execution time: 0.0795
DEBUG - 2022-07-04 11:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:43 --> Total execution time: 0.0522
DEBUG - 2022-07-04 11:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:51 --> Total execution time: 0.0543
DEBUG - 2022-07-04 11:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:53 --> Total execution time: 0.0561
DEBUG - 2022-07-04 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:01 --> Total execution time: 0.0563
DEBUG - 2022-07-04 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:06 --> Total execution time: 0.0659
DEBUG - 2022-07-04 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:37 --> Total execution time: 0.0687
DEBUG - 2022-07-04 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:40 --> Total execution time: 0.0523
DEBUG - 2022-07-04 11:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:51 --> Total execution time: 0.0589
DEBUG - 2022-07-04 11:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:52 --> Total execution time: 0.0562
DEBUG - 2022-07-04 11:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:42:55 --> Total execution time: 0.0508
DEBUG - 2022-07-04 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:43:00 --> Total execution time: 0.0506
DEBUG - 2022-07-04 11:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:43:07 --> Total execution time: 0.0464
DEBUG - 2022-07-04 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:18:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:48:34 --> Total execution time: 0.1195
DEBUG - 2022-07-04 11:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:51:03 --> Total execution time: 0.0822
DEBUG - 2022-07-04 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:51:38 --> Total execution time: 0.0555
DEBUG - 2022-07-04 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:52:06 --> Total execution time: 0.0588
DEBUG - 2022-07-04 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:52:27 --> Total execution time: 0.0604
DEBUG - 2022-07-04 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:52:43 --> Total execution time: 0.0480
DEBUG - 2022-07-04 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:55:56 --> Total execution time: 0.1104
DEBUG - 2022-07-04 11:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:25:57 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:55:57 --> Total execution time: 0.0378
DEBUG - 2022-07-04 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:56:22 --> Total execution time: 0.0559
DEBUG - 2022-07-04 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:56:32 --> Total execution time: 0.0577
DEBUG - 2022-07-04 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:56:58 --> Total execution time: 0.0563
DEBUG - 2022-07-04 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:27:15 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:57:15 --> Total execution time: 0.0575
DEBUG - 2022-07-04 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:57:54 --> Total execution time: 0.0470
DEBUG - 2022-07-04 11:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:57:55 --> Total execution time: 0.0542
DEBUG - 2022-07-04 11:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:57:59 --> Total execution time: 0.0503
DEBUG - 2022-07-04 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:58:05 --> Total execution time: 0.0741
DEBUG - 2022-07-04 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:58:05 --> Total execution time: 0.0726
DEBUG - 2022-07-04 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:58:16 --> Total execution time: 0.0539
DEBUG - 2022-07-04 11:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:58:32 --> Total execution time: 0.0523
DEBUG - 2022-07-04 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:58:46 --> Total execution time: 0.0536
DEBUG - 2022-07-04 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:02 --> Total execution time: 0.0729
DEBUG - 2022-07-04 11:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:10 --> Total execution time: 0.0535
DEBUG - 2022-07-04 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:23 --> Total execution time: 0.0743
DEBUG - 2022-07-04 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:27 --> Total execution time: 0.0730
DEBUG - 2022-07-04 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:32 --> Total execution time: 0.0660
DEBUG - 2022-07-04 11:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:41 --> Total execution time: 0.0533
DEBUG - 2022-07-04 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:57 --> Total execution time: 0.0322
DEBUG - 2022-07-04 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:59:58 --> Total execution time: 0.0552
DEBUG - 2022-07-04 11:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:01:31 --> Total execution time: 0.0504
DEBUG - 2022-07-04 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:01:36 --> Total execution time: 0.0480
DEBUG - 2022-07-04 11:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:32:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:02:49 --> Total execution time: 0.0468
DEBUG - 2022-07-04 11:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:32:57 --> 404 Page Not Found: Lp-profile/esalestrix.in
DEBUG - 2022-07-04 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:02:58 --> Total execution time: 0.0600
DEBUG - 2022-07-04 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:03:14 --> Total execution time: 0.0588
DEBUG - 2022-07-04 11:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:03:45 --> Total execution time: 0.0711
DEBUG - 2022-07-04 11:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:03:45 --> Total execution time: 0.1043
DEBUG - 2022-07-04 11:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:04:00 --> Total execution time: 0.0565
DEBUG - 2022-07-04 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:04:44 --> Total execution time: 0.0565
DEBUG - 2022-07-04 11:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:34:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 11:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:04:52 --> Total execution time: 0.0621
DEBUG - 2022-07-04 11:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:05:01 --> Total execution time: 0.0797
DEBUG - 2022-07-04 11:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:05:06 --> Total execution time: 0.0541
DEBUG - 2022-07-04 11:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:05:12 --> Total execution time: 0.0517
DEBUG - 2022-07-04 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:05:15 --> Total execution time: 0.0544
DEBUG - 2022-07-04 11:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:05:25 --> Total execution time: 0.0534
DEBUG - 2022-07-04 11:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:05:30 --> Total execution time: 0.0580
DEBUG - 2022-07-04 11:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:36:10 --> 404 Page Not Found: Environments/.aws
DEBUG - 2022-07-04 11:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:11:15 --> Total execution time: 0.2244
DEBUG - 2022-07-04 11:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:11:41 --> Total execution time: 0.0346
DEBUG - 2022-07-04 11:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:42:58 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:12:58 --> Total execution time: 0.0393
DEBUG - 2022-07-04 11:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:42:58 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:12:58 --> Total execution time: 0.0513
DEBUG - 2022-07-04 11:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:11 --> Total execution time: 0.0484
DEBUG - 2022-07-04 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:14 --> Total execution time: 0.0404
DEBUG - 2022-07-04 11:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:20 --> Total execution time: 0.0476
DEBUG - 2022-07-04 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:21 --> Total execution time: 0.0476
DEBUG - 2022-07-04 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:27 --> Total execution time: 0.0565
DEBUG - 2022-07-04 11:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:30 --> Total execution time: 0.0588
DEBUG - 2022-07-04 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:30 --> Total execution time: 0.0678
DEBUG - 2022-07-04 11:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:34 --> Total execution time: 0.0720
DEBUG - 2022-07-04 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:13:43 --> Total execution time: 0.0492
DEBUG - 2022-07-04 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:14:01 --> Total execution time: 0.0490
DEBUG - 2022-07-04 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:14:22 --> Total execution time: 0.0530
DEBUG - 2022-07-04 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 11:46:59 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:52:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:22:08 --> Total execution time: 0.0917
DEBUG - 2022-07-04 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:16 --> Total execution time: 0.1863
DEBUG - 2022-07-04 22:25:16 --> Total execution time: 0.0689
DEBUG - 2022-07-04 11:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:22 --> Total execution time: 0.0571
DEBUG - 2022-07-04 11:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:26:01 --> Total execution time: 0.0617
DEBUG - 2022-07-04 11:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:26:11 --> Total execution time: 0.0545
DEBUG - 2022-07-04 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:26:25 --> Total execution time: 0.0621
DEBUG - 2022-07-04 11:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:26:41 --> Total execution time: 0.0596
DEBUG - 2022-07-04 11:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:26:51 --> Total execution time: 0.0489
DEBUG - 2022-07-04 11:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 11:57:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 11:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 11:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:27:00 --> Total execution time: 0.0405
DEBUG - 2022-07-04 12:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:30:05 --> Total execution time: 0.3101
DEBUG - 2022-07-04 12:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:01:36 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-04 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:03:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:33:36 --> Total execution time: 0.0410
DEBUG - 2022-07-04 12:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:33:46 --> Total execution time: 0.0495
DEBUG - 2022-07-04 12:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:34:03 --> Total execution time: 0.0516
DEBUG - 2022-07-04 12:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:34:32 --> Total execution time: 0.0527
DEBUG - 2022-07-04 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:07:22 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:22 --> Total execution time: 0.0873
DEBUG - 2022-07-04 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:07:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:55 --> Total execution time: 0.0618
DEBUG - 2022-07-04 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:08:07 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:38:07 --> Total execution time: 0.0518
DEBUG - 2022-07-04 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:38:17 --> Total execution time: 0.0782
DEBUG - 2022-07-04 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:38:26 --> Total execution time: 0.0479
DEBUG - 2022-07-04 12:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:08:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:38:34 --> Total execution time: 0.0493
DEBUG - 2022-07-04 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:38:44 --> Total execution time: 0.1175
DEBUG - 2022-07-04 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:03 --> Total execution time: 0.0397
DEBUG - 2022-07-04 12:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:39:42 --> Total execution time: 0.0525
DEBUG - 2022-07-04 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:10:26 --> 404 Page Not Found: Wp-configphp/index
DEBUG - 2022-07-04 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:10:26 --> 404 Page Not Found: Wp-configtxt/index
DEBUG - 2022-07-04 12:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:40:28 --> Total execution time: 0.0480
DEBUG - 2022-07-04 12:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:10:36 --> Total execution time: 0.0497
DEBUG - 2022-07-04 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:10:40 --> Total execution time: 0.0535
DEBUG - 2022-07-04 12:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:10:40 --> Total execution time: 0.1051
DEBUG - 2022-07-04 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:40:47 --> Total execution time: 0.0636
DEBUG - 2022-07-04 12:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:40:51 --> Total execution time: 0.0522
DEBUG - 2022-07-04 12:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:41:55 --> Total execution time: 0.0564
DEBUG - 2022-07-04 12:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:12:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:42:10 --> Total execution time: 0.0523
DEBUG - 2022-07-04 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:42:58 --> Total execution time: 0.0500
DEBUG - 2022-07-04 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:43:44 --> Total execution time: 0.0520
DEBUG - 2022-07-04 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:14:19 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:44:19 --> Total execution time: 0.1223
DEBUG - 2022-07-04 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:15:01 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:02 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:03 --> Total execution time: 0.0495
DEBUG - 2022-07-04 12:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:07 --> Total execution time: 0.0321
DEBUG - 2022-07-04 12:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:10 --> Total execution time: 0.0330
DEBUG - 2022-07-04 12:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:11 --> Total execution time: 0.0317
DEBUG - 2022-07-04 12:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:11 --> Total execution time: 0.0510
DEBUG - 2022-07-04 12:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:18 --> Total execution time: 0.0568
DEBUG - 2022-07-04 12:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:27 --> Total execution time: 0.0787
DEBUG - 2022-07-04 12:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:29 --> Total execution time: 0.0328
DEBUG - 2022-07-04 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:33 --> Total execution time: 0.1634
DEBUG - 2022-07-04 12:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:35 --> Total execution time: 0.0323
DEBUG - 2022-07-04 12:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:15:59 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:59 --> Total execution time: 0.0465
DEBUG - 2022-07-04 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:16:16 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:46:16 --> Total execution time: 0.0541
DEBUG - 2022-07-04 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:16:58 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:46:58 --> Total execution time: 0.0534
DEBUG - 2022-07-04 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:16:58 --> Total execution time: 0.0549
DEBUG - 2022-07-04 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:16:58 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:46:58 --> Total execution time: 0.0497
DEBUG - 2022-07-04 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:17:11 --> Total execution time: 0.1028
DEBUG - 2022-07-04 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:17:11 --> Total execution time: 0.1678
DEBUG - 2022-07-04 12:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:18:19 --> Total execution time: 0.0515
DEBUG - 2022-07-04 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:18:35 --> Total execution time: 0.0551
DEBUG - 2022-07-04 12:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:18:35 --> Total execution time: 0.1023
DEBUG - 2022-07-04 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:49:32 --> Total execution time: 0.0516
DEBUG - 2022-07-04 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:50:12 --> Total execution time: 0.0497
DEBUG - 2022-07-04 12:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:21:00 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:51:00 --> Total execution time: 0.0458
DEBUG - 2022-07-04 12:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:23:41 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:53:41 --> Total execution time: 0.2188
DEBUG - 2022-07-04 12:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:23:56 --> Total execution time: 0.0515
DEBUG - 2022-07-04 12:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:24:17 --> Total execution time: 0.0519
DEBUG - 2022-07-04 12:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:24:17 --> Total execution time: 0.1291
DEBUG - 2022-07-04 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:24:47 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:55:14 --> Total execution time: 1.5683
DEBUG - 2022-07-04 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:25:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 12:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:55:29 --> Total execution time: 0.0353
DEBUG - 2022-07-04 12:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:55:51 --> Total execution time: 0.0612
DEBUG - 2022-07-04 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:55:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 12:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:55:53 --> Total execution time: 0.0604
DEBUG - 2022-07-04 12:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:25:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-07-04 22:55:55 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-07-04 22:55:55 --> Total execution time: 0.0869
DEBUG - 2022-07-04 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:07 --> Total execution time: 0.1392
DEBUG - 2022-07-04 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:13 --> Total execution time: 0.0569
DEBUG - 2022-07-04 12:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:20 --> Total execution time: 0.0901
DEBUG - 2022-07-04 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:26 --> Total execution time: 0.0593
DEBUG - 2022-07-04 12:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:28 --> Total execution time: 0.0949
DEBUG - 2022-07-04 12:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:32 --> Total execution time: 0.0537
DEBUG - 2022-07-04 12:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:38 --> Total execution time: 0.0792
DEBUG - 2022-07-04 12:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:57:23 --> Total execution time: 0.0527
DEBUG - 2022-07-04 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:57:33 --> Total execution time: 0.1143
DEBUG - 2022-07-04 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:57:33 --> Total execution time: 0.1767
DEBUG - 2022-07-04 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:57:33 --> Total execution time: 0.0675
DEBUG - 2022-07-04 12:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:57:54 --> Total execution time: 0.0808
DEBUG - 2022-07-04 12:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:28:13 --> Total execution time: 0.0535
DEBUG - 2022-07-04 12:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:17 --> Total execution time: 0.0531
DEBUG - 2022-07-04 12:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:28:18 --> Total execution time: 0.0742
DEBUG - 2022-07-04 12:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:30 --> Total execution time: 0.1080
DEBUG - 2022-07-04 12:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:44 --> Total execution time: 0.0480
DEBUG - 2022-07-04 12:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:45 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:45 --> Total execution time: 0.0605
DEBUG - 2022-07-04 12:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:46 --> Total execution time: 0.0787
DEBUG - 2022-07-04 12:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:53 --> Total execution time: 0.0326
DEBUG - 2022-07-04 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:58 --> Total execution time: 0.0503
DEBUG - 2022-07-04 12:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:03 --> Total execution time: 0.0745
DEBUG - 2022-07-04 12:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 12:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:11 --> Total execution time: 0.1418
DEBUG - 2022-07-04 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:16 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:16 --> Total execution time: 0.0341
DEBUG - 2022-07-04 12:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:29 --> Total execution time: 0.0646
DEBUG - 2022-07-04 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:47 --> Total execution time: 0.0970
DEBUG - 2022-07-04 12:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:29:56 --> Total execution time: 0.0620
DEBUG - 2022-07-04 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:29:59 --> Total execution time: 0.0766
DEBUG - 2022-07-04 12:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:29:59 --> Total execution time: 0.1321
DEBUG - 2022-07-04 12:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:15 --> Total execution time: 0.0986
DEBUG - 2022-07-04 12:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:30:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:21 --> Total execution time: 0.0412
DEBUG - 2022-07-04 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:30:49 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:49 --> Total execution time: 0.0360
DEBUG - 2022-07-04 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:01:58 --> Total execution time: 0.0543
DEBUG - 2022-07-04 12:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:03 --> Total execution time: 0.0546
DEBUG - 2022-07-04 12:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:12 --> Total execution time: 0.0734
DEBUG - 2022-07-04 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:17 --> Total execution time: 0.0590
DEBUG - 2022-07-04 12:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:28 --> Total execution time: 0.0532
DEBUG - 2022-07-04 12:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:40 --> Total execution time: 0.0540
DEBUG - 2022-07-04 12:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:48 --> Total execution time: 0.0570
DEBUG - 2022-07-04 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:50 --> Total execution time: 0.0505
DEBUG - 2022-07-04 12:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:51 --> Total execution time: 0.0533
DEBUG - 2022-07-04 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:52 --> Total execution time: 0.0511
DEBUG - 2022-07-04 12:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:53 --> Total execution time: 0.0537
DEBUG - 2022-07-04 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:55 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:55 --> Total execution time: 0.0481
DEBUG - 2022-07-04 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:58 --> Total execution time: 1.6600
DEBUG - 2022-07-04 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:33:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:33:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:18 --> Total execution time: 0.0518
DEBUG - 2022-07-04 12:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:10 --> Total execution time: 0.0527
DEBUG - 2022-07-04 12:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:11 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:11 --> Total execution time: 0.0337
DEBUG - 2022-07-04 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:28 --> Total execution time: 0.0538
DEBUG - 2022-07-04 12:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:36 --> Total execution time: 0.0599
DEBUG - 2022-07-04 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:37 --> Total execution time: 0.0626
DEBUG - 2022-07-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:57 --> Total execution time: 0.1181
DEBUG - 2022-07-04 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:06:08 --> Total execution time: 0.0544
DEBUG - 2022-07-04 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:06:10 --> Total execution time: 0.0492
DEBUG - 2022-07-04 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:06:10 --> Total execution time: 0.0477
DEBUG - 2022-07-04 12:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:06:38 --> Total execution time: 0.0641
DEBUG - 2022-07-04 12:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:07:10 --> Total execution time: 0.0471
DEBUG - 2022-07-04 12:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:07:20 --> Total execution time: 0.0513
DEBUG - 2022-07-04 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:07:29 --> Total execution time: 0.0643
DEBUG - 2022-07-04 12:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:38:32 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:08:32 --> Total execution time: 0.0506
DEBUG - 2022-07-04 12:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:10 --> Total execution time: 1.6249
DEBUG - 2022-07-04 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:39:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:29 --> Total execution time: 0.0639
DEBUG - 2022-07-04 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:34 --> Total execution time: 0.0581
DEBUG - 2022-07-04 12:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:36 --> Total execution time: 0.0556
DEBUG - 2022-07-04 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:38 --> Total execution time: 0.0551
DEBUG - 2022-07-04 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:38 --> Total execution time: 0.0525
DEBUG - 2022-07-04 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:39:56 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:09:56 --> Total execution time: 0.0486
DEBUG - 2022-07-04 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:17:10 --> Total execution time: 0.2450
DEBUG - 2022-07-04 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:17:34 --> Total execution time: 0.0531
DEBUG - 2022-07-04 12:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:47:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:47:43 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 12:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:50:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:15 --> Total execution time: 0.2048
DEBUG - 2022-07-04 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:52:28 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 12:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:40 --> Total execution time: 0.0980
DEBUG - 2022-07-04 12:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:46 --> Total execution time: 0.0502
DEBUG - 2022-07-04 12:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:54 --> Total execution time: 0.0704
DEBUG - 2022-07-04 12:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:23:22 --> Total execution time: 0.0659
DEBUG - 2022-07-04 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:23:32 --> Total execution time: 0.0989
DEBUG - 2022-07-04 12:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:23:49 --> Total execution time: 0.0759
DEBUG - 2022-07-04 12:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:23:53 --> Total execution time: 0.0682
DEBUG - 2022-07-04 12:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:24:01 --> Total execution time: 0.0850
DEBUG - 2022-07-04 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:54:09 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-04 12:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:54:56 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-04 12:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 12:56:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 12:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 12:57:29 --> No URI present. Default controller set.
DEBUG - 2022-07-04 12:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 12:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:27:29 --> Total execution time: 0.0800
DEBUG - 2022-07-04 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:30:02 --> Total execution time: 0.1276
DEBUG - 2022-07-04 13:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:02:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:32:32 --> Total execution time: 0.0953
DEBUG - 2022-07-04 13:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:32:33 --> Total execution time: 0.0427
DEBUG - 2022-07-04 13:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:32:34 --> Total execution time: 0.0636
DEBUG - 2022-07-04 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:02:43 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 13:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:38:16 --> Total execution time: 0.1982
DEBUG - 2022-07-04 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:38:30 --> Total execution time: 0.0750
DEBUG - 2022-07-04 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:38:37 --> Total execution time: 0.0702
DEBUG - 2022-07-04 13:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:38:47 --> Total execution time: 0.0948
DEBUG - 2022-07-04 13:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:09:20 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:39:20 --> Total execution time: 0.0647
DEBUG - 2022-07-04 13:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:09:29 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:39:30 --> Total execution time: 0.0608
DEBUG - 2022-07-04 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:39:38 --> Total execution time: 0.0970
DEBUG - 2022-07-04 13:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:09:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:39:50 --> Total execution time: 0.0727
DEBUG - 2022-07-04 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:10:10 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:10 --> Total execution time: 0.0455
DEBUG - 2022-07-04 13:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:16:18 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 13:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:02 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-04 13:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:03 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-07-04 13:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:04 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-07-04 13:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:04 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-07-04 13:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:05 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-04 13:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 13:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:05 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-07-04 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:06 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-07-04 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:06 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-07-04 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:07 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-04 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:20:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:28:54 --> 404 Page Not Found: Lessons/create-gigs
DEBUG - 2022-07-04 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:34:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:53:54 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-04 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:54:20 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-04 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:54:32 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-04 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:54:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 13:54:43 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-04 13:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:55:05 --> No URI present. Default controller set.
DEBUG - 2022-07-04 13:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 13:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 13:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 13:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:10:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 14:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:10:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 14:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:18:58 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-04 14:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:18:58 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-04 14:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:27:44 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 14:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:30:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 14:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:32:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:32:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 14:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:39:38 --> No URI present. Default controller set.
DEBUG - 2022-07-04 14:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:43:36 --> Total execution time: 0.0585
DEBUG - 2022-07-04 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:43:48 --> Total execution time: 0.1136
DEBUG - 2022-07-04 14:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:56:18 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:56:28 --> No URI present. Default controller set.
DEBUG - 2022-07-04 14:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:56:30 --> No URI present. Default controller set.
DEBUG - 2022-07-04 14:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 14:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 14:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 14:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 14:56:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 15:27:13 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 15:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:30:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 15:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:30:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 15:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 15:30:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 15:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:35:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 15:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:46:22 --> No URI present. Default controller set.
DEBUG - 2022-07-04 15:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:46:58 --> Total execution time: 0.0517
DEBUG - 2022-07-04 15:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 15:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 15:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 15:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:06:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 16:06:49 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 16:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 16:09:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 16:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 16:11:24 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 16:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:11:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 16:11:25 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 16:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:32:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 16:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 16:34:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 16:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:41:32 --> No URI present. Default controller set.
DEBUG - 2022-07-04 16:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 16:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 16:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 16:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:03:31 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:03:37 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:03:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 17:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:10:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:10:51 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 17:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:14:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:14:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:14:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 17:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:27:32 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:27:32 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:27:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 17:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:36:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:36:37 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:36:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 17:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:37:50 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 17:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:44:09 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:44:11 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:44:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:44:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 17:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:45:11 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:45:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 17:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 17:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 17:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:46:16 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:48:54 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 17:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 17:51:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 17:51:08 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:00:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 18:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:04:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 18:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 18:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 18:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:15:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:15:18 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 18:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:32:45 --> 404 Page Not Found: Assets/images
DEBUG - 2022-07-04 18:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:48:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 18:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:48:19 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-04 18:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:59:13 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-04 18:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:59:13 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-04 18:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:59:14 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-04 18:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 18:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 18:59:14 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-04 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:22:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:22:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:22:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 19:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:23:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 19:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:23:04 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:24:09 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:25:11 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 19:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:26:48 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:27:35 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 19:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:29:34 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 19:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:42:27 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:43:06 --> Total execution time: 0.4098
DEBUG - 2022-07-04 19:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:43:07 --> Total execution time: 0.0627
DEBUG - 2022-07-04 19:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:43:07 --> Total execution time: 0.1212
DEBUG - 2022-07-04 19:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:43:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 19:51:50 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:53:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 19:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 19:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 19:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 19:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:00:24 --> No URI present. Default controller set.
DEBUG - 2022-07-04 20:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:01:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 20:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 20:19:17 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 20:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 20:19:22 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-04 20:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 20:59:16 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 20:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 20:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 20:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 20:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:01:42 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 21:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:02:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:02:27 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-04 21:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:03:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:03:38 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 21:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:05:58 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 21:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:13:02 --> Total execution time: 0.0458
DEBUG - 2022-07-04 21:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:13:07 --> Total execution time: 0.0681
DEBUG - 2022-07-04 21:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:13:07 --> Total execution time: 0.1049
DEBUG - 2022-07-04 21:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:13:41 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:13:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:14:04 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:35 --> Total execution time: 0.0584
DEBUG - 2022-07-04 21:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:36 --> Total execution time: 0.0525
DEBUG - 2022-07-04 21:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:37 --> Total execution time: 0.0984
DEBUG - 2022-07-04 21:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:18:42 --> Total execution time: 0.0498
DEBUG - 2022-07-04 21:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:19:23 --> Total execution time: 0.0499
DEBUG - 2022-07-04 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:19:25 --> Total execution time: 0.0551
DEBUG - 2022-07-04 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:19:25 --> Total execution time: 0.0733
DEBUG - 2022-07-04 21:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:19:36 --> Total execution time: 0.0602
DEBUG - 2022-07-04 21:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:20:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 21:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:20:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 21:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:25:37 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 21:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:29:46 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:31:12 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:32:15 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:47 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:34:18 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:37:35 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:37:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:39:40 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:44:43 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:46:05 --> No URI present. Default controller set.
DEBUG - 2022-07-04 21:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:49:40 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 21:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 21:55:02 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 21:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 21:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 21:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 21:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:02:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:02:20 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-04 22:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:10:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:56 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:15:57 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:36 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:25:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:27:42 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:32:53 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-04 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:35:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:35:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-04 22:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:13 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:14 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:16 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-04 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:37:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-04 22:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:37:53 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:41:18 --> Total execution time: 0.1162
DEBUG - 2022-07-04 22:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:41:44 --> Total execution time: 0.0748
DEBUG - 2022-07-04 22:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:43:01 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:45:56 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:47:44 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:47:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:47:45 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-04 22:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:50:33 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:53:50 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:56:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 22:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:59:08 --> No URI present. Default controller set.
DEBUG - 2022-07-04 22:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 22:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 22:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 22:59:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 22:59:34 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-04 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:04 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:34 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:43 --> Total execution time: 0.0614
DEBUG - 2022-07-04 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:44 --> Total execution time: 0.0714
DEBUG - 2022-07-04 23:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:00:44 --> Total execution time: 0.1439
DEBUG - 2022-07-04 23:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-04 23:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 23:02:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-04 23:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:34 --> Total execution time: 0.0511
DEBUG - 2022-07-04 23:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-04 23:06:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-04 23:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:06:26 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:10:19 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:11:23 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:15:06 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:15:52 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:20:03 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:40:39 --> No URI present. Default controller set.
DEBUG - 2022-07-04 23:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:55 --> Total execution time: 0.0517
DEBUG - 2022-07-04 23:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:57 --> Total execution time: 0.0586
DEBUG - 2022-07-04 23:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:40:57 --> Total execution time: 0.0904
DEBUG - 2022-07-04 23:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-04 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-04 23:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-04 23:50:52 --> Encryption: Auto-configured driver 'openssl'.
