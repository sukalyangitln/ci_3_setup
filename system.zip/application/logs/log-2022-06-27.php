<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-27 00:01:37 --> Total execution time: 0.0337
DEBUG - 2022-06-27 00:02:06 --> Total execution time: 0.0354
DEBUG - 2022-06-27 00:03:04 --> Total execution time: 0.0325
DEBUG - 2022-06-27 00:03:41 --> Total execution time: 0.0688
DEBUG - 2022-06-27 00:03:59 --> Total execution time: 0.0426
DEBUG - 2022-06-27 00:04:04 --> Total execution time: 0.0479
DEBUG - 2022-06-27 00:04:06 --> Total execution time: 0.0700
DEBUG - 2022-06-27 00:04:10 --> Total execution time: 0.0476
DEBUG - 2022-06-27 00:04:11 --> Total execution time: 0.0377
DEBUG - 2022-06-27 00:04:15 --> Total execution time: 0.0535
DEBUG - 2022-06-27 00:04:17 --> Total execution time: 0.0744
DEBUG - 2022-06-27 00:04:25 --> Total execution time: 0.0644
DEBUG - 2022-06-27 00:04:47 --> Total execution time: 0.0437
DEBUG - 2022-06-27 00:04:52 --> Total execution time: 0.0528
DEBUG - 2022-06-27 00:05:29 --> Total execution time: 0.0503
DEBUG - 2022-06-27 00:05:34 --> Total execution time: 0.0521
DEBUG - 2022-06-27 00:10:25 --> Total execution time: 0.1142
DEBUG - 2022-06-27 00:10:54 --> Total execution time: 0.0322
DEBUG - 2022-06-27 00:10:54 --> Total execution time: 0.0268
DEBUG - 2022-06-27 00:11:47 --> Total execution time: 0.0458
DEBUG - 2022-06-27 00:14:22 --> Total execution time: 0.0909
DEBUG - 2022-06-27 00:15:46 --> Total execution time: 0.0362
DEBUG - 2022-06-27 00:17:33 --> Total execution time: 0.0453
DEBUG - 2022-06-27 00:18:12 --> Total execution time: 0.0402
DEBUG - 2022-06-27 00:18:14 --> Total execution time: 0.0452
DEBUG - 2022-06-27 00:19:06 --> Total execution time: 0.0473
DEBUG - 2022-06-27 00:23:30 --> Total execution time: 0.0882
DEBUG - 2022-06-27 00:24:55 --> Total execution time: 0.0661
DEBUG - 2022-06-27 00:25:21 --> Total execution time: 0.0502
DEBUG - 2022-06-27 00:27:14 --> Total execution time: 0.0363
DEBUG - 2022-06-27 00:27:37 --> Total execution time: 0.0554
DEBUG - 2022-06-27 00:27:53 --> Total execution time: 0.0452
DEBUG - 2022-06-27 00:28:03 --> Total execution time: 0.0462
DEBUG - 2022-06-27 00:28:14 --> Total execution time: 0.0674
DEBUG - 2022-06-27 00:28:31 --> Total execution time: 0.0548
DEBUG - 2022-06-27 00:28:41 --> Total execution time: 0.0690
DEBUG - 2022-06-27 00:29:10 --> Total execution time: 0.0487
DEBUG - 2022-06-27 00:29:52 --> Total execution time: 0.0360
DEBUG - 2022-06-27 00:29:57 --> Total execution time: 0.0754
DEBUG - 2022-06-27 00:30:02 --> Total execution time: 0.1995
DEBUG - 2022-06-27 00:30:02 --> Total execution time: 0.0970
DEBUG - 2022-06-27 00:30:06 --> Total execution time: 0.0878
DEBUG - 2022-06-27 00:30:06 --> Total execution time: 0.1147
DEBUG - 2022-06-27 00:30:24 --> Total execution time: 0.0536
DEBUG - 2022-06-27 00:30:36 --> Total execution time: 0.0506
DEBUG - 2022-06-27 00:30:36 --> Total execution time: 0.0439
DEBUG - 2022-06-27 00:30:40 --> Total execution time: 0.0502
DEBUG - 2022-06-27 00:30:41 --> Total execution time: 0.0546
DEBUG - 2022-06-27 00:30:48 --> Total execution time: 0.0381
DEBUG - 2022-06-27 00:32:18 --> Total execution time: 0.0408
DEBUG - 2022-06-27 00:32:33 --> Total execution time: 0.0498
DEBUG - 2022-06-27 00:32:54 --> Total execution time: 0.0396
DEBUG - 2022-06-27 00:35:06 --> Total execution time: 0.1254
DEBUG - 2022-06-27 00:35:32 --> Total execution time: 0.0588
DEBUG - 2022-06-27 00:35:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 00:35:33 --> Total execution time: 0.0469
DEBUG - 2022-06-27 00:37:48 --> Total execution time: 0.1189
DEBUG - 2022-06-27 00:37:49 --> Total execution time: 0.0664
DEBUG - 2022-06-27 00:38:14 --> Total execution time: 0.0492
DEBUG - 2022-06-27 00:38:32 --> Total execution time: 0.0768
DEBUG - 2022-06-27 00:39:26 --> Total execution time: 0.1271
DEBUG - 2022-06-27 00:39:47 --> Total execution time: 0.0673
DEBUG - 2022-06-27 00:39:50 --> Total execution time: 0.0484
DEBUG - 2022-06-27 00:43:37 --> Total execution time: 0.1666
DEBUG - 2022-06-27 00:44:09 --> Total execution time: 0.1359
DEBUG - 2022-06-27 00:44:18 --> Total execution time: 0.0580
DEBUG - 2022-06-27 00:44:22 --> Total execution time: 0.0510
DEBUG - 2022-06-27 00:44:44 --> Total execution time: 0.0508
DEBUG - 2022-06-27 00:44:50 --> Total execution time: 0.0442
DEBUG - 2022-06-27 00:45:02 --> Total execution time: 0.0576
DEBUG - 2022-06-27 00:45:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 00:45:03 --> Total execution time: 0.1024
DEBUG - 2022-06-27 00:45:38 --> Total execution time: 0.0467
DEBUG - 2022-06-27 00:45:39 --> Total execution time: 0.0880
DEBUG - 2022-06-27 00:45:46 --> Total execution time: 0.0455
DEBUG - 2022-06-27 00:45:50 --> Total execution time: 0.0533
DEBUG - 2022-06-27 00:46:00 --> Total execution time: 0.0579
DEBUG - 2022-06-27 00:46:22 --> Total execution time: 0.0923
DEBUG - 2022-06-27 00:46:45 --> Total execution time: 0.0472
DEBUG - 2022-06-27 00:47:25 --> Total execution time: 0.0341
DEBUG - 2022-06-27 01:12:04 --> Total execution time: 0.1352
DEBUG - 2022-06-27 01:16:36 --> Total execution time: 0.0472
DEBUG - 2022-06-27 01:16:41 --> Total execution time: 0.0466
DEBUG - 2022-06-27 01:16:43 --> Total execution time: 0.0407
DEBUG - 2022-06-27 01:16:43 --> Total execution time: 0.0439
DEBUG - 2022-06-27 01:16:55 --> Total execution time: 0.0397
DEBUG - 2022-06-27 01:17:06 --> Total execution time: 0.0345
DEBUG - 2022-06-27 01:22:31 --> Total execution time: 0.0503
DEBUG - 2022-06-27 01:24:06 --> Total execution time: 0.0455
DEBUG - 2022-06-27 01:25:19 --> Total execution time: 0.1070
DEBUG - 2022-06-27 01:25:23 --> Total execution time: 0.1121
DEBUG - 2022-06-27 01:25:40 --> Total execution time: 0.0674
DEBUG - 2022-06-27 01:26:22 --> Total execution time: 0.2232
DEBUG - 2022-06-27 01:26:40 --> Total execution time: 0.0462
DEBUG - 2022-06-27 01:27:04 --> Total execution time: 0.0345
DEBUG - 2022-06-27 01:27:46 --> Total execution time: 0.0618
DEBUG - 2022-06-27 01:27:57 --> Total execution time: 0.0516
DEBUG - 2022-06-27 01:28:02 --> Total execution time: 0.0715
DEBUG - 2022-06-27 01:28:13 --> Total execution time: 0.0768
DEBUG - 2022-06-27 01:28:24 --> Total execution time: 0.1341
DEBUG - 2022-06-27 01:28:35 --> Total execution time: 0.0503
DEBUG - 2022-06-27 01:28:57 --> Total execution time: 0.0832
DEBUG - 2022-06-27 01:29:26 --> Total execution time: 0.0531
DEBUG - 2022-06-27 01:29:27 --> Total execution time: 0.0671
DEBUG - 2022-06-27 01:30:02 --> Total execution time: 0.0522
DEBUG - 2022-06-27 01:31:50 --> Total execution time: 0.0473
DEBUG - 2022-06-27 01:32:24 --> Total execution time: 0.0461
DEBUG - 2022-06-27 01:38:55 --> Total execution time: 0.0764
DEBUG - 2022-06-27 01:42:57 --> Total execution time: 0.0548
DEBUG - 2022-06-27 01:43:13 --> Total execution time: 0.0769
DEBUG - 2022-06-27 01:43:18 --> Total execution time: 0.0714
DEBUG - 2022-06-27 01:47:47 --> Total execution time: 0.1155
DEBUG - 2022-06-27 01:47:52 --> Total execution time: 0.0709
DEBUG - 2022-06-27 01:48:20 --> Total execution time: 0.0625
DEBUG - 2022-06-27 01:51:13 --> Total execution time: 0.0993
DEBUG - 2022-06-27 01:55:20 --> Total execution time: 0.0978
DEBUG - 2022-06-27 01:59:57 --> Total execution time: 0.1073
DEBUG - 2022-06-27 02:05:26 --> Total execution time: 0.1042
DEBUG - 2022-06-27 02:14:11 --> Total execution time: 0.1253
DEBUG - 2022-06-27 02:16:11 --> Total execution time: 0.0480
DEBUG - 2022-06-27 02:19:44 --> Total execution time: 0.0967
DEBUG - 2022-06-27 02:23:08 --> Total execution time: 0.2650
DEBUG - 2022-06-27 02:23:22 --> Total execution time: 0.0997
DEBUG - 2022-06-27 02:23:24 --> Total execution time: 0.0610
DEBUG - 2022-06-27 02:23:25 --> Total execution time: 0.0482
DEBUG - 2022-06-27 02:23:26 --> Total execution time: 0.0415
DEBUG - 2022-06-27 02:23:27 --> Total execution time: 0.0426
DEBUG - 2022-06-27 02:30:02 --> Total execution time: 0.1285
DEBUG - 2022-06-27 02:32:18 --> Total execution time: 0.0617
DEBUG - 2022-06-27 02:39:26 --> Total execution time: 0.1389
DEBUG - 2022-06-27 02:45:25 --> Total execution time: 0.0640
DEBUG - 2022-06-27 02:45:29 --> Total execution time: 0.0353
DEBUG - 2022-06-27 02:45:44 --> Total execution time: 0.0582
DEBUG - 2022-06-27 02:45:50 --> Total execution time: 0.0562
DEBUG - 2022-06-27 02:45:52 --> Total execution time: 0.0678
DEBUG - 2022-06-27 02:49:54 --> Total execution time: 0.0563
DEBUG - 2022-06-27 02:50:00 --> Total execution time: 0.0418
DEBUG - 2022-06-27 02:50:04 --> Total execution time: 0.0630
DEBUG - 2022-06-27 02:50:07 --> Total execution time: 0.0554
DEBUG - 2022-06-27 02:51:38 --> Total execution time: 0.0541
DEBUG - 2022-06-27 02:52:23 --> Total execution time: 0.0444
DEBUG - 2022-06-27 02:53:46 --> Total execution time: 0.0538
DEBUG - 2022-06-27 02:54:57 --> Total execution time: 0.0484
DEBUG - 2022-06-27 02:56:30 --> Total execution time: 0.0593
DEBUG - 2022-06-27 02:58:55 --> Total execution time: 0.1723
DEBUG - 2022-06-27 02:59:14 --> Total execution time: 0.0493
DEBUG - 2022-06-27 02:59:37 --> Total execution time: 0.0464
DEBUG - 2022-06-27 03:06:17 --> Total execution time: 0.0983
DEBUG - 2022-06-27 03:08:10 --> Total execution time: 0.0517
DEBUG - 2022-06-27 03:11:50 --> Total execution time: 0.1198
DEBUG - 2022-06-27 03:18:02 --> Total execution time: 0.0846
DEBUG - 2022-06-27 03:22:20 --> Total execution time: 0.0904
DEBUG - 2022-06-27 03:22:20 --> Total execution time: 0.0326
DEBUG - 2022-06-27 03:22:52 --> Total execution time: 0.1093
DEBUG - 2022-06-27 03:23:00 --> Total execution time: 0.0324
DEBUG - 2022-06-27 03:30:04 --> Total execution time: 0.1996
DEBUG - 2022-06-27 03:38:55 --> Total execution time: 0.1910
DEBUG - 2022-06-27 03:39:09 --> Total execution time: 0.0442
DEBUG - 2022-06-27 03:42:43 --> Total execution time: 0.1729
DEBUG - 2022-06-27 03:42:58 --> Total execution time: 0.0552
DEBUG - 2022-06-27 03:43:03 --> Total execution time: 0.0746
DEBUG - 2022-06-27 03:43:08 --> Total execution time: 0.0560
DEBUG - 2022-06-27 03:43:14 --> Total execution time: 0.0458
DEBUG - 2022-06-27 03:53:26 --> Total execution time: 0.1315
DEBUG - 2022-06-27 04:10:20 --> Total execution time: 0.1394
DEBUG - 2022-06-27 04:10:45 --> Total execution time: 0.0330
DEBUG - 2022-06-27 04:12:11 --> Total execution time: 0.0781
DEBUG - 2022-06-27 04:12:29 --> Total execution time: 0.0477
DEBUG - 2022-06-27 04:12:35 --> Total execution time: 0.0670
DEBUG - 2022-06-27 04:12:40 --> Total execution time: 0.0643
DEBUG - 2022-06-27 04:12:50 --> Total execution time: 0.0573
DEBUG - 2022-06-27 04:12:53 --> Total execution time: 0.1037
DEBUG - 2022-06-27 04:12:55 --> Total execution time: 0.0611
DEBUG - 2022-06-27 04:26:09 --> Total execution time: 0.1786
DEBUG - 2022-06-27 04:30:03 --> Total execution time: 0.1674
DEBUG - 2022-06-27 04:32:47 --> Total execution time: 0.0493
DEBUG - 2022-06-27 05:30:04 --> Total execution time: 0.6960
DEBUG - 2022-06-27 05:33:17 --> Total execution time: 0.0691
DEBUG - 2022-06-27 05:37:45 --> Total execution time: 0.0867
DEBUG - 2022-06-27 05:37:46 --> Total execution time: 0.0441
DEBUG - 2022-06-27 05:49:54 --> Total execution time: 0.0496
DEBUG - 2022-06-27 05:49:58 --> Total execution time: 0.0444
DEBUG - 2022-06-27 05:50:16 --> Total execution time: 0.0733
DEBUG - 2022-06-27 05:50:23 --> Total execution time: 0.0851
DEBUG - 2022-06-27 05:50:37 --> Total execution time: 0.0650
DEBUG - 2022-06-27 05:50:43 --> Total execution time: 0.0609
DEBUG - 2022-06-27 05:51:24 --> Total execution time: 0.0446
DEBUG - 2022-06-27 05:56:01 --> Total execution time: 0.1331
DEBUG - 2022-06-27 05:56:28 --> Total execution time: 0.0533
DEBUG - 2022-06-27 05:56:34 --> Total execution time: 0.0709
DEBUG - 2022-06-27 05:57:58 --> Total execution time: 0.1200
DEBUG - 2022-06-27 05:58:35 --> Total execution time: 0.0564
DEBUG - 2022-06-27 06:07:50 --> Total execution time: 0.1133
DEBUG - 2022-06-27 06:17:18 --> Total execution time: 0.1188
DEBUG - 2022-06-27 06:17:34 --> Total execution time: 0.0411
DEBUG - 2022-06-27 06:22:59 --> Total execution time: 0.0508
DEBUG - 2022-06-27 06:27:29 --> Total execution time: 0.0864
DEBUG - 2022-06-27 06:27:47 --> Total execution time: 0.0645
DEBUG - 2022-06-27 06:27:53 --> Total execution time: 0.0879
DEBUG - 2022-06-27 06:27:58 --> Total execution time: 0.0706
DEBUG - 2022-06-27 06:28:07 --> Total execution time: 0.0989
DEBUG - 2022-06-27 06:28:15 --> Total execution time: 0.0488
DEBUG - 2022-06-27 06:28:18 --> Total execution time: 0.0697
DEBUG - 2022-06-27 06:28:24 --> Total execution time: 0.0482
DEBUG - 2022-06-27 06:28:43 --> Total execution time: 0.0430
DEBUG - 2022-06-27 06:29:10 --> Total execution time: 0.0843
DEBUG - 2022-06-27 06:29:16 --> Total execution time: 0.0491
DEBUG - 2022-06-27 06:29:16 --> Total execution time: 0.0809
DEBUG - 2022-06-27 06:29:20 --> Total execution time: 0.0644
DEBUG - 2022-06-27 06:29:22 --> Total execution time: 0.0700
DEBUG - 2022-06-27 06:29:28 --> Total execution time: 0.1209
DEBUG - 2022-06-27 06:29:34 --> Total execution time: 0.1150
DEBUG - 2022-06-27 06:30:02 --> Total execution time: 0.0493
DEBUG - 2022-06-27 06:30:02 --> Total execution time: 0.0858
DEBUG - 2022-06-27 06:30:27 --> Total execution time: 0.0481
DEBUG - 2022-06-27 06:30:31 --> Total execution time: 0.0634
DEBUG - 2022-06-27 06:30:39 --> Total execution time: 0.0666
DEBUG - 2022-06-27 06:31:35 --> Total execution time: 0.1378
DEBUG - 2022-06-27 06:31:40 --> Total execution time: 0.0452
DEBUG - 2022-06-27 06:31:53 --> Total execution time: 0.0503
DEBUG - 2022-06-27 06:31:57 --> Total execution time: 0.0468
DEBUG - 2022-06-27 06:31:57 --> Total execution time: 0.0588
DEBUG - 2022-06-27 06:32:03 --> Total execution time: 0.0570
DEBUG - 2022-06-27 06:32:05 --> Total execution time: 0.0568
DEBUG - 2022-06-27 06:32:09 --> Total execution time: 0.0533
DEBUG - 2022-06-27 06:32:45 --> Total execution time: 0.0502
DEBUG - 2022-06-27 06:32:49 --> Total execution time: 0.0542
DEBUG - 2022-06-27 06:32:50 --> Total execution time: 0.0307
DEBUG - 2022-06-27 06:32:52 --> Total execution time: 0.0502
DEBUG - 2022-06-27 06:32:55 --> Total execution time: 0.0401
DEBUG - 2022-06-27 06:33:05 --> Total execution time: 0.1249
DEBUG - 2022-06-27 06:33:15 --> Total execution time: 0.0398
DEBUG - 2022-06-27 06:33:42 --> Total execution time: 0.0387
DEBUG - 2022-06-27 06:33:52 --> Total execution time: 0.0432
DEBUG - 2022-06-27 06:33:55 --> Total execution time: 0.0425
DEBUG - 2022-06-27 06:33:55 --> Total execution time: 0.0474
DEBUG - 2022-06-27 06:33:59 --> Total execution time: 0.0631
DEBUG - 2022-06-27 06:34:03 --> Total execution time: 0.0559
DEBUG - 2022-06-27 06:34:04 --> Total execution time: 0.0607
DEBUG - 2022-06-27 06:34:05 --> Total execution time: 0.0446
DEBUG - 2022-06-27 06:34:07 --> Total execution time: 0.0492
DEBUG - 2022-06-27 06:34:09 --> Total execution time: 0.0517
DEBUG - 2022-06-27 06:34:16 --> Total execution time: 0.0542
DEBUG - 2022-06-27 06:34:17 --> Total execution time: 0.0439
DEBUG - 2022-06-27 06:34:20 --> Total execution time: 0.0496
DEBUG - 2022-06-27 06:34:33 --> Total execution time: 0.0533
DEBUG - 2022-06-27 06:34:38 --> Total execution time: 0.0456
DEBUG - 2022-06-27 06:34:42 --> Total execution time: 0.0580
DEBUG - 2022-06-27 06:34:42 --> Total execution time: 0.0470
DEBUG - 2022-06-27 06:36:12 --> Total execution time: 0.0911
DEBUG - 2022-06-27 06:36:48 --> Total execution time: 0.0578
DEBUG - 2022-06-27 06:43:49 --> Total execution time: 0.0862
DEBUG - 2022-06-27 06:44:56 --> Total execution time: 0.0487
DEBUG - 2022-06-27 06:46:51 --> Total execution time: 0.1160
DEBUG - 2022-06-27 06:48:48 --> Total execution time: 0.0531
DEBUG - 2022-06-27 06:53:29 --> Total execution time: 0.0957
DEBUG - 2022-06-27 06:53:32 --> Total execution time: 0.0319
DEBUG - 2022-06-27 06:53:35 --> Total execution time: 0.0320
DEBUG - 2022-06-27 06:53:36 --> Total execution time: 0.0311
DEBUG - 2022-06-27 06:53:37 --> Total execution time: 0.0425
DEBUG - 2022-06-27 06:53:44 --> Total execution time: 0.0533
DEBUG - 2022-06-27 06:54:04 --> Total execution time: 0.0620
DEBUG - 2022-06-27 06:54:06 --> Total execution time: 0.0309
DEBUG - 2022-06-27 06:54:18 --> Total execution time: 0.0754
DEBUG - 2022-06-27 06:54:20 --> Total execution time: 0.0317
DEBUG - 2022-06-27 06:54:27 --> Total execution time: 0.0482
DEBUG - 2022-06-27 06:54:48 --> Total execution time: 0.0370
DEBUG - 2022-06-27 06:54:55 --> Total execution time: 0.0334
DEBUG - 2022-06-27 06:55:44 --> Total execution time: 0.1589
DEBUG - 2022-06-27 06:55:47 --> Total execution time: 0.0747
DEBUG - 2022-06-27 06:55:49 --> Total execution time: 0.0695
DEBUG - 2022-06-27 06:55:52 --> Total execution time: 0.0384
DEBUG - 2022-06-27 06:55:55 --> Total execution time: 0.0405
DEBUG - 2022-06-27 06:55:59 --> Total execution time: 0.0460
DEBUG - 2022-06-27 06:56:11 --> Total execution time: 0.0371
DEBUG - 2022-06-27 06:56:15 --> Total execution time: 0.0489
DEBUG - 2022-06-27 06:56:22 --> Total execution time: 0.0886
DEBUG - 2022-06-27 06:56:34 --> Total execution time: 0.0559
DEBUG - 2022-06-27 06:56:36 --> Total execution time: 0.0673
DEBUG - 2022-06-27 06:56:42 --> Total execution time: 0.0585
DEBUG - 2022-06-27 06:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 06:57:03 --> Total execution time: 0.0595
DEBUG - 2022-06-27 06:57:06 --> Total execution time: 1.8971
DEBUG - 2022-06-27 06:57:06 --> Total execution time: 0.0619
DEBUG - 2022-06-27 06:57:09 --> Total execution time: 0.0833
DEBUG - 2022-06-27 06:57:21 --> Total execution time: 0.0479
DEBUG - 2022-06-27 06:58:04 --> Total execution time: 2.5100
DEBUG - 2022-06-27 06:58:05 --> Total execution time: 0.0662
DEBUG - 2022-06-27 06:58:10 --> Total execution time: 0.0451
DEBUG - 2022-06-27 06:58:27 --> Total execution time: 0.0448
DEBUG - 2022-06-27 06:58:34 --> Total execution time: 1.5100
DEBUG - 2022-06-27 06:58:39 --> Total execution time: 0.0561
DEBUG - 2022-06-27 06:58:44 --> Total execution time: 0.0535
DEBUG - 2022-06-27 06:58:45 --> Total execution time: 0.0651
DEBUG - 2022-06-27 06:58:54 --> Total execution time: 0.0576
DEBUG - 2022-06-27 06:58:57 --> Total execution time: 0.0720
DEBUG - 2022-06-27 06:58:58 --> Total execution time: 0.1105
DEBUG - 2022-06-27 06:59:04 --> Total execution time: 0.0362
DEBUG - 2022-06-27 06:59:10 --> Total execution time: 0.0542
DEBUG - 2022-06-27 06:59:22 --> Total execution time: 0.0493
DEBUG - 2022-06-27 06:59:30 --> Total execution time: 0.0780
DEBUG - 2022-06-27 06:59:32 --> Total execution time: 0.0488
DEBUG - 2022-06-27 06:59:34 --> Total execution time: 0.0471
DEBUG - 2022-06-27 06:59:37 --> Total execution time: 0.0518
DEBUG - 2022-06-27 06:59:40 --> Total execution time: 0.0646
DEBUG - 2022-06-27 06:59:40 --> Total execution time: 0.0495
DEBUG - 2022-06-27 06:59:43 --> Total execution time: 0.0466
DEBUG - 2022-06-27 06:59:53 --> Total execution time: 0.0571
DEBUG - 2022-06-27 06:59:55 --> Total execution time: 0.0515
DEBUG - 2022-06-27 06:59:58 --> Total execution time: 0.0645
DEBUG - 2022-06-27 06:59:59 --> Total execution time: 0.0445
DEBUG - 2022-06-27 07:00:02 --> Total execution time: 0.0858
DEBUG - 2022-06-27 07:00:30 --> Total execution time: 0.0516
DEBUG - 2022-06-27 07:00:53 --> Total execution time: 0.0728
DEBUG - 2022-06-27 07:00:56 --> Total execution time: 0.0331
DEBUG - 2022-06-27 07:01:48 --> Total execution time: 0.0492
DEBUG - 2022-06-27 07:02:02 --> Total execution time: 0.0600
DEBUG - 2022-06-27 07:02:05 --> Total execution time: 0.1140
DEBUG - 2022-06-27 07:02:06 --> Total execution time: 0.0514
DEBUG - 2022-06-27 07:02:27 --> Total execution time: 0.1421
DEBUG - 2022-06-27 07:02:50 --> Total execution time: 0.0481
DEBUG - 2022-06-27 07:02:56 --> Total execution time: 0.0446
DEBUG - 2022-06-27 07:03:11 --> Total execution time: 0.0526
DEBUG - 2022-06-27 07:03:21 --> Total execution time: 0.0670
DEBUG - 2022-06-27 07:03:24 --> Total execution time: 0.0308
DEBUG - 2022-06-27 07:03:48 --> Total execution time: 0.0554
DEBUG - 2022-06-27 07:03:50 --> Total execution time: 0.0344
DEBUG - 2022-06-27 07:03:59 --> Total execution time: 0.0517
DEBUG - 2022-06-27 07:04:04 --> Total execution time: 0.0703
DEBUG - 2022-06-27 07:04:19 --> Total execution time: 0.0726
DEBUG - 2022-06-27 07:04:33 --> Total execution time: 0.1414
DEBUG - 2022-06-27 07:04:45 --> Total execution time: 0.1079
DEBUG - 2022-06-27 07:04:46 --> Total execution time: 0.0345
DEBUG - 2022-06-27 07:04:47 --> Total execution time: 0.0599
DEBUG - 2022-06-27 07:04:48 --> Total execution time: 0.0358
DEBUG - 2022-06-27 07:04:48 --> Total execution time: 0.0369
DEBUG - 2022-06-27 07:05:07 --> Total execution time: 1.5276
DEBUG - 2022-06-27 07:05:16 --> Total execution time: 1.4389
DEBUG - 2022-06-27 07:05:17 --> Total execution time: 2.7439
DEBUG - 2022-06-27 07:05:19 --> Total execution time: 0.0308
DEBUG - 2022-06-27 07:06:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:06:16 --> Total execution time: 0.0499
DEBUG - 2022-06-27 07:06:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:06:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:06:18 --> Total execution time: 0.1851
DEBUG - 2022-06-27 07:06:24 --> Total execution time: 0.0537
DEBUG - 2022-06-27 07:06:24 --> Total execution time: 0.0667
DEBUG - 2022-06-27 07:07:22 --> Total execution time: 0.0504
DEBUG - 2022-06-27 07:07:29 --> Total execution time: 0.0491
DEBUG - 2022-06-27 07:08:18 --> Total execution time: 0.0463
DEBUG - 2022-06-27 07:08:22 --> Total execution time: 0.0507
DEBUG - 2022-06-27 07:08:22 --> Total execution time: 0.0340
DEBUG - 2022-06-27 07:10:09 --> Total execution time: 0.0359
DEBUG - 2022-06-27 07:10:48 --> Total execution time: 0.1111
DEBUG - 2022-06-27 07:10:58 --> Total execution time: 0.0481
DEBUG - 2022-06-27 07:11:03 --> Total execution time: 0.0455
DEBUG - 2022-06-27 07:11:05 --> Total execution time: 0.0659
DEBUG - 2022-06-27 07:11:08 --> Total execution time: 0.0439
DEBUG - 2022-06-27 07:11:17 --> Total execution time: 0.0548
DEBUG - 2022-06-27 07:11:39 --> Total execution time: 0.0630
DEBUG - 2022-06-27 07:11:47 --> Total execution time: 0.0783
DEBUG - 2022-06-27 07:11:56 --> Total execution time: 0.0487
DEBUG - 2022-06-27 07:12:04 --> Total execution time: 0.0851
DEBUG - 2022-06-27 07:14:04 --> Total execution time: 0.0716
DEBUG - 2022-06-27 07:18:28 --> Total execution time: 0.0349
DEBUG - 2022-06-27 07:18:28 --> Total execution time: 0.0444
DEBUG - 2022-06-27 07:18:29 --> Total execution time: 0.0340
DEBUG - 2022-06-27 07:18:45 --> Total execution time: 0.0442
DEBUG - 2022-06-27 07:19:03 --> Total execution time: 0.0372
DEBUG - 2022-06-27 07:19:23 --> Total execution time: 0.0434
DEBUG - 2022-06-27 07:19:39 --> Total execution time: 0.0528
DEBUG - 2022-06-27 07:20:09 --> Total execution time: 0.0514
DEBUG - 2022-06-27 07:20:25 --> Total execution time: 0.0461
DEBUG - 2022-06-27 07:20:28 --> Total execution time: 0.0555
DEBUG - 2022-06-27 07:20:28 --> Total execution time: 0.0454
DEBUG - 2022-06-27 07:20:46 --> Total execution time: 0.0496
DEBUG - 2022-06-27 07:20:50 --> Total execution time: 0.0492
DEBUG - 2022-06-27 07:21:00 --> Total execution time: 0.0483
DEBUG - 2022-06-27 07:21:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:21:01 --> Total execution time: 0.0534
DEBUG - 2022-06-27 07:21:12 --> Total execution time: 0.0708
DEBUG - 2022-06-27 07:21:15 --> Total execution time: 0.0324
DEBUG - 2022-06-27 07:21:17 --> Total execution time: 0.0321
DEBUG - 2022-06-27 07:21:23 --> Total execution time: 0.0487
DEBUG - 2022-06-27 07:21:23 --> Total execution time: 0.0540
DEBUG - 2022-06-27 07:21:30 --> Total execution time: 0.0958
DEBUG - 2022-06-27 07:21:32 --> Total execution time: 0.0818
DEBUG - 2022-06-27 07:21:35 --> Total execution time: 0.0738
DEBUG - 2022-06-27 07:21:40 --> Total execution time: 0.0494
DEBUG - 2022-06-27 07:21:48 --> Total execution time: 0.0441
DEBUG - 2022-06-27 07:21:56 --> Total execution time: 0.0481
DEBUG - 2022-06-27 07:21:58 --> Total execution time: 0.0482
DEBUG - 2022-06-27 07:22:13 --> Total execution time: 0.0512
DEBUG - 2022-06-27 07:22:27 --> Total execution time: 0.0644
DEBUG - 2022-06-27 07:22:28 --> Total execution time: 0.0542
DEBUG - 2022-06-27 07:22:31 --> Total execution time: 0.0608
DEBUG - 2022-06-27 07:22:38 --> Total execution time: 0.0593
DEBUG - 2022-06-27 07:25:24 --> Total execution time: 0.1073
DEBUG - 2022-06-27 07:26:29 --> Total execution time: 0.0456
DEBUG - 2022-06-27 07:27:01 --> Total execution time: 0.0464
DEBUG - 2022-06-27 07:27:08 --> Total execution time: 0.0453
DEBUG - 2022-06-27 07:27:24 --> Total execution time: 0.0508
DEBUG - 2022-06-27 07:27:52 --> Total execution time: 0.0468
DEBUG - 2022-06-27 07:28:20 --> Total execution time: 0.0441
DEBUG - 2022-06-27 07:28:44 --> Total execution time: 0.0473
DEBUG - 2022-06-27 07:28:58 --> Total execution time: 0.0437
DEBUG - 2022-06-27 07:29:15 --> Total execution time: 0.0441
DEBUG - 2022-06-27 07:30:03 --> Total execution time: 0.0560
DEBUG - 2022-06-27 07:30:59 --> Total execution time: 0.0471
DEBUG - 2022-06-27 07:31:03 --> Total execution time: 0.0569
DEBUG - 2022-06-27 07:31:14 --> Total execution time: 0.0455
DEBUG - 2022-06-27 07:31:21 --> Total execution time: 0.0665
DEBUG - 2022-06-27 07:31:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:31:22 --> Total execution time: 0.0492
DEBUG - 2022-06-27 07:32:11 --> Total execution time: 0.0484
DEBUG - 2022-06-27 07:32:13 --> Total execution time: 0.0634
DEBUG - 2022-06-27 07:32:26 --> Total execution time: 0.0705
DEBUG - 2022-06-27 07:33:18 --> Total execution time: 0.0622
DEBUG - 2022-06-27 07:33:33 --> Total execution time: 0.0558
DEBUG - 2022-06-27 07:33:36 --> Total execution time: 0.1351
DEBUG - 2022-06-27 07:33:41 --> Total execution time: 0.0695
DEBUG - 2022-06-27 07:35:01 --> Total execution time: 0.0844
DEBUG - 2022-06-27 07:40:11 --> Total execution time: 0.0860
DEBUG - 2022-06-27 07:44:32 --> Total execution time: 1.9204
DEBUG - 2022-06-27 07:54:39 --> Total execution time: 0.0954
DEBUG - 2022-06-27 07:54:39 --> Total execution time: 0.0336
DEBUG - 2022-06-27 07:54:55 --> Total execution time: 0.0522
DEBUG - 2022-06-27 07:55:15 --> Total execution time: 0.0456
DEBUG - 2022-06-27 07:55:42 --> Total execution time: 0.0503
DEBUG - 2022-06-27 07:55:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:55:43 --> Total execution time: 0.0493
DEBUG - 2022-06-27 07:56:37 --> Total execution time: 0.0439
DEBUG - 2022-06-27 07:56:42 --> Total execution time: 0.0630
DEBUG - 2022-06-27 07:56:58 --> Total execution time: 0.0540
DEBUG - 2022-06-27 07:57:07 --> Total execution time: 0.0583
DEBUG - 2022-06-27 07:58:25 --> Total execution time: 0.0659
DEBUG - 2022-06-27 07:58:46 --> Total execution time: 0.0495
DEBUG - 2022-06-27 07:58:47 --> Total execution time: 0.0479
DEBUG - 2022-06-27 07:58:56 --> Total execution time: 0.0565
DEBUG - 2022-06-27 07:59:00 --> Total execution time: 0.0658
DEBUG - 2022-06-27 07:59:19 --> Total execution time: 0.0923
DEBUG - 2022-06-27 07:59:36 --> Total execution time: 0.0458
DEBUG - 2022-06-27 07:59:41 --> Total execution time: 0.0446
DEBUG - 2022-06-27 07:59:46 --> Total execution time: 0.0436
DEBUG - 2022-06-27 07:59:49 --> Total execution time: 0.0472
DEBUG - 2022-06-27 08:00:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 08:00:01 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-06-27 08:00:02 --> Total execution time: 0.1475
DEBUG - 2022-06-27 08:00:08 --> Total execution time: 0.0533
DEBUG - 2022-06-27 08:00:09 --> Total execution time: 0.0819
DEBUG - 2022-06-27 08:00:11 --> Total execution time: 0.0611
DEBUG - 2022-06-27 08:00:17 --> Total execution time: 0.0665
DEBUG - 2022-06-27 08:00:24 --> Total execution time: 0.0612
DEBUG - 2022-06-27 08:00:28 --> Total execution time: 0.0481
DEBUG - 2022-06-27 08:00:32 --> Total execution time: 0.0605
DEBUG - 2022-06-27 08:00:35 --> Total execution time: 0.0580
DEBUG - 2022-06-27 08:01:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 08:01:11 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-06-27 08:01:12 --> Total execution time: 0.0695
DEBUG - 2022-06-27 08:03:21 --> Total execution time: 0.0396
DEBUG - 2022-06-27 08:03:34 --> Total execution time: 0.0535
DEBUG - 2022-06-27 08:03:51 --> Total execution time: 0.0532
DEBUG - 2022-06-27 08:04:22 --> Total execution time: 0.0756
DEBUG - 2022-06-27 08:04:30 --> Total execution time: 0.0792
DEBUG - 2022-06-27 08:04:45 --> Total execution time: 0.0877
DEBUG - 2022-06-27 08:04:49 --> Total execution time: 0.0790
DEBUG - 2022-06-27 08:04:51 --> Total execution time: 0.0751
DEBUG - 2022-06-27 08:04:59 --> Total execution time: 0.0494
DEBUG - 2022-06-27 08:05:01 --> Total execution time: 0.0485
DEBUG - 2022-06-27 08:05:04 --> Total execution time: 0.0490
DEBUG - 2022-06-27 08:05:11 --> Total execution time: 0.0562
DEBUG - 2022-06-27 08:05:20 --> Total execution time: 0.0519
DEBUG - 2022-06-27 08:05:21 --> Total execution time: 0.0496
DEBUG - 2022-06-27 08:05:25 --> Total execution time: 0.0516
DEBUG - 2022-06-27 08:05:54 --> Total execution time: 0.0471
DEBUG - 2022-06-27 08:05:57 --> Total execution time: 0.0567
DEBUG - 2022-06-27 08:06:01 --> Total execution time: 0.1137
DEBUG - 2022-06-27 08:08:08 --> Total execution time: 0.1724
DEBUG - 2022-06-27 08:18:48 --> Total execution time: 0.0493
DEBUG - 2022-06-27 08:18:52 --> Total execution time: 0.1095
DEBUG - 2022-06-27 08:18:57 --> Total execution time: 0.0326
DEBUG - 2022-06-27 08:19:00 --> Total execution time: 0.0534
DEBUG - 2022-06-27 08:19:04 --> Total execution time: 0.0854
DEBUG - 2022-06-27 08:19:15 --> Total execution time: 0.0413
DEBUG - 2022-06-27 08:21:50 --> Total execution time: 0.0459
DEBUG - 2022-06-27 08:21:57 --> Total execution time: 0.0492
DEBUG - 2022-06-27 08:22:02 --> Total execution time: 0.0976
DEBUG - 2022-06-27 08:24:59 --> Total execution time: 0.1656
DEBUG - 2022-06-27 08:25:16 --> Total execution time: 1.9273
DEBUG - 2022-06-27 08:26:26 --> Total execution time: 0.0356
DEBUG - 2022-06-27 08:28:30 --> Total execution time: 0.0646
DEBUG - 2022-06-27 08:29:02 --> Total execution time: 0.1229
DEBUG - 2022-06-27 08:30:02 --> Total execution time: 0.0617
DEBUG - 2022-06-27 08:37:17 --> Total execution time: 0.0488
DEBUG - 2022-06-27 08:38:53 --> Total execution time: 0.0330
DEBUG - 2022-06-27 08:39:11 --> Total execution time: 0.0762
DEBUG - 2022-06-27 08:39:19 --> Total execution time: 0.1327
DEBUG - 2022-06-27 08:39:24 --> Total execution time: 0.0652
DEBUG - 2022-06-27 08:39:26 --> Total execution time: 0.0675
DEBUG - 2022-06-27 08:39:38 --> Total execution time: 0.0760
DEBUG - 2022-06-27 08:39:53 --> Total execution time: 0.1628
DEBUG - 2022-06-27 08:40:00 --> Total execution time: 0.0820
DEBUG - 2022-06-27 08:40:00 --> Total execution time: 0.0549
DEBUG - 2022-06-27 08:40:08 --> Total execution time: 0.0828
DEBUG - 2022-06-27 08:40:08 --> Total execution time: 0.0583
DEBUG - 2022-06-27 08:40:15 --> Total execution time: 0.0530
DEBUG - 2022-06-27 08:40:28 --> Total execution time: 0.0689
DEBUG - 2022-06-27 08:40:32 --> Total execution time: 0.0724
DEBUG - 2022-06-27 08:41:13 --> Total execution time: 0.0394
DEBUG - 2022-06-27 08:41:15 --> Total execution time: 0.0445
DEBUG - 2022-06-27 08:42:15 --> Total execution time: 0.1473
DEBUG - 2022-06-27 08:42:21 --> Total execution time: 0.0452
DEBUG - 2022-06-27 08:42:31 --> Total execution time: 0.0476
DEBUG - 2022-06-27 08:42:34 --> Total execution time: 0.0658
DEBUG - 2022-06-27 08:42:38 --> Total execution time: 0.0505
DEBUG - 2022-06-27 08:42:42 --> Total execution time: 0.0589
DEBUG - 2022-06-27 08:42:46 --> Total execution time: 0.0508
DEBUG - 2022-06-27 08:42:47 --> Total execution time: 0.0541
DEBUG - 2022-06-27 08:42:49 --> Total execution time: 0.0499
DEBUG - 2022-06-27 08:42:51 --> Total execution time: 0.0737
DEBUG - 2022-06-27 08:42:51 --> Total execution time: 0.0490
DEBUG - 2022-06-27 08:44:01 --> Total execution time: 0.1121
DEBUG - 2022-06-27 08:44:04 --> Total execution time: 0.0616
DEBUG - 2022-06-27 08:44:06 --> Total execution time: 0.0578
DEBUG - 2022-06-27 08:44:07 --> Total execution time: 0.0706
DEBUG - 2022-06-27 08:44:10 --> Total execution time: 0.0727
DEBUG - 2022-06-27 08:44:28 --> Total execution time: 0.0333
DEBUG - 2022-06-27 08:44:28 --> Total execution time: 0.0543
DEBUG - 2022-06-27 08:44:30 --> Total execution time: 0.0315
DEBUG - 2022-06-27 08:44:35 --> Total execution time: 0.0503
DEBUG - 2022-06-27 08:44:38 --> Total execution time: 0.0362
DEBUG - 2022-06-27 08:44:41 --> Total execution time: 0.0442
DEBUG - 2022-06-27 08:44:41 --> Total execution time: 0.0342
DEBUG - 2022-06-27 08:44:45 --> Total execution time: 0.0478
DEBUG - 2022-06-27 08:44:45 --> Total execution time: 0.0438
DEBUG - 2022-06-27 08:44:50 --> Total execution time: 0.0503
DEBUG - 2022-06-27 08:44:54 --> Total execution time: 0.0529
DEBUG - 2022-06-27 08:45:27 --> Total execution time: 0.0531
DEBUG - 2022-06-27 08:45:35 --> Total execution time: 0.0826
DEBUG - 2022-06-27 08:46:03 --> Total execution time: 0.0666
DEBUG - 2022-06-27 08:46:13 --> Total execution time: 0.0635
DEBUG - 2022-06-27 08:46:24 --> Total execution time: 0.0607
DEBUG - 2022-06-27 08:46:27 --> Total execution time: 0.0512
DEBUG - 2022-06-27 08:46:29 --> Total execution time: 0.0507
DEBUG - 2022-06-27 08:46:32 --> Total execution time: 0.0584
DEBUG - 2022-06-27 08:46:36 --> Total execution time: 0.0533
DEBUG - 2022-06-27 08:46:45 --> Total execution time: 0.0675
DEBUG - 2022-06-27 08:48:32 --> Total execution time: 0.1055
DEBUG - 2022-06-27 08:48:40 --> Total execution time: 0.1056
DEBUG - 2022-06-27 08:48:41 --> Total execution time: 0.0462
DEBUG - 2022-06-27 08:48:50 --> Total execution time: 0.0510
DEBUG - 2022-06-27 08:48:56 --> Total execution time: 0.0685
DEBUG - 2022-06-27 08:49:07 --> Total execution time: 0.0526
DEBUG - 2022-06-27 08:49:18 --> Total execution time: 0.0665
DEBUG - 2022-06-27 08:49:22 --> Total execution time: 0.0461
DEBUG - 2022-06-27 08:49:32 --> Total execution time: 0.0521
DEBUG - 2022-06-27 08:50:40 --> Total execution time: 0.0444
DEBUG - 2022-06-27 08:50:55 --> Total execution time: 0.1243
DEBUG - 2022-06-27 08:51:00 --> Total execution time: 0.0510
DEBUG - 2022-06-27 08:51:03 --> Total execution time: 0.0541
DEBUG - 2022-06-27 08:51:08 --> Total execution time: 0.0519
DEBUG - 2022-06-27 08:51:17 --> Total execution time: 0.0601
DEBUG - 2022-06-27 08:51:31 --> Total execution time: 0.0499
DEBUG - 2022-06-27 08:51:34 --> Total execution time: 0.0536
DEBUG - 2022-06-27 08:51:41 --> Total execution time: 0.0475
DEBUG - 2022-06-27 08:51:57 --> Total execution time: 0.0567
DEBUG - 2022-06-27 08:52:00 --> Total execution time: 0.0520
DEBUG - 2022-06-27 08:52:02 --> Total execution time: 0.0595
DEBUG - 2022-06-27 08:52:30 --> Total execution time: 0.0445
DEBUG - 2022-06-27 08:53:57 --> Total execution time: 1.9732
DEBUG - 2022-06-27 08:54:53 --> Total execution time: 0.0337
DEBUG - 2022-06-27 08:56:11 --> Total execution time: 0.0568
DEBUG - 2022-06-27 08:56:39 --> Total execution time: 0.0525
DEBUG - 2022-06-27 08:56:44 --> Total execution time: 0.0594
DEBUG - 2022-06-27 08:57:04 --> Total execution time: 0.0642
DEBUG - 2022-06-27 09:00:55 --> Total execution time: 0.0971
DEBUG - 2022-06-27 09:01:46 --> Total execution time: 0.0465
DEBUG - 2022-06-27 09:01:52 --> Total execution time: 0.0475
DEBUG - 2022-06-27 09:02:23 --> Total execution time: 0.1016
DEBUG - 2022-06-27 09:02:30 --> Total execution time: 0.0494
DEBUG - 2022-06-27 09:02:34 --> Total execution time: 0.0741
DEBUG - 2022-06-27 09:02:39 --> Total execution time: 0.0482
DEBUG - 2022-06-27 09:02:42 --> Total execution time: 0.0509
DEBUG - 2022-06-27 09:02:46 --> Total execution time: 0.0662
DEBUG - 2022-06-27 09:02:53 --> Total execution time: 0.0516
DEBUG - 2022-06-27 09:03:36 --> Total execution time: 0.1134
DEBUG - 2022-06-27 09:03:53 --> Total execution time: 1.4815
DEBUG - 2022-06-27 09:06:08 --> Total execution time: 0.0708
DEBUG - 2022-06-27 09:06:12 --> Total execution time: 0.0521
DEBUG - 2022-06-27 09:06:32 --> Total execution time: 0.0547
DEBUG - 2022-06-27 09:06:38 --> Total execution time: 0.0778
DEBUG - 2022-06-27 09:07:16 --> Total execution time: 0.1194
DEBUG - 2022-06-27 09:07:25 --> Total execution time: 0.0666
DEBUG - 2022-06-27 09:07:34 --> Total execution time: 0.1157
DEBUG - 2022-06-27 09:07:38 --> Total execution time: 0.0468
DEBUG - 2022-06-27 09:08:02 --> Total execution time: 0.0460
DEBUG - 2022-06-27 09:08:29 --> Total execution time: 1.4750
DEBUG - 2022-06-27 09:08:54 --> Total execution time: 0.0589
DEBUG - 2022-06-27 09:09:19 --> Total execution time: 1.5379
DEBUG - 2022-06-27 09:09:33 --> Total execution time: 0.0339
DEBUG - 2022-06-27 09:09:56 --> Total execution time: 0.0593
DEBUG - 2022-06-27 09:10:07 --> Total execution time: 0.0375
DEBUG - 2022-06-27 09:10:09 --> Total execution time: 0.0421
DEBUG - 2022-06-27 09:10:18 --> Total execution time: 0.0411
DEBUG - 2022-06-27 09:10:30 --> Total execution time: 0.0536
DEBUG - 2022-06-27 09:10:39 --> Total execution time: 0.0440
DEBUG - 2022-06-27 09:10:49 --> Total execution time: 0.0685
DEBUG - 2022-06-27 09:10:55 --> Total execution time: 0.0522
DEBUG - 2022-06-27 09:10:55 --> Total execution time: 0.0445
DEBUG - 2022-06-27 09:11:02 --> Total execution time: 0.0554
DEBUG - 2022-06-27 09:11:05 --> Total execution time: 0.0924
DEBUG - 2022-06-27 09:11:12 --> Total execution time: 0.0512
DEBUG - 2022-06-27 09:11:19 --> Total execution time: 0.0521
DEBUG - 2022-06-27 09:11:19 --> Total execution time: 0.0576
DEBUG - 2022-06-27 09:11:37 --> Total execution time: 0.0475
DEBUG - 2022-06-27 09:13:04 --> Total execution time: 0.1255
DEBUG - 2022-06-27 09:13:19 --> Total execution time: 1.9121
DEBUG - 2022-06-27 09:15:57 --> Total execution time: 0.1685
DEBUG - 2022-06-27 09:16:00 --> Total execution time: 0.0513
DEBUG - 2022-06-27 09:16:04 --> Total execution time: 0.0493
DEBUG - 2022-06-27 09:16:07 --> Total execution time: 0.0556
DEBUG - 2022-06-27 09:16:14 --> Total execution time: 0.0487
DEBUG - 2022-06-27 09:18:37 --> Total execution time: 0.0445
DEBUG - 2022-06-27 09:22:02 --> Total execution time: 0.1876
DEBUG - 2022-06-27 09:22:46 --> Total execution time: 0.0333
DEBUG - 2022-06-27 09:23:17 --> Total execution time: 0.1276
DEBUG - 2022-06-27 09:23:47 --> Total execution time: 0.1614
DEBUG - 2022-06-27 09:24:00 --> Total execution time: 0.0481
DEBUG - 2022-06-27 09:27:25 --> Total execution time: 0.0464
DEBUG - 2022-06-27 09:27:48 --> Total execution time: 0.0682
DEBUG - 2022-06-27 09:28:05 --> Total execution time: 0.0772
DEBUG - 2022-06-27 09:29:23 --> Total execution time: 0.0491
DEBUG - 2022-06-27 09:30:03 --> Total execution time: 0.1341
DEBUG - 2022-06-27 09:30:13 --> Total execution time: 0.0522
DEBUG - 2022-06-27 09:31:27 --> Total execution time: 0.0496
DEBUG - 2022-06-27 09:31:30 --> Total execution time: 0.1526
DEBUG - 2022-06-27 09:31:39 --> Total execution time: 0.0493
DEBUG - 2022-06-27 09:31:44 --> Total execution time: 0.0396
DEBUG - 2022-06-27 09:31:49 --> Total execution time: 1.8847
DEBUG - 2022-06-27 09:31:57 --> Total execution time: 0.0449
DEBUG - 2022-06-27 09:32:03 --> Total execution time: 0.0589
DEBUG - 2022-06-27 09:32:04 --> Total execution time: 0.0544
DEBUG - 2022-06-27 09:32:09 --> Total execution time: 0.0528
DEBUG - 2022-06-27 09:32:21 --> Total execution time: 0.0339
DEBUG - 2022-06-27 09:32:29 --> Total execution time: 0.0442
DEBUG - 2022-06-27 09:32:38 --> Total execution time: 0.0502
DEBUG - 2022-06-27 09:32:43 --> Total execution time: 0.0836
DEBUG - 2022-06-27 09:33:03 --> Total execution time: 0.0708
DEBUG - 2022-06-27 09:33:03 --> Total execution time: 0.0582
DEBUG - 2022-06-27 09:33:09 --> Total execution time: 0.0459
DEBUG - 2022-06-27 09:33:09 --> Total execution time: 0.0462
DEBUG - 2022-06-27 09:33:12 --> Total execution time: 0.0604
DEBUG - 2022-06-27 09:33:14 --> Total execution time: 0.0471
DEBUG - 2022-06-27 09:33:19 --> Total execution time: 0.0606
DEBUG - 2022-06-27 09:33:23 --> Total execution time: 0.0533
DEBUG - 2022-06-27 09:33:29 --> Total execution time: 0.0644
DEBUG - 2022-06-27 09:33:37 --> Total execution time: 0.0618
DEBUG - 2022-06-27 09:33:39 --> Total execution time: 0.0525
DEBUG - 2022-06-27 09:33:45 --> Total execution time: 0.0466
DEBUG - 2022-06-27 09:33:52 --> Total execution time: 0.0506
DEBUG - 2022-06-27 09:33:54 --> Total execution time: 0.0582
DEBUG - 2022-06-27 09:33:58 --> Total execution time: 0.0595
DEBUG - 2022-06-27 09:34:24 --> Total execution time: 0.0564
DEBUG - 2022-06-27 09:34:33 --> Total execution time: 0.0694
DEBUG - 2022-06-27 09:34:47 --> Total execution time: 0.0474
DEBUG - 2022-06-27 09:35:10 --> Total execution time: 0.0842
DEBUG - 2022-06-27 09:35:16 --> Total execution time: 0.1195
DEBUG - 2022-06-27 09:35:22 --> Total execution time: 0.1229
DEBUG - 2022-06-27 09:36:02 --> Total execution time: 0.0670
DEBUG - 2022-06-27 09:36:11 --> Total execution time: 0.0689
DEBUG - 2022-06-27 09:36:20 --> Total execution time: 0.0742
DEBUG - 2022-06-27 09:36:47 --> Total execution time: 0.0470
DEBUG - 2022-06-27 09:36:49 --> Total execution time: 0.0513
DEBUG - 2022-06-27 09:36:52 --> Total execution time: 0.0469
DEBUG - 2022-06-27 09:36:55 --> Total execution time: 0.0462
DEBUG - 2022-06-27 09:36:59 --> Total execution time: 0.0456
DEBUG - 2022-06-27 09:37:03 --> Total execution time: 0.0537
DEBUG - 2022-06-27 09:37:07 --> Total execution time: 0.0666
DEBUG - 2022-06-27 09:37:09 --> Total execution time: 0.0886
DEBUG - 2022-06-27 09:37:23 --> Total execution time: 0.1189
DEBUG - 2022-06-27 09:37:37 --> Total execution time: 0.0550
DEBUG - 2022-06-27 09:37:59 --> Total execution time: 0.0532
DEBUG - 2022-06-27 09:38:10 --> Total execution time: 0.0467
DEBUG - 2022-06-27 09:38:20 --> Total execution time: 0.1115
DEBUG - 2022-06-27 09:38:29 --> Total execution time: 0.0511
DEBUG - 2022-06-27 09:38:34 --> Total execution time: 0.0865
DEBUG - 2022-06-27 09:38:42 --> Total execution time: 0.0453
DEBUG - 2022-06-27 09:38:45 --> Total execution time: 0.0491
DEBUG - 2022-06-27 09:39:01 --> Total execution time: 0.0739
DEBUG - 2022-06-27 09:39:46 --> Total execution time: 0.0572
DEBUG - 2022-06-27 09:39:55 --> Total execution time: 0.0489
DEBUG - 2022-06-27 09:40:05 --> Total execution time: 0.0501
DEBUG - 2022-06-27 09:40:09 --> Total execution time: 0.0488
DEBUG - 2022-06-27 09:40:12 --> Total execution time: 0.0453
DEBUG - 2022-06-27 09:40:20 --> Total execution time: 0.0450
DEBUG - 2022-06-27 09:40:25 --> Total execution time: 0.1226
DEBUG - 2022-06-27 09:40:32 --> Total execution time: 0.0730
DEBUG - 2022-06-27 09:40:41 --> Total execution time: 0.0478
DEBUG - 2022-06-27 09:40:48 --> Total execution time: 0.0445
DEBUG - 2022-06-27 09:40:56 --> Total execution time: 0.0397
DEBUG - 2022-06-27 09:41:11 --> Total execution time: 0.0569
DEBUG - 2022-06-27 09:41:16 --> Total execution time: 0.0385
DEBUG - 2022-06-27 09:41:52 --> Total execution time: 0.0448
DEBUG - 2022-06-27 09:42:08 --> Total execution time: 0.0465
DEBUG - 2022-06-27 09:42:18 --> Total execution time: 0.0503
DEBUG - 2022-06-27 09:42:23 --> Total execution time: 0.0443
DEBUG - 2022-06-27 09:42:29 --> Total execution time: 0.1110
DEBUG - 2022-06-27 09:42:46 --> Total execution time: 0.0505
DEBUG - 2022-06-27 09:42:52 --> Total execution time: 0.0567
DEBUG - 2022-06-27 09:43:11 --> Total execution time: 1.5252
DEBUG - 2022-06-27 09:44:03 --> Total execution time: 0.0474
DEBUG - 2022-06-27 09:44:21 --> Total execution time: 0.0612
DEBUG - 2022-06-27 09:44:26 --> Total execution time: 0.0720
DEBUG - 2022-06-27 09:45:10 --> Total execution time: 0.0603
DEBUG - 2022-06-27 09:45:26 --> Total execution time: 0.0741
DEBUG - 2022-06-27 09:45:35 --> Total execution time: 0.0754
DEBUG - 2022-06-27 09:45:38 --> Total execution time: 0.1113
DEBUG - 2022-06-27 09:45:44 --> Total execution time: 0.0552
DEBUG - 2022-06-27 09:45:57 --> Total execution time: 1.4370
DEBUG - 2022-06-27 09:46:00 --> Total execution time: 0.0435
DEBUG - 2022-06-27 09:46:11 --> Total execution time: 0.0498
DEBUG - 2022-06-27 09:46:27 --> Total execution time: 0.0706
DEBUG - 2022-06-27 09:46:33 --> Total execution time: 0.0578
DEBUG - 2022-06-27 09:46:50 --> Total execution time: 0.0465
DEBUG - 2022-06-27 09:47:48 --> Total execution time: 0.0448
DEBUG - 2022-06-27 09:47:58 --> Total execution time: 0.0479
DEBUG - 2022-06-27 09:48:07 --> Total execution time: 0.0706
DEBUG - 2022-06-27 09:48:10 --> Total execution time: 0.0533
DEBUG - 2022-06-27 09:48:13 --> Total execution time: 0.0487
DEBUG - 2022-06-27 09:48:13 --> Total execution time: 0.0465
DEBUG - 2022-06-27 09:48:22 --> Total execution time: 0.0470
DEBUG - 2022-06-27 09:48:23 --> Total execution time: 0.0480
DEBUG - 2022-06-27 09:48:35 --> Total execution time: 0.0503
DEBUG - 2022-06-27 09:48:37 --> Total execution time: 0.0461
DEBUG - 2022-06-27 09:50:13 --> Total execution time: 0.1179
DEBUG - 2022-06-27 09:50:14 --> Total execution time: 0.0483
DEBUG - 2022-06-27 09:50:19 --> Total execution time: 0.0483
DEBUG - 2022-06-27 09:50:20 --> Total execution time: 0.0445
DEBUG - 2022-06-27 09:50:26 --> Total execution time: 0.0461
DEBUG - 2022-06-27 09:50:39 --> Total execution time: 0.0448
DEBUG - 2022-06-27 09:50:48 --> Total execution time: 0.0447
DEBUG - 2022-06-27 09:51:00 --> Total execution time: 0.0731
DEBUG - 2022-06-27 09:51:13 --> Total execution time: 0.0718
DEBUG - 2022-06-27 09:51:45 --> Total execution time: 0.0613
DEBUG - 2022-06-27 09:51:50 --> Total execution time: 0.0626
DEBUG - 2022-06-27 09:52:22 --> Total execution time: 0.0779
DEBUG - 2022-06-27 09:52:26 --> Total execution time: 0.0561
DEBUG - 2022-06-27 09:52:28 --> Total execution time: 0.0506
DEBUG - 2022-06-27 09:52:32 --> Total execution time: 0.0653
DEBUG - 2022-06-27 09:52:52 --> Total execution time: 0.1350
DEBUG - 2022-06-27 09:53:20 --> Total execution time: 0.1120
DEBUG - 2022-06-27 09:53:44 --> Total execution time: 0.0692
DEBUG - 2022-06-27 09:55:23 --> Total execution time: 0.0524
DEBUG - 2022-06-27 09:55:32 --> Total execution time: 0.0989
DEBUG - 2022-06-27 09:56:20 --> Total execution time: 0.0487
DEBUG - 2022-06-27 09:56:29 --> Total execution time: 0.0612
DEBUG - 2022-06-27 09:56:56 --> Total execution time: 0.0704
DEBUG - 2022-06-27 09:57:05 --> Total execution time: 0.0726
DEBUG - 2022-06-27 09:57:14 --> Total execution time: 0.0459
DEBUG - 2022-06-27 09:57:42 --> Total execution time: 0.0406
DEBUG - 2022-06-27 09:57:54 --> Total execution time: 0.0487
DEBUG - 2022-06-27 09:58:03 --> Total execution time: 0.0336
DEBUG - 2022-06-27 09:58:09 --> Total execution time: 0.0577
DEBUG - 2022-06-27 09:58:13 --> Total execution time: 0.0802
DEBUG - 2022-06-27 09:58:46 --> Total execution time: 0.1484
DEBUG - 2022-06-27 09:59:01 --> Total execution time: 0.0534
DEBUG - 2022-06-27 09:59:20 --> Total execution time: 0.0582
DEBUG - 2022-06-27 09:59:35 --> Total execution time: 0.0378
DEBUG - 2022-06-27 09:59:36 --> Total execution time: 0.0373
DEBUG - 2022-06-27 10:02:24 --> Total execution time: 0.1052
DEBUG - 2022-06-27 10:03:16 --> Total execution time: 0.0378
DEBUG - 2022-06-27 10:03:35 --> Total execution time: 0.0462
DEBUG - 2022-06-27 10:03:46 --> Total execution time: 0.0476
DEBUG - 2022-06-27 10:03:57 --> Total execution time: 0.0478
DEBUG - 2022-06-27 10:04:04 --> Total execution time: 0.0550
DEBUG - 2022-06-27 10:04:12 --> Total execution time: 0.0531
DEBUG - 2022-06-27 10:04:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 10:04:13 --> Total execution time: 0.0562
DEBUG - 2022-06-27 10:04:39 --> Total execution time: 0.1116
DEBUG - 2022-06-27 10:04:40 --> Total execution time: 0.0318
DEBUG - 2022-06-27 10:04:49 --> Total execution time: 0.0551
DEBUG - 2022-06-27 10:04:54 --> Total execution time: 0.0552
DEBUG - 2022-06-27 10:05:00 --> Total execution time: 0.0498
DEBUG - 2022-06-27 10:05:00 --> Total execution time: 0.0414
DEBUG - 2022-06-27 10:05:18 --> Total execution time: 0.0595
DEBUG - 2022-06-27 10:05:23 --> Total execution time: 0.0479
DEBUG - 2022-06-27 10:05:23 --> Total execution time: 0.0563
DEBUG - 2022-06-27 10:05:26 --> Total execution time: 0.0461
DEBUG - 2022-06-27 10:05:31 --> Total execution time: 0.0540
DEBUG - 2022-06-27 10:05:45 --> Total execution time: 0.0472
DEBUG - 2022-06-27 10:05:46 --> Total execution time: 0.0349
DEBUG - 2022-06-27 10:05:47 --> Total execution time: 0.0556
DEBUG - 2022-06-27 10:06:29 --> Total execution time: 0.0549
DEBUG - 2022-06-27 10:06:42 --> Total execution time: 0.0777
DEBUG - 2022-06-27 10:06:49 --> Total execution time: 0.0589
DEBUG - 2022-06-27 10:07:00 --> Total execution time: 0.0629
DEBUG - 2022-06-27 10:07:18 --> Total execution time: 0.0569
DEBUG - 2022-06-27 10:07:23 --> Total execution time: 0.0673
DEBUG - 2022-06-27 10:07:29 --> Total execution time: 0.0621
DEBUG - 2022-06-27 10:07:43 --> Total execution time: 0.0495
DEBUG - 2022-06-27 10:07:48 --> Total execution time: 0.0689
DEBUG - 2022-06-27 10:08:02 --> Total execution time: 0.0541
DEBUG - 2022-06-27 10:08:04 --> Total execution time: 0.0657
DEBUG - 2022-06-27 10:08:59 --> Total execution time: 0.0338
DEBUG - 2022-06-27 10:09:07 --> Total execution time: 0.0339
DEBUG - 2022-06-27 10:09:26 --> Total execution time: 0.0718
DEBUG - 2022-06-27 10:09:37 --> Total execution time: 0.0567
DEBUG - 2022-06-27 10:09:45 --> Total execution time: 0.1649
DEBUG - 2022-06-27 10:09:58 --> Total execution time: 0.0676
DEBUG - 2022-06-27 10:10:08 --> Total execution time: 0.1066
DEBUG - 2022-06-27 10:10:09 --> Total execution time: 0.0527
DEBUG - 2022-06-27 10:18:39 --> Total execution time: 0.1105
DEBUG - 2022-06-27 10:21:59 --> Total execution time: 0.1369
DEBUG - 2022-06-27 10:25:31 --> Total execution time: 0.0956
DEBUG - 2022-06-27 10:25:32 --> Total execution time: 0.0350
DEBUG - 2022-06-27 10:26:39 --> Total execution time: 0.0364
DEBUG - 2022-06-27 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:30:03 --> Total execution time: 0.1397
DEBUG - 2022-06-27 00:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:09 --> Total execution time: 0.1031
DEBUG - 2022-06-27 00:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:19 --> Total execution time: 0.0510
DEBUG - 2022-06-27 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:25 --> Total execution time: 0.0523
DEBUG - 2022-06-27 00:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:29 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:29 --> Total execution time: 0.0488
DEBUG - 2022-06-27 00:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:35 --> Total execution time: 0.2812
DEBUG - 2022-06-27 00:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:47 --> Total execution time: 0.0798
DEBUG - 2022-06-27 00:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:57 --> Total execution time: 0.0537
DEBUG - 2022-06-27 00:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:02:59 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:00 --> Total execution time: 0.0531
DEBUG - 2022-06-27 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:03:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:01 --> Total execution time: 0.0411
DEBUG - 2022-06-27 00:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:03:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:04 --> Total execution time: 0.0436
DEBUG - 2022-06-27 00:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:32 --> Total execution time: 0.0448
DEBUG - 2022-06-27 00:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:03:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:34 --> Total execution time: 0.0341
DEBUG - 2022-06-27 00:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:34:04 --> Total execution time: 0.0577
DEBUG - 2022-06-27 00:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:34:04 --> Total execution time: 0.1140
DEBUG - 2022-06-27 00:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:34:05 --> Total execution time: 0.0477
DEBUG - 2022-06-27 00:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:34:31 --> Total execution time: 0.0502
DEBUG - 2022-06-27 00:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:34:53 --> Total execution time: 0.0536
DEBUG - 2022-06-27 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:00 --> Total execution time: 0.0754
DEBUG - 2022-06-27 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:13 --> Total execution time: 0.0584
DEBUG - 2022-06-27 00:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:15 --> Total execution time: 0.1220
DEBUG - 2022-06-27 00:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:19 --> Total execution time: 0.0576
DEBUG - 2022-06-27 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:22 --> Total execution time: 0.0818
DEBUG - 2022-06-27 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:28 --> Total execution time: 0.0477
DEBUG - 2022-06-27 00:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:33 --> Total execution time: 0.0598
DEBUG - 2022-06-27 00:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:36:19 --> Total execution time: 0.0494
DEBUG - 2022-06-27 00:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:38:08 --> Total execution time: 0.0561
DEBUG - 2022-06-27 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:40:06 --> Total execution time: 0.0791
DEBUG - 2022-06-27 00:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:40:12 --> Total execution time: 0.0655
DEBUG - 2022-06-27 00:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:40:15 --> Total execution time: 0.0599
DEBUG - 2022-06-27 00:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:40:38 --> Total execution time: 0.0800
DEBUG - 2022-06-27 00:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:40:42 --> Total execution time: 0.0563
DEBUG - 2022-06-27 00:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:40:46 --> Total execution time: 0.0515
DEBUG - 2022-06-27 00:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:41:14 --> Total execution time: 0.0813
DEBUG - 2022-06-27 00:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:41:31 --> Total execution time: 0.0774
DEBUG - 2022-06-27 00:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:41:35 --> Total execution time: 0.0923
DEBUG - 2022-06-27 00:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:41:55 --> Total execution time: 0.0709
DEBUG - 2022-06-27 00:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:16 --> Total execution time: 0.0663
DEBUG - 2022-06-27 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:19 --> Total execution time: 0.0595
DEBUG - 2022-06-27 00:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:21 --> Total execution time: 0.0605
DEBUG - 2022-06-27 00:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:30 --> Total execution time: 0.0685
DEBUG - 2022-06-27 00:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:38 --> Total execution time: 0.0788
DEBUG - 2022-06-27 00:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:39 --> Total execution time: 0.0548
DEBUG - 2022-06-27 00:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:43 --> Total execution time: 0.0577
DEBUG - 2022-06-27 00:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:46 --> Total execution time: 0.0574
DEBUG - 2022-06-27 00:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:42:54 --> Total execution time: 1.9085
DEBUG - 2022-06-27 00:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:10 --> Total execution time: 0.0439
DEBUG - 2022-06-27 00:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:13 --> Total execution time: 0.0485
DEBUG - 2022-06-27 00:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:13:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 00:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:21 --> Total execution time: 0.0491
DEBUG - 2022-06-27 00:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 00:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:22 --> Total execution time: 0.0573
DEBUG - 2022-06-27 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:19 --> Total execution time: 0.0475
DEBUG - 2022-06-27 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:21 --> Total execution time: 0.0668
DEBUG - 2022-06-27 00:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:38 --> Total execution time: 0.0516
DEBUG - 2022-06-27 00:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:46 --> Total execution time: 0.0633
DEBUG - 2022-06-27 00:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:55 --> Total execution time: 0.0623
DEBUG - 2022-06-27 00:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:59 --> Total execution time: 0.0627
DEBUG - 2022-06-27 00:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:08 --> Total execution time: 0.0546
DEBUG - 2022-06-27 00:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:15:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:26 --> Total execution time: 0.0343
DEBUG - 2022-06-27 00:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:29 --> Total execution time: 0.0309
DEBUG - 2022-06-27 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:34 --> Total execution time: 0.0581
DEBUG - 2022-06-27 00:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:39 --> Total execution time: 0.0694
DEBUG - 2022-06-27 00:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:18:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:48:12 --> Total execution time: 0.0371
DEBUG - 2022-06-27 00:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:48:30 --> Total execution time: 0.1120
DEBUG - 2022-06-27 00:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:48:51 --> Total execution time: 0.0505
DEBUG - 2022-06-27 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:48:58 --> Total execution time: 0.0997
DEBUG - 2022-06-27 00:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:02 --> Total execution time: 0.0957
DEBUG - 2022-06-27 00:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:09 --> Total execution time: 0.0548
DEBUG - 2022-06-27 00:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:37 --> Total execution time: 0.0461
DEBUG - 2022-06-27 00:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:42 --> Total execution time: 0.0499
DEBUG - 2022-06-27 00:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:20:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:50:55 --> Total execution time: 0.0603
DEBUG - 2022-06-27 00:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:51:06 --> Total execution time: 0.0547
DEBUG - 2022-06-27 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:51:20 --> Total execution time: 0.0568
DEBUG - 2022-06-27 00:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:51:39 --> Total execution time: 0.0572
DEBUG - 2022-06-27 00:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:15 --> Total execution time: 0.0649
DEBUG - 2022-06-27 00:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:30 --> Total execution time: 0.0523
DEBUG - 2022-06-27 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:43 --> Total execution time: 0.0454
DEBUG - 2022-06-27 00:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:46 --> Total execution time: 0.0446
DEBUG - 2022-06-27 00:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:51 --> Total execution time: 0.0642
DEBUG - 2022-06-27 00:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:57 --> Total execution time: 0.0539
DEBUG - 2022-06-27 00:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:02 --> Total execution time: 0.0584
DEBUG - 2022-06-27 00:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:05 --> Total execution time: 0.0630
DEBUG - 2022-06-27 00:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:34 --> Total execution time: 0.1499
DEBUG - 2022-06-27 00:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:40 --> Total execution time: 0.0734
DEBUG - 2022-06-27 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:44 --> Total execution time: 0.0642
DEBUG - 2022-06-27 00:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:50 --> Total execution time: 0.0774
DEBUG - 2022-06-27 00:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:55 --> Total execution time: 0.0898
DEBUG - 2022-06-27 00:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:54:01 --> Total execution time: 0.0580
DEBUG - 2022-06-27 00:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:54:04 --> Total execution time: 0.0831
DEBUG - 2022-06-27 00:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:55:52 --> Total execution time: 0.2097
DEBUG - 2022-06-27 00:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:56:55 --> Total execution time: 0.0853
DEBUG - 2022-06-27 00:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:28:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:58:30 --> Total execution time: 0.0734
DEBUG - 2022-06-27 00:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:30:57 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:00:58 --> Total execution time: 0.3118
DEBUG - 2022-06-27 00:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:11 --> Total execution time: 0.0791
DEBUG - 2022-06-27 00:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:11 --> Total execution time: 0.0755
DEBUG - 2022-06-27 00:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:17 --> Total execution time: 0.0912
DEBUG - 2022-06-27 00:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:19 --> Total execution time: 0.0625
DEBUG - 2022-06-27 00:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:22 --> Total execution time: 0.1728
DEBUG - 2022-06-27 00:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:22 --> Total execution time: 0.1245
DEBUG - 2022-06-27 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:40 --> Total execution time: 0.1362
DEBUG - 2022-06-27 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:49 --> Total execution time: 0.0894
DEBUG - 2022-06-27 00:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:51 --> Total execution time: 0.0955
DEBUG - 2022-06-27 00:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:55 --> Total execution time: 0.0776
DEBUG - 2022-06-27 00:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:01 --> Total execution time: 0.0768
DEBUG - 2022-06-27 00:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:17 --> Total execution time: 0.0670
DEBUG - 2022-06-27 00:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:05:06 --> Total execution time: 0.1880
DEBUG - 2022-06-27 00:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:09:33 --> Total execution time: 0.1381
DEBUG - 2022-06-27 00:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:10:31 --> Total execution time: 0.0870
DEBUG - 2022-06-27 00:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:40:53 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:10:53 --> Total execution time: 0.0424
DEBUG - 2022-06-27 00:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:41:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:11:11 --> Total execution time: 0.0473
DEBUG - 2022-06-27 00:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:11:15 --> Total execution time: 0.0397
DEBUG - 2022-06-27 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:11:23 --> Total execution time: 0.0654
DEBUG - 2022-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:11:34 --> Total execution time: 0.0595
DEBUG - 2022-06-27 00:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:11:38 --> Total execution time: 0.0762
DEBUG - 2022-06-27 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:42:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:12:02 --> Total execution time: 0.1374
DEBUG - 2022-06-27 00:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:43:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:13:06 --> Total execution time: 0.2371
DEBUG - 2022-06-27 00:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:13:14 --> Total execution time: 0.0997
DEBUG - 2022-06-27 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:13:31 --> Total execution time: 0.1031
DEBUG - 2022-06-27 00:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:13:46 --> Total execution time: 0.2605
DEBUG - 2022-06-27 00:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:44:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:14:05 --> Total execution time: 0.0570
DEBUG - 2022-06-27 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:14:06 --> Total execution time: 0.0724
DEBUG - 2022-06-27 00:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:44:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:14:46 --> Total execution time: 0.1794
DEBUG - 2022-06-27 00:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:15 --> Total execution time: 0.0539
DEBUG - 2022-06-27 00:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:24 --> Total execution time: 0.0462
DEBUG - 2022-06-27 00:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:31 --> Total execution time: 0.0517
DEBUG - 2022-06-27 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:35 --> Total execution time: 0.1534
DEBUG - 2022-06-27 00:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:38 --> Total execution time: 0.0901
DEBUG - 2022-06-27 00:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:45 --> Total execution time: 0.0627
DEBUG - 2022-06-27 00:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:15:55 --> Total execution time: 0.0478
DEBUG - 2022-06-27 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:14 --> Total execution time: 0.0446
DEBUG - 2022-06-27 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:17 --> Total execution time: 0.0597
DEBUG - 2022-06-27 00:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:17 --> Total execution time: 0.0929
DEBUG - 2022-06-27 00:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:23 --> Total execution time: 0.1159
DEBUG - 2022-06-27 00:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:31 --> Total execution time: 0.0603
DEBUG - 2022-06-27 00:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:32 --> Total execution time: 0.0349
DEBUG - 2022-06-27 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:36 --> Total execution time: 0.0483
DEBUG - 2022-06-27 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:36 --> Total execution time: 0.0633
DEBUG - 2022-06-27 00:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:41 --> Total execution time: 0.0506
DEBUG - 2022-06-27 00:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:43 --> Total execution time: 0.0503
DEBUG - 2022-06-27 00:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:43 --> Total execution time: 0.1083
DEBUG - 2022-06-27 00:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:45 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:45 --> Total execution time: 0.0487
DEBUG - 2022-06-27 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:49 --> Total execution time: 0.0556
DEBUG - 2022-06-27 00:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:53 --> Total execution time: 0.2231
DEBUG - 2022-06-27 00:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:46:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:16:55 --> Total execution time: 0.0569
DEBUG - 2022-06-27 00:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:04 --> Total execution time: 0.0539
DEBUG - 2022-06-27 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:06 --> Total execution time: 0.0520
DEBUG - 2022-06-27 00:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:06 --> Total execution time: 0.0990
DEBUG - 2022-06-27 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:21 --> Total execution time: 0.0590
DEBUG - 2022-06-27 00:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:22 --> Total execution time: 0.0654
DEBUG - 2022-06-27 00:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:47:22 --> Total execution time: 0.1143
DEBUG - 2022-06-27 00:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:41 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:17:41 --> Total execution time: 0.0927
DEBUG - 2022-06-27 00:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:17:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 00:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:17:50 --> Total execution time: 0.0800
DEBUG - 2022-06-27 00:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:17:57 --> Total execution time: 0.0884
DEBUG - 2022-06-27 00:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:02 --> Total execution time: 0.1990
DEBUG - 2022-06-27 00:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:07 --> Total execution time: 0.1152
DEBUG - 2022-06-27 00:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:11 --> Total execution time: 0.1128
DEBUG - 2022-06-27 00:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:14 --> Total execution time: 0.0646
DEBUG - 2022-06-27 00:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:23 --> Total execution time: 0.0596
DEBUG - 2022-06-27 00:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:25 --> Total execution time: 0.0682
DEBUG - 2022-06-27 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:27 --> Total execution time: 0.0929
DEBUG - 2022-06-27 00:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:30 --> Total execution time: 0.2709
DEBUG - 2022-06-27 00:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:33 --> Total execution time: 0.0798
DEBUG - 2022-06-27 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:40 --> Total execution time: 0.1048
DEBUG - 2022-06-27 00:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:49 --> Total execution time: 0.0561
DEBUG - 2022-06-27 00:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:19:25 --> Total execution time: 0.0499
DEBUG - 2022-06-27 00:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:20:28 --> Total execution time: 0.0599
DEBUG - 2022-06-27 00:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:20:33 --> Total execution time: 0.0865
DEBUG - 2022-06-27 00:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:20:53 --> Total execution time: 0.0915
DEBUG - 2022-06-27 00:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:51:03 --> Total execution time: 0.1561
DEBUG - 2022-06-27 00:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:51:05 --> Total execution time: 0.0542
DEBUG - 2022-06-27 00:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:51:05 --> Total execution time: 0.1081
DEBUG - 2022-06-27 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:21:14 --> Total execution time: 0.0510
DEBUG - 2022-06-27 00:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:21:32 --> Total execution time: 0.0593
DEBUG - 2022-06-27 00:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:22:48 --> Total execution time: 0.1907
DEBUG - 2022-06-27 00:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:53:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 00:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:23:08 --> Total execution time: 0.1677
DEBUG - 2022-06-27 00:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:55:18 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 00:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:27:35 --> Total execution time: 0.0607
DEBUG - 2022-06-27 00:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:27:52 --> Total execution time: 0.0554
DEBUG - 2022-06-27 00:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:57:55 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 00:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 00:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:28:07 --> Total execution time: 0.0726
DEBUG - 2022-06-27 00:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:58:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:58:15 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-06-27 00:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:58:41 --> 404 Page Not Found: 30cCCphp/index
DEBUG - 2022-06-27 00:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:58:51 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-06-27 00:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 00:58:55 --> 404 Page Not Found: 30cCCphp/index
DEBUG - 2022-06-27 00:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:29:16 --> Total execution time: 0.0704
DEBUG - 2022-06-27 00:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 00:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 00:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:29:35 --> Total execution time: 0.0799
DEBUG - 2022-06-27 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:30:02 --> Total execution time: 0.1179
DEBUG - 2022-06-27 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:00:15 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 01:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:30:18 --> Total execution time: 0.1203
DEBUG - 2022-06-27 01:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:00:44 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:30:44 --> Total execution time: 0.0577
DEBUG - 2022-06-27 01:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:31:13 --> Total execution time: 0.0491
DEBUG - 2022-06-27 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:31:27 --> Total execution time: 0.0529
DEBUG - 2022-06-27 01:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:31:44 --> Total execution time: 0.0498
DEBUG - 2022-06-27 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:31:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 01:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:31:46 --> Total execution time: 0.0464
DEBUG - 2022-06-27 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:01 --> Total execution time: 0.1345
DEBUG - 2022-06-27 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:01 --> Total execution time: 0.0880
DEBUG - 2022-06-27 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:02 --> Total execution time: 0.0682
DEBUG - 2022-06-27 01:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:02 --> Total execution time: 0.0752
DEBUG - 2022-06-27 01:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:02 --> Total execution time: 0.0707
DEBUG - 2022-06-27 01:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:02 --> Total execution time: 0.0548
DEBUG - 2022-06-27 01:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:02 --> Total execution time: 0.0581
DEBUG - 2022-06-27 01:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:03 --> Total execution time: 0.0636
DEBUG - 2022-06-27 01:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:03 --> Total execution time: 0.0521
DEBUG - 2022-06-27 01:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:03 --> Total execution time: 0.0666
DEBUG - 2022-06-27 01:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:02:05 --> Total execution time: 0.0515
DEBUG - 2022-06-27 01:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:16 --> Total execution time: 0.0361
DEBUG - 2022-06-27 01:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:02:19 --> Total execution time: 0.0410
DEBUG - 2022-06-27 01:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:40 --> Total execution time: 0.0704
DEBUG - 2022-06-27 01:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:44 --> Total execution time: 0.0506
DEBUG - 2022-06-27 01:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:46 --> Total execution time: 0.0989
DEBUG - 2022-06-27 01:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:52 --> Total execution time: 0.0545
DEBUG - 2022-06-27 01:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:33:09 --> Total execution time: 0.0495
DEBUG - 2022-06-27 01:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:33:10 --> Total execution time: 0.0659
DEBUG - 2022-06-27 01:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:33:16 --> Total execution time: 0.0491
DEBUG - 2022-06-27 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:33:24 --> Total execution time: 0.0530
DEBUG - 2022-06-27 01:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:33:47 --> Total execution time: 0.0812
DEBUG - 2022-06-27 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:00 --> Total execution time: 0.0475
DEBUG - 2022-06-27 01:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:04 --> Total execution time: 0.0496
DEBUG - 2022-06-27 01:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:04:22 --> Total execution time: 0.0637
DEBUG - 2022-06-27 01:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:04:23 --> Total execution time: 0.0575
DEBUG - 2022-06-27 01:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:04:23 --> Total execution time: 0.1155
DEBUG - 2022-06-27 01:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:27 --> Total execution time: 0.1496
DEBUG - 2022-06-27 01:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:04:30 --> Total execution time: 0.0511
DEBUG - 2022-06-27 01:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:41 --> Total execution time: 0.0636
DEBUG - 2022-06-27 01:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:05:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 01:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:35:46 --> Total execution time: 2.0319
DEBUG - 2022-06-27 01:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:05:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 01:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:35:57 --> Total execution time: 0.0523
DEBUG - 2022-06-27 01:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:35:58 --> Total execution time: 0.0437
DEBUG - 2022-06-27 01:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:06:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:36:26 --> Total execution time: 0.0586
DEBUG - 2022-06-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:37:00 --> Total execution time: 0.0438
DEBUG - 2022-06-27 01:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:37:09 --> Total execution time: 0.0586
DEBUG - 2022-06-27 01:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:37:14 --> Total execution time: 0.0591
DEBUG - 2022-06-27 01:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:37:43 --> Total execution time: 0.0464
DEBUG - 2022-06-27 01:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:08:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:38:24 --> Total execution time: 0.0490
DEBUG - 2022-06-27 01:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:39:33 --> Total execution time: 0.0579
DEBUG - 2022-06-27 01:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:39:51 --> Total execution time: 0.0710
DEBUG - 2022-06-27 01:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:55 --> Total execution time: 0.0493
DEBUG - 2022-06-27 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:13 --> Total execution time: 0.0504
DEBUG - 2022-06-27 01:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:21 --> Total execution time: 0.0542
DEBUG - 2022-06-27 01:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:30 --> Total execution time: 0.0761
DEBUG - 2022-06-27 01:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:51 --> Total execution time: 0.0810
DEBUG - 2022-06-27 01:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:52 --> Total execution time: 0.0435
DEBUG - 2022-06-27 01:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:56 --> Total execution time: 0.0442
DEBUG - 2022-06-27 01:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:43:37 --> Total execution time: 0.0631
DEBUG - 2022-06-27 01:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:44:49 --> Total execution time: 0.0365
DEBUG - 2022-06-27 01:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:44:50 --> Total execution time: 0.0454
DEBUG - 2022-06-27 01:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:14:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 01:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:14:54 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-06-27 01:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:44:54 --> Total execution time: 0.0612
DEBUG - 2022-06-27 01:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:44:57 --> Total execution time: 0.0496
DEBUG - 2022-06-27 01:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:44:58 --> Total execution time: 0.0633
DEBUG - 2022-06-27 01:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:44:59 --> Total execution time: 0.0479
DEBUG - 2022-06-27 01:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:00 --> Total execution time: 0.0448
DEBUG - 2022-06-27 01:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:01 --> Total execution time: 0.0673
DEBUG - 2022-06-27 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:02 --> Total execution time: 0.0474
DEBUG - 2022-06-27 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:04 --> Total execution time: 0.0475
DEBUG - 2022-06-27 01:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:05 --> Total execution time: 0.0484
DEBUG - 2022-06-27 01:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:06 --> Total execution time: 0.0563
DEBUG - 2022-06-27 01:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:15:08 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-27 01:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:08 --> Total execution time: 0.0368
DEBUG - 2022-06-27 01:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:15:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:15 --> Total execution time: 0.0349
DEBUG - 2022-06-27 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:48:06 --> Total execution time: 0.1861
DEBUG - 2022-06-27 01:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:52:12 --> Total execution time: 1.7125
DEBUG - 2022-06-27 01:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:23:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:53:55 --> Total execution time: 0.1373
DEBUG - 2022-06-27 01:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:23:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:53:55 --> Total execution time: 0.0679
DEBUG - 2022-06-27 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:54:05 --> Total execution time: 0.0565
DEBUG - 2022-06-27 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:54:05 --> Total execution time: 0.0474
DEBUG - 2022-06-27 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:24:37 --> Total execution time: 0.0506
DEBUG - 2022-06-27 01:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:24:40 --> Total execution time: 0.0523
DEBUG - 2022-06-27 01:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:24:40 --> Total execution time: 0.0573
DEBUG - 2022-06-27 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:24:47 --> Total execution time: 0.0661
DEBUG - 2022-06-27 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:24:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:24:51 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 01:24:51 --> Total execution time: 0.0601
DEBUG - 2022-06-27 01:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:24:51 --> Total execution time: 0.1088
DEBUG - 2022-06-27 01:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:55:04 --> Total execution time: 0.0576
DEBUG - 2022-06-27 01:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:55:22 --> Total execution time: 0.0679
DEBUG - 2022-06-27 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:55:49 --> Total execution time: 0.0808
DEBUG - 2022-06-27 01:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:56:27 --> Total execution time: 0.0521
DEBUG - 2022-06-27 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:56:36 --> Total execution time: 0.0560
DEBUG - 2022-06-27 01:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:56:41 --> Total execution time: 0.0544
DEBUG - 2022-06-27 01:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:56:45 --> Total execution time: 0.0591
DEBUG - 2022-06-27 01:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:57:05 --> Total execution time: 0.0535
DEBUG - 2022-06-27 01:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:01 --> Total execution time: 0.1573
DEBUG - 2022-06-27 01:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:12 --> Total execution time: 0.0470
DEBUG - 2022-06-27 01:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:31 --> Total execution time: 0.0758
DEBUG - 2022-06-27 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:32 --> Total execution time: 0.0856
DEBUG - 2022-06-27 01:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:39 --> Total execution time: 0.1527
DEBUG - 2022-06-27 01:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:41 --> Total execution time: 0.1557
DEBUG - 2022-06-27 01:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:58:59 --> Total execution time: 0.0573
DEBUG - 2022-06-27 01:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:02:04 --> Total execution time: 0.1121
DEBUG - 2022-06-27 01:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:02:11 --> Total execution time: 0.0424
DEBUG - 2022-06-27 01:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:02:38 --> Total execution time: 0.0715
DEBUG - 2022-06-27 01:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:02:41 --> Total execution time: 0.0697
DEBUG - 2022-06-27 01:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:02:45 --> Total execution time: 0.0656
DEBUG - 2022-06-27 01:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:02:54 --> Total execution time: 0.0596
DEBUG - 2022-06-27 01:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:02 --> Total execution time: 0.0583
DEBUG - 2022-06-27 01:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:14 --> Total execution time: 0.0608
DEBUG - 2022-06-27 01:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:04:48 --> Total execution time: 0.0810
DEBUG - 2022-06-27 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:35:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:05:27 --> Total execution time: 0.0892
DEBUG - 2022-06-27 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:35:27 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:05:27 --> Total execution time: 0.0478
DEBUG - 2022-06-27 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:35:41 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:05:41 --> Total execution time: 0.0358
DEBUG - 2022-06-27 01:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:35:51 --> Total execution time: 0.0395
DEBUG - 2022-06-27 01:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:35:52 --> Total execution time: 0.0707
DEBUG - 2022-06-27 01:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:35:52 --> Total execution time: 0.1353
DEBUG - 2022-06-27 01:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:36:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:06:34 --> Total execution time: 0.0371
DEBUG - 2022-06-27 01:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:07:43 --> Total execution time: 0.0649
DEBUG - 2022-06-27 01:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:37:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 01:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:07:45 --> Total execution time: 2.0201
DEBUG - 2022-06-27 01:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 01:37:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 01:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:08:50 --> Total execution time: 0.1491
DEBUG - 2022-06-27 01:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:41 --> Total execution time: 0.0547
DEBUG - 2022-06-27 01:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:39:59 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:59 --> Total execution time: 0.0710
DEBUG - 2022-06-27 01:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:00 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:00 --> Total execution time: 0.0616
DEBUG - 2022-06-27 01:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:10 --> Total execution time: 0.0408
DEBUG - 2022-06-27 01:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:13 --> Total execution time: 0.0466
DEBUG - 2022-06-27 01:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:17 --> Total execution time: 0.0586
DEBUG - 2022-06-27 01:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:22 --> Total execution time: 0.0780
DEBUG - 2022-06-27 01:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 01:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:23 --> Total execution time: 0.0688
DEBUG - 2022-06-27 01:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:57 --> Total execution time: 0.0626
DEBUG - 2022-06-27 01:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:03 --> Total execution time: 0.0596
DEBUG - 2022-06-27 01:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:04 --> Total execution time: 0.0675
DEBUG - 2022-06-27 01:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:16 --> Total execution time: 0.0474
DEBUG - 2022-06-27 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:19 --> Total execution time: 0.0587
DEBUG - 2022-06-27 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:19 --> Total execution time: 0.0778
DEBUG - 2022-06-27 01:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:23 --> Total execution time: 0.0831
DEBUG - 2022-06-27 01:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:25 --> Total execution time: 0.0757
DEBUG - 2022-06-27 01:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:29 --> Total execution time: 0.0461
DEBUG - 2022-06-27 01:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:30 --> Total execution time: 0.0536
DEBUG - 2022-06-27 01:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:32 --> Total execution time: 0.0940
DEBUG - 2022-06-27 01:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:33 --> Total execution time: 0.0529
DEBUG - 2022-06-27 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:36 --> Total execution time: 0.0348
DEBUG - 2022-06-27 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:38 --> Total execution time: 0.0668
DEBUG - 2022-06-27 01:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:40 --> Total execution time: 0.0891
DEBUG - 2022-06-27 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:41 --> Total execution time: 0.0562
DEBUG - 2022-06-27 01:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:44 --> Total execution time: 0.0669
DEBUG - 2022-06-27 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:46 --> Total execution time: 0.0555
DEBUG - 2022-06-27 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:50 --> Total execution time: 0.0500
DEBUG - 2022-06-27 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:53 --> Total execution time: 0.0655
DEBUG - 2022-06-27 01:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 01:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:56 --> Total execution time: 0.0533
DEBUG - 2022-06-27 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:41:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-06-27 12:11:57 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-06-27 12:11:57 --> Total execution time: 0.0633
DEBUG - 2022-06-27 01:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:02 --> Total execution time: 0.0941
DEBUG - 2022-06-27 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:03 --> Total execution time: 0.0520
DEBUG - 2022-06-27 01:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:07 --> Total execution time: 0.0535
DEBUG - 2022-06-27 01:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:09 --> Total execution time: 0.0597
DEBUG - 2022-06-27 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:17 --> Total execution time: 0.0875
DEBUG - 2022-06-27 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:17 --> Total execution time: 0.1139
DEBUG - 2022-06-27 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:18 --> Total execution time: 0.1105
DEBUG - 2022-06-27 01:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:19 --> Total execution time: 0.0694
DEBUG - 2022-06-27 01:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:20 --> Total execution time: 0.0899
DEBUG - 2022-06-27 01:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:20 --> Total execution time: 0.0935
DEBUG - 2022-06-27 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:21 --> Total execution time: 0.0934
DEBUG - 2022-06-27 01:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:25 --> Total execution time: 0.0788
DEBUG - 2022-06-27 01:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:27 --> Total execution time: 0.0452
DEBUG - 2022-06-27 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:32 --> Total execution time: 0.1413
DEBUG - 2022-06-27 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:33 --> Total execution time: 0.0575
DEBUG - 2022-06-27 01:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:34 --> Total execution time: 0.0616
DEBUG - 2022-06-27 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:40 --> Total execution time: 0.0798
DEBUG - 2022-06-27 01:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:45 --> Total execution time: 0.1182
DEBUG - 2022-06-27 01:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:46 --> Total execution time: 0.0803
DEBUG - 2022-06-27 01:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:52 --> Total execution time: 0.1125
DEBUG - 2022-06-27 01:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:13:14 --> Total execution time: 0.0536
DEBUG - 2022-06-27 01:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:13:46 --> Total execution time: 0.0741
DEBUG - 2022-06-27 01:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:14:31 --> Total execution time: 0.0868
DEBUG - 2022-06-27 01:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:14:33 --> Total execution time: 0.0776
DEBUG - 2022-06-27 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:22:25 --> Total execution time: 0.2173
DEBUG - 2022-06-27 01:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:23:04 --> Total execution time: 0.1195
DEBUG - 2022-06-27 01:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:23:21 --> Total execution time: 0.0650
DEBUG - 2022-06-27 01:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:56:19 --> Total execution time: 0.1292
DEBUG - 2022-06-27 01:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:56:28 --> Total execution time: 0.1207
DEBUG - 2022-06-27 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:57:18 --> No URI present. Default controller set.
DEBUG - 2022-06-27 01:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:27:18 --> Total execution time: 0.0610
DEBUG - 2022-06-27 01:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:27:57 --> Total execution time: 0.0855
DEBUG - 2022-06-27 01:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:27:58 --> Total execution time: 0.0839
DEBUG - 2022-06-27 01:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:28:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 01:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:28:45 --> Total execution time: 0.1083
DEBUG - 2022-06-27 01:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:59:49 --> Total execution time: 0.0514
DEBUG - 2022-06-27 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 01:59:58 --> Total execution time: 0.0826
DEBUG - 2022-06-27 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:30:04 --> Total execution time: 0.0486
DEBUG - 2022-06-27 02:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:30:48 --> Total execution time: 0.0613
DEBUG - 2022-06-27 02:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:30:58 --> Total execution time: 0.0520
DEBUG - 2022-06-27 02:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:32:02 --> Total execution time: 0.0573
DEBUG - 2022-06-27 02:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:34:16 --> Total execution time: 0.0602
DEBUG - 2022-06-27 02:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:34:26 --> Total execution time: 0.0633
DEBUG - 2022-06-27 02:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:05:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:35:04 --> Total execution time: 0.0535
DEBUG - 2022-06-27 02:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:05:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:35:49 --> Total execution time: 0.0413
DEBUG - 2022-06-27 02:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:01 --> Total execution time: 0.0406
DEBUG - 2022-06-27 02:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:03 --> Total execution time: 0.0468
DEBUG - 2022-06-27 02:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:04 --> Total execution time: 0.0493
DEBUG - 2022-06-27 02:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:05 --> Total execution time: 0.0524
DEBUG - 2022-06-27 02:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:06 --> Total execution time: 0.0363
DEBUG - 2022-06-27 02:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:18 --> Total execution time: 0.0590
DEBUG - 2022-06-27 02:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:36:30 --> Total execution time: 0.0517
DEBUG - 2022-06-27 02:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:06:33 --> Total execution time: 0.0621
DEBUG - 2022-06-27 02:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 02:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 02:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:21 --> Total execution time: 0.0575
DEBUG - 2022-06-27 02:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:35 --> Total execution time: 0.0604
DEBUG - 2022-06-27 02:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:40 --> Total execution time: 0.0572
DEBUG - 2022-06-27 02:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:48 --> Total execution time: 0.0574
DEBUG - 2022-06-27 02:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:52 --> Total execution time: 0.0681
DEBUG - 2022-06-27 02:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:54 --> Total execution time: 0.0762
DEBUG - 2022-06-27 02:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:37:58 --> Total execution time: 0.0647
DEBUG - 2022-06-27 02:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:01 --> Total execution time: 0.0357
DEBUG - 2022-06-27 02:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:08 --> Total execution time: 0.0497
DEBUG - 2022-06-27 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:24 --> Total execution time: 0.0590
DEBUG - 2022-06-27 02:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:28 --> Total execution time: 0.0556
DEBUG - 2022-06-27 02:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:31 --> Total execution time: 0.0956
DEBUG - 2022-06-27 02:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:33 --> Total execution time: 0.0479
DEBUG - 2022-06-27 02:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:33 --> Total execution time: 0.0436
DEBUG - 2022-06-27 02:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:36 --> Total execution time: 0.0439
DEBUG - 2022-06-27 02:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:44 --> Total execution time: 0.0932
DEBUG - 2022-06-27 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:38:55 --> Total execution time: 0.0651
DEBUG - 2022-06-27 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:39:01 --> Total execution time: 0.0864
DEBUG - 2022-06-27 02:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:39:08 --> Total execution time: 0.0760
DEBUG - 2022-06-27 02:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:39:15 --> Total execution time: 0.0577
DEBUG - 2022-06-27 02:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:39:18 --> Total execution time: 0.1498
DEBUG - 2022-06-27 02:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:39:34 --> Total execution time: 0.0579
DEBUG - 2022-06-27 02:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:42:01 --> Total execution time: 0.1580
DEBUG - 2022-06-27 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:42:23 --> Total execution time: 0.0737
DEBUG - 2022-06-27 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:42:33 --> Total execution time: 0.1163
DEBUG - 2022-06-27 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:42:36 --> Total execution time: 0.0514
DEBUG - 2022-06-27 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:42:40 --> Total execution time: 0.1023
DEBUG - 2022-06-27 02:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:43:08 --> Total execution time: 0.1189
DEBUG - 2022-06-27 02:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:43:10 --> Total execution time: 0.0577
DEBUG - 2022-06-27 02:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:43:12 --> Total execution time: 0.0752
DEBUG - 2022-06-27 02:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:43:47 --> Total execution time: 0.0484
DEBUG - 2022-06-27 02:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:46:22 --> Total execution time: 0.1361
DEBUG - 2022-06-27 02:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:19:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:49:48 --> Total execution time: 0.0943
DEBUG - 2022-06-27 02:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:21:35 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:51:36 --> Total execution time: 0.1413
DEBUG - 2022-06-27 02:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:51:41 --> Total execution time: 0.0319
DEBUG - 2022-06-27 02:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:51:45 --> Total execution time: 0.0535
DEBUG - 2022-06-27 02:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:51:54 --> Total execution time: 0.0593
DEBUG - 2022-06-27 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:51:59 --> Total execution time: 0.0755
DEBUG - 2022-06-27 02:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:52:12 --> Total execution time: 0.1385
DEBUG - 2022-06-27 02:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:31 --> Total execution time: 0.1823
DEBUG - 2022-06-27 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:55:04 --> Total execution time: 0.0920
DEBUG - 2022-06-27 02:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:00 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:00 --> Total execution time: 0.0708
DEBUG - 2022-06-27 02:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:03 --> Total execution time: 0.0553
DEBUG - 2022-06-27 02:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:11 --> Total execution time: 0.0743
DEBUG - 2022-06-27 02:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:22 --> Total execution time: 0.0852
DEBUG - 2022-06-27 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:38 --> Total execution time: 0.1529
DEBUG - 2022-06-27 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:42 --> Total execution time: 0.0465
DEBUG - 2022-06-27 02:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:45 --> Total execution time: 0.0585
DEBUG - 2022-06-27 02:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:47 --> Total execution time: 0.0645
DEBUG - 2022-06-27 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:56:54 --> Total execution time: 0.0484
DEBUG - 2022-06-27 02:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:57:00 --> Total execution time: 0.0722
DEBUG - 2022-06-27 02:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:57:06 --> Total execution time: 0.0603
DEBUG - 2022-06-27 02:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:57:13 --> Total execution time: 0.0820
DEBUG - 2022-06-27 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:57:26 --> Total execution time: 0.0706
DEBUG - 2022-06-27 02:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:57:57 --> Total execution time: 0.0827
DEBUG - 2022-06-27 02:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:58:08 --> Total execution time: 0.0847
DEBUG - 2022-06-27 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:58:13 --> Total execution time: 0.0605
DEBUG - 2022-06-27 02:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:01:46 --> Total execution time: 0.4084
DEBUG - 2022-06-27 02:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:02:18 --> Total execution time: 0.0592
DEBUG - 2022-06-27 02:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:02:23 --> Total execution time: 0.0641
DEBUG - 2022-06-27 02:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:02:37 --> Total execution time: 0.0560
DEBUG - 2022-06-27 02:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:02:56 --> Total execution time: 0.0670
DEBUG - 2022-06-27 02:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:03:26 --> Total execution time: 0.0642
DEBUG - 2022-06-27 02:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:03:31 --> Total execution time: 0.0485
DEBUG - 2022-06-27 02:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:03:32 --> Total execution time: 0.0582
DEBUG - 2022-06-27 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:03:34 --> Total execution time: 0.1033
DEBUG - 2022-06-27 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:33:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:03:49 --> Total execution time: 0.0441
DEBUG - 2022-06-27 02:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:34:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:04:03 --> Total execution time: 0.0503
DEBUG - 2022-06-27 02:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:04:14 --> Total execution time: 0.0638
DEBUG - 2022-06-27 02:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:04:49 --> Total execution time: 0.0552
DEBUG - 2022-06-27 02:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:04:59 --> Total execution time: 0.0795
DEBUG - 2022-06-27 02:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:27 --> Total execution time: 0.0480
DEBUG - 2022-06-27 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:43 --> Total execution time: 0.0451
DEBUG - 2022-06-27 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:46 --> Total execution time: 0.0478
DEBUG - 2022-06-27 02:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:47 --> Total execution time: 0.0442
DEBUG - 2022-06-27 02:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:51 --> Total execution time: 0.0556
DEBUG - 2022-06-27 02:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:53 --> Total execution time: 0.0482
DEBUG - 2022-06-27 02:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:54 --> Total execution time: 0.0640
DEBUG - 2022-06-27 02:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:57 --> Total execution time: 0.1127
DEBUG - 2022-06-27 02:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:06:05 --> Total execution time: 0.0469
DEBUG - 2022-06-27 02:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:06:13 --> Total execution time: 0.0964
DEBUG - 2022-06-27 02:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:16 --> Total execution time: 0.0626
DEBUG - 2022-06-27 02:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:29 --> Total execution time: 0.0734
DEBUG - 2022-06-27 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:35 --> Total execution time: 0.0791
DEBUG - 2022-06-27 02:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:39 --> Total execution time: 0.0490
DEBUG - 2022-06-27 02:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:41 --> Total execution time: 0.0550
DEBUG - 2022-06-27 02:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:44 --> Total execution time: 0.0496
DEBUG - 2022-06-27 02:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:37:45 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:07:45 --> Total execution time: 0.0490
DEBUG - 2022-06-27 02:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:39:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:09:06 --> Total execution time: 0.3238
DEBUG - 2022-06-27 02:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:39:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:09:06 --> Total execution time: 0.1007
DEBUG - 2022-06-27 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:09:34 --> Total execution time: 0.0776
DEBUG - 2022-06-27 02:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 02:40:02 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 02:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:40:04 --> Total execution time: 0.1923
DEBUG - 2022-06-27 02:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:40:25 --> Total execution time: 0.2041
DEBUG - 2022-06-27 02:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:40:25 --> Total execution time: 0.0960
DEBUG - 2022-06-27 02:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:41:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:11:16 --> Total execution time: 0.0875
DEBUG - 2022-06-27 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:11:19 --> Total execution time: 0.0670
DEBUG - 2022-06-27 02:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 02:42:23 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 02:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:42:27 --> Total execution time: 0.0544
DEBUG - 2022-06-27 02:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:42:38 --> Total execution time: 0.0473
DEBUG - 2022-06-27 02:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:42:44 --> Total execution time: 0.0518
DEBUG - 2022-06-27 02:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:42:46 --> Total execution time: 0.0609
DEBUG - 2022-06-27 02:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:42:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 02:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:42:46 --> Total execution time: 0.0635
DEBUG - 2022-06-27 02:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:12:49 --> Total execution time: 1.9281
DEBUG - 2022-06-27 02:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 02:43:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 02:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:13:05 --> Total execution time: 0.0404
DEBUG - 2022-06-27 02:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:13:55 --> Total execution time: 0.0520
DEBUG - 2022-06-27 02:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:14:01 --> Total execution time: 0.0846
DEBUG - 2022-06-27 02:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 02:44:44 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 02:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:15:10 --> Total execution time: 0.0440
DEBUG - 2022-06-27 02:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:15:25 --> Total execution time: 0.0707
DEBUG - 2022-06-27 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:45:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:15:54 --> Total execution time: 0.1581
DEBUG - 2022-06-27 02:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:15:58 --> Total execution time: 0.0516
DEBUG - 2022-06-27 02:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:16:13 --> Total execution time: 0.0471
DEBUG - 2022-06-27 02:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:16:53 --> Total execution time: 0.0447
DEBUG - 2022-06-27 02:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:47:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:17:26 --> Total execution time: 0.0400
DEBUG - 2022-06-27 02:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:17:30 --> Total execution time: 0.0567
DEBUG - 2022-06-27 02:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:47:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:17:49 --> Total execution time: 0.0542
DEBUG - 2022-06-27 02:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:17:52 --> Total execution time: 0.0640
DEBUG - 2022-06-27 02:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:48:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:18:15 --> Total execution time: 0.0719
DEBUG - 2022-06-27 02:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:18:51 --> Total execution time: 0.0457
DEBUG - 2022-06-27 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:02 --> Total execution time: 0.0622
DEBUG - 2022-06-27 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:16 --> Total execution time: 0.0465
DEBUG - 2022-06-27 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:16 --> Total execution time: 0.0644
DEBUG - 2022-06-27 02:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:18 --> Total execution time: 0.0466
DEBUG - 2022-06-27 02:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:34 --> Total execution time: 0.0561
DEBUG - 2022-06-27 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:46 --> Total execution time: 0.0470
DEBUG - 2022-06-27 02:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:19:58 --> Total execution time: 0.0584
DEBUG - 2022-06-27 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:20:49 --> Total execution time: 0.0498
DEBUG - 2022-06-27 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:03 --> Total execution time: 0.0316
DEBUG - 2022-06-27 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:06 --> Total execution time: 0.0481
DEBUG - 2022-06-27 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:06 --> Total execution time: 0.0620
DEBUG - 2022-06-27 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:06 --> Total execution time: 0.0450
DEBUG - 2022-06-27 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:07 --> Total execution time: 0.0523
DEBUG - 2022-06-27 02:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:17 --> Total execution time: 0.0498
DEBUG - 2022-06-27 02:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:21 --> Total execution time: 0.0906
DEBUG - 2022-06-27 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:25 --> Total execution time: 0.0703
DEBUG - 2022-06-27 02:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:21:34 --> Total execution time: 0.0471
DEBUG - 2022-06-27 02:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:22:03 --> Total execution time: 0.0486
DEBUG - 2022-06-27 02:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:22:49 --> Total execution time: 0.0485
DEBUG - 2022-06-27 02:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:23:20 --> Total execution time: 0.0438
DEBUG - 2022-06-27 02:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:23:30 --> Total execution time: 0.0451
DEBUG - 2022-06-27 02:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:24:47 --> Total execution time: 0.0496
DEBUG - 2022-06-27 02:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:24:52 --> Total execution time: 0.0469
DEBUG - 2022-06-27 02:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:55:39 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:25:39 --> Total execution time: 0.0549
DEBUG - 2022-06-27 02:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:25:50 --> Total execution time: 0.0535
DEBUG - 2022-06-27 02:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:04 --> Total execution time: 0.0657
DEBUG - 2022-06-27 02:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:06 --> Total execution time: 0.0538
DEBUG - 2022-06-27 02:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:10 --> Total execution time: 0.0604
DEBUG - 2022-06-27 02:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:13 --> Total execution time: 0.1090
DEBUG - 2022-06-27 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:20 --> Total execution time: 0.0569
DEBUG - 2022-06-27 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:20 --> Total execution time: 0.0619
DEBUG - 2022-06-27 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:26 --> Total execution time: 0.1241
DEBUG - 2022-06-27 02:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 02:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:26:54 --> Total execution time: 0.0588
DEBUG - 2022-06-27 02:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 02:59:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 02:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 02:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:29:20 --> Total execution time: 0.0652
DEBUG - 2022-06-27 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:30:02 --> Total execution time: 0.1119
DEBUG - 2022-06-27 03:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:01:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:31:04 --> Total execution time: 0.0413
DEBUG - 2022-06-27 03:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:02 --> Total execution time: 0.0585
DEBUG - 2022-06-27 03:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:10 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:10 --> Total execution time: 0.1097
DEBUG - 2022-06-27 03:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:13 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:13 --> Total execution time: 0.0483
DEBUG - 2022-06-27 03:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:19 --> Total execution time: 0.0553
DEBUG - 2022-06-27 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:36 --> Total execution time: 0.0488
DEBUG - 2022-06-27 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:38 --> Total execution time: 0.0446
DEBUG - 2022-06-27 03:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:43 --> Total execution time: 0.2030
DEBUG - 2022-06-27 03:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:03:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:33:25 --> Total execution time: 0.0623
DEBUG - 2022-06-27 03:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:33:25 --> Total execution time: 0.1342
DEBUG - 2022-06-27 03:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:33:36 --> Total execution time: 0.0462
DEBUG - 2022-06-27 03:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:35:57 --> Total execution time: 0.0559
DEBUG - 2022-06-27 03:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:37:37 --> Total execution time: 0.1624
DEBUG - 2022-06-27 03:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:21 --> Total execution time: 0.0466
DEBUG - 2022-06-27 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:23 --> Total execution time: 0.0526
DEBUG - 2022-06-27 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:23 --> Total execution time: 0.0441
DEBUG - 2022-06-27 03:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:40 --> Total execution time: 0.0524
DEBUG - 2022-06-27 03:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:49 --> Total execution time: 0.0559
DEBUG - 2022-06-27 03:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:52 --> Total execution time: 0.0600
DEBUG - 2022-06-27 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:54 --> Total execution time: 0.0538
DEBUG - 2022-06-27 03:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:30 --> Total execution time: 0.0479
DEBUG - 2022-06-27 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 03:10:07 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 03:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:40:09 --> Total execution time: 0.0501
DEBUG - 2022-06-27 03:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:21 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:40:21 --> Total execution time: 0.0488
DEBUG - 2022-06-27 03:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:40:23 --> Total execution time: 0.0544
DEBUG - 2022-06-27 03:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:40:23 --> Total execution time: 0.0518
DEBUG - 2022-06-27 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:40:24 --> Total execution time: 0.0520
DEBUG - 2022-06-27 03:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:10:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:40:25 --> Total execution time: 0.0658
DEBUG - 2022-06-27 03:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:41:34 --> Total execution time: 0.2483
DEBUG - 2022-06-27 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:46:03 --> Total execution time: 0.2172
DEBUG - 2022-06-27 03:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:46:07 --> Total execution time: 0.0677
DEBUG - 2022-06-27 03:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:18:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:48:09 --> Total execution time: 0.0375
DEBUG - 2022-06-27 03:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:18:10 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:48:10 --> Total execution time: 0.0387
DEBUG - 2022-06-27 03:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:48:15 --> Total execution time: 0.0348
DEBUG - 2022-06-27 03:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:48:22 --> Total execution time: 0.0493
DEBUG - 2022-06-27 03:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:48:28 --> Total execution time: 0.0523
DEBUG - 2022-06-27 03:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:49:40 --> Total execution time: 0.0626
DEBUG - 2022-06-27 03:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:49:50 --> Total execution time: 0.0549
DEBUG - 2022-06-27 03:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:49:57 --> Total execution time: 0.0450
DEBUG - 2022-06-27 03:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:50:06 --> Total execution time: 0.0753
DEBUG - 2022-06-27 03:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:50:25 --> Total execution time: 0.0680
DEBUG - 2022-06-27 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:20:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:50:35 --> Total execution time: 0.1183
DEBUG - 2022-06-27 03:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:50:37 --> Total execution time: 0.1127
DEBUG - 2022-06-27 03:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:50:49 --> Total execution time: 0.0677
DEBUG - 2022-06-27 03:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:21:28 --> Total execution time: 0.0847
DEBUG - 2022-06-27 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:21:34 --> Total execution time: 0.1057
DEBUG - 2022-06-27 03:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:51:52 --> Total execution time: 0.1106
DEBUG - 2022-06-27 03:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:52:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:52:29 --> Total execution time: 0.0844
DEBUG - 2022-06-27 03:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:52:39 --> Total execution time: 0.0599
DEBUG - 2022-06-27 03:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:52:41 --> Total execution time: 0.0584
DEBUG - 2022-06-27 03:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:52:56 --> Total execution time: 0.0551
DEBUG - 2022-06-27 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:53:32 --> Total execution time: 0.0672
DEBUG - 2022-06-27 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:55:08 --> Total execution time: 0.3114
DEBUG - 2022-06-27 03:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:26:25 --> Total execution time: 0.0919
DEBUG - 2022-06-27 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:57:20 --> Total execution time: 0.1418
DEBUG - 2022-06-27 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:28:10 --> Total execution time: 0.0512
DEBUG - 2022-06-27 03:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:19 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:19 --> Total execution time: 0.0439
DEBUG - 2022-06-27 03:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:20 --> Total execution time: 0.0291
DEBUG - 2022-06-27 03:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:32 --> Total execution time: 0.0451
DEBUG - 2022-06-27 03:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:28:38 --> Total execution time: 0.0707
DEBUG - 2022-06-27 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:40 --> Total execution time: 0.0711
DEBUG - 2022-06-27 03:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:54 --> Total execution time: 0.0717
DEBUG - 2022-06-27 03:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 03:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:58:55 --> Total execution time: 0.0656
DEBUG - 2022-06-27 03:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:59:40 --> Total execution time: 0.0448
DEBUG - 2022-06-27 03:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:59:41 --> Total execution time: 0.0657
DEBUG - 2022-06-27 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:59:55 --> Total execution time: 0.0841
DEBUG - 2022-06-27 03:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:00:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 03:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:00:35 --> Total execution time: 0.0580
DEBUG - 2022-06-27 03:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:31:16 --> Total execution time: 0.0477
DEBUG - 2022-06-27 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:31:25 --> Total execution time: 0.0722
DEBUG - 2022-06-27 03:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:31:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:01:32 --> Total execution time: 0.0402
DEBUG - 2022-06-27 03:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:01:55 --> Total execution time: 0.0329
DEBUG - 2022-06-27 03:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:32:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:02:10 --> Total execution time: 0.0615
DEBUG - 2022-06-27 03:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:03:16 --> Total execution time: 0.1134
DEBUG - 2022-06-27 03:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:03:36 --> Total execution time: 0.0975
DEBUG - 2022-06-27 03:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:03:39 --> Total execution time: 0.1393
DEBUG - 2022-06-27 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:03:43 --> Total execution time: 0.0694
DEBUG - 2022-06-27 03:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:04:00 --> Total execution time: 0.0813
DEBUG - 2022-06-27 03:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:04:05 --> Total execution time: 0.0682
DEBUG - 2022-06-27 03:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:04:12 --> Total execution time: 0.0916
DEBUG - 2022-06-27 03:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:04:58 --> Total execution time: 0.0609
DEBUG - 2022-06-27 03:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:05:08 --> Total execution time: 0.0672
DEBUG - 2022-06-27 03:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:05:13 --> Total execution time: 0.1217
DEBUG - 2022-06-27 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:05:58 --> Total execution time: 0.0735
DEBUG - 2022-06-27 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:06:05 --> Total execution time: 0.0837
DEBUG - 2022-06-27 03:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:06:16 --> Total execution time: 0.1096
DEBUG - 2022-06-27 03:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:03 --> Total execution time: 0.0730
DEBUG - 2022-06-27 03:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:10 --> Total execution time: 0.0420
DEBUG - 2022-06-27 03:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:25 --> Total execution time: 0.1182
DEBUG - 2022-06-27 03:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:30 --> Total execution time: 0.0881
DEBUG - 2022-06-27 03:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 14:07:34 --> Total execution time: 0.1133
DEBUG - 2022-06-27 03:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:34 --> Total execution time: 0.0836
DEBUG - 2022-06-27 03:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:34 --> Total execution time: 0.1180
DEBUG - 2022-06-27 03:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:07:49 --> Total execution time: 0.0513
DEBUG - 2022-06-27 03:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:08:03 --> Total execution time: 2.0429
DEBUG - 2022-06-27 03:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 03:38:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 03:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:08:09 --> Total execution time: 0.0799
DEBUG - 2022-06-27 03:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:08:24 --> Total execution time: 0.0554
DEBUG - 2022-06-27 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:08:44 --> Total execution time: 0.1391
DEBUG - 2022-06-27 03:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:40:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:10:01 --> Total execution time: 0.0537
DEBUG - 2022-06-27 03:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:40:07 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:10:07 --> Total execution time: 0.0369
DEBUG - 2022-06-27 03:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:13:27 --> Total execution time: 0.1891
DEBUG - 2022-06-27 03:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:43:53 --> Total execution time: 0.0330
DEBUG - 2022-06-27 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:43:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:13:56 --> Total execution time: 0.0354
DEBUG - 2022-06-27 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:13:58 --> Total execution time: 0.0698
DEBUG - 2022-06-27 03:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:14:04 --> Total execution time: 0.0912
DEBUG - 2022-06-27 03:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:14:05 --> Total execution time: 0.0811
DEBUG - 2022-06-27 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:14:23 --> Total execution time: 1.5475
DEBUG - 2022-06-27 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:14:44 --> Total execution time: 0.0536
DEBUG - 2022-06-27 03:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:15:21 --> Total execution time: 0.0781
DEBUG - 2022-06-27 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:45:26 --> Total execution time: 0.0551
DEBUG - 2022-06-27 03:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 14:15:47 --> Total execution time: 0.0564
DEBUG - 2022-06-27 03:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:15:47 --> Total execution time: 0.0741
DEBUG - 2022-06-27 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:15:49 --> Total execution time: 0.0574
DEBUG - 2022-06-27 03:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:15:51 --> Total execution time: 0.0689
DEBUG - 2022-06-27 03:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:16:05 --> Total execution time: 0.0429
DEBUG - 2022-06-27 03:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:46:25 --> Total execution time: 0.1199
DEBUG - 2022-06-27 03:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:16:42 --> Total execution time: 0.0905
DEBUG - 2022-06-27 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:03 --> Total execution time: 0.0423
DEBUG - 2022-06-27 03:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:07 --> Total execution time: 0.0471
DEBUG - 2022-06-27 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:15 --> Total execution time: 0.0519
DEBUG - 2022-06-27 03:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:20 --> Total execution time: 0.0513
DEBUG - 2022-06-27 03:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:24 --> Total execution time: 0.0727
DEBUG - 2022-06-27 03:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:27 --> Total execution time: 0.0844
DEBUG - 2022-06-27 03:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:39 --> Total execution time: 0.0556
DEBUG - 2022-06-27 03:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:41 --> Total execution time: 0.0856
DEBUG - 2022-06-27 03:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:43 --> Total execution time: 0.0663
DEBUG - 2022-06-27 03:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:45 --> Total execution time: 0.0454
DEBUG - 2022-06-27 03:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:48 --> Total execution time: 0.0428
DEBUG - 2022-06-27 03:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:17:56 --> Total execution time: 0.0964
DEBUG - 2022-06-27 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:18:08 --> Total execution time: 0.0870
DEBUG - 2022-06-27 03:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:18:26 --> Total execution time: 0.0504
DEBUG - 2022-06-27 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:18:53 --> Total execution time: 0.0612
DEBUG - 2022-06-27 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:00 --> Total execution time: 0.1267
DEBUG - 2022-06-27 03:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:01 --> Total execution time: 0.0525
DEBUG - 2022-06-27 03:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:13 --> Total execution time: 0.0544
DEBUG - 2022-06-27 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 03:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:15 --> Total execution time: 0.0457
DEBUG - 2022-06-27 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 14:19:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 14:19:16 --> Total execution time: 0.1940
DEBUG - 2022-06-27 03:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:19:40 --> Total execution time: 0.0328
DEBUG - 2022-06-27 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:50:14 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:20:14 --> Total execution time: 0.0357
DEBUG - 2022-06-27 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:50:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:20:15 --> Total execution time: 0.0400
DEBUG - 2022-06-27 03:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:50:27 --> No URI present. Default controller set.
DEBUG - 2022-06-27 03:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:20:27 --> Total execution time: 0.0538
DEBUG - 2022-06-27 03:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:20:42 --> Total execution time: 0.1101
DEBUG - 2022-06-27 03:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:20:45 --> Total execution time: 0.0731
DEBUG - 2022-06-27 03:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:20:47 --> Total execution time: 0.0741
DEBUG - 2022-06-27 03:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:21:10 --> Total execution time: 0.1748
DEBUG - 2022-06-27 03:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:51:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 03:51:22 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 03:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:51:40 --> Total execution time: 0.0510
DEBUG - 2022-06-27 03:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 03:51:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:51:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 03:51:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 03:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:51:50 --> Total execution time: 0.0774
DEBUG - 2022-06-27 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:22:29 --> Total execution time: 0.1002
DEBUG - 2022-06-27 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:22:34 --> Total execution time: 0.0605
DEBUG - 2022-06-27 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:22:35 --> Total execution time: 0.0567
DEBUG - 2022-06-27 03:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:23:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 03:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:23:06 --> Total execution time: 0.1163
DEBUG - 2022-06-27 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:24:20 --> Total execution time: 0.0542
DEBUG - 2022-06-27 03:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:27:53 --> Total execution time: 0.1606
DEBUG - 2022-06-27 03:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 03:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 03:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 03:58:32 --> Total execution time: 0.0555
DEBUG - 2022-06-27 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:30:02 --> Total execution time: 0.1610
DEBUG - 2022-06-27 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:31:50 --> Total execution time: 0.0435
DEBUG - 2022-06-27 04:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:32:47 --> Total execution time: 0.1075
DEBUG - 2022-06-27 04:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:37:41 --> Total execution time: 0.0933
DEBUG - 2022-06-27 04:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:38:04 --> Total execution time: 0.0339
DEBUG - 2022-06-27 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:38:05 --> Total execution time: 0.0522
DEBUG - 2022-06-27 04:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:38:33 --> Total execution time: 0.0393
DEBUG - 2022-06-27 04:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:38:33 --> Total execution time: 0.0385
DEBUG - 2022-06-27 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:08:45 --> Total execution time: 0.0365
DEBUG - 2022-06-27 04:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:08:47 --> Total execution time: 0.0542
DEBUG - 2022-06-27 04:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:08:47 --> Total execution time: 0.0800
DEBUG - 2022-06-27 04:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:40:34 --> Total execution time: 0.0476
DEBUG - 2022-06-27 04:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:40:52 --> Total execution time: 0.0529
DEBUG - 2022-06-27 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:41:07 --> Total execution time: 0.0675
DEBUG - 2022-06-27 04:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:41:13 --> Total execution time: 0.0940
DEBUG - 2022-06-27 04:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:41:32 --> Total execution time: 0.0673
DEBUG - 2022-06-27 04:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:42:33 --> Total execution time: 0.0455
DEBUG - 2022-06-27 04:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:13:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:43:34 --> Total execution time: 0.1796
DEBUG - 2022-06-27 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:13:38 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:43:38 --> Total execution time: 0.0803
DEBUG - 2022-06-27 04:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:43:44 --> Total execution time: 0.0468
DEBUG - 2022-06-27 04:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:44:02 --> Total execution time: 0.0707
DEBUG - 2022-06-27 04:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:44:25 --> Total execution time: 0.0487
DEBUG - 2022-06-27 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:44:44 --> Total execution time: 0.0661
DEBUG - 2022-06-27 04:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:45:11 --> Total execution time: 0.0605
DEBUG - 2022-06-27 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:45:16 --> Total execution time: 0.0568
DEBUG - 2022-06-27 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:45:19 --> Total execution time: 0.1421
DEBUG - 2022-06-27 04:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:45:57 --> Total execution time: 0.1171
DEBUG - 2022-06-27 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:46:12 --> Total execution time: 0.0551
DEBUG - 2022-06-27 04:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:46:24 --> Total execution time: 0.1311
DEBUG - 2022-06-27 04:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:46:27 --> Total execution time: 0.0586
DEBUG - 2022-06-27 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:46:56 --> Total execution time: 0.0836
DEBUG - 2022-06-27 04:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:47:03 --> Total execution time: 0.0590
DEBUG - 2022-06-27 04:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:47:18 --> Total execution time: 0.0557
DEBUG - 2022-06-27 04:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:47:24 --> Total execution time: 0.0517
DEBUG - 2022-06-27 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:47:58 --> Total execution time: 0.0534
DEBUG - 2022-06-27 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:06 --> Total execution time: 0.0463
DEBUG - 2022-06-27 04:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:17 --> Total execution time: 0.0504
DEBUG - 2022-06-27 04:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:20 --> Total execution time: 0.0623
DEBUG - 2022-06-27 04:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:23 --> Total execution time: 0.0846
DEBUG - 2022-06-27 04:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:25 --> Total execution time: 0.0664
DEBUG - 2022-06-27 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:29 --> Total execution time: 0.0770
DEBUG - 2022-06-27 04:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:34 --> Total execution time: 0.0740
DEBUG - 2022-06-27 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:39 --> Total execution time: 0.0496
DEBUG - 2022-06-27 04:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:40 --> Total execution time: 0.0588
DEBUG - 2022-06-27 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:44 --> Total execution time: 0.0572
DEBUG - 2022-06-27 04:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:47 --> Total execution time: 0.0496
DEBUG - 2022-06-27 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:50 --> Total execution time: 0.0896
DEBUG - 2022-06-27 04:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:56 --> Total execution time: 0.0483
DEBUG - 2022-06-27 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:48:57 --> Total execution time: 0.0610
DEBUG - 2022-06-27 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:19:32 --> Total execution time: 0.0551
DEBUG - 2022-06-27 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:49:37 --> Total execution time: 0.1792
DEBUG - 2022-06-27 04:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:19:40 --> Total execution time: 0.0946
DEBUG - 2022-06-27 04:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:01 --> Total execution time: 0.0792
DEBUG - 2022-06-27 04:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:33 --> Total execution time: 0.0417
DEBUG - 2022-06-27 04:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:37 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:37 --> Total execution time: 0.0346
DEBUG - 2022-06-27 04:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:43 --> Total execution time: 0.0557
DEBUG - 2022-06-27 04:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:43 --> Total execution time: 0.0476
DEBUG - 2022-06-27 04:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:54 --> Total execution time: 0.1311
DEBUG - 2022-06-27 04:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:56 --> Total execution time: 0.0506
DEBUG - 2022-06-27 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:58 --> Total execution time: 0.0510
DEBUG - 2022-06-27 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:50:59 --> Total execution time: 0.0601
DEBUG - 2022-06-27 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:00 --> Total execution time: 0.0530
DEBUG - 2022-06-27 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:00 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:00 --> Total execution time: 0.1114
DEBUG - 2022-06-27 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:09 --> Total execution time: 0.0642
DEBUG - 2022-06-27 04:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:21 --> Total execution time: 0.0555
DEBUG - 2022-06-27 04:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:23 --> Total execution time: 0.1387
DEBUG - 2022-06-27 04:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:25 --> Total execution time: 0.0704
DEBUG - 2022-06-27 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:29 --> Total execution time: 0.0548
DEBUG - 2022-06-27 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:36 --> Total execution time: 0.0529
DEBUG - 2022-06-27 04:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:44 --> Total execution time: 0.0491
DEBUG - 2022-06-27 04:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:51 --> Total execution time: 0.0496
DEBUG - 2022-06-27 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:55 --> Total execution time: 0.1398
DEBUG - 2022-06-27 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:51:56 --> Total execution time: 0.0796
DEBUG - 2022-06-27 04:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:04 --> Total execution time: 0.1155
DEBUG - 2022-06-27 04:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:05 --> Total execution time: 0.1008
DEBUG - 2022-06-27 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:13 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:13 --> Total execution time: 0.0340
DEBUG - 2022-06-27 04:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:36 --> Total execution time: 0.0570
DEBUG - 2022-06-27 04:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:37 --> Total execution time: 0.0555
DEBUG - 2022-06-27 04:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:45 --> Total execution time: 0.0494
DEBUG - 2022-06-27 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:46 --> Total execution time: 0.0579
DEBUG - 2022-06-27 04:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 14:52:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 14:52:47 --> Total execution time: 0.2147
DEBUG - 2022-06-27 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:52:49 --> Total execution time: 0.0579
DEBUG - 2022-06-27 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:53:03 --> Total execution time: 0.0719
DEBUG - 2022-06-27 04:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:53:12 --> Total execution time: 0.0547
DEBUG - 2022-06-27 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:23:21 --> Total execution time: 0.0479
DEBUG - 2022-06-27 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:53:23 --> Total execution time: 0.0631
DEBUG - 2022-06-27 04:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:53:35 --> Total execution time: 0.0510
DEBUG - 2022-06-27 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:53:39 --> Total execution time: 0.0830
DEBUG - 2022-06-27 04:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:54:16 --> Total execution time: 0.0494
DEBUG - 2022-06-27 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:54:17 --> Total execution time: 0.0464
DEBUG - 2022-06-27 04:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:28:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:58:41 --> Total execution time: 0.1057
DEBUG - 2022-06-27 04:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 04:28:57 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:29:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:59:15 --> Total execution time: 0.0399
DEBUG - 2022-06-27 04:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:01:04 --> Total execution time: 0.1698
DEBUG - 2022-06-27 04:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:01:21 --> Total execution time: 0.1279
DEBUG - 2022-06-27 04:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:01:33 --> Total execution time: 0.0549
DEBUG - 2022-06-27 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:01:40 --> Total execution time: 0.0734
DEBUG - 2022-06-27 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 04:31:48 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 04:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:01:49 --> Total execution time: 0.0476
DEBUG - 2022-06-27 04:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:02:36 --> Total execution time: 0.0334
DEBUG - 2022-06-27 04:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:02:58 --> Total execution time: 0.0544
DEBUG - 2022-06-27 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:03:10 --> Total execution time: 0.1335
DEBUG - 2022-06-27 04:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:33:51 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:03:51 --> Total execution time: 0.1033
DEBUG - 2022-06-27 04:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 04:34:13 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 04:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:35:21 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:05:21 --> Total execution time: 0.0356
DEBUG - 2022-06-27 04:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:37:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 04:37:11 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 04:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 04:37:12 --> 404 Page Not Found: Humanstxt/index
DEBUG - 2022-06-27 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 04:37:13 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-27 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:37:14 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:07:14 --> Total execution time: 0.0318
DEBUG - 2022-06-27 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:08:39 --> Total execution time: 0.0486
DEBUG - 2022-06-27 04:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:39:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:09:11 --> Total execution time: 0.1198
DEBUG - 2022-06-27 04:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:10:43 --> Total execution time: 0.0448
DEBUG - 2022-06-27 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:12:23 --> Total execution time: 0.0640
DEBUG - 2022-06-27 04:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:16:54 --> Total execution time: 0.0767
DEBUG - 2022-06-27 04:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:48:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:18:33 --> Total execution time: 0.0388
DEBUG - 2022-06-27 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:19:20 --> Total execution time: 0.0581
DEBUG - 2022-06-27 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:19:21 --> Total execution time: 0.0900
DEBUG - 2022-06-27 04:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:49:34 --> Total execution time: 0.0502
DEBUG - 2022-06-27 04:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:35 --> Total execution time: 0.0560
DEBUG - 2022-06-27 04:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:49:35 --> Total execution time: 0.0659
DEBUG - 2022-06-27 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:19:43 --> Total execution time: 0.0493
DEBUG - 2022-06-27 04:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:19:56 --> Total execution time: 0.0488
DEBUG - 2022-06-27 04:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:20:03 --> Total execution time: 0.0526
DEBUG - 2022-06-27 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:20:11 --> Total execution time: 0.0550
DEBUG - 2022-06-27 04:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:20:17 --> Total execution time: 0.0506
DEBUG - 2022-06-27 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:20:20 --> Total execution time: 0.0499
DEBUG - 2022-06-27 04:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:20:30 --> Total execution time: 0.0707
DEBUG - 2022-06-27 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:50:57 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:20:57 --> Total execution time: 0.0379
DEBUG - 2022-06-27 04:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:51:06 --> Total execution time: 0.0486
DEBUG - 2022-06-27 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:21:15 --> Total execution time: 0.0497
DEBUG - 2022-06-27 04:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:21:39 --> Total execution time: 0.0508
DEBUG - 2022-06-27 04:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:21:42 --> Total execution time: 0.0783
DEBUG - 2022-06-27 04:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:22:08 --> Total execution time: 0.0574
DEBUG - 2022-06-27 04:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:53:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 04:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:23:23 --> Total execution time: 0.0759
DEBUG - 2022-06-27 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:26:16 --> Total execution time: 0.1643
DEBUG - 2022-06-27 04:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:57:04 --> Total execution time: 0.0627
DEBUG - 2022-06-27 04:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:57:34 --> Total execution time: 0.1210
DEBUG - 2022-06-27 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:28:25 --> Total execution time: 0.1224
DEBUG - 2022-06-27 04:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:28:27 --> Total execution time: 0.0454
DEBUG - 2022-06-27 04:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:28:29 --> Total execution time: 0.0468
DEBUG - 2022-06-27 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:28:39 --> Total execution time: 0.0599
DEBUG - 2022-06-27 04:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 04:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 04:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 04:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:29:36 --> Total execution time: 0.0685
DEBUG - 2022-06-27 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:30:03 --> Total execution time: 0.1199
DEBUG - 2022-06-27 05:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:00:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:30:26 --> Total execution time: 0.0490
DEBUG - 2022-06-27 05:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:30:33 --> Total execution time: 0.0398
DEBUG - 2022-06-27 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:30:50 --> Total execution time: 0.0499
DEBUG - 2022-06-27 05:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 05:00:52 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 05:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:31:02 --> Total execution time: 0.0713
DEBUG - 2022-06-27 05:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:31:10 --> Total execution time: 0.0683
DEBUG - 2022-06-27 05:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:01:59 --> Total execution time: 0.0655
DEBUG - 2022-06-27 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:02:06 --> Total execution time: 0.0757
DEBUG - 2022-06-27 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:33:18 --> Total execution time: 0.0515
DEBUG - 2022-06-27 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:33:49 --> Total execution time: 0.0457
DEBUG - 2022-06-27 05:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:00 --> Total execution time: 0.0554
DEBUG - 2022-06-27 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:04 --> Total execution time: 0.0741
DEBUG - 2022-06-27 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:11 --> Total execution time: 0.1203
DEBUG - 2022-06-27 05:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:11 --> Total execution time: 0.0611
DEBUG - 2022-06-27 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:14 --> Total execution time: 0.0482
DEBUG - 2022-06-27 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:17 --> Total execution time: 0.0472
DEBUG - 2022-06-27 05:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:21 --> Total execution time: 0.0510
DEBUG - 2022-06-27 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:25 --> Total execution time: 0.0543
DEBUG - 2022-06-27 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:34:27 --> Total execution time: 0.0531
DEBUG - 2022-06-27 05:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:36:34 --> Total execution time: 0.1790
DEBUG - 2022-06-27 05:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:36:41 --> Total execution time: 0.0457
DEBUG - 2022-06-27 05:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:36:57 --> Total execution time: 0.0655
DEBUG - 2022-06-27 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:36:58 --> Total execution time: 0.0483
DEBUG - 2022-06-27 05:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:37:03 --> Total execution time: 0.0561
DEBUG - 2022-06-27 05:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:37:06 --> Total execution time: 0.0615
DEBUG - 2022-06-27 05:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:37:13 --> Total execution time: 0.0638
DEBUG - 2022-06-27 05:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:38:39 --> Total execution time: 0.1882
DEBUG - 2022-06-27 05:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:39:12 --> Total execution time: 0.0614
DEBUG - 2022-06-27 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:11:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:41:58 --> Total execution time: 0.0786
DEBUG - 2022-06-27 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:42:11 --> Total execution time: 0.0614
DEBUG - 2022-06-27 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:42:18 --> Total execution time: 0.0542
DEBUG - 2022-06-27 05:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:42:25 --> Total execution time: 0.0583
DEBUG - 2022-06-27 05:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:42:26 --> Total execution time: 0.0670
DEBUG - 2022-06-27 05:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:42:36 --> Total execution time: 0.0620
DEBUG - 2022-06-27 05:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:43:02 --> Total execution time: 0.0512
DEBUG - 2022-06-27 05:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:13:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:43:23 --> Total execution time: 0.0358
DEBUG - 2022-06-27 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:43:27 --> Total execution time: 0.0358
DEBUG - 2022-06-27 05:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:19:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:49:20 --> Total execution time: 0.1379
DEBUG - 2022-06-27 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:19:34 --> Total execution time: 0.0476
DEBUG - 2022-06-27 05:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:19:42 --> Total execution time: 0.0576
DEBUG - 2022-06-27 05:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:49:56 --> Total execution time: 0.0362
DEBUG - 2022-06-27 05:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:20:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:50:17 --> Total execution time: 0.0482
DEBUG - 2022-06-27 05:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:22:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:52:18 --> Total execution time: 0.0534
DEBUG - 2022-06-27 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:22:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:52:25 --> Total execution time: 0.0619
DEBUG - 2022-06-27 05:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:59:17 --> Total execution time: 0.0997
DEBUG - 2022-06-27 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:02:24 --> Total execution time: 0.0525
DEBUG - 2022-06-27 05:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:37:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:03 --> Total execution time: 0.0946
DEBUG - 2022-06-27 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:02 --> Total execution time: 0.0656
DEBUG - 2022-06-27 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:39 --> Total execution time: 0.1257
DEBUG - 2022-06-27 05:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:44 --> Total execution time: 0.0897
DEBUG - 2022-06-27 05:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:57 --> Total execution time: 0.0684
DEBUG - 2022-06-27 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:12 --> Total execution time: 0.1303
DEBUG - 2022-06-27 05:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:24 --> Total execution time: 0.0722
DEBUG - 2022-06-27 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:40 --> Total execution time: 0.0505
DEBUG - 2022-06-27 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:41 --> Total execution time: 0.0624
DEBUG - 2022-06-27 05:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:51 --> Total execution time: 0.0520
DEBUG - 2022-06-27 05:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:56 --> Total execution time: 0.0499
DEBUG - 2022-06-27 05:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:59 --> Total execution time: 0.0548
DEBUG - 2022-06-27 05:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:09 --> Total execution time: 0.0509
DEBUG - 2022-06-27 05:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:14 --> Total execution time: 0.0477
DEBUG - 2022-06-27 05:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:19 --> Total execution time: 0.0594
DEBUG - 2022-06-27 05:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:24 --> Total execution time: 0.0582
DEBUG - 2022-06-27 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:35 --> Total execution time: 0.0812
DEBUG - 2022-06-27 05:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:41 --> Total execution time: 0.0615
DEBUG - 2022-06-27 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:12:45 --> Total execution time: 0.0500
DEBUG - 2022-06-27 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:13:04 --> Total execution time: 0.0560
DEBUG - 2022-06-27 05:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:13:17 --> Total execution time: 0.0657
DEBUG - 2022-06-27 05:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:43:19 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:13:19 --> Total execution time: 0.0451
DEBUG - 2022-06-27 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:13:25 --> Total execution time: 0.1252
DEBUG - 2022-06-27 05:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:13:40 --> Total execution time: 0.0464
DEBUG - 2022-06-27 05:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:14:24 --> Total execution time: 0.0799
DEBUG - 2022-06-27 05:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:14:30 --> Total execution time: 0.0509
DEBUG - 2022-06-27 05:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:14:33 --> Total execution time: 0.0583
DEBUG - 2022-06-27 05:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:14:43 --> Total execution time: 0.0498
DEBUG - 2022-06-27 05:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:46:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:16:04 --> Total execution time: 0.0532
DEBUG - 2022-06-27 05:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:46:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:16:05 --> Total execution time: 0.0477
DEBUG - 2022-06-27 05:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:46:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:16:16 --> Total execution time: 0.0448
DEBUG - 2022-06-27 05:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:08 --> Total execution time: 0.0691
DEBUG - 2022-06-27 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:11 --> Total execution time: 0.0455
DEBUG - 2022-06-27 05:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:25 --> Total execution time: 0.0804
DEBUG - 2022-06-27 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:31 --> Total execution time: 0.0413
DEBUG - 2022-06-27 05:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:37 --> Total execution time: 0.0497
DEBUG - 2022-06-27 05:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:41 --> Total execution time: 0.0582
DEBUG - 2022-06-27 05:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:44 --> Total execution time: 0.0567
DEBUG - 2022-06-27 05:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:18:59 --> Total execution time: 0.0479
DEBUG - 2022-06-27 05:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:19:04 --> Total execution time: 0.0487
DEBUG - 2022-06-27 05:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:19:09 --> Total execution time: 0.0585
DEBUG - 2022-06-27 05:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:19:29 --> Total execution time: 0.1367
DEBUG - 2022-06-27 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:19:37 --> Total execution time: 0.0707
DEBUG - 2022-06-27 05:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 05:49:49 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-27 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 05:49:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 05:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:22:45 --> Total execution time: 0.1256
DEBUG - 2022-06-27 05:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:22:55 --> Total execution time: 0.0507
DEBUG - 2022-06-27 05:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:22:55 --> Total execution time: 0.1314
DEBUG - 2022-06-27 05:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:22:58 --> Total execution time: 0.0718
DEBUG - 2022-06-27 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:23:19 --> Total execution time: 0.0733
DEBUG - 2022-06-27 05:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:23:56 --> Total execution time: 0.0812
DEBUG - 2022-06-27 05:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:24:15 --> Total execution time: 0.0750
DEBUG - 2022-06-27 05:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:56:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:26:03 --> Total execution time: 0.0409
DEBUG - 2022-06-27 05:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:56:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:26:12 --> Total execution time: 0.0602
DEBUG - 2022-06-27 05:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:26:59 --> Total execution time: 0.0755
DEBUG - 2022-06-27 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:58:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:28:55 --> Total execution time: 0.0341
DEBUG - 2022-06-27 05:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:28:59 --> Total execution time: 0.0488
DEBUG - 2022-06-27 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:29:09 --> Total execution time: 0.0324
DEBUG - 2022-06-27 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:29:33 --> Total execution time: 0.0564
DEBUG - 2022-06-27 05:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:29:46 --> Total execution time: 0.0486
DEBUG - 2022-06-27 05:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 05:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:29:47 --> Total execution time: 0.0524
DEBUG - 2022-06-27 05:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:29:51 --> Total execution time: 0.0803
DEBUG - 2022-06-27 05:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 05:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 05:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:29:59 --> Total execution time: 0.2418
DEBUG - 2022-06-27 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:30:02 --> Total execution time: 0.1093
DEBUG - 2022-06-27 06:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:30:36 --> Total execution time: 0.0515
DEBUG - 2022-06-27 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:01:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:31:30 --> Total execution time: 0.0342
DEBUG - 2022-06-27 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:01:44 --> Total execution time: 0.0486
DEBUG - 2022-06-27 06:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:01:49 --> Total execution time: 0.0735
DEBUG - 2022-06-27 06:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:01:49 --> Total execution time: 0.1311
DEBUG - 2022-06-27 06:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:32:22 --> Total execution time: 0.1377
DEBUG - 2022-06-27 06:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:33:06 --> Total execution time: 0.0583
DEBUG - 2022-06-27 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:35:36 --> Total execution time: 0.0459
DEBUG - 2022-06-27 06:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:06:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:36:28 --> Total execution time: 0.0347
DEBUG - 2022-06-27 06:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:06:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:36:39 --> Total execution time: 1.9411
DEBUG - 2022-06-27 06:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:06:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:36:40 --> Total execution time: 0.0674
DEBUG - 2022-06-27 06:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:06:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 06:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:36:50 --> Total execution time: 0.0556
DEBUG - 2022-06-27 06:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:25 --> Total execution time: 0.0682
DEBUG - 2022-06-27 06:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:28 --> Total execution time: 0.1627
DEBUG - 2022-06-27 06:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:44 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:44 --> Total execution time: 0.1623
DEBUG - 2022-06-27 06:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 06:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:47 --> Total execution time: 0.1135
DEBUG - 2022-06-27 06:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:50 --> Total execution time: 0.0696
DEBUG - 2022-06-27 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:53 --> Total execution time: 0.0660
DEBUG - 2022-06-27 06:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 16:37:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 16:37:54 --> Total execution time: 0.1953
DEBUG - 2022-06-27 06:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:55 --> Total execution time: 0.0798
DEBUG - 2022-06-27 06:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:37:58 --> Total execution time: 0.0511
DEBUG - 2022-06-27 06:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:03 --> Total execution time: 0.1028
DEBUG - 2022-06-27 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:05 --> Total execution time: 0.1415
DEBUG - 2022-06-27 06:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:06 --> Total execution time: 0.0755
DEBUG - 2022-06-27 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:10 --> Total execution time: 0.0642
DEBUG - 2022-06-27 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:10 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:10 --> Total execution time: 0.1169
DEBUG - 2022-06-27 06:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:18 --> Total execution time: 0.0491
DEBUG - 2022-06-27 06:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:23 --> Total execution time: 0.0552
DEBUG - 2022-06-27 06:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:29 --> Total execution time: 0.1084
DEBUG - 2022-06-27 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:32 --> Total execution time: 0.0493
DEBUG - 2022-06-27 06:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:38:42 --> Total execution time: 0.0515
DEBUG - 2022-06-27 06:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:09:00 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:39:00 --> Total execution time: 0.0343
DEBUG - 2022-06-27 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:09:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:39:09 --> Total execution time: 0.0345
DEBUG - 2022-06-27 06:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:39:10 --> Total execution time: 0.0462
DEBUG - 2022-06-27 06:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:39:18 --> Total execution time: 0.0464
DEBUG - 2022-06-27 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:10:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:40:50 --> Total execution time: 0.0529
DEBUG - 2022-06-27 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:40:50 --> Total execution time: 0.0485
DEBUG - 2022-06-27 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:10:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:40:50 --> Total execution time: 0.0366
DEBUG - 2022-06-27 06:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:40:58 --> Total execution time: 0.0994
DEBUG - 2022-06-27 06:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:41:07 --> Total execution time: 0.0393
DEBUG - 2022-06-27 06:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:41:16 --> Total execution time: 0.0659
DEBUG - 2022-06-27 06:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:41:20 --> Total execution time: 0.0314
DEBUG - 2022-06-27 06:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:42:20 --> Total execution time: 0.0878
DEBUG - 2022-06-27 06:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:43:05 --> Total execution time: 0.0466
DEBUG - 2022-06-27 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:44:07 --> Total execution time: 0.1261
DEBUG - 2022-06-27 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:07 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:44:07 --> Total execution time: 0.1147
DEBUG - 2022-06-27 06:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:44:15 --> Total execution time: 0.0517
DEBUG - 2022-06-27 06:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:44:34 --> Total execution time: 0.0476
DEBUG - 2022-06-27 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:44:45 --> Total execution time: 0.0876
DEBUG - 2022-06-27 06:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:18:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:48:47 --> Total execution time: 0.0639
DEBUG - 2022-06-27 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:49:06 --> Total execution time: 0.0509
DEBUG - 2022-06-27 06:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:19:40 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 06:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:19:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:49:49 --> Total execution time: 0.0334
DEBUG - 2022-06-27 06:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:19:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:49:56 --> Total execution time: 0.0476
DEBUG - 2022-06-27 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:19:57 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:49:57 --> Total execution time: 0.0530
DEBUG - 2022-06-27 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:50:07 --> Total execution time: 0.0441
DEBUG - 2022-06-27 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:50:16 --> Total execution time: 0.0643
DEBUG - 2022-06-27 06:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:50:29 --> Total execution time: 0.0970
DEBUG - 2022-06-27 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:50:36 --> Total execution time: 0.0733
DEBUG - 2022-06-27 06:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:50:46 --> Total execution time: 0.0787
DEBUG - 2022-06-27 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:50:59 --> Total execution time: 0.0723
DEBUG - 2022-06-27 06:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:51:20 --> Total execution time: 0.0539
DEBUG - 2022-06-27 06:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:21:38 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:51:38 --> Total execution time: 0.0831
DEBUG - 2022-06-27 06:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:51:38 --> Total execution time: 0.1128
DEBUG - 2022-06-27 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:52:06 --> Total execution time: 0.1056
DEBUG - 2022-06-27 06:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:52:19 --> Total execution time: 0.0778
DEBUG - 2022-06-27 06:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:22:34 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 06:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:52:39 --> Total execution time: 0.0644
DEBUG - 2022-06-27 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:52:42 --> Total execution time: 0.0763
DEBUG - 2022-06-27 06:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:53:47 --> Total execution time: 0.0460
DEBUG - 2022-06-27 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:54:02 --> Total execution time: 0.1643
DEBUG - 2022-06-27 06:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:54:03 --> Total execution time: 0.0519
DEBUG - 2022-06-27 06:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:54:08 --> Total execution time: 0.0565
DEBUG - 2022-06-27 06:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:54:11 --> Total execution time: 0.0547
DEBUG - 2022-06-27 06:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:54:17 --> Total execution time: 0.0656
DEBUG - 2022-06-27 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:25:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:25:00 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 06:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:55:09 --> Total execution time: 0.0459
DEBUG - 2022-06-27 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:55:48 --> Total execution time: 0.1319
DEBUG - 2022-06-27 06:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:55:55 --> Total execution time: 0.0529
DEBUG - 2022-06-27 06:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:55:59 --> Total execution time: 0.0568
DEBUG - 2022-06-27 06:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:26:03 --> Total execution time: 0.0472
DEBUG - 2022-06-27 06:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:08 --> Total execution time: 0.0564
DEBUG - 2022-06-27 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:11 --> Total execution time: 0.0639
DEBUG - 2022-06-27 06:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:25 --> Total execution time: 0.0540
DEBUG - 2022-06-27 06:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:33 --> Total execution time: 0.0362
DEBUG - 2022-06-27 06:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:33 --> Total execution time: 0.0521
DEBUG - 2022-06-27 06:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:40 --> Total execution time: 0.0773
DEBUG - 2022-06-27 06:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:56:44 --> Total execution time: 0.0565
DEBUG - 2022-06-27 06:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:57:01 --> Total execution time: 0.0473
DEBUG - 2022-06-27 06:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:57:19 --> Total execution time: 0.0460
DEBUG - 2022-06-27 06:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:57:37 --> Total execution time: 0.0418
DEBUG - 2022-06-27 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:57:50 --> Total execution time: 0.0384
DEBUG - 2022-06-27 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:57:53 --> Total execution time: 0.0357
DEBUG - 2022-06-27 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:13 --> Total execution time: 0.0577
DEBUG - 2022-06-27 06:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:16 --> Total execution time: 0.0497
DEBUG - 2022-06-27 06:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:18 --> Total execution time: 0.0592
DEBUG - 2022-06-27 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:29 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:29 --> Total execution time: 0.0483
DEBUG - 2022-06-27 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:30 --> Total execution time: 0.0459
DEBUG - 2022-06-27 06:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:35 --> Total execution time: 0.0469
DEBUG - 2022-06-27 06:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:36 --> Total execution time: 0.0447
DEBUG - 2022-06-27 06:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:39 --> Total execution time: 0.0443
DEBUG - 2022-06-27 06:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:46 --> Total execution time: 0.0528
DEBUG - 2022-06-27 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:58:51 --> Total execution time: 0.0812
DEBUG - 2022-06-27 06:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:59:03 --> Total execution time: 0.0755
DEBUG - 2022-06-27 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:32:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:02:33 --> Total execution time: 0.1349
DEBUG - 2022-06-27 06:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:02:37 --> Total execution time: 0.0538
DEBUG - 2022-06-27 06:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:02:39 --> Total execution time: 0.0527
DEBUG - 2022-06-27 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:02:47 --> Total execution time: 0.0521
DEBUG - 2022-06-27 06:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:02:53 --> Total execution time: 0.0704
DEBUG - 2022-06-27 06:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:03:07 --> Total execution time: 0.1154
DEBUG - 2022-06-27 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:03:09 --> Total execution time: 0.0540
DEBUG - 2022-06-27 06:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:03:11 --> Total execution time: 0.0548
DEBUG - 2022-06-27 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:03:17 --> Total execution time: 0.0446
DEBUG - 2022-06-27 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:04:37 --> Total execution time: 0.0499
DEBUG - 2022-06-27 06:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:04:46 --> Total execution time: 0.0450
DEBUG - 2022-06-27 06:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:08:58 --> Total execution time: 0.1075
DEBUG - 2022-06-27 06:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:10:54 --> Total execution time: 0.1398
DEBUG - 2022-06-27 06:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:11:53 --> Total execution time: 0.0600
DEBUG - 2022-06-27 06:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:14:14 --> Total execution time: 0.1754
DEBUG - 2022-06-27 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:14:22 --> Total execution time: 0.0857
DEBUG - 2022-06-27 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:15:00 --> Total execution time: 0.0523
DEBUG - 2022-06-27 06:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:15:09 --> Total execution time: 0.0634
DEBUG - 2022-06-27 06:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:13 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:15:13 --> Total execution time: 0.0387
DEBUG - 2022-06-27 06:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:15:23 --> Total execution time: 0.0472
DEBUG - 2022-06-27 06:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:15:36 --> Total execution time: 0.0597
DEBUG - 2022-06-27 06:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:15:44 --> Total execution time: 0.0719
DEBUG - 2022-06-27 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:16:08 --> Total execution time: 0.1059
DEBUG - 2022-06-27 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:16:11 --> Total execution time: 0.0492
DEBUG - 2022-06-27 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:46:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:16:23 --> Total execution time: 0.0507
DEBUG - 2022-06-27 06:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:46:37 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:16:37 --> Total execution time: 0.0491
DEBUG - 2022-06-27 06:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:17:02 --> Total execution time: 2.0518
DEBUG - 2022-06-27 06:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:47:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:47:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 06:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:07 --> Total execution time: 1.5254
DEBUG - 2022-06-27 06:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:48:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 06:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:29 --> Total execution time: 1.4974
DEBUG - 2022-06-27 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:30 --> Total execution time: 0.0457
DEBUG - 2022-06-27 06:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:33 --> Total execution time: 0.0506
DEBUG - 2022-06-27 06:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:33 --> Total execution time: 0.0524
DEBUG - 2022-06-27 06:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:40 --> Total execution time: 0.0598
DEBUG - 2022-06-27 06:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:18:43 --> Total execution time: 0.0712
DEBUG - 2022-06-27 06:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:31 --> No URI present. Default controller set.
DEBUG - 2022-06-27 06:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:20:31 --> Total execution time: 0.1470
DEBUG - 2022-06-27 17:20:31 --> Total execution time: 0.1309
DEBUG - 2022-06-27 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:20:39 --> Total execution time: 0.0488
DEBUG - 2022-06-27 06:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:20:49 --> Total execution time: 0.0673
DEBUG - 2022-06-27 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:20:52 --> Total execution time: 0.0732
DEBUG - 2022-06-27 06:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:20:59 --> Total execution time: 0.0896
DEBUG - 2022-06-27 06:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:21:00 --> Total execution time: 0.0320
DEBUG - 2022-06-27 06:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:21:16 --> Total execution time: 0.0547
DEBUG - 2022-06-27 06:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:21:55 --> Total execution time: 0.0568
DEBUG - 2022-06-27 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:22:25 --> Total execution time: 0.0507
DEBUG - 2022-06-27 06:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 06:52:26 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 06:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:22:33 --> Total execution time: 0.0486
DEBUG - 2022-06-27 06:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:22:46 --> Total execution time: 0.0701
DEBUG - 2022-06-27 06:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:22:50 --> Total execution time: 0.0555
DEBUG - 2022-06-27 06:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:00 --> Total execution time: 0.0569
DEBUG - 2022-06-27 06:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 06:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:02 --> Total execution time: 0.0489
DEBUG - 2022-06-27 06:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:06 --> Total execution time: 0.0550
DEBUG - 2022-06-27 06:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:07 --> Total execution time: 0.0698
DEBUG - 2022-06-27 06:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:23 --> Total execution time: 0.1079
DEBUG - 2022-06-27 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:33 --> Total execution time: 0.0312
DEBUG - 2022-06-27 06:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:48 --> Total execution time: 0.0498
DEBUG - 2022-06-27 06:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:23:53 --> Total execution time: 0.0541
DEBUG - 2022-06-27 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:24:31 --> Total execution time: 0.0517
DEBUG - 2022-06-27 06:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:24:33 --> Total execution time: 0.0835
DEBUG - 2022-06-27 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:24:56 --> Total execution time: 0.1036
DEBUG - 2022-06-27 06:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:27:00 --> Total execution time: 0.0980
DEBUG - 2022-06-27 06:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:28:01 --> Total execution time: 0.0838
DEBUG - 2022-06-27 06:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:28:02 --> Total execution time: 0.1190
DEBUG - 2022-06-27 06:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:28:11 --> Total execution time: 0.1039
DEBUG - 2022-06-27 06:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:28:15 --> Total execution time: 0.0896
DEBUG - 2022-06-27 06:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 06:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:28:22 --> Total execution time: 0.0798
DEBUG - 2022-06-27 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:30:04 --> Total execution time: 0.1328
DEBUG - 2022-06-27 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:00:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:30:40 --> Total execution time: 0.0643
DEBUG - 2022-06-27 07:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:01:16 --> Total execution time: 0.0350
DEBUG - 2022-06-27 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:01:18 --> Total execution time: 0.0896
DEBUG - 2022-06-27 07:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:01:18 --> Total execution time: 0.1403
DEBUG - 2022-06-27 07:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:02:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:32:04 --> Total execution time: 0.0575
DEBUG - 2022-06-27 07:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:02:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:32:05 --> Total execution time: 0.0363
DEBUG - 2022-06-27 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 07:02:52 --> 404 Page Not Found: Src/environments
DEBUG - 2022-06-27 07:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:03:09 --> Total execution time: 0.0343
DEBUG - 2022-06-27 07:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:03:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:33:11 --> Total execution time: 0.0510
DEBUG - 2022-06-27 07:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:05:10 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:35:10 --> Total execution time: 0.1501
DEBUG - 2022-06-27 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:35:19 --> Total execution time: 0.0714
DEBUG - 2022-06-27 07:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 07:05:31 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-27 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:36:55 --> Total execution time: 0.0361
DEBUG - 2022-06-27 07:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:38:33 --> Total execution time: 0.0708
DEBUG - 2022-06-27 07:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:38:39 --> Total execution time: 0.0521
DEBUG - 2022-06-27 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:38:47 --> Total execution time: 0.0546
DEBUG - 2022-06-27 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:38:52 --> Total execution time: 0.0649
DEBUG - 2022-06-27 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:38:56 --> Total execution time: 0.0627
DEBUG - 2022-06-27 07:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:39:04 --> Total execution time: 0.0577
DEBUG - 2022-06-27 07:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:43:26 --> Total execution time: 0.0489
DEBUG - 2022-06-27 07:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:43:32 --> Total execution time: 0.0493
DEBUG - 2022-06-27 07:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:43:47 --> Total execution time: 0.0553
DEBUG - 2022-06-27 07:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:43:51 --> Total execution time: 0.0542
DEBUG - 2022-06-27 07:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:43:53 --> Total execution time: 0.0840
DEBUG - 2022-06-27 07:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:46:43 --> Total execution time: 0.1117
DEBUG - 2022-06-27 07:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:47:07 --> Total execution time: 0.0687
DEBUG - 2022-06-27 07:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 07:17:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:17:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:47:30 --> Total execution time: 0.0628
DEBUG - 2022-06-27 07:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 07:17:33 --> 404 Page Not Found: Wp-includes/ID3
DEBUG - 2022-06-27 07:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 07:17:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 07:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:19:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:08 --> Total execution time: 0.0685
DEBUG - 2022-06-27 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:09 --> Total execution time: 0.1260
DEBUG - 2022-06-27 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:09 --> Total execution time: 0.0578
DEBUG - 2022-06-27 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:13 --> Total execution time: 0.0596
DEBUG - 2022-06-27 07:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:22 --> Total execution time: 0.0514
DEBUG - 2022-06-27 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:54:38 --> Total execution time: 0.1107
DEBUG - 2022-06-27 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:54:40 --> Total execution time: 0.0721
DEBUG - 2022-06-27 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:25:26 --> Total execution time: 0.0495
DEBUG - 2022-06-27 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:25:28 --> Total execution time: 0.0353
DEBUG - 2022-06-27 07:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:25:29 --> Total execution time: 0.0353
DEBUG - 2022-06-27 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:27:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:57:34 --> Total execution time: 0.1343
DEBUG - 2022-06-27 07:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:30:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:00:28 --> Total execution time: 0.0948
DEBUG - 2022-06-27 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:00:32 --> Total execution time: 0.0326
DEBUG - 2022-06-27 07:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:00:44 --> Total execution time: 0.0648
DEBUG - 2022-06-27 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:00:51 --> Total execution time: 0.0645
DEBUG - 2022-06-27 07:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:00:53 --> Total execution time: 0.0539
DEBUG - 2022-06-27 07:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:01:00 --> Total execution time: 0.0743
DEBUG - 2022-06-27 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:31:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:01:29 --> Total execution time: 0.0387
DEBUG - 2022-06-27 07:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:01:55 --> Total execution time: 0.0547
DEBUG - 2022-06-27 07:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:02:19 --> Total execution time: 0.0317
DEBUG - 2022-06-27 07:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:02:49 --> Total execution time: 0.0977
DEBUG - 2022-06-27 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:02:59 --> Total execution time: 0.0462
DEBUG - 2022-06-27 07:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:03:22 --> Total execution time: 0.0551
DEBUG - 2022-06-27 07:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:01 --> Total execution time: 0.0642
DEBUG - 2022-06-27 07:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:18 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:18 --> Total execution time: 0.0404
DEBUG - 2022-06-27 07:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:18 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:18 --> Total execution time: 0.0468
DEBUG - 2022-06-27 07:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:21 --> Total execution time: 0.0320
DEBUG - 2022-06-27 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:32 --> Total execution time: 0.0557
DEBUG - 2022-06-27 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:36 --> Total execution time: 0.1570
DEBUG - 2022-06-27 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:38 --> Total execution time: 0.1221
DEBUG - 2022-06-27 07:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:43 --> Total execution time: 0.0513
DEBUG - 2022-06-27 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:44 --> Total execution time: 0.0671
DEBUG - 2022-06-27 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:46 --> Total execution time: 0.0516
DEBUG - 2022-06-27 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:34:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:04:46 --> Total execution time: 0.0511
DEBUG - 2022-06-27 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:35:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:05:28 --> Total execution time: 0.0537
DEBUG - 2022-06-27 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:05:57 --> Total execution time: 1.8430
DEBUG - 2022-06-27 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:36:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 07:36:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:06:29 --> Total execution time: 0.0565
DEBUG - 2022-06-27 07:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:06:58 --> Total execution time: 0.0618
DEBUG - 2022-06-27 07:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:37:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:07:15 --> Total execution time: 0.0486
DEBUG - 2022-06-27 07:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:07:19 --> Total execution time: 0.0352
DEBUG - 2022-06-27 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:37:35 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:07:35 --> Total execution time: 0.0366
DEBUG - 2022-06-27 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:07:50 --> Total execution time: 0.0518
DEBUG - 2022-06-27 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:04 --> Total execution time: 0.0575
DEBUG - 2022-06-27 07:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:06 --> Total execution time: 0.0450
DEBUG - 2022-06-27 07:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:26 --> Total execution time: 0.0529
DEBUG - 2022-06-27 07:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:36 --> Total execution time: 0.0462
DEBUG - 2022-06-27 07:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:45 --> Total execution time: 0.0460
DEBUG - 2022-06-27 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:49 --> Total execution time: 0.0553
DEBUG - 2022-06-27 07:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:08:51 --> Total execution time: 0.0573
DEBUG - 2022-06-27 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:09:02 --> Total execution time: 0.0709
DEBUG - 2022-06-27 07:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:09:07 --> Total execution time: 0.0568
DEBUG - 2022-06-27 07:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:09:21 --> Total execution time: 0.0974
DEBUG - 2022-06-27 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:14 --> Total execution time: 0.0696
DEBUG - 2022-06-27 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:21 --> Total execution time: 0.0531
DEBUG - 2022-06-27 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:22 --> Total execution time: 0.0474
DEBUG - 2022-06-27 07:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:40 --> Total execution time: 0.0554
DEBUG - 2022-06-27 07:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:47 --> Total execution time: 0.0704
DEBUG - 2022-06-27 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:48 --> Total execution time: 0.0446
DEBUG - 2022-06-27 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:48 --> Total execution time: 0.0537
DEBUG - 2022-06-27 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:49 --> Total execution time: 0.0487
DEBUG - 2022-06-27 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:56 --> Total execution time: 0.0556
DEBUG - 2022-06-27 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:10:58 --> Total execution time: 0.0584
DEBUG - 2022-06-27 07:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:11:02 --> Total execution time: 0.0596
DEBUG - 2022-06-27 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:11:10 --> Total execution time: 0.0576
DEBUG - 2022-06-27 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:41:52 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:11:52 --> Total execution time: 0.1317
DEBUG - 2022-06-27 07:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:12:08 --> Total execution time: 0.0760
DEBUG - 2022-06-27 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:42:49 --> Total execution time: 0.0559
DEBUG - 2022-06-27 07:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:42:51 --> Total execution time: 0.0570
DEBUG - 2022-06-27 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:42:51 --> Total execution time: 0.0950
DEBUG - 2022-06-27 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:44:31 --> Total execution time: 0.0682
DEBUG - 2022-06-27 07:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:44:38 --> Total execution time: 0.1637
DEBUG - 2022-06-27 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:44:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:14:57 --> Total execution time: 1.5108
DEBUG - 2022-06-27 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:15:04 --> Total execution time: 0.1077
DEBUG - 2022-06-27 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:15:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 07:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:15:49 --> Total execution time: 0.0528
DEBUG - 2022-06-27 07:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:15:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 18:15:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 18:15:51 --> Total execution time: 0.2144
DEBUG - 2022-06-27 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:15:52 --> Total execution time: 0.0520
DEBUG - 2022-06-27 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:11 --> Total execution time: 0.0491
DEBUG - 2022-06-27 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:19 --> Total execution time: 0.1632
DEBUG - 2022-06-27 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:27 --> Total execution time: 0.0589
DEBUG - 2022-06-27 07:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:28 --> Total execution time: 0.0425
DEBUG - 2022-06-27 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:29 --> Total execution time: 0.0426
DEBUG - 2022-06-27 07:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:32 --> Total execution time: 0.0494
DEBUG - 2022-06-27 07:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:46:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:16:36 --> Total execution time: 0.0372
DEBUG - 2022-06-27 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:17:42 --> Total execution time: 0.0522
DEBUG - 2022-06-27 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:17:42 --> Total execution time: 0.0609
DEBUG - 2022-06-27 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:17:42 --> Total execution time: 0.0623
DEBUG - 2022-06-27 07:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:17:43 --> Total execution time: 0.0922
DEBUG - 2022-06-27 07:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:17:52 --> Total execution time: 0.0583
DEBUG - 2022-06-27 07:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:18:10 --> Total execution time: 0.1134
DEBUG - 2022-06-27 07:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:18:13 --> Total execution time: 0.0662
DEBUG - 2022-06-27 07:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:18:25 --> Total execution time: 0.0764
DEBUG - 2022-06-27 07:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:18:56 --> Total execution time: 0.0553
DEBUG - 2022-06-27 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:49:31 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:19:31 --> Total execution time: 0.0372
DEBUG - 2022-06-27 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:21:03 --> Total execution time: 0.1422
DEBUG - 2022-06-27 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:22:50 --> Total execution time: 0.1184
DEBUG - 2022-06-27 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:22:52 --> Total execution time: 0.0477
DEBUG - 2022-06-27 07:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 18:23:09 --> Total execution time: 1.9251
DEBUG - 2022-06-27 07:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:23:10 --> Total execution time: 1.8018
DEBUG - 2022-06-27 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:23:12 --> Total execution time: 0.0624
DEBUG - 2022-06-27 07:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:23:23 --> Total execution time: 0.0548
DEBUG - 2022-06-27 07:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:23:29 --> Total execution time: 0.0589
DEBUG - 2022-06-27 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:23:39 --> Total execution time: 0.0553
DEBUG - 2022-06-27 07:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:23:49 --> Total execution time: 0.0587
DEBUG - 2022-06-27 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:24:07 --> Total execution time: 0.0769
DEBUG - 2022-06-27 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:24:32 --> Total execution time: 0.1061
DEBUG - 2022-06-27 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:24:41 --> Total execution time: 0.0437
DEBUG - 2022-06-27 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:24:42 --> Total execution time: 0.0451
DEBUG - 2022-06-27 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:24:54 --> Total execution time: 0.0810
DEBUG - 2022-06-27 07:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:25:27 --> Total execution time: 0.0550
DEBUG - 2022-06-27 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:25:32 --> Total execution time: 0.0510
DEBUG - 2022-06-27 07:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:25:47 --> Total execution time: 0.0507
DEBUG - 2022-06-27 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:25:49 --> Total execution time: 0.0695
DEBUG - 2022-06-27 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:26:01 --> Total execution time: 0.0771
DEBUG - 2022-06-27 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:26:21 --> Total execution time: 0.0643
DEBUG - 2022-06-27 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:26:35 --> Total execution time: 0.0679
DEBUG - 2022-06-27 07:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:26:50 --> Total execution time: 0.0574
DEBUG - 2022-06-27 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:26:53 --> Total execution time: 0.0803
DEBUG - 2022-06-27 07:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:27:07 --> Total execution time: 0.0555
DEBUG - 2022-06-27 07:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:31 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:27:31 --> Total execution time: 0.0495
DEBUG - 2022-06-27 07:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:27:32 --> Total execution time: 0.0389
DEBUG - 2022-06-27 07:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:57:40 --> Total execution time: 0.0329
DEBUG - 2022-06-27 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:57:42 --> Total execution time: 0.0590
DEBUG - 2022-06-27 07:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:57:42 --> Total execution time: 0.1260
DEBUG - 2022-06-27 07:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:27:45 --> Total execution time: 0.0895
DEBUG - 2022-06-27 07:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 07:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:03 --> Total execution time: 0.0645
DEBUG - 2022-06-27 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:06 --> Total execution time: 0.0799
DEBUG - 2022-06-27 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:07 --> Total execution time: 0.0490
DEBUG - 2022-06-27 07:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:10 --> Total execution time: 0.0460
DEBUG - 2022-06-27 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:11 --> Total execution time: 0.0564
DEBUG - 2022-06-27 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:11 --> Total execution time: 0.1103
DEBUG - 2022-06-27 07:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:13 --> Total execution time: 0.0614
DEBUG - 2022-06-27 07:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:21 --> Total execution time: 0.0725
DEBUG - 2022-06-27 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:25 --> Total execution time: 0.0532
DEBUG - 2022-06-27 07:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:33 --> Total execution time: 0.0519
DEBUG - 2022-06-27 07:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:37 --> Total execution time: 0.0513
DEBUG - 2022-06-27 07:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 07:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:43 --> Total execution time: 0.0491
DEBUG - 2022-06-27 07:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 07:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 07:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:28:53 --> Total execution time: 0.0513
DEBUG - 2022-06-27 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:04 --> Total execution time: 0.0882
DEBUG - 2022-06-27 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:04 --> Total execution time: 0.1300
DEBUG - 2022-06-27 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:10 --> Total execution time: 0.0855
DEBUG - 2022-06-27 08:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:13 --> Total execution time: 0.0796
DEBUG - 2022-06-27 08:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:30 --> Total execution time: 0.0522
DEBUG - 2022-06-27 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:41 --> Total execution time: 0.0465
DEBUG - 2022-06-27 08:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:00:44 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:30:44 --> Total execution time: 0.0371
DEBUG - 2022-06-27 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:03:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:33:04 --> Total execution time: 0.0594
DEBUG - 2022-06-27 08:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:33:10 --> Total execution time: 0.0623
DEBUG - 2022-06-27 08:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:33:53 --> Total execution time: 0.0600
DEBUG - 2022-06-27 08:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:34:20 --> Total execution time: 0.0958
DEBUG - 2022-06-27 08:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:04:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:34:26 --> Total execution time: 0.1162
DEBUG - 2022-06-27 08:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:34:35 --> Total execution time: 0.0617
DEBUG - 2022-06-27 08:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:34:48 --> Total execution time: 0.0756
DEBUG - 2022-06-27 08:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:34:57 --> Total execution time: 0.0515
DEBUG - 2022-06-27 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:04 --> Total execution time: 0.1388
DEBUG - 2022-06-27 08:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:15 --> Total execution time: 0.0652
DEBUG - 2022-06-27 08:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:20 --> Total execution time: 0.0545
DEBUG - 2022-06-27 08:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:24 --> Total execution time: 0.1088
DEBUG - 2022-06-27 08:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:33 --> Total execution time: 0.0504
DEBUG - 2022-06-27 08:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:36 --> Total execution time: 0.0579
DEBUG - 2022-06-27 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:48 --> Total execution time: 0.0871
DEBUG - 2022-06-27 08:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:35:56 --> Total execution time: 0.0488
DEBUG - 2022-06-27 08:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:36:00 --> Total execution time: 0.0721
DEBUG - 2022-06-27 08:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:36:08 --> Total execution time: 0.0521
DEBUG - 2022-06-27 08:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:36:16 --> Total execution time: 0.0597
DEBUG - 2022-06-27 08:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:36:27 --> Total execution time: 0.0644
DEBUG - 2022-06-27 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:07:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:37:23 --> Total execution time: 0.0491
DEBUG - 2022-06-27 08:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:07:27 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:37:27 --> Total execution time: 0.0514
DEBUG - 2022-06-27 08:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:37:57 --> Total execution time: 0.0959
DEBUG - 2022-06-27 08:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:38:06 --> Total execution time: 0.1382
DEBUG - 2022-06-27 08:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 08:08:28 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 08:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 08:11:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:12:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:42:47 --> Total execution time: 0.1136
DEBUG - 2022-06-27 08:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:12:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:42:48 --> Total execution time: 0.0416
DEBUG - 2022-06-27 08:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:42:53 --> Total execution time: 0.0559
DEBUG - 2022-06-27 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:13:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:43:05 --> Total execution time: 0.0573
DEBUG - 2022-06-27 08:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 08:13:38 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 08:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:15:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:45:47 --> Total execution time: 0.1044
DEBUG - 2022-06-27 08:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:46:28 --> Total execution time: 0.0590
DEBUG - 2022-06-27 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:46:41 --> Total execution time: 0.1492
DEBUG - 2022-06-27 08:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:47:03 --> Total execution time: 0.0521
DEBUG - 2022-06-27 08:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:47:07 --> Total execution time: 0.0549
DEBUG - 2022-06-27 08:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:47:12 --> Total execution time: 0.0556
DEBUG - 2022-06-27 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:47:25 --> Total execution time: 0.0546
DEBUG - 2022-06-27 08:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:47:49 --> Total execution time: 0.0547
DEBUG - 2022-06-27 08:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:47:58 --> Total execution time: 0.0517
DEBUG - 2022-06-27 08:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:48:03 --> Total execution time: 0.0874
DEBUG - 2022-06-27 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:48:13 --> Total execution time: 0.0489
DEBUG - 2022-06-27 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:48:29 --> Total execution time: 0.0524
DEBUG - 2022-06-27 08:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:48:41 --> Total execution time: 0.0930
DEBUG - 2022-06-27 08:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:48:46 --> Total execution time: 0.0864
DEBUG - 2022-06-27 08:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:48:57 --> Total execution time: 0.0515
DEBUG - 2022-06-27 08:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:19:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:49:03 --> Total execution time: 0.0516
DEBUG - 2022-06-27 08:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:49:03 --> Total execution time: 0.1357
DEBUG - 2022-06-27 08:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:49:08 --> Total execution time: 0.0575
DEBUG - 2022-06-27 08:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:50:20 --> Total execution time: 0.0502
DEBUG - 2022-06-27 08:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:50:21 --> Total execution time: 0.0462
DEBUG - 2022-06-27 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:50:28 --> Total execution time: 0.0527
DEBUG - 2022-06-27 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:50:32 --> Total execution time: 0.0499
DEBUG - 2022-06-27 08:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:51:19 --> Total execution time: 0.1183
DEBUG - 2022-06-27 08:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:51:39 --> Total execution time: 0.0555
DEBUG - 2022-06-27 08:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:52:25 --> Total execution time: 0.0693
DEBUG - 2022-06-27 08:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:11 --> Total execution time: 0.0450
DEBUG - 2022-06-27 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:14 --> Total execution time: 0.0455
DEBUG - 2022-06-27 08:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:18 --> Total execution time: 0.0495
DEBUG - 2022-06-27 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:29 --> Total execution time: 0.0719
DEBUG - 2022-06-27 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:29 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:29 --> Total execution time: 0.0855
DEBUG - 2022-06-27 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:50 --> Total execution time: 0.0569
DEBUG - 2022-06-27 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:52 --> Total execution time: 0.0340
DEBUG - 2022-06-27 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:53 --> Total execution time: 0.0758
DEBUG - 2022-06-27 08:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:10 --> Total execution time: 0.0649
DEBUG - 2022-06-27 08:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:13 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:13 --> Total execution time: 0.0342
DEBUG - 2022-06-27 08:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:21 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:21 --> Total execution time: 0.0541
DEBUG - 2022-06-27 08:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:26 --> Total execution time: 0.0688
DEBUG - 2022-06-27 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:33 --> Total execution time: 0.0389
DEBUG - 2022-06-27 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:35 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:35 --> Total execution time: 0.0488
DEBUG - 2022-06-27 08:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:38 --> Total execution time: 0.0402
DEBUG - 2022-06-27 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:40 --> Total execution time: 0.0513
DEBUG - 2022-06-27 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:41 --> Total execution time: 0.0394
DEBUG - 2022-06-27 08:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:42 --> Total execution time: 0.0549
DEBUG - 2022-06-27 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:43 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:43 --> Total execution time: 0.0653
DEBUG - 2022-06-27 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:46 --> Total execution time: 0.0710
DEBUG - 2022-06-27 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:54:50 --> Total execution time: 0.0554
DEBUG - 2022-06-27 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:55:09 --> Total execution time: 0.0456
DEBUG - 2022-06-27 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:55:11 --> Total execution time: 0.0435
DEBUG - 2022-06-27 08:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:25:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:55:48 --> Total execution time: 0.0352
DEBUG - 2022-06-27 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:55:53 --> Total execution time: 0.0343
DEBUG - 2022-06-27 08:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:56:01 --> Total execution time: 0.0868
DEBUG - 2022-06-27 08:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:56:13 --> Total execution time: 0.0781
DEBUG - 2022-06-27 08:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:26:37 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:56:37 --> Total execution time: 0.0397
DEBUG - 2022-06-27 08:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:26:37 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:56:37 --> Total execution time: 0.0334
DEBUG - 2022-06-27 08:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:26:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:56:56 --> Total execution time: 0.0524
DEBUG - 2022-06-27 08:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:57:10 --> Total execution time: 0.0550
DEBUG - 2022-06-27 08:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:12 --> Total execution time: 0.0546
DEBUG - 2022-06-27 08:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:20 --> Total execution time: 0.0514
DEBUG - 2022-06-27 08:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:49 --> Total execution time: 0.0353
DEBUG - 2022-06-27 08:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:53 --> Total execution time: 0.0451
DEBUG - 2022-06-27 08:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:54 --> Total execution time: 0.0328
DEBUG - 2022-06-27 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:55 --> Total execution time: 0.0532
DEBUG - 2022-06-27 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:55 --> Total execution time: 0.0379
DEBUG - 2022-06-27 08:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:55 --> Total execution time: 0.0588
DEBUG - 2022-06-27 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:09 --> Total execution time: 0.0566
DEBUG - 2022-06-27 08:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:20 --> Total execution time: 0.0552
DEBUG - 2022-06-27 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:29 --> Total execution time: 0.0554
DEBUG - 2022-06-27 08:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:38 --> Total execution time: 0.0486
DEBUG - 2022-06-27 08:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:39 --> Total execution time: 0.0601
DEBUG - 2022-06-27 08:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:40 --> Total execution time: 0.0259
DEBUG - 2022-06-27 08:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:43 --> Total execution time: 0.0549
DEBUG - 2022-06-27 08:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:45 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:45 --> Total execution time: 0.1107
DEBUG - 2022-06-27 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:46 --> Total execution time: 0.0501
DEBUG - 2022-06-27 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:46 --> Total execution time: 0.0505
DEBUG - 2022-06-27 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:47 --> Total execution time: 0.0751
DEBUG - 2022-06-27 08:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:50 --> Total execution time: 0.0522
DEBUG - 2022-06-27 08:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:51 --> Total execution time: 0.0809
DEBUG - 2022-06-27 08:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:53 --> Total execution time: 0.0316
DEBUG - 2022-06-27 08:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:54 --> Total execution time: 0.1102
DEBUG - 2022-06-27 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:55 --> Total execution time: 0.1004
DEBUG - 2022-06-27 08:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:59:59 --> Total execution time: 0.0951
DEBUG - 2022-06-27 08:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:01 --> Total execution time: 0.0318
DEBUG - 2022-06-27 08:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:08 --> Total execution time: 0.1019
DEBUG - 2022-06-27 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:12 --> Total execution time: 0.0369
DEBUG - 2022-06-27 08:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:12 --> Total execution time: 0.0434
DEBUG - 2022-06-27 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:15 --> Total execution time: 0.1197
DEBUG - 2022-06-27 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:15 --> Total execution time: 0.0669
DEBUG - 2022-06-27 08:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:21 --> Total execution time: 0.0521
DEBUG - 2022-06-27 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:22 --> Total execution time: 0.1468
DEBUG - 2022-06-27 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:24 --> Total execution time: 0.0397
DEBUG - 2022-06-27 08:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:37 --> Total execution time: 0.0537
DEBUG - 2022-06-27 08:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:42 --> Total execution time: 0.0325
DEBUG - 2022-06-27 08:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:49 --> Total execution time: 0.0710
DEBUG - 2022-06-27 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:56 --> Total execution time: 0.1347
DEBUG - 2022-06-27 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:56 --> Total execution time: 0.0515
DEBUG - 2022-06-27 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:00:58 --> Total execution time: 0.0338
DEBUG - 2022-06-27 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:03 --> Total execution time: 0.0836
DEBUG - 2022-06-27 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:03 --> Total execution time: 0.0535
DEBUG - 2022-06-27 08:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:05 --> Total execution time: 0.0353
DEBUG - 2022-06-27 08:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:12 --> Total execution time: 0.0860
DEBUG - 2022-06-27 08:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:13 --> Total execution time: 0.0903
DEBUG - 2022-06-27 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:22 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:22 --> Total execution time: 0.0538
DEBUG - 2022-06-27 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:26 --> Total execution time: 0.0502
DEBUG - 2022-06-27 08:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:27 --> Total execution time: 0.0526
DEBUG - 2022-06-27 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:28 --> Total execution time: 0.0538
DEBUG - 2022-06-27 08:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:28 --> Total execution time: 0.0953
DEBUG - 2022-06-27 08:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:33 --> Total execution time: 0.0785
DEBUG - 2022-06-27 08:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:33 --> Total execution time: 0.0466
DEBUG - 2022-06-27 08:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:43 --> Total execution time: 0.0682
DEBUG - 2022-06-27 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:46 --> Total execution time: 0.0526
DEBUG - 2022-06-27 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:48 --> Total execution time: 0.0486
DEBUG - 2022-06-27 08:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:51 --> Total execution time: 0.0658
DEBUG - 2022-06-27 08:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:01:58 --> Total execution time: 0.0722
DEBUG - 2022-06-27 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:32:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:02:05 --> Total execution time: 0.0538
DEBUG - 2022-06-27 08:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:06:35 --> Total execution time: 0.0490
DEBUG - 2022-06-27 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 08:39:03 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 08:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:17:22 --> Total execution time: 0.3024
DEBUG - 2022-06-27 08:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:19:01 --> Total execution time: 0.0604
DEBUG - 2022-06-27 08:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:19:05 --> Total execution time: 0.0432
DEBUG - 2022-06-27 08:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:19:09 --> Total execution time: 0.0570
DEBUG - 2022-06-27 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 08:49:42 --> 404 Page Not Found: Assets/images
DEBUG - 2022-06-27 08:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:19:49 --> Total execution time: 0.0487
DEBUG - 2022-06-27 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:19:57 --> Total execution time: 0.0465
DEBUG - 2022-06-27 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:20:17 --> Total execution time: 0.0558
DEBUG - 2022-06-27 08:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:20:22 --> Total execution time: 0.0521
DEBUG - 2022-06-27 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:20:28 --> Total execution time: 0.0688
DEBUG - 2022-06-27 08:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:20:40 --> Total execution time: 0.0459
DEBUG - 2022-06-27 08:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:20:44 --> Total execution time: 0.0452
DEBUG - 2022-06-27 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:50:59 --> No URI present. Default controller set.
DEBUG - 2022-06-27 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:20:59 --> Total execution time: 0.0537
DEBUG - 2022-06-27 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 08:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 08:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 08:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:21:33 --> Total execution time: 0.0628
DEBUG - 2022-06-27 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:30:03 --> Total execution time: 0.5313
DEBUG - 2022-06-27 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:04:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:54 --> Total execution time: 0.1451
DEBUG - 2022-06-27 09:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:35:06 --> Total execution time: 0.0374
DEBUG - 2022-06-27 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:35:15 --> Total execution time: 0.0989
DEBUG - 2022-06-27 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:35:28 --> Total execution time: 0.0669
DEBUG - 2022-06-27 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:35:36 --> Total execution time: 0.0525
DEBUG - 2022-06-27 09:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:35:56 --> Total execution time: 0.1907
DEBUG - 2022-06-27 09:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:36:14 --> Total execution time: 0.0556
DEBUG - 2022-06-27 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:37:08 --> Total execution time: 0.0561
DEBUG - 2022-06-27 09:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:38:36 --> Total execution time: 0.0547
DEBUG - 2022-06-27 09:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:16:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:46:40 --> Total execution time: 0.1019
DEBUG - 2022-06-27 09:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:52:35 --> Total execution time: 0.1132
DEBUG - 2022-06-27 09:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:25:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:55:11 --> Total execution time: 0.0959
DEBUG - 2022-06-27 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:25:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:55:12 --> Total execution time: 0.0395
DEBUG - 2022-06-27 09:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:55:44 --> Total execution time: 0.0464
DEBUG - 2022-06-27 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:55:52 --> Total execution time: 0.0666
DEBUG - 2022-06-27 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:56:13 --> Total execution time: 0.0685
DEBUG - 2022-06-27 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:56:14 --> Total execution time: 0.0750
DEBUG - 2022-06-27 09:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:56:30 --> Total execution time: 0.0679
DEBUG - 2022-06-27 09:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:56:36 --> Total execution time: 0.0454
DEBUG - 2022-06-27 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:57:57 --> Total execution time: 0.0485
DEBUG - 2022-06-27 09:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:58:13 --> Total execution time: 0.0467
DEBUG - 2022-06-27 09:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:58:28 --> Total execution time: 0.0616
DEBUG - 2022-06-27 09:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:58:31 --> Total execution time: 0.0817
DEBUG - 2022-06-27 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:58:52 --> Total execution time: 0.0924
DEBUG - 2022-06-27 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:58:59 --> Total execution time: 0.0770
DEBUG - 2022-06-27 09:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:29:44 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:59:44 --> Total execution time: 0.1425
DEBUG - 2022-06-27 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:59:48 --> Total execution time: 0.0652
DEBUG - 2022-06-27 09:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:59:55 --> Total execution time: 0.0764
DEBUG - 2022-06-27 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:00:03 --> Total execution time: 0.1090
DEBUG - 2022-06-27 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:30:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:00:03 --> Total execution time: 0.1139
DEBUG - 2022-06-27 09:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:33:45 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:03:45 --> Total execution time: 0.1393
DEBUG - 2022-06-27 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:03:50 --> Total execution time: 0.1161
DEBUG - 2022-06-27 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:03:53 --> Total execution time: 0.0574
DEBUG - 2022-06-27 09:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:03:56 --> Total execution time: 0.0603
DEBUG - 2022-06-27 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:04:00 --> Total execution time: 0.0609
DEBUG - 2022-06-27 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:04:02 --> Total execution time: 0.0480
DEBUG - 2022-06-27 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:39:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:48 --> Total execution time: 0.2270
DEBUG - 2022-06-27 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:49 --> Total execution time: 0.0466
DEBUG - 2022-06-27 09:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:15:06 --> Total execution time: 0.1071
DEBUG - 2022-06-27 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:15:36 --> Total execution time: 0.0402
DEBUG - 2022-06-27 09:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:15:39 --> Total execution time: 0.0618
DEBUG - 2022-06-27 09:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:15:40 --> Total execution time: 0.0447
DEBUG - 2022-06-27 09:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:15:51 --> Total execution time: 0.0512
DEBUG - 2022-06-27 09:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:07 --> Total execution time: 0.0540
DEBUG - 2022-06-27 09:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:36 --> Total execution time: 0.0481
DEBUG - 2022-06-27 09:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:47 --> Total execution time: 0.0588
DEBUG - 2022-06-27 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:57 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:57 --> Total execution time: 0.0379
DEBUG - 2022-06-27 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:46:57 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:57 --> Total execution time: 0.0440
DEBUG - 2022-06-27 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:18:25 --> Total execution time: 0.0580
DEBUG - 2022-06-27 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:19:04 --> Total execution time: 0.0500
DEBUG - 2022-06-27 09:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:49:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:19:23 --> Total execution time: 0.0416
DEBUG - 2022-06-27 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:49:35 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:19:35 --> Total execution time: 0.0491
DEBUG - 2022-06-27 09:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:49:50 --> Total execution time: 0.0511
DEBUG - 2022-06-27 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:49:53 --> Total execution time: 0.1024
DEBUG - 2022-06-27 09:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:49:53 --> Total execution time: 0.1203
DEBUG - 2022-06-27 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:50:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:20:49 --> Total execution time: 1.8740
DEBUG - 2022-06-27 09:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 09:50:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:52:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:22:01 --> Total execution time: 0.0376
DEBUG - 2022-06-27 09:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:22:06 --> Total execution time: 0.0335
DEBUG - 2022-06-27 09:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:22:20 --> Total execution time: 0.0544
DEBUG - 2022-06-27 09:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:22:37 --> Total execution time: 0.0317
DEBUG - 2022-06-27 09:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:22:43 --> Total execution time: 0.1587
DEBUG - 2022-06-27 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:23:01 --> Total execution time: 0.0903
DEBUG - 2022-06-27 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:23:26 --> Total execution time: 0.0494
DEBUG - 2022-06-27 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 09:56:25 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:57:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 09:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:27:03 --> Total execution time: 0.0945
DEBUG - 2022-06-27 09:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:27:06 --> Total execution time: 0.0348
DEBUG - 2022-06-27 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:27:13 --> Total execution time: 0.0577
DEBUG - 2022-06-27 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:27:18 --> Total execution time: 0.0535
DEBUG - 2022-06-27 09:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:59:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 09:59:15 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:29:35 --> Total execution time: 0.0666
DEBUG - 2022-06-27 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:30:02 --> Total execution time: 0.1723
DEBUG - 2022-06-27 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:31:31 --> Total execution time: 0.0897
DEBUG - 2022-06-27 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:01:41 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:31:41 --> Total execution time: 0.0644
DEBUG - 2022-06-27 10:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:01:42 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 10:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:32:52 --> Total execution time: 0.0601
DEBUG - 2022-06-27 10:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:01 --> Total execution time: 0.0568
DEBUG - 2022-06-27 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:06 --> Total execution time: 0.0694
DEBUG - 2022-06-27 10:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:09 --> Total execution time: 0.0583
DEBUG - 2022-06-27 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:14 --> Total execution time: 0.0469
DEBUG - 2022-06-27 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:32 --> Total execution time: 0.0509
DEBUG - 2022-06-27 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:34 --> Total execution time: 0.0535
DEBUG - 2022-06-27 10:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:33:41 --> Total execution time: 0.0451
DEBUG - 2022-06-27 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:34:38 --> Total execution time: 0.1161
DEBUG - 2022-06-27 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:05:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:35:08 --> Total execution time: 0.1835
DEBUG - 2022-06-27 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:35:31 --> Total execution time: 0.0613
DEBUG - 2022-06-27 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:05:43 --> Total execution time: 0.0535
DEBUG - 2022-06-27 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:05:44 --> Total execution time: 0.0527
DEBUG - 2022-06-27 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:05:44 --> Total execution time: 0.0454
DEBUG - 2022-06-27 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:05:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:35:58 --> Total execution time: 0.0463
DEBUG - 2022-06-27 10:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:06:07 --> Total execution time: 0.0473
DEBUG - 2022-06-27 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:06:08 --> Total execution time: 0.0569
DEBUG - 2022-06-27 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:06:08 --> Total execution time: 0.0866
DEBUG - 2022-06-27 10:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:36:38 --> Total execution time: 0.0626
DEBUG - 2022-06-27 10:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:37:17 --> Total execution time: 0.0554
DEBUG - 2022-06-27 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:07:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:37:34 --> Total execution time: 0.0358
DEBUG - 2022-06-27 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:07:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:37:34 --> Total execution time: 0.0349
DEBUG - 2022-06-27 10:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:07:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:37:58 --> Total execution time: 0.0411
DEBUG - 2022-06-27 10:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:09 --> Total execution time: 0.0603
DEBUG - 2022-06-27 10:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:08:09 --> Total execution time: 0.0698
DEBUG - 2022-06-27 10:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:08:12 --> Total execution time: 0.0469
DEBUG - 2022-06-27 10:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:08:12 --> Total execution time: 0.0774
DEBUG - 2022-06-27 10:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:16 --> Total execution time: 0.1001
DEBUG - 2022-06-27 10:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:29 --> Total execution time: 0.0546
DEBUG - 2022-06-27 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:30 --> Total execution time: 0.0681
DEBUG - 2022-06-27 10:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:43 --> Total execution time: 0.0726
DEBUG - 2022-06-27 10:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:47 --> Total execution time: 0.0711
DEBUG - 2022-06-27 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:53 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:53 --> Total execution time: 0.0473
DEBUG - 2022-06-27 10:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:08:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:56 --> Total execution time: 0.0528
DEBUG - 2022-06-27 10:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:03 --> Total execution time: 0.0658
DEBUG - 2022-06-27 10:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:04 --> Total execution time: 0.0514
DEBUG - 2022-06-27 10:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:08 --> Total execution time: 0.0832
DEBUG - 2022-06-27 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:13 --> Total execution time: 0.0765
DEBUG - 2022-06-27 10:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:20 --> Total execution time: 0.0370
DEBUG - 2022-06-27 10:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:41 --> Total execution time: 0.0437
DEBUG - 2022-06-27 10:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:47 --> Total execution time: 0.0542
DEBUG - 2022-06-27 10:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:54 --> Total execution time: 0.0396
DEBUG - 2022-06-27 10:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:56 --> Total execution time: 0.0623
DEBUG - 2022-06-27 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:40:05 --> Total execution time: 0.1202
DEBUG - 2022-06-27 10:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:40:16 --> Total execution time: 0.1002
DEBUG - 2022-06-27 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:40:21 --> Total execution time: 0.0748
DEBUG - 2022-06-27 10:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:40:26 --> Total execution time: 0.0514
DEBUG - 2022-06-27 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:40:29 --> Total execution time: 0.0514
DEBUG - 2022-06-27 10:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:40:53 --> Total execution time: 0.0430
DEBUG - 2022-06-27 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:00 --> Total execution time: 0.0656
DEBUG - 2022-06-27 10:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:06 --> Total execution time: 0.0509
DEBUG - 2022-06-27 10:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:14 --> Total execution time: 0.0782
DEBUG - 2022-06-27 10:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:11:32 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:36 --> Total execution time: 0.0507
DEBUG - 2022-06-27 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:37 --> Total execution time: 0.0496
DEBUG - 2022-06-27 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:37 --> Total execution time: 0.0520
DEBUG - 2022-06-27 10:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:38 --> Total execution time: 0.0506
DEBUG - 2022-06-27 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:12:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:42:33 --> Total execution time: 0.0701
DEBUG - 2022-06-27 10:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:16:07 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:46:07 --> Total execution time: 0.0925
DEBUG - 2022-06-27 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:46:18 --> Total execution time: 0.0423
DEBUG - 2022-06-27 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:16:51 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:46:51 --> Total execution time: 0.0549
DEBUG - 2022-06-27 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:47:20 --> Total execution time: 0.0452
DEBUG - 2022-06-27 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:48:27 --> Total execution time: 0.1458
DEBUG - 2022-06-27 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:18:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:48:34 --> Total execution time: 0.0498
DEBUG - 2022-06-27 10:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:48:39 --> Total execution time: 0.0624
DEBUG - 2022-06-27 10:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:48:41 --> Total execution time: 0.0459
DEBUG - 2022-06-27 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:48:52 --> Total execution time: 0.0548
DEBUG - 2022-06-27 10:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:49:12 --> Total execution time: 0.0602
DEBUG - 2022-06-27 10:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:49:30 --> Total execution time: 0.0442
DEBUG - 2022-06-27 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:49:32 --> Total execution time: 0.0445
DEBUG - 2022-06-27 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:19:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:49:32 --> Total execution time: 0.0332
DEBUG - 2022-06-27 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:50:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:50:18 --> Total execution time: 0.0593
DEBUG - 2022-06-27 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:20:32 --> Total execution time: 0.0469
DEBUG - 2022-06-27 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:20:34 --> Total execution time: 0.0529
DEBUG - 2022-06-27 10:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:20:34 --> Total execution time: 0.1115
DEBUG - 2022-06-27 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:20:44 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:50:44 --> Total execution time: 0.0635
DEBUG - 2022-06-27 10:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:51:23 --> Total execution time: 0.0499
DEBUG - 2022-06-27 10:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:11 --> Total execution time: 0.1115
DEBUG - 2022-06-27 10:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:14 --> Total execution time: 0.1140
DEBUG - 2022-06-27 10:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:20 --> Total execution time: 0.0339
DEBUG - 2022-06-27 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:22 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:22 --> Total execution time: 0.0333
DEBUG - 2022-06-27 10:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:29 --> Total execution time: 0.0337
DEBUG - 2022-06-27 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:37 --> Total execution time: 0.1062
DEBUG - 2022-06-27 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:37 --> Total execution time: 0.0489
DEBUG - 2022-06-27 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:46 --> Total execution time: 0.0938
DEBUG - 2022-06-27 10:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:55 --> Total execution time: 0.0508
DEBUG - 2022-06-27 10:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:22:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:58 --> Total execution time: 0.0341
DEBUG - 2022-06-27 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:23:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:02 --> Total execution time: 0.0367
DEBUG - 2022-06-27 10:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:11 --> Total execution time: 0.0494
DEBUG - 2022-06-27 10:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:15 --> Total execution time: 0.0342
DEBUG - 2022-06-27 10:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:33 --> Total execution time: 0.0554
DEBUG - 2022-06-27 10:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:39 --> Total execution time: 0.0525
DEBUG - 2022-06-27 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:41 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:41 --> Total execution time: 0.0540
DEBUG - 2022-06-27 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:41 --> Total execution time: 0.0739
DEBUG - 2022-06-27 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:44 --> Total execution time: 0.0443
DEBUG - 2022-06-27 10:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:46 --> Total execution time: 0.0636
DEBUG - 2022-06-27 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:49 --> Total execution time: 0.0604
DEBUG - 2022-06-27 10:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:11 --> Total execution time: 0.0486
DEBUG - 2022-06-27 10:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:25:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:55 --> Total execution time: 0.0520
DEBUG - 2022-06-27 10:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:01 --> Total execution time: 0.0469
DEBUG - 2022-06-27 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:28 --> Total execution time: 0.0341
DEBUG - 2022-06-27 10:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:35 --> Total execution time: 0.0439
DEBUG - 2022-06-27 10:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:26:38 --> Total execution time: 0.0467
DEBUG - 2022-06-27 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:26:40 --> Total execution time: 0.0508
DEBUG - 2022-06-27 10:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:26:40 --> Total execution time: 0.1038
DEBUG - 2022-06-27 10:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:46 --> Total execution time: 0.0509
DEBUG - 2022-06-27 10:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:57 --> Total execution time: 0.0508
DEBUG - 2022-06-27 10:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:58 --> Total execution time: 0.0545
DEBUG - 2022-06-27 10:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:27:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 10:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:57:24 --> Total execution time: 1.9827
DEBUG - 2022-06-27 10:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:27:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 10:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:27:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 10:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:18 --> Total execution time: 0.1437
DEBUG - 2022-06-27 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:22 --> Total execution time: 0.0449
DEBUG - 2022-06-27 10:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:24 --> Total execution time: 0.0491
DEBUG - 2022-06-27 10:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:33 --> Total execution time: 0.0569
DEBUG - 2022-06-27 10:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 10:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:37 --> Total execution time: 0.0686
DEBUG - 2022-06-27 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 20:58:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 20:58:39 --> Total execution time: 0.1999
DEBUG - 2022-06-27 10:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:40 --> Total execution time: 0.0693
DEBUG - 2022-06-27 10:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:41 --> Total execution time: 0.0494
DEBUG - 2022-06-27 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:45 --> Total execution time: 0.0486
DEBUG - 2022-06-27 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:50 --> Total execution time: 0.0461
DEBUG - 2022-06-27 10:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:58:56 --> Total execution time: 1.5368
DEBUG - 2022-06-27 10:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:01 --> Total execution time: 0.0857
DEBUG - 2022-06-27 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:08 --> Total execution time: 0.0667
DEBUG - 2022-06-27 10:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:39 --> Total execution time: 0.0513
DEBUG - 2022-06-27 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:06 --> Total execution time: 0.0574
DEBUG - 2022-06-27 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:30:11 --> Total execution time: 0.0669
DEBUG - 2022-06-27 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:16 --> Total execution time: 0.0312
DEBUG - 2022-06-27 10:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:30:31 --> Total execution time: 0.1004
DEBUG - 2022-06-27 10:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:04 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:04 --> Total execution time: 0.1284
DEBUG - 2022-06-27 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:13 --> Total execution time: 0.0568
DEBUG - 2022-06-27 10:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:47 --> Total execution time: 0.0474
DEBUG - 2022-06-27 10:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:53 --> Total execution time: 0.0560
DEBUG - 2022-06-27 10:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:58 --> Total execution time: 0.0562
DEBUG - 2022-06-27 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:06 --> Total execution time: 0.0887
DEBUG - 2022-06-27 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:07 --> Total execution time: 0.0540
DEBUG - 2022-06-27 10:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:10 --> Total execution time: 0.0606
DEBUG - 2022-06-27 10:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:12 --> Total execution time: 0.0551
DEBUG - 2022-06-27 10:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:14 --> Total execution time: 0.0542
DEBUG - 2022-06-27 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:17 --> Total execution time: 0.0580
DEBUG - 2022-06-27 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:20 --> Total execution time: 0.0459
DEBUG - 2022-06-27 10:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:24 --> Total execution time: 0.0666
DEBUG - 2022-06-27 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:27 --> Total execution time: 0.0592
DEBUG - 2022-06-27 10:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:29 --> Total execution time: 0.0484
DEBUG - 2022-06-27 10:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:31 --> Total execution time: 0.1713
DEBUG - 2022-06-27 10:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:32 --> Total execution time: 0.0625
DEBUG - 2022-06-27 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:37 --> Total execution time: 0.0319
DEBUG - 2022-06-27 10:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:53 --> Total execution time: 0.0576
DEBUG - 2022-06-27 10:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:03 --> Total execution time: 0.0562
DEBUG - 2022-06-27 10:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:13 --> Total execution time: 0.0449
DEBUG - 2022-06-27 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:17 --> Total execution time: 0.0385
DEBUG - 2022-06-27 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:25 --> Total execution time: 0.0452
DEBUG - 2022-06-27 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:29 --> Total execution time: 0.0495
DEBUG - 2022-06-27 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:31 --> Total execution time: 0.0480
DEBUG - 2022-06-27 10:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:37 --> Total execution time: 0.0644
DEBUG - 2022-06-27 10:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:46 --> Total execution time: 0.0511
DEBUG - 2022-06-27 10:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:03:55 --> Total execution time: 0.0498
DEBUG - 2022-06-27 10:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:31 --> Total execution time: 0.0494
DEBUG - 2022-06-27 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:35:35 --> Total execution time: 0.0602
DEBUG - 2022-06-27 10:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:26 --> Total execution time: 0.0862
DEBUG - 2022-06-27 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:34 --> Total execution time: 0.0848
DEBUG - 2022-06-27 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:37 --> Total execution time: 0.1617
DEBUG - 2022-06-27 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:39 --> Total execution time: 0.0791
DEBUG - 2022-06-27 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:41 --> Total execution time: 0.0722
DEBUG - 2022-06-27 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:42 --> Total execution time: 0.0523
DEBUG - 2022-06-27 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:44 --> Total execution time: 0.0863
DEBUG - 2022-06-27 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:46 --> Total execution time: 0.1415
DEBUG - 2022-06-27 10:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:36:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:06:49 --> Total execution time: 0.0509
DEBUG - 2022-06-27 10:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:08 --> Total execution time: 0.0503
DEBUG - 2022-06-27 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:24 --> Total execution time: 0.0584
DEBUG - 2022-06-27 10:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:32 --> Total execution time: 0.0817
DEBUG - 2022-06-27 10:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:52 --> Total execution time: 0.0908
DEBUG - 2022-06-27 10:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:52 --> Total execution time: 0.0499
DEBUG - 2022-06-27 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:55 --> Total execution time: 0.0793
DEBUG - 2022-06-27 10:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:58 --> Total execution time: 0.0518
DEBUG - 2022-06-27 10:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:05 --> Total execution time: 0.0534
DEBUG - 2022-06-27 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:08 --> Total execution time: 0.0619
DEBUG - 2022-06-27 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:10 --> Total execution time: 0.0486
DEBUG - 2022-06-27 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:13 --> Total execution time: 0.0442
DEBUG - 2022-06-27 10:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:17 --> Total execution time: 0.0636
DEBUG - 2022-06-27 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:40:38 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:10:38 --> Total execution time: 0.1736
DEBUG - 2022-06-27 10:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:22 --> Total execution time: 0.1805
DEBUG - 2022-06-27 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:41:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:47 --> Total execution time: 0.1238
DEBUG - 2022-06-27 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:41:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:47 --> Total execution time: 0.0488
DEBUG - 2022-06-27 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:51 --> Total execution time: 0.0494
DEBUG - 2022-06-27 10:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:12:02 --> Total execution time: 0.0987
DEBUG - 2022-06-27 10:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:42:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:12:58 --> Total execution time: 0.0374
DEBUG - 2022-06-27 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:02 --> Total execution time: 0.0775
DEBUG - 2022-06-27 10:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:13:08 --> Total execution time: 0.0562
DEBUG - 2022-06-27 10:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:13:17 --> Total execution time: 0.0635
DEBUG - 2022-06-27 10:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:34 --> Total execution time: 0.0625
DEBUG - 2022-06-27 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:43:55 --> Total execution time: 0.0828
DEBUG - 2022-06-27 10:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:01 --> Total execution time: 0.0564
DEBUG - 2022-06-27 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:07 --> Total execution time: 0.0728
DEBUG - 2022-06-27 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:08 --> Total execution time: 0.0772
DEBUG - 2022-06-27 10:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:30 --> Total execution time: 0.1138
DEBUG - 2022-06-27 10:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:41 --> Total execution time: 0.0881
DEBUG - 2022-06-27 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:05 --> Total execution time: 0.0591
DEBUG - 2022-06-27 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:12 --> Total execution time: 0.0336
DEBUG - 2022-06-27 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:16 --> Total execution time: 0.0562
DEBUG - 2022-06-27 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:32 --> Total execution time: 0.0632
DEBUG - 2022-06-27 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:35 --> Total execution time: 0.0864
DEBUG - 2022-06-27 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:45:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:40 --> Total execution time: 0.0642
DEBUG - 2022-06-27 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:19 --> Total execution time: 0.0827
DEBUG - 2022-06-27 10:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:23 --> Total execution time: 0.0553
DEBUG - 2022-06-27 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:27 --> Total execution time: 0.0691
DEBUG - 2022-06-27 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:46:28 --> Total execution time: 0.0801
DEBUG - 2022-06-27 10:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:35 --> Total execution time: 0.1370
DEBUG - 2022-06-27 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:41 --> Total execution time: 0.0382
DEBUG - 2022-06-27 10:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:04 --> Total execution time: 0.1343
DEBUG - 2022-06-27 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:14 --> Total execution time: 0.0530
DEBUG - 2022-06-27 10:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:19 --> Total execution time: 0.0717
DEBUG - 2022-06-27 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:28 --> Total execution time: 0.0806
DEBUG - 2022-06-27 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:51 --> Total execution time: 0.0832
DEBUG - 2022-06-27 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:29 --> Total execution time: 0.1731
DEBUG - 2022-06-27 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:55 --> Total execution time: 0.0514
DEBUG - 2022-06-27 10:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:00 --> Total execution time: 0.0527
DEBUG - 2022-06-27 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:08 --> Total execution time: 0.0524
DEBUG - 2022-06-27 10:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:09 --> Total execution time: 0.0556
DEBUG - 2022-06-27 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:18 --> Total execution time: 0.0534
DEBUG - 2022-06-27 10:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:25 --> Total execution time: 0.0589
DEBUG - 2022-06-27 10:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:27 --> Total execution time: 0.0516
DEBUG - 2022-06-27 10:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:31 --> Total execution time: 0.0378
DEBUG - 2022-06-27 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:52 --> Total execution time: 0.0628
DEBUG - 2022-06-27 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:19:54 --> Total execution time: 0.0557
DEBUG - 2022-06-27 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:00 --> Total execution time: 0.0603
DEBUG - 2022-06-27 10:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:03 --> Total execution time: 0.0631
DEBUG - 2022-06-27 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:10 --> Total execution time: 0.0509
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:16 --> Total execution time: 0.0468
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:50:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:50:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 10:50:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:17 --> Total execution time: 0.0460
DEBUG - 2022-06-27 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:17 --> Total execution time: 0.0485
DEBUG - 2022-06-27 21:20:17 --> Total execution time: 0.0588
DEBUG - 2022-06-27 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:17 --> Total execution time: 0.0448
DEBUG - 2022-06-27 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:17 --> Total execution time: 0.1091
DEBUG - 2022-06-27 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:17 --> Total execution time: 0.0478
DEBUG - 2022-06-27 10:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:18 --> Total execution time: 0.0642
DEBUG - 2022-06-27 10:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:18 --> Total execution time: 0.0438
DEBUG - 2022-06-27 10:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:22 --> Total execution time: 0.0489
DEBUG - 2022-06-27 10:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:45 --> Total execution time: 0.0693
DEBUG - 2022-06-27 10:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:51 --> Total execution time: 0.0568
DEBUG - 2022-06-27 10:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:51 --> Total execution time: 0.0309
DEBUG - 2022-06-27 10:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:55 --> Total execution time: 0.0483
DEBUG - 2022-06-27 10:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:56 --> Total execution time: 0.0642
DEBUG - 2022-06-27 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:00 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:00 --> Total execution time: 0.0345
DEBUG - 2022-06-27 10:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:07 --> Total execution time: 0.0440
DEBUG - 2022-06-27 10:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 10:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:09 --> Total execution time: 0.0474
DEBUG - 2022-06-27 10:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:10 --> Total execution time: 0.0440
DEBUG - 2022-06-27 10:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:15 --> Total execution time: 0.0636
DEBUG - 2022-06-27 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:18 --> Total execution time: 0.0578
DEBUG - 2022-06-27 10:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:23 --> Total execution time: 0.0658
DEBUG - 2022-06-27 10:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:27 --> Total execution time: 0.0447
DEBUG - 2022-06-27 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:29 --> Total execution time: 0.0491
DEBUG - 2022-06-27 10:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:31 --> Total execution time: 0.0653
DEBUG - 2022-06-27 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:50 --> Total execution time: 0.0548
DEBUG - 2022-06-27 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:21:55 --> Total execution time: 0.0751
DEBUG - 2022-06-27 10:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:09 --> Total execution time: 0.0521
DEBUG - 2022-06-27 10:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:19 --> Total execution time: 0.0509
DEBUG - 2022-06-27 10:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:36 --> Total execution time: 0.1252
DEBUG - 2022-06-27 10:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:18 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:19 --> Total execution time: 0.0503
DEBUG - 2022-06-27 10:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:22 --> Total execution time: 0.0624
DEBUG - 2022-06-27 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:33 --> Total execution time: 0.0513
DEBUG - 2022-06-27 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:39 --> Total execution time: 0.0595
DEBUG - 2022-06-27 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:52 --> Total execution time: 0.0481
DEBUG - 2022-06-27 10:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:24:06 --> Total execution time: 0.0479
DEBUG - 2022-06-27 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:24:35 --> Total execution time: 0.0702
DEBUG - 2022-06-27 10:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:24:36 --> Total execution time: 0.0886
DEBUG - 2022-06-27 10:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:56:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:26:09 --> Total execution time: 0.1376
DEBUG - 2022-06-27 10:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:56:41 --> Total execution time: 0.0703
DEBUG - 2022-06-27 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:57:21 --> Total execution time: 0.0568
DEBUG - 2022-06-27 10:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:27:30 --> Total execution time: 0.1162
DEBUG - 2022-06-27 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:28:20 --> Total execution time: 0.1227
DEBUG - 2022-06-27 10:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:28:33 --> Total execution time: 0.0475
DEBUG - 2022-06-27 10:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:35 --> Total execution time: 0.0544
DEBUG - 2022-06-27 10:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:36 --> Total execution time: 0.0493
DEBUG - 2022-06-27 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:38 --> Total execution time: 0.0507
DEBUG - 2022-06-27 10:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:39 --> No URI present. Default controller set.
DEBUG - 2022-06-27 10:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:39 --> Total execution time: 0.0566
DEBUG - 2022-06-27 10:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:39 --> Total execution time: 0.0546
DEBUG - 2022-06-27 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:30:02 --> Total execution time: 0.1149
DEBUG - 2022-06-27 11:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:00:33 --> Total execution time: 0.0499
DEBUG - 2022-06-27 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:28 --> Total execution time: 0.0523
DEBUG - 2022-06-27 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:33 --> Total execution time: 0.0636
DEBUG - 2022-06-27 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:36 --> Total execution time: 0.0480
DEBUG - 2022-06-27 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:39 --> Total execution time: 0.0449
DEBUG - 2022-06-27 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:39 --> Total execution time: 0.0649
DEBUG - 2022-06-27 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:40 --> Total execution time: 0.1207
DEBUG - 2022-06-27 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:42 --> Total execution time: 0.0554
DEBUG - 2022-06-27 11:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:44 --> Total execution time: 0.0453
DEBUG - 2022-06-27 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:46 --> Total execution time: 0.0539
DEBUG - 2022-06-27 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:47 --> Total execution time: 0.0446
DEBUG - 2022-06-27 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:48 --> Total execution time: 0.0765
DEBUG - 2022-06-27 11:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:49 --> Total execution time: 0.0725
DEBUG - 2022-06-27 11:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:50 --> Total execution time: 0.0481
DEBUG - 2022-06-27 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:55 --> Total execution time: 0.0555
DEBUG - 2022-06-27 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:56 --> Total execution time: 0.0592
DEBUG - 2022-06-27 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:57 --> Total execution time: 0.1054
DEBUG - 2022-06-27 11:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:01:57 --> Total execution time: 0.1576
DEBUG - 2022-06-27 11:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:00 --> Total execution time: 0.0438
DEBUG - 2022-06-27 11:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:08 --> Total execution time: 0.0556
DEBUG - 2022-06-27 11:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:11 --> Total execution time: 0.0511
DEBUG - 2022-06-27 11:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:13 --> Total execution time: 0.0444
DEBUG - 2022-06-27 11:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:14 --> Total execution time: 0.0445
DEBUG - 2022-06-27 11:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:16 --> Total execution time: 0.0662
DEBUG - 2022-06-27 11:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:18 --> Total execution time: 0.0473
DEBUG - 2022-06-27 11:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:22 --> Total execution time: 0.0586
DEBUG - 2022-06-27 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:29 --> Total execution time: 0.0502
DEBUG - 2022-06-27 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:30 --> Total execution time: 0.0439
DEBUG - 2022-06-27 11:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:32 --> Total execution time: 0.0463
DEBUG - 2022-06-27 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:34 --> Total execution time: 0.0790
DEBUG - 2022-06-27 11:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:41 --> Total execution time: 0.0547
DEBUG - 2022-06-27 11:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:48 --> Total execution time: 0.1074
DEBUG - 2022-06-27 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:53 --> Total execution time: 0.0527
DEBUG - 2022-06-27 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:32:58 --> Total execution time: 0.0564
DEBUG - 2022-06-27 11:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:00 --> Total execution time: 0.0569
DEBUG - 2022-06-27 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:17 --> Total execution time: 0.0596
DEBUG - 2022-06-27 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:25 --> Total execution time: 0.0539
DEBUG - 2022-06-27 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:27 --> Total execution time: 0.0570
DEBUG - 2022-06-27 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:30 --> Total execution time: 0.0691
DEBUG - 2022-06-27 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:32 --> Total execution time: 0.0630
DEBUG - 2022-06-27 11:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:38 --> Total execution time: 0.0634
DEBUG - 2022-06-27 11:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:33:42 --> Total execution time: 0.0722
DEBUG - 2022-06-27 11:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:34:04 --> Total execution time: 0.0678
DEBUG - 2022-06-27 11:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:34:17 --> Total execution time: 0.0733
DEBUG - 2022-06-27 11:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:34:57 --> Total execution time: 0.0788
DEBUG - 2022-06-27 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:35:00 --> Total execution time: 0.0694
DEBUG - 2022-06-27 11:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:05:00 --> Total execution time: 0.0584
DEBUG - 2022-06-27 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:05:52 --> Total execution time: 0.0859
DEBUG - 2022-06-27 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:36:09 --> Total execution time: 0.0623
DEBUG - 2022-06-27 11:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:06:57 --> Total execution time: 0.0552
DEBUG - 2022-06-27 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:07:05 --> Total execution time: 0.0924
DEBUG - 2022-06-27 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:07:52 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:37:52 --> Total execution time: 0.0441
DEBUG - 2022-06-27 11:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:08:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:38:26 --> Total execution time: 0.0432
DEBUG - 2022-06-27 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:08:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:38:32 --> Total execution time: 0.1109
DEBUG - 2022-06-27 11:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:08:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:38:33 --> Total execution time: 0.0407
DEBUG - 2022-06-27 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:08:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:38:56 --> Total execution time: 0.0454
DEBUG - 2022-06-27 11:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:05 --> Total execution time: 0.0557
DEBUG - 2022-06-27 11:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:15 --> Total execution time: 0.0525
DEBUG - 2022-06-27 11:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:22 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:22 --> Total execution time: 0.0542
DEBUG - 2022-06-27 11:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:31 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:32 --> Total execution time: 0.0720
DEBUG - 2022-06-27 11:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:33 --> Total execution time: 0.0724
DEBUG - 2022-06-27 11:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:45 --> Total execution time: 0.0559
DEBUG - 2022-06-27 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:48 --> Total execution time: 0.0377
DEBUG - 2022-06-27 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:09:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:39:48 --> Total execution time: 0.0354
DEBUG - 2022-06-27 11:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:10:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:01 --> Total execution time: 0.0901
DEBUG - 2022-06-27 11:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:10:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:03 --> Total execution time: 0.0588
DEBUG - 2022-06-27 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:10:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:06 --> Total execution time: 0.0625
DEBUG - 2022-06-27 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:10:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:06 --> Total execution time: 0.0525
DEBUG - 2022-06-27 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:10:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:26 --> Total execution time: 0.0535
DEBUG - 2022-06-27 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:10:39 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:39 --> Total execution time: 0.0543
DEBUG - 2022-06-27 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:41:14 --> Total execution time: 0.0494
DEBUG - 2022-06-27 11:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:41:29 --> Total execution time: 0.0560
DEBUG - 2022-06-27 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:12:19 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:42:19 --> Total execution time: 0.0389
DEBUG - 2022-06-27 11:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:12:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:42:30 --> Total execution time: 0.0357
DEBUG - 2022-06-27 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:42:37 --> Total execution time: 0.0347
DEBUG - 2022-06-27 11:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:14:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:44:17 --> Total execution time: 0.0400
DEBUG - 2022-06-27 11:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:44:27 --> Total execution time: 0.0535
DEBUG - 2022-06-27 11:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:00 --> Total execution time: 0.0594
DEBUG - 2022-06-27 11:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:07 --> Total execution time: 0.0488
DEBUG - 2022-06-27 11:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:28 --> Total execution time: 0.0494
DEBUG - 2022-06-27 11:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:09 --> Total execution time: 0.0563
DEBUG - 2022-06-27 11:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 11:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:10 --> Total execution time: 0.0506
DEBUG - 2022-06-27 11:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:30 --> Total execution time: 0.0687
DEBUG - 2022-06-27 11:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:31 --> Total execution time: 0.0620
DEBUG - 2022-06-27 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:43 --> Total execution time: 0.0512
DEBUG - 2022-06-27 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:17:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:56 --> Total execution time: 0.1611
DEBUG - 2022-06-27 11:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:04 --> Total execution time: 0.0738
DEBUG - 2022-06-27 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:10 --> Total execution time: 0.0583
DEBUG - 2022-06-27 11:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:20 --> Total execution time: 0.0590
DEBUG - 2022-06-27 11:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:25 --> Total execution time: 0.0614
DEBUG - 2022-06-27 11:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:47 --> Total execution time: 0.0569
DEBUG - 2022-06-27 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:09 --> Total execution time: 0.0533
DEBUG - 2022-06-27 11:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:12 --> Total execution time: 0.0510
DEBUG - 2022-06-27 11:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:12 --> Total execution time: 0.0736
DEBUG - 2022-06-27 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:15 --> Total execution time: 0.0757
DEBUG - 2022-06-27 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:50:12 --> Total execution time: 0.0612
DEBUG - 2022-06-27 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:51:20 --> Total execution time: 0.0742
DEBUG - 2022-06-27 11:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:51:37 --> Total execution time: 0.0502
DEBUG - 2022-06-27 11:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:51:47 --> Total execution time: 0.0860
DEBUG - 2022-06-27 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:51:50 --> Total execution time: 0.0607
DEBUG - 2022-06-27 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:24:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:54:11 --> Total execution time: 0.1298
DEBUG - 2022-06-27 11:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:56:21 --> Total execution time: 0.1826
DEBUG - 2022-06-27 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:56:24 --> Total execution time: 0.0713
DEBUG - 2022-06-27 11:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:56:33 --> Total execution time: 0.0516
DEBUG - 2022-06-27 11:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:57:24 --> Total execution time: 0.0540
DEBUG - 2022-06-27 11:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:57:27 --> Total execution time: 0.0567
DEBUG - 2022-06-27 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:29:55 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:59:55 --> Total execution time: 0.1776
DEBUG - 2022-06-27 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:00:03 --> Total execution time: 0.0846
DEBUG - 2022-06-27 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:00:12 --> Total execution time: 0.0518
DEBUG - 2022-06-27 11:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:00:22 --> Total execution time: 0.0495
DEBUG - 2022-06-27 11:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:00:26 --> Total execution time: 0.0613
DEBUG - 2022-06-27 11:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:08 --> 404 Page Not Found: Shell4php/index
DEBUG - 2022-06-27 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:09 --> 404 Page Not Found: Upsphp/index
DEBUG - 2022-06-27 11:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:10 --> 404 Page Not Found: Ruphp/index
DEBUG - 2022-06-27 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:11 --> 404 Page Not Found: Ifphp/index
DEBUG - 2022-06-27 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:01:12 --> Total execution time: 0.0443
DEBUG - 2022-06-27 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:12 --> 404 Page Not Found: Vulnphp/index
DEBUG - 2022-06-27 11:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:13 --> 404 Page Not Found: Fwphp/index
DEBUG - 2022-06-27 11:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:14 --> 404 Page Not Found: Skipperphp/index
DEBUG - 2022-06-27 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:16 --> 404 Page Not Found: Skippershellphp/index
DEBUG - 2022-06-27 11:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:17 --> 404 Page Not Found: Ttttphp/index
DEBUG - 2022-06-27 11:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:18 --> 404 Page Not Found: Tshopphp/index
DEBUG - 2022-06-27 11:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:19 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-06-27 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:20 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-06-27 11:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:22 --> 404 Page Not Found: Inje3ctorphp/index
DEBUG - 2022-06-27 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:23 --> 404 Page Not Found: Saudiphp/index
DEBUG - 2022-06-27 11:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:24 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-06-27 11:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:25 --> 404 Page Not Found: Alfashellphp/index
DEBUG - 2022-06-27 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:27 --> 404 Page Not Found: My_alfaphp/index
DEBUG - 2022-06-27 11:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:28 --> 404 Page Not Found: Uploaderphp/index
DEBUG - 2022-06-27 11:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:29 --> 404 Page Not Found: Upphp/index
DEBUG - 2022-06-27 11:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:30 --> 404 Page Not Found: Hackedphp/index
DEBUG - 2022-06-27 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:32 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-06-27 11:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:33 --> 404 Page Not Found: Navirphp/index
DEBUG - 2022-06-27 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:35 --> 404 Page Not Found: Cmd13php/index
DEBUG - 2022-06-27 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:36 --> 404 Page Not Found: Inc20k1php/index
DEBUG - 2022-06-27 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:37 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-06-27 11:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:39 --> 404 Page Not Found: 404php/index
DEBUG - 2022-06-27 11:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:40 --> 404 Page Not Found: Swmphp/index
DEBUG - 2022-06-27 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:41 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-06-27 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:42 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-06-27 11:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:44 --> 404 Page Not Found: Shxphp/index
DEBUG - 2022-06-27 11:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:45 --> 404 Page Not Found: Wsphp/index
DEBUG - 2022-06-27 11:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:46 --> 404 Page Not Found: Mphp/index
DEBUG - 2022-06-27 11:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:47 --> 404 Page Not Found: Edit-formphp/index
DEBUG - 2022-06-27 11:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:49 --> 404 Page Not Found: LEAFphp/index
DEBUG - 2022-06-27 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:50 --> 404 Page Not Found: Leafmailerphp/index
DEBUG - 2022-06-27 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:51 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-06-27 11:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:52 --> 404 Page Not Found: Leafmailer28php/index
DEBUG - 2022-06-27 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:54 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-06-27 11:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:55 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-06-27 11:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:56 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-06-27 11:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:57 --> 404 Page Not Found: Srxphp/index
DEBUG - 2022-06-27 11:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:31:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:31:59 --> 404 Page Not Found: 1337php/index
DEBUG - 2022-06-27 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:00 --> 404 Page Not Found: Xxphp/index
DEBUG - 2022-06-27 11:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:01 --> 404 Page Not Found: XxXphp/index
DEBUG - 2022-06-27 11:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:03 --> 404 Page Not Found: Lfphp/index
DEBUG - 2022-06-27 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:04 --> 404 Page Not Found: Alexphp/index
DEBUG - 2022-06-27 11:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:05 --> 404 Page Not Found: Newphp/index
DEBUG - 2022-06-27 11:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:06 --> 404 Page Not Found: Marijuanaphp/index
DEBUG - 2022-06-27 11:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:07 --> 404 Page Not Found: Gazaphp/index
DEBUG - 2022-06-27 11:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:09 --> 404 Page Not Found: Wp-adminphp/index
DEBUG - 2022-06-27 11:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:10 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-06-27 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:11 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-06-27 11:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:13 --> 404 Page Not Found: Wso1php/index
DEBUG - 2022-06-27 11:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:14 --> 404 Page Not Found: Bbphp/index
DEBUG - 2022-06-27 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:15 --> 404 Page Not Found: Luxphp/index
DEBUG - 2022-06-27 11:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:32:16 --> 404 Page Not Found: Haxorphp/index
DEBUG - 2022-06-27 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:32:40 --> Total execution time: 0.0480
DEBUG - 2022-06-27 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:33:55 --> Total execution time: 0.0659
DEBUG - 2022-06-27 11:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:04:23 --> Total execution time: 0.0830
DEBUG - 2022-06-27 11:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:04:35 --> Total execution time: 0.0922
DEBUG - 2022-06-27 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:04:51 --> Total execution time: 0.0945
DEBUG - 2022-06-27 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:04:58 --> Total execution time: 0.0900
DEBUG - 2022-06-27 11:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:05:21 --> Total execution time: 0.1201
DEBUG - 2022-06-27 11:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:05:29 --> Total execution time: 0.0513
DEBUG - 2022-06-27 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:05:54 --> Total execution time: 0.0866
DEBUG - 2022-06-27 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:06:14 --> Total execution time: 0.1090
DEBUG - 2022-06-27 11:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:06:21 --> Total execution time: 0.0526
DEBUG - 2022-06-27 11:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:06:24 --> Total execution time: 0.0942
DEBUG - 2022-06-27 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:08:25 --> Total execution time: 0.0580
DEBUG - 2022-06-27 11:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:08:41 --> Total execution time: 0.0511
DEBUG - 2022-06-27 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:08:44 --> Total execution time: 0.0610
DEBUG - 2022-06-27 11:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:09:26 --> Total execution time: 0.0306
DEBUG - 2022-06-27 11:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:09:30 --> Total execution time: 0.0465
DEBUG - 2022-06-27 11:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:09:30 --> Total execution time: 0.0599
DEBUG - 2022-06-27 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:09:39 --> Total execution time: 0.0544
DEBUG - 2022-06-27 11:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:09:52 --> Total execution time: 0.0607
DEBUG - 2022-06-27 11:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:09:58 --> Total execution time: 0.0516
DEBUG - 2022-06-27 11:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:05 --> Total execution time: 0.0499
DEBUG - 2022-06-27 11:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:11 --> Total execution time: 0.0544
DEBUG - 2022-06-27 11:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:12 --> Total execution time: 0.0516
DEBUG - 2022-06-27 11:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:18 --> Total execution time: 0.0562
DEBUG - 2022-06-27 11:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:20 --> Total execution time: 0.0733
DEBUG - 2022-06-27 11:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:25 --> Total execution time: 0.0540
DEBUG - 2022-06-27 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:29 --> Total execution time: 0.0684
DEBUG - 2022-06-27 11:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:30 --> Total execution time: 0.0473
DEBUG - 2022-06-27 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:35 --> Total execution time: 0.0647
DEBUG - 2022-06-27 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:38 --> Total execution time: 0.0461
DEBUG - 2022-06-27 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:10:39 --> Total execution time: 0.0451
DEBUG - 2022-06-27 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:40:59 --> Total execution time: 0.0475
DEBUG - 2022-06-27 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:02 --> Total execution time: 0.0461
DEBUG - 2022-06-27 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:03 --> Total execution time: 0.0483
DEBUG - 2022-06-27 11:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:04 --> Total execution time: 0.0681
DEBUG - 2022-06-27 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:13 --> Total execution time: 0.0466
DEBUG - 2022-06-27 11:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:14 --> Total execution time: 0.0456
DEBUG - 2022-06-27 11:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:16 --> Total execution time: 0.0555
DEBUG - 2022-06-27 11:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:23 --> Total execution time: 0.0558
DEBUG - 2022-06-27 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:24 --> Total execution time: 0.0512
DEBUG - 2022-06-27 11:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:11:33 --> Total execution time: 0.0513
DEBUG - 2022-06-27 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:12:11 --> Total execution time: 0.0484
DEBUG - 2022-06-27 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:12:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:12:12 --> Total execution time: 0.0458
DEBUG - 2022-06-27 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:15 --> Total execution time: 0.0740
DEBUG - 2022-06-27 11:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:18 --> Total execution time: 0.0472
DEBUG - 2022-06-27 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:27 --> Total execution time: 0.1316
DEBUG - 2022-06-27 11:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:34 --> Total execution time: 0.0470
DEBUG - 2022-06-27 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:41 --> Total execution time: 0.0459
DEBUG - 2022-06-27 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:42 --> Total execution time: 0.0389
DEBUG - 2022-06-27 11:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:45 --> Total execution time: 0.0469
DEBUG - 2022-06-27 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:48 --> Total execution time: 0.0540
DEBUG - 2022-06-27 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:49 --> Total execution time: 0.0600
DEBUG - 2022-06-27 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:42 --> Total execution time: 0.0453
DEBUG - 2022-06-27 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:49 --> Total execution time: 0.0444
DEBUG - 2022-06-27 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:50 --> Total execution time: 0.0458
DEBUG - 2022-06-27 11:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:15:02 --> Total execution time: 0.0874
DEBUG - 2022-06-27 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:45:13 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:15:17 --> Total execution time: 0.0471
DEBUG - 2022-06-27 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:15:20 --> Total execution time: 0.0543
DEBUG - 2022-06-27 11:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:15:22 --> Total execution time: 0.0402
DEBUG - 2022-06-27 11:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:15:58 --> Total execution time: 0.0500
DEBUG - 2022-06-27 11:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:02 --> Total execution time: 0.0512
DEBUG - 2022-06-27 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:05 --> Total execution time: 0.0610
DEBUG - 2022-06-27 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:05 --> Total execution time: 0.0466
DEBUG - 2022-06-27 11:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:12 --> Total execution time: 0.0863
DEBUG - 2022-06-27 11:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:12 --> Total execution time: 0.1084
DEBUG - 2022-06-27 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:12 --> Total execution time: 0.0435
DEBUG - 2022-06-27 11:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:16 --> Total execution time: 0.0451
DEBUG - 2022-06-27 11:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:19 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:19 --> Total execution time: 0.1201
DEBUG - 2022-06-27 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:23 --> Total execution time: 0.1181
DEBUG - 2022-06-27 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:16:27 --> Total execution time: 0.0455
DEBUG - 2022-06-27 11:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:06 --> Total execution time: 0.0451
DEBUG - 2022-06-27 11:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:17 --> Total execution time: 0.1166
DEBUG - 2022-06-27 11:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:21 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:22 --> Total execution time: 0.0720
DEBUG - 2022-06-27 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:26 --> Total execution time: 0.0561
DEBUG - 2022-06-27 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:28 --> Total execution time: 0.0696
DEBUG - 2022-06-27 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:36 --> Total execution time: 0.0761
DEBUG - 2022-06-27 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:37 --> Total execution time: 0.0521
DEBUG - 2022-06-27 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 11:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:39 --> Total execution time: 0.0455
DEBUG - 2022-06-27 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:48 --> Total execution time: 0.0462
DEBUG - 2022-06-27 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:48 --> Total execution time: 0.0506
DEBUG - 2022-06-27 11:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:52 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:17:52 --> Total execution time: 0.0510
DEBUG - 2022-06-27 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:48:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 11:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:18:02 --> Total execution time: 0.0559
DEBUG - 2022-06-27 11:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:18:23 --> Total execution time: 0.0512
DEBUG - 2022-06-27 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:01 --> Total execution time: 0.1358
DEBUG - 2022-06-27 11:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:07 --> Total execution time: 0.0494
DEBUG - 2022-06-27 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:09 --> Total execution time: 0.0576
DEBUG - 2022-06-27 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:11 --> Total execution time: 0.1057
DEBUG - 2022-06-27 11:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:12 --> Total execution time: 0.0774
DEBUG - 2022-06-27 11:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:14 --> Total execution time: 0.0496
DEBUG - 2022-06-27 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:17 --> Total execution time: 0.0535
DEBUG - 2022-06-27 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:19 --> Total execution time: 0.0801
DEBUG - 2022-06-27 11:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:20 --> Total execution time: 0.0828
DEBUG - 2022-06-27 11:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:20:23 --> Total execution time: 0.0791
DEBUG - 2022-06-27 11:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 11:50:23 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 11:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:21:21 --> Total execution time: 0.0494
DEBUG - 2022-06-27 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:08 --> Total execution time: 0.0506
DEBUG - 2022-06-27 11:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:15 --> Total execution time: 0.0256
DEBUG - 2022-06-27 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:16 --> Total execution time: 0.0269
DEBUG - 2022-06-27 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:16 --> Total execution time: 0.0279
DEBUG - 2022-06-27 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:18 --> Total execution time: 0.0424
DEBUG - 2022-06-27 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:21 --> Total execution time: 0.0403
DEBUG - 2022-06-27 11:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:37 --> Total execution time: 0.0455
DEBUG - 2022-06-27 11:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:53 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:53 --> Total execution time: 0.0416
DEBUG - 2022-06-27 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:22:53 --> Total execution time: 0.0533
DEBUG - 2022-06-27 11:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:23:07 --> Total execution time: 0.0614
DEBUG - 2022-06-27 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:53:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:23:15 --> Total execution time: 0.0461
DEBUG - 2022-06-27 11:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:24:05 --> Total execution time: 0.0557
DEBUG - 2022-06-27 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:24:33 --> Total execution time: 0.0456
DEBUG - 2022-06-27 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:24:37 --> Total execution time: 0.0490
DEBUG - 2022-06-27 11:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:24:43 --> Total execution time: 0.0548
DEBUG - 2022-06-27 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:24:56 --> Total execution time: 0.0632
DEBUG - 2022-06-27 11:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:25:36 --> Total execution time: 0.0712
DEBUG - 2022-06-27 11:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:26:17 --> Total execution time: 0.1223
DEBUG - 2022-06-27 11:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:27:03 --> Total execution time: 0.1252
DEBUG - 2022-06-27 11:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:57:51 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:27:51 --> Total execution time: 0.0443
DEBUG - 2022-06-27 11:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:27:51 --> Total execution time: 0.0465
DEBUG - 2022-06-27 11:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:15 --> Total execution time: 0.0574
DEBUG - 2022-06-27 11:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:17 --> Total execution time: 0.1005
DEBUG - 2022-06-27 11:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:19 --> Total execution time: 0.0497
DEBUG - 2022-06-27 11:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:58:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 11:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:25 --> Total execution time: 0.1172
DEBUG - 2022-06-27 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:29:04 --> Total execution time: 0.0485
DEBUG - 2022-06-27 11:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:29:09 --> Total execution time: 0.0582
DEBUG - 2022-06-27 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:29:11 --> Total execution time: 0.0721
DEBUG - 2022-06-27 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:29:21 --> Total execution time: 0.0458
DEBUG - 2022-06-27 11:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:29:25 --> Total execution time: 0.0723
DEBUG - 2022-06-27 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:29:32 --> Total execution time: 0.0635
DEBUG - 2022-06-27 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:30:03 --> Total execution time: 0.0818
DEBUG - 2022-06-27 12:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:30:36 --> Total execution time: 0.0539
DEBUG - 2022-06-27 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:30:45 --> Total execution time: 0.1289
DEBUG - 2022-06-27 12:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:01:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:31:15 --> Total execution time: 0.0680
DEBUG - 2022-06-27 12:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:31:38 --> Total execution time: 0.0579
DEBUG - 2022-06-27 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:12 --> Total execution time: 0.0559
DEBUG - 2022-06-27 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:16 --> Total execution time: 0.0477
DEBUG - 2022-06-27 12:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:25 --> Total execution time: 0.0662
DEBUG - 2022-06-27 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:31 --> Total execution time: 0.0699
DEBUG - 2022-06-27 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:33 --> Total execution time: 0.0552
DEBUG - 2022-06-27 12:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:35 --> Total execution time: 0.0587
DEBUG - 2022-06-27 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:47 --> Total execution time: 0.0457
DEBUG - 2022-06-27 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:56 --> Total execution time: 0.0469
DEBUG - 2022-06-27 12:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:03:58 --> Total execution time: 0.0457
DEBUG - 2022-06-27 12:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:58 --> Total execution time: 0.1183
DEBUG - 2022-06-27 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:00 --> Total execution time: 0.0779
DEBUG - 2022-06-27 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:01 --> Total execution time: 0.0983
DEBUG - 2022-06-27 12:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:06 --> Total execution time: 0.1656
DEBUG - 2022-06-27 12:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:10 --> Total execution time: 0.0794
DEBUG - 2022-06-27 12:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:32 --> Total execution time: 0.0372
DEBUG - 2022-06-27 12:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:37 --> Total execution time: 0.1305
DEBUG - 2022-06-27 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:41 --> Total execution time: 0.0568
DEBUG - 2022-06-27 12:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:44 --> Total execution time: 0.0518
DEBUG - 2022-06-27 12:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:47 --> Total execution time: 0.0799
DEBUG - 2022-06-27 12:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:49 --> Total execution time: 0.0512
DEBUG - 2022-06-27 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:54 --> Total execution time: 0.0763
DEBUG - 2022-06-27 22:34:54 --> Total execution time: 0.1194
DEBUG - 2022-06-27 12:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:56 --> Total execution time: 0.0978
DEBUG - 2022-06-27 12:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:00 --> Total execution time: 0.0505
DEBUG - 2022-06-27 12:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:02 --> Total execution time: 0.0790
DEBUG - 2022-06-27 12:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:25 --> Total execution time: 0.0486
DEBUG - 2022-06-27 12:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:31 --> Total execution time: 0.0494
DEBUG - 2022-06-27 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:41 --> Total execution time: 0.0520
DEBUG - 2022-06-27 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:48 --> Total execution time: 0.0912
DEBUG - 2022-06-27 12:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:06 --> Total execution time: 0.0680
DEBUG - 2022-06-27 12:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:14 --> Total execution time: 0.0506
DEBUG - 2022-06-27 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:17 --> Total execution time: 0.0426
DEBUG - 2022-06-27 12:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:19 --> Total execution time: 0.0975
DEBUG - 2022-06-27 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:23 --> Total execution time: 0.0514
DEBUG - 2022-06-27 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:25 --> Total execution time: 0.0411
DEBUG - 2022-06-27 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:26 --> Total execution time: 0.0446
DEBUG - 2022-06-27 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:26 --> Total execution time: 0.0654
DEBUG - 2022-06-27 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:30 --> Total execution time: 0.0410
DEBUG - 2022-06-27 12:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:39 --> Total execution time: 0.0566
DEBUG - 2022-06-27 12:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:52 --> Total execution time: 0.0445
DEBUG - 2022-06-27 12:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:59 --> Total execution time: 0.0470
DEBUG - 2022-06-27 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:13 --> Total execution time: 0.0545
DEBUG - 2022-06-27 12:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:48 --> Total execution time: 0.0500
DEBUG - 2022-06-27 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:07 --> Total execution time: 0.0570
DEBUG - 2022-06-27 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:10 --> Total execution time: 0.0436
DEBUG - 2022-06-27 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:16 --> Total execution time: 0.0553
DEBUG - 2022-06-27 12:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:25 --> Total execution time: 0.1105
DEBUG - 2022-06-27 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:52 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:53 --> Total execution time: 0.0840
DEBUG - 2022-06-27 22:38:53 --> Total execution time: 0.1043
DEBUG - 2022-06-27 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:59 --> Total execution time: 0.1086
DEBUG - 2022-06-27 12:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:00 --> Total execution time: 0.0441
DEBUG - 2022-06-27 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:03 --> Total execution time: 0.0501
DEBUG - 2022-06-27 12:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:06 --> Total execution time: 0.0495
DEBUG - 2022-06-27 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:11 --> Total execution time: 0.0612
DEBUG - 2022-06-27 12:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:14 --> Total execution time: 0.0922
DEBUG - 2022-06-27 12:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:16 --> Total execution time: 0.0856
DEBUG - 2022-06-27 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:20 --> Total execution time: 0.0507
DEBUG - 2022-06-27 12:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:24 --> Total execution time: 0.0517
DEBUG - 2022-06-27 12:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:32 --> Total execution time: 0.0764
DEBUG - 2022-06-27 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:37 --> Total execution time: 0.0582
DEBUG - 2022-06-27 12:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:41 --> Total execution time: 0.1328
DEBUG - 2022-06-27 12:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:47 --> Total execution time: 0.0783
DEBUG - 2022-06-27 12:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:48 --> Total execution time: 0.0695
DEBUG - 2022-06-27 12:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:52 --> Total execution time: 0.0495
DEBUG - 2022-06-27 12:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:14 --> Total execution time: 0.1209
DEBUG - 2022-06-27 12:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:27 --> Total execution time: 0.1078
DEBUG - 2022-06-27 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:30 --> Total execution time: 0.0621
DEBUG - 2022-06-27 12:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:33 --> Total execution time: 0.0461
DEBUG - 2022-06-27 12:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:35 --> Total execution time: 0.0963
DEBUG - 2022-06-27 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:43 --> Total execution time: 0.1212
DEBUG - 2022-06-27 12:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:43 --> Total execution time: 0.0447
DEBUG - 2022-06-27 12:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:45 --> Total execution time: 0.0627
DEBUG - 2022-06-27 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:56 --> Total execution time: 0.0568
DEBUG - 2022-06-27 12:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:58 --> Total execution time: 0.0454
DEBUG - 2022-06-27 12:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:59 --> Total execution time: 0.0537
DEBUG - 2022-06-27 12:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:05 --> Total execution time: 0.0587
DEBUG - 2022-06-27 12:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:07 --> Total execution time: 0.0529
DEBUG - 2022-06-27 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:08 --> Total execution time: 0.0513
DEBUG - 2022-06-27 12:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:15 --> Total execution time: 0.0489
DEBUG - 2022-06-27 12:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:18 --> Total execution time: 0.0663
DEBUG - 2022-06-27 12:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:11:19 --> Total execution time: 0.0445
DEBUG - 2022-06-27 12:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:20 --> Total execution time: 0.0726
DEBUG - 2022-06-27 12:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:21 --> Total execution time: 0.0527
DEBUG - 2022-06-27 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:24 --> Total execution time: 0.0507
DEBUG - 2022-06-27 12:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:30 --> Total execution time: 0.0574
DEBUG - 2022-06-27 12:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:41:54 --> Total execution time: 0.0748
DEBUG - 2022-06-27 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:03 --> Total execution time: 0.0998
DEBUG - 2022-06-27 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:13 --> Total execution time: 0.1317
DEBUG - 2022-06-27 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:16 --> Total execution time: 0.1037
DEBUG - 2022-06-27 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:17 --> Total execution time: 0.0638
DEBUG - 2022-06-27 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:22 --> Total execution time: 0.0587
DEBUG - 2022-06-27 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:12:44 --> Total execution time: 0.0425
DEBUG - 2022-06-27 12:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:46 --> Total execution time: 0.0564
DEBUG - 2022-06-27 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:55 --> Total execution time: 0.0486
DEBUG - 2022-06-27 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:13:00 --> Total execution time: 0.0471
DEBUG - 2022-06-27 12:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:02 --> Total execution time: 0.0506
DEBUG - 2022-06-27 12:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:05 --> Total execution time: 0.0500
DEBUG - 2022-06-27 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:14 --> Total execution time: 0.0587
DEBUG - 2022-06-27 12:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:23 --> Total execution time: 0.0492
DEBUG - 2022-06-27 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:27 --> Total execution time: 0.0596
DEBUG - 2022-06-27 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:28 --> Total execution time: 0.0449
DEBUG - 2022-06-27 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:29 --> Total execution time: 0.0692
DEBUG - 2022-06-27 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:31 --> Total execution time: 0.0826
DEBUG - 2022-06-27 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:43:36 --> Total execution time: 0.0695
DEBUG - 2022-06-27 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:44:06 --> Total execution time: 0.0491
DEBUG - 2022-06-27 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:44:25 --> Total execution time: 0.0489
DEBUG - 2022-06-27 12:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:44:42 --> Total execution time: 0.0463
DEBUG - 2022-06-27 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:44:47 --> Total execution time: 0.0486
DEBUG - 2022-06-27 12:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:44:49 --> Total execution time: 0.0586
DEBUG - 2022-06-27 12:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:45:07 --> Total execution time: 0.0534
DEBUG - 2022-06-27 12:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:45:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 12:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:45:21 --> Total execution time: 0.0460
DEBUG - 2022-06-27 12:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:45:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 22:45:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 22:45:22 --> Total execution time: 0.1818
DEBUG - 2022-06-27 12:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:45:25 --> Total execution time: 0.1094
DEBUG - 2022-06-27 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 12:16:00 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:17:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:47:46 --> Total execution time: 0.1212
DEBUG - 2022-06-27 12:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:47:51 --> Total execution time: 0.0612
DEBUG - 2022-06-27 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:47:57 --> Total execution time: 0.0510
DEBUG - 2022-06-27 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:07 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:07 --> Total execution time: 0.0557
DEBUG - 2022-06-27 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:13 --> Total execution time: 0.0623
DEBUG - 2022-06-27 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:18:21 --> Total execution time: 0.0547
DEBUG - 2022-06-27 12:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:18:24 --> Total execution time: 0.0451
DEBUG - 2022-06-27 12:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:18:29 --> Total execution time: 0.0612
DEBUG - 2022-06-27 12:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:31 --> Total execution time: 0.0524
DEBUG - 2022-06-27 12:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:34 --> Total execution time: 0.0737
DEBUG - 2022-06-27 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:43 --> Total execution time: 0.0554
DEBUG - 2022-06-27 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:43 --> Total execution time: 0.0537
DEBUG - 2022-06-27 12:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:54 --> Total execution time: 0.0552
DEBUG - 2022-06-27 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:49:00 --> Total execution time: 0.0540
DEBUG - 2022-06-27 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:49:04 --> Total execution time: 0.0632
DEBUG - 2022-06-27 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:49:09 --> Total execution time: 0.0456
DEBUG - 2022-06-27 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:49:41 --> Total execution time: 0.0594
DEBUG - 2022-06-27 12:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:50:10 --> Total execution time: 0.0486
DEBUG - 2022-06-27 12:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:50:17 --> Total execution time: 0.0484
DEBUG - 2022-06-27 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:50:23 --> Total execution time: 0.0531
DEBUG - 2022-06-27 12:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:50:27 --> Total execution time: 0.0572
DEBUG - 2022-06-27 12:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:51:14 --> Total execution time: 0.0685
DEBUG - 2022-06-27 12:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:05 --> Total execution time: 0.0638
DEBUG - 2022-06-27 12:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:22 --> Total execution time: 0.0637
DEBUG - 2022-06-27 12:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:25 --> Total execution time: 0.0628
DEBUG - 2022-06-27 12:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:35 --> Total execution time: 0.0494
DEBUG - 2022-06-27 12:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:47 --> Total execution time: 0.1087
DEBUG - 2022-06-27 12:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:23:42 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:42 --> Total execution time: 0.0371
DEBUG - 2022-06-27 12:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:54:05 --> Total execution time: 0.0379
DEBUG - 2022-06-27 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:54:44 --> Total execution time: 0.0561
DEBUG - 2022-06-27 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:17 --> Total execution time: 0.0565
DEBUG - 2022-06-27 12:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:25 --> Total execution time: 0.1011
DEBUG - 2022-06-27 12:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:38 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:38 --> Total execution time: 0.1161
DEBUG - 2022-06-27 12:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:39 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:39 --> Total execution time: 0.0565
DEBUG - 2022-06-27 12:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:42 --> Total execution time: 0.0573
DEBUG - 2022-06-27 12:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:46 --> Total execution time: 0.0727
DEBUG - 2022-06-27 12:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:49 --> Total execution time: 0.0674
DEBUG - 2022-06-27 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:51 --> Total execution time: 0.0462
DEBUG - 2022-06-27 12:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:55:58 --> Total execution time: 0.0506
DEBUG - 2022-06-27 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:00 --> Total execution time: 0.0730
DEBUG - 2022-06-27 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:07 --> Total execution time: 0.0478
DEBUG - 2022-06-27 12:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:21 --> Total execution time: 0.0493
DEBUG - 2022-06-27 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:59 --> Total execution time: 0.0374
DEBUG - 2022-06-27 12:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:27:13 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:57:13 --> Total execution time: 0.0536
DEBUG - 2022-06-27 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:00:51 --> Total execution time: 0.0984
DEBUG - 2022-06-27 12:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:02:13 --> Total execution time: 0.1221
DEBUG - 2022-06-27 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:02:22 --> Total execution time: 0.0543
DEBUG - 2022-06-27 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:02:24 --> Total execution time: 0.0532
DEBUG - 2022-06-27 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:02:25 --> Total execution time: 0.0560
DEBUG - 2022-06-27 12:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:02:31 --> Total execution time: 0.0495
DEBUG - 2022-06-27 12:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:03:32 --> Total execution time: 0.0513
DEBUG - 2022-06-27 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:04:06 --> Total execution time: 0.0433
DEBUG - 2022-06-27 12:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:04:36 --> Total execution time: 0.0469
DEBUG - 2022-06-27 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:05:44 --> Total execution time: 0.0543
DEBUG - 2022-06-27 12:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:05:53 --> Total execution time: 0.0626
DEBUG - 2022-06-27 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:30 --> Total execution time: 0.1201
DEBUG - 2022-06-27 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:34 --> Total execution time: 0.0500
DEBUG - 2022-06-27 12:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:37:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:36 --> Total execution time: 0.1144
DEBUG - 2022-06-27 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:37:39 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:39 --> Total execution time: 0.0528
DEBUG - 2022-06-27 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:53 --> Total execution time: 0.0568
DEBUG - 2022-06-27 12:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 12:40:24 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-27 12:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:13:14 --> Total execution time: 0.1056
DEBUG - 2022-06-27 12:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:03 --> Total execution time: 0.0519
DEBUG - 2022-06-27 12:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:43 --> Total execution time: 0.0531
DEBUG - 2022-06-27 12:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:50:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:20:46 --> Total execution time: 0.0576
DEBUG - 2022-06-27 12:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:51:00 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:00 --> Total execution time: 0.0491
DEBUG - 2022-06-27 12:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:12 --> Total execution time: 0.1165
DEBUG - 2022-06-27 12:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:20 --> Total execution time: 0.0490
DEBUG - 2022-06-27 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:42 --> Total execution time: 0.0519
DEBUG - 2022-06-27 12:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:47 --> Total execution time: 0.0470
DEBUG - 2022-06-27 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:54 --> Total execution time: 0.0825
DEBUG - 2022-06-27 12:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:56 --> Total execution time: 0.0560
DEBUG - 2022-06-27 12:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:54:56 --> Total execution time: 0.0929
DEBUG - 2022-06-27 12:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:09 --> Total execution time: 0.0518
DEBUG - 2022-06-27 12:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:33 --> Total execution time: 0.0672
DEBUG - 2022-06-27 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:38 --> Total execution time: 0.0568
DEBUG - 2022-06-27 12:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:55:40 --> Total execution time: 0.0628
DEBUG - 2022-06-27 12:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:55:42 --> Total execution time: 0.0596
DEBUG - 2022-06-27 12:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:55:42 --> Total execution time: 0.1084
DEBUG - 2022-06-27 12:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:43 --> Total execution time: 0.0614
DEBUG - 2022-06-27 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:46 --> Total execution time: 0.0518
DEBUG - 2022-06-27 12:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 12:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:03 --> Total execution time: 0.0658
DEBUG - 2022-06-27 12:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:07 --> Total execution time: 0.0476
DEBUG - 2022-06-27 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:14 --> Total execution time: 0.0780
DEBUG - 2022-06-27 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:16 --> Total execution time: 0.0531
DEBUG - 2022-06-27 12:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:20 --> Total execution time: 0.0545
DEBUG - 2022-06-27 12:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:27 --> Total execution time: 0.0509
DEBUG - 2022-06-27 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 12:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 12:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:20 --> Total execution time: 0.0713
DEBUG - 2022-06-27 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:03 --> Total execution time: 0.1615
DEBUG - 2022-06-27 13:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:05 --> Total execution time: 0.1176
DEBUG - 2022-06-27 13:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:08 --> Total execution time: 0.0659
DEBUG - 2022-06-27 13:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:21 --> Total execution time: 0.0726
DEBUG - 2022-06-27 13:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:34:22 --> Total execution time: 0.1369
DEBUG - 2022-06-27 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:12 --> Total execution time: 0.0503
DEBUG - 2022-06-27 13:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:20 --> Total execution time: 0.0535
DEBUG - 2022-06-27 13:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:25 --> Total execution time: 0.0440
DEBUG - 2022-06-27 13:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:39 --> Total execution time: 0.0494
DEBUG - 2022-06-27 13:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:44 --> Total execution time: 0.0439
DEBUG - 2022-06-27 13:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:48 --> Total execution time: 0.0734
DEBUG - 2022-06-27 13:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:49 --> Total execution time: 0.0554
DEBUG - 2022-06-27 13:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:36:31 --> Total execution time: 0.0474
DEBUG - 2022-06-27 13:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:36:50 --> Total execution time: 0.0704
DEBUG - 2022-06-27 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 13:06:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:36:52 --> Total execution time: 0.0501
DEBUG - 2022-06-27 13:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 13:06:55 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:38:58 --> Total execution time: 0.1942
DEBUG - 2022-06-27 13:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:39:02 --> Total execution time: 0.0545
DEBUG - 2022-06-27 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:39:05 --> Total execution time: 0.0553
DEBUG - 2022-06-27 13:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:39:17 --> Total execution time: 0.0365
DEBUG - 2022-06-27 13:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:39:18 --> Total execution time: 0.0466
DEBUG - 2022-06-27 13:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:39:20 --> Total execution time: 0.0568
DEBUG - 2022-06-27 13:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:43:41 --> Total execution time: 0.1337
DEBUG - 2022-06-27 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:43:42 --> Total execution time: 0.0574
DEBUG - 2022-06-27 13:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:44:14 --> Total execution time: 0.0490
DEBUG - 2022-06-27 13:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:46:57 --> Total execution time: 0.0946
DEBUG - 2022-06-27 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:18:42 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:48:42 --> Total execution time: 0.0659
DEBUG - 2022-06-27 13:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:19:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:49:30 --> Total execution time: 0.0360
DEBUG - 2022-06-27 13:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:50:03 --> Total execution time: 0.0450
DEBUG - 2022-06-27 13:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:22:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:52:02 --> Total execution time: 0.0486
DEBUG - 2022-06-27 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:22:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:52:17 --> Total execution time: 0.0505
DEBUG - 2022-06-27 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:52:20 --> Total execution time: 0.0541
DEBUG - 2022-06-27 13:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:22:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:52:46 --> Total execution time: 0.0591
DEBUG - 2022-06-27 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 13:34:11 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 13:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:35:50 --> Total execution time: 0.0391
DEBUG - 2022-06-27 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:35:57 --> Total execution time: 0.0778
DEBUG - 2022-06-27 13:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:35:57 --> Total execution time: 0.1048
DEBUG - 2022-06-27 13:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:37:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 13:37:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 13:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:38:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:38:14 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 13:39:25 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 13:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 13:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 13:51:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 13:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 13:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 14:04:59 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:14:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 14:14:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 14:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 14:31:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 14:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:35:25 --> No URI present. Default controller set.
DEBUG - 2022-06-27 14:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 14:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 14:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 14:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 14:56:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 14:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 14:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:17:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 15:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:19:49 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 15:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:22:00 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 15:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:37:44 --> No URI present. Default controller set.
DEBUG - 2022-06-27 15:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:45:34 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 15:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:50:10 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 15:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:50:10 --> No URI present. Default controller set.
DEBUG - 2022-06-27 15:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:50:10 --> No URI present. Default controller set.
DEBUG - 2022-06-27 15:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:50:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 15:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:50:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:53:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 15:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 15:53:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 15:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:57:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 15:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:57:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 15:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 15:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 15:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 15:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:06:22 --> Total execution time: 0.0526
DEBUG - 2022-06-27 16:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 16:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:45 --> No URI present. Default controller set.
DEBUG - 2022-06-27 16:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:07:53 --> No URI present. Default controller set.
DEBUG - 2022-06-27 16:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 16:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 16:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:57:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 16:57:08 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 16:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 16:59:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 16:59:40 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 17:01:51 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 17:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:04:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 17:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:19:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 17:19:53 --> 404 Page Not Found: Courses/index
DEBUG - 2022-06-27 17:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 17:25:22 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 17:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:26:12 --> No URI present. Default controller set.
DEBUG - 2022-06-27 17:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:49:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 17:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 17:54:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 17:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 17:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 18:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 18:37:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 18:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:39:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 18:39:51 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:42:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 18:42:04 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 18:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:47:17 --> No URI present. Default controller set.
DEBUG - 2022-06-27 18:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 18:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:53:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 18:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 18:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 18:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 18:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 18:58:51 --> 404 Page Not Found: Wp-json/am-member
DEBUG - 2022-06-27 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:04:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 19:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:06:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 19:06:12 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 19:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:08:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 19:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:13:18 --> No URI present. Default controller set.
DEBUG - 2022-06-27 19:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 19:17:35 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-06-27 19:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 19:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:45:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 19:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 19:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 19:45:06 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-27 19:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 19:45:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 19:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 19:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:17:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 20:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:20:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 20:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:22:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:22:28 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 20:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:25:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 20:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:01 --> Total execution time: 0.0344
DEBUG - 2022-06-27 20:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:04 --> Total execution time: 0.0532
DEBUG - 2022-06-27 20:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:04 --> Total execution time: 0.1013
DEBUG - 2022-06-27 20:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:09 --> No URI present. Default controller set.
DEBUG - 2022-06-27 20:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:27 --> Total execution time: 0.0491
DEBUG - 2022-06-27 20:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:29 --> Total execution time: 0.0482
DEBUG - 2022-06-27 20:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:26:29 --> Total execution time: 0.0946
DEBUG - 2022-06-27 20:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:44:32 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-27 20:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:45:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 20:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:45:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 20:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:45:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:45:52 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 20:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 20:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 20:54:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 20:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 20:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 20:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 20:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:02:27 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:13:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:14:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:14:47 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:15:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:16:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:16:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-27 21:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:16:12 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-27 21:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:16:56 --> Total execution time: 0.0579
DEBUG - 2022-06-27 21:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:03 --> Total execution time: 0.0756
DEBUG - 2022-06-27 21:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:32 --> Total execution time: 0.0466
DEBUG - 2022-06-27 21:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:39 --> Total execution time: 0.0570
DEBUG - 2022-06-27 21:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:23:30 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:54 --> Total execution time: 0.0345
DEBUG - 2022-06-27 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:57 --> Total execution time: 0.0522
DEBUG - 2022-06-27 21:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:23:57 --> Total execution time: 0.1029
DEBUG - 2022-06-27 21:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:27:37 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:29:08 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:40:16 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:40:53 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:40:56 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-27 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:40:56 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-27 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:40:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:40:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:41:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:43:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:43:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 21:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:43:24 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-27 21:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:43:24 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-27 21:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:43:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:45:48 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-27 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:45:48 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-27 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:45:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:47:21 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:47:22 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:27 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:49:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:50:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:52:34 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:52:37 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:54:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:54:36 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2022-06-27 21:54:36 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-27 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:54:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:54:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:54:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 21:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 21:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 21:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:56:45 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 21:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 21:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 21:59:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 22:01:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 22:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:04:03 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 22:04:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:12:11 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:13:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:26 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:14:31 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:15:06 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 22:24:52 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-27 22:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:33:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:33:32 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:34:15 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 22:35:57 --> 404 Page Not Found: Assets/colors
DEBUG - 2022-06-27 22:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:36:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:36:59 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:37:41 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:47:21 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:48:02 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:52:48 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:02 --> Total execution time: 0.0553
DEBUG - 2022-06-27 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:05 --> Total execution time: 0.0503
DEBUG - 2022-06-27 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:05 --> Total execution time: 0.0866
DEBUG - 2022-06-27 22:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 22:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 22:53:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 22:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:59:43 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:59:50 --> Total execution time: 0.0598
DEBUG - 2022-06-27 22:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:59:51 --> Total execution time: 0.0775
DEBUG - 2022-06-27 22:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 22:59:51 --> Total execution time: 0.0986
DEBUG - 2022-06-27 22:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 22:59:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 22:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 22:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 23:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:01:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 23:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:03:39 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:31 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:54 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:56 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:02 --> Total execution time: 0.0397
DEBUG - 2022-06-27 23:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:42 --> Total execution time: 0.0345
DEBUG - 2022-06-27 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:09:44 --> Total execution time: 0.0620
DEBUG - 2022-06-27 23:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:09:44 --> Total execution time: 0.0739
DEBUG - 2022-06-27 23:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:12:53 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-27 23:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:13:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:20 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:19:46 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:28 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:40 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:44 --> Total execution time: 0.0623
DEBUG - 2022-06-27 23:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:46 --> Total execution time: 0.0590
DEBUG - 2022-06-27 23:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:23:46 --> Total execution time: 0.1341
DEBUG - 2022-06-27 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:06 --> Total execution time: 0.0484
DEBUG - 2022-06-27 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:08 --> Total execution time: 0.0517
DEBUG - 2022-06-27 23:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:08 --> Total execution time: 0.1021
DEBUG - 2022-06-27 23:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:12 --> Total execution time: 0.0493
DEBUG - 2022-06-27 23:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-27 23:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:24:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:50 --> Total execution time: 0.0458
DEBUG - 2022-06-27 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:51 --> Total execution time: 0.0460
DEBUG - 2022-06-27 23:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:52 --> Total execution time: 0.0526
DEBUG - 2022-06-27 23:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:24:52 --> Total execution time: 0.0905
DEBUG - 2022-06-27 23:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:45 --> Total execution time: 0.1203
DEBUG - 2022-06-27 23:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:46 --> Total execution time: 0.0842
DEBUG - 2022-06-27 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:47 --> Total execution time: 0.0632
DEBUG - 2022-06-27 23:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:49 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:25:59 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:33 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:36 --> Total execution time: 0.0577
DEBUG - 2022-06-27 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:37 --> Total execution time: 0.0468
DEBUG - 2022-06-27 23:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:39 --> Total execution time: 0.0458
DEBUG - 2022-06-27 23:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:39 --> Total execution time: 0.1168
DEBUG - 2022-06-27 23:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:23 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:24 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:28:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:29:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-27 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:29:17 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-27 23:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:01 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:16 --> Total execution time: 0.0474
DEBUG - 2022-06-27 23:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:17 --> Total execution time: 0.0573
DEBUG - 2022-06-27 23:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:17 --> Total execution time: 0.1107
DEBUG - 2022-06-27 23:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:34:43 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:35:16 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-27 23:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:36 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:35:58 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:37:05 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:37:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:37:47 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-27 23:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-27 23:39:54 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-27 23:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:46:59 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:55:50 --> No URI present. Default controller set.
DEBUG - 2022-06-27 23:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-27 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 23:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 23:57:53 --> Encryption: Auto-configured driver 'openssl'.
