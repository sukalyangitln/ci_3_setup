<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-04 04:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:52:18 --> Total execution time: 1.0269
DEBUG - 2022-05-04 04:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:22:31 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:52:31 --> Total execution time: 0.0665
DEBUG - 2022-05-04 04:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:28:11 --> Total execution time: 0.7998
DEBUG - 2022-05-04 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:58:32 --> Total execution time: 0.2006
DEBUG - 2022-05-04 04:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:59:03 --> Total execution time: 0.0499
DEBUG - 2022-05-04 04:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:59:36 --> Total execution time: 0.0302
DEBUG - 2022-05-04 04:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:30:03 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:00:03 --> Total execution time: 0.1090
DEBUG - 2022-05-04 04:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:00:05 --> Total execution time: 0.0427
DEBUG - 2022-05-04 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:30:10 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:00:10 --> Total execution time: 0.0299
DEBUG - 2022-05-04 04:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:00:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-04 04:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:00:20 --> Total execution time: 0.0301
DEBUG - 2022-05-04 04:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:30:38 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:00:38 --> Total execution time: 0.0323
DEBUG - 2022-05-04 04:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:31:05 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:01:05 --> Total execution time: 0.0321
DEBUG - 2022-05-04 04:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:32:19 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:02:19 --> Total execution time: 0.5266
DEBUG - 2022-05-04 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:03:45 --> Total execution time: 0.0392
DEBUG - 2022-05-04 04:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:03:53 --> Total execution time: 0.0369
DEBUG - 2022-05-04 04:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:45:09 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:15:10 --> Total execution time: 0.8296
DEBUG - 2022-05-04 04:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:46:36 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:16:37 --> Total execution time: 0.8346
DEBUG - 2022-05-04 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:18:39 --> Total execution time: 0.0539
DEBUG - 2022-05-04 04:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:18:45 --> Total execution time: 0.0382
DEBUG - 2022-05-04 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:18:53 --> Total execution time: 0.0357
DEBUG - 2022-05-04 04:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:17 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:19:17 --> Total execution time: 0.3062
DEBUG - 2022-05-04 04:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:49:24 --> Total execution time: 0.0399
DEBUG - 2022-05-04 04:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:19:28 --> Total execution time: 0.0391
DEBUG - 2022-05-04 04:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:19:34 --> Total execution time: 0.0330
DEBUG - 2022-05-04 04:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:49:49 --> Total execution time: 0.0323
DEBUG - 2022-05-04 04:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:19:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-04 04:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:20:01 --> Total execution time: 0.0332
DEBUG - 2022-05-04 04:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:50:09 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:20:09 --> Total execution time: 0.0318
DEBUG - 2022-05-04 04:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 04:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:20:14 --> Total execution time: 0.0302
DEBUG - 2022-05-04 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:20:29 --> Total execution time: 0.0299
DEBUG - 2022-05-04 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 04:50:54 --> No URI present. Default controller set.
DEBUG - 2022-05-04 04:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 04:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:20:54 --> Total execution time: 0.0336
DEBUG - 2022-05-04 05:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:02:58 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:32:59 --> Total execution time: 0.8327
DEBUG - 2022-05-04 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:04:11 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:34:11 --> Total execution time: 0.0368
DEBUG - 2022-05-04 05:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:05:24 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:35:24 --> Total execution time: 0.0380
DEBUG - 2022-05-04 05:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:36:01 --> Total execution time: 0.0432
DEBUG - 2022-05-04 05:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 05:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:36:07 --> Total execution time: 0.0914
DEBUG - 2022-05-04 05:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:36:14 --> Total execution time: 0.0438
DEBUG - 2022-05-04 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:36:19 --> Total execution time: 0.0397
DEBUG - 2022-05-04 05:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:36:25 --> Total execution time: 0.0332
DEBUG - 2022-05-04 05:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:42:59 --> Total execution time: 0.9015
DEBUG - 2022-05-04 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:41:21 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:11:22 --> Total execution time: 0.8377
DEBUG - 2022-05-04 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:48:12 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:18:12 --> Total execution time: 0.0393
DEBUG - 2022-05-04 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 05:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:18:34 --> Total execution time: 0.1245
DEBUG - 2022-05-04 05:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:18:42 --> Total execution time: 0.0407
DEBUG - 2022-05-04 05:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:49:01 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:19:01 --> Total execution time: 0.0320
DEBUG - 2022-05-04 05:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:28:36 --> Total execution time: 0.0573
DEBUG - 2022-05-04 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-04 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:09 --> Total execution time: 0.0290
DEBUG - 2022-05-04 05:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-04 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:24 --> Total execution time: 0.0292
DEBUG - 2022-05-04 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-04 05:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:42 --> Total execution time: 0.0296
DEBUG - 2022-05-04 05:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 05:59:45 --> No URI present. Default controller set.
DEBUG - 2022-05-04 05:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 05:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:29:45 --> Total execution time: 0.0343
DEBUG - 2022-05-04 08:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 08:20:05 --> No URI present. Default controller set.
DEBUG - 2022-05-04 08:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 08:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 13:50:06 --> Total execution time: 1.4001
DEBUG - 2022-05-04 08:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 08:20:37 --> No URI present. Default controller set.
DEBUG - 2022-05-04 08:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 08:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 13:50:37 --> Total execution time: 0.0363
DEBUG - 2022-05-04 09:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:29:00 --> No URI present. Default controller set.
DEBUG - 2022-05-04 09:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:59:01 --> Total execution time: 1.0572
DEBUG - 2022-05-04 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:59:21 --> Total execution time: 0.0442
DEBUG - 2022-05-04 09:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:59:28 --> Total execution time: 0.0915
DEBUG - 2022-05-04 09:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:59:38 --> Total execution time: 0.0508
DEBUG - 2022-05-04 09:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:59:46 --> Total execution time: 0.0385
DEBUG - 2022-05-04 09:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:30:25 --> Total execution time: 0.0390
DEBUG - 2022-05-04 09:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:00:30 --> Total execution time: 0.0816
DEBUG - 2022-05-04 09:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:00:36 --> Total execution time: 0.0758
DEBUG - 2022-05-04 09:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:00:40 --> Total execution time: 0.0827
DEBUG - 2022-05-04 09:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:22:36 --> Total execution time: 0.8356
DEBUG - 2022-05-04 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:54:09 --> Total execution time: 0.0391
DEBUG - 2022-05-04 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:24:58 --> Total execution time: 0.0526
DEBUG - 2022-05-04 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:05 --> Total execution time: 0.0420
DEBUG - 2022-05-04 09:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:11 --> Total execution time: 0.0626
DEBUG - 2022-05-04 09:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:21 --> No URI present. Default controller set.
DEBUG - 2022-05-04 09:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:21 --> Total execution time: 0.0521
DEBUG - 2022-05-04 09:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:32 --> Total execution time: 0.0342
DEBUG - 2022-05-04 09:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 09:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:36 --> Total execution time: 0.0696
DEBUG - 2022-05-04 09:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:38 --> Total execution time: 0.0387
DEBUG - 2022-05-04 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:25:45 --> Total execution time: 0.0319
DEBUG - 2022-05-04 10:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 10:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 10:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:48:07 --> Total execution time: 0.0828
DEBUG - 2022-05-04 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 10:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:48:16 --> Total execution time: 0.0676
DEBUG - 2022-05-04 10:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 10:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 10:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:56:23 --> Total execution time: 0.0826
DEBUG - 2022-05-04 10:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 10:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 10:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:56:31 --> Total execution time: 0.0682
DEBUG - 2022-05-04 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:20:04 --> Total execution time: 0.8736
DEBUG - 2022-05-04 11:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:20:30 --> Total execution time: 0.0416
DEBUG - 2022-05-04 11:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 11:21:18 --> 404 Page Not Found: Use/index
DEBUG - 2022-05-04 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 11:21:19 --> 404 Page Not Found: User/index
DEBUG - 2022-05-04 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 11:21:22 --> 404 Page Not Found: User/index
DEBUG - 2022-05-04 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 11:21:24 --> 404 Page Not Found: User/lo
DEBUG - 2022-05-04 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 11:21:24 --> 404 Page Not Found: User/log
DEBUG - 2022-05-04 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 11:21:24 --> 404 Page Not Found: User/logi
DEBUG - 2022-05-04 11:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:51:25 --> Total execution time: 0.0477
DEBUG - 2022-05-04 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:21:58 --> Total execution time: 0.4549
DEBUG - 2022-05-04 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:22:02 --> Total execution time: 0.0285
DEBUG - 2022-05-04 11:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:52:17 --> Total execution time: 0.0533
DEBUG - 2022-05-04 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:52:18 --> Total execution time: 0.0334
DEBUG - 2022-05-04 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:52:20 --> Total execution time: 0.0336
DEBUG - 2022-05-04 11:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:52:28 --> Total execution time: 0.0450
DEBUG - 2022-05-04 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:52:35 --> Total execution time: 0.0676
DEBUG - 2022-05-04 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:52:37 --> Total execution time: 0.0640
DEBUG - 2022-05-04 11:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:53:19 --> Total execution time: 0.3905
DEBUG - 2022-05-04 11:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:53:44 --> Total execution time: 0.0934
DEBUG - 2022-05-04 11:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 11:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 11:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 17:10:35 --> Total execution time: 1.3711
DEBUG - 2022-05-04 13:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 18:56:55 --> Total execution time: 1.2030
DEBUG - 2022-05-04 13:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:27:06 --> No URI present. Default controller set.
DEBUG - 2022-05-04 13:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 18:57:06 --> Total execution time: 0.0701
DEBUG - 2022-05-04 13:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:13:57 --> Total execution time: 0.0481
DEBUG - 2022-05-04 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:19:58 --> Total execution time: 0.0305
DEBUG - 2022-05-04 13:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:20:06 --> Total execution time: 0.1020
DEBUG - 2022-05-04 13:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:20:11 --> Total execution time: 0.0563
DEBUG - 2022-05-04 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:20:15 --> Total execution time: 0.0384
DEBUG - 2022-05-04 13:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:20:48 --> Total execution time: 0.0320
DEBUG - 2022-05-04 13:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:25:38 --> Total execution time: 0.8356
DEBUG - 2022-05-04 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 13:58:04 --> Total execution time: 0.1544
DEBUG - 2022-05-04 13:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 13:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:28:35 --> Total execution time: 0.2044
DEBUG - 2022-05-04 13:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:28:47 --> Total execution time: 0.0467
DEBUG - 2022-05-04 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:28:59 --> Total execution time: 0.0565
DEBUG - 2022-05-04 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 13:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 13:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:29:16 --> Total execution time: 0.0912
DEBUG - 2022-05-04 14:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:54:04 --> Total execution time: 0.0823
DEBUG - 2022-05-04 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:54:10 --> Total execution time: 0.0830
DEBUG - 2022-05-04 14:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:54:38 --> Total execution time: 0.4534
DEBUG - 2022-05-04 14:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:54:44 --> Total execution time: 0.0308
DEBUG - 2022-05-04 14:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:54:52 --> Total execution time: 0.0515
DEBUG - 2022-05-04 14:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:54:58 --> Total execution time: 0.0735
DEBUG - 2022-05-04 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:55:11 --> Total execution time: 0.2117
DEBUG - 2022-05-04 14:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:55:13 --> Total execution time: 0.0333
DEBUG - 2022-05-04 14:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:55:43 --> Total execution time: 0.3879
DEBUG - 2022-05-04 14:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:55:47 --> Total execution time: 0.0315
DEBUG - 2022-05-04 14:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:57:17 --> Total execution time: 0.0486
DEBUG - 2022-05-04 14:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:57:22 --> Total execution time: 0.0332
DEBUG - 2022-05-04 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:57:36 --> Total execution time: 0.0422
DEBUG - 2022-05-04 14:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:57:43 --> Total execution time: 0.0321
DEBUG - 2022-05-04 14:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:59:20 --> Total execution time: 0.9958
DEBUG - 2022-05-04 14:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:59:35 --> Total execution time: 0.9028
DEBUG - 2022-05-04 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 19:59:59 --> Total execution time: 0.9067
DEBUG - 2022-05-04 14:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:00:50 --> Total execution time: 0.8927
DEBUG - 2022-05-04 14:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:01:07 --> Total execution time: 0.0586
DEBUG - 2022-05-04 14:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:01:16 --> Total execution time: 0.0368
DEBUG - 2022-05-04 14:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:01:21 --> Total execution time: 0.0330
DEBUG - 2022-05-04 14:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:15:54 --> Total execution time: 0.1282
DEBUG - 2022-05-04 14:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:18:57 --> Total execution time: 0.1030
DEBUG - 2022-05-04 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:51:17 --> Total execution time: 0.2976
DEBUG - 2022-05-04 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:51:25 --> Total execution time: 0.0290
DEBUG - 2022-05-04 14:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:21:39 --> Total execution time: 0.0589
DEBUG - 2022-05-04 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:51 --> No URI present. Default controller set.
DEBUG - 2022-05-04 14:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:21:51 --> Total execution time: 0.0939
DEBUG - 2022-05-04 14:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:21:55 --> Total execution time: 0.0316
DEBUG - 2022-05-04 14:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:23:07 --> Total execution time: 2.5452
DEBUG - 2022-05-04 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:23:31 --> Total execution time: 0.0961
DEBUG - 2022-05-04 14:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:23:38 --> Total execution time: 0.0289
DEBUG - 2022-05-04 14:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:23:43 --> Total execution time: 0.0609
DEBUG - 2022-05-04 14:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:25:42 --> Total execution time: 0.5740
DEBUG - 2022-05-04 14:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:25:45 --> Total execution time: 0.0712
DEBUG - 2022-05-04 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:25:58 --> Total execution time: 0.0304
DEBUG - 2022-05-04 14:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:26:12 --> Total execution time: 0.0387
DEBUG - 2022-05-04 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:26:18 --> Total execution time: 0.0309
DEBUG - 2022-05-04 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:26:21 --> Total execution time: 0.0307
DEBUG - 2022-05-04 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:26:45 --> Total execution time: 0.0291
DEBUG - 2022-05-04 14:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:26:57 --> Total execution time: 0.8086
DEBUG - 2022-05-04 14:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:26:58 --> Total execution time: 0.0284
DEBUG - 2022-05-04 14:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:27:37 --> Total execution time: 0.0718
DEBUG - 2022-05-04 14:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:27:46 --> Total execution time: 0.0463
DEBUG - 2022-05-04 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:27:55 --> Total execution time: 0.0436
DEBUG - 2022-05-04 14:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:28:48 --> Total execution time: 0.0394
DEBUG - 2022-05-04 14:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:28:53 --> Total execution time: 0.0536
DEBUG - 2022-05-04 14:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:29:00 --> Total execution time: 0.0387
DEBUG - 2022-05-04 14:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:29:07 --> Total execution time: 0.0412
DEBUG - 2022-05-04 14:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 14:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:29:28 --> Total execution time: 0.0667
DEBUG - 2022-05-04 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 14:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 14:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:29:48 --> Total execution time: 0.0724
DEBUG - 2022-05-04 15:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:30:37 --> Total execution time: 0.0480
DEBUG - 2022-05-04 15:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:30:41 --> Total execution time: 0.0316
DEBUG - 2022-05-04 15:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:30:44 --> Total execution time: 0.0329
DEBUG - 2022-05-04 15:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:30:50 --> Total execution time: 0.0453
DEBUG - 2022-05-04 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:08 --> Total execution time: 0.0308
DEBUG - 2022-05-04 15:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:15 --> Total execution time: 0.0324
DEBUG - 2022-05-04 15:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:19 --> Total execution time: 0.0309
DEBUG - 2022-05-04 15:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:20 --> Total execution time: 0.0316
DEBUG - 2022-05-04 15:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:20 --> Total execution time: 0.0354
DEBUG - 2022-05-04 15:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:20 --> Total execution time: 0.0713
DEBUG - 2022-05-04 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:28 --> Total execution time: 0.0338
DEBUG - 2022-05-04 15:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:39 --> Total execution time: 0.0298
DEBUG - 2022-05-04 15:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:47 --> Total execution time: 0.0292
DEBUG - 2022-05-04 15:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:31:56 --> Total execution time: 0.0302
DEBUG - 2022-05-04 15:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:32:03 --> Total execution time: 0.0299
DEBUG - 2022-05-04 15:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:32:12 --> Total execution time: 0.0317
DEBUG - 2022-05-04 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:32:34 --> Total execution time: 0.0933
DEBUG - 2022-05-04 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:32:46 --> Total execution time: 0.0407
DEBUG - 2022-05-04 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:33:15 --> Total execution time: 0.0374
DEBUG - 2022-05-04 15:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:34:45 --> Total execution time: 0.1201
DEBUG - 2022-05-04 15:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:05:02 --> No URI present. Default controller set.
DEBUG - 2022-05-04 15:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:35:02 --> Total execution time: 0.0687
DEBUG - 2022-05-04 15:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:36:22 --> Total execution time: 0.0767
DEBUG - 2022-05-04 15:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:36:29 --> Total execution time: 0.0621
DEBUG - 2022-05-04 15:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 15:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 15:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 15:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 20:38:20 --> Total execution time: 0.0316
DEBUG - 2022-05-04 16:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:05:25 --> Total execution time: 0.8355
DEBUG - 2022-05-04 16:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:35:44 --> No URI present. Default controller set.
DEBUG - 2022-05-04 16:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:05:44 --> Total execution time: 0.0591
DEBUG - 2022-05-04 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:08:36 --> Total execution time: 0.0778
DEBUG - 2022-05-04 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:08:36 --> Total execution time: 0.0696
DEBUG - 2022-05-04 16:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:09:12 --> Total execution time: 0.0967
DEBUG - 2022-05-04 16:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:09:56 --> Total execution time: 0.0397
DEBUG - 2022-05-04 16:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:10:43 --> Total execution time: 2.0248
DEBUG - 2022-05-04 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:11:11 --> Total execution time: 0.0757
DEBUG - 2022-05-04 16:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:11:35 --> Total execution time: 0.0314
DEBUG - 2022-05-04 16:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:11:50 --> Total execution time: 0.0422
DEBUG - 2022-05-04 16:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:11:55 --> Total execution time: 0.0398
DEBUG - 2022-05-04 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:12:05 --> Total execution time: 0.1343
DEBUG - 2022-05-04 16:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:12:09 --> Total execution time: 0.0445
DEBUG - 2022-05-04 16:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:12:11 --> Total execution time: 0.0365
DEBUG - 2022-05-04 16:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 16:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:12:24 --> Total execution time: 0.0321
DEBUG - 2022-05-04 16:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:12:32 --> Total execution time: 0.0502
DEBUG - 2022-05-04 16:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:13:30 --> Total execution time: 0.0322
DEBUG - 2022-05-04 16:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:13:37 --> Total execution time: 0.0489
DEBUG - 2022-05-04 16:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:13:49 --> Total execution time: 0.0345
DEBUG - 2022-05-04 16:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:56:04 --> No URI present. Default controller set.
DEBUG - 2022-05-04 16:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:26:05 --> Total execution time: 1.2041
DEBUG - 2022-05-04 16:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:27:46 --> Total execution time: 0.8114
DEBUG - 2022-05-04 16:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:27:48 --> Total execution time: 0.0284
DEBUG - 2022-05-04 16:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 16:57:50 --> No URI present. Default controller set.
DEBUG - 2022-05-04 16:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 16:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:27:50 --> Total execution time: 0.0506
DEBUG - 2022-05-04 17:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:41:26 --> Total execution time: 1.2928
DEBUG - 2022-05-04 17:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:53:45 --> Total execution time: 0.0606
DEBUG - 2022-05-04 17:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 17:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:53:54 --> Total execution time: 0.0692
DEBUG - 2022-05-04 17:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:53:59 --> Total execution time: 0.0618
DEBUG - 2022-05-04 17:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:54:02 --> Total execution time: 0.0408
DEBUG - 2022-05-04 17:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 17:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 17:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-04 22:54:47 --> Total execution time: 0.0343
