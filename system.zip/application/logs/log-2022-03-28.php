<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-28 18:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:27:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 18:27:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-03-28 18:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 18:27:29 --> Total execution time: 0.0846
DEBUG - 2022-03-28 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 21:57:31 --> Total execution time: 0.1088
DEBUG - 2022-03-28 18:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 21:57:34 --> Total execution time: 0.1138
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:28:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 21:59:01 --> Total execution time: 0.0511
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 21:59:39 --> Total execution time: 0.0542
DEBUG - 2022-03-28 18:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:00:48 --> Total execution time: 0.0505
DEBUG - 2022-03-28 18:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:01:36 --> Total execution time: 0.0502
DEBUG - 2022-03-28 18:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:01:56 --> Total execution time: 0.0636
DEBUG - 2022-03-28 18:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:35:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:05:10 --> Severity: Notice --> Undefined variable: tdis C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
ERROR - 2022-03-28 22:05:10 --> Severity: Notice --> Trying to get property 'encryption' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
ERROR - 2022-03-28 22:05:10 --> Severity: error --> Exception: Call to a member function encrypt() on null C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-28 18:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:35:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:05:20 --> Severity: Notice --> Undefined variable: tdis C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
ERROR - 2022-03-28 22:05:20 --> Severity: Notice --> Trying to get property 'encryption' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
ERROR - 2022-03-28 22:05:20 --> Severity: error --> Exception: Call to a member function encrypt() on null C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-28 18:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:05:51 --> Total execution time: 0.0507
DEBUG - 2022-03-28 18:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:42:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:12:50 --> Severity: Notice --> Undefined variable: mi C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 76
DEBUG - 2022-03-28 22:12:50 --> Total execution time: 0.0507
DEBUG - 2022-03-28 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:13:17 --> Total execution time: 0.0556
DEBUG - 2022-03-28 18:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:13:23 --> Total execution time: 0.0418
DEBUG - 2022-03-28 18:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 18:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:13:29 --> Total execution time: 0.0464
DEBUG - 2022-03-28 18:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:15:42 --> Total execution time: 0.0614
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:45:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:15:53 --> Total execution time: 0.0542
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:45:53 --> UTF-8 Support Enabled
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:16:10 --> Total execution time: 0.0590
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:20:31 --> Total execution time: 0.0582
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:20:32 --> Total execution time: 0.0548
DEBUG - 2022-03-28 18:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:20:35 --> Total execution time: 0.0443
DEBUG - 2022-03-28 18:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:20:37 --> Total execution time: 0.0433
DEBUG - 2022-03-28 18:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:20:38 --> Total execution time: 0.0660
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:24:19 --> Total execution time: 0.0514
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:54:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:24:20 --> Total execution time: 0.0466
DEBUG - 2022-03-28 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:24:21 --> Total execution time: 0.0589
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:54:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:25:01 --> Total execution time: 0.0503
DEBUG - 2022-03-28 18:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:25:40 --> Total execution time: 0.0868
DEBUG - 2022-03-28 18:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:25:53 --> Total execution time: 0.0678
DEBUG - 2022-03-28 18:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:28:17 --> Total execution time: 0.0504
DEBUG - 2022-03-28 18:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:28:20 --> Total execution time: 0.0674
DEBUG - 2022-03-28 18:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:28:22 --> Total execution time: 0.0469
DEBUG - 2022-03-28 18:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:29:06 --> Total execution time: 0.0830
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:29:10 --> Total execution time: 0.0504
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:10 --> UTF-8 Support Enabled
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:29:51 --> Total execution time: 0.0476
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 18:59:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-28 18:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 18:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 18:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:29:54 --> Total execution time: 0.0478
DEBUG - 2022-03-28 19:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:30:00 --> Total execution time: 0.0458
DEBUG - 2022-03-28 19:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:30:08 --> Total execution time: 0.0454
DEBUG - 2022-03-28 19:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:30:11 --> Total execution time: 0.0437
DEBUG - 2022-03-28 19:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:30:13 --> Total execution time: 0.0510
DEBUG - 2022-03-28 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:31:01 --> Total execution time: 0.0494
DEBUG - 2022-03-28 19:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:31:38 --> Total execution time: 0.0476
DEBUG - 2022-03-28 19:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:01:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:31:39 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-due-list.php 116
ERROR - 2022-03-28 22:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-due-list.php 116
DEBUG - 2022-03-28 22:31:39 --> Total execution time: 0.0521
DEBUG - 2022-03-28 19:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:02:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:32:04 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-complete-list.php 116
ERROR - 2022-03-28 22:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-complete-list.php 116
DEBUG - 2022-03-28 22:32:04 --> Total execution time: 0.0586
DEBUG - 2022-03-28 19:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:33:09 --> Total execution time: 0.0767
DEBUG - 2022-03-28 19:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:33:18 --> Total execution time: 0.0671
DEBUG - 2022-03-28 19:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:03:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:33:33 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-due-list.php 116
ERROR - 2022-03-28 22:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-due-list.php 116
DEBUG - 2022-03-28 22:33:33 --> Total execution time: 0.0495
DEBUG - 2022-03-28 19:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:33:33 --> Total execution time: 0.0707
DEBUG - 2022-03-28 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:33:39 --> Total execution time: 0.0479
DEBUG - 2022-03-28 19:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:06:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:36:23 --> Severity: error --> Exception: Call to undefined method Rents::ThisMonth() C:\xampp\htdocs\personal\jaal\application\controllers\Admin\DashboardController.php 11
DEBUG - 2022-03-28 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:06:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:36:28 --> Severity: error --> Exception: Call to undefined method Rents::ThisMonth() C:\xampp\htdocs\personal\jaal\application\controllers\Admin\DashboardController.php 11
DEBUG - 2022-03-28 19:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:37:11 --> Total execution time: 0.0854
DEBUG - 2022-03-28 19:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:41:06 --> Total execution time: 0.0731
DEBUG - 2022-03-28 19:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 19:14:48 --> Severity: error --> Exception: syntax error, unexpected ''PrevMonth'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\personal\jaal\application\controllers\Admin\DashboardController.php 19
DEBUG - 2022-03-28 19:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 19:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:15:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-28 22:45:21 --> Severity: error --> Exception: Too few arguments to function Rents::PrevMonth(), 0 passed in C:\xampp\htdocs\personal\jaal\application\controllers\Admin\DashboardController.php on line 10 and exactly 1 expected C:\xampp\htdocs\personal\jaal\application\models\Rents.php 14
DEBUG - 2022-03-28 19:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:45:43 --> Total execution time: 0.0676
DEBUG - 2022-03-28 19:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:47:56 --> Total execution time: 0.0590
DEBUG - 2022-03-28 19:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:48:25 --> Total execution time: 0.0478
DEBUG - 2022-03-28 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:48:33 --> Total execution time: 0.0816
DEBUG - 2022-03-28 19:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:48:37 --> Total execution time: 0.0504
DEBUG - 2022-03-28 19:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:48:38 --> Total execution time: 0.0653
DEBUG - 2022-03-28 19:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:49:42 --> Total execution time: 0.0907
DEBUG - 2022-03-28 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:49:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:49:50 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:49:50 --> Total execution time: 0.0468
DEBUG - 2022-03-28 19:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:50:00 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:00 --> Total execution time: 0.0466
DEBUG - 2022-03-28 19:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:50:08 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:08 --> Total execution time: 0.0448
DEBUG - 2022-03-28 19:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:50:18 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:18 --> Total execution time: 0.0459
DEBUG - 2022-03-28 19:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:50:39 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:39 --> Total execution time: 0.0606
DEBUG - 2022-03-28 19:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:46 --> Total execution time: 0.0650
DEBUG - 2022-03-28 19:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:50:51 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:50:51 --> Total execution time: 0.0462
DEBUG - 2022-03-28 19:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:51:06 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:06 --> Total execution time: 0.0479
DEBUG - 2022-03-28 19:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:10 --> Total execution time: 0.0582
DEBUG - 2022-03-28 19:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:51:35 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:35 --> Total execution time: 0.0636
DEBUG - 2022-03-28 19:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:40 --> Total execution time: 0.0424
DEBUG - 2022-03-28 19:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:51:46 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:46 --> Total execution time: 0.0445
DEBUG - 2022-03-28 19:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:51:55 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:51:55 --> Total execution time: 0.0481
DEBUG - 2022-03-28 19:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:52:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:52:43 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:52:43 --> Total execution time: 0.0458
DEBUG - 2022-03-28 19:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:53:01 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:01 --> Total execution time: 0.0489
DEBUG - 2022-03-28 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:53:12 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:12 --> Total execution time: 0.0440
DEBUG - 2022-03-28 19:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:53:38 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:38 --> Total execution time: 0.0663
DEBUG - 2022-03-28 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:53:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:53:59 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:00 --> Total execution time: 0.0663
DEBUG - 2022-03-28 19:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:54:15 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:15 --> Total execution time: 0.0479
DEBUG - 2022-03-28 19:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:54:31 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:32 --> Total execution time: 0.0452
DEBUG - 2022-03-28 19:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:37 --> Total execution time: 0.0424
DEBUG - 2022-03-28 19:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:54:43 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:54:43 --> Total execution time: 0.0485
DEBUG - 2022-03-28 19:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:55:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:55:13 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:55:13 --> Total execution time: 0.0622
DEBUG - 2022-03-28 19:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:55:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:55:34 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:55:34 --> Total execution time: 0.0472
DEBUG - 2022-03-28 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:55:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:55:53 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:55:53 --> Total execution time: 0.0623
DEBUG - 2022-03-28 19:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:56:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:56:05 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:56:05 --> Total execution time: 0.0552
DEBUG - 2022-03-28 19:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:56:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:56:37 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:56:37 --> Total execution time: 0.0658
DEBUG - 2022-03-28 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:57:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 22:57:14 --> You did not select a file to upload.
DEBUG - 2022-03-28 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:57:14 --> Total execution time: 0.0675
DEBUG - 2022-03-28 19:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:57:17 --> Total execution time: 0.0485
DEBUG - 2022-03-28 19:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:58:06 --> Total execution time: 0.0527
DEBUG - 2022-03-28 19:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 22:59:19 --> Total execution time: 0.0585
DEBUG - 2022-03-28 19:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 23:00:10 --> Total execution time: 0.0665
DEBUG - 2022-03-28 19:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 23:00:29 --> Total execution time: 0.0499
DEBUG - 2022-03-28 19:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 23:00:30 --> Total execution time: 0.0787
DEBUG - 2022-03-28 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 23:00:34 --> Total execution time: 0.0485
DEBUG - 2022-03-28 19:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 23:00:35 --> Total execution time: 0.0554
DEBUG - 2022-03-28 19:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 19:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 19:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-28 23:00:59 --> Total execution time: 0.0601
